const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 6: Prompting e tecniche di interazione con l'AI";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 6  ·  Prompting e tecniche di interazione";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  // horizontal flow of numbered boxes with arrows
  async function flow(s, items, o) {
    o = o || {};
    const n = items.length, y = o.y || 1.25, h = o.h || 1.55, gap = o.gap || 0.28;
    const w = (9.0 - gap * (n - 1)) / n;
    for (let i = 0; i < n; i++) {
      const x = 0.5 + i * (w + gap);
      const hi = o.hi === i;
      shapeBox(s, x, y, w, h, hi ? C.accent1 : (o.soft === i ? C.accent6 : C.background2), items[i][1]);
      if (items[i][0]) await iconCircle(s, x + w / 2 - 0.27, y + 0.14, 0.54, items[i][0], hi ? C.background1 : C.accent1, hi ? HEX.a1 : HEX.lt1);
      const ty = items[i][0] ? y + 0.76 : y + 0.15;
      txt(s, (o.numbers === false ? "" : (i + 1) + ". ") + items[i][1], { x: x + 0.08, y: ty, w: w - 0.16, h: 0.42, fontSize: o.headSize || 13, bold: true, color: hi ? C.background1 : C.text1, align: "center", valign: "middle" });
      if (items[i][2]) txt(s, items[i][2], { x: x + 0.1, y: ty + 0.42, w: w - 0.2, h: y + h - ty - 0.48, fontSize: o.bodySize || 11, color: hi ? C.accent6 : C.text2, align: "center" });
      if (i < n - 1) arrow(s, x + w + 0.02, y + h / 2 - 0.16, gap - 0.04);
    }
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 6", { placeholder: "kicker" });
    s.addText("Prompting e tecniche di interazione con l'AI", { placeholder: "title" });
    s.addText("Area: Interagire con l'AI\nContenuti aggiornati a ottobre 2026", { placeholder: "sub" });
    s.addNotes("Benvenuti al sesto tema, il più operativo dell'area 'Interagire con l'AI'. Nel Tema 5 abbiamo visto il senso del dialogo con l'AI, i ruoli che può assumere, la collaborazione e i livelli di delega. Ora passiamo al metodo: come formulare richieste efficaci, come dare il contesto giusto, quali tecniche usare, come costruire il risultato per passi, come ottenere il formato più utile, come applicare tutto questo alle attività professionali e come rendere riutilizzabili le istruzioni che funzionano. Il messaggio del modulo: il prompting è la capacità di collaborare efficacemente con l'AI per trasformare obiettivi, informazioni e idee in risultati utili. Non è un repertorio di formule magiche: insegna principi trasferibili tra strumenti diversi. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026 rispetto alle guide al prompting dei principali fornitori, che vengono aggiornate con l'evoluzione dei modelli; ricontrollarle prima di ogni edizione. Il modulo si presta molto alla pratica: quando possibile, mostrare gli esempi dal vivo su uno strumento autorizzato dall'azienda, senza inserire dati riservati.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la capacità di formulare richieste efficaci, dare un contesto pertinente, usare tecniche diverse in modo proporzionato e migliorare progressivamente i risultati dialogando con il sistema. Il messaggio centrale, che ritroveremo in tutto il modulo: il prompting è la capacità di collaborare efficacemente con l'AI per trasformare obiettivi, informazioni e idee in risultati utili. Collaborare significa che il risultato nasce da un lavoro comune: la persona porta il problema, il contesto, i criteri e il giudizio; il sistema porta velocità, ampiezza di conoscenze generali e capacità di produrre e rielaborare testi, dati e idee. Non ci sono formule rigide da imparare a memoria: ci sono principi che funzionano con strumenti diversi e che si adattano al compito. Una richiesta ben costruita rende il risultato molto più utile; per i contenuti importanti resta buona pratica verificare, in proporzione a ciò che è in gioco.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Formulare richieste efficaci", "Dare un contesto pertinente", "Usare tecniche in modo proporzionato", "Costruire il risultato per passi, dialogando", "Riutilizzare ciò che funziona"], { space: 5 }) });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "messaggio del modulo");
    txt(s, "IL MESSAGGIO DEL MODULO", { x: 5.4, y: 1.4, w: 3.9, h: 0.3, fontSize: 11, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Il prompting è la capacità di collaborare efficacemente con l'AI per trasformare obiettivi, informazioni e idee in risultati utili.", { x: 5.4, y: 1.85, w: 3.9, h: 1.8, fontSize: 17, bold: true, color: C.background1 });
    txt(s, "Principi trasferibili tra strumenti diversi, non formule magiche.", { x: 5.4, y: 3.95, w: 3.9, h: 0.7, fontSize: 13, italic: true, color: C.accent3 });
  }
  {
    const s = content("Il percorso del modulo", "Il percorso segue il lavoro reale di chi usa l'AI, in quattro passi, ciascuno con due sottotemi. Primo: definire, cioè capire che cos'è un prompt e quali elementi rendono efficace una richiesta, a partire dal problema da risolvere (6.1 e 6.2). Secondo: contesto e tecnica, cioè dare le informazioni che cambiano il risultato e scegliere lo strumento proporzionato al compito (6.3 e 6.4). Terzo: dialogare e dare forma, cioè costruire il risultato per passi con feedback specifici e ottenere un formato subito utilizzabile (6.5 e 6.6). Quarto: applicare e riutilizzare, cioè adattare il metodo alle attività professionali e trasformare ciò che funziona in istruzioni riutilizzabili (6.7 e 6.8). Sette sottotemi hanno priorità alta, l'ultimo media. Vanno compresi e applicati: definizione del problema, struttura della richiesta, contesto, istruzioni chiare, iterazione e feedback. Vanno conosciuti e sperimentati: zero-shot, few-shot, scomposizione, alternative, output strutturati, template. Vanno solo accennati: prompt engineering specialistico, ottimizzazione sistematica, tecniche per architetture specifiche. Confini: non ripetiamo il funzionamento tecnico del Tema 2 né l'analisi degli errori del Tema 3; le metodologie di verifica sono l'oggetto del Tema 7; privacy, riservatezza e sicurezza sono trattate nei Temi 14, 17 e 18, ma negli esempi evitiamo sempre di inserire dati riservati in strumenti non autorizzati.");
    const st = [["FiCrosshair", "Definire", "6.1 Fondamenti del prompting", "6.2 Elementi di una richiesta efficace"], ["FiLayers", "Contesto e tecnica", "6.3 Il ruolo del contesto", "6.4 Tecniche fondamentali"], ["FiMessageSquare", "Dialogare e dare forma", "6.5 Prompting iterativo", "6.6 Formato e struttura degli output"], ["FiBriefcase", "Applicare e riutilizzare", "6.7 Attività professionali", "6.8 Istruzioni riutilizzabili"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.2, 2.05, 2.6, i % 2 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.18, 1.35, 0.5, st[i][0]);
      txt(s, st[i][1], { x: x + 0.18, y: 1.95, w: 1.75, h: 0.5, fontSize: 14, bold: true, color: C.text1 });
      txt(s, [{ text: st[i][2], options: { breakLine: true, paraSpaceAfter: 6 } }, { text: st[i][3] }], { x: x + 0.18, y: 2.5, w: 1.75, h: 1.2, fontSize: 11, color: C.text2 });
      if (i < 3) arrow(s, x + 2.07, 2.35, 0.24);
    }
    const lv = [["Comprendere e applicare", "Problema, richiesta, contesto, istruzioni chiare, iterazione e feedback", C.accent1, C.background1], ["Conoscere e sperimentare", "Zero-shot, few-shot, scomposizione, alternative, output strutturati, template", C.accent6, C.text1], ["Solo accennare", "Prompt engineering specialistico, ottimizzazione sistematica", C.background2, C.text1]];
    lv.forEach((l, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 3.98, 2.86, 0.98, l[2], "livello " + l[0]);
      txt(s, l[0], { x: x + 0.15, y: 4.04, w: 2.6, h: 0.3, fontSize: 12, bold: true, color: l[3] });
      txt(s, l[1], { x: x + 0.15, y: 4.34, w: 2.6, h: 0.58, fontSize: 10, color: l[3] });
    });
  }

  // =====================================================================
  section("6.1 Fondamenti");
  divider("6.1", "Fondamenti del prompting", "Il prompt comunica obiettivi, contesto e aspettative: più è chiaro, più il risultato tende a essere utile", "Partiamo dai fondamenti, da comprendere bene: che cos'è un prompt e quali forme può assumere, come cambia il risultato quando la richiesta si arricchisce delle informazioni giuste, quali qualità rendono chiara una richiesta, come aumentare la qualità delle risposte e in che cosa il prompting differisce dalla programmazione tradizionale. Senza ripetere il funzionamento tecnico visto nel Tema 2.");
  {
    const s = content("Che cos'è un prompt", "Il prompt è il testo con cui comunichiamo a un sistema AI che cosa vogliamo, insieme alle informazioni che servono: obiettivi, cioè che cosa vogliamo ottenere; aspettative, cioè come dovrebbe essere il risultato; informazioni, cioè il materiale su cui lavorare. Nel Tema 2 abbiamo visto che il modello riceve anche altre informazioni, come le istruzioni di sistema e la cronologia, ma il prompt è la parte che controlliamo direttamente. Scrivere un prompt assomiglia a dare un incarico a un collaboratore capace, molto rapido, con un'ampia cultura generale, che però non conosce la nostra situazione: più l'incarico è chiaro, più il risultato si avvicina a ciò che serve. Un prompt può assumere tre forme. La domanda chiede un'informazione o una spiegazione: 'Che differenza c'è tra un contratto di appalto e uno di somministrazione?'. L'istruzione indica come comportarsi o impostare il lavoro: 'Rispondi in modo sintetico, comprensibile a chi non ha una formazione giuridica'. La richiesta di esecuzione chiede di produrre qualcosa: 'Riassumi il documento allegato in dieci punti'. Le richieste efficaci spesso combinano le tre forme: un compito, con istruzioni su come svolgerlo. Riconoscere la forma aiuta a capire che cosa manca: una domanda senza istruzioni può ricevere una risposta troppo lunga o tecnica; una richiesta di esecuzione senza indicazioni sul risultato atteso può produrre qualcosa di generico. Il termine 'prompt engineering' indica l'insieme delle tecniche per formulare richieste efficaci; qui ci occupiamo di quelle utili a chi usa l'AI nel lavoro quotidiano.");
    shapeBox(s, 0.5, 1.2, 4.0, 3.75, C.text1, "definizione prompt");
    txt(s, "PROMPT", { x: 0.75, y: 1.38, w: 3.5, h: 0.3, fontSize: 11, bold: true, color: C.accent1, charSpacing: 3 });
    txt(s, "Il testo con cui comunichiamo a un sistema AI obiettivi, aspettative e informazioni.", { x: 0.75, y: 1.8, w: 3.5, h: 1.3, fontSize: 17, color: C.background1 });
    txt(s, "Come dare un incarico a un collaboratore capace e rapido, che però non conosce la nostra situazione.", { x: 0.75, y: 3.45, w: 3.5, h: 1.2, fontSize: 13, italic: true, color: C.accent3 });
    txt(s, "Tre forme, spesso combinate", { x: 4.8, y: 1.2, w: 4.7, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const f = [["FiHelpCircle", "Domanda", "\"Che differenza c'è tra appalto e somministrazione?\""], ["FiSliders", "Istruzione", "\"Rispondi in modo sintetico, comprensibile a chi non è giurista.\""], ["FiPlay", "Richiesta di esecuzione", "\"Riassumi il documento allegato in dieci punti.\""]];
    for (let i = 0; i < 3; i++) {
      const y = 1.65 + i * 0.86;
      shapeBox(s, 4.8, y, 4.7, 0.76, i === 2 ? C.accent6 : C.background2, f[i][1]);
      await iconCircle(s, 4.93, y + 0.14, 0.48, f[i][0]);
      txt(s, f[i][1], { x: 5.55, y: y + 0.05, w: 3.85, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
      txt(s, f[i][2], { x: 5.55, y: y + 0.35, w: 3.85, h: 0.38, fontSize: 11, italic: true, color: C.text2 });
    }
    txt(s, "Le richieste efficaci combinano spesso un compito con istruzioni su come svolgerlo.", { x: 4.8, y: 4.3, w: 4.7, h: 0.6, fontSize: 12, bold: true, color: C.accent1 });
  }
  {
    const s = content("Da una richiesta generica a un risultato utile", "Vediamo un esempio completo, in tre passaggi: questa slide mostra i primi due, la successiva il confronto dei risultati. Primo passaggio, la richiesta generica: 'Scrivi un'email per sollecitare un pagamento'. È una richiesta legittima, e il sistema produrrà un'email corretta nella forma, ma non sa a chi è rivolta, quanto è il ritardo, che relazione c'è con il cliente, che cosa vogliamo ottenere. Secondo passaggio, la richiesta migliorata: aggiungiamo quattro informazioni, evidenziate in slide. L'obiettivo: ottenere il pagamento senza compromettere la relazione. Il contesto: primo sollecito, fattura scaduta da trenta giorni, cliente storico e finora puntuale. Il destinatario: il responsabile amministrativo. Il formato: oggetto e al massimo otto righe, tono cortese ma chiaro, con la proposta di una breve telefonata. Sono quattro righe in più, che richiedono un minuto. Si noti che la richiesta non contiene dati riservati: nome del cliente, numero e importo della fattura si inseriscono dopo, nel testo finale. È una buona abitudine, coerente con le regole sull'uso di dati riservati in strumenti non autorizzati.");
    promptBox(s, 0.5, 1.2, 3.6, 1.55, "Scrivi un'email per sollecitare un pagamento.", { label: "1. Richiesta iniziale generica", labelColor: C.accent2, fontSize: 12 });
    txt(s, "Il sistema deve indovinare destinatario, ritardo, relazione, obiettivo e tono.", { x: 0.5, y: 2.9, w: 3.6, h: 0.75, fontSize: 12, italic: true, color: C.text2 });
    arrow(s, 4.2, 2.3, 0.4, C.accent1);
    shapeBox(s, 4.7, 1.2, 4.8, 3.0, C.accent6, "richiesta migliorata");
    txt(s, "2. Richiesta migliorata", { x: 4.88, y: 1.3, w: 4.4, h: 0.28, fontSize: 11, bold: true, color: C.accent1 });
    txt(s, "Scrivi un'email di primo sollecito per una fattura scaduta da 30 giorni.", { x: 4.88, y: 1.62, w: 4.45, h: 0.45, fontSize: 11, color: C.text1, fontFace: "Courier New" });
    const el = [["Obiettivo", "ottenere il pagamento senza compromettere la relazione."], ["Contesto", "cliente storico, finora sempre puntuale."], ["Destinatario", "il responsabile amministrativo."], ["Formato", "oggetto e massimo 8 righe; tono cortese ma chiaro; proponi una breve telefonata."]];
    el.forEach((e, i) => {
      const y = 2.12 + i * 0.5;
      shapeBox(s, 4.88, y + 0.05, 1.15, 0.32, C.accent1, "etichetta " + e[0]);
      txt(s, e[0], { x: 4.88, y: y + 0.05, w: 1.15, h: 0.32, fontSize: 10, bold: true, color: C.background1, align: "center", valign: "middle" });
      txt(s, e[1], { x: 6.12, y, w: 3.25, h: 0.45, fontSize: 10, color: C.text1, fontFace: "Courier New", valign: "middle" });
    });
    banner(s, 4.38, "Nome del cliente, numero e importo si inseriscono dopo: per un buon testo non servono dati riservati.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Che cosa cambia nel risultato", "Terzo passaggio: il confronto dei risultati. I due testi in slide sono output illustrativi, scritti per il corso per rappresentare in modo tipico ciò che si ottiene con le due richieste; non sono stati generati da un modello specifico. Il consiglio è di ripetere la prova dal vivo con lo strumento autorizzato: i testi saranno diversi, ma la differenza tra le due versioni sarà simile. Il primo risultato è corretto nella forma ma impersonale: potrebbe essere inviato a chiunque, e con un cliente storico rischia di suonare freddo. Il secondo si avvicina a ciò che serve, e ogni miglioramento dipende da un'informazione aggiunta. Il contesto, cliente storico e puntuale, ha prodotto un tono che riconosce la relazione e ipotizza una svista. Il destinatario ha orientato il registro. L'obiettivo ha portato a una proposta concreta, la telefonata, invece di un semplice richiamo. Il formato ha prodotto un oggetto chiaro e un testo breve. Il messaggio didattico: non abbiamo usato formule speciali, abbiamo dato al sistema le informazioni che un collega avrebbe chiesto. E il risultato richiede meno correzioni. Domanda per l'aula: quale altra informazione cambierebbe ancora il testo? Per esempio, se esiste già un contatto diretto con il cliente.");
    promptBox(s, 0.5, 1.2, 4.35, 2.35, "Oggetto: Sollecito di pagamento\n\nGentile Cliente,\nle ricordiamo che la fattura [n.] risulta ancora da saldare. La invitiamo a provvedere al più presto.\nDistinti saluti", { label: "Con la richiesta generica", labelColor: C.accent2, fontSize: 10 });
    promptBox(s, 5.15, 1.2, 4.35, 2.35, "Oggetto: Fattura [n.] scaduta da 30 giorni\n\nGentile [Nome],\ndai nostri controlli la fattura [n.] risulta ancora aperta: immagino si tratti di una svista, vista la puntualità di sempre. Se ci fosse qualche problema, possiamo sentirci al telefono questa settimana.\nUn cordiale saluto", { label: "Con la richiesta migliorata", fill: C.accent6, fontSize: 10 });
    const m = [["Contesto", "tono che riconosce la relazione"], ["Destinatario", "registro adatto"], ["Obiettivo", "propone una soluzione"], ["Formato", "oggetto chiaro, testo breve"]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 3.7, 2.15, 0.8, C.background2, "effetto " + e[0]);
      txt(s, e[0], { x: x + 0.12, y: 3.74, w: 1.95, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 4.04, w: 1.95, h: 0.4, fontSize: 11, color: C.text1 });
    });
    txt(s, "Output illustrativi, scritti per il corso: ripetere la prova dal vivo con lo strumento autorizzato.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Chiarezza, specificità, pertinenza", "Tre qualità caratterizzano una buona richiesta. La chiarezza: la richiesta si può interpretare in un solo modo; non contiene termini vaghi come 'breve', 'professionale', 'migliora', senza precisare che cosa significano. La specificità: indica ciò che conta per quel compito, come destinatario, scopo, formato, vincoli; non lascia al sistema scelte importanti che preferiremmo fare noi. La pertinenza: contiene le informazioni utili e non quelle superflue o fuorvianti. Il contrario di queste qualità sono l'ambiguità, le informazioni mancanti e il rumore. Quando la richiesta è ambigua, il sistema sceglie un'interpretazione, spesso la più comune; quando mancano informazioni, completa con ipotesi ragionevoli, che però non sempre dichiara. Il risultato può essere sensato ma non adatto. Un test pratico, molto efficace in aula: rileggere la richiesta immaginando di darla a un collega competente che non sa nulla della situazione. Che domande farebbe? Le risposte a quelle domande sono ciò che manca. Domanda di verifica: prendete una richiesta che avete fatto di recente all'AI. Supera il test del collega?");
    const q = [["FiEye", "Chiarezza", "Interpretabile in un solo modo. Niente termini vaghi non precisati.", "Contrario: ambiguità"], ["FiCrosshair", "Specificità", "Indica destinatario, scopo, formato, vincoli. Non lascia al sistema le scelte importanti.", "Contrario: informazioni mancanti"], ["FiFilter", "Pertinenza", "Solo informazioni utili, niente di superfluo o fuorviante.", "Contrario: rumore"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.75, { icon: q[i][0], head: q[i][1], headSize: 16, bodySize: 12,
      body: [{ text: q[i][2], options: { breakLine: true, paraSpaceAfter: 10 } }, { text: q[i][3], options: { bold: true, color: C.accent5 } }] });
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.text1, "test collega");
    await iconCircle(s, 0.7, 4.23, 0.56, "FiUser", C.accent1);
    txt(s, "Il test del collega: quali domande farebbe un collega competente che non sa nulla della situazione? Le risposte sono ciò che manca.", { x: 1.45, y: 4.1, w: 7.9, h: 0.85, fontSize: 13, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Come aumentare la qualità delle risposte", "La qualità della richiesta incide molto sull'utilità del risultato: sulla pertinenza al compito, sull'aderenza a obiettivi e vincoli, su formato, tono e livello di dettaglio, e quindi sul numero di correzioni necessarie. L'output tende a essere generico quanto l'input. Tre comportamenti aiutano a ottenere risposte migliori. Primo: fornire le informazioni pertinenti. Il sistema ha un'ampia conoscenza generale, ma non conosce la nostra situazione, i nostri documenti, le decisioni già prese: ciò che serve va fornito. Secondo: chiedere chiarimenti quando necessario, in entrambe le direzioni. Possiamo invitare il sistema a farci domande se mancano informazioni, e possiamo chiedergli di spiegare un passaggio o di indicare su quali ipotesi si basa. Lo vedremo nel 6.3. Terzo: verificare i contenuti in proporzione all'importanza del compito. Una bozza di email interna richiede una rilettura; una sintesi contrattuale da cui dipende una decisione richiede un controllo sulla fonte. Il prompting rende il risultato più utile; la verifica, quando serve, lo rende utilizzabile con fiducia. Le metodologie di verifica sono l'oggetto del Tema 7.");
    await card(s, 0.5, 1.2, 3.6, 3.75, { icon: "FiTrendingUp", head: "Una buona richiesta migliora", headSize: 15, bodySize: 13, fill: C.accent6,
      body: bullets(["Pertinenza al compito", "Aderenza a obiettivi e vincoli", "Formato, tono, livello di dettaglio", "Numero di correzioni necessarie"], { space: 6 }) });
    txt(s, "Tre comportamenti che fanno la differenza", { x: 4.35, y: 1.2, w: 5.15, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const b = [["FiFileText", "Fornire informazioni pertinenti", "Ciò che riguarda la nostra situazione va dato al sistema."], ["FiHelpCircle", "Chiedere chiarimenti quando serve", "Far emergere dati mancanti e ipotesi, in entrambe le direzioni."], ["FiCheckCircle", "Verificare in proporzione all'importanza", "Una rilettura per una bozza, un controllo sulla fonte per una decisione."]];
    for (let i = 0; i < 3; i++) {
      const y = 1.65 + i * 1.12;
      shapeBox(s, 4.35, y, 5.15, 1.0, C.background2, b[i][1]);
      await iconCircle(s, 4.5, y + 0.23, 0.54, b[i][0]);
      txt(s, b[i][1], { x: 5.2, y: y + 0.1, w: 4.2, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
      txt(s, b[i][2], { x: 5.2, y: y + 0.45, w: 4.2, h: 0.5, fontSize: 12, color: C.text2 });
    }
  }
  {
    const s = content("Prompting e programmazione tradizionale", "Il prompting viene talvolta descritto come programmazione in linguaggio naturale. Il paragone è utile, ma va precisato. Nella programmazione tradizionale si scrivono istruzioni in un linguaggio formale, con una sintassi rigida, che il programma esegue secondo la logica del codice. Il comportamento del software non dipende però solo dal codice: dipende anche dai dati in ingresso, dallo stato del sistema e dall'ambiente in cui gira. Nel prompting si usano prevalentemente richieste in linguaggio naturale, che il modello interpreta: per questo la stessa richiesta può produrre risultati diversi, e le istruzioni sono seguite tanto meglio quanto più sono chiare, coerenti e non in conflitto tra loro. Ne derivano due indicazioni pratiche. Primo: ciascun approccio ha i suoi punti di forza. Per regole fisse e calcoli esatti, il software tradizionale e gli strumenti di calcolo restano la scelta naturale; per testi, linguaggio e compiti aperti, l'AI generativa offre una flessibilità che il codice tradizionale non ha. Secondo: i due approcci sono complementari. Molti assistenti AI scrivono ed eseguono codice per fare calcoli, e molti software integrano l'AI generativa nelle loro funzioni. Nel prompting contano soprattutto qualità comunicative: chiarezza, contesto, esempi, le stesse che servono per spiegare un compito a una persona. Il prompt comunica obiettivi e aspettative; non è un comando che assicura un risultato identico e sempre corretto.");
    table(s, [["", "Programmazione tradizionale", "Prompting"], ["Linguaggio", "Formale, sintassi rigida", "Prevalentemente naturale"], ["Come opera", "Esegue la logica del codice; l'esito dipende anche da input, stato e ambiente", "Interpreta la richiesta; può dare risultati diversi a parità di richiesta"], ["Istruzioni", "Applicate come scritte nel codice", "Seguite meglio se chiare, coerenti e non in conflitto"], ["Punti di forza", "Regole fisse, calcoli esatti, ripetibilità", "Testi, linguaggio, compiti aperti, flessibilità"], ["Competenze chiave", "Tecniche", "Comunicative: chiarezza, contesto, esempi"]], { colW: [1.9, 3.55, 3.55], rowH: 0.52, accentCol: 2, fontSize: 12 });
    banner(s, 4.45, "Approcci complementari: l'AI può scrivere codice e usare strumenti di calcolo, e molti software integrano l'AI.", { h: 0.52, fontSize: 13 });
  }

  // =====================================================================
  section("6.2 Elementi di una richiesta");
  divider("6.2", "Gli elementi di una richiesta efficace", "Un prompt efficace rende espliciti i requisiti rilevanti; non deve essere necessariamente lungo", "Vediamo ora il quadro completo degli elementi che possono comporre una richiesta efficace. È un sottotema da comprendere e applicare, complementare ai due successivi: qui presentiamo il quadro, nel 6.3 approfondiamo il contesto, nel 6.4 le tecniche. Partiamo da un passo che precede la scrittura: la definizione del problema.");
  {
    const s = content("Prima il problema, poi il prompt", "Prima di scrivere la richiesta conviene capire quale problema si vuole risolvere. Molti prompt deludenti non sono scritti male: sono la risposta giusta alla domanda sbagliata. Tre domande aiutano. Quale problema voglio risolvere? Per esempio, non 'scrivere una presentazione', ma 'ottenere l'approvazione di un investimento'. A quale scopo serve il risultato? Che cosa ne farò, chi lo userà, quale decisione o azione deve rendere possibile? Con quali criteri di successo? Come capirò che il risultato è buono: che cosa deve contenere, che cosa lo renderebbe inutilizzabile? Le risposte sono già metà del prompt, e forniscono anche il criterio per valutare il risultato. Quando non si riesce a rispondere, il problema non è ancora chiaro: in questo caso, come visto nel Tema 5, il dialogo con l'AI aiuta a chiarirlo, chiedendo al sistema di porci domande prima di procedere.");
    const q = [["1", "Quale problema voglio risolvere?", "Non \"scrivere una presentazione\", ma \"ottenere l'approvazione di un investimento\""], ["2", "A quale scopo serve il risultato?", "Chi lo userà, quale decisione o azione deve rendere possibile"], ["3", "Con quali criteri di successo?", "Che cosa deve contenere, che cosa lo renderebbe inutilizzabile"]];
    q.forEach((e, i) => {
      const y = 1.2 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.82, i % 2 ? C.background1 : C.background2, e[1]);
      txt(s, e[0], { x: 0.65, y, w: 0.5, h: 0.82, fontSize: 24, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 1.2, y, w: 3.5, h: 0.82, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[2], { x: 4.8, y, w: 4.55, h: 0.82, fontSize: 12, color: C.text2, valign: "middle" });
    });
    banner(s, 4.15, "Molti prompt deludenti sono la risposta giusta alla domanda sbagliata. Le risposte alle tre domande sono già metà del prompt.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Gli elementi di una richiesta: una lista di controllo", "Ecco gli otto elementi che possono comporre una richiesta efficace, ciascuno con un esempio. Il problema e l'obiettivo, che abbiamo appena visto. Il compito: che cosa deve fare concretamente il sistema, per esempio scrivere, riassumere, confrontare, classificare. Il contesto e il destinatario: la situazione, le informazioni di riferimento, chi leggerà o userà il risultato. I vincoli e i requisiti: lunghezza, fonti da usare, cose da includere o evitare, regole da rispettare, come 'usa solo le informazioni del documento' o 'rispetta la terminologia del glossario'. Il formato e il livello di dettaglio: come deve essere strutturato il risultato; lo approfondiremo nel 6.6. I criteri di successo: che cosa rende buono il risultato, per esempio 'leggibile ad alta voce in un minuto'; orientano il lavoro del sistema e ci danno un metro per valutarlo. Il ruolo e la prospettiva: da quale punto di vista affrontare il compito. Precisazione importante: non tutti gli elementi servono sempre. Una richiesta efficace rende espliciti quelli rilevanti per quel compito, e può essere lunga una riga o una pagina. Esercizio suggerito: riscrivere una propria richiesta recente usando la lista come controllo, e notare quali elementi mancavano e quali erano superflui.");
    const e = [["FiHelpCircle", "Problema", "I reclami crescono: da dove partire?"], ["FiTarget", "Obiettivo", "Decidere le priorità di intervento"], ["FiPlay", "Compito", "Scrivi, riassumi, confronta, classifica"], ["FiUsers", "Contesto e destinatario", "Riunione di direzione, dirigenti non tecnici"], ["FiSliders", "Vincoli e requisiti", "Una pagina; solo dati del report"], ["FiLayout", "Formato e dettaglio", "Tre punti, poi una raccomandazione"], ["FiCheckSquare", "Criteri di successo", "Priorità chiare in due minuti"], ["FiUser", "Ruolo e prospettiva", "Rileggilo come un nuovo assunto"]];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.2 + row * 1.52;
      shapeBox(s, x, y, 2.15, 1.38, row === 0 && col < 2 ? C.accent6 : C.background2, e[i][1]);
      await iconCircle(s, x + 0.15, y + 0.15, 0.44, e[i][0]);
      txt(s, e[i][1], { x: x + 0.66, y: y + 0.1, w: 1.42, h: 0.55, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[i][2], { x: x + 0.15, y: y + 0.72, w: 1.88, h: 0.6, fontSize: 11, italic: true, color: C.text2 });
    }
    banner(s, 4.32, "Una lista di controllo, non un modulo da compilare: si esplicita ciò che cambia il risultato.", { h: 0.63, fontSize: 13 });
  }
  {
    const s = content("Anatomia di una richiesta", "Ecco una richiesta completa, scomposta per rendere visibili gli elementi: è lo stesso caso degli esempi della lista di controllo. Il compito: preparare una sintesi del report trimestrale sui reclami. Lo scopo: la sintesi servirà alla riunione di direzione per decidere su quali problemi intervenire per primi. Il destinatario: dirigenti che non conoscono i dettagli operativi. I vincoli: massimo una pagina, solo informazioni presenti nel report. Il formato: tre problemi principali, ciascuno con dimensione, tendenza e possibile causa, poi una raccomandazione. Il criterio di successo: un dirigente deve poter capire le priorità in due minuti. Ogni elemento cambia il risultato: senza il destinatario, la sintesi potrebbe essere troppo tecnica; senza lo scopo, descrittiva invece che orientata alla decisione; senza il vincolo sulle fonti, potrebbe includere considerazioni generali non presenti nel report. Nella pratica, la richiesta si scrive di seguito, in poche righe: la scomposizione serve solo a renderla leggibile in aula. Il report, naturalmente, va condiviso solo con strumenti autorizzati a trattarlo.");
    const parts = [["Compito", "Prepara una sintesi del report trimestrale sui reclami allegato."], ["Scopo", "Servirà alla riunione di direzione per decidere su quali problemi intervenire per primi."], ["Destinatario", "Dirigenti che non conoscono i dettagli operativi."], ["Vincoli", "Massimo una pagina. Usa solo informazioni presenti nel report."], ["Formato", "I tre problemi principali, ciascuno con dimensione, tendenza e possibile causa; poi una raccomandazione."], ["Criterio", "Un dirigente deve capire le priorità in due minuti."]];
    parts.forEach((p, i) => {
      const y = 1.15 + i * 0.6;
      shapeBox(s, 0.5, y, 1.7, 0.52, i % 2 ? C.accent6 : C.accent1, p[0]);
      txt(s, p[0], { x: 0.55, y, w: 1.6, h: 0.52, fontSize: 12, bold: true, color: i % 2 ? C.text1 : C.background1, align: "center", valign: "middle" });
      shapeBox(s, 2.3, y, 7.2, 0.52, C.background2, "testo " + p[0]);
      txt(s, p[1], { x: 2.45, y, w: 6.95, h: 0.52, fontSize: 12, color: C.text1, fontFace: "Courier New", valign: "middle" });
    });
    txt(s, "Ogni elemento cambia il risultato: senza destinatario troppo tecnico, senza scopo solo descrittivo, senza vincolo sulle fonti generico.", { x: 0.5, y: 4.8, w: 9, h: 0.35, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Ruoli e prospettive", "Ruoli e prospettive sono uno strumento semplice e molto utile. Assegnare un ruolo, come 'agisci come un revisore attento alla chiarezza' o 'rispondi come un formatore che spiega a principianti', orienta tono, lessico, livello di dettaglio e aspetti considerati. Indicare una prospettiva è spesso ancora più efficace: 'valuta questa proposta dal punto di vista di un cliente attento ai costi', 'rileggi il testo come lo leggerebbe un nuovo assunto'. Le prospettive fanno emergere aspetti che altrimenti resterebbero in ombra, e si possono combinare chiedendo più punti di vista sullo stesso contenuto. Due indicazioni per usarli bene, già incontrate nel Tema 5. Il ruolo orienta lo stile e l'impostazione, ma non aggiunge conoscenze che il sistema non ha: il risultato si valuta come qualsiasi altro. E il ruolo funziona meglio insieme agli altri elementi: 'sei un esperto di marketing' da solo produce un risultato generico; con obiettivo, destinatario e contesto diventa un'indicazione preziosa.");
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiUser", head: "Ruolo", headSize: 16, bodySize: 12,
      body: [{ text: "Orienta tono, lessico, dettaglio", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["\"Agisci come un revisore attento alla chiarezza\"", "\"Rispondi come un formatore per principianti\""], { space: 4 })) });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiEye", head: "Prospettiva", headSize: 16, bodySize: 12, fill: C.accent6,
      body: [{ text: "Fa emergere aspetti in ombra", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["\"Valutala come un cliente attento ai costi\"", "\"Rileggilo come un nuovo assunto\""], { space: 4 })) });
    await card(s, 0.5, 3.95, 4.35, 1.0, { inline: true, icon: "FiSliders", head: "Il ruolo orienta lo stile, non aggiunge conoscenze", headSize: 13 });
    await card(s, 5.15, 3.95, 4.35, 1.0, { inline: true, icon: "FiLink", head: "Rende di più insieme a obiettivo e contesto", headSize: 13 });
  }
  {
    const s = content("Non serve sempre un prompt lungo", "Un prompt efficace rende espliciti i requisiti rilevanti; non deve necessariamente essere lungo o contenere tutti gli elementi. La complessità della richiesta è proporzionata al compito. Per compiti semplici, una richiesta breve è perfettamente adeguata: 'Traduci in inglese questo paragrafo mantenendo il tono formale'. Aggiungere ruolo, criteri e formato sarebbe inutile. Per compiti complessi, con un destinatario specifico e requisiti precisi, conviene una richiesta strutturata, come quella dell'anatomia. Due errori opposti da evitare. La richiesta troppo povera per un compito complesso, che produce risultati generici e molte iterazioni. E la richiesta sovraccarica: istruzioni ridondanti, vincoli in conflitto, informazioni non pertinenti, che possono confondere il sistema e rendere il prompt difficile da mantenere. La domanda da porsi: quali informazioni cambierebbero il risultato in modo significativo? Quelle vanno incluse; le altre no.");
    promptBox(s, 0.5, 1.2, 4.35, 1.35, "Traduci in inglese questo paragrafo mantenendo il tono formale.", { label: "Compito semplice: richiesta breve", fontSize: 12 });
    promptBox(s, 5.15, 1.2, 4.35, 1.35, "Compito, scopo, destinatario, vincoli, formato, criterio di successo (come nell'anatomia).", { label: "Compito complesso: richiesta strutturata", fill: C.accent6, fontSize: 12 });
    await card(s, 0.5, 2.7, 4.35, 1.4, { inline: true, icon: "FiMinusCircle", head: "Troppo povera", bodySize: 12, body: "Per un compito complesso: risultati generici, molte iterazioni." });
    await card(s, 5.15, 2.7, 4.35, 1.4, { inline: true, icon: "FiPlusCircle", head: "Sovraccarica", bodySize: 12, body: "Istruzioni ridondanti o in conflitto, informazioni non pertinenti." });
    banner(s, 4.25, "Quali informazioni cambierebbero il risultato in modo significativo? Quelle vanno incluse; le altre no.", { h: 0.75, fontSize: 13 });
  }

  // =====================================================================
  section("6.3 Il contesto");
  divider("6.3", "Il ruolo del contesto nel prompting", "Il contesto giusto trasforma una risposta generica in una su misura: pertinente, sufficiente, comprensibile", "Il contesto è l'elemento che più spesso fa la differenza tra un risultato generico e uno utile. In questo sottotema, da comprendere e applicare, vediamo quali informazioni fornire e con quali qualità, come organizzarle, come far emergere le informazioni mancanti, come gestire quelle contraddittorie e come lavorare bene con materiali lunghi, senza ripetere la spiegazione tecnica del Tema 2. I documenti aziendali vanno condivisi solo con strumenti autorizzati a trattarli.");
  {
    const s = content("Che cosa è contesto e come renderlo efficace", "Possiamo distinguere tre tipi di contesto. Le informazioni preliminari: la situazione di partenza, i fatti rilevanti, le definizioni usate in azienda, le decisioni già prese. Il contesto aziendale e professionale: organizzazione, settore, pubblico, prassi, tono abituale, vincoli interni. I documenti e i materiali: testi, dati, esempi di lavori precedenti, linee guida, modelli da seguire. Il sistema ha un'ampia conoscenza generale, ma ciò che è specifico della nostra situazione e cambierebbe il risultato va fornito. Più informazioni, però, non significano automaticamente risultati migliori: il contesto efficace ha tre qualità. È pertinente: contiene ciò che serve per quel compito; se alleghiamo dieci documenti per una domanda che ne riguarda uno, la risposta può mescolarli. È sufficientemente completo: tutto ciò che cambierebbe il risultato, non tutto ciò che sappiamo. È comprensibile: documenti leggibili, informazioni ordinate, sigle interne spiegate, dati in formato chiaro. L'esempio in slide: 'proponi un piano di formazione sull'AI' produce un piano generico; aggiungere numero di dipendenti, familiarità con il digitale, tempo disponibile e regole interne esistenti produce un piano su misura. Domanda di verifica: per un compito ricorrente del vostro lavoro, quali informazioni sono indispensabili e quali aggiungete per abitudine?");
    const t = [["FiInfo", "Informazioni preliminari", "Situazione, fatti, definizioni, decisioni già prese"], ["FiBriefcase", "Contesto aziendale", "Organizzazione, settore, pubblico, prassi, tono"], ["FiFolder", "Documenti e materiali", "Testi, dati, esempi precedenti, linee guida, modelli"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 1.35, { inline: true, icon: t[i][0], head: t[i][1], headSize: 13, bodySize: 11, body: t[i][2] });
    const q = [["Pertinente", "ciò che serve per quel compito"], ["Sufficiente", "ciò che cambierebbe il risultato"], ["Comprensibile", "ordinato, sigle spiegate"]];
    q.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.7, 2.86, 0.62, C.text1, "qualità " + e[0]);
      txt(s, [{ text: e[0] + ": ", options: { bold: true, color: C.accent6 } }, { text: e[1], options: { color: C.background1 } }], { x: x + 0.15, y: 2.7, w: 2.6, h: 0.62, fontSize: 12, valign: "middle" });
    });
    promptBox(s, 0.5, 3.47, 9.0, 1.5, "Proponi un piano di formazione sull'AI per la nostra azienda: 80 dipendenti, metà in produzione con poca familiarità con il digitale. Tempo disponibile: quattro mezze giornate. Esistono già regole interne sull'uso dell'AI, da integrare nel percorso.", { label: "Esempio: il contesto rende il piano su misura", fill: C.accent6, fontSize: 12 });
  }
  {
    const s = content("Distinguere informazioni, istruzioni, esempi", "Quando una richiesta contiene molto materiale, è importante che il sistema capisca il ruolo di ciascuna parte. Le informazioni sono il materiale su cui lavorare: un documento, dei dati, una descrizione della situazione. Le istruzioni dicono che cosa fare con quelle informazioni. Gli esempi mostrano come dovrebbe essere il risultato. Se i tre tipi si mescolano, il sistema può confonderli: per esempio trattare una frase di un documento come un'istruzione, o copiare un esempio invece di usarlo come modello. Pensiamo a un documento allegato che contiene la frase 'rispondere entro cinque giorni': è un contenuto da analizzare, non un'istruzione per il sistema. La soluzione è semplice: separare le parti con titoli o delimitatori, e dire esplicitamente il ruolo di ciascuna. 'Di seguito trovi il testo da analizzare', 'Questo è un esempio del formato che desidero, non del contenuto'. La tecnica della delimitazione sarà ripresa nel 6.4.");
    const p = [["Informazioni", "Il materiale su cui lavorare", "\"Di seguito trovi il testo da analizzare.\"", C.background2], ["Istruzioni", "Che cosa fare con le informazioni", "\"Estrai le scadenze e chi ne è responsabile.\"", C.accent6], ["Esempi", "Come dovrebbe essere il risultato", "\"Questo è un esempio del formato, non del contenuto.\"", C.background2]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.45, p[i][3], p[i][0]);
      txt(s, p[i][0], { x: x + 0.2, y: 1.32, w: 2.46, h: 0.4, fontSize: 17, bold: true, color: C.accent1 });
      txt(s, p[i][1], { x: x + 0.2, y: 1.75, w: 2.46, h: 0.6, fontSize: 13, bold: true, color: C.text1 });
      txt(s, p[i][2], { x: x + 0.2, y: 2.45, w: 2.46, h: 1.1, fontSize: 12, italic: true, color: C.text2, fontFace: "Courier New" });
    }
    banner(s, 3.85, "Separare le parti con titoli o delimitatori e dichiararne il ruolo.", { h: 0.55, fontSize: 13 });
    txt(s, "Così il sistema non scambia un contenuto per un'istruzione e usa gli esempi come modello, senza copiarli.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Far emergere informazioni mancanti e ipotesi", "Spesso non sappiamo di aver omesso informazioni importanti, e il sistema, se non glielo chiediamo, tende a procedere completando con ipotesi ragionevoli. Possiamo cambiare questo comportamento con una o due istruzioni. La prima: chiedere domande di chiarimento prima di procedere. Invece di chiedere direttamente il risultato, si invita il sistema a porre le domande più importanti, e a procedere dopo le risposte. È particolarmente utile in tre situazioni: quando il compito è complesso, quando il risultato ha conseguenze importanti, quando stiamo ancora definendo che cosa ci serve. Due accorgimenti la rendono efficace: limitare il numero di domande, per esempio al massimo tre, e chiedere di procedere direttamente se le informazioni bastano, per non rallentare i compiti semplici. La seconda istruzione: chiedere di distinguere ciò che deriva dalle informazioni fornite da ciò che è un'ipotesi del sistema, così da poterla verificare o correggere. Il beneficio è duplice: le lacune emergono prima, invece di nascondersi in un risultato apparentemente completo, e le ipotesi diventano visibili. Il sistema non sempre individua ogni lacuna, ma la trasparenza migliora molto. Questa tecnica è richiamata anche nella guida alla scelta delle tecniche del 6.4.");
    promptBox(s, 0.5, 1.2, 5.6, 2.55, "Devo organizzare una giornata di formazione per il team commerciale. Prima di proporre un programma, fammi al massimo tre domande, le più importanti. Se le informazioni bastano, procedi direttamente.\n\nNel programma, distingui ciò che deriva dalle mie indicazioni da ciò che è una tua ipotesi.", { label: "Esempio", fill: C.accent6, fontSize: 12 });
    txt(s, "Utile quando", { x: 6.35, y: 1.2, w: 3.15, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["Il compito è complesso", "Le conseguenze sono importanti", "Si sta ancora definendo il bisogno"], { x: 6.35, w: 3.15, y: 1.6, h: 0.45, fontSize: 12 });
    chip(s, 6.35, 3.22, 1.5, 0.55, "Domande limitate", { fill: C.background1, line: { color: C.accent1, width: 1 }, fontSize: 11 });
    chip(s, 8.0, 3.22, 1.5, 0.55, "Procedere se basta", { fill: C.background1, line: { color: C.accent1, width: 1 }, fontSize: 11 });
    banner(s, 3.95, "Le lacune emergono prima e le ipotesi diventano visibili, quindi verificabili e correggibili.", { h: 0.62, fontSize: 13 });
    txt(s, "La trasparenza migliora molto, anche se il sistema non individua sempre ogni lacuna.", { x: 0.5, y: 4.68, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Informazioni contraddittorie", "Capita spesso che il contesto contenga informazioni in contrasto: due versioni di una procedura, documenti con dati diversi, una richiesta che dice una cosa e un allegato che ne dice un'altra. I modelli attuali sono in grado di riconoscere le contraddizioni, soprattutto quando si chiede loro di cercarle; ma non sempre le segnalano spontaneamente, e possono scegliere una delle versioni o combinarle senza dirlo. La soluzione è renderlo un compito esplicito. Prima di tutto, prevenire: fornire le versioni aggiornate dei documenti, eliminare il materiale superato, rileggere le proprie istruzioni. Poi indicare una regola di priorità: 'se il documento e le mie indicazioni sono in conflitto, segui le mie indicazioni', oppure 'prevale la versione più recente'. Infine chiedere di individuare le incongruenze e di distinguere le fonti: 'se trovi informazioni in contrasto, elencale indicando da quale documento proviene ciascuna, e chiedimi quale seguire'. Quest'ultima istruzione è particolarmente utile con documenti che non si conoscono bene, perché trasforma una contraddizione nascosta in un'informazione utile, e spesso fa emergere problemi reali nei documenti stessi.");
    const st = [["FiShield", "Prevenire", "Versioni aggiornate, materiale superato eliminato, istruzioni rilette."], ["FiList", "Indicare una priorità", "\"Se il documento e le mie indicazioni sono in conflitto, segui le mie indicazioni.\""], ["FiSearch", "Chiedere di individuarle", "\"Se trovi informazioni in contrasto, elencale con la fonte di ciascuna e chiedimi quale seguire.\""]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.75, { icon: st[i][0], head: st[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2, body: st[i][2] });
    banner(s, 4.1, "L'AI può riconoscere le contraddizioni, ma non sempre le segnala spontaneamente: chiederlo esplicitamente le fa emergere.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Lavorare con materiali lunghi", "Nel Tema 2 abbiamo visto che cos'è la finestra di contesto e perché è limitata. Qui ci interessano le strategie pratiche, che aiutano anche con gli strumenti più capienti. Primo: con documenti molto lunghi o molti allegati, conviene indicare su quali parti concentrarsi, oppure fornire solo le sezioni pertinenti, perché il sistema può dare meno peso ad alcune parti. Secondo: in una conversazione lunga, le istruzioni date all'inizio possono perdere peso; se sono importanti, conviene ripeterle o riassumerle quando si passa a un nuovo compito. Terzo: per lavori su molti documenti, è spesso più efficace procedere per parti, per esempio riassumendo un documento alla volta e poi chiedendo una sintesi complessiva. Quarto: quando la conversazione diventa lunga o confusa, aprire una nuova conversazione con un riepilogo essenziale. Le soglie dipendono dallo strumento, e molte applicazioni gestiscono automaticamente parte di questi aspetti, ma i principi restano validi.");
    const p = [["FiTarget", "Indicare su che cosa concentrarsi", "o fornire solo le sezioni pertinenti"], ["FiRepeat", "Ripetere le istruzioni importanti", "quando si passa a un nuovo compito"], ["FiLayers", "Procedere per parti", "un documento alla volta, poi la sintesi"], ["FiRefreshCw", "Ripartire con un riepilogo", "quando la conversazione è troppo lunga"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.9, headSize: 14, bodySize: 12 });
    txt(s, "Le soglie dipendono dallo strumento; i principi restano validi.", { x: 0.5, y: 4.4, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }

  // =====================================================================
  section("6.4 Tecniche fondamentali");
  divider("6.4", "Tecniche fondamentali di prompting", "Strumenti diversi per compiti diversi: si parte dalla richiesta più semplice e si aggiunge ciò che serve", "Passiamo alle tecniche, da conoscere e sperimentare. Sono strategie per guidare il sistema, complementari agli elementi del 6.2 e al contesto del 6.3. Partiamo da una guida alla scelta, poi vediamo le tecniche principali con esempi utilizzabili: zero-shot e few-shot, istruzioni strutturate e delimitazione, scomposizione, alternative e confronto con criteri. Il criterio del modulo: non formule da applicare sempre, ma strumenti da scegliere.");
  {
    const s = content("Le tecniche e quando usarle", "Ecco la cassetta degli attrezzi, con un orientamento su quando usare ciascuno strumento. Per compiti semplici e ben definiti, come tradurre, riformulare o rispondere a una domanda, basta lo zero-shot: una richiesta chiara, senza esempi. Quando serve uno stile o un formato preciso, difficile da descrivere, il few-shot, cioè alcuni esempi. Quando la richiesta ha molti elementi o sarà riutilizzata, istruzioni strutturate e delimitazione. Per compiti complessi con più fasi, la scomposizione. Per compiti creativi o decisioni con più opzioni, alternative e confronto con criteri. Quando le informazioni potrebbero essere incomplete, la richiesta di chiarimenti, che abbiamo visto nel 6.3. Le tecniche si combinano: una richiesta strutturata può contenere esempi e chiedere chiarimenti. Ma ogni tecnica aggiunge complessità, e usarle tutte sempre non migliora i risultati. La regola: iniziare con la richiesta più semplice che può funzionare, e aggiungere tecniche quando il risultato mostra che servono. Nota di attualità, verificata a ottobre 2026 sulla guida ufficiale OpenAI 'Reasoning best practices': molti modelli recenti ragionano prima di rispondere. Con questi modelli conviene provare prima senza esempi e aggiungerli solo se servono, e non è necessario chiedere di 'ragionare passo passo', perché lo fanno già; l'istruzione può perfino peggiorare il risultato. Contano di più obiettivo, contesto e criteri chiari. La scomposizione resta utile, ma per una ragione diversa: serve alla persona per controllare ogni passaggio. Esercizio suggerito: dare tre compiti diversi, per esempio una traduzione, una classificazione con categorie aziendali e la preparazione di un piano, e chiedere quale tecnica scegliere per ciascuno e perché.");
    table(s, [["Situazione", "Tecnica indicata"], ["Compito semplice e ben definito", "Zero-shot: richiesta chiara, senza esempi"], ["Stile o formato difficile da descrivere", "Few-shot: alcuni esempi del risultato"], ["Molti elementi o richiesta da riutilizzare", "Istruzioni strutturate e delimitazione"], ["Compito complesso con più fasi", "Scomposizione in passaggi"], ["Compito creativo o decisione con opzioni", "Alternative e confronto con criteri"], ["Informazioni forse incomplete", "Chiarimenti prima dell'esecuzione (6.3)"]], { colW: [4.4, 4.6], rowH: 0.45, accentCol: 1, blankCorner: false });
    banner(s, 4.5, "Iniziare con la richiesta più semplice che può funzionare; aggiungere tecniche quando servono.", { h: 0.47, fontSize: 13 });
  }
  {
    const s = content("Zero-shot e few-shot", "Zero-shot significa chiedere al sistema di svolgere un compito senza fornire esempi, basandosi solo sulla descrizione. È il modo più comune e funziona bene per la grande maggioranza dei compiti, perché i modelli attuali sanno già svolgerne moltissimi. Few-shot significa fornire alcuni esempi, di solito da due a cinque, del risultato desiderato, prima di chiedere al sistema di svolgere il compito su un nuovo caso. Gli esempi comunicano in modo molto efficace ciò che è difficile descrivere a parole: uno stile, un formato preciso, un criterio di classificazione. L'esempio in slide è la classificazione delle richieste dei clienti: con due esempi il sistema capisce le categorie e il formato della risposta, e il risultato è pronto per essere ordinato o contato. Un accorgimento: gli esempi devono essere rappresentativi e vari, perché il sistema tende a imitarli anche in aspetti non voluti, come la lunghezza o il tipo di caso. Con categorie aziendali proprie, conviene aggiungere una breve definizione di ciascuna categoria.");
    promptBox(s, 0.5, 1.2, 3.6, 1.6, "Classifica questa richiesta del cliente come: Informazione, Reclamo o Ordine.", { label: "Zero-shot: senza esempi", fontSize: 12 });
    promptBox(s, 4.3, 1.2, 5.2, 2.75, "Classifica le richieste come negli esempi.\n\nRichiesta: \"Quando arriva il mio pacco?\"\nCategoria: Informazione\n\nRichiesta: \"Il prodotto è arrivato rotto.\"\nCategoria: Reclamo\n\nRichiesta: \"[nuova richiesta]\"\nCategoria:", { label: "Few-shot: con esempi", fill: C.accent6, fontSize: 12 });
    txt(s, "Gli esempi comunicano ciò che è difficile descrivere: stile, formato, criteri.", { x: 0.5, y: 3.0, w: 3.6, h: 0.9, fontSize: 13, italic: true, color: C.text2 });
    banner(s, 4.15, "Esempi rappresentativi e vari: il sistema coglie il criterio senza copiare i dettagli.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Istruzioni strutturate e delimitazione", "Quando una richiesta contiene molti elementi, organizzarla in sezioni ordinate la rende più chiara sia per il sistema sia per chi la scrive e la rilegge. Le istruzioni strutturate dividono la richiesta in parti con un titolo: obiettivo, contesto, compito, vincoli, formato. La delimitazione separa i contenuti da elaborare dalle istruzioni, con segni riconoscibili come linee, virgolette, titoli o etichette di apertura e chiusura. Così il sistema non confonde il testo da analizzare con le istruzioni, e ci si può riferire ai contenuti in modo preciso: 'nel testo tra le linee', 'nel documento A'. L'esempio in slide è una richiesta strutturata per rispondere a un cliente. Non serve una sintassi particolare: qualunque convenzione chiara e coerente funziona. Le guide dei fornitori suggeriscono convenzioni specifiche, come titoli in stile Markdown o etichette tra parentesi angolari, ma il principio è lo stesso: ordine e confini chiari. È la base dei template riutilizzabili, che vedremo nel 6.8.");
    promptBox(s, 0.5, 1.2, 5.6, 3.75, "OBIETTIVO\nPreparare la risposta a un cliente.\n\nCONTESTO\nCliente storico; primo reclamo.\n\nCOMPITO\nScrivi una risposta al messaggio tra le linee.\n\nVINCOLI\nTono cortese; massimo 10 righe; nessun impegno su rimborsi.\n\n-----\n[messaggio del cliente]\n-----", { label: "Richiesta strutturata con testo delimitato", fill: C.accent6, fontSize: 12 });
    await card(s, 6.35, 1.2, 3.15, 1.75, { inline: true, icon: "FiList", head: "Struttura", bodySize: 12, body: "Sezioni con titolo: chiaro per il sistema e per chi rilegge." });
    await card(s, 6.35, 3.1, 3.15, 1.85, { inline: true, icon: "FiColumns", head: "Delimitazione", bodySize: 12, body: "Confini chiari tra istruzioni e contenuti. Qualunque convenzione coerente funziona." });
  }
  {
    const s = content("Scomporre i compiti complessi", "Un compito complesso affidato in una sola richiesta può dare risultati validi, ma difficili da controllare: tutto arriva insieme, e se un passaggio iniziale è impostato male, il problema si porta fino alla fine. La scomposizione divide il compito in fasi, da svolgere in sequenza, rivedendo il risultato di ciascuna prima di passare alla successiva. Prendiamo una proposta di miglioramento del processo di gestione degli ordini. Invece di chiederla in un colpo solo, si procede così: descrivere il processo attuale a partire dalle informazioni fornite; individuare i problemi principali; proporre interventi per ciascuno; valutarli secondo costo, impatto e tempi; redigere la proposta. Il vantaggio principale non è una promessa di maggiore accuratezza, ma il controllo: i risultati intermedi si possono verificare, correggere e migliorare prima di costruirci sopra, e la persona guida il percorso. Si può anche chiedere al sistema di proporre una scomposizione, da rivedere prima di procedere. La scomposizione è anche il principio su cui si basano molti flussi di lavoro con AI e agenti, trattati nel Tema 11.");
    const st = ["Descrivere il processo attuale", "Individuare i problemi principali", "Proporre interventi per ciascuno", "Valutarli per costo, impatto, tempi", "Redigere la proposta"];
    st.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.25, 1.68, 1.75, i === 4 ? C.accent1 : C.background2, t);
      txt(s, String(i + 1), { x: x + 0.12, y: 1.32, w: 0.5, h: 0.45, fontSize: 20, bold: true, color: i === 4 ? C.background1 : C.accent1 });
      txt(s, t, { x: x + 0.12, y: 1.8, w: 1.45, h: 1.1, fontSize: 12, bold: true, color: i === 4 ? C.background1 : C.text1 });
      if (i < 4) arrow(s, x + 1.69, 1.98, 0.15);
    });
    txt(s, "Invece di: \"Scrivi una proposta per migliorare il processo di gestione degli ordini\"", { x: 0.5, y: 3.1, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
    const v = [["FiEye", "Risultati intermedi controllabili"], ["FiEdit3", "Correzioni mirate prima di proseguire"], ["FiUserCheck", "La persona guida il percorso"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 3.6, 2.86, 1.35, { inline: true, icon: v[i][0], head: v[i][1], headSize: 13 });
  }
  {
    const s = content("Alternative e confronto con criteri", "Due tecniche collegate, molto utili per decidere e per creare. La richiesta di alternative: invece di una sola risposta, chiedere più versioni o soluzioni. 'Proponi tre possibili titoli', 'suggerisci tre approcci diversi', 'scrivi due versioni dell'introduzione, una formale e una diretta'. Le alternative ampliano le possibilità, evitano di fermarsi alla prima idea e permettono di scegliere o combinare. Conviene chiedere esplicitamente che siano davvero diverse tra loro, altrimenti si ottengono spesso variazioni minime. Il confronto con criteri definiti: valutare le alternative secondo criteri espliciti, scelti da noi. 'Confronta le tre soluzioni secondo costo, tempi di realizzazione e impatto sui clienti, in una tabella, evidenziando i compromessi'. Definire noi i criteri rende il confronto pertinente alla nostra situazione, ed evita valutazioni su criteri generici. Il confronto aiuta a ragionare in modo ordinato; la scelta resta della persona, che conosce pesi e priorità reali.");
    promptBox(s, 0.5, 1.2, 4.35, 2.2, "Proponi tre approcci davvero diversi per ridurre i tempi di risposta alle richieste dei clienti. Per ciascuno: idea, vantaggi, rischi.", { label: "Richiesta di alternative", fontSize: 12 });
    promptBox(s, 5.15, 1.2, 4.35, 2.2, "Confronta i tre approcci secondo: costo, tempi di realizzazione, impatto sui clienti. Usa una tabella ed evidenzia i compromessi.", { label: "Confronto con criteri definiti", fill: C.accent6, fontSize: 12 });
    await card(s, 0.5, 3.6, 4.35, 1.35, { inline: true, icon: "FiShuffle", head: "Chiedere che siano davvero diverse", bodySize: 12, body: "Più idee tra cui scegliere o da combinare." });
    await card(s, 5.15, 3.6, 4.35, 1.35, { inline: true, icon: "FiUserCheck", head: "I criteri li sceglie la persona", bodySize: 12, body: "Il confronto ordina il ragionamento; la scelta resta umana." });
  }

  // =====================================================================
  section("6.5 Prompting iterativo");
  divider("6.5", "Prompting iterativo", "Il risultato si costruisce per passi: il dialogo migliora l'aderenza al bisogno", "Nel Tema 5 abbiamo visto il valore del dialogo con l'AI. Qui sviluppiamo il metodo operativo: il prompting come conversazione, come capire che cosa migliorare, come formulare feedback efficaci, come raffinare e quando ricominciare. E chiariremo una distinzione utile: il dialogo migliora l'aderenza al bisogno, mentre la correttezza dei contenuti importanti si controlla in una fase distinta.");
  {
    const s = content("Il prompting come conversazione", "Un messaggio liberatorio per molti partecipanti: non è necessario formulare subito il prompt perfetto. Con l'AI generativa si lavora in dialogo, come con un interlocutore operativo con cui sviluppare progressivamente un lavoro. Il ciclo tipico ha cinque momenti. Una richiesta iniziale ragionevole, anche incompleta. Una prima risposta, che è già materiale di lavoro: mostra come il sistema ha capito la richiesta e fa emergere ciò che manca. Un chiarimento, nostro o del sistema: aggiungiamo informazioni, correggiamo l'interpretazione, rispondiamo alle sue domande. Un approfondimento: sviluppiamo un punto, chiediamo alternative, cambiamo forma. E infine un risultato utilizzabile. L'esempio in slide, illustrativo, mostra come la prima risposta diventi l'occasione per un chiarimento che migliora molto il risultato. Due indicazioni. Il dialogo migliora l'aderenza al bisogno: il risultato diventa sempre più simile a ciò che serve. Per i contenuti importanti, la verifica resta una fase distinta, che il dialogo non sostituisce. Spesso conviene chiedere esplicitamente al sistema di fare domande, come visto nel 6.3.");
    await flow(s, [[null, "Richiesta iniziale"], [null, "Prima risposta"], [null, "Chiarimento"], [null, "Approfondimento"], [null, "Risultato utilizzabile"]], { y: 1.2, h: 0.72, hi: 4, numbers: false, headSize: 12, gap: 0.24 });
    shapeBox(s, 0.5, 2.1, 9.0, 1.95, C.background2, "dialogo esempio");
    txt(s, "Esempio illustrativo", { x: 0.7, y: 2.17, w: 4, h: 0.28, fontSize: 11, bold: true, color: C.accent1 });
    const d = [["Persona", "Aiutami a preparare l'agenda della riunione di avvio del progetto."], ["AI", "Propone un'agenda e chiede: quanto dura, chi partecipa, che cosa va deciso?"], ["Persona", "Un'ora, otto persone di tre reparti: dobbiamo decidere responsabilità e tempi."], ["AI", "Rivede l'agenda: tempi per punto, decisione sui ruoli, riepilogo delle azioni."]];
    d.forEach((e, i) => {
      const y = 2.48 + i * 0.38;
      txt(s, e[0], { x: 0.7, y, w: 0.9, h: 0.34, fontSize: 11, bold: true, color: e[0] === "AI" ? C.accent1 : C.text1, valign: "middle" });
      txt(s, e[1], { x: 1.6, y, w: 7.75, h: 0.34, fontSize: 11, color: C.text1, italic: e[0] === "AI", valign: "middle" });
    });
    await card(s, 0.5, 4.2, 4.35, 0.78, { inline: true, icon: "FiSmile", head: "Non serve il prompt perfetto al primo colpo", headSize: 12 });
    await card(s, 5.15, 4.2, 4.35, 0.78, { inline: true, icon: "FiCheckCircle", head: "Il dialogo affina il risultato; i contenuti importanti si verificano", headSize: 12, fill: C.accent6 });
  }
  {
    const s = content("Capire che cosa migliorare", "Per far avanzare il dialogo, il passaggio chiave è l'analisi del risultato: confrontarlo con l'obiettivo e con i criteri di successo definiti all'inizio, come visto nel 6.2, e individuare con precisione che cosa non va. Se non sappiamo dire che cosa non va, non possiamo chiedere di migliorarlo. Le carenze più comuni ricadono in poche categorie, ciascuna con una domanda guida. Il contenuto: manca qualcosa, o c'è qualcosa di superfluo? Il tono o registro: è adatto al destinatario? La struttura o il formato: è quella che serve per l'uso successivo? Il livello di dettaglio: è troppo generico o troppo minuzioso? L'interpretazione del compito: il sistema ha capito che cosa volevamo? Riconoscere la categoria aiuta a formulare il feedback giusto, che vediamo nella slide successiva. Quando l'interpretazione del compito è sbagliata, spesso conviene riformulare la richiesta piuttosto che correggere il risultato.");
    const c = [["FiFileText", "Contenuto", "Manca qualcosa? C'è del superfluo?"], ["FiVolume2", "Tono o registro", "È adatto al destinatario?"], ["FiLayout", "Struttura o formato", "Serve per l'uso successivo?"], ["FiZoomIn", "Livello di dettaglio", "Troppo generico o troppo minuzioso?"], ["FiCompass", "Interpretazione", "Il compito è stato capito?"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.2, 1.68, 2.5, i === 4 ? C.accent6 : C.background2, c[i][1]);
      await iconCircle(s, x + 0.56, 1.35, 0.56, c[i][0]);
      txt(s, c[i][1], { x: x + 0.1, y: 2.0, w: 1.48, h: 0.55, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, c[i][2], { x: x + 0.12, y: 2.6, w: 1.44, h: 0.95, fontSize: 11, color: C.text2, align: "center" });
    }
    banner(s, 3.9, "Il metro di valutazione sono l'obiettivo e i criteri di successo definiti all'inizio.", { h: 0.6, fontSize: 13 });
    txt(s, "Se il compito è stato frainteso, spesso conviene riformulare la richiesta invece di correggere il risultato.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Feedback efficaci", "La qualità del feedback determina la qualità della revisione. Un feedback generico, come 'non mi piace, rifallo' o 'miglioralo', produce di solito un risultato diverso ma non necessariamente migliore, perché il sistema non sa che cosa cambiare. Un feedback efficace è specifico, cioè indica che cosa non va e dove; motivato, cioè spiega perché, così che il sistema possa applicare il criterio anche ad altre parti; costruttivo, cioè indica la direzione del cambiamento. La tabella mostra alcune trasformazioni. Invece di 'troppo lungo', 'riduci a metà, eliminando gli esempi e mantenendo le tre raccomandazioni'. Invece di 'non è professionale', 'usa un tono più formale, senza espressioni colloquiali'. Invece di 'manca qualcosa', 'aggiungi un paragrafo sui tempi di attuazione, che per la direzione è il punto più importante'. Un accorgimento prezioso: dire anche che cosa va bene e deve restare invariato. 'Mantieni la struttura e l'introduzione, cambia solo la conclusione'. Esercizio suggerito: prendere un risultato insoddisfacente e far scrivere un feedback generico e uno efficace, confrontando poi le due revisioni.");
    table(s, [["Feedback generico", "Feedback efficace"], ["\"Troppo lungo\"", "\"Riduci a metà: elimina gli esempi, mantieni le tre raccomandazioni\""], ["\"Non è professionale\"", "\"Tono più formale: niente espressioni colloquiali, prima persona plurale\""], ["\"Manca qualcosa\"", "\"Aggiungi un paragrafo sui tempi di attuazione, il punto più importante per la direzione\""], ["\"Miglioralo\"", "\"Mantieni struttura e introduzione; rendi la conclusione più concreta\""]], { colW: [2.6, 6.4], rowH: 0.62, accentCol: 1, blankCorner: false, fontSize: 12 });
    const c = ["Specifico: che cosa e dove", "Motivato: perché", "Costruttivo: in che direzione", "Dire anche che cosa mantenere"];
    c.forEach((t, i) => chip(s, 0.5 + i * 2.28, 4.45, 2.16, 0.5, t, { fill: C.accent6, fontSize: 11 }));
  }
  {
    const s = content("Raffinare, approfondire, riformulare", "Oltre a correggere, il dialogo permette di fare altre tre cose. Raffinare: aggiungere i requisiti che emergono osservando i risultati. Spesso ci si accorge solo vedendo la prima versione di un vincolo implicito, per esempio che il testo non deve citare un concorrente, o che serve un certo ordine degli argomenti. Approfondire: chiedere di sviluppare un punto, aggiungere dettagli, esempi o spiegazioni: 'sviluppa il secondo punto con un esempio concreto', 'spiega meglio come hai stimato i tempi'. Riformulare: chiedere di riscrivere il risultato per un altro pubblico o con un'altra struttura, oppure riformulare la propria richiesta quando ci si accorge che era impostata male. Un suggerimento pratico: quando il dialogo fa emergere un requisito importante, conviene annotarlo e includerlo nella richiesta iniziale la volta successiva, o nel template, come vedremo nel 6.8. Così ciò che si impara in una conversazione diventa patrimonio per le successive.");
    const c = [["FiSliders", "Raffinare", "Aggiungere i requisiti emersi dai risultati", "\"Non citare i concorrenti; inizia dai benefici per il cliente.\""], ["FiZoomIn", "Approfondire", "Sviluppare un punto, aggiungere dettagli o spiegazioni", "\"Sviluppa il secondo punto con un esempio concreto.\""], ["FiRepeat", "Riformulare", "Riscrivere per altro pubblico o struttura; correggere la richiesta", "\"Riscrivilo per i colleghi del magazzino.\""]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.0, { icon: c[i][0], head: c[i][1], headSize: 16, bodySize: 12,
      body: [{ text: c[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 10 } }, { text: c[i][3], options: { italic: true } }] });
    banner(s, 4.35, "I requisiti emersi in un dialogo si annotano e si includono la volta successiva, o nel template (6.8).", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Continuare o ricominciare", "Nelle conversazioni articolate arriva il momento di chiedersi se continuare a correggere o ricominciare. Conviene continuare quando il risultato si sta avvicinando a ciò che serve, le correzioni sono puntuali e il contesto accumulato è utile. Conviene ricominciare, con una nuova richiesta in una nuova conversazione, quando dopo più iterazioni il risultato non migliora; quando lo stesso errore si ripete nonostante le correzioni; quando ci si accorge che la richiesta iniziale era impostata male; quando la conversazione è diventata lunga e confusa. Ricominciare non significa perdere il lavoro fatto: si scrive una nuova richiesta che incorpora ciò che si è imparato, cioè i requisiti emersi, gli errori da evitare, la parte migliore del risultato ottenuto. Spesso una richiesta nuova e ben impostata ottiene in un passaggio ciò che dieci correzioni non avevano ottenuto. Se nemmeno così il risultato migliora, come visto nel Tema 5, probabilmente mancano informazioni essenziali o il compito richiede un altro strumento.");
    await card(s, 0.5, 1.2, 4.35, 2.8, { icon: "FiArrowRight", head: "Continuare", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Il risultato si sta avvicinando", "Le correzioni sono puntuali", "Il contesto accumulato è utile"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.8, { icon: "FiRefreshCw", head: "Ricominciare", headSize: 16, bodySize: 13,
      body: bullets(["Più iterazioni senza miglioramenti", "Lo stesso errore si ripete", "La richiesta iniziale era impostata male", "Conversazione lunga e confusa"], { space: 3 }) });
    banner(s, 4.15, "Ricominciare con una richiesta che incorpora ciò che si è imparato: requisiti, errori da evitare, parti migliori.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Aderenza e correttezza", "Una distinzione utile per usare bene il dialogo. L'aderenza è la corrispondenza del risultato a ciò che abbiamo chiesto: tono, formato, struttura, contenuti indicati. L'iterazione la migliora molto, ed è il motivo per cui il dialogo è così efficace. La correttezza è la corrispondenza dei contenuti ai fatti: dati, nomi, date, riferimenti, ragionamenti. Su questo l'iterazione aiuta solo in parte, per esempio quando forniamo nuove informazioni o chiediamo di indicare le fonti, ma non sostituisce un controllo. Un testo può essere perfettamente aderente nel tono e nel formato e contenere un dato da correggere; e la cura della forma può farci sembrare 'finito' un testo di cui non abbiamo ancora controllato i fatti. Anche chiedere al sistema 'sei sicuro?' non equivale a una verifica, come visto nel Tema 3. La pratica è semplice: quando il contenuto conta, controllare dati, fonti e passaggi chiave con metodi proporzionati all'importanza. Le metodologie di verifica sono l'oggetto del Tema 7. Concetto chiave del sottotema: l'iterazione migliora l'aderenza al compito; la verifica della correttezza appartiene a una fase distinta.");
    shapeBox(s, 0.5, 1.2, 4.35, 2.75, C.accent6, "aderenza");
    await iconCircle(s, 0.7, 1.35, 0.52, "FiTarget");
    txt(s, "Aderenza", { x: 1.35, y: 1.35, w: 3.3, h: 0.52, fontSize: 18, bold: true, color: C.accent1, valign: "middle" });
    txt(s, "Il risultato corrisponde a ciò che è stato chiesto: tono, formato, struttura, contenuti indicati.", { x: 0.7, y: 2.05, w: 3.95, h: 0.95, fontSize: 13, color: C.text1 });
    txt(s, "Il dialogo la migliora molto.", { x: 0.7, y: 3.2, w: 3.95, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
    shapeBox(s, 5.15, 1.2, 4.35, 2.75, C.text1, "correttezza");
    await iconCircle(s, 5.35, 1.35, 0.52, "FiCheckCircle");
    txt(s, "Correttezza", { x: 6.0, y: 1.35, w: 3.3, h: 0.52, fontSize: 18, bold: true, color: C.background1, valign: "middle" });
    txt(s, "I contenuti corrispondono ai fatti: dati, nomi, date, riferimenti, ragionamenti.", { x: 5.35, y: 2.05, w: 3.95, h: 0.95, fontSize: 13, color: C.accent3 });
    txt(s, "Si controlla in una fase distinta.", { x: 5.35, y: 3.2, w: 3.95, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
    banner(s, 4.1, "Quando il contenuto conta, controllare dati, fonti e passaggi chiave, in proporzione all'importanza del compito.", { h: 0.85, fontSize: 13 });
  }

  // =====================================================================
  section("6.6 Formato e struttura");
  divider("6.6", "Guidare il formato e la struttura degli output", "La forma giusta rende il risultato subito utilizzabile nelle attività successive", "Un risultato pertinente può essere poco utile se ha la forma sbagliata: un testo lungo quando serviva una tabella, un linguaggio tecnico per un pubblico non esperto, un elenco disordinato quando serviva un formato da importare. In questo sottotema, da applicare, vediamo come guidare formato, struttura, dettaglio, tono e destinatario, con un'introduzione agli output strutturati come CSV e JSON e ai criteri verificabili.");
  {
    const s = content("Scegliere il formato in base all'uso", "Senza indicazioni, il sistema sceglie un formato 'medio', di solito testo con paragrafi, talvolta con titoli ed elenchi. Specificare il formato fa risparmiare molto lavoro di adattamento. Le opzioni principali: testo strutturato con titoli e paragrafi, per documenti e spiegazioni; elenchi, per passaggi, requisiti, sintesi; tabelle, per confronti e dati con più attributi; schemi, come sequenze di passaggi, gerarchie, alberi decisionali; documenti professionali, come report, verbali, email; formati strutturati, come CSV e JSON, per altri programmi. La domanda da porsi è: che cosa farò con il risultato? Se va incollato in una presentazione, servono punti brevi; se va confrontato, una tabella; se va importato in un foglio di calcolo, un CSV. Per i documenti professionali, il formato comprende la struttura delle sezioni: indicarla, come nell'esempio del report, è uno dei modi più efficaci per ottenere documenti utilizzabili. Se l'azienda ha modelli propri, fornire un modello vuoto o un esempio ben fatto senza dati riservati è la via più rapida, ed è un'applicazione del few-shot. Anche la lunghezza va indicata in modo concreto: 'una pagina', 'massimo 200 parole', piuttosto che 'breve'. Le strutture di altri documenti ricorrono nel modulo: l'email nel 6.1, il verbale nel template del 6.8.");
    const f = [["FiAlignLeft", "Testo strutturato", "Documenti, spiegazioni"], ["FiList", "Elenchi", "Passaggi, requisiti, sintesi"], ["FiGrid", "Tabelle", "Confronti, dati con più attributi"], ["FiGitBranch", "Schemi", "Sequenze, gerarchie, decisioni"], ["FiFileText", "Documenti professionali", "Sezioni indicate o un modello"], ["FiCode", "Formati strutturati", "CSV, JSON per altri programmi"]];
    await iconGrid(s, f.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 2.45, headSize: 13, bodySize: 12 });
    promptBox(s, 0.5, 3.8, 5.6, 1.15, "Struttura: sintesi in tre righe; contesto; analisi; conclusioni; raccomandazioni. Massimo una pagina.", { label: "Esempio: struttura di un report", fill: C.accent6, fontSize: 11 });
    shapeBox(s, 6.3, 3.8, 3.2, 1.15, C.text1, "domanda formato");
    txt(s, "Che cosa farò con il risultato?", { x: 6.5, y: 3.8, w: 2.85, h: 1.15, fontSize: 15, bold: true, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Dettaglio, tono e destinatario", "Lo stesso contenuto cambia forma a seconda di chi lo riceverà. Tre aspetti vanno guidati: il livello di dettaglio, il tono e lo stile, l'adattamento al destinatario, cioè il suo ruolo, le sue conoscenze, le sue priorità, ciò che deve fare dopo aver letto. L'esempio in slide mostra la stessa informazione, l'introduzione di un nuovo software per le note spese, adattata a tre destinatari: la direzione, interessata a costi, benefici e tempi; i dipendenti, interessati a che cosa cambia per loro e a come fare; l'amministrazione, interessata a controlli, scadenze e integrazione contabile. Un modo efficace per guidare questi aspetti è descrivere il destinatario invece di elencare aggettivi sul tono: 'il testo è per colleghi del magazzino che usano poco il computer' comunica più di 'semplice e chiaro'. E si possono chiedere in un solo passaggio più versioni per destinatari diversi a partire dallo stesso contenuto: è uno degli usi più apprezzati dell'AI nella comunicazione interna.");
    txt(s, "Stessa informazione: il nuovo software per le note spese", { x: 0.5, y: 1.15, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const a = [["FiBriefcase", "Direzione", "Costi, benefici, tempi di adozione", "Sintetico, orientato alla decisione"], ["FiUsers", "Dipendenti", "Che cosa cambia per me, come si fa", "Semplice, pratico, passo passo"], ["FiDollarSign", "Amministrazione", "Controlli, scadenze, integrazione contabile", "Preciso, tecnico, completo"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.6, 2.86, 2.2, { icon: a[i][0], head: a[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2,
      body: [{ text: a[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }, { text: a[i][3], options: {} }] });
    banner(s, 4.0, "Descrivere il destinatario comunica più di un elenco di aggettivi: \"colleghi del magazzino che usano poco il computer\".", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Introduzione agli output strutturati", "Gli output strutturati sono formati pensati per essere letti da altri programmi, oltre che dalle persone. I due più comuni sono il CSV e il JSON. Il CSV è una tabella in formato testo, con una riga per ogni record e i valori separati da un segno, di solito virgola o punto e virgola: si apre direttamente in un foglio di calcolo. Il JSON è un formato con coppie di nomi e valori, molto usato per lo scambio di dati tra applicazioni. Sono utili anche a chi non programma, perché trasformano informazioni disordinate in dati ordinati e riutilizzabili: per esempio, estrarre da venti email dei clienti l'azienda, il prodotto richiesto e la quantità, in un CSV da aprire in un foglio di calcolo. Conviene specificare esattamente i campi, il loro ordine, il separatore e come trattare i valori mancanti. Prima di importare il risultato, conviene dare un'occhiata alla struttura, e controllare a campione i valori più importanti. L'uso di questi formati in integrazioni automatiche è solo accennato in questo modulo.");
    promptBox(s, 0.5, 1.2, 4.35, 1.6, "Estrai da ogni email: azienda, prodotto, quantità. Restituisci un CSV con separatore punto e virgola e intestazione. Se un dato manca, scrivi ND.", { label: "Richiesta", fontSize: 11 });
    promptBox(s, 0.5, 2.95, 4.35, 1.4, "azienda;prodotto;quantità\nAlfa Srl;Modello A;20\nBeta Spa;Modello C;ND", { label: "CSV: si apre in un foglio di calcolo", fill: C.accent6, fontSize: 11 });
    promptBox(s, 5.15, 1.2, 4.35, 2.1, "{\n  \"azienda\": \"Alfa Srl\",\n  \"prodotto\": \"Modello A\",\n  \"quantità\": 20\n}", { label: "JSON: coppie di nomi e valori", fontSize: 11 });
    await card(s, 5.15, 3.45, 4.35, 0.9, { inline: true, icon: "FiList", head: "Specificare campi, ordine, separatore, valori mancanti", headSize: 12 });
    banner(s, 4.5, "Da informazioni sparse a dati pronti da usare: prima di importarli, un rapido controllo di struttura e valori.", { h: 0.48, fontSize: 12 });
  }
  {
    const s = content("Vincoli di presentazione e criteri verificabili", "Oltre al formato generale, si possono indicare vincoli di presentazione precisi: lunghezze massime, numero di punti, presenza o assenza di titoli, lingua, convenzioni per date e numeri, terminologia da usare o evitare. Per esempio: 'date nel formato gg/mm/aaaa', 'importi in euro con due decimali', 'usa sempre il termine collaboratore, non dipendente'. Ancora più utile è formulare criteri verificabili, cioè requisiti che si possono controllare in modo oggettivo sul risultato: 'ogni azione ha un responsabile e una scadenza', 'ogni raccomandazione cita un dato del report', 'leggibile ad alta voce in un minuto'. Hanno un doppio vantaggio: orientano il sistema in modo preciso, e permettono di controllare rapidamente il risultato. Si può anche chiedere al sistema di controllarli prima di consegnare e di segnalare ciò che non è rispettato, come nell'esempio in slide; una rapida rilettura conferma il controllo. Ricordiamo infine che una tabella ordinata o un report ben impaginato rendono il risultato utilizzabile, ma la qualità della forma non dice nulla sulla correttezza dei contenuti. Esercizio suggerito: trasformare un elenco di appunti disordinati in una tabella con colonne definite dai partecipanti.");
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiLayout", head: "Vincoli di presentazione", headSize: 15, bodySize: 12,
      body: bullets(["\"Date nel formato gg/mm/aaaa\"", "\"Importi in euro con due decimali\"", "\"Usa sempre il termine collaboratore\""], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCheckSquare", head: "Criteri verificabili", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["\"Ogni azione ha responsabile e scadenza\"", "\"Ogni raccomandazione cita un dato del report\"", "\"Leggibile ad alta voce in un minuto\""], { space: 4 }) });
    promptBox(s, 0.5, 3.65, 9.0, 0.82, "Prima di consegnare, controlla i criteri elencati e segnalami quelli non rispettati.", { label: "Si può chiedere un autocontrollo", fontSize: 12 });
    txt(s, "I criteri verificabili orientano il sistema e rendono rapido il controllo; una rilettura lo conferma.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text1 });
  }

  // =====================================================================
  section("6.7 Attività professionali");
  divider("6.7", "Prompting per attività professionali", "Gli stessi principi si adattano ad attività diverse: si imparano metodi, non prompt universali", "Applichiamo ora i principi alle attività professionali più comuni. Non costruiamo un catalogo di casi d'uso, oggetto dei Temi 8-11, né un repertorio di prompt da memorizzare: vediamo come gli stessi principi si adattano ad attività diverse, con richieste utilizzabili. Gli esempi sono volutamente privi di dati riservati: nella pratica, documenti e dati aziendali vanno usati solo con strumenti autorizzati.");
  {
    const s = content("Attività creative, analitiche e operative", "Le attività professionali in cui si usa l'AI si possono ricondurre a tre famiglie, che richiedono approcci diversi. Le attività creative, come brainstorming, scrittura di contenuti, ideazione di nomi o campagne: si cercano varietà e originalità. Conviene chiedere molte alternative, indicare tono e vincoli lasciando spazio, iterare per selezionare e combinare. Le attività analitiche, come sintesi documentale, analisi di dati, confronto di alternative: si cercano accuratezza e fedeltà alle fonti. Conviene fornire i materiali, chiedere di basarsi su di essi, distinguere fatti e interpretazioni, definire criteri espliciti e verificare i punti importanti. Le attività operative, come comunicazioni standard, estrazione di dati, compilazione di documenti: si cercano coerenza e ripetibilità. Conviene usare istruzioni strutturate, esempi, formati precisi, template. Riconoscere la natura dell'attività è il primo passo per scegliere il metodo giusto.");
    table(s, [["", "Creative", "Analitiche", "Operative"], ["Si cerca", "Varietà, originalità", "Accuratezza, fedeltà alle fonti", "Coerenza, ripetibilità"], ["Tecniche utili", "Molte alternative, iterazione", "Materiali forniti, criteri espliciti", "Struttura, esempi, template"], ["Istruzione tipica", "\"Proponi dieci idee diverse\"", "\"Usa solo il documento fornito\"", "\"Segui esattamente questo formato\""], ["Valutazione", "Gusto, adeguatezza", "Controllo dei punti importanti", "Controllo di requisiti e campioni"]], { colW: [1.9, 2.35, 2.4, 2.35], rowH: 0.64, accentCol: -1, fontSize: 12 });
    txt(s, "Riconoscere la natura dell'attività è il primo passo per scegliere il metodo.", { x: 0.5, y: 4.8, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Scrittura e revisione di contenuti", "La scrittura è l'attività più diffusa. Per scrivere: dichiarare scopo e destinatario, indicare il messaggio principale, fornire i punti da trattare e i vincoli, chiedere formato e lunghezza, come abbiamo fatto con l'email di sollecito. Qui ci concentriamo sulla revisione di un testo proprio, uno degli usi più efficaci. Conviene indicare che cosa si vuole migliorare, per esempio chiarezza, sintesi, tono, correttezza linguistica, e che cosa deve restare invariato, per esempio i contenuti o la struttura: così il sistema migliora la forma senza cambiare ciò che andava bene. Un'altra richiesta utile è chiedere le modifiche principali con una breve motivazione: si mantiene il controllo e si impara. L'esempio in slide mostra una richiesta di revisione pronta da usare. Come visto nel Tema 5, partire da una propria bozza e chiedere all'AI di rivederla valorizza il pensiero originale della persona.");
    promptBox(s, 0.5, 1.2, 5.6, 2.7, "Rivedi il testo tra le linee per renderlo più chiaro e sintetico.\nNon modificare i contenuti né aggiungere informazioni.\nMantieni la struttura in tre paragrafi.\nIndica le modifiche principali con una breve motivazione.\n\n-----\n[testo]\n-----", { label: "Esempio: revisione", fill: C.accent6, fontSize: 12 });
    const p = [["Scrittura", "Scopo, destinatario, messaggio principale, punti, vincoli, formato"], ["Revisione", "Che cosa migliorare e che cosa non toccare"], ["Modifiche motivate", "Controllo sulle scelte e apprendimento"]];
    p.forEach((e, i) => {
      const y = 1.2 + i * 0.95;
      shapeBox(s, 6.35, y, 3.15, 0.82, C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.05, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.36, w: 2.9, h: 0.44, fontSize: 11, color: C.text1 });
    });
    banner(s, 4.1, "Dire che cosa non toccare permette al sistema di migliorare la forma lasciando intatto ciò che funziona.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Analisi e sintesi documentale", "L'analisi e la sintesi di documenti sono tra gli usi più utili dell'AI nel lavoro: permettono di estrarre in pochi minuti obblighi, scadenze, punti chiave da documenti lunghi. Qui la fedeltà alla fonte conta molto, e alcuni accorgimenti la rendono controllabile. Fornire il documento, invece di affidarsi alla conoscenza generale del sistema. Indicare lo scopo: una sintesi per decidere è diversa da una per informare. Chiedere di basarsi sul documento e di segnalare quando un'informazione non è presente. Chiedere riferimenti alle parti, come sezione, pagina o articolo, per poter controllare rapidamente. Distinguere ciò che il documento dice da ciò che il sistema interpreta. Per documenti lunghi, procedere per parti. L'esempio in slide è una richiesta pronta per analizzare un contratto di fornitura. Per i documenti rilevanti, i riferimenti agli articoli rendono semplice controllare sulla fonte i punti importanti, anche perché una sintesi può essere accurata frase per frase e tralasciare un aspetto rilevante.");
    promptBox(s, 0.5, 1.2, 5.6, 2.45, "Analizza il contratto di fornitura allegato.\nElenca in una tabella: obblighi del fornitore, obblighi nostri, scadenze, penali.\nPer ogni voce indica l'articolo di riferimento.\nUsa solo il testo del contratto; se un elemento non è presente, scrivi \"non indicato\".", { label: "Esempio: analisi documentale", fill: C.accent6, fontSize: 12 });
    txt(s, "Principi", { x: 6.35, y: 1.2, w: 3.15, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["Fornire il documento", "Indicare lo scopo", "Basarsi sul documento", "Riferimenti alle parti", "Fatti distinti da interpretazioni"], { x: 6.35, w: 3.15, y: 1.55, h: 0.4, fontSize: 12 });
    banner(s, 4.1, "I riferimenti agli articoli rendono rapido il controllo sulla fonte dei punti importanti.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Informazioni e dati", "Due attività vicine. Organizzare informazioni: trasformare appunti, email, messaggi in strutture ordinate, come elenchi di azioni, tabelle, schede. Qui i formati del 6.6 sono preziosi: definire colonne e campi, chiedere di non completare i dati mancanti con stime, indicare come trattare i casi ambigui. Analizzare dati: individuare tendenze, confrontare periodi, spiegare variazioni, preparare grafici. Tre accorgimenti. Quando lo strumento lo consente, chiedere che i calcoli vengano eseguiti con codice e di mostrare come sono stati fatti: molti assistenti oggi lo fanno, con risultati affidabili e controllabili. Chiedere di distinguere ciò che i dati mostrano da ciò che è un'ipotesi interpretativa: 'le vendite sono calate del 12%' è un dato, 'probabilmente per la stagionalità' è un'ipotesi, utile ma da valutare. Spiegare il significato delle colonne e delle sigle interne, che il sistema non conosce. I dati aziendali vanno caricati solo in strumenti autorizzati.");
    await card(s, 0.5, 1.2, 4.35, 2.8, { icon: "FiInbox", head: "Organizzare informazioni", headSize: 15, bodySize: 12,
      body: bullets(["Da appunti ed email a tabelle, azioni, schede", "Definire colonne e campi", "Non completare i dati mancanti con stime", "Indicare come trattare i casi ambigui"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.8, { icon: "FiBarChart2", head: "Analizzare dati", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Calcoli eseguiti con codice, mostrando come", "Dati distinti da ipotesi interpretative", "Spiegare colonne e sigle interne"], { space: 3 }) });
    banner(s, 4.15, "\"Le vendite sono calate del 12%\" è un dato. \"Probabilmente per la stagionalità\" è un'ipotesi.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Ricerca, brainstorming e problem solving", "Un gruppo di attività orientate al pensiero, in cui l'AI è un interlocutore particolarmente prezioso. Per la ricerca: definire che cosa si cerca e con quali criteri, chiedere fonti consultabili quando lo strumento ha accesso alla ricerca, e usare i risultati come punto di partenza da approfondire. Per il brainstorming: chiedere molte idee, davvero diverse, eventualmente in categorie; indicare i vincoli senza restringere troppo; poi selezionare, combinare e sviluppare le migliori. Se le idee sembrano prevedibili, chiedere esplicitamente proposte meno convenzionali. Per il problem solving: usare la scomposizione, chiedere le possibili cause prima delle soluzioni, chiedere alternative con criteri definiti, e chiedere esplicitamente obiezioni e rischi, applicando il ruolo di interlocutore critico visto nel Tema 5. L'esempio in slide è una richiesta di problem solving in fasi, pronta da adattare. Il valore dell'AI sta nell'ampliare e strutturare il ragionamento; valutazione e scelta restano della persona.");
    promptBox(s, 0.5, 1.2, 5.6, 3.0, "Il tasso di resi di un nostro prodotto è aumentato negli ultimi tre mesi.\n1. Elenca le possibili cause, raggruppate per area.\n2. Per ciascuna, indica quali dati servirebbero per confermarla.\n3. Proponi tre interventi e confrontali per costo, tempi e impatto.\n4. Indica i rischi principali di ciascun intervento.", { label: "Esempio: problem solving per fasi", fill: C.accent6, fontSize: 12 });
    const a = [["Ricerca", "Criteri chiari, fonti consultabili"], ["Brainstorming", "Molte idee diverse, poi selezione"], ["Problem solving", "Cause, alternative, criteri, rischi"]];
    a.forEach((e, i) => {
      const y = 1.2 + i * 1.0;
      shapeBox(s, 6.35, y, 3.15, 0.88, C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.05, w: 2.9, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.42, w: 2.9, h: 0.42, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.4, "L'AI amplia e struttura il ragionamento; valutazione e scelta restano della persona.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Documenti importanti: lavorare per fasi", "Per report, comunicazioni organizzative, offerte e altri documenti importanti, una strategia molto efficace combina scomposizione e dialogo in quattro fasi. Prima chiedere una scaletta e rivederla: è il momento in cui si decide che cosa dire, e correggere una scaletta costa molto meno che correggere un testo. Poi far sviluppare il testo sezione per sezione. Poi chiedere una revisione critica, per esempio dal punto di vista del destinatario: 'quali domande farebbe la direzione leggendo questo report?'. Infine rileggere e controllare personalmente i contenuti. Per le comunicazioni, gli elementi da dare sono il messaggio principale, il destinatario, il tono, l'azione richiesta e il canale, perché un'email, un messaggio in chat e un avviso in bacheca hanno forme diverse. L'esempio in slide mostra la richiesta della prima fase. Il metodo è lo stesso per un report trimestrale o un'offerta commerciale: cambiano contenuti e requisiti, non i principi. Concetto chiave del sottotema: il metodo si adatta allo scopo e al contesto; si imparano principi, non prompt universali. Esercizio suggerito: ciascun partecipante sceglie un'attività reale, la classifica come creativa, analitica o operativa e scrive una richiesta applicando i principi del modulo; lo sviluppiamo nell'esercitazione del 6.8.");
    await flow(s, [["FiList", "Scaletta", "Chiedere e rivedere la struttura"], ["FiEdit3", "Sviluppo", "Testo sezione per sezione"], ["FiEye", "Revisione critica", "Dal punto di vista del destinatario"], ["FiUserCheck", "Verifica personale", "Rilettura e controllo dei contenuti"]], { y: 1.2, h: 2.0, hi: 3, headSize: 13, bodySize: 11 });
    promptBox(s, 0.5, 3.4, 5.6, 1.55, "Prepara la scaletta di una comunicazione ai colleghi sul nuovo orario del magazzino: messaggio principale, tre punti, azione richiesta. Non scrivere ancora il testo.", { label: "Esempio: la richiesta della prima fase", fill: C.accent6, fontSize: 11 });
    await card(s, 6.35, 3.4, 3.15, 1.55, { head: "Per le comunicazioni", headSize: 13, bodySize: 11, body: "Messaggio principale, destinatario, tono, azione richiesta, canale." });
  }

  // =====================================================================
  section("6.8 Istruzioni riutilizzabili");
  divider("6.8", "Istruzioni riutilizzabili e standardizzazione", "Ciò che funziona si conserva e si condivide: template e assistenti configurati, mantenuti aggiornati", "Ultimo sottotema, a priorità media, da comprendere e conoscere. Quando un'attività si ripete, ha senso non riscrivere ogni volta la richiesta da zero, ma costruire istruzioni riutilizzabili: template, librerie condivise, istruzioni persistenti, assistenti configurati. Vediamo come costruirle, i benefici e le poche attenzioni per mantenerle efficaci. La configurazione tecnica di sistemi complessi appartiene al Tema 11. Chiudiamo con un'esercitazione pratica che percorre tutto il modulo.");
  {
    const s = content("Prompt occasionali e ricorrenti", "La prima distinzione riguarda la frequenza. Un prompt occasionale serve per un'esigenza unica o rara: si scrive, si itera, si usa il risultato, e non vale la pena conservarlo. Un prompt ricorrente serve per un'attività che si ripete: il verbale delle riunioni settimanali, la risposta a un tipo di richiesta frequente, la sintesi mensile di un report, la revisione di testi secondo le regole aziendali. Per i prompt ricorrenti, riscrivere ogni volta la richiesta fa perdere tempo, fa dimenticare requisiti emersi in passato, e produce risultati che variano a seconda di chi scrive. Trasformare la richiesta in un'istruzione riutilizzabile risolve tutti e tre i problemi. Conviene farlo quando l'attività si ripete con una certa frequenza, quando la richiesta ha richiesto diverse iterazioni per funzionare bene, quando più persone svolgono la stessa attività e serve coerenza, quando il risultato deve rispettare standard precisi.");
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiZap", head: "Prompt occasionale", headSize: 16, bodySize: 13, body: "Esigenza unica o rara: si scrive, si itera, si usa. Non serve conservarlo." });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiRepeat", head: "Prompt ricorrente", headSize: 16, bodySize: 13, fill: C.accent6, body: "Attività che si ripete: verbali, risposte frequenti, sintesi periodiche, revisioni secondo regole." });
    txt(s, "Quando trasformarlo in istruzione riutilizzabile", { x: 0.5, y: 3.6, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    ["Attività frequente", "Ha richiesto molte iterazioni", "Più persone, serve coerenza", "Standard precisi da rispettare"].forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.0, 2.15, 0.7, t, { fill: C.background2, fontSize: 12 }));
  }
  {
    const s = content("Template di prompt", "Un template è una richiesta riutilizzabile, con una parte fissa, cioè le istruzioni che valgono sempre, e alcune parti variabili, indicate da segnaposto da compilare ogni volta. L'esempio in slide è un template per il verbale di riunione. La parte fissa contiene il compito, il formato e le regole, come assegnare sempre un responsabile e una scadenza alle azioni e scrivere 'da definire' quando mancano. Le parti variabili, tra parentesi quadre, sono il tipo di riunione, i destinatari e gli appunti. Un buon template incorpora ciò che si è imparato con le iterazioni: i requisiti emersi, gli errori da evitare, gli esempi che funzionano. Per questo costruire un template è anche un modo per consolidare l'esperienza e condividerla. Alcuni consigli: usare istruzioni strutturate e delimitazione, come visto nel 6.4; tenere il template il più semplice possibile; indicare in testa a che cosa serve e chi l'ha scritto; provarlo su casi diversi prima di condividerlo.");
    promptBox(s, 0.5, 1.2, 5.8, 3.75, "COMPITO\nRedigi il verbale della riunione [TIPO DI RIUNIONE] per [DESTINATARI].\n\nFORMATO\n1. Partecipanti\n2. Decisioni\n3. Azioni (responsabile, scadenza)\n4. Prossimi passi\n\nREGOLE\nOgni azione ha un responsabile e una scadenza; se mancano, scrivi \"da definire\".\nUsa solo le informazioni degli appunti.\n\nAPPUNTI\n-----\n[APPUNTI]\n-----", { label: "Template: verbale di riunione", fill: C.accent6, fontSize: 10 });
    await card(s, 6.55, 1.2, 2.95, 1.75, { head: "Parte fissa", headSize: 14, bodySize: 12, body: "Compito, formato, regole: ciò che vale sempre." });
    await card(s, 6.55, 3.1, 2.95, 1.85, { head: "Parti variabili", headSize: 14, bodySize: 12, body: "[Segnaposto] da compilare ogni volta." });
  }
  {
    const s = content("Librerie, istruzioni persistenti, assistenti configurati", "Le istruzioni riutilizzabili si possono conservare e usare in diversi modi, sempre più integrati negli strumenti. Le librerie condivise: raccolte di template organizzate per attività, condivise in un gruppo di lavoro o in azienda, in un documento o in uno spazio comune. Diffondono le buone pratiche e permettono di non ripartire da zero. Le istruzioni persistenti: molti strumenti permettono di impostare istruzioni valide per tutte le conversazioni, come il proprio ruolo, il tono preferito, il formato abituale. Fanno risparmiare tempo ogni giorno; conviene rileggerle ogni tanto, perché si applicano a tutte le richieste e vanno aggiornate quando cambia il lavoro. Gli assistenti configurati: molti strumenti, come visto nel Tema 4, permettono di creare assistenti con istruzioni, documenti di riferimento e talvolta collegamenti propri, dedicati a un'attività, e di condividerli con i colleghi. Sono l'evoluzione naturale di un template molto usato: chi lo usa trova già il contesto e le regole, e deve solo fornire il caso specifico. Due precisazioni. Il comportamento effettivo dipende dalle funzionalità dello strumento: che cosa si può configurare, come vengono usati i documenti, che cosa si condivide. E le configurazioni vanno mantenute aggiornate, come i template. La configurazione tecnica degli assistenti è trattata nel Tema 11.");
    const c = [["FiBookOpen", "Librerie condivise", "Template organizzati per attività, condivisi nel gruppo o in azienda", "Diffondono le buone pratiche"], ["FiUser", "Istruzioni persistenti", "Ruolo, tono, formato abituale validi per tutte le conversazioni", "Da rileggere quando cambia il lavoro"], ["FiUserCheck", "Assistenti configurati", "Istruzioni, documenti e collegamenti dedicati a un'attività", "L'evoluzione di un template molto usato"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.95, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2,
      body: [{ text: c[i][2], options: { breakLine: true, paraSpaceAfter: 10 } }, { text: c[i][3], options: { bold: true, color: C.accent1 } }] });
    banner(s, 4.3, "Il comportamento dipende dalle funzionalità dello strumento; le configurazioni vanno mantenute aggiornate.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Standardizzare: benefici e manutenzione", "Quando le istruzioni sono usate da più persone o per attività importanti, la standardizzazione porta benefici concreti. Riduce il lavoro ripetitivo: non si riscrive ogni volta la stessa richiesta. Rende coerenti i risultati, indipendentemente da chi usa l'istruzione. Permette di condividere le buone pratiche: ciò che una persona ha imparato con molte iterazioni diventa disponibile a tutti. Facilita l'onboarding: un nuovo collega parte da istruzioni che funzionano. E apre al miglioramento continuo: un template condiviso si può perfezionare con il contributo di chi lo usa. Per mantenere questi benefici bastano poche attenzioni, le stesse di qualsiasi documento aziendale come una procedura o un modulo. Indicare versione e responsabile di ogni istruzione condivisa. Provarla periodicamente su casi reali, anche quando cambia il modello. Aggiornarla quando cambiano procedure, documenti o esigenze. E adattarla ai casi particolari: chi usa un template ne comprende la logica e sa quando serve una modifica. I risultati dei template si controllano come tutti gli altri, in proporzione all'importanza. Concetto chiave del sottotema: le istruzioni riutilizzabili favoriscono coerenza e produttività; vanno mantenute e non sostituiscono il controllo dei risultati.");
    txt(s, "Benefici", { x: 0.5, y: 1.15, w: 5.4, h: 0.35, fontSize: 15, bold: true, color: C.accent1 });
    const b = [["FiZap", "Meno lavoro ripetitivo"], ["FiCopy", "Risultati coerenti"], ["FiShare2", "Buone pratiche condivise"], ["FiUserPlus", "Onboarding più facile"], ["FiTrendingUp", "Miglioramento continuo"]];
    for (let i = 0; i < 5; i++) {
      const y = 1.58 + i * 0.68;
      shapeBox(s, 0.5, y, 5.4, 0.58, i % 2 ? C.background1 : C.background2, b[i][1]);
      await iconCircle(s, 0.62, y + 0.07, 0.44, b[i][0]);
      txt(s, b[i][1], { x: 1.2, y, w: 4.6, h: 0.58, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
    }
    await card(s, 6.15, 1.2, 3.35, 3.75, { icon: "FiTool", head: "Per mantenerli efficaci", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Versione e responsabile", "Prove periodiche su casi reali", "Aggiornare quando cambiano procedure o modelli", "Adattare ai casi particolari, capendone la logica"], { space: 6 }) });
  }
  {
    const s = content("Esercitazione: dal compito reale al template", "Esercitazione conclusiva, applicabile a qualsiasi contesto professionale, da svolgere individualmente o a coppie, in circa 25 minuti, su uno strumento autorizzato e senza dati riservati. I partecipanti seguono sei passi. Uno: individuare un'attività reale del proprio lavoro, per esempio una comunicazione, una sintesi, una classificazione, una preparazione di riunione. Due: formulare una richiesta iniziale, come la scriverebbero d'abitudine, e salvare il risultato. Tre: migliorare la richiesta aggiungendo contesto e criteri, usando la lista di controllo del 6.2, e salvare il nuovo risultato. Quattro: analizzare il risultato con le domande del 6.5. Cinque: dare un feedback specifico, motivato e costruttivo, e osservare la revisione. Sei: valutare se l'attività è ricorrente e, in caso affermativo, trasformare la richiesta finale in un template con parti fisse e segnaposto. Risultato atteso: due versioni della richiesta con i rispettivi risultati, il feedback dato e, se pertinente, una bozza di template. Criterio di confronto, semplice e uguale per tutti: per ogni versione, quante modifiche servono prima di poter usare il risultato? Si assegna un punteggio da 0, pronto all'uso, a 3, da rifare. In plenaria, due o tre partecipanti mostrano la differenza tra le versioni e quale informazione aggiunta ha fatto più differenza. Di solito la versione migliorata ottiene un punteggio nettamente migliore: è la dimostrazione pratica del messaggio del modulo.");
    const st = ["Individuare un'attività reale", "Formulare una richiesta iniziale", "Migliorarla con contesto e criteri", "Analizzare il risultato", "Dare un feedback specifico", "Valutare se farne un template"];
    st.forEach((t, i) => {
      const y = 1.15 + i * 0.6;
      shapeBox(s, 0.5, y, 5.0, 0.52, i % 2 ? C.background1 : C.background2, "passo " + (i + 1));
      txt(s, String(i + 1), { x: 0.62, y, w: 0.4, h: 0.52, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: 1.05, y, w: 4.35, h: 0.52, fontSize: 13, color: C.text1, valign: "middle" });
    });
    await card(s, 5.75, 1.15, 3.75, 1.75, { inline: true, icon: "FiFlag", head: "Risultato atteso", headSize: 14, bodySize: 11, body: "Due versioni della richiesta con i risultati, il feedback dato e, se utile, una bozza di template." });
    shapeBox(s, 5.75, 3.05, 3.75, 1.65, C.text1, "criterio di confronto");
    txt(s, "Criterio di confronto", { x: 5.95, y: 3.12, w: 3.4, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Quante modifiche servono prima di usare il risultato? Da 0 (pronto) a 3 (da rifare).", { x: 5.95, y: 3.5, w: 3.4, h: 1.1, fontSize: 12, color: C.background1 });
    txt(s, "Circa 25 minuti, su uno strumento autorizzato, senza dati riservati.", { x: 0.5, y: 4.8, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo le competenze sviluppate, una per sottotema. Suggerimento: chiedere ai partecipanti di formularle con parole proprie prima di mostrare la slide. 6.1: spiegare che cos'è un prompt e come la qualità della richiesta incide sul risultato. 6.2: definire il problema e rendere espliciti i requisiti rilevanti, senza allungare inutilmente la richiesta. 6.3: fornire un contesto pertinente, sufficiente e comprensibile, e far emergere informazioni mancanti, ipotesi e contraddizioni. 6.4: scegliere tecniche proporzionate al compito, partendo dalla richiesta più semplice. 6.5: costruire il risultato dialogando, con feedback specifici, distinguendo l'aderenza alla richiesta dalla correttezza dei contenuti. 6.6: ottenere formati subito utilizzabili, con criteri verificabili. 6.7: applicare il metodo alle attività professionali, adattandolo alla loro natura. 6.8: costruire, condividere e mantenere istruzioni riutilizzabili. Il filo che le unisce è il messaggio del modulo: il prompting è la capacità di collaborare efficacemente con l'AI per trasformare obiettivi, informazioni e idee in risultati utili.");
    const r = [["6.1", "Capire come la richiesta incide sul risultato"], ["6.2", "Definire il problema ed esplicitare i requisiti rilevanti"], ["6.3", "Dare un contesto pertinente e far emergere ciò che manca"], ["6.4", "Scegliere tecniche proporzionate al compito"], ["6.5", "Costruire il risultato dialogando, distinguendo aderenza e correttezza"], ["6.6", "Ottenere formati subito utilizzabili"], ["6.7", "Applicare il metodo alle attività professionali"], ["6.8", "Costruire e mantenere istruzioni riutilizzabili"]];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.7;
      shapeBox(s, x, y, 4.4, 0.62, row % 2 ? C.background1 : C.background2, "competenza " + t[0]);
      txt(s, t[0], { x: x + 0.12, y, w: 0.55, h: 0.62, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t[1], { x: x + 0.7, y, w: 3.6, h: 0.62, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 4.05, "Il prompting è la capacità di collaborare efficacemente con l'AI per trasformare obiettivi, informazioni e idee in risultati utili.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Uno schema per le richieste importanti", "Traduciamo il tema in uno strumento pratico: uno schema per le richieste importanti, da usare come lista di controllo, non come modulo obbligatorio. Prima di scrivere: qual è il problema, lo scopo, il criterio di successo? Nella richiesta: compito, contesto e destinatario, vincoli, formato; se utile, esempi, ruolo o prospettiva, e l'invito a porre domande se mancano informazioni. Dopo il primo risultato: analizzare che cosa migliorare e dare feedback specifico, oppure ricominciare con una richiesta migliore. Prima di usare il risultato: ricordare che aderenza non significa correttezza, e verificare in proporzione all'importanza, come vedremo nel Tema 7. Se l'attività è ricorrente: trasformare la richiesta in un template. E sempre: nessun dato riservato in strumenti non autorizzati.");
    const st = [["Prima di scrivere", "Problema, scopo, criterio di successo", C.background2], ["Nella richiesta", "Compito, contesto e destinatario, vincoli, formato; se utile esempi, ruolo, domande di chiarimento", C.accent6], ["Dopo il primo risultato", "Che cosa migliorare e feedback specifico, o una nuova richiesta", C.background2], ["Prima di usarlo", "Aderenza non è correttezza: verifica proporzionata all'importanza", C.accent6], ["Se è ricorrente", "Trasformarla in un template", C.background2]];
    st.forEach((e, i) => {
      const y = 1.12 + i * 0.68;
      shapeBox(s, 0.5, y, 9.0, 0.6, e[2], e[0]);
      txt(s, e[0], { x: 0.65, y, w: 2.5, h: 0.6, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.2, y, w: 6.2, h: 0.6, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 4.6, "E sempre: nessun dato riservato in strumenti non autorizzati.", { h: 0.42, fontSize: 12 });
  }
  {
    const s = content("Prossimo passo: il Tema 7", "Il percorso prosegue con il Tema 7, dedicato alla verifica degli output e al pensiero critico. In questo modulo abbiamo visto come il prompting e il dialogo rendano il risultato sempre più aderente al bisogno; il Tema 7 completa il ciclo con la verifica dei contenuti: come controllarli, come verificare fatti e fonti, come valutare un ragionamento, come esercitare il pensiero critico nell'uso quotidiano dell'AI, in proporzione all'importanza del compito. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.background2, "tema 6");
    txt(s, "TEMA 6", { x: 0.75, y: 1.4, w: 3.1, h: 0.35, fontSize: 13, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Prompting e tecniche di interazione", { x: 0.75, y: 1.8, w: 3.1, h: 0.75, fontSize: 18, bold: true, color: C.text1 });
    txt(s, bullets(["Definire il problema", "Formulare la richiesta", "Dialogare e dare forma", "Riutilizzare"], { space: 4 }), { x: 0.75, y: 2.7, w: 3.1, h: 2.0, fontSize: 14, color: C.text2 });
    arrow(s, 4.25, 2.9, 0.55, C.accent1);
    shapeBox(s, 4.95, 1.2, 4.55, 3.75, C.text1, "tema 7");
    txt(s, "TEMA 7", { x: 5.2, y: 1.4, w: 4.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Verifica degli output e pensiero critico", { x: 5.2, y: 1.8, w: 4.1, h: 0.75, fontSize: 18, bold: true, color: C.background1 });
    txt(s, bullets(["Controllare i contenuti", "Verificare fatti e fonti", "Valutare i ragionamenti", "Esercitare il pensiero critico"], { space: 3 }), { x: 5.2, y: 2.7, w: 4.1, h: 2.0, fontSize: 14, color: C.accent3 });
  }
  {
    const s = content("Nota sulle fonti e sugli esempi", "Questa slide è pensata per il relatore. I principi del modulo sono coerenti con le guide al prompting pubblicate dai principali fornitori di modelli, che vengono riviste con l'evoluzione dei modelli: vale la pena consultarle prima di ogni edizione. Guide citate, verificate il 16 ottobre 2026. Anthropic, 'Prompt engineering overview', su platform.claude.com (il vecchio indirizzo docs.claude.com reindirizza qui). OpenAI, 'Prompt engineering' e 'Reasoning best practices', su developers.openai.com (il vecchio indirizzo platform.openai.com reindirizza qui); la seconda conferma le indicazioni sui modelli che ragionano citate nelle note della slide 'Le tecniche e quando usarle'. Google, 'Prompt design strategies' per la Gemini API, su ai.google.dev. Le pagine vengono riorganizzate spesso: se un indirizzo non funziona, cercare il titolo della guida. Gli esempi di prompt e i due output della slide 'Che cosa cambia nel risultato' sono illustrativi, costruiti per il corso e privi di dati riservati: vanno adattati alla realtà aziendale, preferibilmente con casi proposti dai partecipanti, e provati sullo strumento autorizzato prima della sessione.");
    await iconCircle(s, 0.5, 1.2, 0.6, "FiBookmark");
    txt(s, "Per il relatore", { x: 1.3, y: 1.2, w: 8.2, h: 0.6, fontSize: 16, bold: true, color: C.text1, valign: "middle" });
    rowList(s, ["Anthropic: Prompt engineering overview (platform.claude.com)", "OpenAI: Prompt engineering; Reasoning best practices (developers.openai.com)", "Google: Prompt design strategies, Gemini API (ai.google.dev)", "Le guide vengono aggiornate: consultarle prima di ogni edizione", "Esempi e output illustrativi, senza dati riservati: adattarli e provarli sullo strumento autorizzato"], { y: 1.9, h: 0.46, fontSize: 13 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }

  await pres.writeFile({ fileName: "Tema6_Prompting_tecniche_interazione.pptx" });
  await applyTheme("Tema6_Prompting_tecniche_interazione.pptx", THEME);
  console.log("done");
})();
