const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 6: Prompting e tecniche di interazione con l'AI";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 6  ·  Prompting e tecniche di interazione";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 6", { placeholder: "kicker" });
    s.addText("Prompting e tecniche di interazione con l'AI", { placeholder: "title" });
    s.addText("Area: Interagire con l'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al sesto tema, il più operativo dell'area 'Interagire con l'AI'. Nel Tema 5 abbiamo compreso il senso del dialogo con l'AI, i ruoli che può assumere, la collaborazione e i livelli di delega, rimandando a questo tema le tecniche concrete. Ora passiamo al metodo: come formulare richieste efficaci, come selezionare il contesto, quali tecniche usare, come migliorare progressivamente i risultati, come ottenere il formato giusto, come applicare tutto questo alle attività professionali e come rendere riutilizzabili le istruzioni che funzionano. Un'avvertenza importante, che è anche il criterio del documento di perimetro: questo modulo non è un repertorio di formule magiche o di prompt preconfezionati. Insegna principi trasferibili tra strumenti diversi. Una richiesta semplice può essere appropriata quanto una strutturata, e un buon prompt non garantisce un risultato corretto. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026 rispetto alle guide al prompting dei principali fornitori, che vengono aggiornate con l'evoluzione dei modelli; ricontrollarle prima di ogni edizione. Il modulo si presta molto alla pratica; quando possibile, mostrare gli esempi dal vivo su uno strumento autorizzato dall'azienda, senza inserire dati riservati.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la capacità di formulare richieste efficaci, selezionare e organizzare il contesto, usare tecniche di interazione diverse e migliorare progressivamente i risultati. La consapevolezza da sviluppare è altrettanto importante. Il prompting non consiste nell'uso di formule rigide: richiede di definire il problema, comunicare obiettivi e vincoli, offrire informazioni pertinenti e guidare il sistema attraverso le iterazioni. Un prompt ben formulato aumenta le probabilità di ottenere un risultato utile, ma non ne garantisce la correttezza. E l'efficacia dipende anche dal modello, dal compito e dalla capacità di chi usa lo strumento di valutare gli output. Il messaggio centrale del tema: il prompting efficace nasce dalla capacità di definire il problema, comunicarlo con chiarezza, fornire informazioni pertinenti e guidare progressivamente il sistema verso un risultato adeguato, senza confondere aderenza alla richiesta e correttezza.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Formulare richieste efficaci", "Selezionare e organizzare il contesto", "Usare tecniche diverse in modo proporzionato", "Migliorare i risultati per iterazioni"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Il prompting non è un insieme di formule rigide: è definire il problema, comunicare obiettivi e vincoli, dare informazioni pertinenti, guidare il sistema.\n\nUn buon prompt aumenta le probabilità di un risultato utile, ma non ne garantisce la correttezza." });
  }
  {
    const s = content("Dieci domande guida per questo modulo", "Le dieci domande guida accompagnano il modulo. Le prime tre riguardano i fondamenti e gli elementi di una richiesta efficace, a partire dalla definizione del problema. La quarta e la quinta riguardano il contesto e la gestione delle informazioni mancanti. La sesta le tecniche. La settima l'iterazione. L'ottava il formato degli output. La nona la riutilizzabilità delle istruzioni. L'ultima, forse la più importante, i limiti del prompting. Alla fine del modulo torneremo su tutte con una risposta sintetica.");
    qGrid(s, ["Che cos'è un prompt e a che cosa serve?", "Come identificare il problema prima di formulare la richiesta?", "Quali elementi rendono una richiesta chiara e specifica?", "Quali informazioni di contesto sono davvero pertinenti?", "Come chiedere chiarimenti su dati mancanti o ipotesi?", "Quando usare esempi, scomposizione, istruzioni strutturate?", "Come migliorare un output con feedback e iterazione?", "Come ottenere il formato più utile per il proprio lavoro?", "Quando trasformare un prompt in un template?", "Perché un buon prompt non garantisce un risultato corretto?"], 5, 1.2, 1.75, 11);
  }
  {
    const s = content("Il filo conduttore", "Il filo conduttore del modulo è un metodo in quattro passi, che segue il lavoro reale di chi usa l'AI. Primo: definire, cioè capire che cos'è un prompt, quale problema vogliamo risolvere e quali elementi rendono una richiesta efficace, nei sottotemi 6.1 e 6.2. Secondo: dare contesto e scegliere la tecnica, cioè selezionare le informazioni che cambiano il risultato e usare lo strumento proporzionato al compito, nei sottotemi 6.3 e 6.4. Terzo: iterare e dare forma, cioè migliorare il risultato con feedback specifici e ottenere un formato davvero utilizzabile, nei sottotemi 6.5 e 6.6. Quarto: applicare e riutilizzare, cioè adattare il metodo alle attività professionali e trasformare ciò che funziona in istruzioni riutilizzabili, nei sottotemi 6.7 e 6.8. Il messaggio che accompagna tutto il percorso: un buon prompt aumenta le probabilità di un risultato utile, ma non ne garantisce la correttezza.");
    const d = [["FiTarget", "Definire", "Problema, elementi della richiesta", "6.1  6.2"], ["FiLayers", "Contesto e tecnica", "Informazioni pertinenti, strumento giusto", "6.3  6.4"], ["FiRepeat", "Iterare e dare forma", "Feedback specifico, formato utile", "6.5  6.6"], ["FiBookmark", "Applicare e riutilizzare", "Attività reali, template", "6.7  6.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.15, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.05, y: 2.02, w: 2.0, h: 0.45, fontSize: 13, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.45, w: 1.9, h: 0.5, fontSize: 12, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, d[i][3], { x: x + 0.1, y: 2.95, w: 1.9, h: 0.3, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    banner(s, 3.65, "Un buon prompt aumenta le probabilità di un risultato utile, ma non ne garantisce la correttezza.", { h: 0.8, fontSize: 15 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti mantenuti separati. Sette hanno priorità alta, l'ultimo, sulle istruzioni riutilizzabili, priorità media. Il documento di perimetro raccomanda di trattare i sottotemi 6.2, 6.3 e 6.4 in modo complementare: il 6.2 introduce il quadro completo degli elementi di una richiesta, il 6.3 approfondisce il contesto, il 6.4 le tecniche. Vanno compresi e applicati: definizione del problema, struttura della richiesta, gestione del contesto, istruzioni chiare, iterazione e feedback. Vanno conosciuti e sperimentati: zero-shot, few-shot, scomposizione dei compiti, confronto di alternative, output strutturati e template. Vanno solo accennati: prompt engineering specialistico, ottimizzazione sistematica, programmazione di sistemi di prompting e tecniche legate a specifiche architetture. Confini: non ripetiamo il funzionamento tecnico del Tema 2 né l'analisi degli errori del Tema 3; non entriamo nelle metodologie di verifica, che sono l'oggetto del Tema 7; non trattiamo privacy, riservatezza e sicurezza, che sono oggetto dei Temi 14, 17 e 18, ma negli esempi evitiamo sempre di inserire dati riservati in strumenti non autorizzati.");
    pathSlide(s, [["6.1", "Fondamenti del prompting", "Alta"], ["6.2", "Gli elementi di una richiesta efficace", "Alta"], ["6.3", "Il ruolo del contesto", "Alta"], ["6.4", "Tecniche fondamentali", "Alta"], ["6.5", "Prompting iterativo", "Alta"], ["6.6", "Formato e struttura degli output", "Alta"], ["6.7", "Prompting per attività professionali", "Alta"], ["6.8", "Istruzioni riutilizzabili", "Media"]],
      [["Comprendere e applicare", "Definizione del problema, struttura della richiesta, contesto, istruzioni chiare, iterazione e feedback", C.accent1, C.background1], ["Conoscere e sperimentare", "Zero-shot, few-shot, scomposizione, alternative, output strutturati, template", C.accent6, C.text1], ["Solo accennare", "Prompt engineering specialistico, ottimizzazione su benchmark, tecniche per architetture specifiche", C.background2, C.text1]]);
  }

  // =====================================================================
  section("6.1 Fondamenti");
  divider("6.1", "Fondamenti del prompting", "Il prompt comunica obiettivi e aspettative, ma non è un comando che assicura un risultato corretto", "Partiamo dai fondamenti, da comprendere bene. Che cos'è un prompt, quali forme può assumere, che cosa rende una richiesta chiara, perché la qualità dell'input conta, in che cosa il prompting differisce dalla programmazione tradizionale e, fin da subito, quali sono i suoi limiti. Senza ripetere il funzionamento tecnico visto nel Tema 2.");
  {
    const s = content("Che cos'è un prompt", "Il prompt è il testo con cui comunichiamo a un sistema AI che cosa vogliamo: una domanda, un'istruzione, una richiesta, insieme alle informazioni che servono per soddisfarla. Nel Tema 2 abbiamo visto che il modello riceve anche altre informazioni, come le istruzioni di sistema e la cronologia, ma il prompt è la parte che controlliamo noi direttamente. La sua funzione è comunicare: obiettivi, cioè che cosa vogliamo ottenere; aspettative, cioè come dovrebbe essere il risultato; informazioni, cioè il materiale su cui lavorare. In questo senso scrivere un prompt assomiglia a dare un incarico a un collaboratore capace, molto rapido, con un'ampia cultura generale, ma che non conosce nulla della nostra situazione, non può leggerci nel pensiero e tende a riempire i vuoti con le ipotesi più comuni. Più l'incarico è chiaro, più il risultato si avvicina a ciò che serve. Il termine 'prompt engineering', ingegneria dei prompt, indica l'insieme delle tecniche per formulare richieste efficaci; in questo modulo ci occupiamo delle tecniche utili a chi usa l'AI nel lavoro quotidiano, non di quelle specialistiche.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.text1, "definizione prompt");
    txt(s, "PROMPT", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 11, bold: true, color: C.accent1, charSpacing: 3 });
    txt(s, "Il testo con cui comunichiamo a un sistema AI che cosa vogliamo, insieme alle informazioni che servono.", { x: 0.75, y: 1.8, w: 3.9, h: 1.4, fontSize: 16, color: C.background1 });
    txt(s, "Come dare un incarico a un collaboratore capace e rapido, che però non conosce nulla della nostra situazione.", { x: 0.75, y: 3.4, w: 3.9, h: 1.2, fontSize: 13, italic: true, color: C.accent3 });
    txt(s, "Comunica", { x: 5.15, y: 1.2, w: 4.35, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const f = [["FiTarget", "Obiettivi", "Che cosa vogliamo ottenere"], ["FiCheckSquare", "Aspettative", "Come dovrebbe essere il risultato"], ["FiFileText", "Informazioni", "Il materiale su cui lavorare"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.7 + i * 1.08;
      await iconCircle(s, 5.15, y, 0.55, f[i][0]);
      txt(s, f[i][1], { x: 5.85, y: y - 0.02, w: 3.65, h: 0.32, fontSize: 15, bold: true, color: C.text1 });
      txt(s, f[i][2], { x: 5.85, y: y + 0.3, w: 3.65, h: 0.4, fontSize: 13, color: C.text2 });
    }
  }
  {
    const s = content("Domanda, istruzione, richiesta di esecuzione", "Un prompt può assumere tre forme principali, che spesso si combinano. La domanda chiede un'informazione o una spiegazione: 'Che differenza c'è tra un contratto di appalto e uno di somministrazione?'. L'istruzione indica come comportarsi o come impostare il lavoro: 'Rispondi in modo sintetico, con un linguaggio comprensibile a chi non ha una formazione giuridica'. La richiesta di esecuzione chiede di produrre qualcosa o di svolgere un compito su un materiale: 'Riassumi il documento allegato in dieci punti'. Molti prompt efficaci combinano le tre forme: una richiesta di esecuzione, accompagnata da istruzioni su come svolgerla e talvolta da domande da tenere presenti. Riconoscere la forma della propria richiesta aiuta a capire che cosa manca: una domanda senza istruzioni può ricevere una risposta troppo lunga o troppo tecnica; una richiesta di esecuzione senza indicazioni sul risultato atteso può produrre qualcosa di generico.");
    const t = [["FiHelpCircle", "Domanda", "Chiede un'informazione o una spiegazione", "\"Che differenza c'è tra appalto e somministrazione?\""], ["FiSliders", "Istruzione", "Indica come comportarsi o impostare il lavoro", "\"Rispondi in modo sintetico, comprensibile a chi non è giurista.\""], ["FiPlay", "Richiesta di esecuzione", "Chiede di produrre o svolgere qualcosa", "\"Riassumi il documento allegato in dieci punti.\""]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.0, { icon: t[i][0], head: t[i][1], headSize: 16, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2,
      body: [{ text: t[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 10 } }, { text: t[i][3], options: { italic: true } }] });
    banner(s, 4.35, "I prompt efficaci spesso combinano le tre forme: un compito, con istruzioni su come svolgerlo.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Richieste generiche e contestualizzate", "Il confronto in slide mostra la differenza tra una richiesta generica e una contestualizzata sullo stesso compito. La richiesta generica: 'Scrivi un'email per sollecitare un pagamento'. Il sistema produrrà un'email plausibile, ma generica: non sa a chi è rivolta, quanto è il ritardo, che tipo di relazione c'è con il cliente, che tono usare. La richiesta contestualizzata aggiunge le informazioni che cambiano il risultato: si tratta di un cliente storico e importante, la fattura è scaduta da trenta giorni, è il primo sollecito, il tono deve essere cortese ma chiaro, l'email deve essere breve e proporre un contatto telefonico. Il risultato sarà molto più vicino a ciò che serve, e richiederà meno correzioni. Si noti che la richiesta contestualizzata non contiene dati riservati: non servono il nome del cliente o l'importo esatto per ottenere un buon testo, che si potranno inserire dopo. È una buona abitudine, coerente con l'avvertenza del documento di perimetro sull'uso di dati riservati in strumenti non autorizzati.");
    promptBox(s, 0.5, 1.2, 4.35, 1.4, "Scrivi un'email per sollecitare un pagamento.", { label: "Richiesta generica", labelColor: C.accent2, fontSize: 12 });
    txt(s, "Risultato plausibile ma generico: destinatario, ritardo, relazione e tono sono ignoti.", { x: 0.5, y: 2.75, w: 4.35, h: 0.7, fontSize: 12, italic: true, color: C.text2 });
    promptBox(s, 5.15, 1.2, 4.35, 3.0, "Scrivi un'email di primo sollecito per una fattura scaduta da 30 giorni. Il destinatario è un cliente storico e importante. Tono cortese ma chiaro, massimo 8 righe. Proponi un breve contatto telefonico per chiarire eventuali problemi.", { label: "Richiesta contestualizzata", fill: C.accent6, fontSize: 12 });
    banner(s, 4.35, "Non servono dati riservati per un buon testo: nome del cliente e importo si inseriscono dopo.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Chiarezza, specificità, pertinenza", "Tre qualità caratterizzano una buona richiesta. La chiarezza: la richiesta si può interpretare in un solo modo; non contiene termini vaghi come 'breve', 'professionale', 'migliora', senza precisare che cosa significano. La specificità: indica ciò che conta per quel compito, come destinatario, scopo, formato, vincoli; non lascia al sistema scelte importanti che preferiremmo fare noi. La pertinenza: contiene le informazioni utili e non quelle superflue o fuorvianti, che possono distrarre il sistema o orientarlo male. Il contrario di queste qualità sono l'ambiguità e le informazioni mancanti, che abbiamo già incontrato nel Tema 5: quando la richiesta è ambigua, il sistema sceglie un'interpretazione, spesso la più comune; quando mancano informazioni, il sistema fa ipotesi, quasi sempre senza dichiararle. In entrambi i casi il risultato può essere ragionevole ma non adatto. Un test pratico: rileggere la richiesta immaginando di darla a un collega competente che non sa nulla della situazione. Che domande farebbe? Le risposte a quelle domande sono ciò che manca.");
    const q = [["FiEye", "Chiarezza", "Interpretabile in un solo modo. Niente termini vaghi non precisati.", "Contrario: ambiguità"], ["FiCrosshair", "Specificità", "Indica destinatario, scopo, formato, vincoli. Non lascia al sistema le scelte importanti.", "Contrario: informazioni mancanti"], ["FiFilter", "Pertinenza", "Solo informazioni utili, niente di superfluo o fuorviante.", "Contrario: rumore"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.75, { icon: q[i][0], head: q[i][1], headSize: 16, bodySize: 12,
      body: [{ text: q[i][2], options: { breakLine: true, paraSpaceAfter: 10 } }, { text: q[i][3], options: { bold: true, color: C.accent5 } }] });
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.text1, "test collega");
    await iconCircle(s, 0.7, 4.23, 0.56, "FiUser", C.accent1);
    txt(s, "Il test del collega: quali domande farebbe un collega competente che non sa nulla della situazione? Le risposte sono ciò che manca.", { x: 1.45, y: 4.1, w: 7.9, h: 0.85, fontSize: 13, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Qualità dell'input e utilità dell'output", "Esiste una relazione diretta tra la qualità della richiesta e l'utilità del risultato, che si può riassumere così: l'output tende a essere generico quanto l'input. Una richiesta vaga produce un risultato medio, adatto a tutti e a nessuno; una richiesta che esplicita obiettivi, contesto e aspettative produce un risultato su misura. Ma è importante non sopravvalutare questa relazione. La qualità della richiesta aumenta le probabilità di un risultato utile, cioè aderente a ciò che si è chiesto. Non garantisce che il risultato sia corretto, perché la correttezza dipende anche dalle capacità del modello, dalle informazioni disponibili e dal compito. E non può compensare la mancanza di informazioni: se il sistema non ha i dati necessari, una richiesta perfetta otterrà una risposta perfettamente formulata e potenzialmente inventata. Lo schema in slide distingue due dimensioni che riprenderemo spesso: l'utilità, cioè l'aderenza alla richiesta, su cui il prompting incide molto; la correttezza, su cui incide solo in parte e che richiede verifica.");
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiTrendingUp", head: "Su che cosa incide molto", headSize: 15, bodySize: 13, fill: C.accent6,
      body: bullets(["Pertinenza al compito", "Aderenza a obiettivi e vincoli", "Formato, tono, livello di dettaglio", "Numero di correzioni necessarie"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiAlertCircle", head: "Su che cosa incide solo in parte", headSize: 15, bodySize: 13,
      body: bullets(["Correttezza dei contenuti", "Capacità che il modello non ha", "Informazioni che il sistema non possiede"], { space: 3 }) });
    banner(s, 4.0, "L'output tende a essere generico quanto l'input. Ma una richiesta perfetta non rende vera una risposta.", { h: 0.95 });
  }
  {
    const s = content("Prompting e programmazione tradizionale", "Il prompting viene talvolta descritto come una forma di programmazione in linguaggio naturale. Il paragone è utile solo in parte, e le differenze sono istruttive. Nella programmazione tradizionale si scrivono istruzioni in un linguaggio formale, con una sintassi rigida: il programma esegue esattamente ciò che è scritto, sempre nello stesso modo, e se c'è un errore lo si trova e lo si corregge. Nel prompting si scrivono richieste in linguaggio naturale, interpretate dal modello: il risultato dipende dall'interpretazione, può variare a parità di richiesta, e non c'è garanzia che le istruzioni vengano seguite alla lettera, soprattutto se sono molte o in conflitto tra loro. Ne derivano due conseguenze pratiche. Primo: non bisogna aspettarsi dal prompting la precisione della programmazione; per i compiti che richiedono esattezza assoluta, come calcoli o regole fisse, è meglio affidarsi a software tradizionale o a strumenti di calcolo. Secondo: nel prompting contano qualità comunicative più che tecniche, come chiarezza, completezza, esempi, che sono le stesse che servono per spiegare un compito a una persona.");
    table(s, [["", "Programmazione tradizionale", "Prompting"], ["Linguaggio", "Formale, sintassi rigida", "Naturale, interpretato"], ["Esecuzione", "Esattamente ciò che è scritto", "Secondo l'interpretazione del modello"], ["Ripetibilità", "Sempre uguale", "Può variare"], ["Istruzioni seguite", "Sempre, alla lettera", "Non garantito, specie se molte o in conflitto"], ["Competenze chiave", "Tecniche", "Comunicative: chiarezza, completezza, esempi"]], { colW: [2.2, 3.4, 3.4], rowH: 0.55, accentCol: 2 });
    banner(s, 4.55, "Per esattezza assoluta (calcoli, regole fisse) meglio software tradizionale o strumenti di calcolo.", { h: 0.45, fontSize: 13 });
  }
  {
    const s = content("Prompting e limiti delle istruzioni", "Questa integrazione del sottotema mette in chiaro, fin dall'inizio, ciò che il prompting non può fare. Un prompt ben costruito non conferisce al sistema capacità che non possiede: se il modello non conosce una normativa recente, scrivere 'sei un esperto aggiornato di questa normativa' non gliela farà conoscere, come abbiamo visto nel Tema 5 parlando di ruoli. Non elimina automaticamente errori o allucinazioni: istruzioni come 'non inventare nulla' o 'sii preciso' possono ridurre alcuni comportamenti indesiderati, ma non garantiscono l'assenza di errori, perché il sistema non sa sempre di non sapere. E non trasforma un compito inadatto in un compito adatto: se il compito richiede dati che il sistema non ha, o un'esattezza che non può garantire, nessuna formulazione risolverà il problema. Ci sono invece istruzioni che aiutano davvero a gestire questi limiti: chiedere di indicare quando un'informazione è incerta, di distinguere ciò che deriva dai documenti forniti da ciò che è ipotesi, di segnalare quando mancano dati per rispondere. Le vedremo nel 6.3 e nel 6.4. Ma resta il principio: la verifica della correttezza è una fase distinta, oggetto del Tema 7.");
    txt(s, "Un buon prompt non può", { x: 0.5, y: 1.15, w: 4.35, h: 0.35, fontSize: 15, bold: true, color: C.accent5 });
    rowList(s, ["Conferire capacità che il sistema non ha", "Eliminare errori e allucinazioni", "Rendere adatto un compito inadatto"], { x: 0.5, w: 4.35, y: 1.6, h: 0.65, fontSize: 13 });
    txt(s, "Istruzioni che aiutano a gestire i limiti", { x: 5.15, y: 1.15, w: 4.35, h: 0.35, fontSize: 15, bold: true, color: C.accent1 });
    ["Indica quando un'informazione è incerta", "Distingui ciò che viene dai documenti dalle ipotesi", "Segnala se mancano dati per rispondere"].forEach((t, i) => { const y = 1.6 + i * 0.73; shapeBox(s, 5.15, y, 4.35, 0.65, C.accent6, t); txt(s, "\"" + t + "\"", { x: 5.35, y, w: 4.0, h: 0.65, fontSize: 12, italic: true, color: C.text1, valign: "middle" }); });
    banner(s, 4.05, "La verifica della correttezza è una fase distinta.", { h: 0.9, fontSize: 15 });
  }
  keySlide("Il prompt comunica obiettivi e aspettative, ma non è un comando che assicura un risultato deterministico e corretto.", "Sottotema 6.1  ·  Fondamenti del prompting", "Concetto chiave. Il prompt è il modo in cui comunichiamo al sistema che cosa vogliamo: domande, istruzioni, richieste di esecuzione, spesso combinate. Chiarezza, specificità e pertinenza ne determinano l'efficacia; ambiguità e informazioni mancanti spingono il sistema verso ipotesi implicite. La qualità dell'input incide molto sull'utilità dell'output, ma solo in parte sulla correttezza. A differenza della programmazione, il prompting non garantisce esecuzioni esatte e ripetibili. Domanda di verifica: prendete una richiesta che avete fatto di recente all'AI. Supera il test del collega? Quali domande avrebbe fatto un collega competente?");

  // =====================================================================
  section("6.2 Elementi di una richiesta");
  divider("6.2", "Gli elementi di una richiesta efficace", "Un prompt efficace rende espliciti i requisiti rilevanti; non deve essere necessariamente lungo", "Dopo i fondamenti, vediamo il quadro completo degli elementi che possono comporre una richiesta efficace. È un sottotema da comprendere e applicare, complementare ai due successivi: qui presentiamo il quadro, nel 6.3 approfondiamo il contesto, nel 6.4 le tecniche. Partiremo però da un passo che precede la scrittura: la definizione del problema.");
  {
    const s = content("Prima il problema, poi il prompt", "Questa integrazione del sottotema propone di rovesciare l'ordine abituale: prima di scrivere la richiesta, occorre capire quale problema si vuole risolvere. Molti prompt deludenti non sono scritti male: sono la risposta giusta alla domanda sbagliata. Tre domande aiutano. Quale problema voglio risolvere? Per esempio, non 'scrivere una presentazione', ma 'convincere la direzione ad approvare un investimento'. A quale scopo serve il risultato? Che cosa ne farò, chi lo userà, quale decisione o azione deve rendere possibile? Con quali criteri di successo? Come capirò che il risultato è buono: che cosa deve contenere, a quali requisiti deve rispondere, che cosa lo renderebbe inutilizzabile? Le risposte a queste domande sono già metà del prompt, e forniscono anche il criterio per valutare il risultato. Quando non si riesce a rispondere, è un segnale che il problema non è ancora chiaro; in questo caso, come abbiamo visto nel Tema 5, il dialogo con l'AI può aiutare a chiarirlo, chiedendo al sistema di porci domande prima di procedere.");
    const q = [["1", "Quale problema voglio risolvere?", "Non \"scrivere una presentazione\", ma \"ottenere l'approvazione di un investimento\""], ["2", "A quale scopo serve il risultato?", "Chi lo userà, quale decisione o azione deve rendere possibile"], ["3", "Con quali criteri di successo?", "Che cosa deve contenere, che cosa lo renderebbe inutilizzabile"]];
    q.forEach((e, i) => {
      const y = 1.2 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.82, i % 2 ? C.background1 : C.background2, e[1]);
      txt(s, e[0], { x: 0.65, y, w: 0.5, h: 0.82, fontSize: 24, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 1.2, y, w: 3.5, h: 0.82, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[2], { x: 4.8, y, w: 4.55, h: 0.82, fontSize: 12, color: C.text2, valign: "middle" });
    });
    banner(s, 4.15, "Molti prompt deludenti sono la risposta giusta alla domanda sbagliata. Le risposte alle tre domande sono già metà del prompt.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Otto elementi possibili", "Ecco gli otto elementi che possono comporre una richiesta efficace, secondo il documento di perimetro. Il problema da affrontare e l'obiettivo, che abbiamo appena visto. Il compito: che cosa deve fare concretamente il sistema, per esempio scrivere, riassumere, confrontare, classificare. Il contesto e il destinatario: la situazione, le informazioni di riferimento, chi leggerà o userà il risultato. I vincoli e i requisiti: lunghezza, scadenze, cose da includere o evitare, regole da rispettare. Il formato e il livello di dettaglio: come deve essere strutturato il risultato. I criteri di un risultato soddisfacente: che cosa lo rende buono. I ruoli e le prospettive: da quale punto di vista affrontare il compito. Una precisione importante, espressa nel concetto chiave: non tutti gli elementi servono sempre. Un prompt efficace rende espliciti i requisiti rilevanti per quel compito, e può essere lungo una riga o una pagina. Questi otto elementi sono una lista di controllo, non un modulo da compilare ogni volta.");
    const e = [["FiHelpCircle", "Problema"], ["FiTarget", "Obiettivo"], ["FiPlay", "Compito"], ["FiUsers", "Contesto e destinatario"], ["FiSliders", "Vincoli e requisiti"], ["FiLayout", "Formato e dettaglio"], ["FiCheckSquare", "Criteri di successo"], ["FiUser", "Ruolo e prospettiva"]];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.2 + row * 1.5;
      shapeBox(s, x, y, 2.15, 1.32, row === 0 && col < 2 ? C.accent6 : C.background2, e[i][1]);
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, e[i][0]);
      txt(s, e[i][1], { x: x + 0.18, y: y + 0.75, w: 1.85, h: 0.5, fontSize: 13, bold: true, color: C.text1 });
    }
    banner(s, 4.3, "Una lista di controllo, non un modulo da compilare ogni volta: si esplicita ciò che è rilevante.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Anatomia di una richiesta", "Ecco un esempio di richiesta che contiene molti degli elementi, scomposta per renderli visibili. Il compito: preparare una sintesi del report trimestrale sui reclami. L'obiettivo e lo scopo: la sintesi servirà alla riunione di direzione per decidere su quali problemi intervenire per primi. Il destinatario: dirigenti che non conoscono i dettagli operativi. I vincoli: massimo una pagina, solo informazioni presenti nel report. Il formato: tre problemi principali, ciascuno con dimensione, tendenza e possibile causa, poi una raccomandazione. Il criterio di successo: un dirigente deve poter capire in due minuti quali sono le priorità. Si noti come ogni elemento cambia il risultato: senza il destinatario, la sintesi potrebbe essere troppo tecnica; senza lo scopo, potrebbe essere descrittiva invece che orientata alla decisione; senza il vincolo sulle fonti, potrebbe includere considerazioni generiche non presenti nel report. Il report, naturalmente, va condiviso solo con strumenti autorizzati a trattarlo.");
    const parts = [["Compito", "Prepara una sintesi del report trimestrale sui reclami allegato."], ["Scopo", "Servirà alla riunione di direzione per decidere su quali problemi intervenire per primi."], ["Destinatario", "Dirigenti che non conoscono i dettagli operativi."], ["Vincoli", "Massimo una pagina. Usa solo informazioni presenti nel report."], ["Formato", "I tre problemi principali, ciascuno con dimensione, tendenza e possibile causa; poi una raccomandazione."], ["Criterio", "Un dirigente deve capire le priorità in due minuti."]];
    parts.forEach((p, i) => {
      const y = 1.15 + i * 0.6;
      shapeBox(s, 0.5, y, 1.7, 0.52, i % 2 ? C.accent6 : C.accent1, p[0]);
      txt(s, p[0], { x: 0.55, y, w: 1.6, h: 0.52, fontSize: 12, bold: true, color: i % 2 ? C.text1 : C.background1, align: "center", valign: "middle" });
      shapeBox(s, 2.3, y, 7.2, 0.52, C.background2, "testo " + p[0]);
      txt(s, p[1], { x: 2.45, y, w: 6.95, h: 0.52, fontSize: 12, color: C.text1, fontFace: "Courier New", valign: "middle" });
    });
    txt(s, "Ogni elemento cambia il risultato: senza destinatario troppo tecnico, senza scopo solo descrittivo, senza vincolo sulle fonti generico.", { x: 0.5, y: 4.8, w: 9, h: 0.35, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Vincoli, formato e criteri di qualità", "Tre elementi meritano un approfondimento, perché sono spesso trascurati. I vincoli e i requisiti: indicano i limiti entro cui muoversi. Possono riguardare la lunghezza, come 'massimo 150 parole'; le fonti, come 'usa solo le informazioni del documento'; i contenuti, come 'non includere prezzi', 'cita sempre la clausola di riferimento'; le regole, come 'rispetta la terminologia del nostro glossario'. Il formato e il livello di dettaglio: senza indicazioni, il sistema sceglie un formato medio; specificarlo fa risparmiare molto lavoro di adattamento. Lo approfondiremo nel 6.6. I criteri di un risultato soddisfacente: dire al sistema che cosa rende buono il risultato orienta il suo lavoro, e ci dà un riferimento per valutarlo. Per esempio: 'il testo deve poter essere letto ad alta voce in un minuto', 'ogni affermazione deve essere collegata a un punto del documento', 'la proposta deve essere realizzabile con le risorse indicate'. Un consiglio: quando i vincoli sono molti, elencarli in modo ordinato aiuta sia il sistema sia chi rilegge la richiesta.");
    const c = [["FiSliders", "Vincoli e requisiti", ["\"Massimo 150 parole\"", "\"Usa solo le informazioni del documento\"", "\"Cita sempre la clausola di riferimento\""]], ["FiLayout", "Formato e dettaglio", ["\"Tabella con tre colonne\"", "\"Cinque punti, una riga ciascuno\"", "Approfondimento nel 6.6"]], ["FiCheckSquare", "Criteri di qualità", ["\"Leggibile ad alta voce in un minuto\"", "\"Ogni affermazione collegata al documento\"", "\"Realizzabile con le risorse indicate\""]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.0, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2, body: bullets(c[i][2], { space: 5 }) });
    banner(s, 4.35, "Quando i vincoli sono molti, elencarli in modo ordinato aiuta il sistema e chi rilegge.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Ruoli e prospettive", "L'ultimo elemento sono i ruoli e le prospettive. Abbiamo visto nel Tema 5 che assegnare un ruolo orienta il comportamento del sistema ma non gli conferisce competenze. Qui guardiamo l'aspetto operativo: come usare ruoli e prospettive in modo utile. Assegnare un ruolo, come 'agisci come un revisore attento alla chiarezza', 'rispondi come un formatore che spiega a principianti', orienta tono, lessico, livello di dettaglio e aspetti considerati. Ancora più utile è spesso indicare la prospettiva da cui guardare il compito: 'valuta questa proposta dal punto di vista di un cliente attento ai costi', 'rileggi il testo come lo leggerebbe un nuovo assunto'. Le prospettive aiutano a far emergere aspetti che altrimenti resterebbero in ombra, e si possono combinare chiedendo più punti di vista sullo stesso contenuto. Due cautele già note: il ruolo non crea competenze, quindi il risultato va valutato come qualsiasi altro; e il ruolo non sostituisce le altre informazioni: 'sei un esperto di marketing' senza obiettivo, destinatario e contesto produce comunque un risultato generico.");
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiUser", head: "Ruolo", headSize: 16, bodySize: 12,
      body: [{ text: "Orienta tono, lessico, dettaglio", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["\"Agisci come un revisore attento alla chiarezza\"", "\"Rispondi come un formatore per principianti\""], { space: 4 })) });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiEye", head: "Prospettiva", headSize: 16, bodySize: 12, fill: C.accent6,
      body: [{ text: "Fa emergere aspetti in ombra", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["\"Valutala come un cliente attento ai costi\"", "\"Rileggilo come un nuovo assunto\""], { space: 4 })) });
    await card(s, 0.5, 3.95, 4.35, 1.0, { head: "Il ruolo non crea competenze", headSize: 13 });
    await card(s, 5.15, 3.95, 4.35, 1.0, { head: "Il ruolo non sostituisce obiettivo e contesto", headSize: 13 });
  }
  {
    const s = content("Non serve sempre un prompt lungo", "Il concetto chiave del sottotema contiene una precisazione importante: un prompt efficace non deve necessariamente essere lungo o contenere tutti gli elementi. La complessità della richiesta deve essere proporzionata al compito. Per compiti semplici e con un risultato evidente, una richiesta breve è perfettamente adeguata: 'Traduci in inglese questo paragrafo mantenendo il tono formale'. Aggiungere ruolo, criteri, formato sarebbe inutile. Per compiti complessi, con molte variabili, un destinatario specifico, requisiti precisi, conviene invece una richiesta strutturata, come quella vista nell'anatomia. Tra i due estremi c'è tutta la gamma intermedia. Due errori opposti da evitare. Il primo è la richiesta troppo povera per un compito complesso: produce risultati generici e molte iterazioni. Il secondo è la richiesta sovraccarica: istruzioni ridondanti, vincoli in conflitto, informazioni non pertinenti, che possono confondere il sistema e rendere il prompt difficile da mantenere. La domanda da porsi è: quali informazioni cambierebbero il risultato in modo significativo? Quelle vanno incluse; le altre no.");
    promptBox(s, 0.5, 1.2, 4.35, 1.35, "Traduci in inglese questo paragrafo mantenendo il tono formale.", { label: "Compito semplice: richiesta breve", fontSize: 12 });
    promptBox(s, 5.15, 1.2, 4.35, 1.35, "Compito, scopo, destinatario, vincoli, formato, criterio di successo (come nell'anatomia).", { label: "Compito complesso: richiesta strutturata", fill: C.accent6, fontSize: 12 });
    await card(s, 0.5, 2.7, 4.35, 1.4, { inline: true, icon: "FiMinusCircle", head: "Troppo povera", bodySize: 12, body: "Per un compito complesso: risultati generici, molte iterazioni." });
    await card(s, 5.15, 2.7, 4.35, 1.4, { inline: true, icon: "FiPlusCircle", head: "Sovraccarica", bodySize: 12, body: "Istruzioni ridondanti o in conflitto, informazioni non pertinenti." });
    banner(s, 4.25, "Quali informazioni cambierebbero il risultato in modo significativo? Quelle vanno incluse; le altre no.", { h: 0.75, fontSize: 13 });
  }
  keySlide("Un prompt efficace rende espliciti i requisiti rilevanti; non deve necessariamente essere lungo o contenere tutti gli elementi in ogni situazione.", "Sottotema 6.2  ·  Gli elementi di una richiesta efficace", "Concetto chiave. Prima di scrivere, definire il problema, lo scopo e i criteri di successo. Poi scegliere, tra gli otto elementi possibili, quelli rilevanti per il compito: problema, obiettivo, compito, contesto e destinatario, vincoli, formato, criteri, ruolo e prospettiva. La lunghezza e la struttura della richiesta sono proporzionate alla complessità del compito. Esercizio suggerito: chiedere ai partecipanti di riscrivere una propria richiesta recente usando la lista degli otto elementi come controllo, e di notare quali elementi mancavano e quali erano superflui.");

  // =====================================================================
  section("6.3 Il contesto");
  divider("6.3", "Il ruolo del contesto nel prompting", "Più informazioni non producono automaticamente risultati migliori: serve un contesto pertinente, completo e comprensibile", "Il contesto è l'elemento che più spesso fa la differenza tra un risultato generico e uno utile. In questo sottotema, da comprendere e applicare, vediamo quali informazioni di contesto fornire, come organizzarle, come valutarne la qualità, come gestire le informazioni mancanti e contraddittorie e come tenere conto dei limiti della finestra di contesto, senza ripetere la spiegazione tecnica del Tema 2. Un'avvertenza da ripetere: i documenti aziendali vanno condivisi solo con strumenti autorizzati a trattarli.");
  {
    const s = content("Che cosa è contesto", "Possiamo distinguere tre tipi di contesto. Le informazioni preliminari e le conoscenze di riferimento: ciò che il sistema deve sapere per svolgere il compito, come la situazione di partenza, i fatti rilevanti, le definizioni usate in azienda, le decisioni già prese. Il contesto aziendale e professionale: le caratteristiche dell'organizzazione, del settore, del pubblico, le prassi, il tono abituale della comunicazione, i vincoli normativi o interni. I documenti e i materiali pertinenti: testi, dati, esempi di lavori precedenti, linee guida, modelli da seguire, che il sistema può usare come base o riferimento. Il sistema, come abbiamo visto, conosce solo ciò che gli viene fornito, oltre alla sua conoscenza generale. Tutto ciò che è specifico della nostra situazione, e che cambierebbe il risultato, deve essere nel contesto. Un esempio: chiedere 'proponi un piano di formazione sull'AI' produce un piano generico; aggiungere che l'azienda ha 80 dipendenti, che metà lavora in produzione con poca familiarità con il digitale, che il budget consente quattro mezze giornate e che esistono già delle regole interne sull'uso dell'AI, produce un piano su misura.");
    const t = [["FiInfo", "Informazioni preliminari", "Situazione di partenza, fatti, definizioni, decisioni già prese"], ["FiBriefcase", "Contesto aziendale e professionale", "Organizzazione, settore, pubblico, prassi, tono, vincoli"], ["FiFolder", "Documenti e materiali", "Testi, dati, esempi precedenti, linee guida, modelli"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 1.85, { inline: true, icon: t[i][0], head: t[i][1], headSize: 13, bodySize: 12, body: t[i][2] });
    promptBox(s, 0.5, 3.25, 9.0, 1.7, "Proponi un piano di formazione sull'AI per la nostra azienda: 80 dipendenti, metà in produzione con poca familiarità con il digitale. Budget: quattro mezze giornate. Esistono già regole interne sull'uso dell'AI, da integrare nel percorso.", { label: "Esempio: il contesto rende il piano su misura", fill: C.accent6, fontSize: 12 });
  }
  {
    const s = content("Distinguere informazioni, istruzioni, esempi", "Quando una richiesta contiene molto materiale, è importante che il sistema capisca il ruolo di ciascuna parte. Le informazioni sono il materiale su cui lavorare: un documento, dei dati, una descrizione della situazione. Le istruzioni dicono che cosa fare con quelle informazioni. Gli esempi mostrano come dovrebbe essere il risultato. Se i tre tipi si mescolano, il sistema può confonderli: per esempio, trattare una frase di un documento come un'istruzione, o copiare un esempio invece di usarlo come modello. Pensiamo a un documento allegato che contiene la frase 'rispondere entro cinque giorni': è un contenuto da analizzare, non un'istruzione per il sistema. Un modo semplice per evitare confusioni è separare chiaramente le parti, con titoli o delimitatori, e dire esplicitamente il ruolo di ciascuna: 'Di seguito trovi il testo da analizzare', 'Questo è un esempio del formato che desidero, non del contenuto'. La tecnica della delimitazione sarà ripresa nel 6.4.");
    const p = [["Informazioni", "Il materiale su cui lavorare", "\"Di seguito trovi il testo da analizzare.\"", C.background2], ["Istruzioni", "Che cosa fare con le informazioni", "\"Estrai le scadenze e chi ne è responsabile.\"", C.accent6], ["Esempi", "Come dovrebbe essere il risultato", "\"Questo è un esempio del formato, non del contenuto.\"", C.background2]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.45, p[i][3], p[i][0]);
      txt(s, p[i][0], { x: x + 0.2, y: 1.32, w: 2.46, h: 0.4, fontSize: 17, bold: true, color: C.accent1 });
      txt(s, p[i][1], { x: x + 0.2, y: 1.75, w: 2.46, h: 0.6, fontSize: 13, bold: true, color: C.text1 });
      txt(s, p[i][2], { x: x + 0.2, y: 2.45, w: 2.46, h: 1.1, fontSize: 12, italic: true, color: C.text2, fontFace: "Courier New" });
    }
    banner(s, 3.85, "Se si mescolano, il sistema può trattare un contenuto come un'istruzione o copiare un esempio.", { h: 0.55, fontSize: 13 });
    txt(s, "Separare le parti con titoli o delimitatori e dichiararne il ruolo.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Qualità del contesto: pertinente, completo, comprensibile", "Il concetto chiave del sottotema contraddice un'idea molto diffusa: che più informazioni producano sempre risultati migliori. Non è così. Il contesto deve avere tre qualità. Pertinenza: contiene ciò che serve per quel compito. Informazioni non pertinenti possono distrarre il sistema, che tende a usarle anche quando non dovrebbe: se alleghiamo dieci documenti per una domanda che ne riguarda uno, la risposta può mescolare elementi di tutti. Completezza sufficiente: contiene tutto ciò che cambierebbe il risultato; non serve tutto ciò che sappiamo, ma ciò che serve. Comprensibilità: è organizzato in modo che il sistema, come una persona, possa capirlo: documenti leggibili, informazioni ordinate, abbreviazioni e sigle interne spiegate, dati in un formato chiaro. Un documento scansionato male, una tabella esportata in modo disordinato o un elenco di appunti incomprensibili riducono la qualità del risultato. Ricordiamo anche quanto visto nel Tema 2: nei contesti molto lunghi, alcune informazioni possono essere trascurate. Un contesto essenziale e ben organizzato è spesso più efficace di uno abbondante.");
    const q = [["FiFilter", "Pertinente", "Ciò che serve per quel compito. Le informazioni superflue distraggono."], ["FiCheckSquare", "Sufficientemente completo", "Tutto ciò che cambierebbe il risultato, non tutto ciò che sappiamo."], ["FiEye", "Comprensibile", "Leggibile e ordinato, sigle spiegate, dati in formato chiaro."]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.5, { icon: q[i][0], head: q[i][1], headSize: 15, bodySize: 13, fill: i === 0 ? C.accent6 : C.background2, body: q[i][2] });
    banner(s, 3.9, "Più informazioni non significano risultati migliori: un contesto essenziale e ben organizzato è spesso più efficace.", { h: 0.75, fontSize: 13 });
    txt(s, "Esempio: dieci documenti allegati per una domanda che ne riguarda uno producono risposte che li mescolano.", { x: 0.5, y: 4.75, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Chiedere all'AI di esplicitare le informazioni mancanti", "Questa integrazione, che compare sia nel 6.3 sia nel 6.4, affronta un problema concreto: spesso non sappiamo di aver omesso informazioni importanti. Il sistema, invece di segnalarcelo, di solito procede facendo ipotesi implicite. Possiamo cambiare questo comportamento con istruzioni esplicite. La prima: chiedere domande di chiarimento prima di procedere, se mancano informazioni necessarie. Ne abbiamo visto il valore nel Tema 5; qui lo trasformiamo in un'istruzione. La seconda: chiedere di distinguere i dati disponibili dalle ipotesi, cioè di indicare quali parti del risultato si basano sulle informazioni fornite e quali su supposizioni. La terza: chiedere di dichiarare le ipotesi fatte, in modo da poterle verificare o correggere. L'esempio in slide mostra un'istruzione che si può aggiungere a molte richieste. Il beneficio è duplice: le lacune emergono prima, invece di nascondersi in un risultato apparentemente completo, e le ipotesi diventano visibili e quindi controllabili. Il sistema non sempre riconosce tutte le lacune, ma questa istruzione migliora molto la trasparenza.");
    promptBox(s, 0.5, 1.2, 5.3, 2.4, "Prima di procedere, se mancano informazioni necessarie per svolgere bene il compito, fammi al massimo tre domande.\n\nNel risultato, distingui chiaramente ciò che deriva dai documenti forniti da ciò che è una tua ipotesi.", { label: "Istruzione aggiuntiva", fill: C.accent6, fontSize: 12 });
    const b = [["FiHelpCircle", "Domande prima di procedere"], ["FiColumns", "Dati distinti dalle ipotesi"], ["FiEye", "Ipotesi dichiarate e controllabili"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.25 + i * 0.8;
      await iconCircle(s, 6.1, y, 0.52, b[i][0]);
      txt(s, b[i][1], { x: 6.75, y, w: 2.75, h: 0.52, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
    }
    banner(s, 3.85, "Le lacune emergono prima, invece di nascondersi in un risultato apparentemente completo.", { h: 0.6, fontSize: 13 });
    txt(s, "Il sistema non riconosce sempre tutte le lacune, ma la trasparenza migliora molto.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Informazioni contraddittorie", "Capita spesso che il contesto contenga informazioni in contraddizione tra loro: due versioni di una procedura, documenti con dati diversi, una richiesta che dice una cosa e un allegato che ne dice un'altra, istruzioni che si contraddicono. Il sistema, di solito, non segnala il conflitto: sceglie una delle versioni, o le mescola, e il risultato può essere incoerente senza che ce ne accorgiamo. Come gestire questa situazione? Prima di tutto, prevenire: fornire le versioni aggiornate dei documenti, eliminare il materiale superato, rileggere le istruzioni per individuare conflitti. Poi, indicare una regola di priorità: per esempio 'se il documento e le mie indicazioni sono in conflitto, segui le mie indicazioni', oppure 'prevale la versione più recente'. Infine, chiedere di segnalare: 'se trovi informazioni contraddittorie tra i documenti, segnalalo e non scegliere al posto mio'. Quest'ultima istruzione è particolarmente utile quando si lavora con documenti di cui non si conosce bene il contenuto, perché trasforma una contraddizione nascosta in un'informazione utile.");
    const st = [["FiShield", "Prevenire", "Versioni aggiornate, materiale superato eliminato, istruzioni rilette"], ["FiList", "Indicare una priorità", "\"Se il documento e le mie indicazioni sono in conflitto, segui le mie indicazioni.\""], ["FiAlertTriangle", "Chiedere di segnalare", "\"Se trovi informazioni contraddittorie, segnalalo e non scegliere al posto mio.\""]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.75, { icon: st[i][0], head: st[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2, body: st[i][2] });
    banner(s, 4.1, "Di solito il sistema non segnala il conflitto: sceglie o mescola, e il risultato può essere incoerente.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Gestire i limiti della finestra di contesto", "Nel Tema 2 abbiamo visto che cos'è la finestra di contesto e perché è limitata. Qui ci interessano le conseguenze pratiche nel prompting. Primo: con documenti molto lunghi o molti allegati, il sistema può non considerare tutto con la stessa attenzione, e alcune parti possono essere trascurate. Conviene quindi indicare su quali parti concentrarsi, oppure fornire solo le sezioni pertinenti. Secondo: in una conversazione lunga, le istruzioni date all'inizio possono perdere peso. Se sono importanti, conviene ripeterle o riassumerle quando si passa a un nuovo compito. Terzo: per lavori su molti documenti o molto materiale, è spesso più efficace procedere per parti, per esempio riassumendo un documento alla volta e poi chiedendo una sintesi complessiva, piuttosto che caricare tutto in una sola richiesta. Quarto: quando la conversazione diventa troppo lunga o confusa, aprire una nuova conversazione con un riepilogo essenziale di ciò che serve. Le soglie esatte dipendono dallo strumento, e molte applicazioni gestiscono automaticamente parte di questi limiti, ma i principi restano validi.");
    const p = [["FiTarget", "Indicare su che cosa concentrarsi", "o fornire solo le sezioni pertinenti"], ["FiClipboard", "Ripetere le istruzioni importanti", "quando si passa a un nuovo compito"], ["FiLayers", "Procedere per parti", "un documento alla volta, poi la sintesi"], ["FiRefreshCw", "Ricominciare con un riepilogo", "quando la conversazione è troppo lunga"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.9, headSize: 14, bodySize: 12 });
    txt(s, "Le soglie dipendono dallo strumento; i principi restano validi.", { x: 0.5, y: 4.4, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Fornire più informazioni non produce automaticamente risultati migliori; è preferibile un contesto pertinente, sufficientemente completo e comprensibile.", "Sottotema 6.3  ·  Il ruolo del contesto nel prompting", "Concetto chiave. Il contesto comprende informazioni preliminari, contesto aziendale e documenti. Va organizzato distinguendo informazioni, istruzioni ed esempi; deve essere pertinente, sufficientemente completo e comprensibile. Si può chiedere al sistema di segnalare le informazioni mancanti, distinguere dati e ipotesi, segnalare le contraddizioni. E i limiti della finestra di contesto si gestiscono con selezione, ripetizione, lavoro per parti e nuovi avvii. Domanda di verifica: per un compito ricorrente del vostro lavoro, quali informazioni di contesto sono indispensabili e quali, invece, aggiungete per abitudine senza che servano?");

  // =====================================================================
  section("6.4 Tecniche fondamentali");
  divider("6.4", "Tecniche fondamentali di prompting", "La complessità della tecnica deve essere proporzionata al compito: non esiste una strategia unica migliore", "Passiamo alle tecniche, da conoscere e sperimentare. Sono strategie per guidare il sistema, complementari agli elementi del 6.2 e al contesto del 6.3. Vedremo zero-shot e few-shot, le istruzioni strutturate e la delimitazione dei contenuti, la scomposizione dei compiti, la richiesta di alternative e il confronto con criteri, la richiesta di chiarimenti, e infine come scegliere la tecnica in base al compito. Ricordiamo il criterio del modulo: non sono formule da applicare sempre, ma strumenti da scegliere.");
  {
    const s = content("Una cassetta degli attrezzi", "Ecco le principali tecniche, che vedremo una per una. Zero-shot: chiedere direttamente, senza esempi. Few-shot: fornire alcuni esempi del risultato atteso. Istruzioni strutturate: organizzare la richiesta in sezioni ordinate. Delimitazione dei contenuti: separare chiaramente istruzioni, informazioni ed esempi. Scomposizione dei compiti: dividere un compito complesso in passaggi. Richiesta di alternative: chiedere più versioni o soluzioni. Confronto tra opzioni con criteri definiti: valutare alternative secondo criteri espliciti. Richiesta di chiarimenti prima dell'esecuzione: far porre domande al sistema. Sono strumenti diversi, adatti a situazioni diverse, e si possono combinare. L'immagine della cassetta degli attrezzi è utile: non si usa il trapano per piantare un chiodo, e un buon artigiano sceglie lo strumento in base al lavoro. Allo stesso modo, la maggior parte delle richieste quotidiane non ha bisogno di tecniche elaborate; le tecniche servono quando il compito lo richiede.");
    const t = [["FiZap", "Zero-shot"], ["FiCopy", "Few-shot"], ["FiList", "Istruzioni strutturate"], ["FiColumns", "Delimitazione"], ["FiGitBranch", "Scomposizione"], ["FiShuffle", "Alternative"], ["FiSliders", "Confronto con criteri"], ["FiHelpCircle", "Chiarimenti prima"]];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.2 + row * 1.5;
      shapeBox(s, x, y, 2.15, 1.32, C.background2, t[i][1]);
      await iconCircle(s, x + 0.78, y + 0.15, 0.58, t[i][0]);
      txt(s, t[i][1], { x: x + 0.1, y: y + 0.82, w: 1.95, h: 0.42, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
    }
    banner(s, 4.3, "Si sceglie lo strumento in base al lavoro: la maggior parte delle richieste non richiede tecniche elaborate.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Zero-shot e few-shot", "Zero-shot significa chiedere al sistema di svolgere un compito senza fornire esempi, basandosi solo sulla descrizione. È il modo più comune e funziona bene per la grande maggioranza dei compiti, perché i modelli attuali sanno già svolgerne moltissimi. Few-shot significa fornire alcuni esempi, di solito da due a cinque, del risultato desiderato, prima di chiedere al sistema di svolgere il compito su un nuovo caso. Gli esempi comunicano in modo molto efficace ciò che è difficile descrivere a parole: uno stile, un formato preciso, un criterio di classificazione, un livello di dettaglio. L'esempio in slide mostra una classificazione di richieste dei clienti: con due esempi il sistema capisce le categorie e il formato della risposta. Alcune cautele. Gli esempi devono essere rappresentativi e coerenti, perché il sistema tende a imitarli anche negli aspetti non voluti: se tutti gli esempi sono brevi, tenderà a rispondere brevemente; se riguardano tutti un certo tipo di caso, potrebbe forzare i nuovi casi in quello schema. E conviene variare gli esempi, per evitare che il sistema copi un dettaglio invece di cogliere il criterio.");
    promptBox(s, 0.5, 1.2, 3.6, 1.6, "Classifica questa richiesta del cliente come: Informazione, Reclamo o Ordine.", { label: "Zero-shot: senza esempi", fontSize: 11 });
    promptBox(s, 4.3, 1.2, 5.2, 2.75, "Classifica le richieste come negli esempi.\n\nRichiesta: \"Quando arriva il mio pacco?\"\nCategoria: Informazione\n\nRichiesta: \"Il prodotto è arrivato rotto.\"\nCategoria: Reclamo\n\nRichiesta: \"[nuova richiesta]\"\nCategoria:", { label: "Few-shot: con esempi", fill: C.accent6, fontSize: 11 });
    txt(s, "Gli esempi comunicano ciò che è difficile descrivere: stile, formato, criteri.", { x: 0.5, y: 3.0, w: 3.6, h: 0.9, fontSize: 12, italic: true, color: C.text2 });
    banner(s, 4.15, "Esempi rappresentativi e vari: il sistema li imita anche negli aspetti non voluti.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Istruzioni strutturate e delimitazione", "Quando una richiesta contiene molti elementi, organizzarla in sezioni ordinate la rende più chiara sia per il sistema sia per chi la scrive e la rilegge. Le istruzioni strutturate dividono la richiesta in parti con un titolo: per esempio obiettivo, contesto, compito, vincoli, formato. La delimitazione separa chiaramente i contenuti da elaborare dalle istruzioni, usando segni riconoscibili come linee, virgolette, titoli, o etichette di apertura e chiusura. Questo evita che il sistema confonda il testo da analizzare con le istruzioni, come abbiamo visto nel 6.3, e permette di riferirsi ai contenuti in modo preciso: 'nel testo tra le linee', 'nel documento A'. L'esempio in slide mostra una richiesta strutturata con un testo delimitato. Non serve una sintassi particolare: qualunque modo chiaro e coerente funziona. Le guide di diversi fornitori suggeriscono convenzioni specifiche, come titoli in stile Markdown o etichette tra parentesi angolari, ma il principio è lo stesso: ordine e confini chiari. Questa tecnica è particolarmente utile per i prompt da riutilizzare, che vedremo nel 6.8.");
    promptBox(s, 0.5, 1.2, 5.6, 3.75, "OBIETTIVO\nPreparare la risposta a un cliente.\n\nCONTESTO\nCliente storico; primo reclamo.\n\nCOMPITO\nScrivi una risposta al messaggio tra le linee.\n\nVINCOLI\nTono cortese; massimo 10 righe; nessun impegno su rimborsi.\n\n-----\n[messaggio del cliente]\n-----", { label: "Richiesta strutturata con testo delimitato", fill: C.accent6, fontSize: 11 });
    await card(s, 6.35, 1.2, 3.15, 1.75, { inline: true, icon: "FiList", head: "Struttura", bodySize: 12, body: "Sezioni con titolo: chiaro per il sistema e per chi rilegge." });
    await card(s, 6.35, 3.1, 3.15, 1.85, { inline: true, icon: "FiColumns", head: "Delimitazione", bodySize: 12, body: "Confini chiari tra istruzioni e contenuti. Qualunque convenzione coerente funziona." });
  }
  {
    const s = content("Scomporre i compiti complessi", "Un compito complesso affidato in una sola richiesta produce spesso risultati superficiali o incompleti: il sistema deve gestire troppe cose insieme e tende a trattarle tutte in modo sommario. La scomposizione divide il compito in passaggi, da svolgere in sequenza, controllando il risultato di ciascuno prima di passare al successivo. Prendiamo la preparazione di una proposta di miglioramento di un processo. Invece di chiedere 'scrivi una proposta per migliorare il processo di gestione degli ordini', si può procedere così: primo, descrivere il processo attuale a partire dalle informazioni fornite; secondo, individuare i principali problemi; terzo, per ciascun problema, proporre possibili interventi; quarto, valutare gli interventi secondo costo, impatto e tempi; quinto, redigere la proposta. Vantaggi: ogni passaggio è più semplice e quindi più accurato; si possono correggere gli errori prima che si propaghino; la persona mantiene il controllo del percorso. Si può anche chiedere al sistema stesso di proporre una scomposizione del compito, da rivedere prima di procedere. La scomposizione è anche il principio su cui si basano molti flussi di lavoro con AI e agenti, che saranno trattati nel Tema 11.");
    const st = ["Descrivere il processo attuale", "Individuare i problemi principali", "Proporre interventi per ciascuno", "Valutarli per costo, impatto, tempi", "Redigere la proposta"];
    st.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.25, 1.68, 1.75, i === 4 ? C.accent1 : C.background2, t);
      txt(s, String(i + 1), { x: x + 0.12, y: 1.32, w: 0.5, h: 0.45, fontSize: 20, bold: true, color: i === 4 ? C.background1 : C.accent1 });
      txt(s, t, { x: x + 0.12, y: 1.8, w: 1.45, h: 1.1, fontSize: 12, bold: true, color: i === 4 ? C.background1 : C.text1 });
      if (i < 4) arrow(s, x + 1.69, 1.98, 0.15);
    });
    txt(s, "Invece di: \"Scrivi una proposta per migliorare il processo di gestione degli ordini\"", { x: 0.5, y: 3.1, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
    const v = [["FiTarget", "Passaggi più semplici, più accurati"], ["FiShield", "Errori corretti prima che si propaghino"], ["FiUserCheck", "La persona controlla il percorso"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 3.6, 2.86, 1.35, { inline: true, icon: v[i][0], head: v[i][1], headSize: 13 });
  }
  {
    const s = content("Alternative e confronto con criteri", "Due tecniche strettamente collegate. La richiesta di alternative: invece di una sola risposta, chiedere più versioni o soluzioni diverse. 'Proponi tre possibili titoli', 'suggerisci tre approcci diversi a questo problema', 'scrivi due versioni dell'introduzione, una più formale e una più diretta'. Le alternative ampliano le possibilità, evitano di fermarsi alla prima idea, e permettono di scegliere o combinare. È utile chiedere esplicitamente che siano davvero diverse tra loro, altrimenti il sistema tende a proporre variazioni minime. Il confronto tra opzioni con criteri definiti: valutare le alternative secondo criteri espliciti, scelti da noi. 'Confronta queste tre soluzioni secondo costo, tempi di realizzazione e impatto sui clienti, in una tabella, evidenziando i compromessi'. Definire noi i criteri è fondamentale: se li lasciamo scegliere al sistema, rischiamo un confronto basato su criteri generici o non pertinenti, e, come visto nel Tema 3, un'oggettività solo apparente. Il confronto aiuta a ragionare, ma la scelta resta della persona, che conosce pesi e priorità reali.");
    promptBox(s, 0.5, 1.2, 4.35, 2.2, "Proponi tre approcci davvero diversi per ridurre i tempi di risposta alle richieste dei clienti. Per ciascuno: idea, vantaggi, rischi.", { label: "Richiesta di alternative", fontSize: 12 });
    promptBox(s, 5.15, 1.2, 4.35, 2.2, "Confronta i tre approcci secondo: costo, tempi di realizzazione, impatto sui clienti. Usa una tabella ed evidenzia i compromessi.", { label: "Confronto con criteri definiti", fill: C.accent6, fontSize: 12 });
    await card(s, 0.5, 3.6, 4.35, 1.35, { inline: true, icon: "FiShuffle", head: "Chiedere che siano davvero diverse", bodySize: 12, body: "Altrimenti si ottengono variazioni minime." });
    await card(s, 5.15, 3.6, 4.35, 1.35, { inline: true, icon: "FiUserCheck", head: "I criteri li sceglie la persona", bodySize: 12, body: "Il confronto aiuta a ragionare; la scelta resta umana." });
  }
  {
    const s = content("Chiedere chiarimenti prima dell'esecuzione", "Riprendiamo la richiesta di chiarimenti, questa volta come tecnica. Nel 6.3 l'abbiamo vista come modo di gestire le lacune del contesto; qui la consideriamo come una strategia di interazione. Invece di chiedere direttamente il risultato, si chiede al sistema di porre domande mirate quando l'input non consente di procedere in modo affidabile, e di procedere solo dopo aver ricevuto le risposte. È particolarmente utile in tre situazioni: quando il compito è complesso e non siamo sicuri di aver fornito tutte le informazioni; quando il risultato ha conseguenze importanti e non vogliamo supposizioni implicite; quando stiamo ancora definendo che cosa ci serve. Due accorgimenti la rendono più efficace. Limitare il numero di domande, per esempio 'al massimo tre domande, le più importanti', per evitare questionari lunghi. E chiedere di procedere comunque se le informazioni sono sufficienti, per non rallentare i compiti semplici. Il risultato è un dialogo breve e mirato prima dell'esecuzione, che sostituisce le supposizioni con informazioni reali.");
    promptBox(s, 0.5, 1.2, 5.6, 1.9, "Devo organizzare una giornata di formazione per il team commerciale. Prima di proporre un programma, fammi al massimo tre domande, le più importanti. Se le informazioni ti sembrano sufficienti, procedi direttamente.", { label: "Esempio", fill: C.accent6, fontSize: 12 });
    txt(s, "Utile quando", { x: 6.35, y: 1.2, w: 3.15, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["Il compito è complesso", "Le conseguenze sono importanti", "Si sta ancora definendo il bisogno"], { x: 6.35, w: 3.15, y: 1.6, h: 0.45, fontSize: 12 });
    await card(s, 0.5, 3.3, 4.35, 1.65, { inline: true, icon: "FiHash", head: "Limitare il numero di domande", bodySize: 12, body: "\"Al massimo tre, le più importanti\"" });
    await card(s, 5.15, 3.3, 4.35, 1.65, { inline: true, icon: "FiFastForward", head: "Procedere se basta", bodySize: 12, body: "Per non rallentare i compiti semplici" });
  }
  {
    const s = content("Scegliere la tecnica in base al compito", "Il concetto chiave del sottotema invita a scegliere la tecnica in modo proporzionato. La tabella offre un orientamento indicativo. Per compiti semplici e ben definiti, come tradurre, riformulare o rispondere a una domanda, basta lo zero-shot, con una richiesta chiara. Quando serve uno stile o un formato preciso, difficile da descrivere, il few-shot è la scelta naturale. Quando la richiesta ha molti elementi o sarà riutilizzata, conviene usare istruzioni strutturate e delimitazione. Per compiti complessi con più fasi, la scomposizione. Per compiti creativi o decisioni con più opzioni, alternative e confronto con criteri. Quando le informazioni potrebbero essere incomplete o il compito è importante, la richiesta di chiarimenti. Le tecniche si combinano liberamente: una richiesta strutturata può contenere esempi e chiedere chiarimenti. Ma ogni tecnica aggiunge complessità e tempo, e usarle tutte sempre non migliora i risultati. La regola: iniziare con la richiesta più semplice che può funzionare, e aggiungere tecniche quando il risultato mostra che servono, come vedremo nel 6.5. Una nota di attualità: molti modelli recenti ragionano prima di rispondere, in modo esplicito o nascosto. Con questi modelli le guide dei fornitori suggeriscono di partire senza esempi e di non chiedere di 'ragionare passo passo', perché lo fanno già e l'istruzione può perfino peggiorare il risultato; contano di più obiettivo, contesto e criteri chiari. La scomposizione resta utile, ma per una ragione diversa: serve alla persona per controllare ogni passaggio, non al modello per ragionare. Indicazione verificata a ottobre 2026 su fonti secondarie: da confermare sulle guide ufficiali.");
    table(s, [["Situazione", "Tecnica indicata"], ["Compito semplice e ben definito", "Zero-shot con richiesta chiara"], ["Stile o formato difficile da descrivere", "Few-shot con esempi"], ["Molti elementi o richiesta da riutilizzare", "Istruzioni strutturate e delimitazione"], ["Compito complesso con più fasi", "Scomposizione"], ["Compito creativo o decisione con opzioni", "Alternative e confronto con criteri"], ["Informazioni forse incomplete, compito importante", "Chiarimenti prima dell'esecuzione"]], { colW: [4.6, 4.4], rowH: 0.45, accentCol: 1, blankCorner: false });
    banner(s, 4.55, "Iniziare con la richiesta più semplice che può funzionare; aggiungere tecniche quando servono.", { h: 0.42, fontSize: 13 });
  }
  keySlide("La complessità della tecnica deve essere proporzionata al compito; non esiste una strategia unica migliore in ogni situazione.", "Sottotema 6.4  ·  Tecniche fondamentali di prompting", "Concetto chiave. Zero-shot, few-shot, istruzioni strutturate, delimitazione, scomposizione, alternative, confronto con criteri e chiarimenti preventivi sono strumenti diversi, da scegliere in base al compito e da combinare quando serve. Nessuno è sempre il migliore, e la richiesta più semplice che funziona è spesso la scelta giusta. Esercizio suggerito: dare ai partecipanti tre compiti diversi, per esempio una traduzione, una classificazione con categorie aziendali e la preparazione di un piano, e chiedere quale tecnica sceglierebbero per ciascuno e perché.");

  // =====================================================================
  section("6.5 Prompting iterativo");
  divider("6.5", "Prompting iterativo", "L'iterazione migliora l'aderenza al compito; la verifica della correttezza è una fase distinta", "Nel Tema 5 abbiamo visto il valore del dialogo come processo iterativo. Qui sviluppiamo il metodo operativo: come analizzare un risultato, come formulare feedback efficaci, come raffinare le istruzioni, quando modificare la richiesta e quando ricominciare. E chiariremo un limite importante: l'iterazione migliora l'aderenza alla richiesta, ma non garantisce la correttezza.");
  {
    const s = content("Il ciclo del miglioramento progressivo", "Il prompting iterativo segue un ciclo in quattro passaggi. Prima formulazione: una richiesta ragionevole, anche non perfetta, secondo i principi visti. Analisi delle carenze: confrontare il risultato con l'obiettivo e i criteri di successo, individuando con precisione che cosa non va. Feedback e richieste di correzione: comunicare al sistema che cosa cambiare, in modo specifico. Raffinamento: il sistema produce una nuova versione, che si analizza di nuovo. Il ciclo si ripete finché il risultato è adeguato allo scopo. Il passaggio più importante, e più trascurato, è il secondo: l'analisi delle carenze. Se non sappiamo dire che cosa non va, non possiamo chiedere di migliorarlo; e i criteri di successo definiti all'inizio, come visto nel 6.2, sono proprio lo strumento per farlo. Un'osservazione utile: le carenze più comuni ricadono in poche categorie, come contenuto mancante o superfluo, tono o registro inadatto, struttura o formato sbagliati, livello di dettaglio inadeguato, interpretazione errata del compito. Riconoscere la categoria aiuta a formulare il feedback giusto.");
    const st = [["FiEdit3", "Prima formulazione"], ["FiSearch", "Analisi delle carenze"], ["FiMessageSquare", "Feedback e correzione"], ["FiRefreshCw", "Raffinamento"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.25, 2.05, 1.55, i === 1 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.38, 0.6, st[i][0]);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.1, y: 2.05, w: 1.85, h: 0.6, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
      if (i < 3) arrow(s, x + 2.07, 1.9, 0.24);
    }
    txt(s, "Carenze più comuni", { x: 0.5, y: 3.0, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    ["Contenuto mancante o superfluo", "Tono o registro inadatto", "Struttura o formato sbagliati", "Dettaglio inadeguato", "Compito frainteso"].forEach((t, i) => chip(s, 0.5 + i * 1.84, 3.4, 1.7, 0.75, t, { fill: C.background1, line: { color: C.accent3, width: 1 }, fontSize: 11 }));
    banner(s, 4.35, "Il passaggio chiave è l'analisi: se non sappiamo dire che cosa non va, non possiamo chiedere di migliorarlo.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Feedback efficaci", "La qualità del feedback determina la qualità della revisione. Un feedback generico, come 'non mi piace, rifallo' o 'miglioralo', produce di solito un risultato diverso ma non necessariamente migliore, perché il sistema non sa che cosa cambiare. Un feedback efficace ha tre caratteristiche. È specifico: indica che cosa non va e dove. È motivato: spiega perché, così che il sistema possa applicare il criterio anche ad altre parti. È costruttivo: indica la direzione del cambiamento, non solo il problema. La tabella mostra alcune trasformazioni. Invece di 'troppo lungo', 'riduci a metà, eliminando gli esempi e mantenendo le tre raccomandazioni'. Invece di 'non è professionale', 'usa un tono più formale: niente espressioni colloquiali e prima persona plurale'. Invece di 'manca qualcosa', 'aggiungi un paragrafo sui tempi di attuazione, che per la direzione è il punto più importante'. Un altro accorgimento utile è indicare anche ciò che va bene e deve restare invariato: 'mantieni la struttura e l'introduzione, cambia solo la conclusione'. Senza questa indicazione, il sistema può modificare anche le parti che funzionavano.");
    table(s, [["Feedback generico", "Feedback efficace"], ["\"Troppo lungo\"", "\"Riduci a metà: elimina gli esempi, mantieni le tre raccomandazioni\""], ["\"Non è professionale\"", "\"Tono più formale: niente espressioni colloquiali, prima persona plurale\""], ["\"Manca qualcosa\"", "\"Aggiungi un paragrafo sui tempi di attuazione, il punto più importante per la direzione\""], ["\"Miglioralo\"", "\"Mantieni struttura e introduzione; rendi la conclusione più concreta\""]], { colW: [2.6, 6.4], rowH: 0.62, accentCol: 1, blankCorner: false, fontSize: 12 });
    const c = ["Specifico: che cosa e dove", "Motivato: perché", "Costruttivo: in che direzione", "Dire anche che cosa mantenere"];
    c.forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.45, 2.15, 0.5, t, { fill: C.accent6, fontSize: 11 }));
  }
  {
    const s = content("Raffinare, approfondire, riformulare", "Oltre a correggere, l'iterazione permette di fare altre tre cose. Raffinare le istruzioni: aggiungere progressivamente i requisiti emersi osservando i risultati. Spesso ci si accorge solo vedendo la prima versione di un vincolo implicito, per esempio che il testo non deve citare un concorrente, o che serve un certo ordine degli argomenti. Approfondire: chiedere di sviluppare un punto specifico, aggiungere dettagli, esempi, dati, o spiegare un passaggio. 'Sviluppa il secondo punto con un esempio concreto', 'spiega meglio come hai stimato i tempi'. Riformulare: chiedere di riscrivere il risultato in un altro modo, per un altro pubblico, con un'altra struttura, o di riformulare la propria richiesta quando ci si accorge che era impostata male. Un suggerimento pratico: quando un'iterazione fa emergere un requisito importante, conviene annotarlo e includerlo nella richiesta iniziale la volta successiva, o nel template, come vedremo nel 6.8. Così ciò che si impara in un dialogo non si perde.");
    const c = [["FiSliders", "Raffinare", "Aggiungere i requisiti emersi dai risultati", "\"Non citare i concorrenti; inizia dai benefici per il cliente.\""], ["FiZoomIn", "Approfondire", "Sviluppare un punto, aggiungere dettagli o spiegazioni", "\"Sviluppa il secondo punto con un esempio concreto.\""], ["FiRepeat", "Riformulare", "Riscrivere per altro pubblico o struttura; correggere la richiesta", "\"Riscrivilo per i colleghi del magazzino.\""]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.0, { icon: c[i][0], head: c[i][1], headSize: 16, bodySize: 12,
      body: [{ text: c[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 10 } }, { text: c[i][3], options: { italic: true } }] });
    banner(s, 4.35, "I requisiti emersi in un dialogo vanno annotati e inclusi la volta successiva, o nel template (6.8).", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Modificare la richiesta o ricominciare", "Nelle conversazioni articolate arriva spesso il momento di chiedersi se continuare a correggere o ricominciare da capo. Ecco alcuni criteri pratici. Conviene continuare nella stessa conversazione quando il risultato si sta avvicinando a ciò che serve, le correzioni sono puntuali e il contesto accumulato è utile. Conviene ricominciare, con una nuova richiesta in una nuova conversazione, quando dopo più iterazioni il risultato non migliora, o peggiora; quando il sistema continua a riproporre lo stesso errore nonostante le correzioni; quando ci si accorge che la richiesta iniziale era impostata male e le correzioni si stanno accumulando; quando la conversazione è diventata lunga e confusa. Ricominciare non significa perdere il lavoro fatto: si scrive una nuova richiesta che incorpora tutto ciò che si è imparato, cioè i requisiti emersi, gli errori da evitare, eventualmente la parte migliore del risultato ottenuto. Spesso una richiesta nuova e ben impostata ottiene in un passaggio ciò che dieci correzioni non avevano ottenuto. Ricordiamo anche quanto detto nel Tema 5: se nemmeno ricominciando il risultato migliora, forse il compito non è adatto all'AI o mancano informazioni essenziali.");
    await card(s, 0.5, 1.2, 4.35, 2.8, { icon: "FiArrowRight", head: "Continuare", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Il risultato si sta avvicinando", "Le correzioni sono puntuali", "Il contesto accumulato è utile"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.8, { icon: "FiRefreshCw", head: "Ricominciare", headSize: 16, bodySize: 13,
      body: bullets(["Più iterazioni senza miglioramenti", "Lo stesso errore si ripete", "La richiesta iniziale era impostata male", "Conversazione lunga e confusa"], { space: 3 }) });
    banner(s, 4.15, "Ricominciare con una richiesta che incorpora ciò che si è imparato: requisiti, errori da evitare, parti migliori.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("I limiti dell'iterazione", "Questa integrazione del sottotema contiene uno dei messaggi più importanti del modulo. L'iterazione migliora l'aderenza alla richiesta: il risultato diventa sempre più simile a ciò che abbiamo chiesto, nel tono, nel formato, nella struttura, nei contenuti indicati. Ma aderenza e accuratezza sono cose diverse. Un testo può essere perfettamente aderente a tono e formato richiesti, e contenere un dato sbagliato. Anzi, il rischio è che proprio la cura della forma ci renda meno attenti al contenuto: dopo cinque iterazioni sul tono, il testo ci sembra 'finito' e non controlliamo più i fatti. Inoltre, ripetere una richiesta non garantisce la rimozione degli errori: se il sistema non ha le informazioni corrette, continuerà a riproporre l'errore, oppure lo sostituirà con un altro, magari dopo essersi scusato. E chiedere 'sei sicuro?' non è una verifica, come abbiamo visto nel Tema 3. Il concetto chiave lo dice con precisione: la verifica indipendente della correttezza appartiene a una fase distinta. Le metodologie di verifica saranno oggetto del Tema 7.");
    shapeBox(s, 0.5, 1.2, 4.35, 2.6, C.accent6, "aderenza");
    txt(s, "Aderenza", { x: 0.7, y: 1.32, w: 3.95, h: 0.45, fontSize: 18, bold: true, color: C.accent1 });
    txt(s, "Il risultato corrisponde a ciò che è stato chiesto: tono, formato, struttura, contenuti indicati.", { x: 0.7, y: 1.85, w: 3.95, h: 0.9, fontSize: 13, color: C.text1 });
    txt(s, "L'iterazione la migliora molto.", { x: 0.7, y: 3.0, w: 3.95, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
    shapeBox(s, 5.15, 1.2, 4.35, 2.6, C.text1, "correttezza");
    txt(s, "Correttezza", { x: 5.35, y: 1.32, w: 3.95, h: 0.45, fontSize: 18, bold: true, color: C.background1 });
    txt(s, "Il contenuto corrisponde ai fatti ed è privo di errori.", { x: 5.35, y: 1.85, w: 3.95, h: 0.9, fontSize: 13, color: C.accent3 });
    txt(s, "Richiede una verifica distinta.", { x: 5.35, y: 3.0, w: 3.95, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
    const r = ["La cura della forma riduce l'attenzione al contenuto", "Ripetere la richiesta non rimuove gli errori", "\"Sei sicuro?\" non è una verifica"];
    r.forEach((t, i) => chip(s, 0.5 + i * 3.07, 4.05, 2.86, 0.85, t, { fill: C.background1, line: { color: C.accent5, width: 1.25 }, color: C.text1, fontSize: 12 }));
  }
  keySlide("L'iterazione consente di migliorare l'aderenza al compito, ma la verifica indipendente della correttezza appartiene a una fase distinta.", "Sottotema 6.5  ·  Prompting iterativo e miglioramento progressivo", "Concetto chiave. Il prompting iterativo segue un ciclo: formulare, analizzare le carenze, dare feedback, raffinare. Il feedback efficace è specifico, motivato, costruttivo, e dice anche che cosa mantenere. L'iterazione permette di raffinare, approfondire, riformulare; e a volte conviene ricominciare con una richiesta migliore. Ma un risultato più aderente non è necessariamente più corretto. Esercizio suggerito: prendere un risultato insoddisfacente prodotto dall'AI e far scrivere ai partecipanti un feedback generico e uno efficace, confrontando poi le due revisioni.");

  // =====================================================================
  section("6.6 Formato e struttura");
  divider("6.6", "Guidare il formato e la struttura degli output", "La forma dell'output ne condiziona l'utilità, ma la buona formattazione non dimostra la correttezza del contenuto", "Un risultato può essere corretto e pertinente, ma inutilizzabile se ha la forma sbagliata: un testo lungo quando serviva una tabella, un linguaggio tecnico per un pubblico non esperto, un elenco disordinato quando serviva un formato da importare in un altro programma. In questo sottotema, da applicare, vediamo come guidare formato, struttura, livello di dettaglio, tono e stile, con un'introduzione agli output strutturati come JSON e CSV.");
  {
    const s = content("Definire il formato desiderato", "Senza indicazioni, il sistema sceglie un formato 'medio', di solito testo con paragrafi, talvolta con titoli ed elenchi. Specificare il formato fa risparmiare molto lavoro di adattamento e rende il risultato immediatamente utilizzabile. Le opzioni principali sono quelle in slide. Testo strutturato con titoli e paragrafi, adatto a documenti e spiegazioni. Elenchi puntati o numerati, adatti a passaggi, requisiti, sintesi. Tabelle, adatte a confronti e dati con più attributi. Schemi e strutture gerarchiche, come mappe, sequenze di passaggi, alberi decisionali. Documenti professionali con struttura definita, come report, verbali, email, presentazioni. Formati strutturati per altri programmi, come JSON e CSV, che vedremo tra poco. La domanda da porsi è: che cosa farò con il risultato? Se va incollato in una presentazione, servono punti brevi; se va confrontato, una tabella; se va importato in un foglio di calcolo, un CSV. Il formato non è un dettaglio estetico: è parte dell'utilità del risultato nelle attività successive.");
    const f = [["FiAlignLeft", "Testo strutturato", "Documenti, spiegazioni"], ["FiList", "Elenchi", "Passaggi, requisiti, sintesi"], ["FiGrid", "Tabelle", "Confronti, dati con più attributi"], ["FiGitBranch", "Schemi", "Sequenze, gerarchie, decisioni"], ["FiFileText", "Documenti professionali", "Report, verbali, email"], ["FiCode", "Formati strutturati", "JSON, CSV per altri programmi"]];
    await iconGrid(s, f.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 2.95, headSize: 14, bodySize: 12 });
    banner(s, 4.35, "La domanda da porsi: che cosa farò con il risultato?", { h: 0.6 });
  }
  {
    const s = content("Report, documenti e comunicazioni professionali", "Per i documenti professionali, il formato comprende la struttura delle sezioni, l'ordine degli argomenti e le convenzioni del genere. Indicare la struttura desiderata è uno dei modi più efficaci per ottenere documenti utilizzabili. Per esempio, per un verbale di riunione: data e partecipanti; argomenti discussi; decisioni prese; azioni, con responsabile e scadenza; prossimi passi. Per un report: sintesi iniziale in tre righe; contesto; analisi; conclusioni; raccomandazioni. Per un'email: oggetto; messaggio principale nelle prime due righe; dettagli; richiesta o prossimo passo; chiusura. Le aziende hanno spesso modelli propri: fornire al sistema un modello vuoto, o un esempio di documento ben fatto privo di dati riservati, è il modo più rapido per ottenere risultati coerenti con le prassi interne. È un'applicazione del few-shot visto nel 6.4. Anche la lunghezza va indicata, in modo concreto: 'una pagina', 'massimo 200 parole', 'cinque punti di una riga', piuttosto che 'breve'.");
    const d = [["Verbale", ["Data e partecipanti", "Argomenti discussi", "Decisioni prese", "Azioni: responsabile e scadenza", "Prossimi passi"]], ["Report", ["Sintesi in tre righe", "Contesto", "Analisi", "Conclusioni", "Raccomandazioni"]], ["Email", ["Oggetto", "Messaggio principale nelle prime due righe", "Dettagli", "Richiesta o prossimo passo", "Chiusura"]]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.75, i === 1 ? C.accent6 : C.background2, d[i][0]);
      txt(s, d[i][0], { x: x + 0.2, y: 1.3, w: 2.46, h: 0.4, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, d[i][1].map((t, k) => ({ text: (k + 1) + ". " + t, options: { breakLine: k < d[i][1].length - 1, paraSpaceAfter: 4 } })), { x: x + 0.2, y: 1.8, w: 2.46, h: 2.05, fontSize: 12, color: C.text1 });
    }
    await card(s, 0.5, 4.1, 4.35, 0.88, { inline: true, icon: "FiCopy", head: "Fornire un modello o un esempio", headSize: 12 });
    await card(s, 5.15, 4.1, 4.35, 0.88, { inline: true, icon: "FiMaximize2", head: "Lunghezza concreta, non \"breve\"", headSize: 12, fill: C.accent6 });
  }
  {
    const s = content("Dettaglio, tono e destinatario", "Lo stesso contenuto può e deve cambiare forma a seconda di chi lo riceverà. Tre aspetti vanno guidati. Il livello di dettaglio e di sintesi: una sintesi per la direzione, una spiegazione completa per chi deve applicare una procedura, un riepilogo di una riga per un messaggio rapido. Il tono e lo stile: formale o informale, tecnico o divulgativo, neutro o persuasivo, conciso o esplicativo. L'adattamento al destinatario: il suo ruolo, le sue conoscenze, le sue priorità, ciò che deve fare dopo aver letto. L'esempio in slide mostra la stessa informazione, l'introduzione di un nuovo software per le note spese, adattata a tre destinatari: la direzione, interessata a costi e benefici; i dipendenti, interessati a che cosa cambia per loro e a come fare; il reparto amministrativo, interessato ai controlli e alle scadenze. Un modo efficace per guidare questi aspetti è descrivere il destinatario, invece di elencare aggettivi sul tono: 'il testo è per colleghi del magazzino che usano poco il computer' comunica più di 'semplice e chiaro'. Un'altra tecnica utile è chiedere più versioni per destinatari diversi a partire dallo stesso contenuto.");
    txt(s, "Stessa informazione: il nuovo software per le note spese", { x: 0.5, y: 1.15, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const a = [["FiBriefcase", "Direzione", "Costi, benefici, tempi di adozione", "Sintetico, orientato alla decisione"], ["FiUsers", "Dipendenti", "Che cosa cambia per me, come si fa", "Semplice, pratico, passo passo"], ["FiDollarSign", "Amministrazione", "Controlli, scadenze, integrazione contabile", "Preciso, tecnico, completo"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.6, 2.86, 2.2, { icon: a[i][0], head: a[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2,
      body: [{ text: a[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }, { text: a[i][3], options: {} }] });
    banner(s, 4.0, "Descrivere il destinatario comunica più di un elenco di aggettivi: \"colleghi del magazzino che usano poco il computer\".", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Introduzione agli output strutturati", "Gli output strutturati sono formati pensati per essere letti da altri programmi, oltre che dalle persone. I due più comuni sono il CSV e il JSON. Il CSV, comma separated values, è una tabella in formato testo, con una riga per ogni record e i valori separati da un segno, di solito virgola o punto e virgola: si apre direttamente in un foglio di calcolo. Il JSON è un formato con coppie di nomi e valori, molto usato per lo scambio di dati tra applicazioni. Perché sono utili anche a chi non programma? Perché permettono di trasformare informazioni disordinate in dati ordinati e riutilizzabili: per esempio, estrarre da venti email dei clienti il nome dell'azienda, il prodotto richiesto e la quantità, in un CSV da incollare in un foglio di calcolo. Quando si chiede un output strutturato, conviene specificare esattamente i campi, il loro ordine, il separatore e come trattare i valori mancanti. Due avvertenze: il formato può contenere piccoli errori di struttura, quindi va controllato prima di importarlo; e un dato ben formattato non è per questo un dato corretto. L'uso di questi formati in integrazioni automatiche va solo accennato in questo modulo.");
    promptBox(s, 0.5, 1.2, 4.35, 1.6, "Estrai da ogni email: azienda, prodotto, quantità. Restituisci un CSV con separatore punto e virgola e intestazione. Se un dato manca, scrivi ND.", { label: "Richiesta", fontSize: 11 });
    promptBox(s, 0.5, 2.95, 4.35, 1.4, "azienda;prodotto;quantità\nAlfa Srl;Modello A;20\nBeta Spa;Modello C;ND", { label: "CSV: si apre in un foglio di calcolo", fill: C.accent6, fontSize: 11 });
    promptBox(s, 5.15, 1.2, 4.35, 2.1, "{\n  \"azienda\": \"Alfa Srl\",\n  \"prodotto\": \"Modello A\",\n  \"quantità\": 20\n}", { label: "JSON: coppie di nomi e valori", fontSize: 11 });
    await card(s, 5.15, 3.45, 4.35, 0.9, { inline: true, icon: "FiList", head: "Specificare campi, ordine, separatore, valori mancanti", headSize: 12 });
    banner(s, 4.5, "Controllare la struttura prima di importare. Un dato ben formattato non è per questo corretto.", { h: 0.48, fontSize: 12 });
  }
  {
    const s = content("Vincoli di presentazione e criteri verificabili", "Oltre al formato generale, si possono indicare vincoli di presentazione più precisi: lunghezze massime, numero di punti, presenza o assenza di titoli, uso del grassetto, lingua, convenzioni per date e numeri, terminologia da usare o evitare. Per esempio: 'date nel formato gg/mm/aaaa', 'importi in euro con due decimali', 'usa sempre il termine collaboratore, non dipendente'. Ancora più utile è formulare requisiti verificabili, cioè criteri che si possono controllare in modo oggettivo sul risultato: 'ogni azione deve avere un responsabile e una scadenza', 'ogni raccomandazione deve fare riferimento a un dato del report', 'nessun paragrafo oltre le quattro righe'. I requisiti verificabili hanno un doppio vantaggio: orientano il sistema in modo preciso, e permettono di controllare rapidamente se il risultato li rispetta, sia a noi sia, in parte, al sistema stesso, a cui si può chiedere di controllare i requisiti prima di consegnare il risultato. Un'avvertenza: anche il controllo dei requisiti da parte del sistema non è infallibile, e va confermato con una rapida rilettura.");
    await card(s, 0.5, 1.2, 4.35, 2.75, { icon: "FiLayout", head: "Vincoli di presentazione", headSize: 15, bodySize: 12,
      body: bullets(["\"Date nel formato gg/mm/aaaa\"", "\"Importi in euro con due decimali\"", "\"Usa sempre il termine collaboratore\"", "\"Massimo cinque punti, senza titoli\""], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.75, { icon: "FiCheckSquare", head: "Requisiti verificabili", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["\"Ogni azione ha responsabile e scadenza\"", "\"Ogni raccomandazione cita un dato del report\"", "\"Nessun paragrafo oltre quattro righe\""], { space: 4 }) });
    banner(s, 4.1, "I requisiti verificabili orientano il sistema e permettono un controllo rapido del risultato.", { h: 0.85, fontSize: 13 });
  }
  keySlide("La forma dell'output ne condiziona l'utilità nelle attività successive, ma la buona formattazione non dimostra la correttezza del contenuto.", "Sottotema 6.6  ·  Guidare il formato e la struttura degli output", "Concetto chiave. Il formato si sceglie in base a ciò che si farà con il risultato: testo, elenchi, tabelle, schemi, documenti professionali, formati strutturati come CSV e JSON. Dettaglio, tono e stile si guidano descrivendo il destinatario. Vincoli di presentazione e requisiti verificabili rendono il risultato preciso e controllabile. Ma una tabella ordinata o un report ben impaginato non sono, per questo, corretti: torna il principio dell'autorevolezza apparente visto nel Tema 3. Esercizio suggerito: chiedere ai partecipanti di trasformare un elenco di appunti disordinati in una tabella con colonne definite da loro.");

  // =====================================================================
  section("6.7 Attività professionali");
  divider("6.7", "Prompting per attività professionali", "Il metodo si adatta allo scopo e al contesto: si imparano principi, non prompt universali", "Applichiamo ora i principi alle attività professionali più comuni. Il criterio è chiaro: non costruiamo un catalogo di casi d'uso, oggetto dei Temi 8-11, né un repertorio di prompt da memorizzare. Vediamo come gli stessi principi si adattano ad attività diverse, con alcuni esempi illustrativi. Gli esempi sono volutamente privi di dati riservati: nella pratica, documenti e dati aziendali vanno usati solo con strumenti autorizzati.");
  {
    const s = content("Attività creative, analitiche e operative", "Le attività professionali in cui si usa l'AI possono essere ricondotte a tre grandi famiglie, che richiedono approcci di prompting diversi. Le attività creative, come brainstorming, scrittura di contenuti, ideazione di nomi o campagne: qui si cercano varietà e originalità. Conviene chiedere molte alternative, indicare il tono e i vincoli ma lasciare spazio, iterare per selezionare e combinare. La valutazione è soprattutto di gusto e di adeguatezza. Le attività analitiche, come sintesi documentale, analisi di dati, confronto di alternative: qui si cercano accuratezza e fedeltà alle fonti. Conviene fornire i materiali, chiedere di basarsi solo su di essi, distinguere fatti e interpretazioni, definire criteri espliciti, verificare con attenzione. Le attività operative, come scrittura di comunicazioni standard, estrazione di dati, compilazione di documenti: qui si cercano coerenza e ripetibilità. Conviene usare istruzioni strutturate, esempi, formati precisi, template riutilizzabili. Riconoscere la natura dell'attività è il primo passo per scegliere il metodo giusto.");
    table(s, [["", "Creative", "Analitiche", "Operative"], ["Si cerca", "Varietà, originalità", "Accuratezza, fedeltà alle fonti", "Coerenza, ripetibilità"], ["Tecniche utili", "Molte alternative, iterazione", "Materiali forniti, criteri espliciti", "Struttura, esempi, template"], ["Istruzione tipica", "\"Proponi dieci idee diverse\"", "\"Usa solo il documento fornito\"", "\"Segui esattamente questo formato\""], ["Valutazione", "Gusto, adeguatezza", "Verifica attenta dei contenuti", "Controllo di requisiti e campioni"]], { colW: [1.9, 2.35, 2.4, 2.35], rowH: 0.64, accentCol: -1, fontSize: 12 });
    txt(s, "Riconoscere la natura dell'attività è il primo passo per scegliere il metodo.", { x: 0.5, y: 4.8, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Scrittura e revisione di contenuti", "La scrittura è l'attività più diffusa. I principi chiave: dichiarare scopo e destinatario, indicare il messaggio principale, fornire i punti da trattare e i vincoli, chiedere il formato e la lunghezza. Per la revisione di un testo proprio, conviene indicare che cosa si vuole migliorare, per esempio chiarezza, sintesi, tono, correttezza linguistica, e che cosa deve restare invariato, per esempio il contenuto o la struttura. Altrimenti il sistema può riscrivere tutto, cambiando anche ciò che andava bene o introducendo affermazioni non presenti nell'originale. Un'altra richiesta utile è chiedere le modifiche sotto forma di suggerimenti motivati, invece del testo riscritto: si mantiene il controllo e si impara. L'esempio in slide mostra una richiesta di revisione. Ricordiamo quanto visto nel Tema 5: partire da una propria bozza e chiedere all'AI di rivederla mantiene il pensiero originale della persona.");
    promptBox(s, 0.5, 1.2, 5.6, 2.7, "Rivedi il testo tra le linee per renderlo più chiaro e sintetico.\nNon modificare i contenuti né aggiungere informazioni.\nMantieni la struttura in tre paragrafi.\nIndica le modifiche principali con una breve motivazione.\n\n-----\n[testo]\n-----", { label: "Esempio: revisione", fill: C.accent6, fontSize: 11 });
    const p = [["Scrittura", "Scopo, destinatario, messaggio principale, punti, vincoli, formato"], ["Revisione", "Che cosa migliorare e che cosa non toccare"], ["Suggerimenti motivati", "Invece del testo riscritto: controllo e apprendimento"]];
    p.forEach((e, i) => {
      const y = 1.2 + i * 0.95;
      shapeBox(s, 6.35, y, 3.15, 0.82, C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.05, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.36, w: 2.9, h: 0.44, fontSize: 11, color: C.text1 });
    });
    banner(s, 4.1, "Senza indicare che cosa non toccare, il sistema può cambiare ciò che andava bene o aggiungere affermazioni nuove.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Analisi e sintesi documentale", "L'analisi e la sintesi di documenti sono tra gli usi più utili dell'AI nel lavoro, e tra quelli in cui la fedeltà alla fonte conta di più. I principi chiave. Fornire il documento, invece di affidarsi alla conoscenza del sistema. Indicare lo scopo della sintesi: una sintesi per decidere è diversa da una per informare. Chiedere di basarsi solo sul documento, e di segnalare quando un'informazione richiesta non è presente, invece di colmare il vuoto. Chiedere riferimenti alle parti del documento, come sezione, pagina o articolo, per poter controllare. Distinguere ciò che il documento dice da ciò che il sistema interpreta. Per documenti lunghi, procedere per parti o indicare su quali sezioni concentrarsi. L'esempio in slide mostra una richiesta di analisi di un contratto di fornitura, per individuare scadenze e obblighi. Ricordiamo che una sintesi può essere accurata in ogni frase e omettere un punto importante, come abbiamo visto nel Tema 3: per i documenti rilevanti, la verifica sulla fonte resta necessaria.");
    promptBox(s, 0.5, 1.2, 5.6, 2.45, "Analizza il contratto di fornitura allegato.\nElenca in una tabella: obblighi del fornitore, obblighi nostri, scadenze, penali.\nPer ogni voce indica l'articolo di riferimento.\nUsa solo il testo del contratto; se un elemento non è presente, scrivi \"non indicato\".", { label: "Esempio: analisi documentale", fill: C.accent6, fontSize: 11 });
    txt(s, "Principi", { x: 6.35, y: 1.2, w: 3.15, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["Fornire il documento", "Indicare lo scopo", "Solo il documento; segnalare ciò che manca", "Riferimenti alle parti", "Fatti distinti da interpretazioni"], { x: 6.35, w: 3.15, y: 1.55, h: 0.4, fontSize: 11 });
    banner(s, 4.1, "Una sintesi può essere accurata in ogni frase e omettere un punto importante: per i documenti rilevanti, verificare sulla fonte.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Informazioni e dati", "Due attività vicine. L'elaborazione e l'organizzazione di informazioni: trasformare appunti, email, messaggi in strutture ordinate, come elenchi di azioni, tabelle, schede, calendari. Qui i formati strutturati del 6.6 sono preziosi: definire le colonne o i campi, chiedere di non inventare dati mancanti, indicare come trattare i casi ambigui. L'analisi e l'interpretazione di dati: individuare tendenze, confrontare periodi, spiegare variazioni, preparare grafici. Tre accorgimenti specifici. Primo, quando lo strumento lo consente, chiedere che i calcoli vengano eseguiti con codice, invece che 'stimati' nel testo, come visto nel Tema 3, e chiedere di mostrare come sono stati fatti. Secondo, chiedere di distinguere ciò che i dati mostrano da ciò che è un'ipotesi interpretativa: 'le vendite sono calate del 12%' è un dato, 'probabilmente per la stagionalità' è un'ipotesi. Terzo, descrivere il significato delle colonne e delle sigle, perché il sistema non conosce le convenzioni interne. I dati aziendali, naturalmente, vanno caricati solo in strumenti autorizzati.");
    await card(s, 0.5, 1.2, 4.35, 2.8, { icon: "FiInbox", head: "Organizzare informazioni", headSize: 15, bodySize: 12,
      body: bullets(["Da appunti ed email a tabelle, azioni, schede", "Definire colonne e campi", "Non inventare dati mancanti", "Indicare come trattare i casi ambigui"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.8, { icon: "FiBarChart2", head: "Analizzare dati", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Calcoli eseguiti con codice, mostrando come", "Dati distinti da ipotesi interpretative", "Spiegare colonne e sigle interne"], { space: 3 }) });
    banner(s, 4.15, "\"Le vendite sono calate del 12%\" è un dato. \"Probabilmente per la stagionalità\" è un'ipotesi.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Ricerca, alternative, brainstorming e problem solving", "Un gruppo di attività orientate al pensiero. Per la ricerca e il confronto di alternative: definire che cosa si cerca e con quali criteri, chiedere fonti verificabili quando lo strumento ha accesso alla ricerca, e trattare i risultati come punto di partenza da verificare. Per il brainstorming: chiedere molte idee, davvero diverse, eventualmente in categorie; indicare i vincoli ma senza restringere troppo; poi selezionare, combinare, approfondire le migliori, e ricordare che le idee tendono al convenzionale. Per il problem solving: usare la scomposizione, chiedere le possibili cause prima delle soluzioni, chiedere alternative e confronto con criteri definiti, e chiedere esplicitamente obiezioni e rischi, applicando il ruolo di interlocutore critico visto nel Tema 5. L'esempio in slide mostra una richiesta di problem solving strutturata in fasi. In tutte queste attività il valore dell'AI sta nell'ampliare e strutturare il ragionamento; la valutazione e la scelta restano della persona.");
    promptBox(s, 0.5, 1.2, 5.6, 3.0, "Il tasso di resi di un nostro prodotto è aumentato negli ultimi tre mesi.\n1. Elenca le possibili cause, raggruppate per area.\n2. Per ciascuna, indica quali dati servirebbero per confermarla.\n3. Proponi tre interventi e confrontali per costo, tempi e impatto.\n4. Indica i rischi principali di ciascun intervento.", { label: "Esempio: problem solving per fasi", fill: C.accent6, fontSize: 11 });
    const a = [["Ricerca", "Criteri chiari, fonti verificabili"], ["Brainstorming", "Molte idee diverse, poi selezione"], ["Problem solving", "Cause, alternative, criteri, rischi"]];
    a.forEach((e, i) => {
      const y = 1.2 + i * 1.0;
      shapeBox(s, 6.35, y, 3.15, 0.88, C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.05, w: 2.9, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.42, w: 2.9, h: 0.42, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.4, "L'AI amplia e struttura il ragionamento; valutazione e scelta restano della persona.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Report e comunicazioni", "L'ultima attività, la preparazione di report e comunicazioni, combina quasi tutti i principi visti. Per un report: definire scopo e destinatario, fornire i dati e i materiali, indicare la struttura e la lunghezza, chiedere una sintesi iniziale, distinguere dati e interpretazioni, inserire raccomandazioni collegate ai dati. Per le comunicazioni: definire il messaggio principale, il destinatario, il tono, l'azione richiesta, il canale, perché un'email, un messaggio di chat e un avviso in bacheca hanno forme diverse. Una buona strategia per i documenti importanti è combinare più passaggi: prima chiedere una scaletta e rivederla; poi far sviluppare il testo sezione per sezione; poi chiedere una revisione critica, per esempio dal punto di vista del destinatario; infine rileggere e verificare personalmente. È un esempio concreto di scomposizione e iterazione applicate a un'attività professionale. Il metodo è lo stesso per un report trimestrale, una comunicazione organizzativa o un'offerta commerciale: cambiano i contenuti e i requisiti, non i principi.");
    const st = [["FiList", "Scaletta", "Chiedere e rivedere la struttura"], ["FiEdit3", "Sviluppo", "Testo sezione per sezione"], ["FiEye", "Revisione critica", "Dal punto di vista del destinatario"], ["FiUserCheck", "Verifica personale", "Rilettura e controllo dei contenuti"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.25, 2.05, 2.1, i === 3 ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.4, 0.6, st[i][0], i === 3 ? C.background1 : C.accent1, i === 3 ? HEX.a1 : HEX.lt1);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.1, y: 2.1, w: 1.85, h: 0.4, fontSize: 14, bold: true, color: i === 3 ? C.background1 : C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.5, w: 1.75, h: 0.75, fontSize: 12, color: i === 3 ? C.accent6 : C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.07, 2.15, 0.24);
    }
    await card(s, 0.5, 3.55, 4.35, 1.4, { inline: true, icon: "FiFileText", head: "Report", bodySize: 12, body: "Scopo, destinatario, dati, struttura, sintesi iniziale, raccomandazioni collegate ai dati." });
    await card(s, 5.15, 3.55, 4.35, 1.4, { inline: true, icon: "FiMail", head: "Comunicazioni", bodySize: 12, fill: C.accent6, body: "Messaggio principale, destinatario, tono, azione richiesta, canale." });
  }
  keySlide("Il metodo deve adattarsi allo scopo e al contesto lavorativo; il tema insegna ad applicare i principi, non a memorizzare prompt universali.", "Sottotema 6.7  ·  Prompting per attività professionali", "Concetto chiave. Attività creative, analitiche e operative richiedono approcci diversi: varietà, fedeltà alle fonti, coerenza. Scrittura e revisione, analisi documentale, organizzazione di informazioni e dati, ricerca, brainstorming e problem solving, report e comunicazioni applicano gli stessi principi in modi diversi. Non esistono prompt universali: esistono principi che si adattano. Esercizio suggerito: chiedere a ciascun partecipante di scegliere un'attività reale del proprio lavoro, classificarla come creativa, analitica o operativa, e scrivere una richiesta applicando i principi del modulo, senza inserire dati riservati.");

  // =====================================================================
  section("6.8 Istruzioni riutilizzabili");
  divider("6.8", "Istruzioni riutilizzabili e standardizzazione", "Le istruzioni riutilizzabili favoriscono coerenza e produttività, ma vanno manutenute e non sostituiscono il controllo", "Ultimo sottotema, a priorità media, da comprendere e conoscere. Quando un'attività si ripete, ha senso non riscrivere ogni volta la richiesta da zero, ma costruire istruzioni riutilizzabili: template, librerie condivise, istruzioni personalizzate, assistenti configurati. Vediamo vantaggi, modalità e limiti, senza entrare nella configurazione tecnica di sistemi complessi, che appartiene al Tema 11.");
  {
    const s = content("Prompt occasionali e ricorrenti", "La prima distinzione riguarda la frequenza. Un prompt occasionale serve per un'esigenza unica o rara: si scrive, si itera, si usa il risultato, e non vale la pena di conservarlo. Un prompt ricorrente serve per un'attività che si ripete: il verbale delle riunioni settimanali, la risposta a un tipo di richiesta frequente, la sintesi mensile di un report, la revisione di testi secondo le regole aziendali. Per i prompt ricorrenti, riscrivere ogni volta la richiesta comporta tre problemi: si perde tempo, si dimenticano requisiti emersi in passato, e i risultati variano a seconda di chi scrive e di come scrive. Trasformare la richiesta in un'istruzione riutilizzabile risolve tutti e tre. Quando conviene farlo? Quando l'attività si ripete con una certa frequenza, quando la richiesta ha già richiesto diverse iterazioni per funzionare bene, quando più persone svolgono la stessa attività e serve coerenza, quando il risultato deve rispettare standard precisi. È la risposta alla nona domanda guida.");
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiZap", head: "Prompt occasionale", headSize: 16, bodySize: 13, body: "Esigenza unica o rara: si scrive, si itera, si usa. Non serve conservarlo." });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiRepeat", head: "Prompt ricorrente", headSize: 16, bodySize: 13, fill: C.accent6, body: "Attività che si ripete: verbali, risposte frequenti, sintesi periodiche, revisioni secondo regole." });
    txt(s, "Quando trasformarlo in istruzione riutilizzabile", { x: 0.5, y: 3.6, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    ["Attività frequente", "Ha richiesto molte iterazioni", "Più persone, serve coerenza", "Standard precisi da rispettare"].forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.0, 2.15, 0.7, t, { fill: C.background2, fontSize: 12 }));
  }
  {
    const s = content("Template di prompt", "Un template è una richiesta riutilizzabile, con una parte fissa, cioè le istruzioni che valgono sempre, e alcune parti variabili, indicate da segnaposto da compilare ogni volta. L'esempio in slide mostra un template per il verbale di riunione. La parte fissa contiene il compito, il formato, le regole, come assegnare sempre un responsabile e una scadenza alle azioni, e la richiesta di segnalare le informazioni mancanti. Le parti variabili, tra parentesi quadre, sono il tipo di riunione, i destinatari e gli appunti. Un buon template incorpora ciò che si è imparato con le iterazioni: i requisiti emersi, gli errori da evitare, gli esempi che funzionano. Per questo, costruire un template è anche un modo per consolidare l'esperienza. Alcuni consigli: usare istruzioni strutturate e delimitazione, come visto nel 6.4, per rendere chiaro che cosa va sostituito; tenere il template il più semplice possibile; indicare in testa a che cosa serve e chi l'ha scritto; provarlo su casi diversi prima di condividerlo.");
    promptBox(s, 0.5, 1.2, 5.8, 3.75, "COMPITO\nRedigi il verbale della riunione [TIPO DI RIUNIONE] per [DESTINATARI].\n\nFORMATO\n1. Partecipanti\n2. Decisioni\n3. Azioni (responsabile, scadenza)\n4. Prossimi passi\n\nREGOLE\nOgni azione ha un responsabile e una scadenza; se mancano, scrivi \"da definire\".\nUsa solo le informazioni degli appunti.\n\nAPPUNTI\n-----\n[APPUNTI]\n-----", { label: "Template: verbale di riunione", fill: C.accent6, fontSize: 10 });
    await card(s, 6.55, 1.2, 2.95, 1.75, { head: "Parte fissa", headSize: 14, bodySize: 12, body: "Compito, formato, regole: ciò che vale sempre." });
    await card(s, 6.55, 3.1, 2.95, 1.85, { head: "Parti variabili", headSize: 14, bodySize: 12, body: "[Segnaposto] da compilare ogni volta." });
  }
  {
    const s = content("Librerie, istruzioni persistenti, assistenti configurati", "Le istruzioni riutilizzabili possono essere conservate e usate in diversi modi. Le librerie condivise di istruzioni: raccolte di template organizzate per attività, condivise in un gruppo di lavoro o in azienda, per esempio in un documento o in uno spazio comune. Permettono di diffondere le buone pratiche e di non ripartire da zero. Le istruzioni personalizzate e le preferenze persistenti: molti strumenti permettono di impostare istruzioni che valgono per tutte le conversazioni, come il proprio ruolo, il tono preferito, il formato abituale, le informazioni sul proprio lavoro. Sono comode, ma vanno usate con attenzione: si applicano a tutto, anche quando non sono pertinenti, e si tende a dimenticarle. Gli assistenti configurati per attività specifiche: come visto nel Tema 4, molti strumenti permettono di creare assistenti con istruzioni, documenti di riferimento e talvolta collegamenti propri, dedicati a un'attività, e di condividerli con i colleghi. Sono l'evoluzione naturale di un template molto usato. Qui li introduciamo soltanto: la loro configurazione tecnica sarà trattata nel Tema 11.");
    const c = [["FiBookOpen", "Librerie condivise", "Template organizzati per attività, condivisi nel gruppo o in azienda", "Diffondono buone pratiche"], ["FiUser", "Istruzioni persistenti", "Ruolo, tono, formato abituale validi per tutte le conversazioni", "Attenzione: si applicano a tutto e si dimenticano"], ["FiUserCheck", "Assistenti configurati", "Istruzioni, documenti e collegamenti dedicati a un'attività", "Evoluzione di un template molto usato"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.3, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2,
      body: [{ text: c[i][2], options: { breakLine: true, paraSpaceAfter: 10 } }, { text: c[i][3], options: { bold: true, color: i === 1 ? C.accent5 : C.accent1 } }] });
    txt(s, "Qui solo un'introduzione: la configurazione tecnica degli assistenti è un argomento a sé.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Standardizzare, versionare, manutenere", "Quando le istruzioni sono usate da più persone o per attività importanti, servono alcune buone pratiche di gestione. La standardizzazione di formati e criteri di qualità: definire, per le attività ricorrenti, il formato atteso e i requisiti che il risultato deve rispettare, così che i risultati siano coerenti indipendentemente da chi usa l'istruzione. La gestione delle versioni: quando un template viene modificato, conviene indicare la versione, la data e il motivo della modifica, e sapere quale versione si sta usando, per poter tornare indietro se una modifica peggiora i risultati. L'aggiornamento e la manutenzione: le istruzioni invecchiano, perché cambiano le procedure, i documenti di riferimento, le esigenze, e anche i modelli, come visto nel Tema 4; un template che funzionava bene può funzionare diversamente con un nuovo modello. La verifica nel tempo: provare periodicamente le istruzioni su casi reali, per controllare che diano ancora i risultati attesi, e indicare un responsabile per ciascuna istruzione condivisa. Sono le stesse pratiche che si usano per qualsiasi documento aziendale importante, come una procedura o un modulo.");
    const p = [["FiLayout", "Standardizzare", "Formato atteso e requisiti di qualità per le attività ricorrenti"], ["FiTag", "Versionare", "Versione, data, motivo della modifica; possibilità di tornare indietro"], ["FiRefreshCw", "Aggiornare", "Procedure, documenti, esigenze e modelli cambiano"], ["FiCheckCircle", "Verificare nel tempo", "Prove periodiche su casi reali, un responsabile per istruzione"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.9, headSize: 14, bodySize: 12 });
    banner(s, 4.3, "Le stesse pratiche di qualsiasi documento aziendale importante, come una procedura o un modulo.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("I limiti della standardizzazione", "La standardizzazione porta coerenza e produttività, ma ha limiti da conoscere. Primo: un template standard non si adatta automaticamente ai casi particolari. Se viene applicato meccanicamente a situazioni diverse da quelle per cui è stato pensato, può produrre risultati inadeguati. Chi lo usa deve riconoscere quando il caso richiede un adattamento. Secondo: un template riduce la variabilità della forma, non garantisce la correttezza del contenuto. I risultati vanno controllati come qualsiasi altro, e anzi la loro forma familiare può indurre a controllarli meno, un caso di automation bias visto nel Tema 5. Terzo: le istruzioni invecchiano, come abbiamo visto, e un template non mantenuto diventa una fonte di errori sistematici. Quarto: un uso eccessivo di template può ridurre la capacità delle persone di formulare richieste e di capire perché un'istruzione funziona; è utile che chi usa un template ne comprenda la logica. Il concetto chiave lo riassume: le istruzioni riutilizzabili favoriscono coerenza e produttività, ma devono essere manutenute e non sostituiscono il controllo dei risultati.");
    const l = [["FiMaximize", "Non si adattano da sole ai casi particolari", "Riconoscere quando serve un adattamento"], ["FiCheckSquare", "Uniformano la forma, non garantiscono il contenuto", "La forma familiare può ridurre i controlli"], ["FiClock", "Invecchiano", "Un template non mantenuto genera errori sistematici"], ["FiUser", "Possono ridurre la competenza", "Chi li usa deve capirne la logica"]];
    await iconGrid(s, l.map(e => ({ icon: e[0], head: e[1], body: e[2], iconBg: C.accent5 })), 2, { y: 1.2, H: 3.75, headSize: 13, bodySize: 12 });
  }
  keySlide("Istruzioni riutilizzabili possono favorire coerenza e produttività, ma devono essere manutenute e non sostituiscono il controllo dei risultati.", "Sottotema 6.8  ·  Istruzioni riutilizzabili e standardizzazione", "Concetto chiave dell'ultimo sottotema. Per le attività ricorrenti conviene costruire istruzioni riutilizzabili: template con parti fisse e variabili, librerie condivise, istruzioni persistenti, assistenti configurati. Servono standardizzazione, gestione delle versioni, manutenzione e verifica nel tempo. E restano i limiti: i template non si adattano da soli, non garantiscono la correttezza, invecchiano, e chi li usa deve capirne la logica. Esercizio suggerito: chiedere ai partecipanti di individuare un'attività ricorrente del proprio lavoro e di costruire un template, con parti fisse e segnaposto.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle dieci domande guida. Che cos'è un prompt: il testo con cui comunichiamo obiettivi, aspettative e informazioni. Come identificare il problema: chiedendosi quale problema, a quale scopo, con quali criteri di successo. Quali elementi rendono una richiesta chiara: quelli rilevanti tra problema, obiettivo, compito, contesto, vincoli, formato, criteri, ruolo. Quale contesto è pertinente: quello che cambierebbe il risultato, organizzato e comprensibile. Come chiedere chiarimenti: istruendo il sistema a porre domande e a distinguere dati e ipotesi. Quando usare le tecniche: in proporzione al compito, partendo dalla richiesta più semplice. Come migliorare un output: con un ciclo di analisi e feedback specifico. Come ottenere il formato giusto: chiedendosi che cosa si farà con il risultato. Quando creare un template: per attività ricorrenti, condivise o con standard precisi. Perché un buon prompt non garantisce la correttezza: perché migliora l'aderenza, non la verità. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Che cos'è un prompt?", "Comunica obiettivi, aspettative, informazioni"], ["Come identificare il problema?", "Quale problema, a quale scopo, quali criteri"], ["Quali elementi?", "Quelli rilevanti tra gli otto"], ["Quale contesto?", "Ciò che cambierebbe il risultato"], ["Come chiedere chiarimenti?", "Domande, dati distinti dalle ipotesi"], ["Quando usare le tecniche?", "In proporzione al compito"], ["Come migliorare un output?", "Analisi delle carenze e feedback specifico"], ["Quale formato?", "Che cosa farò con il risultato?"], ["Quando un template?", "Attività ricorrenti, condivise, con standard"], ["Perché non garantisce la correttezza?", "Migliora l'aderenza, non la verità"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.79;
      shapeBox(s, x, y, 4.4, 0.71, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.45, h: 0.71, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.05, w: 3.75, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.36, w: 3.75, h: 0.3, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo gli undici risultati attesi. Il partecipante dovrebbe essere in grado di: spiegare che cos'è un prompt e quali funzioni svolge; definire il problema prima di formulare una richiesta; esplicitare obiettivi, requisiti e criteri di qualità; selezionare e fornire contesto adeguato; riconoscere lacune informative e chiedere chiarimenti; usare tecniche proporzionate al compito; migliorare le risposte con feedback e iterazioni; specificare strutture e formati utilizzabili; adattare le tecniche alle principali attività professionali; costruire e riutilizzare template; riconoscere i limiti del prompting e la necessità di verificare i risultati.");
    const r = ["Spiegare che cos'è un prompt e a che cosa serve", "Definire il problema prima della richiesta", "Esplicitare obiettivi, requisiti, criteri di qualità", "Selezionare e fornire contesto adeguato", "Riconoscere lacune e chiedere chiarimenti", "Usare tecniche proporzionate al compito", "Migliorare con feedback e iterazioni", "Specificare formati utilizzabili", "Adattare le tecniche alle attività professionali", "Costruire e riutilizzare template", "Riconoscere i limiti e verificare i risultati"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.45, h: 0.58, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.75, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Uno schema per le richieste importanti", "Come per i moduli precedenti, traduciamo il tema in uno strumento pratico: uno schema per le richieste importanti, da usare come lista di controllo, non come modulo obbligatorio. Prima di scrivere: qual è il problema, lo scopo, il criterio di successo? Nella richiesta: compito, contesto e destinatario, vincoli, formato; eventualmente esempi, ruolo o prospettiva; e l'istruzione di porre domande se mancano informazioni e di distinguere dati e ipotesi. Dopo il primo risultato: analizzare le carenze e dare feedback specifico, oppure ricominciare con una richiesta migliore. Prima di usare il risultato: ricordare che aderenza non significa correttezza, e verificare in proporzione all'importanza, come vedremo nel Tema 7. Se l'attività è ricorrente: trasformare la richiesta in un template. E sempre: nessun dato riservato in strumenti non autorizzati.");
    const st = [["Prima di scrivere", "Problema, scopo, criterio di successo", C.background2], ["Nella richiesta", "Compito, contesto e destinatario, vincoli, formato; se utile esempi, ruolo, domande di chiarimento", C.accent6], ["Dopo il primo risultato", "Analisi delle carenze e feedback specifico, o una nuova richiesta", C.background2], ["Prima di usarlo", "Aderenza non è correttezza: verifica proporzionata all'importanza", C.accent6], ["Se è ricorrente", "Trasformarla in un template", C.background2]];
    st.forEach((e, i) => {
      const y = 1.12 + i * 0.68;
      shapeBox(s, 0.5, y, 9.0, 0.6, e[2], e[0]);
      txt(s, e[0], { x: 0.65, y, w: 2.5, h: 0.6, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.2, y, w: 6.2, h: 0.6, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 4.6, "E sempre: nessun dato riservato in strumenti non autorizzati.", { h: 0.42, fontSize: 12 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei errori tipici nel prompting, uno per ciascuno dei principali messaggi del modulo. Primo: cercare la formula magica. Non esistono prompt universali: esistono principi da adattare al compito, e una richiesta semplice può essere adeguata quanto una strutturata. Secondo: scrivere prima di aver chiarito il problema. Molti prompt deludenti sono la risposta giusta alla domanda sbagliata. Terzo: allegare tutto per sicurezza. Più informazioni non producono automaticamente risultati migliori; serve un contesto pertinente e ordinato. Quarto: dire soltanto 'rifallo'. Un feedback generico produce un risultato diverso, non necessariamente migliore; serve dire che cosa, dove e perché. Quinto: scambiare un testo ben formattato per un testo corretto. Aderenza e formato non dimostrano la correttezza, che richiede una verifica distinta. Sesto: usare un template senza mantenerlo. Le istruzioni invecchiano con le procedure e con i modelli, e vanno provate nel tempo. Suggerimento: chiedere ai partecipanti quale di questi errori riconoscono nelle proprie abitudini.");
    const a = [["FiZap", "\"Esiste la formula magica\"", "Principi da adattare, non prompt universali", "6.1"], ["FiHelpCircle", "\"Scrivo subito la richiesta\"", "Prima il problema, poi il prompt", "6.2"], ["FiPaperclip", "\"Allego tutto, per sicurezza\"", "Contesto pertinente e ordinato", "6.3"], ["FiRotateCcw", "\"Non va bene, rifallo\"", "Feedback specifico e motivato", "6.5"], ["FiLayout", "\"È ben formattato, quindi è giusto\"", "Aderenza non è correttezza", "6.6"], ["FiArchive", "\"Il template funziona per sempre\"", "Le istruzioni vanno mantenute", "6.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Prossimo passo: il Tema 7", "Il percorso prosegue con il Tema 7, dedicato alla verifica degli output e al pensiero critico. In questo modulo abbiamo ripetuto più volte un principio: il prompting migliora l'aderenza alla richiesta, ma la correttezza richiede una verifica distinta. Il Tema 7 sarà dedicato proprio a questa fase: come controllare i contenuti prodotti dall'AI, come verificare fatti e fonti, come valutare la solidità di un ragionamento, come esercitare il pensiero critico nell'uso quotidiano dell'AI. Completerà così il ciclo dell'interazione: definire il problema e formulare la richiesta, guidare il sistema, verificare il risultato. Lasciare spazio alle domande finali e, se possibile, a un'esercitazione pratica conclusiva. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.background2, "tema 6");
    txt(s, "TEMA 6", { x: 0.75, y: 1.4, w: 3.1, h: 0.35, fontSize: 13, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Prompting e tecniche di interazione", { x: 0.75, y: 1.8, w: 3.1, h: 0.75, fontSize: 18, bold: true, color: C.text1 });
    txt(s, bullets(["Definire il problema", "Formulare la richiesta", "Guidare e iterare", "Riutilizzare"], { space: 4 }), { x: 0.75, y: 2.7, w: 3.1, h: 2.0, fontSize: 14, color: C.text2 });
    arrow(s, 4.25, 2.9, 0.55, C.accent1);
    shapeBox(s, 4.95, 1.2, 4.55, 3.75, C.text1, "tema 7");
    txt(s, "TEMA 7", { x: 5.2, y: 1.4, w: 4.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Verifica degli output e pensiero critico", { x: 5.2, y: 1.8, w: 4.1, h: 0.75, fontSize: 18, bold: true, color: C.background1 });
    txt(s, bullets(["Controllare i contenuti", "Verificare fatti e fonti", "Valutare i ragionamenti", "Esercitare il pensiero critico"], { space: 3 }), { x: 5.2, y: 2.7, w: 4.1, h: 2.0, fontSize: 14, color: C.accent3 });
  }
  {
    const s = content("Nota sulle fonti e sugli esempi", "Questa slide è pensata per il relatore. I principi presentati nel modulo sono coerenti con le guide al prompting pubblicate dai principali fornitori di modelli, che vale la pena consultare per approfondire e per aggiornarsi, perché vengono riviste con l'evoluzione dei modelli. Le tecniche cambiano meno rapidamente dei prodotti, ma alcune indicazioni specifiche, per esempio sulle convenzioni di delimitazione o sui modelli che ragionano prima di rispondere, possono evolvere. Gli esempi di prompt nelle slide sono illustrativi, costruiti per il corso e privi di dati riservati: vanno adattati alla realtà aziendale, preferibilmente con casi proposti dai partecipanti, e provati sullo strumento autorizzato dall'azienda prima della sessione. Nelle esercitazioni, ricordare sempre di non inserire dati riservati in strumenti non autorizzati. Le guide citate in slide: Anthropic, 'Prompt engineering overview' (docs.claude.com); OpenAI, 'Prompt engineering' e 'Reasoning best practices' (platform.openai.com); Google, 'Prompt design strategies' per la Gemini API (ai.google.dev). Titoli e indirizzi verificati a ottobre 2026, ma le pagine vengono riorganizzate spesso: se un indirizzo non funziona, cercare il titolo della guida.");
    await iconCircle(s, 0.5, 1.25, 0.6, "FiBookmark");
    txt(s, "Per il relatore", { x: 1.3, y: 1.25, w: 8.2, h: 0.6, fontSize: 16, bold: true, color: C.text1, valign: "middle" });
    rowList(s, ["Anthropic: Prompt engineering overview (docs.claude.com)", "OpenAI: Prompt engineering; Reasoning best practices (platform.openai.com)", "Google: Prompt design strategies, Gemini API (ai.google.dev)", "Le guide vengono aggiornate: consultarle prima di ogni edizione", "Esempi illustrativi, senza dati riservati: adattarli ai casi dei partecipanti e provarli sullo strumento autorizzato"], { y: 2.0, h: 0.46, fontSize: 13 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 0.5, y: 4.75, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema6_Prompting_tecniche_interazione.pptx" });
  await applyTheme("Tema6_Prompting_tecniche_interazione.pptx", THEME);
  console.log("done");
})();
