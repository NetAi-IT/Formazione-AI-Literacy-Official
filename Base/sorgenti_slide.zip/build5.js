const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 5: Il dialogo uomo-AI";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 5  ·  Il dialogo uomo-AI";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function dialog(s, x, y, w, turns, o) {
    o = o || {};
    let yy = y;
    const lh = o.lh || 0.5, gap = o.gap || 0.1;
    turns.forEach(t => {
      const user = t[0] === "P";
      const bw = w * 0.78;
      const bx = user ? x : x + w - bw;
      const h = t[2] || lh;
      shapeBox(s, bx, yy, bw, h, user ? C.background2 : C.accent6, "turno");
      txt(s, [{ text: (user ? "Persona: " : "AI: "), options: { bold: true, color: user ? C.text1 : C.accent1 } }, { text: t[1], options: { color: C.text1 } }], { x: bx + 0.15, y: yy, w: bw - 0.3, h, fontSize: o.fontSize || 12, valign: "middle" });
      yy += h + gap;
    });
    return yy;
  }


  // ---------- helpers aggiunti nella revisione ----------
  // scheda compatta: icona a sinistra, titolo e testo a destra
  async function miniCard(s, x, y, w, h, icon, head, body, fill) {
    shapeBox(s, x, y, w, h, fill || C.background2, head);
    await iconCircle(s, x + 0.15, y + (h - 0.5) / 2, 0.5, icon);
    txt(s, head, { x: x + 0.8, y: y + 0.1, w: w - 0.95, h: 0.34, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
    txt(s, body, { x: x + 0.8, y: y + 0.44, w: w - 0.95, h: h - 0.52, fontSize: 11, color: C.text2 });
  }
  // scheda di ruolo: Esempio, Beneficio, Attenzione
  function roleBody(es, ben, att) {
    return [
      { text: "Esempio", options: { bold: true, color: C.accent2, breakLine: true } },
      { text: es, options: { italic: true, breakLine: true, paraSpaceAfter: 8 } },
      { text: "Beneficio", options: { bold: true, color: C.accent1, breakLine: true } },
      { text: ben, options: { breakLine: true, paraSpaceAfter: 8 } },
      { text: "Attenzione", options: { bold: true, color: C.accent5, breakLine: true } },
      { text: att, options: {} },
    ];
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 5", { placeholder: "kicker" });
    s.addText("Il dialogo uomo-AI", { placeholder: "title" });
    s.addText("Area: Interagire con l'AI\nContenuti aggiornati a ottobre 2026", { placeholder: "sub" });
    s.addNotes(`Benvenuti al quinto tema, che apre una nuova area del percorso: 'Interagire con l'AI'. Nei quattro temi precedenti abbiamo costruito la comprensione: perché l'AI è rilevante, come funziona, quanto possiamo fidarci dei risultati, come è organizzato l'ecosistema. Da qui in avanti ci spostiamo sulla pratica. Questo tema non è un manuale di prompting, che sarà l'oggetto del Tema 6, né un percorso tecnico sugli agenti. Riguarda il modo di lavorare con l'AI: che cosa significa dialogare con un sistema in linguaggio naturale, quali ruoli può assumere, come si collabora, quanto si può delegare, quanto conta la persona e come sviluppare una fiducia ben calibrata. L'obiettivo è che chi esce dal modulo si senta più preparato a usare l'AI, non soltanto più consapevole dei suoi limiti. Suggerimento per l'apertura: chiedere ai partecipanti come descriverebbero il proprio rapporto con un assistente AI, se lo usano: uno strumento, un collega, un consulente, un motore di ricerca? Le metafore che emergono saranno utili per tutto il modulo. Nota per il relatore: contenuti e fonti verificati a ottobre 2026; gli studi sugli effetti dell'AI generativa sul pensiero critico sono in rapida evoluzione e vanno ricontrollati prima di ogni edizione.`);
  }
  {
    const s = content("Obiettivo del modulo", `L'obiettivo del modulo è imparare a collaborare in modo efficace con l'AI attraverso il dialogo. Il beneficio è concreto: chi sa dialogare con un sistema AI riesce a esplorare un problema da più punti di vista, a sviluppare idee, a produrre bozze, analisi e confronti in meno tempo, e a prendere decisioni meglio informate. Per farlo servono tre capacità, che svilupperemo nel modulo: usare il dialogo invece della singola domanda; scegliere il ruolo dell'AI e il livello di delega adatti al compito; ottenere risultati migliori mantenendo un controllo proporzionato. Il secondo riquadro ricorda perché la persona è decisiva: lo stesso strumento dà risultati molto diversi in mani diverse, perché il valore nasce dalla combinazione delle capacità dell'AI con obiettivi chiari, contesto e competenze di chi la usa. È il messaggio che accompagna tutto il tema.`);
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Collaborare con l'AI attraverso il dialogo", "Scegliere il ruolo e il livello di delega adatti al compito", "Ottenere risultati migliori mantenendo un controllo proporzionato"], { space: 8 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiTrendingUp", head: "Perché conviene", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Chi sa dialogare con l'AI esplora problemi, sviluppa idee e produce risultati migliori in meno tempo.\n\nIl valore dipende anche dalla persona: obiettivi chiari, contesto, competenze, controllo adeguato." });
  }
  {
    const s = content("Il filo conduttore", `Il filo conduttore del modulo è un percorso in quattro passi. Primo: l'interfaccia naturale, cioè che cosa cambia quando il linguaggio diventa il modo di usare un software, con le opportunità che apre e l'ambiguità da gestire, nel sottotema 5.1. Secondo: il dialogo e i ruoli, cioè il valore della conversazione progressiva rispetto alla richiesta isolata e i diversi ruoli che l'AI può assumere, nei sottotemi 5.2 e 5.3. Terzo: la collaborazione e la delega, cioè come si dividono i compiti tra persona e sistema e quanta autonomia conviene affidare, nei sottotemi 5.4 e 5.5. Quarto: la persona e la fiducia, cioè perché la qualità dipende dalle competenze di chi usa l'AI e come costruire una fiducia calibrata, nei sottotemi 5.6 e 5.7. Il modulo si chiude con un metodo pratico in cinque passaggi e con i principi di sintesi. Per il relatore, il perimetro: vanno compresi bene il dialogo iterativo, la collaborazione, i livelli di delega, il ruolo delle competenze umane, l'autonomia cognitiva e la responsabilità; vanno conosciuti le interfacce conversazionali, i ruoli dell'AI, l'uso come interlocutore critico, il feedback; vanno solo accennati le teorie dell'interazione uomo-macchina, i modelli psicologici della fiducia e la progettazione di agenti. Non ripetiamo i meccanismi tecnici del Tema 2, l'analisi di allucinazioni e bias del Tema 3, il confronto tra prodotti del Tema 4. Le tecniche per formulare le richieste sono nel Tema 6, la verifica degli output nel Tema 7, la progettazione di agenti e workflow nel Tema 11, la riprogettazione di processi e ruoli nei Temi 13 e 16.`);
    const st = [["FiMessageSquare", "Interfaccia naturale", "Dal comando alla richiesta", "5.1"], ["FiRepeat", "Dialogo e ruoli", "Conversare, scegliere il ruolo dell'AI", "5.2  5.3"], ["FiUsers", "Collaborazione e delega", "Chi fa che cosa, quanta autonomia", "5.4  5.5"], ["FiUserCheck", "Persona e fiducia", "Competenze, fiducia calibrata", "5.6  5.7"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.2, 2.05, 2.65, i === 3 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.35, 0.6, st[i][0]);
      txt(s, st[i][1], { x: x + 0.1, y: 2.05, w: 1.85, h: 0.6, fontSize: 15, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.68, w: 1.75, h: 0.6, fontSize: 12, color: C.text2, align: "center" });
      chip(s, x + 0.45, 3.35, 1.15, 0.34, st[i][3], { fill: C.accent1, color: C.background1, fontSize: 11 });
      if (i < 3) arrow(s, x + 2.07, 2.38, 0.24);
    }
    banner(s, 4.1, "Il valore nasce dalla combinazione delle capacità dell'AI, delle competenze umane e di un controllo adeguato al contesto.", { h: 0.85, fontSize: 14 });
  }

  // =====================================================================
  section("5.1 Linguaggio naturale");
  divider("5.1", "Il linguaggio naturale come interfaccia", "Rende accessibili capacità prima riservate agli specialisti: obiettivi chiari e lettura attenta delle risposte ne moltiplicano il valore", `Nel Tema 1 abbiamo visto che il linguaggio naturale è stato uno dei fattori della svolta generativa, perché ha reso l'AI accessibile a tutti. Qui guardiamo il fenomeno dal punto di vista dell'interazione: che cosa cambia, concretamente, quando parliamo con un software invece di usarne i comandi? Quali possibilità apre, quali aspetti vanno gestiti, e come cambia il nostro rapporto con la tecnologia?`);
  {
    const s = content("Dai comandi alle richieste", `Con il software tradizionale interagiamo attraverso comandi predefiniti: menu, pulsanti, campi da compilare, formule, parole chiave. Ogni comando ha un significato preciso e prevedibile, ma dobbiamo conoscerlo: sapere dove si trova la funzione, come si chiama, in che ordine compilare i campi. Con un'interfaccia conversazionale formuliamo invece richieste in linguaggio naturale, con parole nostre, esprimendo l'obiettivo più che la sequenza di operazioni: 'confronta questi due preventivi e dimmi quale conviene per un ordine di cento pezzi'. Il sistema interpreta la richiesta e propone come soddisfarla. Il confronto in slide mostra le differenze principali. Il punto è che ci spostiamo dal 'come' al 'che cosa': non dobbiamo più sapere come si fa, ma saper dire che cosa vogliamo. Il sistema interpreta, e quando l'interpretazione non è quella giusta possiamo correggerla nel dialogo, come vedremo nel 5.2.`);
    table(s, [["", "Comandi predefiniti", "Richieste in linguaggio naturale"], ["Che cosa esprimiamo", "Il \"come\": la sequenza di operazioni", "Il \"che cosa\": l'obiettivo"], ["Che cosa serve sapere", "Dove sono le funzioni, come si usano", "Che cosa vogliamo ottenere"], ["Significato", "Preciso e prevedibile", "Da interpretare, si chiarisce nel dialogo"], ["Flessibilità", "Solo ciò che è previsto", "Molto ampia, anche richieste nuove"], ["Esempio", "Menu, formule, campi da compilare", "\"Confronta questi preventivi per 100 pezzi\""]], { colW: [2.1, 3.45, 3.45], rowH: 0.55, accentCol: 2 });
    banner(s, 4.55, "Dal \"come si fa\" al \"che cosa voglio\": il sistema interpreta, e il dialogo permette di correggere l'interpretazione.", { h: 0.45, fontSize: 13 });
  }
  {
    const s = content("Opportunità e aspetti da gestire", `La comunicazione conversazionale apre opportunità rilevanti. Accessibilità: chiunque sappia esprimersi può usare capacità prima riservate agli specialisti, come analizzare dati, scrivere codice semplice, tradurre, sintetizzare documenti lunghi. Riduzione delle barriere tecniche: non servono manuali, formule o linguaggi di programmazione per iniziare. Flessibilità: si possono chiedere cose mai previste dai progettisti, combinare attività diverse, cambiare direzione a metà. Esplorazione: diventa facile provare attività nuove, per esempio un'analisi che prima non si sarebbe affrontata. Possibilità di precisare: se il risultato non va, si spiega che cosa cambiare, come con un collega. Ci sono anche aspetti da gestire, e il dialogo è lo strumento principale per farlo. L'ambiguità del linguaggio si riduce precisando scambio dopo scambio. Le funzioni sono meno visibili che in un menu, ma si può chiedere direttamente al sistema che cosa sa fare e come. Iniziare è facile, ma un risultato di qualità richiede obiettivi chiari e una valutazione attenta: sono le competenze che il modulo aiuta a sviluppare.`);
    await card(s, 0.5, 1.2, 5.3, 3.75, { icon: "FiThumbsUp", head: "Opportunità", headSize: 16, bodySize: 14, fill: C.accent6,
      body: bullets(["Accessibilità: basta sapersi esprimere", "Meno barriere tecniche: niente manuali o formule per iniziare", "Flessibilità: anche richieste non previste", "Esplorazione: provare attività nuove", "Si può precisare, come con un collega"], { space: 6 }) });
    await card(s, 6.0, 1.2, 3.5, 3.75, { icon: "FiSliders", head: "Da gestire con il dialogo", headSize: 15, bodySize: 12,
      body: bullets(["Ambiguità: si precisa scambio dopo scambio", "Funzioni poco visibili: chiedere al sistema che cosa sa fare", "Qualità: servono obiettivi chiari e una valutazione attenta"], { space: 6 }) });
  }
  {
    const s = content("Flessibilità e ambiguità del linguaggio", `La flessibilità del linguaggio umano ha un rovescio: l'ambiguità. Tra persone comunichiamo bene perché condividiamo molto contesto implicito: sappiamo chi è l'interlocutore, che cosa sa, a che cosa serve la richiesta. Un sistema AI lavora con il contesto che ha a disposizione: il testo della conversazione e, secondo le funzionalità del sistema, i file allegati, la memoria delle conversazioni precedenti, le istruzioni impostate, i documenti o gli strumenti collegati. Ciò che manca lo completa con le interpretazioni più probabili. Gli esempi in slide sono richieste apparentemente chiare. 'Fammi un riassunto breve del report': breve quanto? Per chi? 'Rendi questa email più professionale': più formale, più sintetica, più tecnica? 'Analizza le vendite': quali aspetti, quale periodo, a quale scopo? In ciascun caso il sistema darà una risposta ragionevole, che potrebbe non essere quella che avevamo in mente. Due conseguenze pratiche. Primo: dare obiettivi e contesto è il modo più semplice per migliorare i risultati, come vedremo nel 5.6. Secondo: l'ambiguità si gestisce con il dialogo, precisando dopo aver visto il primo risultato, come vedremo nel 5.2.`);
    const ex = [["\"Fammi un riassunto breve del report\"", "Quanto breve? Per chi? A che scopo?"], ["\"Rendi questa email più professionale\"", "Più formale? Più sintetica? Più tecnica?"], ["\"Analizza le vendite\"", "Quali aspetti? Quale periodo? Per decidere che cosa?"]];
    ex.forEach((e, i) => {
      const y = 1.2 + i * 0.9;
      shapeBox(s, 0.5, y, 4.5, 0.75, C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 4.2, h: 0.75, fontSize: 14, italic: true, bold: true, color: C.text1, valign: "middle" });
      arrow(s, 5.1, y + 0.22, 0.35, C.accent2);
      shapeBox(s, 5.55, y, 3.95, 0.75, C.accent6, "ambiguità " + i);
      txt(s, e[1], { x: 5.75, y, w: 3.65, h: 0.75, fontSize: 13, color: C.text1, valign: "middle" });
    });
    await miniCard(s, 0.5, 3.95, 4.35, 1.0, "FiUser", "Tra persone: contesto condiviso", "Gran parte delle informazioni resta implicita.");
    await miniCard(s, 5.15, 3.95, 4.35, 1.0, "FiCpu", "Con l'AI: il contesto disponibile", "Conversazione e, secondo il sistema, file, memoria, istruzioni, strumenti.", C.accent6);
  }
  {
    const s = content("Testo, voce e immagini", `L'interazione conversazionale non è solo scritta. Oltre al testo, molti sistemi permettono di interagire con la voce, talvolta in conversazioni fluide quasi in tempo reale, e in modo multimodale, mostrando immagini, documenti, schermate o condividendo la fotocamera. Ogni modalità ha caratteristiche diverse. Il testo si può rileggere e modificare prima di inviare, lascia traccia ed è adatto a richieste articolate. La voce è rapida e naturale, comoda quando si hanno le mani occupate o si è in movimento, ideale per esplorare idee; è più difficile da rileggere e accentua la sensazione di parlare con una persona, un aspetto che riprenderemo nel 5.7. La modalità multimodale permette di mostrare invece di descrivere: una foto di un guasto, un grafico, un modulo da compilare; riduce l'ambiguità quando le parole non bastano, con attenzione a che cosa si condivide, soprattutto in ambito aziendale. Non esiste una modalità migliore in assoluto: la scelta dipende dall'attività, dal flusso di lavoro e dalle capacità dello strumento. Per esempio, si può dettare a voce una bozza o chiedere una revisione parlando, e ricevere comunque un testo scritto da consegnare, se lo strumento lo consente.`);
    const m = [["FiType", "Testo", ["Si rilegge prima di inviare", "Lascia traccia, riutilizzabile", "Adatto a richieste articolate"]], ["FiMic", "Voce", ["Rapida e naturale, a mani libere", "Ideale per esplorare idee", "Accentua la sensazione di parlare con una persona"]], ["FiImage", "Multimodale", ["Mostrare invece di descrivere", "Riduce l'ambiguità", "Attenzione a che cosa si condivide"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.0, { icon: m[i][0], head: m[i][1], headSize: 16, bodySize: 13, fill: i === 0 ? C.accent6 : C.background2, body: bullets(m[i][2], { space: 4 }) });
    banner(s, 4.35, "La modalità si sceglie in base all'attività, al flusso di lavoro e alle capacità dello strumento.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Cambia il rapporto tra utente e software", `L'interfaccia conversazionale cambia il rapporto con il software. Con il software tradizionale l'utente è un operatore: conosce gli strumenti, esegue le operazioni, e il software fa esattamente ciò che gli viene detto. Con un sistema conversazionale l'utente diventa piuttosto un committente: esprime un'intenzione e il contesto, e il sistema propone un percorso o un risultato. Quanto dell'esecuzione resta alla persona dipende dal compito e dal sistema: a volte l'AI suggerisce un passo alla volta e la persona esegue, a volte prepara una bozza completa, a volte, con gli strumenti adatti, svolge un'attività in più passaggi. Questo ha tre conseguenze, riassunte in basso. Le competenze si spostano: meno conoscenza dei comandi, più capacità di definire obiettivi, fornire contesto e valutare. L'esecuzione può andare dal singolo passo all'intera attività, secondo il sistema e le scelte della persona. Il controllo si può esercitare sul processo o sul risultato: si può chiedere al sistema di mostrare i passaggi, oppure concentrarsi sull'esito. Sarà il tema dei livelli di delega, nel 5.5.`);
    await card(s, 0.5, 1.2, 3.6, 2.6, { icon: "FiSettings", head: "Utente operatore", headSize: 16, bodySize: 13, body: "Conosce gli strumenti ed esegue le operazioni. Il software fa esattamente ciò che gli viene detto." });
    arrow(s, 4.25, 2.3, 0.55, C.accent1);
    await card(s, 4.95, 1.2, 4.55, 2.6, { icon: "FiBriefcase", head: "Utente committente", headSize: 16, bodySize: 13, fill: C.accent6, body: "Esprime un'intenzione e il contesto; il sistema propone un percorso o un risultato. La persona sceglie quanto seguire l'esecuzione." });
    const k = ["Intenzione: definire obiettivi, dare contesto", "Esecuzione: dal singolo passo all'intera attività", "Controllo: sul processo o sul risultato, secondo il compito"];
    k.forEach((t, i) => { shapeBox(s, 0.5 + i * 3.07, 4.0, 2.86, 0.95, C.background2, t); txt(s, t, { x: 0.65 + i * 3.07, y: 4.0, w: 2.56, h: 0.95, fontSize: 12, bold: true, color: C.text1, valign: "middle" }); });
  }

  // =====================================================================
  section("5.2 Dalla domanda alla conversazione");
  divider("5.2", "Dalla domanda alla conversazione", "Una buona interazione può svilupparsi in più scambi e non richiede una richiesta iniziale perfetta", `Uno dei modi più comuni di usare un assistente AI è quello del motore di ricerca: si fa una domanda, si legge la risposta, si chiude. Ma un sistema conversazionale dà il meglio quando lo si usa come un dialogo. In questo sottotema, da comprendere bene, vediamo la differenza tra richiesta isolata e conversazione, il dialogo come processo di miglioramento progressivo, un esempio concreto, il contesto della conversazione e la possibilità, spesso trascurata, che sia l'AI a porre domande a noi. Le tecniche operative per formulare e perfezionare le richieste saranno sviluppate nel Tema 6; qui ci interessa il valore del dialogo.`);
  {
    const s = content("Richiesta isolata e dialogo articolato", `Una richiesta isolata è un singolo scambio: domanda, risposta, fine. Funziona bene per bisogni semplici e ben definiti, come una traduzione, una definizione, una formula. Un dialogo articolato è una sequenza di scambi in cui la richiesta si costruisce progressivamente: si parte da un'idea, si guarda il primo risultato, si precisa, si aggiungono informazioni, si chiede un'alternativa, si approfondisce un punto. È adatto ai bisogni complessi, quelli in cui all'inizio non sappiamo ancora esattamente che cosa ci serve. Molte persone usano l'AI solo nel primo modo, e quando il risultato non soddisfa concludono che 'l'AI non funziona per questo'. Spesso il problema è aver interrotto il dialogo troppo presto. Il messaggio è liberatorio: non serve scrivere la richiesta ideale al primo colpo, serve saper proseguire.`);
    await card(s, 0.5, 1.2, 4.35, 2.8, { icon: "FiSearch", head: "Richiesta isolata", headSize: 16, bodySize: 13,
      body: bullets(["Un solo scambio: domanda e risposta", "Adatta a bisogni semplici e definiti", "Esempi: tradurre, definire, una formula"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.8, { icon: "FiMessageSquare", head: "Dialogo articolato", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Più scambi: la richiesta si costruisce", "Adatto a bisogni complessi o ancora sfumati", "Precisare, aggiungere, chiedere alternative"], { space: 4 }) });
    banner(s, 4.2, "Non serve la richiesta perfetta al primo colpo: serve saper proseguire il dialogo.", { h: 0.75 });
  }
  {
    const s = content("Un processo di miglioramento progressivo", `Possiamo descrivere il dialogo come un ciclo di miglioramento. Si formula una richiesta, anche imperfetta. Si valuta il risultato: che cosa va bene, che cosa manca. Si precisa: si aggiungono informazioni, si correggono le interpretazioni, si chiede di cambiare tono, struttura, livello di dettaglio. E si ripete: ogni giro avvicina il risultato a ciò che serve. È lo stesso modo in cui lavoriamo con un collega su un documento: prima bozza, commenti, seconda versione. Un vantaggio meno evidente: ogni iterazione è un momento di apprendimento anche per noi. Vedere un primo risultato aiuta a capire meglio che cosa vogliamo davvero, perché rende esplicite scelte che non avevamo considerato. E se dopo alcuni giri il risultato non migliora, è un'informazione utile: conviene aggiungere ciò che manca, riformulare l'impostazione o ripartire con una richiesta diversa.`);
    const st = [["FiEdit3", "Chiedere", "Anche in modo imperfetto"], ["FiEye", "Valutare", "Che cosa va, che cosa manca"], ["FiSliders", "Precisare", "Informazioni, correzioni, nuove indicazioni"], ["FiTrendingUp", "Migliorare", "Ogni giro avvicina il risultato"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.25, 2.05, 2.2, i === 3 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.4, 0.6, st[i][0]);
      txt(s, st[i][1], { x: x + 0.1, y: 2.1, w: 1.85, h: 0.4, fontSize: 16, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.55, w: 1.75, h: 0.8, fontSize: 12, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.07, 2.2, 0.24);
    }
    await card(s, 0.5, 3.65, 4.35, 1.3, { inline: true, icon: "FiBookOpen", head: "Si impara anche noi", bodySize: 12, body: "Il primo risultato aiuta a capire che cosa vogliamo davvero." });
    await card(s, 5.15, 3.65, 4.35, 1.3, { inline: true, icon: "FiCornerUpRight", head: "Se non migliora, cambiare strada", bodySize: 12, fill: C.accent6, body: "Aggiungere ciò che manca, riformulare o ripartire." });
  }
  {
    const s = content("Un esempio di dialogo", `Ecco un esempio di dialogo progressivo, fittizio e semplificato, con un estratto della risposta dell'AI a ogni passaggio. Una persona deve preparare una comunicazione interna sul nuovo sistema di prenotazione delle sale. Prima richiesta: 'Scrivi una comunicazione sul nuovo sistema di prenotazione delle sale'. Il sistema produce un testo corretto ma generico, lungo e tecnico. Seconda richiesta: la persona precisa il pubblico, tutti i dipendenti, molti non tecnici, e fissa un limite di otto righe. Il testo diventa breve e chiaro, ma manca l'informazione più urgente. Terza richiesta: la persona chiede di aprire con la scadenza, cioè che dal 1° marzo il vecchio sistema non funzionerà. Ora il messaggio è mirato. Quarta: tre possibili oggetti per l'email. In quattro scambi il testo è passato da generico a pronto da rivedere, senza che la prima richiesta fosse perfetta. Due osservazioni: le informazioni decisive, pubblico, lunghezza e scadenza, le ha portate la persona; e il risultato si rilegge prima dell'invio, come qualunque bozza. Suggerimento: se possibile, ripetere un dialogo simile dal vivo con uno strumento aziendale.`);
    const rows = [
      ["Scrivi una comunicazione sul nuovo sistema di prenotazione delle sale.", "«Gentili colleghi, siamo lieti di presentarvi la nuova piattaforma integrata con il calendario aziendale e l'accesso unico...» (25 righe)", "Generica", C.background2, C.text1],
      ["È per tutti i dipendenti, molti non tecnici: massimo 8 righe, tono semplice.", "«Da questo mese le sale si prenotano con una nuova app: scegli sala e orario, poi conferma.»", "Più chiara", C.accent6, C.text1],
      ["Apri con la scadenza: dal 1° marzo il vecchio sistema non funzionerà.", "«Dal 1° marzo il vecchio sistema non sarà più attivo: da oggi prenota le sale con la nuova app...»", "Mirata", C.accent6, C.text1],
      ["Proponi tre oggetti per l'email.", "«Dal 1° marzo cambia la prenotazione delle sale» e altre due proposte", "Pronta da rivedere", C.accent1, C.background1],
    ];
    rows.forEach((r, i) => {
      const y = 1.15 + i * 0.86;
      shapeBox(s, 0.5, y, 3.75, 0.76, C.background2, "richiesta " + (i + 1));
      txt(s, [{ text: "Persona: ", options: { bold: true, color: C.text1 } }, { text: r[0], options: { color: C.text1 } }], { x: 0.62, y, w: 3.55, h: 0.76, fontSize: 11, valign: "middle" });
      arrow(s, 4.3, y + 0.22, 0.25, C.accent2);
      shapeBox(s, 4.6, y, 3.6, 0.76, C.accent6, "risposta " + (i + 1));
      txt(s, [{ text: "AI: ", options: { bold: true, color: C.accent1 } }, { text: r[1], options: { italic: true, color: C.text1 } }], { x: 4.72, y, w: 3.4, h: 0.76, fontSize: 11, valign: "middle" });
      chip(s, 8.3, y + 0.13, 1.2, 0.5, r[2], { fill: r[3], color: r[4], fontSize: 11 });
    });
    banner(s, 4.62, "In quattro scambi, da un testo generico a un messaggio pronto da rivedere: pubblico e scadenza li ha portati la persona.", { h: 0.45, fontSize: 12 });
  }
  {
    const s = content("Il contesto della conversazione", `Durante un dialogo si accumulano informazioni: il pubblico, l'obiettivo, i vincoli, le correzioni, le preferenze espresse. Questo contesto è una risorsa: non serve ripetere tutto a ogni richiesta, perché il sistema tiene conto di ciò che è già stato detto, come abbiamo visto nel Tema 2. Quanto contesto è disponibile dipende dal sistema: alcuni strumenti conservano una memoria tra le conversazioni, permettono di organizzare il lavoro in progetti con documenti e istruzioni permanenti, o collegano file e applicazioni aziendali. Ci sono situazioni in cui il contesto può diventare un ostacolo: quando si cambia argomento e le impostazioni del compito precedente influenzano quello nuovo; quando la conversazione è molto lunga e le informazioni iniziali possono perdere peso; quando all'inizio si è presa una strada sbagliata che continua a condizionare le risposte. In questi casi una strategia utile è aprire una nuova conversazione, riportando in sintesi ciò che serve; si può anche chiedere all'AI stessa di preparare quella sintesi. Non è una regola universale: con conversazioni ben organizzate, o con strumenti che gestiscono il contesto in modo strutturato, si può proseguire a lungo nello stesso dialogo.`);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiLayers", head: "Una risorsa", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Pubblico, obiettivi, vincoli, correzioni restano nel dialogo", "Non serve ripetere tutto", "Il quadro si precisa scambio dopo scambio"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiAlertCircle", head: "Quando può ostacolare", headSize: 16, bodySize: 13,
      body: bullets(["Si cambia argomento", "La conversazione è molto lunga", "All'inizio si è presa una strada sbagliata"], { space: 3 }) });
    banner(s, 3.8, "Una strategia utile: nuova conversazione con una sintesi di ciò che serve, anche preparata dall'AI.", { h: 0.6 });
    txt(s, "Il contesto disponibile dipende dal sistema: memoria, progetti, file e istruzioni permanenti variano da strumento a strumento.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("L'AI come interlocutore che può porre domande", `Una possibilità spesso trascurata: non siamo solo noi a fare domande. Possiamo chiedere al sistema di porci domande prima di procedere. Per esempio: 'Devo preparare un piano di formazione per i nuovi assunti. Prima di proporre qualcosa, fammi le domande che ti servono per capire bene la situazione'. Il sistema chiederà, plausibilmente, quante persone, quali ruoli, quanto tempo, quali competenze di partenza, quale budget. Rispondere a queste domande ci porta a esplicitare assunzioni che davamo per scontate e a scoprire informazioni che non avevamo considerato. Alcuni sistemi pongono domande di chiarimento anche spontaneamente, quando la richiesta è ambigua. Il valore è triplice: chiarire le esigenze, esplicitare le assunzioni, individuare le informazioni mancanti. Il risultato parte così da basi più solide, e spesso arriva prima. Le risposte, e quindi le scelte, restano della persona, che conosce la situazione reale.`);
    dialog(s, 0.5, 1.2, 5.4, [["P", "Devo preparare un piano di formazione per i nuovi assunti. Prima di proporre, fammi le domande che ti servono.", 0.75], ["A", "Quante persone? Quali ruoli? Quanto tempo? Competenze di partenza? Budget?", 0.75]], { gap: 0.15 });
    const v = [["FiHelpCircle", "Chiarire le esigenze"], ["FiEye", "Esplicitare le assunzioni"], ["FiSearch", "Individuare informazioni mancanti"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.2 + i * 0.75;
      await iconCircle(s, 6.2, y, 0.5, v[i][0]);
      txt(s, v[i][1], { x: 6.85, y, w: 2.65, h: 0.5, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
    }
    shapeBox(s, 0.5, 3.35, 9.0, 1.6, C.text1, "valore delle domande");
    await iconCircle(s, 0.75, 3.8, 0.65, "FiZap", C.accent1);
    txt(s, [{ text: "Domande migliori, risultati migliori. ", options: { bold: true, color: C.background1 } }, { text: "Rispondere alle domande dell'AI fa emergere ciò che sappiamo e non avevamo detto: il risultato parte da basi più solide.", options: { color: C.accent3 } }], { x: 1.6, y: 3.35, w: 7.7, h: 1.6, fontSize: 15, valign: "middle" });
  }
  {
    const s = content("L'AI come supporto alla definizione dei problemi", `Spesso la parte più difficile di un'attività non è risolvere il problema, ma capire qual è il problema. Qui l'AI offre un beneficio professionale concreto: prima di investire tempo in una soluzione, aiuta a individuare le possibili cause, i vincoli, le alternative e le informazioni mancanti. Alcuni modi di usarla: chiedere quali potrebbero essere le cause di una situazione, prima di cercare soluzioni; chiedere di esplicitare vincoli e obiettivi che potrebbero essere in conflitto; chiedere alternative da confrontare; chiedere quali dati servirebbero per decidere; chiedere di distinguere tra sintomi e problema. Per esempio, prima di chiedere 'come riduco i reclami dei clienti?', si può chiedere 'aiutami a capire quali problemi potrebbero esserci dietro l'aumento dei reclami e quali dati mi servirebbero per distinguerli'. Il beneficio è evitare di risolvere il problema sbagliato: si arriva alla soluzione con le domande e i dati giusti. La conversazione diventa uno strumento per pensare meglio, non solo per ottenere risposte.`);
    const u = [["FiGitBranch", "Esplorare le possibili cause prima delle soluzioni"], ["FiShuffle", "Esplicitare vincoli e obiettivi in conflitto"], ["FiLayers", "Generare alternative da confrontare"], ["FiDatabase", "Individuare le informazioni mancanti"], ["FiFilter", "Distinguere sintomi e problema"]];
    for (let i = 0; i < 5; i++) {
      const y = 1.15 + i * 0.62;
      shapeBox(s, 0.5, y, 4.6, 0.54, i % 2 ? C.background1 : C.background2, u[i][1]);
      await iconCircle(s, 0.6, y + 0.06, 0.42, u[i][0]);
      txt(s, u[i][1], { x: 1.15, y, w: 3.9, h: 0.54, fontSize: 12, color: C.text1, valign: "middle" });
    }
    await card(s, 5.4, 1.15, 4.1, 2.0, { head: "Esempio", headSize: 14, bodySize: 12, fill: C.accent6,
      body: [{ text: "Invece di: ", options: { bold: true, color: C.text2 } }, { text: "\"Come riduco i reclami dei clienti?\"", options: { italic: true, breakLine: true, paraSpaceAfter: 6 } }, { text: "Prima: ", options: { bold: true, color: C.accent1 } }, { text: "\"Aiutami a capire quali problemi potrebbero esserci dietro l'aumento dei reclami e quali dati mi servirebbero per distinguerli.\"", options: { italic: true } }] });
    await miniCard(s, 5.4, 3.3, 4.1, 0.87, "FiTarget", "Il beneficio", "Lavorare sul problema giusto, con le domande e i dati giusti.");
    txt(s, "La conversazione come strumento per pensare meglio, non solo per ottenere risposte.", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.text1 });
  }

  // =====================================================================
  section("5.3 I ruoli dell'AI");
  divider("5.3", "I diversi ruoli che l'AI può assumere", "Scegliere il ruolo giusto moltiplica il valore dell'AI; assegnare un ruolo orienta le risposte, ma non crea competenze nuove", `Uno stesso assistente AI può essere usato in modi molto diversi: come fonte di spiegazioni, come assistente operativo, come compagno di brainstorming, come analista, come revisore, come tutor, come interlocutore critico. In questo sottotema passiamo in rassegna questi ruoli con un esempio, il beneficio principale e il punto di attenzione di ciascuno; vediamo un esempio di AI come partner di ragionamento su una decisione aziendale; e chiariamo la differenza tra il ruolo che assegniamo al sistema e le competenze su cui può davvero contare. Non confrontiamo prodotti o architetture, che sono temi del Tema 4.`);
  {
    const s = content("Sette ruoli possibili", `Ecco i sette ruoli. Fonte di informazioni e spiegazioni: spiegare un concetto, chiarire un termine, dare una panoramica. Assistente operativo: scrivere bozze, riformulare, tradurre, organizzare informazioni. Supporto creativo e al brainstorming: generare idee, alternative, nomi, spunti. Analista e supporto al problem solving: analizzare dati e documenti, scomporre problemi, confrontare opzioni. Revisore di contenuti e risultati: rileggere un testo, segnalare errori, incoerenze, punti deboli. Tutor e supporto all'apprendimento: spiegare passo passo, proporre esercizi, adattarsi al livello della persona. Interlocutore critico: proporre controargomentazioni, alternative, obiezioni. Molte interazioni combinano più ruoli, e passare consapevolmente da un ruolo all'altro è una delle abilità di chi usa bene l'AI. Suggerimento: chiedere ai partecipanti quali ruoli usano già e quali non avevano considerato.`);
    const r = [["FiBookOpen", "Fonte di informazioni"], ["FiBriefcase", "Assistente operativo"], ["FiZap", "Supporto creativo"], ["FiBarChart2", "Analista"], ["FiCheckSquare", "Revisore"], ["FiAward", "Tutor"], ["FiMessageCircle", "Interlocutore critico"]];
    for (let i = 0; i < 7; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = row === 0 ? 0.5 + col * 2.3 : 1.65 + col * 2.3, y = 1.2 + row * 1.7;
      shapeBox(s, x, y, 2.15, 1.5, i === 6 ? C.accent1 : C.background2, r[i][1]);
      await iconCircle(s, x + 0.78, y + 0.18, 0.6, r[i][0], i === 6 ? C.background1 : C.accent1, i === 6 ? HEX.a1 : HEX.lt1);
      txt(s, r[i][1], { x: x + 0.1, y: y + 0.88, w: 1.95, h: 0.5, fontSize: 14, bold: true, color: i === 6 ? C.background1 : C.text1, align: "center", valign: "middle" });
    }
    txt(s, "Molte interazioni combinano più ruoli: saper passare dall'uno all'altro è un'abilità.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Fonte, assistente operativo, supporto creativo", `Vediamo i primi tre ruoli con la stessa struttura: esempio, beneficio, punto di attenzione. Come fonte di informazioni e spiegazioni, l'AI aiuta a orientarsi in pochi minuti su un argomento nuovo: 'Spiegami in termini semplici che cos'è il bilancio di sostenibilità'. Il punto di attenzione: per fatti, dati e riferimenti precisi conviene appoggiarsi a fonti verificabili; alcuni strumenti citano le fonti o cercano sul web, e questo facilita il controllo. Come assistente operativo, l'AI svolge compiti concreti: 'Trasforma questi appunti in un verbale ordinato'. È spesso il ruolo più immediatamente utile, perché restituisce tempo sulle attività ripetitive. L'attenzione: il risultato è una bozza da rileggere prima di condividerla. Come supporto creativo, l'AI genera in pochi secondi molte alternative da cui partire: 'Proponi dieci idee per un evento interno con budget contenuto'. L'attenzione: le idee migliori vanno selezionate e sviluppate, meglio se insieme ad altre persone.`);
    const r = [["FiBookOpen", "Fonte di informazioni", "\"Spiegami in termini semplici che cos'è il bilancio di sostenibilità.\"", "Orientarsi in pochi minuti su un tema nuovo", "Per dati e riferimenti precisi, fonti verificabili"], ["FiBriefcase", "Assistente operativo", "\"Trasforma questi appunti in un verbale ordinato.\"", "Tempo recuperato sulle attività ripetitive", "È una bozza: rileggerla prima di condividerla"], ["FiZap", "Supporto creativo", "\"Proponi dieci idee per un evento interno con budget contenuto.\"", "Molte alternative da cui partire, in poco tempo", "Selezionare e sviluppare le idee migliori"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.2, 2.86, 3.75, { icon: r[i][0], head: r[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: roleBody(r[i][2], r[i][3], r[i][4]) });
    }
  }
  {
    const s = content("Analista, revisore, tutor", `Altri tre ruoli, con la stessa struttura. Come analista, l'AI aiuta a esaminare dati e documenti, a scomporre problemi, a confrontare opzioni: 'Confronta questi tre contratti sulle clausole di recesso'. Il beneficio è la rapidità nel confronto di documenti lunghi; l'attenzione è controllare i punti decisivi sul testo originale, perché le conclusioni dipendono dalle informazioni fornite e dai criteri usati. Come revisore, l'AI rilegge un contenuto e segnala errori, incoerenze, punti poco chiari: 'Rileggi questa offerta e segnala i passaggi ambigui o in contraddizione'. Il beneficio è uno sguardo esterno sempre disponibile, che vede ciò che chi scrive non vede più; l'attenzione è che la revisione non è esaustiva: può non accorgersi di alcuni errori o segnalarne di inesistenti. Come tutor, l'AI spiega passo passo, adatta il livello, propone esercizi: 'Insegnami le basi delle tabelle pivot con esempi graduali'. Il beneficio è imparare al proprio ritmo; l'attenzione è esercitarsi in prima persona, perché si impara davvero facendo.`);
    const r = [["FiBarChart2", "Analista", "\"Confronta questi tre contratti sulle clausole di recesso.\"", "Confronti rapidi su documenti lunghi", "Controllare i punti decisivi sul testo originale"], ["FiCheckSquare", "Revisore", "\"Rileggi questa offerta e segnala passaggi ambigui o in contraddizione.\"", "Uno sguardo esterno, sempre disponibile", "La revisione non è esaustiva"], ["FiAward", "Tutor", "\"Insegnami le basi delle tabelle pivot con esempi graduali.\"", "Imparare al proprio ritmo e livello", "Esercitarsi in prima persona per imparare davvero"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.2, 2.86, 3.75, { icon: r[i][0], head: r[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: roleBody(r[i][2], r[i][3], r[i][4]) });
    }
  }
  {
    const s = content("L'AI come strumento di confronto critico", `Questo è uno degli usi più preziosi e meno praticati. Come abbiamo visto nel Tema 3, i sistemi AI tendono ad assecondare l'utente. Ma possiamo chiedere esplicitamente il contrario: usare l'AI per mettere alla prova idee, progetti e decisioni prima di presentarli. Nella colonna di sinistra, i modi per mettere alla prova un'idea. L'avvocato del diavolo: 'costruisci gli argomenti più forti contro la mia proposta'. Il pre-mortem: 'immagina che il progetto sia fallito tra un anno: quali sono le cause più probabili?'. Le prospettive diverse: 'come la valuterebbero un cliente, un fornitore, l'amministrazione?'. Le assunzioni nascoste: 'che cosa sto dando per scontato?'. Nella colonna di destra, i modi per strutturare una valutazione: chiedere alternative per lo stesso obiettivo; chiedere i criteri che potrebbero essere rilevanti, per non dimenticarne qualcuno; confrontare le opzioni secondo quei criteri, evidenziando i compromessi; chiedere quali informazioni potrebbero cambiare la valutazione. Le persone tendono a considerare le opzioni che vengono in mente per prime e a cercare conferme; un interlocutore che propone sistematicamente criteri, alternative e obiezioni aiuta a contrastare queste tendenze. Le critiche dell'AI vanno a loro volta valutate: non tutte saranno pertinenti. Il valore sta nello stimolo al ragionamento, e il beneficio si vede nella solidità della decisione.`);
    const r = [["FiShield", "Avvocato del diavolo", "\"Costruisci gli argomenti più forti contro la mia proposta.\""], ["FiAlertTriangle", "Pre-mortem", "\"Il progetto è fallito: quali le cause più probabili?\""], ["FiUsers", "Prospettive diverse", "\"Come la valuterebbero un cliente, un fornitore?\""], ["FiEye", "Assunzioni nascoste", "\"Che cosa sto dando per scontato?\""], ["FiShuffle", "Alternative", "\"Quali altre strade per lo stesso obiettivo?\""], ["FiList", "Criteri dimenticati", "\"Quali criteri potrebbero essere rilevanti?\""], ["FiSliders", "Compromessi", "\"Confronta le opzioni secondo questi criteri.\""], ["FiInfo", "Informazioni decisive", "\"Che cosa potrebbe cambiare la valutazione?\""]];
    for (let i = 0; i < 8; i++) {
      const col = Math.floor(i / 4), row = i % 4;
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.8;
      shapeBox(s, x, y, 4.4, 0.72, row % 2 ? C.background1 : C.background2, r[i][1]);
      await iconCircle(s, x + 0.1, y + 0.14, 0.44, r[i][0]);
      txt(s, r[i][1], { x: x + 0.65, y: y + 0.05, w: 3.65, h: 0.3, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, r[i][2], { x: x + 0.65, y: y + 0.36, w: 3.65, h: 0.3, fontSize: 11, italic: true, color: C.text2, valign: "middle" });
    }
    banner(s, 4.4, "Mettere alla prova idee e decisioni prima di presentarle: le obiezioni dell'AI sono uno stimolo da valutare.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("L'AI come partner di ragionamento", `Ecco un esempio fittizio di AI come partner di ragionamento su una decisione aziendale. Una piccola azienda sta valutando se aprire una filiale commerciale a Milano o potenziare le vendite online. Invece di chiedere 'che cosa mi conviene fare?', la persona chiede all'AI di aiutarla a ragionare prima di decidere. In pochi scambi emerge un quadro più ricco. Alternative: oltre alle due opzioni iniziali, un partner commerciale locale o un test di sei mesi con un agente, che permette di raccogliere dati prima di investire. Criteri: investimento e costi fissi, tempo per i primi risultati, vicinanza ai clienti chiave, reversibilità della scelta. Rischi: costi fissi senza volumi sufficienti, canali che si fanno concorrenza, dati di mercato incompleti. Opportunità: nuovi clienti, un test a basso costo, dati per decidere il passo successivo. La persona sceglie quali criteri contano davvero, aggiunge i dati reali dell'azienda e decide. Il risultato è una decisione meglio informata, che si può anche argomentare più facilmente con la direzione. Suggerimento: chiedere ai partecipanti una decisione reale su cui proverebbero lo stesso approccio.`);
    shapeBox(s, 0.5, 1.12, 9.0, 0.62, C.background2, "richiesta decisione");
    txt(s, [{ text: "Persona: ", options: { bold: true, color: C.text1 } }, { text: "Valutiamo se aprire una filiale a Milano o potenziare le vendite online. Aiutami a ragionare prima di decidere.", options: { color: C.text1 } }], { x: 0.7, y: 1.12, w: 8.6, h: 0.62, fontSize: 13, valign: "middle" });
    const q = [["FiShuffle", "Alternative", ["Filiale a Milano", "Potenziare l'online", "Partner locale", "Test di sei mesi con un agente"]], ["FiList", "Criteri", ["Investimento e costi fissi", "Tempo per i risultati", "Vicinanza ai clienti", "Reversibilità"]], ["FiAlertTriangle", "Rischi", ["Costi fissi senza volumi", "Canali in concorrenza", "Dati di mercato incompleti"]], ["FiSun", "Opportunità", ["Nuovi clienti", "Test a basso costo", "Dati per il passo successivo"]]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.9, 2.15, 2.15, i === 3 ? C.accent6 : C.background2, q[i][1]);
      await iconCircle(s, x + 0.15, 2.02, 0.45, q[i][0], i === 2 ? HEX.a4 : C.accent1);
      txt(s, q[i][1], { x: x + 0.7, y: 2.02, w: 1.4, h: 0.45, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, bullets(q[i][2], { space: 3 }), { x: x + 0.15, y: 2.6, w: 1.9, h: 1.4, fontSize: 11, color: C.text2 });
    }
    shapeBox(s, 0.5, 4.2, 9.0, 0.78, C.text1, "ruolo della persona");
    txt(s, [{ text: "La persona sceglie i criteri che contano, aggiunge i dati reali e decide. ", options: { bold: true, color: C.background1 } }, { text: "Risultato: una decisione meglio informata e argomentata.", options: { color: C.accent3 } }], { x: 0.7, y: 4.2, w: 7.6, h: 0.78, fontSize: 13, valign: "middle" });
    txt(s, "Esempio fittizio", { x: 8.2, y: 4.2, w: 1.2, h: 0.78, fontSize: 10, italic: true, color: C.accent2, align: "right", valign: "middle" });
  }
  {
    const s = content("Ruolo assegnato e competenza effettiva", `Una pratica molto diffusa è assegnare un ruolo all'AI: 'Sei un esperto di diritto del lavoro', 'Agisci come un revisore severo'. Funziona? In buona parte sì: il ruolo orienta il comportamento del sistema, cioè tono, lessico, livello di dettaglio, prospettiva, aspetti a cui presta attenzione, e questo spesso rende le risposte più pertinenti e utili. Lo riprenderemo nel Tema 6. Ma c'è una distinzione da tenere presente: assegnare un ruolo non crea competenze che il modello non ha, non garantisce l'accuratezza, non attribuisce responsabilità professionale. Dire al sistema che è un avvocato orienta la risposta verso le questioni giuridiche rilevanti, ma non aggiunge conoscenze aggiornate sulla normativa né la capacità di valutare il caso concreto. L'accuratezza dipende da altro: dal modello, dalle informazioni e dalle fonti a cui il sistema può accedere, per esempio documenti forniti o ricerche sul web, e dal controllo di chi usa il risultato. Il rischio da evitare è che lo stile professionale aumenti la fiducia più di quanto giustificato. Quando le conseguenze sono rilevanti, il ruolo assegnato è un ottimo punto di partenza per prepararsi, non un sostituto del parere di un professionista.`);
    await card(s, 0.5, 1.2, 4.35, 2.9, { icon: "FiCheckCircle", head: "Il ruolo orienta", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Tono e lessico", "Livello di dettaglio", "Prospettiva e aspetti considerati", "Risposte più pertinenti"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.9, { icon: "FiInfo", head: "Il ruolo non aggiunge", headSize: 16, bodySize: 13, iconBg: HEX.a4,
      body: bullets(["Conoscenze che il modello non ha", "Garanzie di accuratezza", "Responsabilità professionale"], { space: 4 }) });
    banner(s, 4.3, "Il ruolo migliora l'orientamento della risposta; l'accuratezza dipende da modello, fonti disponibili e controllo.", { h: 0.65, fontSize: 13 });
  }

  // =====================================================================
  section("5.4 La collaborazione uomo-AI");
  divider("5.4", "La collaborazione uomo-AI", "Il valore nasce dalla combinazione delle capacità del sistema con le competenze e il contesto della persona", `Un sottotema da comprendere bene. Dopo aver visto i ruoli possibili, analizziamo il processo: che cosa distingue l'ottenere una risposta dal collaborare, un esempio concreto di collaborazione, come si suddividono le fasi di un'attività tra persona e sistema, e il ciclo di produzione e revisione. Non anticipiamo la riprogettazione dei processi e dei ruoli organizzativi, trattata nei Temi 13 e 16: qui parliamo della collaborazione nel lavoro della singola persona.`);
  {
    const s = content("Ottenere una risposta o collaborare", `C'è una differenza sostanziale tra ottenere una risposta e collaborare a un'attività. Nel primo caso si chiede, si riceve, si usa: l'AI è un fornitore di risultati. Nel secondo si lavora insieme su un obiettivo, in più passaggi, ciascuno con ciò che sa fare meglio: la persona porta obiettivi, contesto e competenza di dominio; il sistema porta velocità, ampiezza, capacità di generare alternative, organizzare e sintetizzare grandi quantità di informazioni. Il risultato è spesso migliore di ciò che ciascuno avrebbe ottenuto da solo. Due modi di affrontare lo stesso compito, un'analisi dei feedback dei clienti. Modalità 'risposta': si incollano i feedback, si chiede 'analizzali', si copia il risultato. Modalità 'collaborazione': la persona definisce le domande a cui l'analisi deve rispondere, il sistema propone una classificazione, la persona la corregge con la sua conoscenza dei prodotti, il sistema conta e sintetizza, la persona verifica alcuni casi e trae le conclusioni. Il valore aggiunto è visibile nella riga in basso: il primo risultato è utile come punto di partenza, il secondo è pertinente, verificato nei punti chiave e padroneggiato da chi lo presenterà. Richiede qualche minuto in più, ma restituisce molto di più.`);
    await card(s, 0.5, 1.2, 4.35, 2.85, { inline: true, icon: "FiDownload", head: "Ottenere una risposta", bodySize: 12,
      body: [{ text: "L'AI fornisce un risultato", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Esempio: ", options: { bold: true, color: C.accent2 } }, { text: "si incollano i feedback dei clienti, si chiede \"analizzali\", si copia il risultato.", options: {} }] });
    await card(s, 5.15, 1.2, 4.35, 2.85, { inline: true, icon: "FiUsers", head: "Collaborare", bodySize: 12, fill: C.accent6,
      body: [{ text: "Si lavora insieme, ognuno con ciò che sa fare meglio", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }].concat(bullets(["La persona definisce le domande", "L'AI propone una classificazione", "La persona la corregge con la sua conoscenza", "L'AI conta e sintetizza", "La persona verifica e conclude"], { space: 2 })) });
    shapeBox(s, 0.5, 4.2, 4.35, 0.75, C.background2, "risultato risposta");
    txt(s, [{ text: "Risultato: ", options: { bold: true } }, { text: "un punto di partenza, generico e da controllare per intero" }], { x: 0.7, y: 4.2, w: 4.0, h: 0.75, fontSize: 12, color: C.text1, valign: "middle" });
    shapeBox(s, 5.15, 4.2, 4.35, 0.75, C.accent1, "risultato collaborazione");
    txt(s, [{ text: "Risultato: ", options: { bold: true } }, { text: "pertinente, verificato nei punti chiave, padroneggiato" }], { x: 5.35, y: 4.2, w: 4.0, h: 0.75, fontSize: 12, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Da richiesta generica a collaborazione efficace", `Un caso professionale fittizio in quattro passaggi: rispondere al reclamo di un cliente per un ritardo di consegna. Primo passaggio, la richiesta iniziale: la persona incolla l'email del cliente e chiede 'scrivi una risposta a questo reclamo'. Secondo passaggio, la prima proposta dell'AI: una risposta cortese e ben scritta, ma generica, con scuse di rito e nessuna soluzione concreta. Notate che l'AI, oltre a proporre, chiede le informazioni che le mancano: quale soluzione potete offrire? che tipo di cliente è? Terzo passaggio, il chiarimento della persona: il cliente è storico, il ritardo è stato causato da un fornitore, l'azienda può offrire la spedizione prioritaria gratuita sul prossimo ordine; il tono deve essere diretto, senza formule di rito. Quarto passaggio, il risultato migliorato: una risposta specifica che riconosce il disagio, spiega la causa in una riga, propone la soluzione e indica un referente. La persona controlla che le condizioni offerte siano corrette e la invia. La barra mostra il progresso della qualità. Il salto non nasce da una formula magica, ma dalla combinazione di due contributi: le domande dell'AI e il contesto che solo la persona conosce.`);
    const st = [["1", "Richiesta iniziale", "«Scrivi una risposta a questo reclamo.» Allegata l'email del cliente sul ritardo di consegna.", C.background2, C.text1, 0.25], ["2", "Prima proposta dell'AI", "Risposta cortese ma generica: scuse di rito, nessuna soluzione. L'AI chiede: «Quale soluzione potete offrire? Che cliente è?»", C.accent6, C.text1, 0.45], ["3", "Chiarimento della persona", "«Cliente storico; ritardo causato da un fornitore; offriamo la spedizione prioritaria gratuita sul prossimo ordine. Tono diretto.»", C.background2, C.text1, 0.65], ["4", "Risultato migliorato", "Risposta specifica: riconosce il disagio, spiega la causa in una riga, propone la soluzione e un referente. La persona controlla e invia.", C.accent1, C.background1, 1.0]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.75, st[i][3], "passaggio " + st[i][0]);
      txt(s, st[i][0], { x: x + 0.15, y: 1.25, w: 0.45, h: 0.45, fontSize: 22, bold: true, color: i === 3 ? C.background1 : C.accent1 });
      txt(s, st[i][1], { x: x + 0.6, y: 1.25, w: 1.45, h: 0.5, fontSize: 12, bold: true, color: st[i][4], valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 1.85, w: 1.88, h: 1.95, fontSize: 11, color: st[i][4] });
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 4.0, w: 2.15, h: 0.16, rectRadius: 0.08, fill: { color: C.background2 }, line: { type: "none" }, objectName: "barra base " + st[i][0] });
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 4.0, w: 2.15 * st[i][5], h: 0.16, rectRadius: 0.08, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "barra qualità " + st[i][0] });
    }
    banner(s, 4.32, "Il salto di qualità nasce da due contributi: le domande dell'AI e il contesto che solo la persona conosce.", { h: 0.63, fontSize: 13 });
  }
  {
    const s = content("Suddividere le attività tra persona e sistema", `Collaborare significa anche decidere chi fa che cosa. Possiamo scomporre una tipica attività intellettuale in fasi e chiederci, per ciascuna, quale contributo può dare l'AI e quale porta la persona. La tabella propone un esempio indicativo. Definire obiettivo e criteri: decide la persona; l'AI aiuta con domande, esempi e criteri possibili. Raccogliere e organizzare le informazioni: l'AI è un supporto efficace; la persona sceglie le fonti e ne verifica la pertinenza. Produrre una prima versione: qui l'AI dà spesso il contributo maggiore, sulla base delle indicazioni e del contesto della persona. Rivedere e migliorare: lavoro congiunto, con l'AI come revisore e interlocutore critico e la persona che decide quali modifiche accettare. Validare e decidere l'uso: anche qui l'AI può contribuire, con controlli di coerenza, confronti con le fonti, verifiche di completezza rispetto ai requisiti; la decisione sull'uso spetta alla persona, e responsabilità e autorizzazioni seguono i ruoli e i processi dell'organizzazione. Il filo che attraversa tutte le fasi è la competenza della persona: senza conoscenza del dominio non si sa che cosa chiedere, non si riconoscono gli errori, non si sa quali suggerimenti accettare; e il contesto, cioè obiettivi, vincoli, pubblico e storia, il sistema lo conosce solo se la persona lo porta o lo rende disponibile. Le procedure di verifica degli output sono oggetto del Tema 7.`);
    table(s, [["Fase", "Contributo dell'AI", "Contributo della persona"], ["Definire obiettivo e criteri", "Domande, esempi, criteri possibili", "Decide obiettivi e criteri"], ["Raccogliere e organizzare", "Supporto efficace", "Sceglie le fonti, verifica la pertinenza"], ["Produrre una prima versione", "Spesso il contributo maggiore", "Fornisce indicazioni e contesto"], ["Rivedere e migliorare", "Revisore e interlocutore critico", "Decide quali modifiche accettare"], ["Validare e decidere l'uso", "Controlli, confronti, verifiche di coerenza", "Decide; responsabilità secondo ruoli e processi"]], { colW: [2.6, 3.1, 3.3], rowH: 0.5, accentCol: 2, blankCorner: false, fontSize: 12 });
    banner(s, 4.5, "L'AI può contribuire a ogni fase; competenze e contesto della persona orientano tutto il lavoro.", { h: 0.48, fontSize: 13 });
  }
  {
    const s = content("Produrre, rivedere, migliorare", `Uno dei modi più comuni di collaborare con l'AI riguarda i contenuti: testi, presentazioni, analisi, piani. Possiamo vederlo come un ciclo in cui persona e sistema si alternano. La persona imposta: obiettivo, pubblico, punti chiave, materiali. L'AI produce una prima versione. La persona valuta e commenta: che cosa funziona, che cosa manca, che cosa è sbagliato. L'AI rivede secondo le indicazioni, oppure propone a sua volta osservazioni critiche, nel ruolo di revisore. La persona decide, rifinisce e valida. Il ciclo può anche partire dalla persona: si scrive una propria bozza e si chiede all'AI di rivederla, migliorarla o metterla alla prova. Questo secondo modo ha un vantaggio importante: il pensiero di partenza è della persona, e l'AI lo arricchisce. È spesso la scelta migliore quando il contenuto deve esprimere una posizione personale o una competenza specifica, o quando conta sviluppare le proprie capacità, come vedremo nel 5.7.`);
    const st = [["Persona", "Imposta obiettivo, pubblico, punti chiave", C.background2, C.text1], ["AI", "Produce una prima versione", C.accent6, C.text1], ["Persona", "Valuta e commenta", C.background2, C.text1], ["AI", "Rivede o propone osservazioni critiche", C.accent6, C.text1], ["Persona", "Decide, rifinisce, valida", C.accent1, C.background1]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.3, 1.68, 1.9, st[i][2], "fase " + i);
      txt(s, st[i][0], { x: x + 0.1, y: 1.4, w: 1.48, h: 0.4, fontSize: 15, bold: true, color: i === 4 ? C.background1 : C.accent1, align: "center" });
      txt(s, st[i][1], { x: x + 0.12, y: 1.85, w: 1.44, h: 1.25, fontSize: 12, color: st[i][3], align: "center" });
    }
    await card(s, 0.5, 3.45, 9.0, 1.5, { inline: true, icon: "FiEdit", head: "Si può partire anche dalla persona", bodySize: 13, fill: C.background2, body: "Scrivere una propria bozza e chiedere all'AI di rivederla o metterla alla prova: il pensiero di partenza resta nostro e l'AI lo arricchisce." });
  }

  // =====================================================================
  section("5.5 Livelli di delega");
  divider("5.5", "I livelli di delega all'Intelligenza Artificiale", "Il livello di delega si sceglie in base al compito, alle capacità del sistema, ai rischi e ai controlli disponibili", `Un sottotema da comprendere bene, il cui obiettivo è la consapevolezza decisionale. Nel 5.4 abbiamo parlato della distribuzione del lavoro; qui parliamo del grado di autonomia che affidiamo al sistema. Proponiamo una scala di livelli di delega, dal semplice uso informativo all'esecuzione con maggiore autonomia, e vediamo come scegliere il livello adatto, con un esempio su tre attività. Una nota didattica importante: i livelli sono una classificazione illustrativa, non uno standard tecnico, e non sono una progressione obbligatoria. Non bisogna arrivare all'ultimo livello: bisogna scegliere quello adatto, e salire quando le condizioni lo permettono. La progettazione di agenti e workflow sarà trattata nel Tema 11.`);
  {
    const s = content("Cinque livelli di delega", `Ecco i cinque livelli. Primo, l'AI come strumento informativo: fornisce informazioni e spiegazioni, la persona le usa come vuole. Secondo, l'AI come supporto e suggeritore: propone idee, opzioni, correzioni; la persona sceglie e realizza. Terzo, l'AI come collaboratore: produce parti significative del risultato, come bozze o analisi, che la persona rivede, integra e valida. Quarto, la delega con supervisione: l'AI svolge un'attività per intero e la persona controlla il risultato prima dell'uso. Quinto, l'autonomia entro vincoli: l'AI svolge attività, anche in più passaggi e con azioni concrete, entro limiti e autorizzazioni definiti; la persona stabilisce i vincoli, monitora e interviene sulle eccezioni. La fascia in basso collega i livelli a quattro termini che spesso si confondono. Assistenza: l'AI aiuta in un'attività che resta della persona, livelli 1 e 2. Collaborazione: contributi alternati allo stesso risultato, livello 3. Delega: l'AI svolge un'attività intera, livelli 4 e 5. Automazione: il livello 5 applicato in modo sistematico e ricorrente, senza intervento caso per caso, secondo regole definite in anticipo. Cambia non solo quanto lavoro svolge l'AI, ma dove si colloca la persona: dentro l'attività, accanto, sopra, a monte nella definizione delle regole. Ripetiamo la nota didattica: è una classificazione illustrativa, non uno standard tecnico, e non una scala di maturità.`);
    const lv = [["1", "Strumento informativo", "Fornisce informazioni e spiegazioni"], ["2", "Supporto e suggeritore", "Propone; la persona sceglie e realizza"], ["3", "Collaboratore", "Produce parti del risultato; la persona rivede e valida"], ["4", "Delega con supervisione", "Svolge l'attività; la persona controlla prima dell'uso"], ["5", "Autonomia entro vincoli", "Agisce entro limiti; la persona monitora e gestisce le eccezioni"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84, h = 1.6 + i * 0.35, y = 4.2 - h;
      shapeBox(s, x, y, 1.68, h, i === 4 ? C.accent1 : (i >= 2 ? C.accent6 : C.background2), "livello " + lv[i][0]);
      txt(s, lv[i][0], { x: x + 0.12, y: y + 0.08, w: 0.6, h: 0.45, fontSize: 22, bold: true, color: i === 4 ? C.background1 : C.accent1 });
      txt(s, lv[i][1], { x: x + 0.12, y: y + 0.55, w: 1.48, h: 0.6, fontSize: 13, bold: true, color: i === 4 ? C.background1 : C.text1 });
      txt(s, lv[i][2], { x: x + 0.12, y: y + 1.15, w: 1.48, h: h - 1.2, fontSize: 11, color: i === 4 ? C.accent6 : C.text2 });
    }
    const band = [["Assistenza", 0.5, 3.52], ["Collaborazione", 4.18, 1.68], ["Delega", 6.02, 3.48]];
    band.forEach(b => chip(s, b[1], 4.28, b[2], 0.34, b[0], { fill: C.text2, color: C.background1, fontSize: 11 }));
    txt(s, "Automazione: livello 5 applicato in modo sistematico. Classificazione illustrativa, non uno standard tecnico né una progressione obbligatoria.", { x: 0.5, y: 4.7, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.accent5 });
  }
  {
    const s = content("Che cosa fanno l'AI e la persona a ogni livello", `Questa tabella dettaglia, per ciascun livello, il ruolo dell'AI, il ruolo della persona e un esempio. Al primo livello l'AI spiega e la persona interpreta e decide come usare le informazioni: per esempio, capire le novità di una normativa prima di leggere il testo ufficiale. Al secondo l'AI propone e la persona sceglie: alcune formulazioni alternative per un paragrafo difficile. Al terzo l'AI produce e la persona rivede e integra: una bozza di relazione da completare. Al quarto l'AI esegue e la persona controlla ogni risultato: le risposte alle richieste standard dei clienti, verificate prima dell'invio. Al quinto l'AI agisce entro vincoli e la persona definisce i limiti, monitora e gestisce le eccezioni: lo smistamento automatico delle richieste in arrivo, con controlli a campione. Si noti come cambia il ruolo della persona: da chi usa le informazioni, a chi sceglie, a chi rivede, a chi controlla, a chi definisce le regole e supervisiona.`);
    table(s, [["Livello", "L'AI", "La persona", "Esempio"], ["1. Informativo", "Spiega", "Interpreta, decide l'uso", "Capire le novità di una normativa"], ["2. Suggeritore", "Propone", "Sceglie e realizza", "Formulazioni alternative per un paragrafo"], ["3. Collaboratore", "Produce parti", "Rivede, integra, valida", "Bozza di relazione da completare"], ["4. Delega supervisionata", "Esegue", "Controlla ogni risultato", "Risposte standard verificate prima dell'invio"], ["5. Autonomia entro vincoli", "Agisce", "Definisce limiti, monitora, eccezioni", "Smistamento richieste con controlli a campione"]], { colW: [2.2, 1.4, 2.5, 2.9], rowH: 0.55, accentCol: 2, blankCorner: false, fontSize: 12 });
    txt(s, "Da chi usa le informazioni, a chi sceglie, rivede, controlla, definisce le regole.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Come evolve il ruolo umano", `Al crescere dell'autonomia del sistema, il ruolo della persona non scompare: si evolve verso attività di coordinamento, supervisione, progettazione e controllo. Nei livelli 1 e 2 la persona è un utilizzatore esperto: usa l'AI come uno strumento potente dentro il proprio lavoro. Nei livelli 3 e 4 diventa revisore ed editor: valuta, corregge e integra il lavoro dell'AI, e decide che cosa è pronto. Al livello 5 diventa coordinatore e progettista: disegna il flusso di lavoro, definisce regole e controlli, coordina persone e sistemi, gestisce le eccezioni. Sono competenze di valore crescente, molto richieste: saper scomporre un'attività, definire criteri di qualità, organizzare controlli efficaci. Due osservazioni pratiche. Primo: la supervisione è un'attività vera, che richiede attenzione anche quando tutto funziona bene; lo vedremo parlando di automation bias. Secondo: la competenza di dominio resta la base, perché è ciò che permette di guidare il sistema e riconoscere un risultato inadeguato. Per questo conviene continuare a esercitare le attività centrali del proprio ruolo, come vedremo nel 5.7.`);
    const r = [["FiTool", "Utilizzatore esperto", "Usa l'AI come strumento dentro il proprio lavoro", "Livelli 1-2"], ["FiEdit", "Revisore ed editor", "Valuta, corregge, integra, decide che cosa è pronto", "Livelli 3-4"], ["FiGrid", "Coordinatore e progettista", "Disegna il flusso, definisce regole e controlli, coordina", "Livello 5"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.25, 2.86, 2.2, i === 2 ? C.accent1 : C.background2, r[i][1]);
      await iconCircle(s, x + 0.2, 1.42, 0.55, r[i][0], i === 2 ? C.background1 : C.accent1, i === 2 ? HEX.a1 : HEX.lt1);
      txt(s, r[i][1], { x: x + 0.9, y: 1.42, w: 1.85, h: 0.55, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.text1, valign: "middle" });
      txt(s, r[i][2], { x: x + 0.2, y: 2.15, w: 2.46, h: 0.85, fontSize: 13, color: i === 2 ? C.background1 : C.text1 });
      txt(s, r[i][3], { x: x + 0.2, y: 3.0, w: 2.46, h: 0.3, fontSize: 11, bold: true, color: i === 2 ? C.accent6 : C.accent1 });
      if (i < 2) arrow(s, x + 2.88, 2.2, 0.17);
    }
    await card(s, 0.5, 3.65, 4.35, 1.3, { inline: true, icon: "FiTrendingUp", head: "Competenze di valore crescente", bodySize: 12, body: "Coordinare, progettare flussi, definire criteri di qualità e controlli." });
    await card(s, 5.15, 3.65, 4.35, 1.3, { inline: true, icon: "FiAward", head: "La competenza di dominio resta la base", bodySize: 12, fill: C.accent6, body: "È ciò che permette di guidare il sistema e riconoscere un risultato inadeguato." });
  }
  {
    const s = content("Scegliere il livello adeguato", `Come si sceglie il livello di delega? Quattro fattori. Il compito: quanto è strutturato, ripetitivo, verificabile? Compiti ben definiti e facili da controllare si prestano a livelli più alti. Le capacità del sistema: quanto è affidabile, per quel compito specifico, nelle nostre condizioni? I rischi: quali conseguenze ha un errore, quanto è grave, reversibile, rilevabile, e chi lo subisce? I controlli disponibili: possiamo verificare i risultati, con quali risorse e competenze? A ogni livello corrisponde una forma di controllo, riassunta nella fascia centrale. Ai livelli 1 e 2 il controllo è diretto: la persona valuta ogni informazione o suggerimento. Al livello 3 è un controllo di revisione del risultato complessivo. Al livello 4 è una verifica sistematica, con criteri chiari di accettazione. Al livello 5 è un controllo progettato in anticipo: vincoli e autorizzazioni, controlli a campione, monitoraggio, possibilità di interrompere. Il messaggio del riquadro scuro: una maggiore autonomia è un'opportunità. Quando il compito è adatto e i controlli sono adeguati, delegare di più libera tempo e permette di gestire volumi che prima non erano sostenibili, cioè genera efficienza e scalabilità. La condizione è che resti chiaro chi risponde del risultato e con quali mezzi lo controlla. La definizione organizzativa di ruoli e responsabilità è trattata nei Temi 13, 16 e 18.`);
    const f = [["FiTarget", "Compito", "Strutturato, ripetitivo, verificabile?"], ["FiCpu", "Capacità del sistema", "Affidabile per questo compito, qui?"], ["FiAlertTriangle", "Rischi", "Conseguenze di un errore: gravità, reversibilità?"], ["FiCheckSquare", "Controlli disponibili", "Possiamo verificare, con quali risorse?"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 1.45, C.background2, f[i][1]);
      await iconCircle(s, x + 0.15, 1.27, 0.48, f[i][0]);
      txt(s, f[i][1], { x: x + 0.72, y: 1.27, w: 1.38, h: 0.48, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, f[i][2], { x: x + 0.15, y: 1.85, w: 1.88, h: 0.7, fontSize: 12, color: C.text2 });
    }
    const ctl = [["Livelli 1-2", "Controllo diretto"], ["Livello 3", "Revisione del risultato"], ["Livello 4", "Verifica sistematica"], ["Livello 5", "Controllo progettato"]];
    ctl.forEach((c, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 2.75, 2.15, 0.62, C.accent6, "controllo " + c[0]);
      txt(s, [{ text: c[0], options: { bold: true, color: C.accent1, breakLine: true } }, { text: c[1], options: { color: C.text1 } }], { x: x + 0.15, y: 2.75, w: 1.9, h: 0.62, fontSize: 11, valign: "middle" });
    });
    shapeBox(s, 0.5, 3.52, 9.0, 1.43, C.text1, "autonomia come opportunità");
    txt(s, "Più autonomia può generare efficienza e scalabilità", { x: 0.75, y: 3.6, w: 8.5, h: 0.45, fontSize: 17, bold: true, color: C.background1 });
    txt(s, "Quando il compito è adatto e i controlli sono adeguati, delegare di più libera tempo e permette di gestire volumi maggiori. Resta chiaro chi risponde del risultato e con quali mezzi lo controlla.", { x: 0.75, y: 4.05, w: 8.5, h: 0.82, fontSize: 13, color: C.accent3 });
  }
  {
    const s = content("Quando aumentare la delega", `Applichiamo i quattro fattori a tre attività fittizie, con livelli di delega diversi. Prima: smistare le richieste in arrivo per categoria. È un compito molto ripetitivo e verificabile a campione, l'impatto di un errore è basso e reversibile, perché una richiesta mal classificata si riassegna, e i controlli si possono progettare: regole, campioni, eccezioni inoltrate a una persona. Qui un livello alto, l'autonomia entro vincoli, genera efficienza senza rischi rilevanti. Seconda: rispondere alle domande standard sulle consegne. Ripetitiva e verificabile, ma la risposta arriva al cliente: l'impatto è medio. Una delega supervisionata, con verifica prima dell'invio, offre gran parte del risparmio di tempo mantenendo il controllo; con l'esperienza e dati sulla qualità si può valutare di salire. Terza: valutare un fornitore strategico. Poco ripetitiva, verificabile solo in parte, con un impatto alto e poco reversibile. Qui l'AI è preziosa come suggeritore o collaboratore: raccoglie informazioni, propone criteri, prepara un confronto, ma la valutazione richiede la revisione di chi conosce il contesto. La regola pratica è nel banner. Esercizio suggerito: chiedere ai partecipanti di collocare tre attività del proprio lavoro nella tabella.`);
    table(s, [["Attività", "Ripetitività", "Verificabilità", "Impatto di un errore", "Controlli", "Livello"], ["Smistare le richieste in arrivo per categoria", "Alta", "Alta, a campione", "Basso, reversibile", "Regole, campioni, eccezioni a una persona", "5 · Autonomia entro vincoli"], ["Rispondere alle domande standard sulle consegne", "Alta", "Alta", "Medio: arriva al cliente", "Verifica prima dell'invio", "4 · Delega supervisionata"], ["Valutare un fornitore strategico", "Bassa", "Parziale", "Alto, poco reversibile", "Revisione esperta, fonti", "2-3 · Suggeritore o collaboratore"]], { colW: [2.1, 1.1, 1.25, 1.35, 1.7, 1.5], rowH: [0.45, 0.82, 0.82, 0.82], accentCol: 5, blankCorner: false, fontSize: 11 });
    banner(s, 4.2, "Si aumenta la delega quando il compito è ripetitivo e verificabile, l'impatto di un errore è gestibile e i controlli sono previsti.", { h: 0.75, fontSize: 13 });
  }

  // =====================================================================
  section("5.6 Il ruolo della persona");
  divider("5.6", "La qualità dipende anche dalla persona", "Le competenze umane restano determinanti per formulare problemi, interpretare risultati e riconoscere output inadeguati", `Spesso, quando si parla di AI, l'attenzione è tutta sullo strumento: quale modello è il migliore, quale funzione è nuova. Questo sottotema sposta l'attenzione sull'altro protagonista: la persona. A parità di strumento, persone diverse ottengono risultati molto diversi. Vediamo quali capacità fanno la differenza, perché il feedback è una competenza pratica, e la distinzione tra uso passivo e uso attivo dell'AI.`);
  {
    const s = content("Otto fattori che dipendono dalla persona", `Otto fattori determinano la qualità della collaborazione. Chiarezza degli obiettivi: sapere a che cosa servirà il risultato. Comprensione del problema: aver capito la natura della questione, non solo la superficie. Conoscenza del contesto: pubblico, vincoli, storia, priorità, cioè ciò che il sistema non può sapere se non glielo diciamo o non glielo rendiamo disponibile. Competenze di dominio: agiscono in due momenti; prima, per sapere che cosa chiedere e quali informazioni fornire; dopo, per riconoscere errori, omissioni, semplificazioni e scegliere quali suggerimenti accettare. Domande pertinenti: approfondire e mettere in discussione. Interpretazione dei risultati: distinguere ciò che è solido da ciò che è incerto. Feedback e correzione: indicare con precisione che cosa migliorare. Utilizzo attivo: costruire il risultato invece di limitarsi a riceverlo. Contesto e competenze di dominio sono probabilmente i fattori più decisivi: lo stesso strumento, nelle mani di un esperto e di un principiante, dà risultati di qualità diversa, e il principiante può ottenere un testo che sembra ottimo senza poter sapere se lo è. Per questo l'AI non rende superflua la competenza: la rende più preziosa. Notate che nessuno di questi fattori riguarda la tecnica dello strumento: sono competenze professionali e cognitive generali, che valgono con qualsiasi sistema.`);
    const f = [["FiTarget", "Chiarezza degli obiettivi", "Sapere a che cosa servirà il risultato"], ["FiHelpCircle", "Comprensione del problema", "Capire la natura della questione"], ["FiMap", "Conoscenza del contesto", "Pubblico, vincoli, storia, priorità"], ["FiAward", "Competenze di dominio", "Che cosa chiedere, quali errori vedere"], ["FiMessageCircle", "Domande pertinenti", "Approfondire e mettere in discussione"], ["FiEye", "Interpretazione dei risultati", "Solido o incerto?"], ["FiEdit", "Feedback e correzione", "Indicare con precisione che cosa migliorare"], ["FiActivity", "Utilizzo attivo", "Costruire il risultato, non solo riceverlo"]];
    await iconGrid(s, f.map((e, i) => ({ icon: e[0], head: e[1], body: e[2], fill: i === 2 || i === 3 ? C.accent6 : C.background2 })), 4, { y: 1.15, H: 3.15, headSize: 13, bodySize: 11 });
    banner(s, 4.45, "Contesto e competenza di dominio contano prima e dopo la richiesta: con l'AI la competenza vale di più.", { h: 0.5, fontSize: 13 });
  }
  {
    const s = content("Obiettivi chiari e comprensione del problema", `I primi due fattori lavorano a monte dell'interazione. Con un obiettivo vago il sistema produce risultati generici e, soprattutto, non abbiamo un criterio per valutarli. Con un obiettivo chiaro, sia la richiesta sia la valutazione diventano molto più facili. L'esempio in slide mette a confronto i due casi: 'scrivimi qualcosa sul nuovo servizio' e 'i clienti attuali devono capire che cosa cambia per loro e iscriversi alla presentazione'. Lo stesso vale per la comprensione del problema: chiedere come rendere più persuasiva una comunicazione non aiuta se il problema è che arriva alle persone sbagliate. Non si tratta di tecnica di formulazione, che vedremo nel Tema 6, ma di chiarezza di pensiero. E quando l'obiettivo non è ancora chiaro, il dialogo stesso aiuta a scoprirlo, come abbiamo visto nel 5.2.`);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiCloud", head: "Obiettivo vago", headSize: 15, bodySize: 13,
      body: [{ text: "\"Scrivimi qualcosa sul nuovo servizio.\"", options: { italic: true, bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Risultato generico, nessun criterio per valutarlo.", options: {} }] });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiTarget", head: "Obiettivo chiaro", headSize: 15, bodySize: 13, fill: C.accent6,
      body: [{ text: "I clienti attuali devono capire che cosa cambia per loro e iscriversi alla presentazione.", options: { italic: true, bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Richiesta e valutazione diventano più facili.", options: {} }] });
    banner(s, 3.95, "Prima di chiedere: che cosa voglio ottenere? Se non è ancora chiaro, il dialogo aiuta a scoprirlo.", { h: 0.75 });
  }
  {
    const s = content("Domande, interpretazione e feedback", `Tre capacità operano durante l'interazione. Porre domande pertinenti: non solo la richiesta iniziale, ma le domande successive che approfondiscono, chiariscono, mettono in discussione: 'su che cosa si basa questa conclusione?', 'quali casi non rientrano?', 'che cosa cambierebbe se il budget fosse la metà?'. Interpretare i risultati: distinguere ciò che è solido da ciò che è incerto, accorgersi di quando la risposta è generica, riconoscere le assunzioni implicite. Dare feedback precisi: è la competenza pratica con l'effetto più immediato. Un feedback generico, 'non va, rifallo', produce di solito una versione diversa ma non necessariamente migliore. Un feedback specifico, 'il secondo paragrafo è troppo tecnico per il pubblico e manca la scadenza', permette una correzione mirata. È la stessa abilità che serve per guidare il lavoro di un collaboratore, e si sviluppa con la pratica. Esercizio suggerito: prendere una risposta AI insoddisfacente e scrivere insieme il feedback più preciso possibile. Le tecniche specifiche di formulazione e affinamento sono nel Tema 6.`);
    const c = [["FiHelpCircle", "Domande pertinenti", ["\"Su che cosa si basa questa conclusione?\"", "\"Quali casi non rientrano?\"", "\"Che cosa cambierebbe se...?\""]], ["FiEye", "Interpretare i risultati", ["Solido o incerto?", "Generico o specifico?", "Quali assunzioni implicite?"]], ["FiEdit", "Feedback preciso", ["Generico: \"non va, rifallo\"", "Preciso: \"il secondo paragrafo è troppo tecnico, manca la scadenza\"", "Effetto: una correzione mirata"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.15, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2, body: bullets(c[i][2], { space: 5 }) });
    banner(s, 4.5, "Il feedback preciso è una competenza pratica: la leva più rapida per migliorare una risposta.", { h: 0.45, fontSize: 13 });
  }
  {
    const s = content("Utilizzo passivo e utilizzo attivo", `I fattori visti convergono in una distinzione di atteggiamento: utilizzo passivo e utilizzo attivo. Nell'utilizzo passivo la persona fa una richiesta, riceve una risposta e la usa così com'è: non porta contesto, non mette in discussione, non personalizza. Il risultato tende a essere generico e gli eventuali errori sono più difficili da notare. Nell'utilizzo attivo la persona parte da obiettivi chiari, porta il contesto, dialoga, confronta con ciò che sa, corregge, integra e verifica dove serve. Il confronto in tabella sintetizza le differenze. Non è una garanzia automatica: un utilizzo attivo favorisce risultati più pertinenti, offre occasioni di apprendimento perché la persona esercita le proprie competenze nel dialogo, e mantiene il controllo su ciò che si produce. Richiede un po' più di impegno all'inizio, che con l'abitudine diventa naturale. È spesso ciò che distingue chi trae un vantaggio reale dall'AI da chi conclude che 'non serve'. Domanda per il gruppo: nel vostro uso quotidiano, siete più vicini all'utilizzo passivo o a quello attivo?`);
    table(s, [["", "Utilizzo passivo", "Utilizzo attivo"], ["Obiettivi", "Impliciti o vaghi", "Chiari"], ["Contesto", "Non fornito", "Fornito e precisato"], ["Dialogo", "Una richiesta, una risposta", "Scambi, domande, correzioni"], ["Atteggiamento", "Accetta il risultato", "Confronta, integra, verifica dove serve"], ["Risultato", "Spesso generico, errori più difficili da notare", "Più pertinente e controllato"], ["Competenze", "Esercitate poco", "Esercitate e sviluppate nel dialogo"]], { colW: [2.0, 3.5, 3.5], rowH: 0.48, accentCol: 2 });
    txt(s, "Un utilizzo attivo favorisce qualità, apprendimento e controllo.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 13, italic: true, color: C.text1 });
  }

  // =====================================================================
  section("5.7 Limiti e rischi");
  divider("5.7", "Limiti e rischi della relazione conversazionale", "Conoscere le dinamiche della conversazione permette di sviluppare una fiducia calibrata e di usare l'AI con consapevolezza", `Ultimo sottotema. La naturalezza della conversazione è il grande punto di forza dei sistemi AI, e porta con sé alcune dinamiche da conoscere: la tendenza ad attribuire al sistema qualità umane, l'automation bias, gli effetti della delega cognitiva sulle competenze. L'obiettivo non è diffidare dell'AI, ma sviluppare una fiducia calibrata: più fiducia dove il sistema si è dimostrato affidabile per quel compito, più controllo dove un errore costa di più. Non ripetiamo l'analisi tecnica di allucinazioni e bias del Tema 3, né le procedure di verifica, oggetto del Tema 7: ci concentriamo sulle dinamiche dell'interazione e su come gestirle.`);
  {
    const s = content("Antropomorfizzazione", `Nel Tema 2 abbiamo incontrato l'effetto ELIZA: la tendenza ad attribuire comprensione e qualità umane a un sistema che produce linguaggio in modo convincente. È una reazione naturale di esseri sociali a un comportamento linguistico molto simile a quello umano, non un segno di ingenuità. I sistemi conversazionali usano un linguaggio caldo, ricordano ciò che abbiamo detto, si scusano, esprimono comprensione; con la voce l'effetto è ancora più forte. La slide distingue ciò che percepiamo da un modo più accurato di leggerlo. Comprensione: il sistema elabora il contesto, spesso molto bene, e può cogliere aspetti rilevanti della nostra situazione, ma non la vive e conosce solo ciò che ha a disposizione. Empatia: produce risposte adatte al tono e al contesto; è un comportamento linguistico, non un legame personale. Intenzionalità e opinioni: le risposte dipendono da addestramento, istruzioni e formulazione della richiesta; per questo una 'opinione' può cambiare se cambiamo la domanda. Non serve risolvere qui le questioni filosofiche aperte su questi sistemi: serve un modo pratico di usarli bene. In basso, tre indicazioni. Calibrare la fiducia sul compito, non sul tono della risposta. Condividere dati personali o aziendali secondo le regole dell'organizzazione. E sul piano personale: usare l'AI per riflettere, prepararsi a una conversazione difficile o sentirsi meno soli davanti a un problema può essere utile; il rischio è l'affidamento eccessivo, quando il sistema diventa l'unico riferimento o sostituisce un supporto professionale nei momenti in cui servirebbe.`);
    const p = [["FiCheckCircle", "Comprensione", "Ha capito davvero la mia situazione?", "Elabora il contesto, spesso molto bene; conosce solo ciò che ha a disposizione"], ["FiHeart", "Empatia", "Partecipa ai miei stati d'animo?", "Risponde in modo adatto al tono: comportamento linguistico, non legame personale"], ["FiCompass", "Intenzionalità", "Vuole aiutarmi, ha opinioni sue?", "Segue addestramento, istruzioni e richiesta: le opinioni cambiano con la domanda"]];
    txt(s, "Che cosa percepiamo", { x: 1.2, y: 1.12, w: 4.2, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    txt(s, "Come leggerlo", { x: 5.25, y: 1.12, w: 4.1, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    for (let i = 0; i < 3; i++) {
      const y = 1.47 + i * 0.85;
      shapeBox(s, 0.5, y, 9.0, 0.75, i % 2 ? C.background1 : C.background2, p[i][1]);
      await iconCircle(s, 0.62, y + 0.13, 0.48, p[i][0]);
      txt(s, p[i][1], { x: 1.2, y, w: 1.55, h: 0.75, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, p[i][2], { x: 2.75, y, w: 2.4, h: 0.75, fontSize: 12, italic: true, color: C.text1, valign: "middle" });
      txt(s, p[i][3], { x: 5.25, y, w: 4.15, h: 0.75, fontSize: 11, color: C.text2, valign: "middle" });
    }
    txt(s, "Usarla bene", { x: 0.5, y: 4.07, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Calibrare la fiducia sul compito, non sul tono", "Condividere dati secondo le regole dell'organizzazione", "Supporto personale: utile, senza sostituire un aiuto professionale"].forEach((t, i) => chip(s, 0.5 + i * 3.07, 4.4, 2.86, 0.58, t, { fill: C.background1, line: { color: C.accent1, width: 1.25 }, color: C.text1, fontSize: 11 }));
  }
  {
    const s = content("Automation bias e verifica proporzionata", `Un interlocutore che risponde con sicurezza, in modo fluente, e che spesso ha ragione, induce fiducia. È comprensibile, ma può alimentare un circolo: più ci fidiamo, meno controlliamo; meno controlliamo, meno errori notiamo; meno errori notiamo, più ci fidiamo. Questa dinamica ha un nome: automation bias, la tendenza a privilegiare i suggerimenti di un sistema automatizzato senza un'adeguata verifica, talvolta anche contro altre informazioni o il proprio giudizio. È stata studiata per decenni, prima dell'AI generativa, in aviazione, medicina e controllo industriale; una sintesi nota è quella di Parasuraman e Manzey, pubblicata nel 2010 su Human Factors. Si manifesta in due forme. Errori di commissione: seguire un suggerimento sbagliato, per esempio accettare una classificazione errata. Errori di omissione: non accorgersi di un problema che il sistema non ha segnalato, per esempio dare per completo un riassunto che omette un punto importante. È più forte quando il sistema è di solito affidabile, il carico di lavoro è alto e l'esperienza è poca. Non dipende da superficialità individuale: è una tendenza cognitiva comune, che si gestisce con abitudini di controllo proporzionate. In basso tre esempi concreti: per un'email interna di routine basta una rilettura rapida; per numeri destinati a un cliente si controllano i valori chiave sulla fonte; per una decisione contrattuale si verificano le clausole sul testo originale e, se serve, si chiede un parere esperto. Le procedure di verifica sono sviluppate nel Tema 7.`);
    shapeBox(s, 0.5, 1.15, 9.0, 0.95, C.text1, "definizione automation bias");
    txt(s, [{ text: "Automation bias: ", options: { bold: true, color: C.accent1 } }, { text: "la tendenza a privilegiare i suggerimenti automatizzati senza adeguata verifica. Più forte quando il sistema è di solito affidabile, il carico è alto, l'esperienza è poca.", options: { color: C.background1 } }], { x: 0.7, y: 1.15, w: 8.6, h: 0.95, fontSize: 13, valign: "middle" });
    await miniCard(s, 0.5, 2.25, 4.35, 0.95, "FiCheck", "Errori di commissione", "Seguire un suggerimento sbagliato: accettare una classificazione errata.");
    await miniCard(s, 5.15, 2.25, 4.35, 0.95, "FiEyeOff", "Errori di omissione", "Non vedere un problema non segnalato: un riassunto che omette un punto.", C.accent6);
    txt(s, "Verifica proporzionata: tre esempi", { x: 0.5, y: 3.3, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const v = [["Email interna di routine", "Rilettura rapida"], ["Numeri per un cliente", "Controllo dei valori chiave sulla fonte"], ["Decisione contrattuale", "Clausole sul testo originale, parere esperto"]];
    v.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 3.65, 2.86, 0.95, i === 2 ? C.accent6 : C.background2, "verifica " + i);
      txt(s, [{ text: e[0], options: { bold: true, color: C.text1, breakLine: true } }, { text: e[1], options: { color: C.text2 } }], { x: x + 0.15, y: 3.65, w: 2.56, h: 0.95, fontSize: 12, valign: "middle" });
    });
    txt(s, "Fonte: Parasuraman e Manzey, Human Factors, 2010", { x: 0.5, y: 4.72, w: 6, h: 0.25, fontSize: 10, color: C.accent2 });
  }
  {
    const s = content("Delega cognitiva: benefici e attenzioni", `Per delega cognitiva intendiamo affidare all'AI attività mentali: ricordare, sintetizzare, scrivere, ragionare, confrontare. Partiamo dai benefici, che sono reali. Deleghiamo attività mentali agli strumenti da sempre, alla scrittura, alla calcolatrice, al navigatore, e questo ci ha liberato tempo e attenzione per altro. Con l'AI, delegare una sintesi, una prima bozza o una ricerca preliminare libera energie per le attività a maggior valore: il giudizio, la relazione con le persone, la creatività, le decisioni. Gli effetti sulle competenze dipendono dalle modalità di utilizzo. Possono indebolirsi quando si accettano risultati senza comprenderli, quando si smette di esercitare le attività centrali del proprio ruolo, quando non si è più in grado di riconoscere un errore. Sono rischi legati al modo d'uso, non conseguenze necessarie della delega. Un segnale dalla ricerca: un'indagine di Microsoft Research e Carnegie Mellon presentata a CHI 2025 (Lee e colleghi), su 319 lavoratori della conoscenza e 936 esempi di uso reale, ha osservato che una maggiore fiducia nell'AI generativa si associava a un minore pensiero critico dichiarato, mentre una maggiore fiducia nelle proprie capacità si associava a un pensiero critico maggiore. Due cautele da comunicare: i dati sono auto-riferiti, e gli stessi autori precisano che l'analisi non stabilisce un rapporto causale. È un'indicazione utile, coerente con quanto visto nel modulo: il valore sta nell'usare l'AI continuando a ragionare.`);
    await card(s, 0.5, 1.2, 4.35, 2.25, { icon: "FiSun", head: "Benefici", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Libera tempo e attenzione per le attività a maggior valore", "Accelera sintesi, bozze, ricerche preliminari", "Come scrittura, calcolatrice, navigatore"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.25, { icon: "FiSliders", head: "Effetti che dipendono dall'uso", headSize: 15, bodySize: 12, iconBg: HEX.a4,
      body: [{ text: "Le competenze possono indebolirsi quando:", options: { color: C.text1, breakLine: true, paraSpaceAfter: 3 } }].concat(bullets(["si accettano risultati senza comprenderli", "si smette di esercitare le attività centrali", "non si riconoscono più gli errori"], { space: 1 })) });
    shapeBox(s, 0.5, 3.6, 9.0, 1.35, C.text2, "studio Lee");
    txt(s, "UN SEGNALE DALLA RICERCA", { x: 0.7, y: 3.68, w: 4, h: 0.28, fontSize: 10, bold: true, color: C.accent3, charSpacing: 2 });
    txt(s, "Più fiducia nell'AI si associava a meno pensiero critico dichiarato; più fiducia nelle proprie capacità, a più pensiero critico. Dati auto-riferiti su 319 lavoratori: un'associazione, non un rapporto causale.", { x: 0.7, y: 3.95, w: 8.6, h: 0.7, fontSize: 12, color: C.background1 });
    txt(s, "Fonte: Lee et al., Microsoft Research e Carnegie Mellon, CHI 2025", { x: 0.7, y: 4.65, w: 8, h: 0.25, fontSize: 10, color: C.accent3 });
  }
  {
    const s = content("Utilizzare l'AI mantenendo autonomia e competenze", `Una certa dipendenza dagli strumenti è normale e accettabile: nessuno rinuncia al foglio di calcolo. Il punto è usare l'AI in modo che il suo valore cresca nel tempo, insieme alle nostre competenze. Le pratiche in slide sono proporzionate al compito e alle conseguenze degli errori, non regole da applicare sempre. Farsi un'idea prima, quando conta: per decisioni e contenuti importanti, un'ipotesi propria, anche sommaria, dà un termine di confronto; per attività di routine non serve. Mettere alla prova, non solo produrre: usare l'AI come interlocutore critico. Esercitare le attività centrali: continuare a svolgere in prima persona, almeno in parte, ciò che è decisivo per il proprio ruolo e la propria crescita. Capire ciò che si presenta: saper spiegare i risultati che si portano ad altri. Verificare in proporzione: più controllo dove un errore costa di più. Decidere secondo il proprio ruolo: l'AI propone opzioni, chi ha la responsabilità decide. Domanda di verifica: quale di queste pratiche vi sembra più utile nel vostro lavoro? Chiedere a ciascun partecipante di sceglierne una.`);
    const p = [["FiZap", "Farsi un'idea prima, quando conta", "Un'ipotesi propria come termine di confronto"], ["FiShield", "Mettere alla prova, non solo produrre", "L'AI come interlocutore critico"], ["FiRepeat", "Esercitare le attività centrali", "Quelle decisive per il ruolo e la crescita"], ["FiMessageCircle", "Capire ciò che si presenta", "Saper spiegare i risultati che si portano ad altri"], ["FiCheckSquare", "Verificare in proporzione", "Più controllo dove un errore costa di più"], ["FiUserCheck", "Decidere secondo il proprio ruolo", "L'AI propone opzioni, chi è responsabile decide"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 3.15, headSize: 13, bodySize: 12 });
    banner(s, 4.5, "Pratiche proporzionate al compito: rendono il valore dell'AI sostenibile e crescente nel tempo.", { h: 0.5, fontSize: 13 });
  }

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Un metodo pratico di collaborazione uomo-AI", `Ecco il modulo tradotto in un metodo di lavoro in cinque passaggi, applicabile a quasi ogni attività. Uno: definire l'obiettivo, cioè che cosa serve, per chi, entro quando. Due: fornire le informazioni disponibili, cioè documenti, contesto, vincoli. Tre: collaborare e perfezionare, attraverso il dialogo, le domande dell'AI e feedback precisi; qui si sceglie anche il ruolo dell'AI e il livello di delega adatti. Quattro: valutare il risultato in proporzione al rischio: più controllo dove un errore costa di più. Cinque: usare il risultato e apprendere dall'esperienza, annotando che cosa ha funzionato, così che la volta successiva sia più rapida. La riga in basso mostra il metodo applicato a un caso fittizio, la preparazione di un'offerta per un nuovo cliente: obiettivo e scadenza, listino e note dell'incontro, una bozza migliorata con le domande dell'AI e le correzioni sui prezzi, un controllo puntuale di prezzi e condizioni, l'invio e una richiesta riuscita conservata come modello. Esercizio suggerito: applicare i cinque passaggi a un'attività reale scelta dai partecipanti.`);
    const st = [["1", "Definire l'obiettivo", "Che cosa serve, per chi, entro quando", "Offerta chiara per un nuovo cliente, entro venerdì"], ["2", "Fornire le informazioni", "Documenti, contesto, vincoli disponibili", "Listino, condizioni standard, note dell'incontro"], ["3", "Collaborare e perfezionare", "Dialogo, domande dell'AI, feedback precisi", "Bozza, domande dell'AI, correzioni sui prezzi"], ["4", "Valutare in proporzione al rischio", "Più controllo dove un errore costa di più", "Controllo puntuale di prezzi e condizioni"], ["5", "Usare e apprendere", "Applicare il risultato, annotare che cosa ha funzionato", "Invio; la richiesta riuscita diventa un modello"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.68, 2.1, i === 4 ? C.accent1 : (i === 2 ? C.accent6 : C.background2), "passaggio " + st[i][0]);
      s.addShape(pres.shapes.OVAL, { x: x + 0.12, y: 1.27, w: 0.45, h: 0.45, fill: { color: i === 4 ? C.background1 : C.accent1 }, line: { type: "none" }, objectName: "numero " + st[i][0] });
      txt(s, st[i][0], { x: x + 0.12, y: 1.27, w: 0.45, h: 0.45, fontSize: 15, bold: true, color: i === 4 ? C.accent1 : C.background1, align: "center", valign: "middle" });
      txt(s, st[i][1], { x: x + 0.12, y: 1.8, w: 1.48, h: 0.72, fontSize: 13, bold: true, color: i === 4 ? C.background1 : C.text1 });
      txt(s, st[i][2], { x: x + 0.12, y: 2.58, w: 1.48, h: 0.62, fontSize: 11, color: i === 4 ? C.accent6 : C.text2 });
    }
    txt(s, "Esempio fittizio: un'offerta per un nuovo cliente", { x: 0.5, y: 3.4, w: 9, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 3.75, 1.68, 1.2, C.background1, "esempio " + st[i][0], { color: C.accent3, width: 1 });
      txt(s, st[i][3], { x: x + 0.1, y: 3.75, w: 1.48, h: 1.2, fontSize: 11, italic: true, color: C.text1, valign: "middle" });
    }
  }
  {
    const s = content("Principi per un dialogo efficace", `Accanto al metodo, otto principi operativi da tenere a portata di mano, uno o due per ciascun sottotema. Dialogare: costruire il risultato in più scambi invece di fermarsi alla prima risposta. Quando il compito è poco definito, chiedere all'AI di fare domande prima di procedere. Scegliere il ruolo adatto al momento: fonte, revisore, tutor, interlocutore critico. Chiedere critiche e alternative, non solo conferme, sulle idee e sulle decisioni importanti. Portare il contesto: obiettivi, pubblico, vincoli, documenti utili. Aumentare la delega quando il compito è ripetitivo e verificabile e i controlli sono previsti. Dare feedback precisi: è la leva più rapida per migliorare. Calibrare la fiducia sul compito: la conversazione è naturale, il sistema non è una persona. Il messaggio di sintesi in basso è il criterio con cui leggere tutto il modulo: il dialogo con l'AI è una nuova modalità di lavoro, e il valore nasce dalla combinazione delle capacità dell'AI, delle competenze umane e di un controllo adeguato al contesto.`);
    const p = [["FiMessageSquare", "Dialogare: costruire il risultato in più scambi"], ["FiHelpCircle", "Se il compito è poco definito, chiedere all'AI di fare domande"], ["FiUsers", "Scegliere il ruolo adatto: fonte, revisore, tutor, interlocutore critico"], ["FiShield", "Chiedere critiche e alternative sulle decisioni importanti"], ["FiMap", "Portare il contesto: obiettivi, pubblico, vincoli, documenti"], ["FiSliders", "Aumentare la delega quando il compito è ripetitivo, verificabile e controllato"], ["FiEdit", "Dare feedback precisi: è la leva più rapida per migliorare"], ["FiUserCheck", "Calibrare la fiducia sul compito, non sul tono della risposta"]];
    for (let i = 0; i < 8; i++) {
      const y = 1.12 + i * 0.44;
      shapeBox(s, 0.5, y, 9.0, 0.39, i % 2 ? C.background1 : C.background2, "principio " + (i + 1));
      txt(s, String(i + 1), { x: 0.6, y, w: 0.35, h: 0.39, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      await iconCircle(s, 1.0, y + 0.03, 0.33, p[i][0]);
      txt(s, p[i][1], { x: 1.5, y, w: 7.9, h: 0.39, fontSize: 13, color: C.text1, valign: "middle" });
    }
    banner(s, 4.7, "Il valore nasce dalla combinazione delle capacità dell'AI, delle competenze umane e di un controllo adeguato al contesto.", { h: 0.42, fontSize: 12 });
  }
  {
    const s = content("Prossimo passo: il Tema 6", `Il percorso prosegue con il Tema 6, dedicato al prompting e alle tecniche di interazione. In questo modulo abbiamo visto il perché e il che cosa: il valore del dialogo, i ruoli dell'AI, la collaborazione, i livelli di delega, il contributo della persona e la fiducia calibrata. Il Tema 6 offre il come: formulare richieste efficaci, fornire contesto ed esempi, assegnare ruoli e formati, perfezionare progressivamente le richieste. È il modo concreto di mettere in pratica il metodo in cinque passaggi, in particolare il secondo e il terzo. Più avanti, il Tema 7 sarà dedicato alla verifica degli output e al pensiero critico, cioè al quarto passaggio. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.`);
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.background2, "tema 5");
    txt(s, "TEMA 5", { x: 0.75, y: 1.4, w: 3.1, h: 0.35, fontSize: 13, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Il dialogo uomo-AI", { x: 0.75, y: 1.8, w: 3.1, h: 0.5, fontSize: 18, bold: true, color: C.text1 });
    txt(s, bullets(["Dialogare e collaborare con l'AI", "Scegliere ruoli e livelli di delega", "Il contributo della persona", "Una fiducia calibrata"], { space: 4 }), { x: 0.75, y: 2.45, w: 3.1, h: 2.2, fontSize: 14, color: C.text2 });
    arrow(s, 4.25, 2.9, 0.55, C.accent1);
    shapeBox(s, 4.95, 1.2, 4.55, 3.75, C.text1, "tema 6");
    txt(s, "TEMA 6", { x: 5.2, y: 1.4, w: 4.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Prompting e tecniche di interazione", { x: 5.2, y: 1.8, w: 4.1, h: 0.7, fontSize: 18, bold: true, color: C.background1 });
    txt(s, bullets(["Dal perché del dialogo al come", "Formulare richieste efficaci", "Contesto, esempi, ruoli, formati", "Perfezionare le richieste", "Poi, Tema 7: verifica e pensiero critico"], { space: 3 }), { x: 5.2, y: 2.6, w: 4.1, h: 2.2, fontSize: 14, color: C.accent3 });
  }
  {
    const s = content("Fonti e riferimenti", `Le fonti citate nel modulo. Verifica svolta il 16 ottobre 2026: per Weizenbaum confermati rivista, volume, numero e pagine; per Parasuraman e Manzey confermati rivista, volume, numero e pagine 381-410; per Lee e colleghi confermati titolo, autori (Carnegie Mellon University e Microsoft Research), atti CHI 2025, pagine 1-22, DOI 10.1145/3706598.3713778, campione di 319 lavoratori della conoscenza con 936 esempi, natura auto-riferita dei dati e l'affermazione degli autori che l'analisi non stabilisce un rapporto causale. Gli esempi del modulo (comunicazione sulle sale, reclamo del cliente, filiale a Milano, tre attività per i livelli di delega, offerta per un nuovo cliente) sono fittizi e non derivano da fonti. La ricerca sugli effetti dell'AI generativa sul pensiero critico è in rapida evoluzione: prima di ogni edizione è consigliabile verificare se sono disponibili studi più recenti o più solidi da citare.`);
    const src = [
      "Weizenbaum, J. (1966). ELIZA: A Computer Program for the Study of Natural Language Communication between Man and Machine. Communications of the ACM, 9(1), 36-45.",
      "Parasuraman, R., Manzey, D. H. (2010). Complacency and Bias in Human Use of Automation: An Attentional Integration. Human Factors, 52(3), 381-410.",
      "Lee, H.-P. et al. (2025). The Impact of Generative AI on Critical Thinking: Self-Reported Reductions in Cognitive Effort and Confidence Effects From a Survey of Knowledge Workers. Proceedings of the 2025 CHI Conference on Human Factors in Computing Systems, ACM, 1-22. Carnegie Mellon University e Microsoft Research.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.0, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione. Gli esempi del modulo sono fittizi.", { x: 1.3, y: 4.5, w: 8.2, h: 0.35, fontSize: 12, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema5_Dialogo_uomo_AI.pptx" });
  await applyTheme("Tema5_Dialogo_uomo_AI.pptx", THEME);
  console.log("done");
})();
