const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 5: Il dialogo uomo-AI";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 5  ·  Il dialogo uomo-AI";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function dialog(s, x, y, w, turns, o) {
    o = o || {};
    let yy = y;
    const lh = o.lh || 0.5, gap = o.gap || 0.1;
    turns.forEach(t => {
      const user = t[0] === "P";
      const bw = w * 0.78;
      const bx = user ? x : x + w - bw;
      const h = t[2] || lh;
      shapeBox(s, bx, yy, bw, h, user ? C.background2 : C.accent6, "turno");
      txt(s, [{ text: (user ? "Persona: " : "AI: "), options: { bold: true, color: user ? C.text1 : C.accent1 } }, { text: t[1], options: { color: C.text1 } }], { x: bx + 0.15, y: yy, w: bw - 0.3, h, fontSize: o.fontSize || 12, valign: "middle" });
      yy += h + gap;
    });
    return yy;
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 5", { placeholder: "kicker" });
    s.addText("Il dialogo uomo-AI", { placeholder: "title" });
    s.addText("Area: Interagire con l'AI", { placeholder: "sub" });
    s.addNotes("Benvenuti al quinto tema, che apre una nuova area del percorso: 'Interagire con l'AI'. Nei quattro temi precedenti abbiamo costruito la comprensione: perché l'AI è rilevante, come funziona, quanto possiamo fidarci dei risultati, come è organizzato l'ecosistema. Da qui in avanti ci spostiamo sulla pratica dell'interazione. Questo primo tema dell'area non è un manuale di prompting, che sarà l'oggetto del Tema 6, né un percorso tecnico sugli agenti. Riguarda la relazione operativa e cognitiva tra persona e AI: che cosa significa dialogare con un sistema in linguaggio naturale, quali ruoli può assumere, come si collabora, quanto si può delegare, quanto conta la persona e quali rischi comporta una relazione così naturale. Suggerimento per l'apertura: chiedere ai partecipanti come descriverebbero il proprio rapporto con un assistente AI, se lo usano: uno strumento, un collega, un consulente, un motore di ricerca? Le metafore che emergono saranno utili per tutto il modulo.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere le caratteristiche dell'interazione conversazionale con i sistemi AI e sviluppare la capacità di riconoscere modalità di collaborazione, livelli di delega e responsabilità di chi li usa. La consapevolezza da sviluppare ha due facce. La prima: l'efficacia dell'interazione non dipende solo dalle capacità del sistema, ma anche dalla persona, cioè dal suo ruolo attivo, dalla chiarezza degli obiettivi, dalle competenze e dal livello di autonomia che decide di affidare alla tecnologia. La seconda: una conversazione naturale non equivale a un rapporto con un interlocutore umano, e non garantisce l'esattezza delle risposte. Il messaggio centrale del tema lo riassume: interagire consapevolmente con l'AI significa costruire una collaborazione in cui la tecnologia amplifica le capacità umane senza sostituire automaticamente giudizio, competenze e responsabilità.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Comprendere l'interazione conversazionale con l'AI", "Riconoscere modalità di collaborazione e livelli di delega", "Mantenere chiara la responsabilità di chi usa l'AI"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "L'efficacia dipende anche dalla persona: ruolo attivo, obiettivi chiari, competenze, autonomia affidata.\n\nUna conversazione naturale non è un rapporto con un interlocutore umano e non garantisce risposte esatte." });
  }
  {
    const s = content("Dieci domande guida per questo modulo", "Le dieci domande guida accompagnano il modulo. Le prime tre riguardano il linguaggio naturale come interfaccia e il passaggio dalla domanda alla conversazione, compresa la possibilità che sia l'AI a porre domande. La quarta riguarda i ruoli dell'AI e le competenze che non è corretto presumere. La quinta e la sesta la collaborazione e i livelli di delega. La settima il contributo delle competenze personali. L'ottava l'uso dell'AI come strumento di confronto critico. Le ultime due i rischi della relazione conversazionale e la tutela dell'autonomia cognitiva e della responsabilità. Alla fine del modulo torneremo su tutte con una risposta sintetica.");
    const qs = ["Che cosa cambia quando il linguaggio naturale diventa interfaccia?", "Perché il dialogo non si esaurisce in un'unica domanda?", "Come può l'AI aiutare a chiarire un problema ponendo domande?", "Quali ruoli può svolgere l'AI e quali competenze non presumere?", "In cosa consiste una collaborazione efficace?", "Come distinguere supporto, collaborazione, delega e autonomia?", "Quali competenze personali migliorano la collaborazione?", "Come usare l'AI per mettere alla prova un'ipotesi?", "Quali rischi da antropomorfizzazione e fiducia eccessiva?", "Come preservare autonomia cognitiva e responsabilità?"];
    for (let i = 0; i < 10; i++) {
      const col = i % 5, row = Math.floor(i / 5);
      const x = 0.5 + col * 1.84, y = 1.2 + row * 1.9;
      shapeBox(s, x, y, 1.7, 1.75, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, qs[i], { x: x + 0.15, y: y + 0.55, w: 1.45, h: 1.15, fontSize: 11, color: C.text1 });
    }
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in sette sottotemi, tutti con priorità alta e tutti mantenuti separati. Vanno compresi bene: il dialogo iterativo, la collaborazione uomo-AI, i livelli di delega, il ruolo delle competenze umane, l'autonomia cognitiva e la responsabilità. Vanno conosciuti: le interfacce conversazionali, i ruoli dell'AI, l'uso come interlocutore critico, le dinamiche di feedback e chiarimento. Vanno solo accennati: le teorie avanzate dell'interazione uomo-macchina, i modelli psicologici della fiducia nell'automazione e la progettazione tecnica di agenti conversazionali. Confini: non ripetiamo i meccanismi tecnici del Tema 2, né l'analisi di allucinazioni e bias del Tema 3, né il confronto tra prodotti del Tema 4. Le tecniche operative per formulare le richieste sono rimandate al Tema 6; le procedure di verifica degli output al Tema 7; la progettazione di agenti e workflow al tema dedicato; la riprogettazione di processi e ruoli all'area aziendale.");
    const items = [["5.1", "Il linguaggio naturale come interfaccia"], ["5.2", "Dalla domanda alla conversazione"], ["5.3", "I diversi ruoli che l'AI può assumere"], ["5.4", "La collaborazione uomo-AI"], ["5.5", "I livelli di delega all'AI"], ["5.6", "La qualità dipende anche dalla persona"], ["5.7", "Limiti e rischi della relazione conversazionale"]];
    items.forEach((it, i) => {
      const y = 1.15 + i * 0.52;
      shapeBox(s, 0.5, y, 5.6, 0.44, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.44, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.44, fontSize: 13, color: C.text1, valign: "middle" });
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.09, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: C.accent1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, "Alta", { x: 5.2, y: y + 0.09, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: C.background1, align: "center", valign: "middle" });
    });
    const lv = [["Comprendere bene", "Dialogo iterativo, collaborazione, livelli di delega, competenze umane, autonomia cognitiva e responsabilità", C.accent1, C.background1], ["Conoscere", "Interfacce conversazionali, ruoli dell'AI, interlocutore critico, feedback e chiarimento", C.accent6, C.text1], ["Solo accennare", "Teorie dell'interazione uomo-macchina, modelli psicologici della fiducia, progettazione di agenti", C.background2, C.text1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 1.25;
      shapeBox(s, 6.35, y, 3.15, 1.1, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.66, fontSize: 10, color: l[3] });
    });
  }

  // =====================================================================
  section("5.1 Linguaggio naturale");
  divider("5.1", "Il linguaggio naturale come interfaccia", "Amplia l'accessibilità, ma richiede comunque obiettivi chiari e interpretazione critica delle risposte", "Nel Tema 1 abbiamo visto che il linguaggio naturale è stato uno dei fattori della svolta generativa, perché ha reso l'AI accessibile a tutti. Qui non ripercorriamo quella storia, ma guardiamo il fenomeno dal punto di vista dell'interazione: che cosa cambia, concretamente, quando parliamo con un software invece di usarne i comandi? Quali vantaggi porta, quali nuove difficoltà introduce, e come cambia il nostro rapporto con la tecnologia?");
  {
    const s = content("Dai comandi alle richieste", "Con il software tradizionale interagiamo attraverso comandi predefiniti: menu, pulsanti, campi da compilare, formule, parole chiave. Ogni comando ha un significato preciso e prevedibile, ma dobbiamo conoscerlo: sapere dove si trova la funzione, come si chiama, in che ordine compilare i campi. Il software fa esattamente ciò che chiediamo, e solo quello. Con un'interfaccia conversazionale formuliamo invece richieste in linguaggio naturale, con parole nostre, esprimendo l'obiettivo più che la sequenza di operazioni: 'confronta questi due preventivi e dimmi quale conviene per un ordine di cento pezzi'. Il sistema interpreta la richiesta e decide come soddisfarla. Il confronto in slide mostra le differenze principali. Il punto è che ci spostiamo dal 'come' al 'che cosa': non dobbiamo più sapere come si fa, ma dobbiamo saper dire che cosa vogliamo. E il sistema, interpretando, può interpretare male.");
    table(s, [["", "Comandi predefiniti", "Richieste in linguaggio naturale"], ["Che cosa esprimiamo", "Il \"come\": la sequenza di operazioni", "Il \"che cosa\": l'obiettivo"], ["Che cosa serve sapere", "Dove sono le funzioni, come si usano", "Che cosa vogliamo ottenere"], ["Significato", "Preciso e prevedibile", "Da interpretare, a volte ambiguo"], ["Flessibilità", "Solo ciò che è previsto", "Molto ampia, anche richieste nuove"], ["Esempio", "Menu, formule, campi da compilare", "\"Confronta questi preventivi per 100 pezzi\""]], { colW: [2.1, 3.45, 3.45], rowH: 0.55, accentCol: 2 });
    banner(s, 4.55, "Dal \"come si fa\" al \"che cosa voglio\": e il sistema, interpretando, può interpretare male.", { h: 0.45, fontSize: 13 });
  }
  {
    const s = content("Vantaggi e limiti della comunicazione conversazionale", "La comunicazione conversazionale porta vantaggi evidenti. Accessibilità: chiunque sappia esprimersi può usare capacità prima riservate agli specialisti. Flessibilità: si possono chiedere cose mai previste dai progettisti, combinare attività diverse, cambiare direzione a metà. Rapidità di apprendimento: non servono manuali per iniziare. Possibilità di precisare: se il risultato non va, si può spiegare che cosa cambiare, come si farebbe con un collega. Ma ha anche limiti specifici. L'ambiguità: il linguaggio umano è impreciso, e la stessa frase può essere interpretata in modi diversi. La scarsa visibilità delle funzioni: in un menu vediamo che cosa il software sa fare, in una chat no, e rischiamo di non scoprire possibilità utili o di chiedere cose che il sistema non può fare. La dipendenza dalla capacità di esprimersi: chi formula meglio ottiene di più. La facilità apparente: proprio perché è facile iniziare, si rischia di sottovalutare l'impegno necessario per ottenere risultati di qualità e per valutarli.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiThumbsUp", head: "Vantaggi", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Accessibilità: basta sapersi esprimere", "Flessibilità: anche richieste non previste", "Si inizia senza manuali", "Si può precisare come con un collega"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiAlertCircle", head: "Limiti", headSize: 16, bodySize: 13,
      body: bullets(["Ambiguità del linguaggio", "Funzioni poco visibili: non si vede che cosa il sistema sa fare", "Chi si esprime meglio ottiene di più", "Facilità apparente: iniziare è facile, ottenere qualità no"], { space: 5 }) });
  }
  {
    const s = content("Flessibilità e ambiguità del linguaggio", "La flessibilità del linguaggio umano è anche la sua debolezza. Comunichiamo bene tra persone perché condividiamo moltissimo contesto implicito: sappiamo chi è l'interlocutore, che cosa sa, a che cosa serve la richiesta. Un sistema AI conosce solo ciò che è scritto nella conversazione e nelle informazioni che gli abbiamo fornito, e riempie i vuoti con le interpretazioni più probabili. Gli esempi in slide sono richieste apparentemente chiare. 'Fammi un riassunto breve del report': breve quanto? Cinque righe o una pagina? Per chi: per la direzione o per il team tecnico? 'Rendi questa email più professionale': più formale, più sintetica, più tecnica? 'Analizza le vendite': quali aspetti, quale periodo, a quale scopo? In ciascun caso il sistema darà una risposta ragionevole, ma potrebbe non essere quella che avevamo in mente. Non è un errore del sistema: è un'ambiguità della richiesta. Due conseguenze. Primo: chiarezza degli obiettivi e contesto restano responsabilità di chi chiede, come vedremo nel 5.6. Secondo: l'ambiguità si può gestire con il dialogo, precisando dopo aver visto il primo risultato, come vedremo nel 5.2. Le tecniche per formulare richieste precise sono oggetto del Tema 6.");
    const ex = [["\"Fammi un riassunto breve del report\"", "Quanto breve? Per chi? A che scopo?"], ["\"Rendi questa email più professionale\"", "Più formale? Più sintetica? Più tecnica?"], ["\"Analizza le vendite\"", "Quali aspetti? Quale periodo? Per decidere che cosa?"]];
    ex.forEach((e, i) => {
      const y = 1.2 + i * 0.95;
      shapeBox(s, 0.5, y, 4.5, 0.8, C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 4.2, h: 0.8, fontSize: 14, italic: true, bold: true, color: C.text1, valign: "middle" });
      arrow(s, 5.1, y + 0.24, 0.35, C.accent2);
      shapeBox(s, 5.55, y, 3.95, 0.8, C.accent6, "ambiguità " + i);
      txt(s, e[1], { x: 5.75, y, w: 3.65, h: 0.8, fontSize: 13, color: C.text1, valign: "middle" });
    });
    await card(s, 0.5, 4.1, 4.35, 0.88, { inline: true, icon: "FiUser", head: "Tra persone: contesto condiviso", bodySize: 11, body: "" });
    await card(s, 5.15, 4.1, 4.35, 0.88, { inline: true, icon: "FiCpu", head: "Con l'AI: solo ciò che è scritto", bodySize: 11, fill: C.accent6, body: "" });
  }
  {
    const s = content("Testo, voce e immagini", "L'interazione conversazionale non è solo scritta. Oltre al testo, la forma più diffusa, molti sistemi permettono di interagire con la voce, parlando e ascoltando le risposte, talvolta in conversazioni fluide quasi in tempo reale; e in modo multimodale, mostrando immagini, documenti, schermate, o condividendo la fotocamera. Ogni modalità ha caratteristiche diverse per l'interazione. Il testo è preciso, si può rileggere e modificare prima di inviare, lascia traccia ed è adatto a richieste articolate e a risultati da riutilizzare. La voce è rapida e naturale, comoda quando si hanno le mani occupate o si è in movimento, ma meno precisa, più difficile da rileggere, e accentua la sensazione di parlare con una persona, un aspetto che riprenderemo nel 5.7. L'interazione multimodale permette di mostrare invece di descrivere: una foto di un guasto, un grafico, un modulo da compilare. Riduce l'ambiguità quando le parole non bastano, ma richiede attenzione a che cosa si condivide, soprattutto in ambito aziendale. La scelta della modalità dipende dall'attività: per un brainstorming in movimento la voce può essere ideale, per un documento da consegnare il testo resta più adatto.");
    const m = [["FiType", "Testo", ["Preciso, si rilegge prima di inviare", "Lascia traccia, riutilizzabile", "Adatto a richieste articolate"]], ["FiMic", "Voce", ["Rapida e naturale, a mani libere", "Meno precisa, difficile da rileggere", "Accentua la sensazione di parlare con una persona"]], ["FiImage", "Multimodale", ["Mostrare invece di descrivere", "Riduce l'ambiguità", "Attenzione a che cosa si condivide"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.0, { icon: m[i][0], head: m[i][1], headSize: 16, bodySize: 13, fill: i === 0 ? C.accent6 : C.background2, body: bullets(m[i][2], { space: 4 }) });
    banner(s, 4.35, "La modalità si sceglie in base all'attività: voce per esplorare in movimento, testo per ciò che va consegnato.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Cambia il rapporto tra utente e software", "L'interfaccia conversazionale cambia il rapporto con il software in modo più profondo di quanto sembri. Con il software tradizionale l'utente è un operatore: conosce gli strumenti, esegue le operazioni, e il software esegue esattamente ciò che gli viene detto. La responsabilità di come si fa è dell'utente. Con un sistema conversazionale l'utente diventa piuttosto un committente: esprime un obiettivo, e il sistema decide come raggiungerlo, proponendo un risultato che va valutato. Questo spostamento ha tre conseguenze. Primo, le competenze richieste cambiano: meno conoscenza dei comandi, più capacità di definire obiettivi, fornire contesto e valutare risultati. Secondo, il controllo si sposta dal processo al risultato: non vediamo tutti i passaggi con cui il sistema arriva alla risposta, quindi dobbiamo saper valutare l'esito. Terzo, la relazione assomiglia di più a quella con un collaboratore, con tutti i vantaggi e i rischi che questo comporta, compresa la tentazione di trattarlo come una persona. Come ogni committente, chi usa l'AI resta responsabile di ciò che chiede e di ciò che decide di fare con il risultato.");
    await card(s, 0.5, 1.2, 3.6, 2.6, { icon: "FiSettings", head: "Utente operatore", headSize: 16, bodySize: 13, body: "Conosce gli strumenti ed esegue le operazioni. Il software fa esattamente ciò che gli viene detto." });
    arrow(s, 4.25, 2.3, 0.55, C.accent1);
    await card(s, 4.95, 1.2, 4.55, 2.6, { icon: "FiBriefcase", head: "Utente committente", headSize: 16, bodySize: 13, fill: C.accent6, body: "Esprime un obiettivo; il sistema decide come raggiungerlo e propone un risultato da valutare." });
    const k = ["Competenze: definire obiettivi, dare contesto, valutare", "Controllo: dal processo al risultato", "Relazione: più simile a un collaboratore, con i suoi rischi"];
    k.forEach((t, i) => { shapeBox(s, 0.5 + i * 3.07, 4.0, 2.86, 0.95, C.background2, t); txt(s, t, { x: 0.65 + i * 3.07, y: 4.0, w: 2.56, h: 0.95, fontSize: 12, bold: true, color: C.text1, valign: "middle" }); });
  }
  keySlide("Il linguaggio naturale amplia l'accessibilità della tecnologia, ma richiede comunque obiettivi chiari e un'interpretazione critica delle risposte.", "Sottotema 5.1  ·  Il linguaggio naturale come interfaccia", "Concetto chiave. Con il linguaggio naturale passiamo dai comandi alle richieste, dal 'come' al 'che cosa'. Ne guadagniamo in accessibilità e flessibilità, ma il linguaggio è ambiguo, il sistema conosce solo ciò che è scritto, e l'utente diventa un committente che deve saper definire obiettivi e valutare risultati. Domanda di verifica: pensate a una richiesta che avete fatto di recente a un assistente AI e che non ha dato il risultato sperato. Era chiara per voi, ma era chiara anche senza il contesto che avevate in testa?");

  // =====================================================================
  section("5.2 Dalla domanda alla conversazione");
  divider("5.2", "Dalla domanda alla conversazione", "Una buona interazione può svilupparsi in più scambi e non richiede una richiesta iniziale perfetta", "Uno dei modi più comuni di usare un assistente AI è quello del motore di ricerca: si fa una domanda, si legge la risposta, si chiude. Ma un sistema conversazionale dà il meglio quando lo si usa come un dialogo. In questo sottotema, da comprendere bene, vediamo la differenza tra richiesta isolata e conversazione, il dialogo come processo iterativo, il valore dei chiarimenti e la possibilità, spesso trascurata, che sia l'AI a porre domande a noi. Le tecniche operative per formulare e perfezionare le richieste saranno sviluppate nel Tema 6; qui ci interessa il valore del dialogo.");
  {
    const s = content("Richiesta isolata e dialogo articolato", "Una richiesta isolata è un singolo scambio: domanda, risposta, fine. Funziona bene per bisogni semplici e ben definiti, come una traduzione, una definizione, una formula. Un dialogo articolato è una sequenza di scambi in cui la richiesta si costruisce progressivamente: si parte da un'idea, si guarda il primo risultato, si precisa, si aggiungono informazioni, si chiede un'alternativa, si approfondisce un punto. È adatto ai bisogni complessi, quelli in cui all'inizio non sappiamo ancora esattamente che cosa ci serve, o in cui il risultato ha molte dimensioni. Molte persone usano l'AI solo nel primo modo, e quando il risultato non soddisfa concludono che 'l'AI non funziona per questo'. Spesso il problema non è lo strumento, ma l'aver interrotto il dialogo troppo presto. Il concetto chiave del sottotema lo dice con chiarezza: una buona interazione può svilupparsi attraverso più scambi e non richiede una richiesta iniziale perfetta. Questo è liberatorio: non serve scrivere la richiesta ideale al primo colpo, serve saper proseguire.");
    await card(s, 0.5, 1.2, 4.35, 2.8, { icon: "FiSearch", head: "Richiesta isolata", headSize: 16, bodySize: 13,
      body: bullets(["Un solo scambio: domanda e risposta", "Adatta a bisogni semplici e definiti", "Esempi: tradurre, definire, una formula"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.8, { icon: "FiMessageSquare", head: "Dialogo articolato", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Più scambi: la richiesta si costruisce", "Adatto a bisogni complessi o ancora sfumati", "Precisare, aggiungere, chiedere alternative"], { space: 4 }) });
    banner(s, 4.2, "Spesso il problema non è lo strumento, ma aver interrotto il dialogo troppo presto.", { h: 0.75 });
  }
  {
    const s = content("Un processo progressivo e iterativo", "Possiamo descrivere il dialogo come un ciclo. Si formula una richiesta, anche imperfetta. Si valuta il risultato: che cosa va bene, che cosa manca, che cosa non corrisponde a ciò che serviva. Si precisa: si aggiungono informazioni, si correggono le interpretazioni sbagliate, si chiede di cambiare tono, struttura, livello di dettaglio. E si ripete finché il risultato è adeguato. È lo stesso modo in cui lavoriamo con un collega su un documento: prima bozza, commenti, seconda versione. Un aspetto importante: ogni iterazione è anche un momento di apprendimento per noi. Vedere un primo risultato ci aiuta spesso a capire meglio che cosa vogliamo davvero, perché le risposte rendono esplicite scelte che non avevamo considerato. Questo è uno dei vantaggi meno evidenti del dialogo. Una cautela: il ciclo ha senso finché porta miglioramenti. Se dopo diverse iterazioni il risultato non migliora, conviene fermarsi e chiedersi se il compito è adatto all'AI, se mancano informazioni fondamentali, o se è meglio ricominciare da capo con una richiesta impostata diversamente.");
    const st = [["FiEdit3", "Chiedere", "Anche in modo imperfetto"], ["FiEye", "Valutare", "Che cosa va, che cosa manca"], ["FiSliders", "Precisare", "Informazioni, correzioni, nuove indicazioni"], ["FiRepeat", "Ripetere", "Finché il risultato è adeguato"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.25, 2.05, 2.2, i === 1 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.4, 0.6, st[i][0]);
      txt(s, st[i][1], { x: x + 0.1, y: 2.1, w: 1.85, h: 0.4, fontSize: 16, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.55, w: 1.75, h: 0.8, fontSize: 12, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.07, 2.2, 0.24);
    }
    await card(s, 0.5, 3.65, 4.35, 1.3, { inline: true, icon: "FiBookOpen", head: "Si impara anche noi", bodySize: 12, body: "Il primo risultato aiuta a capire che cosa vogliamo davvero." });
    await card(s, 5.15, 3.65, 4.35, 1.3, { inline: true, icon: "FiStopCircle", head: "Sapere quando fermarsi", bodySize: 12, fill: C.accent6, body: "Se non migliora: compito adatto? Informazioni mancanti? Ricominciare?" });
  }
  {
    const s = content("Un esempio di dialogo", "Ecco un esempio di dialogo progressivo, semplificato. Una persona deve preparare una comunicazione interna sul nuovo sistema di prenotazione delle sale riunioni. Prima richiesta: 'Scrivi una comunicazione sul nuovo sistema di prenotazione delle sale'. Il sistema produce un testo generico e lungo. Seconda richiesta: la persona precisa il pubblico, tutti i dipendenti, molti dei quali non tecnici, e chiede un testo più breve. Il sistema accorcia e semplifica. Terza richiesta: la persona si accorge che manca l'informazione più importante, cioè da quando il vecchio sistema non funzionerà più, e chiede di metterla in evidenza all'inizio. Quarta: chiede tre possibili oggetti per l'email. In quattro scambi il testo è diventato adatto allo scopo, senza che la prima richiesta fosse perfetta. Notate due cose: le informazioni decisive, cioè il pubblico e la scadenza, le ha portate la persona; e il risultato finale andrà comunque riletto prima dell'invio. Suggerimento: se possibile, mostrare un dialogo simile dal vivo.");
    dialog(s, 0.5, 1.2, 6.0, [["P", "Scrivi una comunicazione sul nuovo sistema di prenotazione delle sale."], ["A", "Testo generico e lungo, con molti dettagli tecnici."], ["P", "È per tutti i dipendenti, molti non tecnici: più breve e semplice."], ["A", "Versione più breve e chiara."], ["P", "Metti in evidenza all'inizio che dal 1° marzo il vecchio sistema non funzionerà."], ["P", "Proponi tre possibili oggetti per l'email."]], { lh: 0.5, gap: 0.12 });
    await card(s, 6.8, 1.2, 2.7, 1.85, { head: "Le informazioni decisive", headSize: 14, bodySize: 12, body: "Pubblico e scadenza li ha portati la persona." });
    await card(s, 6.8, 3.2, 2.7, 1.75, { head: "Prima di inviare", headSize: 14, bodySize: 12, fill: C.accent6, body: "Il testo finale va comunque riletto e verificato." });
  }
  {
    const s = content("Il contesto della conversazione", "Durante un dialogo si accumulano informazioni: il pubblico, l'obiettivo, i vincoli, le correzioni, le preferenze espresse. Questo contesto conversazionale è una risorsa: non serve ripetere tutto a ogni richiesta, perché il sistema tiene conto di ciò che è già stato detto, come abbiamo visto nel Tema 2. Un buon dialogo sfrutta questa risorsa, costruendo progressivamente un quadro sempre più preciso. Ci sono però tre situazioni in cui il contesto diventa un ostacolo. Quando si cambia argomento: informazioni e impostazioni di un compito precedente possono influenzare quello nuovo in modo indesiderato. Quando la conversazione diventa molto lunga: le informazioni iniziali possono perdere peso. Quando all'inizio si è presa una strada sbagliata: un'impostazione errata continua a condizionare le risposte, anche dopo averla corretta. In questi casi, la scelta migliore è spesso aprire una nuova conversazione, riportando in modo sintetico solo le informazioni utili emerse fino a quel momento. Un'abitudine pratica: una conversazione per ogni attività.");
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiLayers", head: "Una risorsa", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Pubblico, obiettivi, vincoli, correzioni restano nel dialogo", "Non serve ripetere tutto", "Il quadro si precisa scambio dopo scambio"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiAlertTriangle", head: "Quando diventa un ostacolo", headSize: 16, bodySize: 13,
      body: bullets(["Si cambia argomento", "La conversazione è molto lunga", "All'inizio si è presa una strada sbagliata"], { space: 3 }) });
    banner(s, 3.8, "In questi casi: nuova conversazione, riportando in sintesi solo ciò che serve.", { h: 0.6 });
    txt(s, "Un'abitudine pratica: una conversazione per ogni attività.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("L'AI come interlocutore che può porre domande", "Questa integrazione del sottotema riguarda una possibilità spesso trascurata: non siamo solo noi a fare domande. Possiamo chiedere al sistema di porci domande prima di procedere, per chiarire le nostre esigenze. Per esempio: 'Devo preparare un piano di formazione per i nuovi assunti. Prima di proporre qualcosa, fammi le domande che ti servono per capire bene la situazione'. Il sistema chiederà, plausibilmente, quante persone, quali ruoli, quanto tempo, quali competenze di partenza, quali vincoli di budget. Molte di queste domande ci costringeranno a esplicitare assunzioni che davamo per scontate, o a scoprire informazioni che non avevamo considerato. Alcuni sistemi pongono domande di chiarimento anche spontaneamente, quando la richiesta è ambigua. Il valore è triplice: chiarire le esigenze, esplicitare le assunzioni, individuare le informazioni mancanti. Ma c'è un limite importante, sottolineato dal documento di perimetro: il sistema può aiutare a definire gli obiettivi, non sostituirsi alla persona nel deciderli. Le domande dell'AI sono un aiuto al nostro ragionamento; le risposte, e quindi le scelte, restano nostre.");
    dialog(s, 0.5, 1.2, 5.4, [["P", "Devo preparare un piano di formazione per i nuovi assunti. Prima di proporre, fammi le domande che ti servono.", 0.75], ["A", "Quante persone? Quali ruoli? Quanto tempo? Competenze di partenza? Budget?", 0.75]], { gap: 0.15 });
    const v = [["FiHelpCircle", "Chiarire le esigenze"], ["FiEye", "Esplicitare le assunzioni"], ["FiSearch", "Individuare informazioni mancanti"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.2 + i * 0.75;
      await iconCircle(s, 6.2, y, 0.5, v[i][0]);
      txt(s, v[i][1], { x: 6.85, y, w: 2.65, h: 0.5, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
    }
    shapeBox(s, 0.5, 3.35, 9.0, 1.6, C.text1, "limite domande");
    await iconCircle(s, 0.75, 3.8, 0.65, "FiUserCheck", C.accent1);
    txt(s, [{ text: "L'AI aiuta a definire gli obiettivi, non li decide. ", options: { bold: true, color: C.background1 } }, { text: "Le domande del sistema sono un aiuto al nostro ragionamento; le risposte, e quindi le scelte, restano nostre.", options: { color: C.accent3 } }], { x: 1.6, y: 3.35, w: 7.7, h: 1.6, fontSize: 15, valign: "middle" });
  }
  {
    const s = content("L'AI come supporto alla definizione dei problemi", "Estendiamo l'idea della slide precedente. Spesso la parte più difficile di un'attività non è risolvere il problema, ma capire qual è il problema. L'AI può essere un buon supporto in questa fase, perché ci obbliga a mettere in parole ciò che è ancora confuso, e perché può proporre prospettive diverse. Alcuni modi di usarla: chiedere di riformulare il problema in modi diversi, per vedere se ne emerge uno più utile; chiedere quali potrebbero essere le cause di una situazione, prima di cercare soluzioni; chiedere di distinguere tra sintomi e problema; chiedere quali informazioni servirebbero per decidere; chiedere quali obiettivi potrebbero essere in conflitto tra loro. Per esempio, prima di chiedere 'come riduco i reclami dei clienti?', si può chiedere 'aiutami a capire quali tipi di problemi potrebbero esserci dietro l'aumento dei reclami e quali dati mi servirebbero per distinguerli'. La conversazione diventa uno strumento per pensare meglio, non solo per ottenere risposte. Anche qui vale il limite: la definizione finale del problema e degli obiettivi spetta alla persona, che conosce la situazione reale.");
    const u = [["FiRefreshCw", "Riformulare il problema in modi diversi"], ["FiGitBranch", "Esplorare le possibili cause prima delle soluzioni"], ["FiFilter", "Distinguere sintomi e problema"], ["FiDatabase", "Individuare le informazioni necessarie per decidere"], ["FiShuffle", "Far emergere obiettivi in conflitto"]];
    for (let i = 0; i < 5; i++) {
      const y = 1.15 + i * 0.62;
      shapeBox(s, 0.5, y, 4.6, 0.54, i % 2 ? C.background1 : C.background2, u[i][1]);
      await iconCircle(s, 0.6, y + 0.06, 0.42, u[i][0]);
      txt(s, u[i][1], { x: 1.15, y, w: 3.9, h: 0.54, fontSize: 12, color: C.text1, valign: "middle" });
    }
    await card(s, 5.4, 1.15, 4.1, 2.95, { head: "Esempio", headSize: 14, bodySize: 13, fill: C.accent6,
      body: [{ text: "Invece di: ", options: { bold: true, color: C.text2 } }, { text: "\"Come riduco i reclami dei clienti?\"", options: { italic: true, breakLine: true, paraSpaceAfter: 10 } }, { text: "Prima: ", options: { bold: true, color: C.accent1 } }, { text: "\"Aiutami a capire quali problemi potrebbero esserci dietro l'aumento dei reclami e quali dati mi servirebbero per distinguerli.\"", options: { italic: true } }] });
    txt(s, "La conversazione come strumento per pensare meglio, non solo per ottenere risposte.", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Una buona interazione può svilupparsi attraverso più scambi e non richiede una richiesta iniziale perfetta.", "Sottotema 5.2  ·  Dalla domanda alla conversazione", "Concetto chiave. Il dialogo è un processo iterativo: chiedere, valutare, precisare, ripetere. Il contesto della conversazione è una risorsa, ma a volte conviene ricominciare. L'AI può anche porci domande, aiutandoci a chiarire esigenze, assunzioni e informazioni mancanti, e può supportare la definizione dei problemi, senza sostituirsi alla persona nel decidere gli obiettivi. Domanda di verifica: la prossima volta che dovete affrontare un compito poco definito, come potreste iniziare la conversazione con l'AI? Una possibile risposta: descrivere la situazione e chiedere al sistema quali domande farebbe per capirla meglio.");

  // =====================================================================
  section("5.3 I ruoli dell'AI");
  divider("5.3", "I diversi ruoli che l'AI può assumere", "Assegnare un ruolo può orientare il comportamento dell'AI, ma non garantisce che abbia le competenze richieste", "Uno stesso assistente AI può essere usato in modi molto diversi: come fonte di spiegazioni, come assistente operativo, come compagno di brainstorming, come revisore, come tutor, come interlocutore critico. In questo sottotema passiamo in rassegna questi ruoli, con i loro punti di forza e le loro cautele, e affrontiamo una distinzione importante: quella tra il ruolo che assegniamo al sistema e la competenza che effettivamente possiede. Non confrontiamo prodotti o architetture, che sono temi del Tema 4.");
  {
    const s = content("Sette ruoli possibili", "Ecco i sette ruoli indicati dal documento di perimetro. Fonte di informazioni e spiegazioni: spiegare un concetto, chiarire un termine, dare una panoramica su un argomento. Assistente operativo: svolgere compiti concreti come scrivere bozze, riformulare, tradurre, organizzare informazioni. Supporto creativo e al brainstorming: generare idee, alternative, nomi, spunti. Analista e supporto al problem solving: analizzare dati e documenti, scomporre problemi, confrontare opzioni. Revisore di contenuti e risultati: rileggere un testo, segnalare errori, incoerenze, punti deboli. Tutor e supporto all'apprendimento: spiegare passo passo, proporre esercizi, adattare la spiegazione al livello della persona. Interlocutore critico: proporre controargomentazioni, alternative, obiezioni. Molte interazioni combinano più ruoli, e passare consapevolmente da un ruolo all'altro è una delle abilità di chi usa bene l'AI. Nelle prossime slide vediamo per ciascun ruolo un esempio e la principale cautela. Suggerimento: chiedere ai partecipanti quali ruoli usano già e quali non avevano considerato.");
    const r = [["FiBookOpen", "Fonte di informazioni"], ["FiBriefcase", "Assistente operativo"], ["FiZap", "Supporto creativo"], ["FiBarChart2", "Analista"], ["FiCheckSquare", "Revisore"], ["FiAward", "Tutor"], ["FiMessageCircle", "Interlocutore critico"]];
    for (let i = 0; i < 7; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = row === 0 ? 0.5 + col * 2.3 : 1.65 + col * 2.3, y = 1.2 + row * 1.7;
      shapeBox(s, x, y, 2.15, 1.5, i === 6 ? C.accent1 : C.background2, r[i][1]);
      await iconCircle(s, x + 0.78, y + 0.18, 0.6, r[i][0], i === 6 ? C.background1 : C.accent1, i === 6 ? HEX.a1 : HEX.lt1);
      txt(s, r[i][1], { x: x + 0.1, y: y + 0.88, w: 1.95, h: 0.5, fontSize: 14, bold: true, color: i === 6 ? C.background1 : C.text1, align: "center", valign: "middle" });
    }
    txt(s, "Molte interazioni combinano più ruoli.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Fonte, assistente operativo, supporto creativo", "Vediamo i primi tre ruoli. Come fonte di informazioni e spiegazioni, l'AI è molto efficace per orientarsi su un argomento nuovo, capire un concetto, ottenere una panoramica. Esempio: 'Spiegami in termini semplici che cos'è il bilancio di sostenibilità'. Cautela: è il ruolo più esposto alle informazioni inesatte viste nel Tema 3; per fatti, dati e riferimenti precisi servono fonti verificabili. Come assistente operativo, l'AI svolge compiti concreti: 'Trasforma questi appunti in un verbale ordinato'. È il ruolo più diffuso e spesso il più immediatamente utile. Cautela: il risultato è una bozza, non un prodotto finito, e chi la usa ne è responsabile. Come supporto creativo, l'AI aiuta a generare idee e alternative: 'Proponi dieci idee per un evento interno di fine anno con budget contenuto'. Cautela: come abbiamo visto, le idee tendono al convenzionale; vanno considerate materiale grezzo da selezionare e sviluppare, preferibilmente insieme ad altre persone.");
    const r = [["FiBookOpen", "Fonte di informazioni", "\"Spiegami in termini semplici che cos'è il bilancio di sostenibilità.\"", "Per fatti e dati precisi servono fonti verificabili"], ["FiBriefcase", "Assistente operativo", "\"Trasforma questi appunti in un verbale ordinato.\"", "È una bozza: chi la usa ne è responsabile"], ["FiZap", "Supporto creativo", "\"Proponi dieci idee per un evento interno con budget contenuto.\"", "Idee spesso convenzionali: materiale grezzo da sviluppare"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.2, 2.86, 3.75, { icon: r[i][0], head: r[i][1], headSize: 15, bodySize: 12,
        body: [{ text: "Esempio", options: { bold: true, color: C.accent1, breakLine: true } }, { text: r[i][2], options: { italic: true, breakLine: true, paraSpaceAfter: 12 } }, { text: "Cautela", options: { bold: true, color: C.accent5, breakLine: true } }, { text: r[i][3], options: {} }] });
    }
  }
  {
    const s = content("Analista, revisore, tutor", "Altri tre ruoli. Come analista e supporto al problem solving, l'AI aiuta a esaminare dati e documenti, a scomporre problemi, a confrontare opzioni: 'Confronta questi tre contratti e evidenzia le differenze sulle clausole di recesso'. Cautela: le conclusioni dipendono dalle informazioni fornite e dai criteri, espliciti o impliciti; vanno verificate. Come revisore, l'AI rilegge un contenuto e segnala errori, incoerenze, punti poco chiari: 'Rileggi questa offerta e segnala i passaggi ambigui o in contraddizione'. È un ruolo prezioso, perché uno sguardo esterno aiuta a vedere ciò che chi scrive non vede più. Cautela: la revisione non è esaustiva; il sistema può non accorgersi di alcuni errori e segnalarne altri inesistenti. Come tutor, l'AI supporta l'apprendimento: spiega passo passo, adatta il livello, propone esercizi, verifica la comprensione: 'Insegnami le basi delle tabelle pivot con esempi graduali'. Cautela: se si delega tutto, si impara poco; per imparare davvero bisogna provare in prima persona, un tema che riprenderemo nel 5.7 parlando di delega cognitiva.");
    const r = [["FiBarChart2", "Analista", "\"Confronta questi tre contratti sulle clausole di recesso.\"", "Conclusioni legate a informazioni e criteri: verificare"], ["FiCheckSquare", "Revisore", "\"Rileggi questa offerta e segnala passaggi ambigui o in contraddizione.\"", "Revisione non esaustiva: può mancare errori o segnalarne di inesistenti"], ["FiAward", "Tutor", "\"Insegnami le basi delle tabelle pivot con esempi graduali.\"", "Se si delega tutto, si impara poco: provare in prima persona"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.2, 2.86, 3.75, { icon: r[i][0], head: r[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2,
        body: [{ text: "Esempio", options: { bold: true, color: C.accent1, breakLine: true } }, { text: r[i][2], options: { italic: true, breakLine: true, paraSpaceAfter: 12 } }, { text: "Cautela", options: { bold: true, color: C.accent5, breakLine: true } }, { text: r[i][3], options: {} }] });
    }
  }
  {
    const s = content("L'AI come strumento di confronto critico", "Questa integrazione del sottotema merita una slide dedicata, perché è uno degli usi più preziosi e meno praticati. Come abbiamo visto nel Tema 3, i sistemi AI tendono ad assecondare l'utente. Ma possiamo chiedere esplicitamente il contrario: usare l'AI per mettere alla prova un'ipotesi, non per confermarla. Ecco alcuni modi. L'avvocato del diavolo: 'Ecco la mia proposta: costruisci gli argomenti più forti contro di essa'. Il pre-mortem: 'Immagina che questo progetto sia fallito tra un anno: quali sono le cause più probabili?'. Le prospettive diverse: 'Come valuterebbero questa decisione un cliente, un fornitore e un collega dell'amministrazione?'. Le alternative: 'Quali altre strade potrei considerare per raggiungere lo stesso obiettivo?'. Le assunzioni nascoste: 'Quali assunzioni sto dando per scontate in questo ragionamento?'. Questi usi aiutano a contrastare il nostro bias di conferma e a migliorare la qualità delle decisioni. Un'avvertenza: anche le critiche dell'AI vanno valutate. Non tutte saranno pertinenti, e il sistema può produrre obiezioni plausibili ma deboli. Il valore sta nello stimolo al ragionamento, non nell'autorità delle obiezioni.");
    const r = [["FiShield", "Avvocato del diavolo", "\"Costruisci gli argomenti più forti contro la mia proposta.\""], ["FiAlertTriangle", "Pre-mortem", "\"Immagina che il progetto sia fallito: quali le cause più probabili?\""], ["FiUsers", "Prospettive diverse", "\"Come la valuterebbero un cliente, un fornitore, l'amministrazione?\""], ["FiShuffle", "Alternative", "\"Quali altre strade per lo stesso obiettivo?\""], ["FiEye", "Assunzioni nascoste", "\"Che cosa sto dando per scontato?\""]];
    for (let i = 0; i < 5; i++) {
      const y = 1.15 + i * 0.66;
      shapeBox(s, 0.5, y, 9.0, 0.58, i % 2 ? C.background1 : C.background2, r[i][1]);
      await iconCircle(s, 0.6, y + 0.07, 0.44, r[i][0]);
      txt(s, r[i][1], { x: 1.2, y, w: 2.6, h: 0.58, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, r[i][2], { x: 3.85, y, w: 5.55, h: 0.58, fontSize: 12, italic: true, color: C.text2, valign: "middle" });
    }
    banner(s, 4.5, "Anche le critiche dell'AI vanno valutate: il valore sta nello stimolo al ragionamento.", { h: 0.5, fontSize: 13 });
  }
  {
    const s = content("Ruolo assegnato e competenza effettiva", "Una pratica molto diffusa è assegnare un ruolo all'AI: 'Sei un avvocato esperto di diritto del lavoro', 'Agisci come un consulente finanziario', 'Sei un revisore severo'. Funziona? In parte sì: assegnare un ruolo orienta il comportamento del sistema, cioè il tono, il lessico, il livello di dettaglio, la prospettiva da cui affronta il problema, gli aspetti a cui presta attenzione. È utile e la riprenderemo nel Tema 6. Ma c'è una distinzione fondamentale: assegnare un ruolo non conferisce competenze. Dire al sistema che è un avvocato non gli dà la conoscenza aggiornata della normativa, la capacità di valutare il caso concreto, l'esperienza delle prassi dei tribunali, né la responsabilità professionale di un avvocato. Il sistema produrrà testi nello stile di un avvocato, con la stessa affidabilità, e gli stessi limiti, che avrebbe senza quel ruolo, su quell'argomento. Il rischio è che lo stile professionale aumenti la nostra fiducia, ricadendo nell'autorevolezza apparente vista nel Tema 3. Per questo, nei ruoli che richiedono competenze specialistiche, la consulenza di un professionista reale resta necessaria quando le conseguenze sono rilevanti.");
    await card(s, 0.5, 1.2, 4.35, 2.9, { icon: "FiCheckCircle", head: "Il ruolo orienta", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Tono e lessico", "Livello di dettaglio", "Prospettiva e aspetti considerati"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.9, { icon: "FiXCircle", head: "Il ruolo non conferisce", headSize: 16, bodySize: 13, iconBg: C.accent5,
      body: bullets(["Conoscenze aggiornate e verificate", "Capacità di valutare il caso concreto", "Esperienza e responsabilità professionale"], { space: 4 }) });
    banner(s, 4.3, "\"Sei un avvocato esperto\" produce testi nello stile di un avvocato, non la competenza di un avvocato.", { h: 0.65, fontSize: 13 });
  }
  keySlide("Assegnare un ruolo all'AI può orientarne il comportamento, ma non garantisce che abbia le competenze richieste.", "Sottotema 5.3  ·  I diversi ruoli che l'AI può assumere", "Concetto chiave. L'AI può essere fonte, assistente operativo, supporto creativo, analista, revisore, tutor e interlocutore critico, ciascuno con i suoi punti di forza e le sue cautele. Il ruolo di interlocutore critico è particolarmente prezioso per mettere alla prova le nostre idee invece di confermarle. E assegnare un ruolo orienta il comportamento, non crea competenze. Domanda di verifica: avete una proposta da presentare alla direzione. Come potete usare l'AI in almeno tre ruoli diversi per migliorarla? Possibile risposta: revisore per chiarezza e coerenza, interlocutore critico per le obiezioni, supporto creativo per alternative di presentazione.");

  // =====================================================================
  section("5.4 La collaborazione uomo-AI");
  divider("5.4", "La collaborazione uomo-AI", "Il valore può nascere dalla combinazione delle capacità del sistema con quelle della persona, senza sostituire il giudizio umano", "Un sottotema da comprendere bene. Dopo aver visto i ruoli possibili, analizziamo il processo: come si collabora con l'AI in un'attività, come si dividono i compiti, perché le capacità umane e quelle del sistema sono complementari, e perché la responsabilità sulla validazione e sull'uso del risultato resta della persona. Non anticipiamo la riprogettazione dei processi e dei ruoli organizzativi, che appartiene all'area aziendale: qui parliamo della collaborazione nel lavoro della singola persona.");
  {
    const s = content("Ottenere una risposta o collaborare", "C'è una differenza sostanziale tra ottenere una risposta e collaborare a un'attività. Nel primo caso si chiede, si riceve, si usa: l'AI è un fornitore di risultati. Nel secondo caso si lavora insieme su un obiettivo, in più passaggi, ciascuno contribuendo con ciò che sa fare meglio: la persona porta gli obiettivi, il contesto, il giudizio; il sistema porta velocità, ampiezza, capacità di generare e riorganizzare. Il risultato finale è il prodotto di questa combinazione, e spesso è migliore di ciò che ciascuno avrebbe ottenuto da solo. Due esempi sullo stesso compito, preparare un'analisi dei feedback dei clienti. Modalità 'risposta': si incollano i feedback e si chiede 'analizzali', poi si copia il risultato. Modalità 'collaborazione': la persona definisce le domande a cui l'analisi deve rispondere, il sistema propone una prima classificazione, la persona la corregge in base alla conoscenza dei prodotti, il sistema conta e sintetizza, la persona verifica alcuni casi e trae le conclusioni. Il secondo modo richiede più impegno, ma produce un'analisi più affidabile e utile, di cui la persona è davvero padrona.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiDownload", head: "Ottenere una risposta", headSize: 16, bodySize: 12,
      body: [{ text: "L'AI fornisce un risultato", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Esempio: ", options: { bold: true, color: C.accent2 } }, { text: "si incollano i feedback dei clienti, si chiede \"analizzali\", si copia il risultato.", options: {} }] });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiUsers", head: "Collaborare", headSize: 16, bodySize: 12, fill: C.accent6,
      body: [{ text: "Si lavora insieme, ognuno con ciò che sa fare meglio", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["La persona definisce le domande", "L'AI propone una classificazione", "La persona la corregge con la sua conoscenza", "L'AI conta e sintetizza", "La persona verifica e conclude"], { space: 2 })) });
  }
  {
    const s = content("Suddividere le attività tra persona e sistema", "Collaborare significa anche decidere chi fa che cosa. Possiamo scomporre una tipica attività di lavoro intellettuale in fasi e chiederci, per ciascuna, quale contributo può dare l'AI e quale resta alla persona. La tabella ne propone un esempio indicativo. Definire l'obiettivo e i criteri di qualità: è un compito della persona; l'AI può aiutare con domande, come abbiamo visto. Raccogliere e organizzare le informazioni: l'AI è un supporto efficace, la persona sceglie le fonti e ne verifica la pertinenza. Produrre una prima versione: qui l'AI dà spesso il contributo maggiore, su indicazione della persona. Rivedere e migliorare: lavoro congiunto, con l'AI come revisore e interlocutore critico e la persona che decide quali modifiche accettare. Validare e decidere l'uso: compito esclusivo della persona, che ne porta la responsabilità. Il messaggio è che l'AI tende a contribuire di più nelle fasi centrali, mentre l'inizio, cioè gli obiettivi, e la fine, cioè la validazione, restano saldamente umani.");
    table(s, [["Fase", "Contributo dell'AI", "Contributo della persona"], ["Definire obiettivo e criteri", "Domande di chiarimento", "Decide obiettivi e criteri"], ["Raccogliere e organizzare", "Supporto efficace", "Sceglie le fonti, verifica la pertinenza"], ["Produrre una prima versione", "Spesso il contributo maggiore", "Fornisce indicazioni e contesto"], ["Rivedere e migliorare", "Revisore e interlocutore critico", "Decide quali modifiche accettare"], ["Validare e decidere l'uso", "Nessuno", "Responsabilità esclusiva"]], { colW: [2.8, 3.1, 3.1], rowH: 0.55, accentCol: 2, blankCorner: false });
    banner(s, 4.55, "L'AI contribuisce soprattutto nelle fasi centrali; obiettivi e validazione restano umani.", { h: 0.45, fontSize: 13 });
  }
  {
    const s = content("Capacità complementari", "Perché la collaborazione può dare risultati migliori di ciascuno dei due da solo? Perché persona e sistema hanno capacità diverse e complementari. Il sistema AI è veloce, può elaborare grandi quantità di testo in pochi secondi, ha una conoscenza ampia anche se non sempre precisa, genera molte alternative, non si stanca, è costante nello stile e disponibile in ogni momento. La persona conosce il contesto reale, l'organizzazione, le persone, la storia, i vincoli non scritti; ha competenze di dominio e esperienza; sa giudicare che cosa è rilevante e che cosa no; comprende le conseguenze delle scelte; ha valori, responsabilità e la capacità di decidere; e sa accorgersi quando qualcosa non torna. La collaborazione funziona quando ciascuno porta ciò che sa fare meglio. Funziona male quando si chiede all'AI di fare ciò che solo la persona può fare, come decidere obiettivi o giudicare l'adeguatezza al contesto, oppure quando la persona si limita a fare ciò che l'AI farebbe meglio, rinunciando al suo valore aggiunto.");
    await card(s, 0.5, 1.2, 4.35, 3.0, { icon: "FiCpu", head: "Il sistema AI", headSize: 16, bodySize: 13,
      body: bullets(["Velocità e grandi quantità di testo", "Conoscenza ampia, non sempre precisa", "Molte alternative, costanza", "Sempre disponibile"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 3.0, { icon: "FiUser", head: "La persona", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Contesto reale, vincoli non scritti", "Competenza di dominio ed esperienza", "Giudizio su rilevanza e conseguenze", "Valori, responsabilità, decisione"], { space: 3 }) });
    banner(s, 4.35, "Funziona quando ciascuno porta ciò che sa fare meglio.", { h: 0.6 });
  }
  {
    const s = content("Produrre, rivedere, migliorare", "Uno dei modi più comuni di collaborare con l'AI riguarda i contenuti: testi, presentazioni, analisi, piani. Possiamo vederla come un ciclo in cui persona e sistema si alternano. La persona imposta: obiettivo, pubblico, punti chiave, materiali. L'AI produce una prima versione. La persona valuta e commenta: che cosa funziona, che cosa manca, che cosa è sbagliato. L'AI rivede secondo le indicazioni, oppure propone a sua volta osservazioni critiche, nel ruolo di revisore. La persona decide e rifinisce, e alla fine valida. Il ciclo può anche partire dalla persona: si scrive una propria bozza e si chiede all'AI di rivederla, migliorarla o metterla alla prova. Questo secondo modo ha un vantaggio importante: il pensiero di partenza è della persona, e l'AI lo arricchisce invece di sostituirlo. È spesso la scelta migliore quando il contenuto deve esprimere una posizione personale o una competenza specifica, o quando conta mantenere e sviluppare le proprie capacità, come vedremo nel 5.7.");
    const st = [["Persona", "Imposta obiettivo, pubblico, punti chiave", C.background2, C.text1], ["AI", "Produce una prima versione", C.accent6, C.text1], ["Persona", "Valuta e commenta", C.background2, C.text1], ["AI", "Rivede o propone osservazioni critiche", C.accent6, C.text1], ["Persona", "Decide, rifinisce, valida", C.accent1, C.background1]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.3, 1.68, 1.9, st[i][2], "fase " + i);
      txt(s, st[i][0], { x: x + 0.1, y: 1.4, w: 1.48, h: 0.4, fontSize: 15, bold: true, color: i === 4 ? C.background1 : C.accent1, align: "center" });
      txt(s, st[i][1], { x: x + 0.12, y: 1.85, w: 1.44, h: 1.25, fontSize: 12, color: st[i][3], align: "center" });
    }
    await card(s, 0.5, 3.45, 9.0, 1.5, { inline: true, icon: "FiEdit", head: "Si può partire anche dalla persona", bodySize: 13, fill: C.background2, body: "Scrivere una propria bozza e chiedere all'AI di rivederla o metterla alla prova: il pensiero di partenza resta nostro e l'AI lo arricchisce." });
  }
  {
    const s = content("Supporto al ragionamento e alla valutazione", "La collaborazione con l'AI non serve solo a produrre più velocemente: può migliorare la qualità del ragionamento e delle decisioni. È il senso dell'integrazione C, che ritroviamo qui. Alcuni esempi concreti. Prima di una decisione, chiedere all'AI di elencare i criteri che potrebbero essere rilevanti, per verificare di non averne dimenticato qualcuno. Chiedere di confrontare le opzioni secondo quei criteri, evidenziando i compromessi. Chiedere quali informazioni potrebbero far cambiare la valutazione. Chiedere gli argomenti contrari alla scelta che si sta per fare. Chiedere di riformulare il proprio ragionamento in modo strutturato, per individuarne i punti deboli. In tutti questi casi l'AI non decide: amplia e struttura il campo di ciò che la persona considera. Le persone tendono a valutare le opzioni che vengono loro in mente per prime e a cercare conferme; un interlocutore che propone sistematicamente criteri, alternative e obiezioni aiuta a contrastare queste tendenze. Il beneficio non si vede nella velocità, ma nella qualità e nella solidità della decisione.");
    const e = [["FiList", "Criteri dimenticati", "Quali criteri potrebbero essere rilevanti?"], ["FiSliders", "Compromessi", "Confronta le opzioni secondo questi criteri"], ["FiInfo", "Informazioni decisive", "Che cosa potrebbe cambiare la valutazione?"], ["FiShield", "Argomenti contrari", "Quali obiezioni alla scelta che sto per fare?"], ["FiGitBranch", "Punti deboli", "Riformula il mio ragionamento in modo strutturato"]];
    await iconGrid(s, e.slice(0, 3).map(x => ({ icon: x[0], head: x[1], body: "\"" + x[2] + "\"" })), 3, { y: 1.2, h: 1.4, headSize: 14 });
    await iconGrid(s, e.slice(3).map(x => ({ icon: x[0], head: x[1], body: "\"" + x[2] + "\"" })), 2, { y: 2.8, h: 1.25, headSize: 14 });
    banner(s, 4.25, "L'AI non decide: amplia e struttura ciò che la persona considera. Il beneficio è nella qualità della decisione.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Competenze, contesto e responsabilità", "Due elementi rendono possibile una buona collaborazione, e uno la chiude. Le competenze professionali: senza conoscenza del dominio non si sa che cosa chiedere, non si riconoscono gli errori, non si sa quali suggerimenti accettare. L'AI amplifica le competenze di chi la usa, ma non le sostituisce: nelle mani di un esperto è uno strumento potente, nelle mani di chi non conosce l'argomento può diventare una fonte di errori non riconosciuti. Il contesto: obiettivi, vincoli, pubblico, storia, persone coinvolte. Il sistema lo conosce solo nella misura in cui gli viene fornito, ed è la persona a doverlo portare nella collaborazione. E infine la responsabilità: qualunque sia stato il contributo dell'AI, la validazione e l'uso del risultato finale spettano alla persona. È lei che decide se il risultato è adeguato, se va corretto, se può essere inviato, presentato, usato per decidere. Riprendiamo un principio già incontrato nel Tema 3: 'l'ha scritto l'AI' non è una giustificazione. Le procedure di verifica degli output saranno sviluppate nel Tema 7.");
    const c = [["FiAward", "Competenze professionali", "Sapere che cosa chiedere, riconoscere gli errori, scegliere i suggerimenti. L'AI amplifica, non sostituisce.", C.background2], ["FiMap", "Contesto", "Obiettivi, vincoli, pubblico, storia: il sistema li conosce solo se la persona li porta.", C.background2], ["FiUserCheck", "Responsabilità", "Validazione e uso del risultato spettano alla persona. \"L'ha scritto l'AI\" non è una giustificazione.", C.accent6]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.75, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 13, fill: c[i][3], body: c[i][2] });
  }
  keySlide("Il valore dell'AI può nascere dalla combinazione delle capacità del sistema con quelle della persona, senza implicare la sostituzione del giudizio umano.", "Sottotema 5.4  ·  La collaborazione uomo-AI", "Concetto chiave. Collaborare è diverso dall'ottenere una risposta: si suddividono le fasi, si combinano capacità complementari, si alternano produzione e revisione. La collaborazione può migliorare non solo la velocità, ma la qualità del ragionamento e delle decisioni. Le competenze e il contesto della persona sono la condizione per una buona collaborazione, e la responsabilità finale resta sua. Domanda di verifica: scegliete un'attività ricorrente del vostro lavoro. Quali fasi affidereste all'AI, quali terreste per voi, e perché?");

  // =====================================================================
  section("5.5 Livelli di delega");
  divider("5.5", "I livelli di delega all'Intelligenza Artificiale", "Il livello di delega deve essere adeguato al compito, alle capacità del sistema, ai rischi e ai controlli disponibili", "Un sottotema da comprendere bene, il cui obiettivo è la consapevolezza decisionale. Nel 5.4 abbiamo parlato della distribuzione del lavoro; qui parliamo del grado di autonomia che affidiamo al sistema. Proponiamo una scala di livelli di delega, dal semplice uso informativo all'esecuzione con maggiore autonomia. Una nota didattica importante, indicata dal documento di perimetro: i livelli sono una classificazione illustrativa, non uno standard tecnico, e non sono una progressione obbligatoria. Non bisogna arrivare all'ultimo livello: bisogna scegliere quello adatto. La progettazione di agenti e workflow sarà trattata nel tema dedicato.");
  {
    const s = content("Cinque livelli di delega", "Ecco i cinque livelli. Primo, l'AI come strumento informativo: fornisce informazioni e spiegazioni, la persona le usa come vuole. Secondo, l'AI come supporto e suggeritore: propone idee, opzioni, correzioni; la persona sceglie e realizza. Terzo, l'AI come collaboratore nella produzione: produce parti significative del risultato, come bozze o analisi, che la persona rivede, integra e valida. Quarto, la delega con supervisione: l'AI svolge un'attività per intero, e la persona controlla il risultato prima che venga usato. Quinto, l'esecuzione con maggiore autonomia entro vincoli e autorizzazioni: l'AI svolge attività, anche in più passaggi e con azioni concrete, entro limiti definiti; la persona stabilisce i vincoli, monitora e interviene su eccezioni. Ripetiamo la nota didattica: è una classificazione illustrativa, utile per ragionare, non uno standard tecnico. E non è una scala di maturità: un uso al primo livello non è 'meno evoluto' di uno al quinto. Per molte attività, il livello più adatto è proprio il secondo o il terzo.");
    const lv = [["1", "Strumento informativo", "Fornisce informazioni e spiegazioni"], ["2", "Supporto e suggeritore", "Propone; la persona sceglie e realizza"], ["3", "Collaboratore", "Produce parti del risultato; la persona rivede e valida"], ["4", "Delega con supervisione", "Svolge l'attività; la persona controlla prima dell'uso"], ["5", "Autonomia entro vincoli", "Agisce entro limiti; la persona monitora ed eccezioni"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84, h = 1.6 + i * 0.35, y = 4.35 - h;
      shapeBox(s, x, y, 1.68, h, i === 4 ? C.accent1 : (i >= 2 ? C.accent6 : C.background2), "livello " + lv[i][0]);
      txt(s, lv[i][0], { x: x + 0.12, y: y + 0.08, w: 0.6, h: 0.45, fontSize: 22, bold: true, color: i === 4 ? C.background1 : C.accent1 });
      txt(s, lv[i][1], { x: x + 0.12, y: y + 0.55, w: 1.48, h: 0.6, fontSize: 13, bold: true, color: i === 4 ? C.background1 : C.text1 });
      txt(s, lv[i][2], { x: x + 0.12, y: y + 1.15, w: 1.48, h: h - 1.2, fontSize: 11, color: i === 4 ? C.accent6 : C.text2 });
    }
    txt(s, "Classificazione illustrativa, non uno standard tecnico né una progressione obbligatoria.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Che cosa fanno l'AI e la persona a ogni livello", "Questa tabella dettaglia, per ciascun livello, il ruolo dell'AI, il ruolo della persona e un esempio. Al primo livello, l'AI spiega e la persona interpreta e decide come usare le informazioni: per esempio, capire le novità di una normativa prima di leggere il testo ufficiale. Al secondo, l'AI suggerisce e la persona sceglie: per esempio, alcune formulazioni alternative per un paragrafo difficile. Al terzo, l'AI produce e la persona rivede e integra: per esempio, una bozza di relazione da completare. Al quarto, l'AI esegue e la persona controlla ogni risultato: per esempio, le risposte alle richieste standard dei clienti, verificate prima dell'invio. Al quinto, l'AI agisce entro vincoli e la persona definisce i limiti, monitora e gestisce le eccezioni: per esempio, lo smistamento automatico delle richieste in arrivo, con controlli a campione. Si noti come cambia il ruolo della persona: da chi usa le informazioni, a chi sceglie, a chi rivede, a chi controlla, a chi definisce le regole e supervisiona.");
    table(s, [["Livello", "L'AI", "La persona", "Esempio"], ["1. Informativo", "Spiega", "Interpreta, decide l'uso", "Capire le novità di una normativa"], ["2. Suggeritore", "Propone", "Sceglie e realizza", "Formulazioni alternative per un paragrafo"], ["3. Collaboratore", "Produce parti", "Rivede, integra, valida", "Bozza di relazione da completare"], ["4. Delega supervisionata", "Esegue", "Controlla ogni risultato", "Risposte standard verificate prima dell'invio"], ["5. Autonomia entro vincoli", "Agisce", "Definisce limiti, monitora, eccezioni", "Smistamento richieste con controlli a campione"]], { colW: [2.2, 1.4, 2.5, 2.9], rowH: 0.55, accentCol: 2, blankCorner: false, fontSize: 12 });
    txt(s, "Da chi usa le informazioni, a chi sceglie, rivede, controlla, definisce le regole.", { x: 0.5, y: 4.85, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Assistenza, collaborazione, delega, automazione", "Il documento di perimetro chiede di distinguere quattro concetti, che spesso si confondono. Assistenza: l'AI aiuta la persona a svolgere un'attività che resta sua; corrisponde ai primi due livelli. Collaborazione: persona e AI contribuiscono insieme al risultato, alternandosi; corrisponde soprattutto al terzo livello. Delega: la persona affida all'AI lo svolgimento di un'attività intera, mantenendo la responsabilità del risultato e, di norma, il controllo; corrisponde al quarto e, con più autonomia, al quinto livello. Automazione: l'attività si svolge in modo ricorrente senza l'intervento della persona per ogni singolo caso, secondo regole e vincoli definiti in anticipo; è il quinto livello applicato in modo sistematico. La differenza non riguarda solo quanto lavoro svolge l'AI, ma dove si colloca la persona: dentro l'attività, accanto, sopra, o a monte, nella definizione delle regole. Ricordiamo che nel Tema 4 abbiamo visto chatbot, assistenti, agenti e automazioni come categorie di sistemi; qui stiamo parlando del modo in cui la persona decide di usarli.");
    const c = [["FiLifeBuoy", "Assistenza", "L'AI aiuta in un'attività che resta della persona", "Livelli 1-2", "Dentro l'attività"], ["FiUsers", "Collaborazione", "Contributi alternati allo stesso risultato", "Livello 3", "Accanto all'AI"], ["FiSend", "Delega", "L'AI svolge un'attività intera; la persona controlla", "Livelli 4-5", "Sopra l'attività"], ["FiRepeat", "Automazione", "Svolgimento ricorrente senza intervento caso per caso", "Livello 5 sistematico", "A monte: definisce le regole"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 3.2, i === 3 ? C.accent6 : C.background2, c[i][1]);
      await iconCircle(s, x + 0.18, 1.35, 0.5, c[i][0]);
      txt(s, c[i][1], { x: x + 0.78, y: 1.35, w: 1.35, h: 0.5, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, c[i][2], { x: x + 0.18, y: 2.0, w: 1.85, h: 1.1, fontSize: 12, color: C.text2 });
      txt(s, c[i][3], { x: x + 0.18, y: 3.15, w: 1.85, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
      txt(s, "Persona: " + c[i][4], { x: x + 0.18, y: 3.5, w: 1.85, h: 0.75, fontSize: 11, bold: true, color: C.text1 });
    }
    txt(s, "Nel Tema 4: categorie di sistemi. Qui: il modo in cui la persona decide di usarli.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Come cambia il ruolo umano", "Al crescere dell'autonomia del sistema, il ruolo della persona non scompare: cambia. Nei livelli bassi la persona è esecutrice, e usa l'AI come uno strumento: le competenze richieste sono quelle tradizionali del proprio lavoro, più la capacità di usare bene lo strumento. Nei livelli intermedi la persona diventa revisore ed editor: deve saper valutare, correggere e integrare il lavoro dell'AI, il che richiede competenza di dominio almeno pari a quella necessaria per svolgere l'attività. Nei livelli alti la persona diventa supervisore e progettista: deve definire obiettivi, regole, vincoli e controlli, monitorare l'andamento, riconoscere le anomalie e intervenire sulle eccezioni. Due osservazioni. Primo: la supervisione è un'attività impegnativa, non un riposo; richiede attenzione proprio quando il sistema funziona bene, che è il momento in cui è più facile distrarsi, come vedremo parlando di automation bias. Secondo: per supervisionare bene un'attività bisogna saperla fare. Se delegando completamente si perdono le competenze, si perde anche la capacità di controllare; è un legame tra 5.5 e 5.7 che vale la pena sottolineare.");
    const r = [["FiTool", "Esecutore", "Usa l'AI come strumento", "Livelli 1-2"], ["FiEdit", "Revisore ed editor", "Valuta, corregge, integra", "Livelli 3-4"], ["FiEye", "Supervisore e progettista", "Definisce regole e controlli, monitora, gestisce eccezioni", "Livello 5"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.25, 2.86, 2.2, i === 2 ? C.accent1 : C.background2, r[i][1]);
      await iconCircle(s, x + 0.2, 1.42, 0.55, r[i][0], i === 2 ? C.background1 : C.accent1, i === 2 ? HEX.a1 : HEX.lt1);
      txt(s, r[i][1], { x: x + 0.9, y: 1.42, w: 1.85, h: 0.55, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.text1, valign: "middle" });
      txt(s, r[i][2], { x: x + 0.2, y: 2.15, w: 2.46, h: 0.85, fontSize: 13, color: i === 2 ? C.background1 : C.text1 });
      txt(s, r[i][3], { x: x + 0.2, y: 3.0, w: 2.46, h: 0.3, fontSize: 11, bold: true, color: i === 2 ? C.accent6 : C.accent1 });
      if (i < 2) arrow(s, x + 2.88, 2.2, 0.17);
    }
    await card(s, 0.5, 3.65, 4.35, 1.3, { inline: true, icon: "FiActivity", head: "Supervisionare è impegnativo", bodySize: 12, body: "Serve attenzione proprio quando tutto funziona bene." });
    await card(s, 5.15, 3.65, 4.35, 1.3, { inline: true, icon: "FiAward", head: "Per supervisionare bisogna saper fare", bodySize: 12, fill: C.accent6, body: "Perdere le competenze significa perdere la capacità di controllo." });
  }
  {
    const s = content("Responsabilità e controllo ai diversi livelli", "La responsabilità del risultato resta sempre della persona e dell'organizzazione, a qualunque livello. Ciò che cambia è la forma del controllo. Ai primi livelli il controllo è diretto: la persona valuta ogni informazione o suggerimento prima di usarlo. Al terzo livello è un controllo di revisione: la persona rilegge e valida il risultato complessivo, con particolare attenzione alle parti prodotte dall'AI. Al quarto livello è un controllo sistematico: ogni risultato viene verificato prima dell'uso, e servono criteri chiari per decidere che cosa è accettabile. Al quinto livello è un controllo progettato: vincoli e autorizzazioni definiti in anticipo, per esempio quali azioni il sistema può compiere e quali richiedono conferma, controlli a campione, monitoraggio, gestione delle eccezioni, possibilità di interrompere. Più alto è il livello, più il controllo deve essere progettato prima, e non può essere improvvisato dopo. Un principio utile: deve essere sempre chiaro chi risponde del risultato, e chi ne risponde deve avere i mezzi per controllarlo. La definizione organizzativa di ruoli e responsabilità appartiene all'area aziendale.");
    const c = [["1-2", "Controllo diretto", "Ogni informazione o suggerimento valutato prima dell'uso"], ["3", "Controllo di revisione", "Rilettura e validazione del risultato complessivo"], ["4", "Controllo sistematico", "Ogni risultato verificato con criteri chiari"], ["5", "Controllo progettato", "Vincoli, autorizzazioni, campioni, monitoraggio, possibilità di interrompere"]];
    for (let i = 0; i < 4; i++) {
      const y = 1.15 + i * 0.75;
      shapeBox(s, 0.5, y, 9.0, 0.66, i === 3 ? C.accent6 : (i % 2 ? C.background1 : C.background2), c[i][1]);
      txt(s, "Livelli " + c[i][0], { x: 0.65, y, w: 1.3, h: 0.66, fontSize: 12, bold: true, color: C.accent1, valign: "middle" });
      txt(s, c[i][1], { x: 2.0, y, w: 2.4, h: 0.66, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, c[i][2], { x: 4.45, y, w: 4.95, h: 0.66, fontSize: 12, color: C.text2, valign: "middle" });
    }
    banner(s, 4.25, "Deve essere sempre chiaro chi risponde del risultato, e chi ne risponde deve avere i mezzi per controllarlo.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Scegliere il livello adeguato", "Come si sceglie il livello di delega? Il concetto chiave del sottotema indica quattro fattori, che riprendono quanto visto nel Tema 3. Il compito: quanto è strutturato, ripetitivo, verificabile? Compiti ben definiti e facili da controllare si prestano a livelli più alti. Le capacità del sistema: quanto è affidabile, per quel compito specifico, nelle nostre condizioni? I rischi: quali sono le conseguenze di un errore, quanto sono gravi, reversibili, rilevabili, e chi le subisce? I controlli disponibili: possiamo verificare i risultati, con quali risorse e competenze? Il livello adeguato è quello compatibile con tutti e quattro. E c'è un messaggio da sottolineare con forza: una maggiore autonomia non determina automaticamente risultati migliori. Delegare di più può far risparmiare tempo, ma può anche moltiplicare gli errori, ridurre la qualità, far perdere competenze e controllo. Livelli maggiori di automazione non sono un traguardo da perseguire indiscriminatamente. Per molte attività di lavoro intellettuale, la collaborazione al terzo livello è la scelta che offre il miglior equilibrio tra beneficio e controllo.");
    const f = [["FiTarget", "Compito", "Strutturato, ripetitivo, verificabile?"], ["FiCpu", "Capacità del sistema", "Affidabile per questo compito, qui?"], ["FiAlertTriangle", "Rischi", "Conseguenze di un errore: gravità, reversibilità?"], ["FiCheckSquare", "Controlli disponibili", "Possiamo verificare, con quali risorse?"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 1.85, C.background2, f[i][1]);
      await iconCircle(s, x + 0.18, 1.35, 0.5, f[i][0]);
      txt(s, f[i][1], { x: x + 0.78, y: 1.35, w: 1.35, h: 0.5, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, f[i][2], { x: x + 0.18, y: 2.0, w: 1.85, h: 0.95, fontSize: 12, color: C.text2 });
    }
    shapeBox(s, 0.5, 3.25, 9.0, 1.7, C.text1, "autonomia non è meglio");
    txt(s, "Una maggiore autonomia non determina automaticamente risultati migliori.", { x: 0.75, y: 3.4, w: 8.5, h: 0.5, fontSize: 18, bold: true, color: C.background1 });
    txt(s, "Delegare di più può far risparmiare tempo, ma anche moltiplicare gli errori e far perdere competenze e controllo. Per molte attività intellettuali la collaborazione (livello 3) offre il miglior equilibrio.", { x: 0.75, y: 3.95, w: 8.5, h: 0.9, fontSize: 13, color: C.accent3 });
  }
  keySlide("Una maggiore autonomia non determina automaticamente risultati migliori: il livello di delega deve essere adeguato al compito, alle capacità del sistema, ai rischi e ai controlli disponibili.", "Sottotema 5.5  ·  I livelli di delega all'Intelligenza Artificiale", "Concetto chiave. Cinque livelli illustrativi: strumento informativo, suggeritore, collaboratore, delega supervisionata, autonomia entro vincoli. Assistenza, collaborazione, delega e automazione sono modalità diverse, in cui la persona si colloca in posizioni diverse. Al crescere dell'autonomia il ruolo umano si sposta dall'esecuzione alla supervisione, e il controllo deve essere progettato in anticipo. La responsabilità resta sempre umana. E più autonomia non è un traguardo in sé. Domanda di verifica: per un'attività del vostro lavoro, a quale livello di delega la affidereste oggi? Che cosa dovrebbe cambiare per salire di un livello, e ne varrebbe la pena?");

  // =====================================================================
  section("5.6 Il ruolo della persona");
  divider("5.6", "La qualità dipende anche dalla persona", "Le competenze umane restano determinanti per formulare problemi, interpretare risultati e riconoscere output inadeguati", "Spesso, quando si parla di AI, l'attenzione è tutta sullo strumento: quale modello è il migliore, quale funzione è nuova. Questo sottotema sposta l'attenzione sull'altro protagonista: la persona. A parità di strumento, persone diverse ottengono risultati molto diversi. Vediamo quali capacità e atteggiamenti fanno la differenza, e la distinzione tra uso passivo e uso attivo dell'AI. Il sottotema descrive il contributo delle competenze; nel 5.7 vedremo il rischio che queste competenze si indeboliscano.");
  {
    const s = content("Otto fattori che dipendono dalla persona", "Il documento di perimetro indica otto fattori. Chiarezza degli obiettivi: sapere che cosa si vuole ottenere e a che cosa servirà il risultato. Comprensione del problema: aver capito la natura della questione, non solo la sua superficie. Conoscenza del contesto: pubblico, vincoli, storia, persone coinvolte. Competenze professionali e conoscenza del dominio: la base per chiedere bene e valutare bene. Capacità di porre domande pertinenti: sapere che cosa chiedere, e come proseguire il dialogo. Capacità di interpretare i risultati: capire che cosa il sistema ha prodotto, che cosa significa, quanto è affidabile. Feedback e correzione: saper indicare con precisione che cosa non va e come migliorarlo. Utilizzo attivo invece che passivo: partecipare alla costruzione del risultato invece di limitarsi a riceverlo. Notate che nessuno di questi fattori riguarda la conoscenza tecnica dello strumento: sono competenze professionali e cognitive generali, che valgono con qualsiasi sistema, e che la AI Literacy contribuisce a sviluppare.");
    const f = [["FiTarget", "Chiarezza degli obiettivi"], ["FiHelpCircle", "Comprensione del problema"], ["FiMap", "Conoscenza del contesto"], ["FiAward", "Competenze di dominio"], ["FiMessageCircle", "Domande pertinenti"], ["FiEye", "Interpretazione dei risultati"], ["FiEdit", "Feedback e correzione"], ["FiActivity", "Utilizzo attivo"]];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.2 + row * 1.6;
      shapeBox(s, x, y, 2.15, 1.42, i === 7 ? C.accent6 : C.background2, f[i][1]);
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, f[i][0]);
      txt(s, f[i][1], { x: x + 0.18, y: y + 0.78, w: 1.85, h: 0.55, fontSize: 13, bold: true, color: C.text1 });
    }
    banner(s, 4.45, "Nessuno di questi fattori riguarda la tecnica dello strumento: valgono con qualsiasi sistema.", { h: 0.5, fontSize: 13 });
  }
  {
    const s = content("Obiettivi chiari e comprensione del problema", "I primi due fattori lavorano a monte dell'interazione. Senza obiettivi chiari, il sistema produce risultati generici, e soprattutto non abbiamo un criterio per valutarli: come capire se un testo va bene, se non sappiamo a chi è destinato e che cosa deve ottenere? Senza comprensione del problema, rischiamo di chiedere la soluzione sbagliata: per esempio di chiedere come scrivere una comunicazione più persuasiva, quando il problema è che la comunicazione arriva alle persone sbagliate. L'esempio in slide mette a confronto due modi di affrontare la stessa situazione. Nel primo, l'obiettivo è vago: 'scrivimi qualcosa sul nuovo servizio'. Nel secondo, la persona sa che cosa vuole ottenere: che i clienti attuali capiscano in che cosa il nuovo servizio cambia le loro abitudini e si iscrivano alla presentazione. Con il secondo obiettivo, sia la richiesta sia la valutazione del risultato diventano molto più facili. Non si tratta di tecnica di formulazione, che vedremo nel Tema 6, ma di chiarezza di pensiero: prima di chiedere all'AI, chiedersi che cosa si vuole davvero ottenere. E, come abbiamo visto nel 5.2, quando non lo si sa ancora, il dialogo stesso può aiutare a scoprirlo.");
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiCloud", head: "Obiettivo vago", headSize: 15, bodySize: 13,
      body: [{ text: "\"Scrivimi qualcosa sul nuovo servizio.\"", options: { italic: true, bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Risultato generico, nessun criterio per valutarlo.", options: {} }] });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiTarget", head: "Obiettivo chiaro", headSize: 15, bodySize: 13, fill: C.accent6,
      body: [{ text: "I clienti attuali devono capire che cosa cambia per loro e iscriversi alla presentazione.", options: { italic: true, bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Richiesta e valutazione diventano più facili.", options: {} }] });
    banner(s, 3.8, "Prima di chiedere all'AI: che cosa voglio davvero ottenere? E qual è davvero il problema?", { h: 0.6 });
    txt(s, "Non è tecnica di formulazione (Tema 6), ma chiarezza di pensiero.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Contesto e competenze di dominio", "Il contesto e le competenze di dominio sono probabilmente i fattori più decisivi. Il contesto è ciò che il sistema non può sapere se non glielo diciamo: chi è il cliente, che cosa è successo nell'ultimo incontro, quali sono le priorità dell'azienda in questo periodo, quali sensibilità vanno rispettate. Una persona che conosce il contesto e lo porta nella conversazione ottiene risultati pertinenti; una persona che non lo conosce, o non lo condivide, ottiene risultati generici. Le competenze di dominio agiscono in due momenti. Prima: chi conosce l'argomento sa quali aspetti sono rilevanti, quali domande porre, quali informazioni fornire. Dopo: chi conosce l'argomento riconosce un errore, un'omissione, una semplificazione eccessiva, e sa quali suggerimenti accettare e quali scartare. È per questo che lo stesso strumento, nelle mani di un esperto e di un principiante, produce risultati di qualità molto diversa, e soprattutto con un rischio molto diverso di errori non riconosciuti. Il principiante può ottenere un testo che sembra ottimo, ma non ha modo di sapere se lo è. La conclusione pratica: l'AI non rende superflua la competenza; la rende più importante, perché è la competenza a trasformare un risultato plausibile in un risultato affidabile.");
    await card(s, 0.5, 1.2, 2.9, 3.0, { icon: "FiMap", head: "Contesto", headSize: 15, bodySize: 12, fill: C.accent6, body: "Ciò che il sistema non può sapere: cliente, storia, priorità, sensibilità. Chi lo porta ottiene risultati pertinenti." });
    await card(s, 3.55, 1.2, 2.9, 3.0, { icon: "FiAward", head: "Competenza: prima", headSize: 15, bodySize: 12, body: "Sapere quali aspetti sono rilevanti, quali domande porre, quali informazioni fornire." });
    await card(s, 6.6, 1.2, 2.9, 3.0, { icon: "FiEye", head: "Competenza: dopo", headSize: 15, bodySize: 12, body: "Riconoscere errori, omissioni, semplificazioni. Scegliere quali suggerimenti accettare." });
    banner(s, 4.35, "L'AI non rende superflua la competenza: la rende più importante.", { h: 0.6 });
  }
  {
    const s = content("Domande, interpretazione e feedback", "Tre capacità operano durante l'interazione. Porre domande pertinenti: non solo la richiesta iniziale, ma le domande successive che approfondiscono, chiariscono, mettono in discussione. Per esempio: 'su che cosa si basa questa conclusione?', 'quali casi non rientrano in questa regola?', 'che cosa cambierebbe se il budget fosse la metà?'. Interpretare i risultati: capire che cosa il sistema ha prodotto, distinguere ciò che è solido da ciò che è incerto, accorgersi di quando la risposta è generica o elude la domanda, riconoscere le assunzioni implicite. Dare feedback e correzioni precise: un feedback generico come 'non va bene, rifallo' produce di solito un risultato diverso ma non necessariamente migliore; un feedback specifico, come 'il secondo paragrafo è troppo tecnico per il pubblico, e manca il riferimento alla scadenza', permette al sistema di correggere davvero. È la stessa abilità che serve per guidare il lavoro di un collaboratore. Queste tre capacità si sviluppano con la pratica e con la riflessione su ciò che funziona. Le tecniche specifiche di formulazione e affinamento delle richieste saranno sviluppate nel Tema 6.");
    const c = [["FiHelpCircle", "Domande pertinenti", ["\"Su che cosa si basa questa conclusione?\"", "\"Quali casi non rientrano?\"", "\"Che cosa cambierebbe se...?\""]], ["FiEye", "Interpretare i risultati", ["Solido o incerto?", "Generico o eludente?", "Quali assunzioni implicite?"]], ["FiEdit", "Feedback preciso", ["Generico: \"non va, rifallo\"", "Specifico: \"il secondo paragrafo è troppo tecnico, manca la scadenza\""]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.15, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2, body: bullets(c[i][2], { space: 5 }) });
    txt(s, "Come guidare il lavoro di un collaboratore. Le tecniche specifiche nel Tema 6.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Utilizzo passivo e utilizzo attivo", "Tutti i fattori visti convergono in una distinzione di atteggiamento: utilizzo passivo e utilizzo attivo dell'AI. Nell'utilizzo passivo, la persona fa una richiesta, riceve una risposta e la usa così com'è. Non porta contesto, non mette in discussione, non verifica, non personalizza. Il risultato è generico, e il rischio di errori non riconosciuti è alto. Nell'utilizzo attivo, la persona parte da obiettivi chiari, porta il contesto, dialoga, mette in discussione, confronta con ciò che sa, corregge, integra, verifica e decide. Il risultato è pertinente, e la persona ne è davvero padrona. Il confronto in tabella sintetizza le differenze. È importante sottolineare che l'utilizzo attivo richiede più impegno, almeno all'inizio, ma produce risultati migliori, riduce gli errori, e mantiene e sviluppa le competenze della persona, invece di eroderle. È anche ciò che distingue chi trae un vantaggio reale dall'AI da chi ottiene risultati mediocri e conclude che 'non serve'. Domanda per il gruppo: nel vostro uso quotidiano, siete più vicini all'utilizzo passivo o a quello attivo?");
    table(s, [["", "Utilizzo passivo", "Utilizzo attivo"], ["Obiettivi", "Impliciti o vaghi", "Chiari"], ["Contesto", "Non fornito", "Fornito e precisato"], ["Dialogo", "Una richiesta, una risposta", "Scambi, domande, correzioni"], ["Atteggiamento", "Accetta il risultato", "Mette in discussione, confronta"], ["Risultato", "Generico, errori non riconosciuti", "Pertinente, verificato, padroneggiato"], ["Competenze", "Rischiano di indebolirsi", "Si mantengono e si sviluppano"]], { colW: [2.0, 3.5, 3.5], rowH: 0.48, accentCol: 2 });
    txt(s, "Più impegno all'inizio, risultati migliori e competenze che crescono.", { x: 0.5, y: 4.85, w: 9, h: 0.3, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Le competenze umane restano determinanti per formulare problemi, interpretare risultati e riconoscere output inadeguati.", "Sottotema 5.6  ·  La qualità della collaborazione dipende anche dalla persona", "Concetto chiave. La qualità della collaborazione dipende da otto fattori che riguardano la persona: obiettivi, comprensione del problema, contesto, competenze di dominio, domande, interpretazione, feedback, atteggiamento attivo. Lo stesso strumento dà risultati molto diversi in mani diverse, e la competenza diventa più importante, non meno, perché è ciò che permette di riconoscere un risultato inadeguato. Domanda di verifica: in quale ambito del vostro lavoro vi sentite abbastanza competenti da riconoscere un errore dell'AI? E in quale no? Che cosa ne consegue per il modo in cui la usate in ciascun ambito?");

  // =====================================================================
  section("5.7 Limiti e rischi");
  divider("5.7", "Limiti e rischi della relazione conversazionale", "Un'interazione naturale e convincente non attribuisce al sistema intenzionalità, giudizio umano o responsabilità decisionale", "Ultimo sottotema, il cui obiettivo è la consapevolezza critica. La naturalezza della conversazione è il grande punto di forza dei sistemi AI, ma porta con sé rischi specifici, di natura relazionale e cognitiva: attribuire al sistema qualità umane, fidarsi troppo, accettare passivamente, delegare il pensiero fino a indebolire le proprie capacità. Non ripetiamo l'analisi tecnica di allucinazioni e bias del Tema 3, né le procedure di verifica, che saranno oggetto del Tema 7: ci concentriamo sulle dinamiche dell'interazione e sui loro effetti su di noi.");
  {
    const s = content("Antropomorfizzazione", "Nel Tema 2 abbiamo incontrato l'effetto ELIZA: la tendenza ad attribuire comprensione e qualità umane a un sistema che produce linguaggio in modo convincente. Qui guardiamo le conseguenze di questa tendenza nella relazione quotidiana. I sistemi conversazionali usano un linguaggio caldo e personale, ricordano ciò che abbiamo detto, si scusano, si complimentano, esprimono comprensione; con la voce, l'effetto è ancora più forte. È facile percepire tre cose che non ci sono. La comprensione: la sensazione che il sistema abbia capito davvero la nostra situazione, quando ha elaborato le parole che abbiamo scritto. L'empatia: la sensazione che partecipi ai nostri stati d'animo, quando produce espressioni appropriate al contesto. L'intenzionalità: la sensazione che voglia aiutarci, che abbia scopi o opinioni proprie. Queste percezioni non sono stupide: sono la reazione naturale di esseri sociali a un comportamento linguistico molto simile a quello umano. Ma hanno conseguenze: aumentano la fiducia oltre il dovuto, possono portare a condividere informazioni personali o riservate con troppa leggerezza, e in alcuni casi a cercare nel sistema un sostegno emotivo che non può dare. Riconoscere queste percezioni in noi stessi è il primo passo per gestirle.");
    const p = [["FiCheckCircle", "Comprensione", "Ha capito davvero la mia situazione?", "Ha elaborato le parole che ho scritto"], ["FiHeart", "Empatia", "Partecipa ai miei stati d'animo?", "Produce espressioni adatte al contesto"], ["FiCompass", "Intenzionalità", "Vuole aiutarmi, ha opinioni sue?", "Genera risposte secondo addestramento e istruzioni"]];
    txt(s, "Che cosa percepiamo", { x: 1.9, y: 1.15, w: 3.5, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    txt(s, "Che cosa accade", { x: 5.6, y: 1.15, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    for (let i = 0; i < 3; i++) {
      const y = 1.5 + i * 0.85;
      shapeBox(s, 0.5, y, 9.0, 0.75, i % 2 ? C.background1 : C.background2, p[i][1]);
      await iconCircle(s, 0.62, y + 0.13, 0.48, p[i][0]);
      txt(s, p[i][1], { x: 1.2, y, w: 1.6, h: 0.75, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, p[i][2], { x: 2.8, y, w: 2.7, h: 0.75, fontSize: 12, italic: true, color: C.text1, valign: "middle" });
      txt(s, p[i][3], { x: 5.6, y, w: 3.8, h: 0.75, fontSize: 12, color: C.text2, valign: "middle" });
    }
    txt(s, "Conseguenze possibili", { x: 0.5, y: 4.1, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Fiducia oltre il dovuto", "Condivisione di dati riservati", "Ricerca di sostegno emotivo"].forEach((t, i) => chip(s, 0.5 + i * 3.07, 4.45, 2.86, 0.5, t, { fill: C.background1, line: { color: C.accent5, width: 1.25 }, color: C.accent5, fontSize: 12 }));
  }
  {
    const s = content("Fiducia eccessiva e accettazione passiva", "Un interlocutore che risponde sempre, con sicurezza, in modo fluente e competente, e che spesso ha ragione, induce fiducia. È un meccanismo comprensibile, ma porta a due rischi collegati. La fiducia eccessiva: attribuire al sistema un'affidabilità superiore a quella reale, generalizzando dalle volte in cui ha funzionato bene a tutte le situazioni. Come abbiamo visto nel Tema 3, l'affidabilità varia molto da compito a compito, e un sistema eccellente in un'attività può sbagliare in un'altra apparentemente simile. L'accettazione passiva: smettere di valutare le risposte e limitarsi a usarle, per abitudine, per mancanza di tempo, o perché metterle in discussione sembra superfluo. Accade soprattutto quando le risposte sono lunghe e ben strutturate, quando l'argomento non ci è familiare, quando abbiamo fretta. I due rischi si alimentano a vicenda: più ci fidiamo, meno controlliamo; meno controlliamo, meno ci accorgiamo degli errori; meno errori notiamo, più ci fidiamo. È un circolo da interrompere intenzionalmente. Lo schema in slide lo rappresenta.");
    const cyc = [["Ci fidiamo di più", 0.5, 1.3], ["Controlliamo di meno", 3.0, 1.3], ["Notiamo meno errori", 3.0, 2.95], ["La fiducia cresce ancora", 0.5, 2.95]];
    cyc.forEach((c, i) => chip(s, c[1], c[2], 2.2, 0.85, c[0], { fill: i === 2 ? C.accent5 : C.background2, color: i === 2 ? C.background1 : C.text1, fontSize: 13 }));
    arrow(s, 2.72, 1.57, 0.26, C.accent2);
    s.addShape(pres.shapes.DOWN_ARROW, { x: 3.95, y: 2.2, w: 0.32, h: 0.7, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia giù" });
    s.addShape(pres.shapes.LEFT_ARROW, { x: 2.72, y: 3.22, w: 0.26, h: 0.32, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia sinistra" });
    s.addShape(pres.shapes.UP_ARROW, { x: 1.45, y: 2.2, w: 0.32, h: 0.7, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia su" });
    await card(s, 5.6, 1.2, 3.9, 1.6, { inline: true, icon: "FiThumbsUp", head: "Fiducia eccessiva", bodySize: 12, body: "Generalizzare dai successi a tutte le situazioni." });
    await card(s, 5.6, 2.95, 3.9, 1.6, { inline: true, icon: "FiPause", head: "Accettazione passiva", bodySize: 12, fill: C.accent6, body: "Smettere di valutare: fretta, abitudine, argomento poco familiare." });
    banner(s, 4.7, "Un circolo da interrompere intenzionalmente.", { h: 0.35, fontSize: 12, fill: C.background1, color: C.text1, italic: true });
  }
  {
    const s = content("Automation bias", "L'automation bias, o pregiudizio di automazione, è la tendenza a privilegiare i suggerimenti di un sistema automatizzato anche senza un'adeguata verifica, talvolta anche quando contrastano con altre informazioni disponibili o con il proprio giudizio. È stato studiato per decenni, molto prima dell'AI generativa, in settori come l'aviazione, la medicina e il controllo industriale, dove si è osservato che gli operatori tendono a seguire le indicazioni dei sistemi automatici e a ridurre il proprio monitoraggio. Una sintesi nota è quella di Raja Parasuraman e Dietrich Manzey, pubblicata nel 2010. Si manifesta in due forme. Errori di commissione: seguire un suggerimento sbagliato del sistema, per esempio accettare una classificazione errata. Errori di omissione: non accorgersi di un problema perché il sistema non lo ha segnalato, per esempio dare per completo un riassunto che omette un punto importante. L'automation bias è più forte quando il sistema è generalmente affidabile, quando il carico di lavoro è alto e quando la persona ha poca esperienza. Non dipende da superficialità individuale: è una tendenza cognitiva comune, che si contrasta con la consapevolezza e con abitudini di controllo. Non approfondiamo i modelli psicologici della fiducia nell'automazione, che vanno solo accennati.");
    shapeBox(s, 0.5, 1.2, 9.0, 1.0, C.text1, "definizione automation bias");
    txt(s, [{ text: "Automation bias: ", options: { bold: true, color: C.accent1 } }, { text: "la tendenza a privilegiare i suggerimenti automatizzati senza adeguata verifica, anche contro altre informazioni o il proprio giudizio.", options: { color: C.background1 } }], { x: 0.7, y: 1.2, w: 8.6, h: 1.0, fontSize: 14, valign: "middle" });
    await card(s, 0.5, 2.4, 4.35, 1.4, { inline: true, icon: "FiCheck", head: "Errori di commissione", bodySize: 12, body: "Seguire un suggerimento sbagliato: accettare una classificazione errata." });
    await card(s, 5.15, 2.4, 4.35, 1.4, { inline: true, icon: "FiEyeOff", head: "Errori di omissione", bodySize: 12, fill: C.accent6, body: "Non vedere un problema non segnalato: un riassunto che omette un punto." });
    txt(s, "Più forte quando", { x: 0.5, y: 3.95, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Il sistema è di solito affidabile", "Il carico di lavoro è alto", "L'esperienza è poca"].forEach((t, i) => chip(s, 0.5 + i * 3.07, 4.3, 2.86, 0.5, t, { fill: C.background2, fontSize: 12 }));
    txt(s, "Fonte: Parasuraman e Manzey, Human Factors, 2010", { x: 0.5, y: 4.9, w: 6, h: 0.25, fontSize: 10, color: C.accent2 });
  }
  {
    const s = content("Il rischio della delega cognitiva", "Questa integrazione del sottotema affronta il tema forse più importante per il lungo periodo. Per delega cognitiva intendiamo affidare all'AI attività mentali: ricordare, sintetizzare, scrivere, ragionare, valutare, decidere. Di per sé non è un male: deleghiamo attività mentali agli strumenti da sempre, alla scrittura, alla calcolatrice, al navigatore, e questo ci ha liberato tempo e attenzione per altro. Anche con l'AI, delegare una sintesi o una prima bozza può liberare energie per ciò che conta di più. Diventa problematica quando riduce la capacità di comprendere, verificare e decidere autonomamente. Alcuni segnali: non riuscire più a scrivere un testo senza il supporto dell'AI; usare risultati che non si saprebbero spiegare o difendere; smettere di ragionare su un problema prima di chiedere; non essere più in grado di accorgersi degli errori del sistema. Una ricerca di Microsoft Research e Carnegie Mellon presentata nel 2025 (Lee e colleghi), basata su un'indagine tra 319 lavoratori della conoscenza, ha osservato che una maggiore fiducia nell'AI generativa si associava a un minore impegno di pensiero critico, mentre una maggiore fiducia nelle proprie capacità si associava a un pensiero critico maggiore. È un'indagine basata su autovalutazioni, non una prova definitiva, ma il segnale è coerente con quanto abbiamo visto: il rischio non è usare l'AI, ma smettere di pensare mentre la si usa.");
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiSun", head: "Opportunità", headSize: 15, bodySize: 13, fill: C.accent6, body: "Delegare attività mentali libera tempo e attenzione, come la scrittura, la calcolatrice, il navigatore." });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiAlertTriangle", head: "Diventa un problema quando", headSize: 15, bodySize: 12, iconBg: C.accent5, body: bullets(["Non si sa più fare senza", "Si usano risultati che non si saprebbero spiegare", "Si smette di ragionare prima di chiedere", "Non si riconoscono più gli errori"], { space: 1 }) });
    shapeBox(s, 0.5, 3.55, 9.0, 1.4, C.text1, "studio Lee");
    txt(s, "UN SEGNALE DALLA RICERCA", { x: 0.7, y: 3.65, w: 4, h: 0.28, fontSize: 10, bold: true, color: C.accent3, charSpacing: 2 });
    txt(s, "Più fiducia nell'AI, meno pensiero critico dichiarato; più fiducia nelle proprie capacità, più pensiero critico (indagine su 319 lavoratori della conoscenza).", { x: 0.7, y: 3.95, w: 8.6, h: 0.65, fontSize: 13, color: C.background1 });
    txt(s, "Fonte: Lee et al., Microsoft Research e Carnegie Mellon, CHI 2025", { x: 0.7, y: 4.62, w: 8, h: 0.25, fontSize: 10, color: C.accent2 });
  }
  {
    const s = content("Dipendenza e preservazione del giudizio", "L'ultimo rischio è la dipendenza: la difficoltà a svolgere attività, o a prendere decisioni, senza il supporto dell'AI. Una certa dipendenza dagli strumenti è normale e accettabile; diventa un problema quando ci rende vulnerabili, per esempio se lo strumento non è disponibile, cambia comportamento, o sbaglia senza che ce ne accorgiamo, oppure quando riduce le competenze di cui l'organizzazione ha bisogno. Come preservare autonomia cognitiva, giudizio e responsabilità? Alcune pratiche concrete, raccolte in slide. Pensare prima di chiedere: farsi un'idea propria, anche sommaria, prima di consultare l'AI, così da avere un termine di confronto. Usare l'AI per mettere alla prova il proprio pensiero, non solo per sostituirlo, come abbiamo visto nel ruolo di interlocutore critico. Mantenere la pratica: continuare a svolgere personalmente, almeno in parte, le attività che sono centrali per il proprio ruolo e la propria crescita. Saper spiegare: non usare risultati che non si saprebbero spiegare o difendere. Verificare con proporzione. Decidere in prima persona: l'AI propone, la persona decide. Queste pratiche non riducono il valore dell'AI: lo rendono sostenibile nel tempo.");
    const p = [["FiZap", "Pensare prima di chiedere", "Farsi un'idea propria come termine di confronto"], ["FiShield", "Mettere alla prova, non solo sostituire", "L'AI come interlocutore critico"], ["FiRepeat", "Mantenere la pratica", "Svolgere in prima persona le attività centrali"], ["FiMessageCircle", "Saper spiegare", "Non usare ciò che non si saprebbe difendere"], ["FiCheckSquare", "Verificare con proporzione", "Secondo le conseguenze di un errore"], ["FiUserCheck", "Decidere in prima persona", "L'AI propone, la persona decide"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 3.15, headSize: 13, bodySize: 12 });
    banner(s, 4.5, "Queste pratiche non riducono il valore dell'AI: lo rendono sostenibile nel tempo.", { h: 0.5, fontSize: 13 });
  }
  keySlide("Un'interazione naturale e convincente non attribuisce al sistema intenzionalità, giudizio umano o responsabilità decisionale.", "Sottotema 5.7  ·  Limiti e rischi della relazione conversazionale", "Concetto chiave dell'ultimo sottotema. La naturalezza della conversazione induce a percepire comprensione, empatia e intenzionalità, e a fidarsi oltre il dovuto. Fiducia eccessiva, accettazione passiva e automation bias si alimentano a vicenda. La delega cognitiva può liberare energie, ma diventa un rischio quando riduce la capacità di comprendere, verificare e decidere, e può portare a una dipendenza che indebolisce le competenze. Preservare autonomia cognitiva e responsabilità richiede pratiche intenzionali. Domanda di verifica: quale delle pratiche della slide precedente vi impegnate ad adottare da domani? Chiedere a ciascun partecipante di sceglierne una.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle dieci domande guida con una risposta sintetica. Il linguaggio naturale come interfaccia: dal come al che cosa, più accessibilità ma più ambiguità. Perché un dialogo: perché la qualità si costruisce in più scambi. L'AI che pone domande: aiuta a chiarire esigenze, assunzioni e informazioni mancanti. Ruoli e competenze: molti ruoli possibili, ma il ruolo assegnato non crea competenze. Collaborazione efficace: capacità complementari, fasi ben distribuite, validazione umana. Supporto, collaborazione, delega, autonomia: livelli diversi, da scegliere in base a compito, sistema, rischi e controlli. Competenze personali: obiettivi, contesto, dominio, domande, interpretazione, feedback, atteggiamento attivo. Mettere alla prova un'ipotesi: chiedere obiezioni, alternative, assunzioni nascoste. Rischi: antropomorfizzazione, fiducia eccessiva, automation bias. Autonomia e responsabilità: pensare prima di chiedere, mantenere la pratica, decidere in prima persona. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Linguaggio naturale come interfaccia?", "Dal come al che cosa: accessibile ma ambiguo"], ["Perché un dialogo?", "La qualità si costruisce in più scambi"], ["L'AI che pone domande?", "Chiarisce esigenze, assunzioni, lacune"], ["Ruoli e competenze?", "Il ruolo orienta, non crea competenze"], ["Collaborazione efficace?", "Capacità complementari, validazione umana"], ["Supporto, delega, autonomia?", "Livelli da scegliere su compito e rischi"], ["Competenze personali?", "Obiettivi, contesto, dominio, feedback"], ["Mettere alla prova un'ipotesi?", "Obiezioni, alternative, assunzioni"], ["Rischi della relazione?", "Antropomorfizzazione, fiducia, automation bias"], ["Autonomia e responsabilità?", "Pensare prima, mantenere la pratica, decidere"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.79;
      shapeBox(s, x, y, 4.4, 0.71, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.45, h: 0.71, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.05, w: 3.75, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.36, w: 3.75, h: 0.3, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dieci risultati attesi. Il partecipante dovrebbe essere in grado di: comprendere caratteristiche e limiti delle interfacce conversazionali; distinguere una richiesta isolata da un dialogo progressivo; riconoscere i diversi ruoli che un sistema AI può svolgere; comprendere come distribuire le attività tra persona e AI; distinguere assistenza, collaborazione, delega ed esecuzione autonoma; riconoscere il contributo delle competenze personali alla qualità dei risultati; usare l'AI per esplorare controargomentazioni e alternative; riconoscere i rischi di antropomorfizzazione e fiducia eccessiva; comprendere opportunità e limiti della delega cognitiva; preservare il ruolo attivo della persona nella valutazione dei risultati e nelle decisioni.");
    const r = ["Caratteristiche e limiti delle interfacce conversazionali", "Richiesta isolata e dialogo progressivo", "I diversi ruoli dell'AI", "Distribuire le attività tra persona e AI", "Assistenza, collaborazione, delega, autonomia", "Il contributo delle competenze personali", "Esplorare controargomentazioni e alternative", "Rischi di antropomorfizzazione e fiducia eccessiva", "Opportunità e limiti della delega cognitiva", "Il ruolo attivo della persona nelle decisioni"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.79;
      shapeBox(s, x, y, 4.4, 0.7, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.45, h: 0.7, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.75, h: 0.7, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Principi per un dialogo consapevole", "Come per i temi precedenti, traduciamo il modulo in uno strumento pratico: otto principi per un dialogo consapevole con l'AI, da distribuire o da tenere a portata di mano. Sapere che cosa si vuole ottenere, e se non lo si sa, usare il dialogo per scoprirlo. Portare il contesto: il sistema conosce solo ciò che gli diciamo. Dialogare invece di accontentarsi della prima risposta. Scegliere il ruolo dell'AI adatto al momento, ricordando che il ruolo non crea competenze. Chiedere anche critiche e alternative, non solo conferme. Scegliere consapevolmente il livello di delega, in base al compito e ai rischi. Ricordare che la naturalezza della conversazione non rende il sistema una persona, né le sue risposte vere. Pensare con la propria testa e decidere in prima persona: l'AI amplifica, non sostituisce. È il messaggio centrale del tema: costruire una collaborazione in cui la tecnologia amplifica le capacità umane senza sostituire giudizio, competenze e responsabilità.");
    const p = [["FiTarget", "Sapere che cosa si vuole ottenere, o usare il dialogo per scoprirlo"], ["FiMap", "Portare il contesto: il sistema conosce solo ciò che gli diciamo"], ["FiMessageSquare", "Dialogare invece di accontentarsi della prima risposta"], ["FiUsers", "Scegliere il ruolo adatto: il ruolo non crea competenze"], ["FiShield", "Chiedere critiche e alternative, non solo conferme"], ["FiSliders", "Scegliere consapevolmente il livello di delega"], ["FiUser", "La conversazione è naturale, ma il sistema non è una persona"], ["FiUserCheck", "Pensare con la propria testa e decidere in prima persona"]];
    for (let i = 0; i < 8; i++) {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 9.0, 0.41, i % 2 ? C.background1 : C.background2, "principio " + (i + 1));
      txt(s, String(i + 1), { x: 0.6, y, w: 0.35, h: 0.41, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      await iconCircle(s, 1.0, y + 0.03, 0.35, p[i][0]);
      txt(s, p[i][1], { x: 1.5, y, w: 7.9, h: 0.41, fontSize: 13, color: C.text1, valign: "middle" });
    }
    txt(s, "La tecnologia amplifica le capacità umane, senza sostituire giudizio, competenze e responsabilità.", { x: 0.5, y: 4.9, w: 9, h: 0.25, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Prossimo passo: il Tema 6", "Il percorso prosegue con il Tema 6, dedicato al prompting e alle tecniche di interazione. In questo modulo abbiamo più volte rimandato al Tema 6 le tecniche operative: come formulare una richiesta efficace, come fornire contesto ed esempi, come assegnare ruoli e formati, come perfezionare progressivamente le richieste. Ora che abbiamo chiarito il senso del dialogo, i ruoli dell'AI, la collaborazione, i livelli di delega e l'importanza del contributo della persona, possiamo passare agli strumenti pratici con le giuste premesse: il prompting non è una formula magica, ma il modo concreto di esercitare quel ruolo attivo di cui abbiamo parlato. Più avanti, il Tema 7 sarà dedicato alla verifica degli output e al pensiero critico. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.background2, "tema 5");
    txt(s, "TEMA 5", { x: 0.75, y: 1.4, w: 3.1, h: 0.35, fontSize: 13, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Il dialogo uomo-AI", { x: 0.75, y: 1.8, w: 3.1, h: 0.5, fontSize: 18, bold: true, color: C.text1 });
    txt(s, bullets(["Dialogo e ruoli dell'AI", "Collaborazione e delega", "Il contributo della persona", "Rischi della relazione"], { space: 4 }), { x: 0.75, y: 2.45, w: 3.1, h: 2.2, fontSize: 14, color: C.text2 });
    arrow(s, 4.25, 2.9, 0.55, C.accent1);
    shapeBox(s, 4.95, 1.2, 4.55, 3.75, C.text1, "tema 6");
    txt(s, "TEMA 6", { x: 5.2, y: 1.4, w: 4.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Prompting e tecniche di interazione", { x: 5.2, y: 1.8, w: 4.1, h: 0.7, fontSize: 18, bold: true, color: C.background1 });
    txt(s, bullets(["Formulare richieste efficaci", "Contesto, esempi, ruoli, formati", "Perfezionare le richieste", "Poi, Tema 7: verifica e pensiero critico"], { space: 3 }), { x: 5.2, y: 2.65, w: 4.1, h: 2.1, fontSize: 14, color: C.accent3 });
  }
  {
    const s = content("Fonti e riferimenti", "Le principali fonti citate nel modulo. La ricerca sugli effetti dell'AI generativa sul pensiero critico e sull'apprendimento è in rapida evoluzione: prima di ogni edizione è consigliabile verificare se sono disponibili studi più recenti o più solidi da citare.");
    const src = [
      "Weizenbaum, J. (1966). ELIZA. Communications of the ACM, 9(1).",
      "Parasuraman, R., Manzey, D. H. (2010). Complacency and Bias in Human Use of Automation: An Attentional Integration. Human Factors, 52(3).",
      "Lee, H.-P. et al. (2025). The Impact of Generative AI on Critical Thinking: Self-Reported Reductions in Cognitive Effort and Confidence Effects From a Survey of Knowledge Workers. CHI 2025, Microsoft Research e Carnegie Mellon University.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.0, fontSize: 13, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema5_Dialogo_uomo_AI.pptx" });
  await applyTheme("Tema5_Dialogo_uomo_AI.pptx", THEME);
  console.log("done");
})();
