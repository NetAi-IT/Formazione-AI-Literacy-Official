const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 4: Ecosistema AI: modelli, strumenti e piattaforme";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 4  ·  Ecosistema AI: modelli, strumenti e piattaforme";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }


  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 4", { placeholder: "kicker" });
    s.addText("Ecosistema AI: modelli, strumenti e piattaforme", { placeholder: "title" });
    s.addText("Area: Comprendere l'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al quarto tema del percorso. Nei primi tre temi abbiamo capito perché l'AI è rilevante, come funziona e quanto possiamo fidarci dei suoi risultati. Ora guardiamo al panorama concreto: modelli, applicazioni, piattaforme, modalità di accesso. È un panorama affollato e in continuo movimento, in cui ogni settimana compaiono nuovi prodotti e nuove funzioni. L'obiettivo del modulo non è imparare a usare tutti gli strumenti, né conoscere a memoria il mercato, ma costruire una mappa stabile per orientarsi e criteri per scegliere in modo consapevole. Avvertenza importante per il relatore: esempi di prodotti, funzionalità, piani commerciali, prezzi e disponibilità geografiche cambiano rapidamente. Prima di ogni erogazione è necessario verificarli e, se serve, aggiornare le slide. L'ultima verifica è di ottobre 2026. Suggerimento per l'apertura: chiedere ai partecipanti quali strumenti AI conoscono o usano, anche solo di nome, e scriverli alla lavagna. La lista servirà più volte durante il modulo per collocare ciascuno strumento nella mappa.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è fornire una comprensione strutturata dell'ecosistema dell'AI, distinguendo modelli, applicazioni, piattaforme, infrastrutture e modalità di accesso, e sviluppare criteri per orientarsi tra le soluzioni disponibili. La consapevolezza da sviluppare riprende un concetto già incontrato nel Tema 2: il modello non è tutto. Il valore di uno strumento AI dipende anche dalle funzionalità dell'applicazione, dalle integrazioni con gli altri sistemi, dalle condizioni di utilizzo, cioè contratti, gestione dei dati e controlli, e dall'adeguatezza al contesto aziendale. E conoscere l'ecosistema non significa conoscere tutti i prodotti, ma sapersi orientare: capire come sono organizzate le soluzioni e scegliere quelle adatte alle proprie esigenze, invece di inseguire ogni novità.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Una mappa stabile dell'ecosistema: modelli, applicazioni, piattaforme, infrastrutture, accessi", "Criteri per confrontare e scegliere le soluzioni"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Il valore di uno strumento non dipende solo dal modello, ma anche da funzionalità, integrazioni, condizioni d'uso e adeguatezza al contesto.\n\nSapersi orientare, non conoscere a memoria tutti i prodotti." });
  }
  {
    const s = content("Dieci domande guida per questo modulo", "Le dieci domande guida accompagnano il modulo. Le prime due riguardano la struttura dell'ecosistema e le sue categorie. La terza e la quarta riguardano le differenze tra prodotti e tra approcci: generalista, specializzato, integrato. La quinta riguarda chatbot, assistenti, agenti e automazioni. La sesta le modalità di accesso. Le domande dalla settima alla nona riguardano la scelta: criteri di confronto, licenze e dipendenza dal fornitore, verifica delle funzioni effettivamente disponibili. L'ultima riguarda la dinamicità dell'ecosistema e il valore delle competenze trasferibili. Alla fine del modulo torneremo su tutte con una risposta sintetica.");
    const qs = ["Che differenza c'è tra un modello e un'applicazione che lo usa?", "Quali sono le principali categorie di modelli e strumenti?", "Perché prodotti simili hanno capacità e condizioni diverse?", "Quando scegliere generalista, specializzato o integrato?", "Che cosa distingue chatbot, assistenti, agenti e automazioni?", "Applicazione, API o modello locale: che differenze?", "Quali fattori considerare per confrontare due soluzioni?", "Come influiscono licenze, portabilità e lock-in?", "Come verificare che una funzione pubblicizzata sia disponibile?", "Perché servono competenze trasferibili tra piattaforme?"];
    for (let i = 0; i < 10; i++) {
      const col = i % 5, row = Math.floor(i / 5);
      const x = 0.5 + col * 1.84, y = 1.2 + row * 1.9;
      shapeBox(s, x, y, 1.7, 1.75, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, qs[i], { x: x + 0.15, y: y + 0.55, w: 1.45, h: 1.15, fontSize: 11, color: C.text1 });
    }
  }
  {
    const s = content("Il filo conduttore", "Il filo conduttore del modulo è un percorso dalla mappa alla scelta, in quattro passi. Primo: la struttura dell'ecosistema e le famiglie di modelli, cioè di che cosa è fatta un'applicazione AI e quali modelli esistono, nei sottotemi 4.1 e 4.2. Secondo: i prodotti e gli approcci, cioè come leggere l'offerta e quando conviene uno strumento generalista, una soluzione specializzata o l'AI già presente nei software in uso, nei sottotemi 4.3 e 4.4. Terzo: l'autonomia e l'accesso, cioè la differenza tra chatbot, assistenti, agenti e automazioni, e i diversi modi in cui le capacità AI arrivano in azienda, nei sottotemi 4.5 e 4.6. Quarto: la scelta e l'evoluzione, cioè i criteri per confrontare le soluzioni e il motivo per cui vanno rivisti nel tempo, nei sottotemi 4.7 e 4.8. Il messaggio che accompagna tutto il percorso viene dal documento di perimetro: conoscere l'ecosistema significa sapersi orientare e scegliere consapevolmente, non conoscere a memoria tutti i prodotti. Suggerimento: riprendere la lista di strumenti scritta alla lavagna in apertura e annunciare che, alla fine del modulo, sapremo collocarli tutti nella mappa.");
    const d = [["FiMap", "Struttura e modelli", "Di che cosa è fatta un'applicazione", "4.1  4.2"], ["FiGrid", "Prodotti e approcci", "Leggere l'offerta", "4.3  4.4"], ["FiSliders", "Autonomia e accesso", "Che cosa fa, come arriva", "4.5  4.6"], ["FiCheckSquare", "Scelta ed evoluzione", "Criteri e revisione nel tempo", "4.7  4.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.15, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.05, w: 1.9, h: 0.38, fontSize: 15, bold: true, color: dark ? C.background1 : C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.43, w: 1.9, h: 0.5, fontSize: 12, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, d[i][3], { x: x + 0.1, y: 2.95, w: 1.9, h: 0.3, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    banner(s, 3.65, "Sapersi orientare e scegliere consapevolmente, non conoscere a memoria tutti i prodotti.", { h: 0.8, fontSize: 15 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti confermati e mantenuti separati. Cinque hanno priorità alta: la struttura dell'ecosistema, le piattaforme e gli strumenti, la distinzione tra AI generalista, specializzata e integrata, le differenze tra chatbot, assistenti, agenti e automazioni, e i criteri di scelta. Tre hanno priorità media: le famiglie di modelli, le modalità di accesso e la dinamicità dell'ecosistema. Vanno compresi bene: la differenza tra modello e applicazione, le categorie di strumenti, le soluzioni generaliste e specializzate, la differenza tra chatbot, assistenti e agenti, i criteri di scelta. Vanno conosciuti: famiglie di modelli, modalità di accesso, differenze tra cloud e locale, modelli aperti e chiusi, vendor lock-in. Vanno solo accennati: infrastrutture, configurazione tecnica delle API, deployment, orchestrazione avanzata e integrazione. Confini: non ripetiamo storia e funzionamento tecnico, usiamo l'affidabilità del Tema 3 come criterio senza ripeterne la teoria, non trattiamo tecniche di interazione e prompting (Temi 5 e 6), né la progettazione di agenti e workflow (Tema 11), né la scelta dei casi d'uso (Tema 15) e la governance (Tema 18).");
    const items = [["4.1", "La struttura dell'ecosistema AI", "Alta"], ["4.2", "Le principali famiglie di modelli AI", "Media"], ["4.3", "Le principali piattaforme e strumenti", "Alta"], ["4.4", "AI generalista, specializzata e integrata", "Alta"], ["4.5", "Chatbot, assistenti, agenti e automazioni", "Alta"], ["4.6", "Modalità di accesso e utilizzo", "Media"], ["4.7", "Criteri per confrontare e scegliere", "Alta"], ["4.8", "Evoluzione e dinamicità dell'ecosistema", "Media"]];
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    const lv = [["Comprendere bene", "Modello e applicazione, categorie di strumenti, generalista e specializzato, chatbot, assistenti e agenti, criteri di scelta", C.accent1, C.background1], ["Conoscere", "Famiglie di modelli, modalità di accesso, cloud e locale, aperti e chiusi, vendor lock-in", C.accent6, C.text1], ["Solo accennare", "Infrastrutture, API, deployment, orchestrazione, integrazione", C.background2, C.text1]];
    lv.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  // =====================================================================
  section("4.1 Struttura dell'ecosistema");
  divider("4.1", "La struttura dell'ecosistema AI", "Un'applicazione AI è spesso composta da più elementi e non coincide con il modello che utilizza", "Partiamo dalla mappa. Quando si parla di AI si usano spesso come sinonimi termini che indicano cose diverse: modello, sistema, applicazione, piattaforma. E si tende a identificare un prodotto con il modello che usa. In questo sottotema, da comprendere bene, mettiamo ordine: distinguiamo i componenti, i ruoli dei diversi attori e il modo in cui si combinano. È la base per tutto il resto del modulo.");
  {
    const s = content("Modello, sistema, applicazione, piattaforma", "Quattro termini da distinguere. Il modello è il componente addestrato che elabora gli input e genera gli output, come abbiamo visto nel Tema 2: per esempio un grande modello linguistico. Da solo non ha un'interfaccia per l'utente. Il sistema è l'insieme di componenti che lavorano insieme intorno al modello: istruzioni, accesso ai dati, strumenti, filtri di sicurezza, memoria. L'applicazione è il prodotto con cui l'utente interagisce, costruito sul sistema: un assistente conversazionale, una funzione AI dentro un programma di videoscrittura, un'app per trascrivere le riunioni. La piattaforma è un ambiente che offre più servizi e strumenti su cui costruire, configurare e gestire applicazioni AI: per esempio le piattaforme cloud che mettono a disposizione diversi modelli, strumenti di sviluppo e funzioni di amministrazione. I confini non sono sempre netti, e i fornitori usano questi termini in modo diverso. Ma la distinzione serve a porsi le domande giuste: quando valutiamo 'un'AI', stiamo valutando il modello, l'applicazione o la piattaforma?");
    const d = [["FiCpu", "Modello", "Il componente addestrato che elabora input e genera output. Senza interfaccia per l'utente."], ["FiLayers", "Sistema", "I componenti intorno al modello: istruzioni, dati, strumenti, filtri, memoria."], ["FiMonitor", "Applicazione", "Il prodotto con cui l'utente interagisce: assistente, funzione AI in un software, app."], ["FiServer", "Piattaforma", "Un ambiente con più servizi per costruire, configurare e gestire applicazioni AI."]];
    await iconGrid(s, d.map((e, i) => ({ icon: e[0], head: e[1], body: e[2], fill: i === 0 ? C.accent6 : C.background2 })), 4, { y: 1.2, h: 2.75, headSize: 15, bodySize: 12 });
    banner(s, 4.15, "Quando valutiamo \"un'AI\", stiamo valutando il modello, l'applicazione o la piattaforma?", { h: 0.8 });
  }
  {
    const s = content("Foundation models e modelli specializzati", "Al centro dell'ecosistema attuale ci sono i foundation models, o modelli di base: modelli di grandi dimensioni, addestrati su enormi quantità di dati molto vari, capaci di svolgere molti compiti diversi e usati come base per moltissime applicazioni. Il nome indica proprio questo ruolo di fondamenta su cui si costruisce. I grandi modelli linguistici e multimodali sono foundation models. Accanto a questi esistono i modelli specializzati: progettati o adattati per un compito o un dominio specifico, come la trascrizione vocale, la traduzione, l'analisi di immagini mediche, il riconoscimento di documenti, oppure modelli generalisti affinati sul linguaggio di un settore. Hanno ambiti più ristretti, ma spesso prestazioni migliori, costi minori o requisiti di calcolo più bassi per il compito per cui sono pensati. Nella pratica le due categorie convivono: molte applicazioni usano un foundation model per comprendere e generare il linguaggio e modelli specializzati per singole funzioni, come la trascrizione o l'estrazione di dati da documenti scansionati.");
    await twoPanel(s, "Foundation models", bullets(["Grandi, addestrati su dati molto vari", "Molti compiti diversi", "Base per moltissime applicazioni", "Esempio: grandi modelli linguistici e multimodali"], { space: 3 }), "Modelli specializzati", bullets(["Pensati per un compito o un dominio", "Spesso più efficienti per quel compito", "Costi e requisiti di calcolo minori", "Esempio: trascrizione vocale, lettura di documenti"], { space: 3 }), { li: "FiLayers", ri: "FiCrosshair", h: 2.8 });
    banner(s, 4.2, "Nella pratica convivono: molte applicazioni combinano un foundation model e modelli specializzati.", { h: 0.75 });
  }
  {
    const s = content("Gli attori dell'ecosistema", "L'ecosistema è popolato da attori con ruoli diversi, che possiamo organizzare in livelli. Alla base ci sono gli operatori infrastrutturali: produttori di chip, fornitori di cloud e di data center, che offrono la capacità di calcolo necessaria per addestrare e far funzionare i modelli. Poi i fornitori di modelli: aziende e centri di ricerca che sviluppano i modelli, sia proprietari sia con pesi accessibili. Poi le piattaforme, che rendono disponibili i modelli insieme a strumenti di sviluppo, gestione e sicurezza. Infine gli sviluppatori di applicazioni, che costruiscono prodotti per utenti finali o per settori specifici, spesso usando modelli di altri. Alcune grandi aziende tecnologiche sono presenti in tutti i livelli, dall'infrastruttura all'applicazione; altre si concentrano su un solo livello. Per un'azienda utente questa mappa è utile per capire con chi ha a che fare: il fornitore dell'applicazione che usa può essere diverso dal fornitore del modello, che a sua volta può appoggiarsi all'infrastruttura di un terzo. Questo ha conseguenze, per esempio, su dove transitano i dati e su chi è responsabile di cosa. Non entriamo nei dettagli delle infrastrutture, che vanno solo accennati.");
    const L = [["FiMonitor", "Sviluppatori di applicazioni", "Prodotti per utenti finali o settori specifici, spesso con modelli di altri"], ["FiServer", "Piattaforme", "Modelli, strumenti di sviluppo, gestione e sicurezza"], ["FiCpu", "Fornitori di modelli", "Sviluppano modelli proprietari o con pesi accessibili"], ["FiCloud", "Operatori infrastrutturali", "Chip, cloud, data center: la capacità di calcolo"]];
    for (let i = 0; i < 4; i++) {
      const y = 1.2 + i * 0.92, inset = i * 0.2;
      shapeBox(s, 0.5 + inset, y, 5.6 - 2 * inset, 0.8, i === 0 ? C.accent1 : C.background2, L[i][1]);
      await iconCircle(s, 0.65 + inset, y + 0.15, 0.5, L[i][0], i === 0 ? C.background1 : C.accent1, i === 0 ? HEX.a1 : HEX.lt1);
      txt(s, L[i][1], { x: 1.25 + inset, y: y + 0.05, w: 4.7 - 2 * inset, h: 0.35, fontSize: 13, bold: true, color: i === 0 ? C.background1 : C.text1 });
      txt(s, L[i][2], { x: 1.25 + inset, y: y + 0.4, w: 4.7 - 2 * inset, h: 0.38, fontSize: 10, color: i === 0 ? C.accent6 : C.text2 });
    }
    await card(s, 6.4, 1.2, 3.1, 1.75, { head: "Presenti su più livelli", headSize: 14, bodySize: 12, body: "Alcune grandi aziende tecnologiche coprono tutta la filiera; altre un solo livello." });
    await card(s, 6.4, 3.1, 3.1, 1.85, { head: "Per l'azienda utente", headSize: 14, bodySize: 12, fill: C.accent6, body: "Il fornitore dell'applicazione può essere diverso da quello del modello e dell'infrastruttura: dove passano i dati, chi risponde di cosa?" });
  }
  {
    const s = content("Com'è fatta un'applicazione AI", "Apriamo idealmente un'applicazione AI per vedere com'è composta. Lo schema in slide è semplificato ma realistico. C'è l'interfaccia, ciò che l'utente vede: una chat, un pulsante dentro un software, un'app. C'è la logica dell'applicazione, cioè il software che decide che cosa fare con ogni richiesta, quali istruzioni aggiungere, quali dati recuperare, quale modello chiamare. Ci sono uno o più modelli, spesso di fornitori diversi: per esempio un grande modello per le risposte, un modello più piccolo ed economico per compiti semplici, un modello specializzato per la trascrizione. C'è software tradizionale, deterministico, per tutto ciò che non richiede l'AI: calcoli, regole, gestione degli utenti, archiviazione. E ci sono le connessioni ai dati e agli altri sistemi: documenti, database, CRM, posta elettronica. Il punto chiave: il modello è solo uno dei componenti, e la qualità finale dipende da come tutti i pezzi sono combinati. Due applicazioni con lo stesso modello possono offrire esperienze e risultati molto diversi.");
    shapeBox(s, 0.5, 1.2, 9.0, 0.6, C.text1, "interfaccia");
    txt(s, "Interfaccia: chat, pulsante in un software, app", { x: 0.7, y: 1.2, w: 8.6, h: 0.6, fontSize: 14, bold: true, color: C.background1, valign: "middle", align: "center" });
    shapeBox(s, 0.5, 1.95, 9.0, 0.6, C.background2, "logica");
    txt(s, "Logica dell'applicazione: istruzioni, scelta dei dati e del modello", { x: 0.7, y: 1.95, w: 8.6, h: 0.6, fontSize: 14, bold: true, color: C.text1, valign: "middle", align: "center" });
    const comp = [["FiCpu", "Modello principale", C.accent1, C.background1], ["FiZap", "Modello piccolo per compiti semplici", C.accent6, C.text1], ["FiMic", "Modello specializzato", C.accent6, C.text1], ["FiSettings", "Software tradizionale", C.background2, C.text1]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 2.7, 2.15, 1.15, comp[i][2], comp[i][1]);
      await iconCircle(s, x + 0.15, 2.9, 0.48, comp[i][0], i === 0 ? C.background1 : C.accent1, i === 0 ? HEX.a1 : HEX.lt1);
      txt(s, comp[i][1], { x: x + 0.72, y: 2.7, w: 1.38, h: 1.15, fontSize: 12, bold: true, color: comp[i][3], valign: "middle" });
    }
    shapeBox(s, 0.5, 4.0, 9.0, 0.6, C.background2, "dati");
    txt(s, "Connessioni a dati e sistemi: documenti, database, CRM, posta", { x: 0.7, y: 4.0, w: 8.6, h: 0.6, fontSize: 14, bold: true, color: C.text1, valign: "middle", align: "center" });
    txt(s, "Schema semplificato. Il modello è solo uno dei componenti.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Più modelli, modelli che cambiano", "Una conseguenza importante della struttura appena vista: il legame tra applicazione e modello non è fisso. Un'applicazione può usare più modelli contemporaneamente, scegliendo per ogni richiesta quello più adatto per qualità, velocità o costo; alcune applicazioni lo fanno in automatico, altre lasciano scegliere all'utente. Può cambiare modello nel tempo: quando esce una versione nuova, o quando il fornitore dell'applicazione decide di passare a un altro fornitore di modelli. E può combinare i modelli con software tradizionale, affidando all'AI solo le parti in cui è utile. Le conseguenze pratiche per chi usa questi strumenti sono tre. Primo: il comportamento di un'applicazione può cambiare, anche senza che l'interfaccia cambi, perché è cambiato il modello sottostante; una prova fatta sei mesi fa potrebbe non essere più valida. Secondo: conoscere quale modello usa un'applicazione è utile, ma non basta per valutarla. Terzo: quando si sceglie uno strumento, è utile sapere se il fornitore comunica i cambi di modello e se l'azienda può influire su questa scelta. Un esempio recente, da verificare al momento della sessione: in Microsoft 365 Copilot l'utente può scegliere tra modelli di OpenAI e di Anthropic oppure lasciare la scelta alla modalità automatica, e gli amministratori possono disattivare i modelli che l'azienda non autorizza.");
    const k = [["FiShuffle", "Più modelli insieme", "Il più adatto per qualità, velocità o costo, in automatico o a scelta dell'utente"], ["FiRefreshCw", "Modelli che cambiano", "Nuove versioni o passaggio a un altro fornitore"], ["FiSettings", "Modelli + software tradizionale", "L'AI solo dove serve"]];
    await iconGrid(s, k.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, h: 1.75, headSize: 14, bodySize: 12 });
    txt(s, "Che cosa significa per chi li usa", { x: 0.5, y: 3.15, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    ["Il comportamento può cambiare senza che cambi l'interfaccia", "Sapere quale modello usa un'app è utile, ma non basta", "Il fornitore comunica i cambi di modello? Possiamo influire?"].forEach((t, i) => { shapeBox(s, 0.5 + i * 3.07, 3.55, 2.86, 1.4, C.accent6, t); txt(s, t, { x: 0.65 + i * 3.07, y: 3.55, w: 2.56, h: 1.4, fontSize: 13, color: C.text1, valign: "middle" }); });
  }
  {
    const s = content("Ecosistemi integrati e soluzioni composte", "Dal punto di vista dell'azienda utente, possiamo distinguere due configurazioni tipiche. Gli ecosistemi integrati: un unico grande fornitore offre modello, applicazioni, piattaforma e infrastruttura, spesso integrati con altri suoi prodotti già in uso in azienda, come la suite di produttività o il servizio di posta. Vantaggi: semplicità, coerenza, un solo interlocutore, integrazione immediata con gli strumenti esistenti. Limiti: maggiore dipendenza da un solo fornitore e minore libertà di scegliere il componente migliore per ogni esigenza. Le soluzioni composte: l'azienda combina componenti di fornitori diversi, per esempio un modello di un fornitore, una piattaforma di un altro, un'applicazione specializzata di un terzo, collegati tra loro. Vantaggi: flessibilità, possibilità di scegliere il meglio per ogni funzione, minore dipendenza. Limiti: maggiore complessità di integrazione, gestione e responsabilità, e più contratti da governare. Non c'è una configurazione giusta in assoluto: dipende dalle dimensioni dell'azienda, dalle competenze interne, dai sistemi già in uso. Torneremo su questi aspetti parlando di vendor lock-in nel sottotema 4.7.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiBox", head: "Ecosistema integrato", headSize: 16, bodySize: 13,
      body: [{ text: "Un unico fornitore per modello, applicazioni, piattaforma e infrastruttura", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Vantaggi: ", options: { bold: true, color: C.accent1 } }, { text: "semplicità, coerenza, un interlocutore, integrazione con i prodotti già in uso", options: { breakLine: true, paraSpaceAfter: 6 } }, { text: "Limiti: ", options: { bold: true, color: C.accent5 } }, { text: "più dipendenza, meno libertà di scelta", options: {} }] });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiGrid", head: "Soluzione composta", headSize: 16, bodySize: 13, fill: C.accent6,
      body: [{ text: "Componenti di fornitori diversi collegati tra loro", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Vantaggi: ", options: { bold: true, color: C.accent1 } }, { text: "flessibilità, il meglio per ogni funzione, meno dipendenza", options: { breakLine: true, paraSpaceAfter: 6 } }, { text: "Limiti: ", options: { bold: true, color: C.accent5 } }, { text: "più complessità di integrazione, gestione e contratti", options: {} }] });
  }
  keySlide("Un'applicazione AI è spesso composta da più elementi tecnologici e non coincide necessariamente con il modello che utilizza.", "Sottotema 4.1  ·  La struttura dell'ecosistema AI", "Concetto chiave. L'ecosistema si articola in livelli: infrastrutture, modelli, piattaforme, applicazioni. Un'applicazione combina interfaccia, logica, uno o più modelli, software tradizionale e connessioni ai dati, e può cambiare modello nel tempo. Le aziende possono affidarsi a ecosistemi integrati o comporre soluzioni di fornitori diversi. Domanda di verifica: riprendiamo la lista di strumenti scritta alla lavagna all'inizio. Per ciascuno, sappiamo dire se è un modello, un'applicazione o una piattaforma? E chi ne è il fornitore?");

  // =====================================================================
  section("4.2 Famiglie di modelli");
  divider("4.2", "Le principali famiglie di modelli AI", "Modelli differenti rispondono a esigenze differenti: non esiste un unico modello migliore per qualunque attività", "Dopo aver visto il ruolo dei modelli nell'ecosistema, li classifichiamo. È un sottotema a priorità media, da conoscere: non serve imparare i nomi dei singoli modelli, ma riconoscere le famiglie, capire le differenze di dimensioni e requisiti e, soprattutto, comprendere la distinzione tra modelli proprietari e modelli con pesi accessibili, che ha conseguenze concrete sulle possibilità di controllo da parte delle aziende.");
  {
    const s = content("Quattro famiglie di modelli", "Possiamo raggruppare i modelli in quattro grandi famiglie, con la consueta avvertenza che i confini si sovrappongono. I modelli linguistici generalisti: elaborano e generano testo, e sono alla base degli assistenti conversazionali. I modelli multimodali: ricevono e talvolta producono più tipi di dati, come testo, immagini, audio; oggi i principali modelli generalisti sono in gran parte multimodali. I modelli per immagini, audio e video: specializzati nella generazione o nell'elaborazione di questi contenuti, per esempio la generazione di immagini da descrizioni testuali, la trascrizione del parlato, la sintesi vocale, la generazione di brevi video. I modelli specializzati per attività o domini: pensati per compiti specifici, come la classificazione di documenti, la traduzione, l'analisi di codice, oppure per settori come quello medico, legale o finanziario. Gli esempi di modelli citati nelle note vanno verificati e aggiornati prima di ogni sessione, perché cambiano rapidamente: tra le famiglie note di modelli generalisti, a ottobre 2026, ci sono quelle sviluppate da OpenAI, Anthropic, Google, Microsoft, Mistral, Meta e diversi sviluppatori cinesi, come quelli delle famiglie Qwen e DeepSeek.");
    const f = [["FiMessageSquare", "Linguistici generalisti", "Elaborano e generano testo; base degli assistenti conversazionali"], ["FiLayers", "Multimodali", "Testo, immagini, audio insieme; oggi molti modelli generalisti lo sono"], ["FiImage", "Immagini, audio e video", "Generare immagini, trascrivere, sintesi vocale, brevi video"], ["FiCrosshair", "Specializzati", "Per attività (traduzione, documenti, codice) o domini (medico, legale, finanziario)"]];
    await iconGrid(s, f.map((e, i) => ({ icon: e[0], head: e[1], body: e[2], fill: i === 1 ? C.accent6 : C.background2 })), 2, { y: 1.2, H: 3.75, headSize: 15, bodySize: 13 });
  }
  {
    const s = content("Capacità, dimensioni e requisiti", "I modelli differiscono molto per dimensioni, e le dimensioni hanno conseguenze pratiche. I modelli grandi, con centinaia di miliardi di parametri o più, offrono in genere le capacità più ampie, soprattutto nel ragionamento complesso e nella conoscenza generale. Ma richiedono infrastrutture potenti, quindi sono di norma usati via cloud, e sono più costosi e lenti per singola richiesta. I modelli piccoli, con pochi miliardi di parametri, hanno capacità più limitate, ma sono veloci, economici e possono funzionare su un server aziendale, su un normale computer o persino su uno smartphone. Per molti compiti ben definiti, come classificare, estrarre informazioni o riassumere testi brevi, un modello piccolo può essere sufficiente. Molti fornitori offrono oggi famiglie di modelli in più taglie, dalla più potente alla più leggera, proprio per coprire esigenze diverse. Il messaggio pratico: il modello più grande non è sempre la scelta migliore. Conviene scegliere il modello più adatto al compito, bilanciando qualità, velocità, costo e requisiti tecnici.");
    table(s, [["", "Modelli grandi", "Modelli piccoli"], ["Capacità", "Le più ampie, ragionamento complesso", "Più limitate, buone su compiti definiti"], ["Requisiti", "Infrastrutture potenti, di norma cloud", "Server aziendale, computer, smartphone"], ["Velocità", "Più lenti per richiesta", "Veloci"], ["Costo per richiesta", "Più alto", "Più basso"], ["Adatti a", "Compiti complessi e vari", "Classificare, estrarre, riassumere testi brevi"]], { colW: [2.1, 3.45, 3.45], rowH: 0.55, accentCol: 2 });
    banner(s, 4.6, "Il modello più grande non è sempre la scelta migliore: conta l'adeguatezza al compito.", { h: 0.45, fontSize: 13 });
  }
  {
    const s = content("Modelli proprietari e modelli con pesi accessibili", "Una distinzione fondamentale riguarda l'accesso al modello. I modelli proprietari, detti anche chiusi, sono accessibili solo tramite i servizi del fornitore: un'applicazione o un'API. L'azienda utente non riceve il modello, ma ne usa le capacità come servizio. Vantaggi: in genere sono tra i modelli più capaci, non richiedono infrastruttura propria, sono aggiornati e gestiti dal fornitore. Limiti: i dati devono transitare verso il fornitore, secondo le sue condizioni; il fornitore può modificare o ritirare il modello; le possibilità di personalizzazione sono quelle previste dal servizio. I modelli con pesi accessibili, in inglese open-weight, sono modelli i cui parametri, cioè i 'pesi', sono resi scaricabili. L'azienda può quindi eseguirli sulla propria infrastruttura o su un cloud di sua scelta, personalizzarli con un addestramento aggiuntivo e mantenerli invariati nel tempo. Vantaggi: maggiore controllo, possibilità di esecuzione locale, nessuna dipendenza dalla disponibilità del servizio. Limiti: servono competenze e infrastruttura, la responsabilità della gestione e della sicurezza passa all'azienda, e le capacità dei modelli più grandi e recenti possono essere diverse da quelle dei migliori modelli proprietari. Esempi noti di famiglie open-weight, verificati a ottobre 2026 e da ricontrollare prima di ogni sessione, sono Gemma di Google, i modelli di Mistral, gpt-oss di OpenAI, pubblicato nell'agosto 2025, e le famiglie cinesi come Qwen e DeepSeek. La famiglia Llama di Meta è stata a lungo il riferimento dei modelli aperti, ma dal 2026 Meta ha spostato la sua strategia verso modelli prevalentemente chiusi: un buon esempio di quanto rapidamente cambi l'ecosistema, come vedremo nel sottotema 4.8.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiLock", head: "Proprietari (chiusi)", headSize: 16, bodySize: 12,
      body: [{ text: "Accessibili solo tramite i servizi del fornitore", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }].concat(bullets(["Spesso tra i più capaci", "Nessuna infrastruttura propria", "I dati transitano verso il fornitore", "Il fornitore può modificarli o ritirarli"], { space: 2 })) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiDownload", head: "Pesi accessibili (open-weight)", headSize: 16, bodySize: 12, fill: C.accent6,
      body: [{ text: "Parametri scaricabili ed eseguibili altrove", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }].concat(bullets(["Esecuzione locale o su cloud a scelta", "Personalizzabili, invariati nel tempo", "Servono competenze e infrastruttura", "Gestione e sicurezza a carico dell'azienda"], { space: 2 })) });
  }
  {
    const s = content("Open-weight non significa open-source", "Una precisazione importante, perché i termini vengono spesso confusi, anche nella comunicazione commerciale. Un modello AI non è solo i suoi pesi: comprende anche il codice per eseguirlo e addestrarlo, i dati con cui è stato addestrato e le condizioni d'uso, cioè la licenza. Ognuno di questi elementi può essere aperto o chiuso. Un modello open-weight rende disponibili i pesi, ma spesso non i dati di addestramento né tutto il codice, e la licenza può contenere limitazioni: per esempio divieti per certi usi, obblighi di attribuzione, o restrizioni per aziende sopra una certa dimensione. Il termine open-source, nella tradizione del software, indica invece la libertà di usare, studiare, modificare e redistribuire senza discriminazioni. Nel 2024 l'Open Source Initiative, l'organizzazione che custodisce la definizione di open source, ha pubblicato una definizione specifica per l'AI, che richiede anche informazioni dettagliate sui dati di addestramento e la disponibilità del codice. Molti modelli presentati come 'open' non la soddisfano. Il messaggio pratico: davanti a un modello 'aperto', chiedersi che cosa è aperto, e leggere la licenza.");
    const lv = [["FiCpu", "Pesi", "I parametri del modello"], ["FiCode", "Codice", "Per eseguire e addestrare"], ["FiDatabase", "Dati", "Con cui è stato addestrato"], ["FiFileText", "Licenza", "Che cosa si può fare e a quali condizioni"]];
    txt(s, "Che cosa può essere aperto o chiuso", { x: 0.5, y: 1.15, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.55, 2.15, 1.45, C.background2, lv[i][1]);
      await iconCircle(s, x + 0.18, 1.7, 0.5, lv[i][0]);
      txt(s, lv[i][1], { x: x + 0.8, y: 1.7, w: 1.3, h: 0.5, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, lv[i][2], { x: x + 0.18, y: 2.3, w: 1.85, h: 0.6, fontSize: 12, color: C.text2 });
    }
    await card(s, 0.5, 3.2, 4.35, 1.75, { head: "Open-weight", headSize: 15, bodySize: 12, body: "Pesi disponibili; spesso non i dati né tutto il codice. La licenza può limitare usi, attribuzione, dimensione dell'azienda." });
    await card(s, 5.15, 3.2, 4.35, 1.75, { head: "Open-source", headSize: 15, bodySize: 12, fill: C.accent6, body: "Libertà di usare, studiare, modificare, redistribuire. La definizione OSI per l'AI (2024) richiede anche informazioni sui dati e il codice." });
  }
  {
    const s = content("Modelli aperti, chiusi e controllo tecnologico", "Questa integrazione del sottotema collega il grado di apertura alle possibilità concrete per un'azienda. La tabella confronta quattro possibilità: controllare dove vengono elaborati i dati, modificare il modello con un addestramento aggiuntivo, distribuirlo all'interno di propri prodotti, eseguirlo localmente senza connessione a servizi esterni. Con un modello proprietario usato come servizio, queste possibilità dipendono interamente dal fornitore: alcuni offrono scelte sulla regione di elaborazione dei dati o forme di personalizzazione, ma sempre dentro il proprio servizio. Con un modello open-weight, l'azienda può in genere eseguire il modello dove vuole, personalizzarlo e mantenerlo, ma la distribuzione e certi usi dipendono dalla licenza specifica. Con un modello pienamente open-source, le libertà sono più ampie. Attenzione però a non trasformare l'apertura in un valore assoluto. Più controllo significa anche più responsabilità e più competenze necessarie. Per molte aziende un servizio proprietario con buone garanzie contrattuali è la scelta più sensata; per altre, per esempio con dati molto sensibili o esigenze di funzionamento senza rete, il controllo diretto può essere decisivo.");
    table(s, [["Possibilità per l'azienda", "Proprietario come servizio", "Open-weight", "Open-source"], ["Scegliere dove sono elaborati i dati", "Secondo le opzioni del fornitore", "Sì", "Sì"], ["Personalizzare il modello", "Nei limiti del servizio", "Sì, secondo la licenza", "Sì"], ["Distribuirlo nei propri prodotti", "No (si usa il servizio)", "Dipende dalla licenza", "Sì"], ["Eseguirlo localmente", "No", "Sì", "Sì"], ["Competenze e responsabilità interne", "Basse", "Alte", "Alte"]], { colW: [2.9, 2.2, 2.0, 1.9], rowH: 0.52, accentCol: 2, blankCorner: false, fontSize: 12 });
    banner(s, 4.5, "Più controllo significa anche più responsabilità e più competenze necessarie.", { h: 0.5, fontSize: 13 });
  }
  keySlide("Modelli differenti rispondono a esigenze differenti; non esiste un unico modello migliore per qualunque attività.", "Sottotema 4.2  ·  Le principali famiglie di modelli AI", "Concetto chiave. I modelli si differenziano per famiglia, cioè linguistici, multimodali, per media, specializzati; per dimensione, con conseguenze su capacità, costi e requisiti; e per grado di apertura, con conseguenze sul controllo. Open-weight non equivale a open-source, e la licenza va sempre letta. Domanda di verifica: un'azienda deve analizzare documenti molto riservati su computer non collegati a internet. Quali tipi di modelli può considerare? Risposta: modelli open-weight, probabilmente di dimensioni contenute, eseguiti localmente, verificando che la licenza ne consenta l'uso.");

  // =====================================================================
  section("4.3 Piattaforme e strumenti");
  divider("4.3", "Le principali piattaforme e gli strumenti AI", "Prodotti dall'interfaccia simile possono offrire capacità, integrazioni, controlli e condizioni molto diversi", "Passiamo dai modelli ai prodotti. Questo sottotema offre una fotografia dell'offerta attuale, con alcuni esempi indicativi. Ricordiamo il criterio del documento di perimetro: i nomi dei prodotti, le funzioni e le condizioni cambiano rapidamente e vanno verificati prima di ogni sessione. Ciò che conta, e che resta valido nel tempo, è saper leggere l'offerta: distinguere le categorie, riconoscere le funzionalità comuni e le differenze, e verificare ciò che è davvero disponibile.");
  {
    const s = content("Gli assistenti AI generalisti", "La categoria più visibile è quella degli assistenti AI generalisti: applicazioni conversazionali, utilizzabili per compiti molto diversi, accessibili via web, app per computer e smartphone. Il documento di perimetro indica quattro esempi indicativi, tra i più diffusi. ChatGPT, sviluppato da OpenAI, è l'assistente che ha portato l'AI generativa al grande pubblico nel 2022. Claude, sviluppato da Anthropic. Gemini, sviluppato da Google, integrato anche nei servizi e nella suite di produttività Google. Copilot, il marchio con cui Microsoft offre funzioni AI, sia come assistente autonomo sia integrato nella suite Microsoft 365 e in altri prodotti. Ciascuno usa modelli sviluppati dal proprio fornitore o da partner: Copilot, per esempio, oggi usa modelli di più fornitori: OpenAI, Anthropic e modelli sviluppati da Microsoft, con una modalità automatica che sceglie il modello per ogni richiesta. È un buon esempio del sottotema 4.1: dietro lo stesso nome di prodotto possono lavorare modelli diversi, che cambiano nel tempo. Esistono naturalmente molti altri assistenti, anche di sviluppatori europei e asiatici. Non facciamo qui una classifica e non confrontiamo le prestazioni, che cambiano a ogni versione: ci interessa riconoscere la categoria e, nelle prossime slide, le funzionalità comuni e le differenze. Nota per il relatore: verificare prima di ogni sessione nomi, fornitori, integrazioni e disponibilità in Italia.");
    const a = [["ChatGPT", "OpenAI", "L'assistente che ha portato l'AI generativa al grande pubblico"], ["Claude", "Anthropic", "Assistente generalista, disponibile via web, app e API"], ["Gemini", "Google", "Integrato anche nei servizi e nella suite di produttività Google"], ["Copilot", "Microsoft", "Assistente e funzioni AI integrate in Microsoft 365 e altri prodotti"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 2.75, C.background2, a[i][0]);
      await iconCircle(s, x + 0.18, 1.38, 0.5, "FiMessageSquare");
      txt(s, a[i][0], { x: x + 0.18, y: 2.0, w: 1.85, h: 0.4, fontSize: 17, bold: true, color: C.text1 });
      txt(s, a[i][1], { x: x + 0.18, y: 2.4, w: 1.85, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, a[i][2], { x: x + 0.18, y: 2.75, w: 1.85, h: 1.1, fontSize: 12, color: C.text2 });
    }
    banner(s, 4.15, "Esempi indicativi, non una classifica. Nomi, funzioni e disponibilità vanno verificati prima di ogni sessione.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Le categorie di strumenti", "Oltre agli assistenti generalisti, l'offerta comprende molte altre categorie. Gli strumenti per ricerca e analisi: motori di ricerca con risposte generate e fonti citate, strumenti per l'analisi di documenti e dati, funzioni di 'ricerca approfondita' che consultano molte fonti e producono un rapporto. Gli strumenti di produttività: funzioni AI dentro posta, calendario, videoscrittura, fogli di calcolo, presentazioni, videoconferenze, come la trascrizione e la sintesi delle riunioni. Gli strumenti per produzione e gestione di contenuti: generazione di immagini, video, audio e voce, supporto alla scrittura di testi di marketing, traduzione, gestione di contenuti per siti e social. Le applicazioni specializzate: soluzioni per funzioni o settori specifici, come l'assistenza clienti, la selezione del personale, l'analisi legale, lo sviluppo software, la contabilità. Nel 4.4 vedremo che molte di queste capacità arrivano integrate in software già presenti in azienda. Suggerimento: riprendere la lista della lavagna e collocare ciascuno strumento in una categoria.");
    const c = [["FiMessageSquare", "Assistenti generalisti", "Conversazione per compiti molto diversi"], ["FiSearch", "Ricerca e analisi", "Risposte con fonti, analisi di documenti e dati, ricerca approfondita"], ["FiBriefcase", "Produttività", "Posta, documenti, fogli, presentazioni, riunioni"], ["FiImage", "Contenuti", "Immagini, video, voce, testi, traduzioni"], ["FiCrosshair", "Applicazioni specializzate", "Assistenza clienti, selezione, legale, sviluppo, contabilità"]];
    await iconGrid(s, c.slice(0, 3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, h: 1.7, headSize: 14 });
    await iconGrid(s, c.slice(3).map((e, i) => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 3.1, h: 1.4, headSize: 14 });
    txt(s, "Molte capacità arrivano integrate in software già presenti in azienda (sottotema 4.4).", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Funzionalità comuni e differenze principali", "Gli assistenti generalisti hanno oggi molte funzionalità in comune: conversazione in linguaggio naturale, scrittura e revisione di testi, caricamento e analisi di documenti, comprensione di immagini, quasi sempre ricerca sul web, spesso generazione di immagini, analisi di dati con esecuzione di codice, funzioni vocali. A prima vista sembrano quindi molto simili. Le differenze, però, possono essere rilevanti e stanno spesso in aspetti meno visibili. La qualità delle risposte nei compiti che ci interessano. Le integrazioni con gli altri strumenti aziendali, come posta, documenti, CRM. Le funzioni per il lavoro di gruppo, come progetti condivisi e assistenti configurati. I limiti di utilizzo, come il numero di richieste o la dimensione dei file. Le funzioni di amministrazione e controllo per le aziende. Le condizioni sull'uso dei dati, per esempio se le conversazioni possono essere usate per addestrare i modelli. E la disponibilità di ciascuna funzione nel piano che si usa. Il concetto chiave del sottotema lo esprime così: due prodotti dall'interfaccia simile possono offrire capacità, integrazioni, controlli e condizioni molto diversi.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiCopy", head: "Spesso in comune", headSize: 15, bodySize: 13,
      body: bullets(["Conversazione e scrittura", "Caricamento e analisi di documenti", "Comprensione di immagini", "Ricerca sul web", "Analisi di dati, funzioni vocali", "Generazione di immagini"], { space: 2 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiSliders", head: "Dove stanno le differenze", headSize: 15, bodySize: 13, fill: C.accent6,
      body: bullets(["Qualità sui compiti che ci interessano", "Integrazioni con strumenti aziendali", "Funzioni per il lavoro di gruppo", "Limiti di utilizzo", "Amministrazione e controlli", "Condizioni sull'uso dei dati", "Disponibilità nel piano usato"], { space: 2 }) });
  }
  {
    const s = content("Capacità del modello e funzionalità dell'applicazione", "Riprendiamo una distinzione già vista nei Temi 2 e 3, perché qui diventa uno strumento di lettura dell'offerta. Quando un prodotto dichiara una capacità, conviene chiedersi da dove deriva. Alcune capacità derivano soprattutto dal modello: la qualità della scrittura, il ragionamento, la comprensione di immagini, la lunghezza del contesto gestibile. Altre derivano dall'applicazione: la ricerca sul web, l'esecuzione di codice, il collegamento a posta e documenti, la memoria tra conversazioni, i progetti condivisi, i controlli amministrativi, la gestione dei dati. Questa distinzione spiega situazioni frequenti. Lo stesso modello può essere disponibile in due applicazioni diverse con funzioni molto diverse. Un'applicazione può migliorare molto senza cambiare modello, aggiungendo funzioni. E una capacità del modello può non essere disponibile in una certa applicazione o in un certo piano. Per chi valuta uno strumento, il messaggio è chiaro: non basta sapere quale modello usa; bisogna verificare quali funzioni offre l'applicazione, nella configurazione che useremo.");
    await twoPanel(s, "Dal modello", bullets(["Qualità della scrittura", "Ragionamento", "Comprensione di immagini", "Lunghezza del contesto"], { space: 3 }), "Dall'applicazione", bullets(["Ricerca sul web, esecuzione di codice", "Collegamento a posta e documenti", "Memoria e progetti condivisi", "Controlli e gestione dei dati"], { space: 3 }), { li: "FiCpu", ri: "FiPackage", h: 2.6 });
    txt(s, "Situazioni frequenti", { x: 0.5, y: 3.95, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Stesso modello, funzioni diverse in app diverse", "L'app migliora senza cambiare modello", "Una capacità del modello non disponibile in un piano"].forEach((t, i) => chip(s, 0.5 + i * 3.07, 4.35, 2.86, 0.6, t, { fill: C.background2, fontSize: 12 }));
  }
  {
    const s = content("Disponibilità delle funzionalità", "Anche all'interno dello stesso prodotto, le funzionalità non sono le stesse per tutti. Dipendono da almeno quattro fattori. Il piano: le versioni gratuite, individuali a pagamento, per team e per grandi aziende offrono modelli, limiti di utilizzo e funzioni diverse, e spesso condizioni diverse sull'uso dei dati. L'area geografica: alcune funzioni vengono lanciate prima in certi paesi, o non sono disponibili in altri, anche per ragioni normative; in Europa alcune funzioni sono arrivate in ritardo o con limitazioni. Un esempio, secondo le informazioni disponibili a ottobre 2026 e da verificare: in Microsoft 365 Copilot i modelli di Anthropic sono disattivati per impostazione predefinita per le organizzazioni europee, perché i dati vengono elaborati negli Stati Uniti, e l'attivazione è una decisione dell'amministratore. La configurazione organizzativa: nelle versioni aziendali gli amministratori possono attivare o disattivare funzioni, come la ricerca web, i collegamenti a servizi esterni o la memoria, in base alle politiche interne. La modalità di accesso: la versione web, l'app per computer, l'app per smartphone e l'accesso via API non offrono sempre le stesse funzioni. La conseguenza pratica: quando un collega dice 'lo strumento X può fare Y', bisogna chiedersi: in quale piano, in quale paese, con quale configurazione, da quale applicazione? Ed è il motivo per cui una dimostrazione vista online può non essere riproducibile nel nostro ambiente.");
    const f = [["FiLayers", "Piano", "Gratuito, individuale, team, enterprise: modelli, limiti, funzioni e condizioni sui dati diversi"], ["FiGlobe", "Area geografica", "Funzioni lanciate prima altrove, o limitate per ragioni normative"], ["FiSettings", "Configurazione organizzativa", "Gli amministratori attivano o disattivano funzioni"], ["FiSmartphone", "Modalità di accesso", "Web, app per computer, app mobile, API non sempre equivalenti"]];
    await iconGrid(s, f.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.85, headSize: 14, bodySize: 12 });
    banner(s, 4.25, "\"Lo strumento X può fare Y\": in quale piano, in quale paese, con quale configurazione, da quale applicazione?", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Capacità dichiarate e funzionalità disponibili", "Questa integrazione, che ritroveremo anche nel sottotema 4.7, invita a distinguere ciò che il fornitore comunica da ciò che è concretamente accessibile e utilizzabile. La comunicazione commerciale presenta di solito le capacità migliori, nelle condizioni migliori, spesso con funzioni appena annunciate, in anteprima o disponibili solo in alcuni piani e paesi. Non è necessariamente scorretta, ma è incompleta. Lo schema propone quattro passaggi di verifica. Primo: leggere la documentazione ufficiale, non solo gli annunci, cercando le note su disponibilità, limiti e requisiti. Secondo: verificare la configurazione specifica, cioè piano, paese, impostazioni dell'amministratore. Terzo: provare la funzione nell'ambiente reale, con i propri casi e i propri dati di prova, come abbiamo visto nel Tema 3. Quarto: controllare le condizioni, cioè limiti d'uso, costi aggiuntivi, termini sui dati. Termini come 'anteprima', 'beta', 'in arrivo', 'disponibile per alcuni utenti' sono segnali da non sottovalutare: indicano funzioni non ancora stabili o non ancora disponibili per tutti.");
    const st = [["FiBookOpen", "Documentazione ufficiale", "Non solo gli annunci: disponibilità, limiti, requisiti"], ["FiSettings", "Configurazione specifica", "Piano, paese, impostazioni dell'amministratore"], ["FiPlay", "Prova nell'ambiente reale", "Con i propri casi e dati di prova"], ["FiFileText", "Condizioni", "Limiti d'uso, costi aggiuntivi, termini sui dati"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.25, 2.05, 2.5, i === 2 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.4, 0.6, st[i][0]);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.1, y: 2.1, w: 1.85, h: 0.6, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.75, w: 1.75, h: 0.9, fontSize: 11, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.07, 2.3, 0.24);
    }
    txt(s, "Segnali da non sottovalutare", { x: 0.5, y: 3.95, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["\"Anteprima\"", "\"Beta\"", "\"In arrivo\"", "\"Per alcuni utenti\""].forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.35, 2.15, 0.55, t, { fill: C.background1, line: { color: C.accent5, width: 1.25 }, color: C.accent5, fontSize: 13 }));
  }
  keySlide("Due prodotti dall'interfaccia simile possono offrire capacità, integrazioni, controlli e condizioni molto diversi.", "Sottotema 4.3  ·  Le principali piattaforme e gli strumenti AI", "Concetto chiave. L'offerta comprende assistenti generalisti, strumenti di ricerca e analisi, di produttività, di contenuti e applicazioni specializzate. Gli assistenti hanno molte funzioni comuni, ma le differenze stanno in qualità, integrazioni, controlli, limiti e condizioni sui dati. Le funzioni dipendono anche da piano, paese, configurazione e modalità di accesso, e ciò che viene annunciato non coincide sempre con ciò che è disponibile. Domanda di verifica: avete visto in un video una funzione di un assistente AI che vi interessa. Che cosa verificate prima di proporla ai colleghi? Risposta: documentazione ufficiale, disponibilità nel nostro piano e paese, configurazione aziendale, prova reale e condizioni.");

  // =====================================================================
  section("4.4 Generalista, specializzata, integrata");
  divider("4.4", "AI generalista, specializzata e integrata", "Adottare l'AI non richiede necessariamente un nuovo applicativo separato", "Dopo la fotografia dell'offerta, distinguiamo gli approcci. È un sottotema da comprendere bene, perché risponde a una domanda molto concreta: per una certa esigenza, conviene uno strumento generalista, una soluzione specializzata, o le funzioni AI già presenti nei software che usiamo? E qual è la differenza tra usare uno strumento AI e integrare l'AI in un processo?");
  {
    const s = content("Tre approcci", "Le capacità AI possono arrivare in azienda attraverso tre approcci. Le soluzioni generaliste: strumenti come gli assistenti conversazionali, utilizzabili per compiti molto diversi da persone con ruoli diversi. Sono flessibili e immediati, ma richiedono che sia l'utente a portare il contesto, cioè documenti, informazioni e istruzioni. Le applicazioni specializzate: strumenti sviluppati per una funzione o un'attività specifica, come l'assistenza clienti, la selezione del personale, l'analisi dei contratti, la manutenzione degli impianti. Conoscono il dominio, hanno flussi di lavoro pensati per quell'attività e spesso integrazioni specifiche, ma servono solo a quello. L'AI integrata nei software esistenti: funzioni AI che compaiono dentro gli strumenti già in uso, come la suite di produttività, il CRM, l'ERP, il gestionale. Lavorano direttamente sui dati e nei flussi già presenti, senza cambiare strumento, ma con le capacità e i limiti scelti dal fornitore del software. Il concetto chiave del sottotema sottolinea un punto spesso trascurato: adottare l'AI non richiede necessariamente un nuovo applicativo. A volte la via più semplice è attivare e imparare a usare bene le funzioni AI di ciò che si ha già.");
    const a = [["FiMessageSquare", "Generalista", "Molti compiti diversi", ["Flessibile e immediata", "L'utente porta il contesto"]], ["FiCrosshair", "Specializzata", "Una funzione o attività", ["Conosce il dominio e i flussi", "Serve solo a quello"]], ["FiGrid", "Integrata nei software", "Dentro gli strumenti già in uso", ["Lavora sui dati e nei flussi esistenti", "Capacità scelte dal fornitore"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.75, { icon: a[i][0], head: a[i][1], headSize: 16, bodySize: 13, fill: i === 2 ? C.accent6 : C.background2,
      body: [{ text: a[i][2], options: { bold: true, color: C.accent1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(a[i][3], { space: 3 })) });
    banner(s, 4.15, "Adottare l'AI non richiede necessariamente un nuovo applicativo: spesso è già nei software in uso.", { h: 0.8 });
  }
  {
    const s = content("L'AI nei software di produttività e nei gestionali", "Una parte crescente delle capacità AI arriva dentro software che le aziende usano già. Nelle suite di produttività, come quelle di Microsoft e Google: scrivere e riassumere email, preparare bozze di documenti e presentazioni, analizzare fogli di calcolo, trascrivere e sintetizzare riunioni, cercare informazioni tra i propri file. Nei CRM: riassumere la storia di un cliente, suggerire le prossime azioni, preparare bozze di comunicazioni, classificare le richieste. Negli ERP e nei gestionali: leggere documenti come fatture e ordini, segnalare anomalie, rispondere a domande sui dati aziendali in linguaggio naturale, prevedere scorte o flussi di cassa. Il vantaggio principale è che queste funzioni hanno già accesso ai dati e ai flussi di lavoro, rispettano i permessi esistenti e non richiedono di spostare informazioni in un altro strumento. I limiti: le capacità dipendono dalle scelte del fornitore, spesso sono disponibili solo in certi piani o con licenze aggiuntive, e funzionano bene solo se i dati nel sistema sono di buona qualità. Le applicazioni per tipo di attività sono trattate nei Temi 8-11, l'individuazione dei casi d'uso nel Tema 15.");
    const c = [["FiFileText", "Suite di produttività", ["Email e documenti", "Fogli e presentazioni", "Riunioni: trascrizioni e sintesi", "Ricerca tra i propri file"]], ["FiUsers", "CRM", ["Sintesi della storia del cliente", "Prossime azioni suggerite", "Bozze di comunicazioni", "Classificazione delle richieste"]], ["FiDatabase", "ERP e gestionali", ["Lettura di fatture e ordini", "Segnalazione di anomalie", "Domande sui dati in linguaggio naturale", "Previsioni"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.65, { inline: true, icon: c[i][0], head: c[i][1], headSize: 14, bodySize: 12, body: bullets(c[i][2], { space: 3 }) });
    await card(s, 0.5, 4.0, 4.35, 0.95, { head: "Vantaggi: dati, flussi e permessi già presenti", headSize: 13 });
    await card(s, 5.15, 4.0, 4.35, 0.95, { head: "Limiti: scelte del fornitore, licenze, qualità dei dati", headSize: 13, fill: C.accent6 });
  }
  {
    const s = content("Soluzioni pronte all'uso e personalizzate", "Una seconda dimensione, trasversale alle precedenti, distingue le soluzioni pronte all'uso da quelle personalizzate. Le soluzioni pronte all'uso si attivano e si usano così come sono, con eventuali configurazioni di base: rapidità, costi prevedibili, manutenzione a carico del fornitore, ma adattamento limitato alle specificità aziendali. Le soluzioni personalizzate sono adattate o costruite per le esigenze dell'azienda: per esempio un assistente collegato alle procedure interne con un sistema RAG, un flusso che combina un modello con i dati del gestionale, un'applicazione sviluppata su una piattaforma. Offrono un adattamento molto maggiore, ma richiedono tempi, competenze, investimenti e manutenzione continua. Tra i due estremi c'è una fascia intermedia molto importante e in crescita: la configurazione senza sviluppo. Molti strumenti generalisti permettono di creare assistenti personalizzati con istruzioni proprie, documenti di riferimento e collegamenti a fonti aziendali, senza scrivere codice. Spesso è il modo più rapido per ottenere un buon adattamento. Non entriamo nelle procedure di integrazione, che vanno solo accennate.");
    const sp = [["Pronte all'uso", "Si attivano e si usano così come sono", ["Rapide, costi prevedibili", "Adattamento limitato"], C.background2], ["Configurate senza sviluppo", "Assistenti con istruzioni, documenti e fonti proprie", ["Buon adattamento, tempi brevi", "Nei limiti dello strumento"], C.accent6], ["Personalizzate", "Adattate o costruite per l'azienda", ["Massimo adattamento", "Tempi, competenze, manutenzione"], C.background2]];
    s.addShape(pres.shapes.LINE, { x: 0.5, y: 1.3, w: 9.0, h: 0, line: { color: C.accent2, width: 2, endArrowType: "triangle" }, objectName: "personalizzazione" });
    txt(s, "Personalizzazione crescente", { x: 6.5, y: 1.05, w: 3.0, h: 0.25, fontSize: 11, bold: true, color: C.accent2, align: "right" });
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.55, 2.86, 3.4, sp[i][3], sp[i][0]);
      txt(s, sp[i][0], { x: x + 0.2, y: 1.7, w: 2.46, h: 0.65, fontSize: 16, bold: true, color: C.text1 });
      txt(s, sp[i][1], { x: x + 0.2, y: 2.4, w: 2.46, h: 0.8, fontSize: 13, color: C.text1 });
      txt(s, bullets(sp[i][2], { space: 4 }), { x: x + 0.2, y: 3.35, w: 2.46, h: 1.4, fontSize: 12, color: C.text2 });
    }
  }
  {
    const s = content("Vantaggi e limiti dei diversi approcci", "Questa tabella riassume vantaggi e limiti dei tre approcci, per aiutare a rispondere alla quarta domanda guida: quando ha senso usare uno strumento generalista, una soluzione specializzata o l'AI integrata? Lo strumento generalista è adatto quando i compiti sono vari, quando si vuole sperimentare, quando le persone hanno bisogno di un supporto trasversale alla scrittura, all'analisi, alla ricerca. La soluzione specializzata è adatta quando c'è un'attività ricorrente, importante e ben definita, con esigenze specifiche di dominio, flussi e integrazioni. L'AI integrata è adatta quando il lavoro avviene già dentro un certo software, e quando si vuole sfruttare dati e permessi esistenti senza spostare informazioni. Nella pratica le aziende usano spesso una combinazione: uno strumento generalista per tutti, le funzioni AI dei software principali, e soluzioni specializzate per pochi processi chiave. Sottolineare che si tratta di indicazioni generali: la valutazione dei casi d'uso specifici è trattata nel Tema 15.");
    table(s, [["", "Generalista", "Specializzata", "Integrata nei software"], ["Ideale quando", "Compiti vari, sperimentazione", "Attività ricorrente, importante, definita", "Il lavoro avviene già in quel software"], ["Vantaggi", "Flessibile, immediata, per tutti", "Conosce il dominio, flussi dedicati", "Dati, flussi e permessi esistenti"], ["Limiti", "Il contesto lo porta l'utente", "Serve solo a quello, un fornitore in più", "Capacità decise dal fornitore del software"], ["Impegno", "Basso", "Medio o alto", "Basso o medio"]], { colW: [1.7, 2.4, 2.45, 2.45], rowH: 0.62, accentCol: -1, fontSize: 12 });
    banner(s, 4.4, "Spesso si combinano: un generalista per tutti, l'AI nei software principali, soluzioni specializzate per pochi processi chiave.", { h: 0.6, fontSize: 12 });
  }
  {
    const s = content("Usare uno strumento o integrare l'AI in un processo", "L'ultimo punto del sottotema distingue due modi di adottare l'AI, che hanno implicazioni molto diverse. Usare uno strumento AI significa che una persona, nel suo lavoro, apre un assistente e lo usa per un compito: scrivere una bozza, riassumere un documento. Il processo aziendale non cambia; cambia il modo in cui la persona svolge una parte del suo lavoro. I benefici dipendono dall'iniziativa e dalla competenza dei singoli. Integrare capacità AI in un processo significa invece ridisegnare un flusso di lavoro inserendo l'AI in uno o più passaggi, in modo sistematico: per esempio, tutte le richieste che arrivano all'assistenza vengono classificate automaticamente, ricevono una bozza di risposta, e l'operatore verifica e invia. Qui cambiano il processo, i ruoli, i controlli, e servono integrazione con i sistemi, regole, monitoraggio. I benefici possono essere più ampi e misurabili, ma anche l'impegno e i rischi. Entrambi gli approcci sono legittimi e spesso il primo prepara il secondo: l'uso individuale fa emergere le attività in cui l'integrazione può valere la pena. La trasformazione dei processi è trattata nel Tema 13, l'adozione nel Tema 16.");
    await card(s, 0.5, 1.2, 4.35, 3.0, { icon: "FiUser", head: "Usare uno strumento", headSize: 16, bodySize: 13,
      body: bullets(["La persona apre un assistente per un compito", "Il processo non cambia", "Benefici legati a iniziativa e competenza dei singoli", "Impegno e rischi contenuti"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 3.0, { icon: "FiGitBranch", head: "Integrare l'AI in un processo", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["L'AI entra in modo sistematico in uno o più passaggi", "Cambiano processo, ruoli, controlli", "Servono integrazione, regole, monitoraggio", "Benefici più ampi, ma più impegno e rischi"], { space: 3 }) });
    banner(s, 4.35, "Spesso il primo prepara il secondo: l'uso individuale fa emergere dove l'integrazione vale la pena.", { h: 0.6, fontSize: 13 });
  }
  keySlide("Le capacità AI possono essere disponibili in prodotti generalisti, strumenti dedicati o software già presenti in azienda; adottare AI non richiede necessariamente un nuovo applicativo separato.", "Sottotema 4.4  ·  AI generalista, specializzata e integrata", "Concetto chiave. Tre approcci, generalista, specializzato e integrato, con vantaggi e limiti diversi, spesso combinati. Una seconda dimensione va dal pronto all'uso al personalizzato, passando per la configurazione senza sviluppo. E usare uno strumento è diverso da integrare l'AI in un processo. Domanda di verifica: quali funzioni AI sono già disponibili nei software che usate ogni giorno? Le avete mai attivate o provate? Spesso la risposta sorprende: molte capacità sono già lì.");

  // =====================================================================
  section("4.5 Chatbot, assistenti, agenti");
  divider("4.5", "Chatbot, assistenti, agenti e automazioni", "Conversare, ricevere assistenza, automatizzare e delegare sono modalità e livelli di autonomia differenti", "Un sottotema da comprendere nelle differenze, perché i termini chatbot, assistente, agente e automazione sono usati molto, spesso in modo confuso, e la terminologia di mercato non è standardizzata. Introduciamo le categorie e i livelli di autonomia, senza progettare flussi di lavoro: agenti e automazioni sono approfonditi nel Tema 11.");
  {
    const s = content("Uno spettro di autonomia", "Possiamo ordinare queste categorie lungo uno spettro di autonomia crescente. Il chatbot conversa: risponde a domande e richieste, un messaggio alla volta, e la persona decide che cosa fare delle risposte. L'assistente configurato è un chatbot adattato a un compito specifico, con istruzioni, documenti e talvolta strumenti propri: per esempio un assistente per le domande sulle procedure HR. Il sistema con strumenti, oltre a rispondere, può usare strumenti esterni: cercare sul web, eseguire codice, leggere un file, consultare un database, e talvolta compiere un'azione, come creare un evento in calendario, su richiesta. L'agente riceve un obiettivo e svolge in modo relativamente autonomo una sequenza di passaggi per raggiungerlo: pianifica, usa strumenti, valuta i risultati intermedi, decide il passo successivo. Accanto a questi c'è l'automazione, che segue una logica diversa: esegue un flusso predefinito, attivato da un evento, che può includere uno o più passaggi con AI. Il punto chiave: muovendosi lungo lo spettro, cresce quanto il sistema decide e agisce da solo, e cambia il ruolo della persona, da chi usa le risposte a chi supervisiona le azioni.");
    const sp = [["FiMessageCircle", "Chatbot", "Conversa, risponde"], ["FiUserCheck", "Assistente configurato", "Adattato a un compito"], ["FiTool", "Sistema con strumenti", "Cerca, calcola, consulta, agisce su richiesta"], ["FiCompass", "Agente", "Persegue un obiettivo in più passaggi"]];
    s.addShape(pres.shapes.LINE, { x: 0.5, y: 1.3, w: 9.0, h: 0, line: { color: C.accent2, width: 2, endArrowType: "triangle" }, objectName: "autonomia" });
    txt(s, "Autonomia crescente", { x: 6.5, y: 1.05, w: 3.0, h: 0.25, fontSize: 11, bold: true, color: C.accent2, align: "right" });
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, last = i === 3;
      shapeBox(s, x, 1.55, 2.15, 2.1, last ? C.accent1 : (i === 2 ? C.accent6 : C.background2), sp[i][1]);
      await iconCircle(s, x + 0.78, 1.7, 0.6, sp[i][0], last ? C.background1 : C.accent1, last ? HEX.a1 : HEX.lt1);
      txt(s, sp[i][1], { x: x + 0.1, y: 2.4, w: 1.95, h: 0.55, fontSize: 14, bold: true, color: last ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, sp[i][2], { x: x + 0.1, y: 2.95, w: 1.95, h: 0.65, fontSize: 12, color: last ? C.background1 : C.text2, align: "center" });
    }
    shapeBox(s, 0.5, 3.85, 9.0, 1.1, C.background2, "automazione");
    await iconCircle(s, 0.7, 4.12, 0.56, "FiRepeat", C.text2);
    txt(s, [{ text: "Automazione: ", options: { bold: true, color: C.text1 } }, { text: "una logica diversa. Esegue un flusso predefinito, attivato da un evento, che può includere passaggi con AI.", options: { color: C.text2 } }], { x: 1.45, y: 3.85, w: 7.9, h: 1.1, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Chatbot e assistenti configurati", "Partiamo dai livelli più semplici. Il termine chatbot ha una storia lunga: per anni ha indicato i sistemi di risposta automatica dei siti web, spesso basati su regole e menu predefiniti, piuttosto rigidi. Oggi indica soprattutto le interfacce conversazionali basate su modelli linguistici, molto più flessibili. In entrambi i casi la logica è la stessa: domanda e risposta, e la persona decide che cosa fare. Gli assistenti configurati sono un passo avanti: partendo da un assistente generalista, si definiscono istruzioni specifiche, un tono, un ambito, si caricano documenti di riferimento, talvolta si collegano fonti aziendali. Il risultato è un assistente dedicato: per le domande dei dipendenti sulle procedure, per la redazione di offerte secondo lo stile aziendale, per il supporto al servizio clienti. Molti strumenti permettono di creare questi assistenti senza programmare, e di condividerli con i colleghi. Il loro valore sta nel fatto che il contesto non va fornito ogni volta: è incorporato nella configurazione. Restano però sistemi che rispondono, con i limiti di affidabilità visti nel Tema 3, e le cui risposte vanno usate con giudizio.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiMessageCircle", head: "Chatbot", headSize: 16, bodySize: 13,
      body: [{ text: "Ieri: ", options: { bold: true, color: C.text1 } }, { text: "risposte automatiche a regole e menu, rigide", options: { breakLine: true, paraSpaceAfter: 6 } }, { text: "Oggi: ", options: { bold: true, color: C.text1 } }, { text: "interfacce conversazionali basate su modelli linguistici, flessibili", options: { breakLine: true, paraSpaceAfter: 6 } }, { text: "Logica: domanda e risposta, la persona decide", options: { bold: true, color: C.accent1 } }] });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiUserCheck", head: "Assistente configurato", headSize: 16, bodySize: 13, fill: C.accent6,
      body: [{ text: "Istruzioni, tono, ambito, documenti e fonti propri", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }].concat(bullets(["Esempi: procedure per i dipendenti, offerte nello stile aziendale, supporto clienti", "Spesso creabile senza programmare e condivisibile", "Il contesto è nella configurazione"], { space: 3 })) });
  }
  {
    const s = content("Sistemi con strumenti e agenti", "Il salto qualitativo avviene quando il sistema non si limita a rispondere, ma usa strumenti. Un sistema con strumenti può, per esempio, cercare informazioni aggiornate sul web, eseguire codice per un calcolo, leggere un file, interrogare un database, e in alcuni casi compiere azioni nei sistemi collegati: inviare un'email, creare un evento, aggiornare un record. Di norma lo fa su richiesta dell'utente, un passo alla volta. Un agente va oltre: riceve un obiettivo, per esempio 'prepara un confronto tra le offerte di questi tre fornitori e una bozza di email per la direzione', e lo persegue attraverso un ciclo. Pianifica i passaggi, esegue un'azione usando uno strumento, osserva il risultato, decide il passo successivo, e così via fino al completamento, eventualmente chiedendo conferme. Lo schema in slide mostra questo ciclo. Gli agenti stanno diventando molto diffusi: esistono agenti che navigano sul web, che usano il computer al posto dell'utente, che svolgono ricerche approfondite, che scrivono e modificano software. Offrono grandi potenzialità per le attività composte da più passaggi, ma introducono rischi nuovi: un errore a un passaggio si propaga ai successivi, e le azioni compiute possono avere effetti reali difficili da annullare.");
    const cyc = [["Obiettivo", 0.5, 2.2, C.text1, C.background1], ["Pianifica", 2.3, 1.25, C.background2, C.text1], ["Agisce con strumenti", 4.1, 2.2, C.accent1, C.background1], ["Osserva il risultato", 2.3, 3.15, C.background2, C.text1]];
    cyc.forEach(c => chip(s, c[1], c[2], 1.6, 0.75, c[0], { fill: c[3], color: c[4], fontSize: 13 }));
    arrow(s, 2.12, 2.42, 0.17, C.accent2);
    s.addShape(pres.shapes.LINE, { x: 3.9, y: 1.62, w: 0.6, h: 0.58, line: { color: C.accent2, width: 2, endArrowType: "triangle" }, objectName: "freccia" });
    s.addShape(pres.shapes.LINE, { x: 3.9, y: 2.95, w: 0.6, h: 0.58, flipH: true, line: { color: C.accent2, width: 2, endArrowType: "triangle" }, objectName: "freccia" });
    s.addShape(pres.shapes.LINE, { x: 3.1, y: 2.0, w: 0, h: 1.15, flipV: true, line: { color: C.accent2, width: 2, endArrowType: "triangle", dashType: "dash" }, objectName: "freccia" });
    txt(s, "decide il passo successivo", { x: 3.15, y: 2.4, w: 0.95, h: 0.6, fontSize: 9, italic: true, color: C.accent2 });
    txt(s, "Ciclo ripetuto fino al completamento", { x: 0.5, y: 4.05, w: 5.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
    await card(s, 6.0, 1.2, 3.5, 1.75, { inline: true, icon: "FiTool", head: "Sistema con strumenti", bodySize: 12, body: "Cerca, calcola, legge, consulta, agisce: di norma su richiesta, un passo alla volta." });
    await card(s, 6.0, 3.1, 3.5, 1.85, { inline: true, icon: "FiAlertTriangle", head: "Rischi nuovi degli agenti", bodySize: 12, fill: C.accent6, body: "Gli errori si propagano tra i passaggi; le azioni hanno effetti reali, talvolta irreversibili." });
  }
  {
    const s = content("Automazioni tradizionali e workflow con AI", "Le automazioni seguono una logica diversa dagli agenti, ed è utile non confonderle. Un'automazione tradizionale esegue un flusso predefinito, passo per passo, sempre nello stesso modo, quando si verifica un evento: per esempio, quando arriva una fattura, salvala nella cartella giusta e notifica l'amministrazione. È deterministica, prevedibile e verificabile, ma rigida: non sa gestire ciò che non è previsto. Un workflow con componenti AI mantiene la struttura predefinita, ma inserisce l'AI in uno o più passaggi per gestire ciò che le regole non sanno gestire: leggere la fattura e estrarne i dati, classificare una richiesta, scrivere la bozza di una risposta. Il percorso resta deciso da chi ha progettato il flusso; l'AI svolge compiti precisi al suo interno. La differenza con un agente è sostanziale: nel workflow è la persona a decidere la sequenza dei passaggi, nell'agente è il sistema. Per questo i workflow con AI sono spesso più prevedibili e controllabili, e sono la scelta più comune per i processi aziendali ricorrenti; gli agenti sono più flessibili ma meno prevedibili. Non progettiamo qui flussi di lavoro: il tema è approfondito nel Tema 11.");
    table(s, [["", "Automazione tradizionale", "Workflow con AI", "Agente"], ["Chi decide la sequenza", "Chi progetta il flusso", "Chi progetta il flusso", "Il sistema"], ["Ruolo dell'AI", "Nessuno", "Compiti precisi in alcuni passaggi", "Pianifica ed esegue"], ["Prevedibilità", "Massima", "Alta", "Più bassa"], ["Flessibilità", "Bassa", "Media", "Alta"], ["Esempio", "Archivia e notifica", "Estrae e registra i dati", "Gestisce l'intera pratica"]], { colW: [2.1, 2.3, 2.3, 2.3], rowH: 0.5, accentCol: 2, fontSize: 12 });
    banner(s, 4.55, "Nei processi ricorrenti i workflow con AI sono spesso la scelta più prevedibile e controllabile.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Livelli di autonomia e supervisione umana", "Al crescere dell'autonomia cambia il ruolo della supervisione umana, riprendendo lo spettro supporto, supervisione, delega visto nel Tema 3. Possiamo distinguere tre modalità di intervento della persona. La persona nel ciclo, in inglese human in the loop: il sistema propone, la persona approva ogni passaggio o ogni azione rilevante prima che venga eseguita. Per esempio, l'agente prepara l'email, ma la invia solo dopo conferma. La persona sopra il ciclo, human on the loop: il sistema opera in autonomia, la persona monitora, può intervenire e fermarlo, e controlla gli esiti a campione o su eccezioni. La persona fuori dal ciclo: il sistema opera senza supervisione diretta; ammissibile solo per attività a basso impatto, ben collaudate e reversibili. Due indicazioni pratiche. Le azioni che hanno effetti esterni o difficili da annullare, come inviare comunicazioni, effettuare pagamenti, modificare dati, cancellare file, dovrebbero di norma richiedere una conferma umana. E i permessi concessi a un agente dovrebbero essere i minimi necessari: un agente che deve leggere i documenti non ha bisogno di poterli cancellare. Le implicazioni di sicurezza sono approfondite nei Temi 11 e 17.");
    const m = [["Persona nel ciclo", "Approva ogni passaggio o azione rilevante", "L'agente prepara l'email, la invia solo dopo conferma", C.accent6, C.text1], ["Persona sopra il ciclo", "Monitora, può fermare, controlla su eccezioni", "Classificazione automatica con controlli a campione", C.background2, C.text1], ["Persona fuori dal ciclo", "Nessuna supervisione diretta", "Solo attività a basso impatto, collaudate, reversibili", C.text1, C.background1]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.4, m[i][3], m[i][0]);
      txt(s, m[i][0], { x: x + 0.2, y: 1.32, w: 2.46, h: 0.4, fontSize: 15, bold: true, color: m[i][4] });
      txt(s, m[i][1], { x: x + 0.2, y: 1.75, w: 2.46, h: 0.7, fontSize: 13, bold: true, color: i === 2 ? C.accent6 : C.accent1 });
      txt(s, "Esempio: " + m[i][2], { x: x + 0.2, y: 2.5, w: 2.46, h: 1.0, fontSize: 12, color: m[i][4] });
    }
    await card(s, 0.5, 3.8, 4.35, 1.15, { inline: true, icon: "FiCheckSquare", head: "Conferma per azioni con effetti esterni", bodySize: 11, body: "Comunicazioni, pagamenti, modifiche, cancellazioni" });
    await card(s, 5.15, 3.8, 4.35, 1.15, { inline: true, icon: "FiKey", head: "Permessi minimi necessari", bodySize: 11, fill: C.accent6, body: "Chi deve leggere non ha bisogno di cancellare" });
  }
  {
    const s = content("Una terminologia non standardizzata", "Un'avvertenza finale, molto pratica. I termini che abbiamo usato non hanno definizioni condivise nel mercato, e i fornitori li usano in modi diversi, talvolta anche per ragioni di marketing. 'Assistente' può indicare un chatbot generico, un assistente configurato o un sistema con molti strumenti. 'Agente' può indicare un vero sistema che pianifica ed esegue attività in autonomia, ma anche un semplice assistente configurato o un workflow con un passaggio di AI: negli ultimi anni il termine è diventato molto di moda, e viene applicato a prodotti molto diversi. Anche 'copilota' è usato sia come nome di prodotto sia come termine generico per un assistente che affianca l'utente. La conseguenza: davanti a un prodotto, non fermarsi all'etichetta, ma chiedersi che cosa fa davvero. Le quattro domande in slide aiutano: risponde soltanto o agisce? Chi decide la sequenza dei passaggi? Quali strumenti e sistemi può usare, e con quali permessi? Quando e come interviene la persona? Le risposte permettono di collocare qualunque prodotto nello spettro, indipendentemente da come si chiama.");
    txt(s, "Stesso termine, significati diversi", { x: 0.5, y: 1.15, w: 4.35, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    const t = [["\"Assistente\"", "Chatbot generico, assistente configurato, sistema con strumenti"], ["\"Agente\"", "Sistema autonomo, ma anche assistente configurato o workflow"], ["\"Copilota\"", "Nome di prodotto o termine generico"]];
    t.forEach((e, i) => {
      const y = 1.55 + i * 1.1;
      shapeBox(s, 0.5, y, 4.35, 0.95, C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y: y + 0.08, w: 4.0, h: 0.35, fontSize: 15, bold: true, color: C.accent5 });
      txt(s, e[1], { x: 0.7, y: y + 0.45, w: 4.0, h: 0.45, fontSize: 12, color: C.text2 });
    });
    txt(s, "Quattro domande oltre l'etichetta", { x: 5.15, y: 1.15, w: 4.35, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    const q = ["Risponde soltanto o agisce?", "Chi decide la sequenza dei passaggi?", "Quali strumenti e sistemi usa, con quali permessi?", "Quando e come interviene la persona?"];
    q.forEach((e, i) => {
      const y = 1.55 + i * 0.83;
      shapeBox(s, 5.15, y, 4.35, 0.7, C.accent6, e);
      txt(s, String(i + 1), { x: 5.3, y, w: 0.4, h: 0.7, fontSize: 18, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e, { x: 5.75, y, w: 3.65, h: 0.7, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  keySlide("Conversare, ricevere assistenza, automatizzare e delegare l'esecuzione di attività rappresentano modalità e livelli di autonomia differenti.", "Sottotema 4.5  ·  Chatbot, assistenti, agenti e automazioni", "Concetto chiave. Chatbot, assistenti configurati, sistemi con strumenti e agenti si dispongono lungo uno spettro di autonomia crescente; le automazioni seguono una logica diversa, a flusso predefinito, e possono includere passaggi con AI. Più autonomia significa più potenzialità e più rischi, e richiede di definire bene il ruolo della persona e i permessi. E la terminologia di mercato non è standardizzata: conta che cosa fa il sistema, non come si chiama. Domanda di verifica: un fornitore vi propone un 'agente AI per la gestione degli ordini'. Quali domande fate per capire di che cosa si tratta? Le quattro domande della slide precedente.");

  // =====================================================================
  section("4.6 Modalità di accesso");
  divider("4.6", "Modalità di accesso e utilizzo dell'AI", "Capacità analoghe possono essere disponibili in modalità diverse, con implicazioni tecniche, economiche e organizzative", "Questo sottotema, a priorità media, riguarda il come: attraverso quali canali le capacità AI arrivano alle persone e ai sistemi aziendali. La stessa capacità, per esempio riassumere un documento, può essere usata da un'app sul telefono, da un pulsante dentro un software, da un programma aziendale che chiama un'API, o da un modello eseguito su un server interno. Vedremo le principali modalità e le loro differenze generali, senza entrare nella configurazione tecnica, che va solo accennata.");
  {
    const s = content("Le principali modalità di accesso", "Ecco le principali modalità, dalle più vicine all'utente alle più tecniche. Le applicazioni web, desktop e mobili: si usano direttamente, tramite browser, programma installato o app sul telefono. È il modo più diffuso per gli assistenti generalisti. L'AI integrata in applicazioni esistenti: le funzioni compaiono dentro software già in uso, come abbiamo visto nel 4.4. Le API, interfacce di programmazione: permettono a un software di inviare richieste a un modello e ricevere le risposte in modo automatico, senza un'interfaccia per l'utente. Sono la base su cui gli sviluppatori costruiscono applicazioni e integrazioni. Le piattaforme cloud e i servizi gestiti: ambienti offerti dai grandi fornitori cloud che mettono a disposizione più modelli, di fornitori diversi, insieme a strumenti per costruire, gestire e controllare le applicazioni AI. L'esecuzione locale e le infrastrutture dedicate: il modello, tipicamente open-weight, gira su computer o server dell'azienda, o su un'infrastruttura riservata. Le modalità non si escludono: la stessa azienda può usarne diverse per esigenze diverse.");
    const m = [["FiMonitor", "App web, desktop, mobili", "Uso diretto da browser, programma o telefono"], ["FiGrid", "Integrata in app esistenti", "Funzioni dentro i software già in uso"], ["FiCode", "API", "Un software chiama il modello in modo automatico"], ["FiCloud", "Piattaforme cloud gestite", "Più modelli e strumenti per costruire e controllare"], ["FiHardDrive", "Esecuzione locale o dedicata", "Il modello gira su infrastruttura dell'azienda"]];
    for (let i = 0; i < 5; i++) {
      const y = 1.15 + i * 0.77;
      shapeBox(s, 0.5, y, 9.0, 0.68, i % 2 ? C.background1 : C.background2, m[i][1]);
      await iconCircle(s, 0.62, y + 0.1, 0.48, m[i][0]);
      txt(s, m[i][1], { x: 1.25, y, w: 3.4, h: 0.68, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, m[i][2], { x: 4.7, y, w: 4.7, h: 0.68, fontSize: 13, color: C.text2, valign: "middle" });
    }
    txt(s, "Dalle più vicine all'utente alle più tecniche. Non si escludono a vicenda.", { x: 0.5, y: 5.0, w: 9, h: 0.2, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Applicazioni e API: due modi di usare lo stesso modello", "Vale la pena soffermarsi sulla differenza tra applicazione e API, perché spesso genera confusione, anche nei costi. Con un'applicazione, una persona interagisce con il modello attraverso un'interfaccia: scrive, legge, carica file. Di solito si paga un abbonamento per utente, con limiti di utilizzo, e si ottengono anche le funzionalità dell'applicazione, come la ricerca, la memoria, i progetti. Con un'API, è un software a dialogare con il modello: un programma aziendale invia un testo e riceve una risposta, che poi usa in un suo flusso. Non c'è interfaccia per l'utente, e le funzionalità dell'applicazione non sono incluse: vanno costruite. Di solito si paga in base al consumo, cioè alla quantità di testo elaborata, misurata in token, come abbiamo visto nel Tema 2. Le API sono quindi lo strumento per integrare l'AI nei processi e nei prodotti aziendali, mentre le applicazioni sono lo strumento per l'uso individuale. Anche le condizioni sull'uso dei dati possono essere diverse tra i due canali dello stesso fornitore. Non entriamo nella configurazione tecnica delle API, che va solo accennata.");
    table(s, [["", "Applicazione", "API"], ["Chi interagisce", "Una persona, tramite interfaccia", "Un software, in modo automatico"], ["Funzionalità incluse", "Quelle dell'app (ricerca, memoria, progetti...)", "Solo il modello: il resto va costruito"], ["Modello di costo tipico", "Abbonamento per utente, con limiti", "A consumo, in base ai token elaborati"], ["Uso tipico", "Lavoro individuale e di gruppo", "Integrazione in processi e prodotti"], ["Condizioni sui dati", "Secondo il piano dell'app", "Secondo le condizioni dell'API"]], { colW: [2.3, 3.35, 3.35], rowH: 0.58, accentCol: 2 });
    txt(s, "Le condizioni sui dati possono differire tra i canali dello stesso fornitore.", { x: 0.5, y: 4.75, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Cloud ed esecuzione locale", "Una scelta importante riguarda dove vengono elaborati i dati. Nel cloud, il modello gira sui server del fornitore o di una piattaforma cloud, e i dati viaggiano su internet verso quei server. Vantaggi: accesso ai modelli più potenti, nessuna infrastruttura da gestire, scalabilità, aggiornamenti continui. Aspetti da valutare: dove si trovano fisicamente i server, cioè in quale paese o regione; quali garanzie offre il fornitore sui dati; la dipendenza dalla connessione e dalla disponibilità del servizio. Molti fornitori permettono di scegliere la regione di elaborazione, per esempio l'Unione europea. Nell'esecuzione locale, il modello gira su computer o server dell'azienda, o su un'infrastruttura dedicata, e i dati non escono dal perimetro aziendale. Vantaggi: controllo massimo, funzionamento anche senza internet, costi prevedibili una volta sostenuto l'investimento. Aspetti da valutare: serve un modello open-weight adatto; servono hardware e competenze; i modelli che si possono eseguire localmente sono in genere meno capaci dei migliori modelli in cloud; la manutenzione e la sicurezza sono a carico dell'azienda. Esistono anche soluzioni intermedie, come le istanze dedicate o il cloud privato.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiCloud", head: "Cloud", headSize: 16, bodySize: 12,
      body: [{ text: "Il modello gira sui server del fornitore", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }, { text: "Vantaggi: ", options: { bold: true, color: C.accent1 } }, { text: "modelli più potenti, niente infrastruttura, aggiornamenti", options: { breakLine: true, paraSpaceAfter: 6 } }, { text: "Da valutare: ", options: { bold: true, color: C.accent5 } }, { text: "regione dei server, garanzie sui dati, dipendenza dalla connessione. Spesso si può scegliere l'UE.", options: {} }] });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiHardDrive", head: "Esecuzione locale", headSize: 16, bodySize: 12, fill: C.accent6,
      body: [{ text: "Il modello gira su infrastruttura dell'azienda", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }, { text: "Vantaggi: ", options: { bold: true, color: C.accent1 } }, { text: "controllo massimo, funziona senza internet, i dati restano in azienda", options: { breakLine: true, paraSpaceAfter: 6 } }, { text: "Da valutare: ", options: { bold: true, color: C.accent5 } }, { text: "modelli open-weight in genere meno capaci, hardware, competenze, sicurezza a carico dell'azienda.", options: {} }] });
  }
  {
    const s = content("Soluzioni individuali, team ed enterprise", "Molti strumenti sono offerti in versioni diverse per individui, gruppi di lavoro e grandi organizzazioni. Le differenze non riguardano solo il prezzo, ma soprattutto la gestione degli accessi, dei dati e dei controlli. Nelle versioni individuali, gratuite o a pagamento, ciascuno gestisce il proprio account; l'azienda non ha visibilità né controllo, e le condizioni sui dati sono quelle per i consumatori, che possono prevedere, per impostazione predefinita, l'uso delle conversazioni per migliorare i modelli. Nelle versioni team, un amministratore gestisce gli utenti, la fatturazione è centralizzata, ci sono spazi di lavoro condivisi e di solito garanzie migliori sui dati. Nelle versioni enterprise si aggiungono controlli avanzati: accesso con le credenziali aziendali, gestione centralizzata delle autorizzazioni, registri delle attività, controllo sulle funzioni attivabili, impegni contrattuali sulla conservazione e sull'uso dei dati, talvolta scelta della regione di elaborazione. La conseguenza pratica, molto importante: usare per lavoro un account personale gratuito non equivale a usare lo stesso strumento in versione aziendale, anche se l'interfaccia è identica. Le politiche aziendali in materia sono trattate nei Temi 17 e 18.");
    table(s, [["", "Individuale", "Team", "Enterprise"], ["Gestione utenti", "Ciascuno il proprio account", "Amministratore, fatturazione unica", "Credenziali aziendali, autorizzazioni centralizzate"], ["Controlli", "Nessuno per l'azienda", "Di base", "Avanzati: registri, funzioni attivabili"], ["Dati", "Condizioni per consumatori", "Garanzie in genere migliori", "Impegni contrattuali, talvolta regione"], ["Collaborazione", "Personale", "Spazi condivisi", "Spazi condivisi e governati"]], { colW: [1.8, 2.2, 2.3, 2.7], rowH: 0.62, accentCol: 3, fontSize: 12 });
    banner(s, 4.35, "Account personale gratuito e versione aziendale non sono equivalenti, anche con la stessa interfaccia.", { h: 0.6, fontSize: 13 });
  }
  keySlide("Capacità analoghe possono essere rese disponibili attraverso modalità differenti, con implicazioni tecniche, economiche e organizzative diverse.", "Sottotema 4.6  ·  Modalità di accesso e utilizzo dell'AI", "Concetto chiave. App, AI integrata, API, piattaforme cloud ed esecuzione locale sono modi diversi di accedere a capacità simili. Cambiano chi interagisce, quali funzioni sono incluse, come si paga, dove sono elaborati i dati, quanto controllo ha l'azienda. E le versioni individuali, team ed enterprise differiscono soprattutto nella gestione di accessi, dati e controlli. Domanda di verifica: perché usare per lavoro un account personale gratuito di un assistente AI può essere problematico, anche se lo strumento è lo stesso della versione aziendale? Risposta: condizioni sui dati diverse, nessun controllo né visibilità per l'azienda.");

  // =====================================================================
  section("4.7 Criteri di scelta");
  divider("4.7", "Criteri per confrontare e scegliere", "Lo strumento più noto o il modello più potente non è necessariamente la scelta migliore per l'azienda", "Arriviamo al sottotema più operativo, a priorità alta, il cui obiettivo è saper valutare. Mettiamo insieme quanto visto per costruire un insieme di criteri con cui confrontare due o più soluzioni. Ricordiamo il confine: qui parliamo della scelta dello strumento, non della scelta del caso d'uso né della valutazione economica del progetto, che sono trattate nei Temi 12 e 15. E introduciamo privacy e sicurezza come criteri, senza trattare in dettaglio norme e governance.");
  {
    const s = content("Undici criteri", "Ecco gli undici criteri indicati dal documento di perimetro, raggruppati in quattro famiglie per facilitarne l'uso. Primo, l'adeguatezza: lo strumento serve alle attività e agli obiettivi che abbiamo? Le prestazioni sono di qualità e affidabili per quei compiti? È facile da usare e accessibile per le persone che lo useranno? Secondo, le funzionalità e l'integrazione: quali funzioni offre davvero e come si collega ai nostri sistemi? Terzo, i costi e le condizioni: modello di prezzo e costi complessivi, condizioni contrattuali e supporto del fornitore. Quarto, i dati e il controllo: gestione dei dati, riservatezza e sicurezza; controlli amministrativi e gestione degli utenti; portabilità di dati e configurazioni; dipendenza dal fornitore. Trasversale a tutti c'è l'undicesimo criterio: verificare le funzionalità effettivamente disponibili nella configurazione specifica. Non tutti i criteri hanno lo stesso peso in ogni situazione: per un uso sperimentale di un piccolo gruppo conteranno soprattutto adeguatezza e facilità d'uso; per un'adozione aziendale ampia, dati, controlli e lock-in diventano decisivi.");
    const fam = [["Adeguatezza", ["Attività e obiettivi", "Qualità e affidabilità", "Facilità d'uso e accessibilità"], C.accent6], ["Funzionalità e integrazione", ["Funzionalità disponibili", "Possibilità di integrazione"], C.background2], ["Costi e condizioni", ["Prezzo e costi complessivi", "Contratto e supporto"], C.background2], ["Dati e controllo", ["Dati, riservatezza, sicurezza", "Controlli amministrativi", "Portabilità", "Vendor lock-in"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 2.95, fam[i][2], fam[i][0]);
      txt(s, fam[i][0], { x: x + 0.15, y: 1.3, w: 1.85, h: 0.6, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, bullets(fam[i][1], { space: 4 }), { x: x + 0.15, y: 1.95, w: 1.9, h: 2.1, fontSize: 12, color: C.text1 });
    }
    shapeBox(s, 0.5, 4.3, 9.0, 0.65, C.text1, "criterio trasversale");
    await iconCircle(s, 0.65, 4.37, 0.5, "FiCheckSquare", C.accent1);
    txt(s, "Trasversale: verificare le funzionalità effettivamente disponibili nella configurazione specifica", { x: 1.3, y: 4.3, w: 8.1, h: 0.65, fontSize: 13, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Adeguatezza, qualità e facilità d'uso", "Il primo gruppo di criteri riguarda il rapporto tra lo strumento e le esigenze. Adeguatezza alle attività e agli obiettivi: il punto di partenza è sempre il bisogno, non lo strumento. Per quali attività lo useremo? Chi lo userà? Che cosa vogliamo ottenere? Uno strumento eccellente per la generazione di immagini è inutile se ci serve analizzare contratti. Qualità e affidabilità delle prestazioni: qui applichiamo quanto visto nel Tema 3. Non ci basiamo su benchmark e dimostrazioni, ma proviamo lo strumento sui nostri casi reali, compresi quelli difficili, e valutiamo il tipo di errori e la facilità di verificarli. Facilità d'uso e accessibilità: uno strumento potente ma complesso rischia di essere usato poco o male. Contano la chiarezza dell'interfaccia, la lingua italiana, la disponibilità sui dispositivi usati, l'accessibilità per persone con disabilità, la curva di apprendimento. Un suggerimento: coinvolgere nella prova alcuni futuri utenti reali, non solo le persone più esperte di tecnologia.");
    const c = [["FiTarget", "Adeguatezza", ["Per quali attività e chi lo userà?", "Che cosa vogliamo ottenere?", "Prima il bisogno, poi lo strumento"]], ["FiAward", "Qualità e affidabilità", ["Prove sui nostri casi reali", "Anche quelli difficili", "Tipo di errori e facilità di verifica"]], ["FiSmile", "Facilità d'uso", ["Interfaccia chiara, lingua italiana", "Dispositivi e accessibilità", "Curva di apprendimento"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.9, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 13, body: bullets(c[i][2], { space: 4 }) });
    banner(s, 4.3, "Coinvolgere nella prova alcuni futuri utenti reali, non solo i più esperti di tecnologia.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Funzionalità, integrazione e costi complessivi", "Secondo e terzo gruppo di criteri. Funzionalità disponibili e possibilità di integrazione: lo strumento offre le funzioni che ci servono, nel piano che acquisteremo? Si collega ai sistemi che usiamo, come posta, archivio documentale, CRM, gestionale? Ha API per future integrazioni? Modelli di prezzo e costi complessivi: il prezzo di listino è solo una parte del costo. I modelli di prezzo più comuni sono l'abbonamento per utente, il consumo a token tramite API, le licenze aggiuntive per funzioni AI dentro software esistenti, o combinazioni di questi. I costi complessivi comprendono anche l'integrazione con i sistemi, la configurazione, la formazione delle persone, il tempo dedicato alla verifica dei risultati, la gestione e la manutenzione, e gli eventuali costi di uscita se un giorno si cambierà strumento. Un'avvertenza: con il consumo a token i costi possono crescere in modo poco prevedibile se l'uso aumenta; con gli abbonamenti si paga anche chi usa poco. Condizioni contrattuali e supporto: livelli di servizio garantiti, assistenza in italiano, tempi di risposta, durata e recesso. I prezzi specifici cambiano rapidamente e vanno verificati al momento della valutazione.");
    await card(s, 0.5, 1.2, 4.35, 1.85, { inline: true, icon: "FiLink", head: "Funzionalità e integrazione", bodySize: 12, body: "Le funzioni che servono, nel piano acquistato? Collegamenti con posta, archivi, CRM, gestionale? API per il futuro?" });
    await card(s, 0.5, 3.2, 4.35, 1.75, { inline: true, icon: "FiFileText", head: "Contratto e supporto", bodySize: 12, body: "Livelli di servizio, assistenza in italiano, durata e recesso." });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.accent6, "costi complessivi");
    txt(s, "Costi complessivi, oltre il listino", { x: 5.35, y: 1.3, w: 4.0, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const cc = ["Licenze o consumo", "Integrazione e configurazione", "Formazione delle persone", "Tempo per verificare i risultati", "Gestione e manutenzione", "Costi di uscita"];
    cc.forEach((t, i) => { chip(s, 5.35, 1.75 + i * 0.5, 3.95, 0.42, t, { fill: i === 0 ? C.accent1 : C.background1, color: i === 0 ? C.background1 : C.text1, fontSize: 12 }); });
  }
  {
    const s = content("Dati, sicurezza e controlli amministrativi", "Il quarto gruppo di criteri è spesso decisivo per un'adozione aziendale. Introduciamo questi temi come criteri di scelta; normativa, governance e politiche aziendali sono approfonditi nei Temi 17 e 18. Gestione dei dati, riservatezza e sicurezza: le domande essenziali da porre al fornitore sono quelle in slide. I nostri dati vengono usati per addestrare i modelli? Di norma nelle versioni aziendali no, ma va verificato. Per quanto tempo sono conservati, e possiamo cancellarli? Dove vengono elaborati e conservati, in quale paese o regione? Il fornitore si appoggia a terzi, per esempio per il modello o l'infrastruttura, e con quali garanzie? Quali certificazioni di sicurezza possiede? Controlli amministrativi e gestione degli utenti: possiamo gestire centralmente chi accede e con quali permessi, usare le credenziali aziendali, disattivare funzioni non autorizzate, consultare i registri delle attività, rimuovere rapidamente l'accesso a chi lascia l'azienda? Le risposte a queste domande vanno cercate nella documentazione contrattuale e tecnica, non solo nelle pagine commerciali, e conviene coinvolgere le funzioni competenti, come IT, sicurezza e ufficio legale o privacy.");
    txt(s, "Domande sui dati", { x: 0.5, y: 1.15, w: 4.35, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["Sono usati per addestrare i modelli?", "Per quanto tempo sono conservati? Si possono cancellare?", "Dove sono elaborati e conservati?", "Quali terze parti sono coinvolte?", "Quali certificazioni di sicurezza?"], { x: 0.5, w: 4.35, y: 1.55, h: 0.55, fontSize: 12 });
    txt(s, "Domande sui controlli", { x: 5.15, y: 1.15, w: 4.35, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["Gestione centralizzata di accessi e permessi?", "Accesso con credenziali aziendali?", "Disattivazione di funzioni non autorizzate?", "Registri delle attività?", "Revoca rapida degli accessi?"], { x: 5.15, w: 4.35, y: 1.55, h: 0.55, fontSize: 12 });
    banner(s, 4.75, "Cercare le risposte nei documenti contrattuali e coinvolgere IT, sicurezza, legale e privacy.", { h: 0.42, fontSize: 12 });
  }
  {
    const s = content("Indipendenza tecnologica e vendor lock-in", "Questa integrazione del sottotema riguarda la reversibilità delle scelte. Si parla di vendor lock-in, o dipendenza dal fornitore, quando cambiare fornitore diventa così costoso o complicato da essere, di fatto, impraticabile. Nell'AI il rischio è concreto per diverse ragioni. I dati e i contenuti prodotti possono essere difficili da esportare in formati utilizzabili altrove. Le configurazioni, come assistenti personalizzati, istruzioni, flussi di lavoro, integrazioni, possono essere specifiche di una piattaforma e da ricostruire da zero. Le integrazioni con i sistemi aziendali possono essere legate alle API di un fornitore. Le persone si abituano a uno strumento, e il cambio comporta nuova formazione. E se l'AI è integrata in una suite di produttività, cambiare significa cambiare molto di più. Le conseguenze possono riguardare la continuità del servizio, se il fornitore cambia condizioni o ritira un prodotto, la trasferibilità di dati e configurazioni, e i costi futuri, perché un fornitore da cui si dipende ha più potere negoziale. Il criterio collegato è la portabilità: la possibilità di esportare dati e configurazioni e di riutilizzarli altrove. Alcune strategie per ridurre il rischio sono in slide. Non si tratta di evitare ogni dipendenza, che è spesso inevitabile, ma di sceglierla consapevolmente.");
    txt(s, "Dove nasce la dipendenza", { x: 0.5, y: 1.15, w: 4.35, h: 0.3, fontSize: 14, bold: true, color: C.accent5 });
    rowList(s, ["Dati e contenuti difficili da esportare", "Configurazioni specifiche della piattaforma", "Integrazioni legate alle API di un fornitore", "Abitudini e formazione delle persone", "AI integrata in una suite più ampia"], { x: 0.5, w: 4.35, y: 1.55, h: 0.5, fontSize: 12 });
    txt(s, "Come ridurre il rischio", { x: 5.15, y: 1.15, w: 4.35, h: 0.3, fontSize: 14, bold: true, color: C.accent1 });
    const st = ["Verificare l'esportazione di dati e configurazioni", "Preferire formati e standard aperti", "Valutare piattaforme che supportano più modelli", "Documentare istruzioni e flussi fuori dallo strumento", "Leggere le clausole di uscita del contratto"];
    st.forEach((t, i) => { const y = 1.55 + i * 0.58; shapeBox(s, 5.15, y, 4.35, 0.5, C.accent6, t); txt(s, t, { x: 5.35, y, w: 4.0, h: 0.5, fontSize: 12, color: C.text1, valign: "middle" }); });
    banner(s, 4.55, "Non evitare ogni dipendenza, ma sceglierla consapevolmente, valutando la reversibilità.", { h: 0.45, fontSize: 12 });
  }
  {
    const s = content("Verificare ciò che è davvero disponibile", "Ritroviamo qui l'integrazione sulle capacità dichiarate e le funzionalità effettivamente disponibili, già introdotta nel 4.3, ora come parte del processo di scelta. Il principio è semplice: si sceglie sulla base di prove concrete, non sulla base della comunicazione commerciale. In pratica, prima di una scelta impegnativa, conviene organizzare una prova, spesso chiamata pilota. Le tappe in slide: definire le attività da provare e i criteri di successo; ottenere un accesso di prova nella configurazione che si intende acquistare, cioè lo stesso piano, la stessa regione, le stesse impostazioni amministrative; provare con un piccolo gruppo di utenti reali e casi reali, usando dati di prova o dati autorizzati; verificare i limiti del piano, come numero di richieste, dimensione dei file, funzioni incluse e a pagamento; raccogliere riscontri e confrontare i risultati con i criteri. Se si confrontano due strumenti, è utile provarli sugli stessi casi. Infine, ricordare che ciò che si verifica oggi può cambiare: come vedremo nel 4.8, le condizioni vanno ricontrollate nel tempo. Le metodologie strutturate di sperimentazione sono trattate nei Temi 15 e 16.");
    const st = [["FiTarget", "Definire attività e criteri di successo"], ["FiSettings", "Accesso di prova nella configurazione reale"], ["FiUsers", "Utenti e casi reali, dati autorizzati"], ["FiSliders", "Verificare i limiti del piano"], ["FiCheckCircle", "Confrontare i risultati con i criteri"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.25, 1.68, 2.3, i === 2 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.56, 1.4, 0.56, st[i][0]);
      txt(s, (i + 1) + ".", { x: x + 0.1, y: 2.05, w: 1.48, h: 0.3, fontSize: 14, bold: true, color: C.accent1, align: "center" });
      txt(s, st[i][1], { x: x + 0.1, y: 2.35, w: 1.48, h: 1.1, fontSize: 12, bold: true, color: C.text1, align: "center" });
    }
    banner(s, 3.75, "Si sceglie sulla base di prove concrete, non della comunicazione commerciale. Due strumenti si confrontano sugli stessi casi.", { h: 0.75, fontSize: 13 });
    txt(s, "Ciò che si verifica oggi può cambiare: ricontrollare nel tempo (sottotema 4.8).", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Una scheda di confronto", "Per rendere operativi i criteri, ecco una scheda di confronto semplice, che si può riprodurre in un foglio di calcolo. Per ogni criterio si attribuisce un peso, in base all'importanza per la specifica situazione, e si valuta ciascuna soluzione, per esempio da uno a cinque, annotando le evidenze raccolte: prove fatte, documenti letti, risposte del fornitore. I valori in slide sono puramente illustrativi e servono solo a mostrare il formato. Tre raccomandazioni. Primo: definire i pesi prima di valutare le soluzioni, per evitare di adattarli inconsciamente alla soluzione preferita. Secondo: alcuni criteri possono essere requisiti minimi, cioè condizioni senza le quali la soluzione è esclusa a prescindere dal punteggio, per esempio la garanzia che i dati non vengano usati per l'addestramento o l'elaborazione in Unione europea. Terzo: il punteggio aiuta a ragionare, ma non sostituisce il giudizio; serve soprattutto a rendere esplicite e discutibili le ragioni della scelta. E ricordiamo il concetto chiave: lo strumento più noto o il modello più potente non è necessariamente la scelta migliore per l'azienda.");
    table(s, [["Criterio", "Peso", "Soluzione A", "Soluzione B", "Evidenze"], ["Adeguatezza alle attività", "Alto", "4", "3", "Prove su 20 casi reali"], ["Qualità e affidabilità", "Alto", "4", "4", "Errori annotati per tipo"], ["Integrazione con i sistemi", "Medio", "2", "5", "Documentazione tecnica"], ["Costi complessivi", "Medio", "4", "3", "Stima su 12 mesi"], ["Dati e sicurezza", "Requisito", "Sì", "Sì", "Contratto, certificazioni"], ["Portabilità e lock-in", "Medio", "3", "2", "Prova di esportazione"]], { colW: [2.6, 1.1, 1.3, 1.3, 2.7], rowH: 0.45, accentCol: -1, blankCorner: false, fontSize: 12 });
    txt(s, "Valori puramente illustrativi", { x: 0.5, y: 4.5, w: 4, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
    txt(s, "Pesi prima della valutazione  ·  Requisiti minimi escludenti  ·  Il punteggio non sostituisce il giudizio", { x: 0.5, y: 4.8, w: 9, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
  }
  keySlide("Lo strumento più noto o il modello più potente non è necessariamente la scelta migliore per l'azienda.", "Sottotema 4.7  ·  Criteri per confrontare e scegliere gli strumenti AI", "Concetto chiave. La scelta di uno strumento AI si basa su più criteri: adeguatezza, qualità, facilità d'uso, funzionalità e integrazione, costi complessivi, contratto e supporto, dati e sicurezza, controlli, portabilità e dipendenza dal fornitore. Il loro peso dipende dalla situazione. E la scelta va fondata su prove concrete nella configurazione reale, non sulla notorietà del prodotto né sulla comunicazione commerciale. Domanda di verifica: un collega propone di adottare per tutta l'azienda l'assistente AI che usa a casa, perché 'è il migliore'. Quali criteri porterebbero a una valutazione più completa? Risposta: tutti quelli della scheda, in particolare versione aziendale, dati, controlli, integrazione, costi complessivi e prove sui casi reali.");

  // =====================================================================
  section("4.8 Dinamicità dell'ecosistema");
  divider("4.8", "L'evoluzione e la dinamicità dell'ecosistema AI", "I principi di funzionamento e valutazione durano più delle caratteristiche di una singola versione di un prodotto", "Ultimo sottotema, a priorità media, il cui obiettivo è acquisire consapevolezza. Abbiamo ripetuto più volte che prodotti, funzioni e condizioni cambiano rapidamente. Qui guardiamo a questo fenomeno direttamente: che cosa cambia, con quali conseguenze per le aziende e le persone, e perché le competenze trasferibili sono l'investimento più solido. È anche la ragione per cui i criteri del 4.7 vanno rivisti nel tempo.");
  {
    const s = content("Che cosa cambia", "L'ecosistema AI cambia su più fronti contemporaneamente. Le capacità dei modelli: nuove versioni escono a ritmo serrato, con miglioramenti su ragionamento, multimodalità, lunghezza del contesto, velocità, costo; compiti difficili un anno prima diventano ordinari. Le funzionalità: vengono introdotte, modificate, spostate in altri piani, talvolta rimosse; un prodotto può cambiare interfaccia e logica in pochi mesi. La convergenza: applicazioni e piattaforme tendono a offrire funzioni sempre più simili, e i confini tra categorie, per esempio tra assistente, strumento di ricerca e agente, si sfumano; le suite di produttività integrano assistenti, e gli assistenti integrano funzioni di produttività. I modelli commerciali e i prezzi: piani, limiti di utilizzo e tariffe cambiano frequentemente; il costo per elaborare la stessa quantità di testo con un modello di pari capacità è sceso molto negli ultimi anni, ma i modelli più avanzati possono avere costi elevati. Il panorama competitivo: nuovi attori emergono, alcuni prodotti vengono abbandonati, aziende vengono acquisite, alleanze tra fornitori cambiano. Per il relatore: è utile citare un esempio recente, verificato al momento della sessione, di funzione introdotta o ritirata. Due esempi a ottobre 2026: l'arrivo di modelli di più fornitori dentro lo stesso prodotto, come in Microsoft 365 Copilot, e il cambio di strategia di Meta, che dopo anni di modelli aperti si è orientata verso modelli prevalentemente chiusi.");
    const c = [["FiTrendingUp", "Capacità dei modelli", "Nuove versioni frequenti: ragionamento, multimodalità, contesto, costo"], ["FiToggleLeft", "Funzionalità", "Introdotte, modificate, spostate di piano, rimosse"], ["FiGitMerge", "Convergenza", "Funzioni sempre più simili, confini tra categorie sfumati"], ["FiDollarSign", "Modelli commerciali e prezzi", "Piani, limiti e tariffe che cambiano spesso"], ["FiUsers", "Panorama competitivo", "Nuovi attori, prodotti abbandonati, acquisizioni, alleanze"]];
    await iconGrid(s, c.slice(0, 3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, h: 1.75, headSize: 14 });
    await iconGrid(s, c.slice(3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 3.15, h: 1.5, headSize: 14 });
  }
  {
    const s = content("Obsolescenza di strumenti, procedure e competenze", "Il ritmo del cambiamento ha conseguenze concrete. L'obsolescenza degli strumenti: uno strumento scelto oggi può essere superato, cambiare condizioni o essere ritirato; per questo, come abbiamo visto, conviene valutare la reversibilità delle scelte. L'obsolescenza delle procedure: istruzioni operative del tipo 'clicca qui, poi seleziona questa opzione' diventano rapidamente obsolete quando l'interfaccia cambia; anche i prompt e le configurazioni che funzionano bene con un modello possono funzionare diversamente con la versione successiva, e i risultati di una valutazione possono non valere più. L'obsolescenza delle competenze specifiche: saper usare tutte le funzioni di un determinato prodotto è utile, ma è una competenza che invecchia in fretta. Le implicazioni pratiche sono tre. Rivedere periodicamente gli strumenti in uso e le valutazioni fatte. Documentare procedure e configurazioni in modo che siano aggiornabili, distinguendo i principi dai dettagli operativi. E investire soprattutto nelle competenze che non invecchiano, come vedremo nella prossima slide.");
    const o = [["FiPackage", "Strumenti", "Superati, cambiati, ritirati"], ["FiList", "Procedure", "Istruzioni operative, prompt, valutazioni che non valgono più"], ["FiUser", "Competenze specifiche", "Saper usare un prodotto invecchia in fretta"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 1.95, { inline: true, icon: o[i][0], head: o[i][1], headSize: 15, bodySize: 13, body: o[i][2] });
    txt(s, "Che cosa fare", { x: 0.5, y: 3.35, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    ["Rivedere periodicamente strumenti e valutazioni", "Documentare separando principi e dettagli operativi", "Investire nelle competenze che non invecchiano"].forEach((t, i) => { shapeBox(s, 0.5 + i * 3.07, 3.75, 2.86, 1.2, C.accent6, t); txt(s, t, { x: 0.65 + i * 3.07, y: 3.75, w: 2.56, h: 1.2, fontSize: 13, bold: true, color: C.text1, valign: "middle" }); });
  }
  {
    const s = content("Competenze e conoscenze trasferibili", "Questa slide risponde all'ultima domanda guida: perché è utile acquisire competenze trasferibili tra piattaforme diverse? Perché sono le uniche che resistono al ritmo del cambiamento. A sinistra, ciò che cambia rapidamente: i nomi dei prodotti, le interfacce, le singole funzioni, i piani e i prezzi, la classifica dei modelli migliori. A destra, ciò che resta valido nel tempo: come funzionano i modelli e le applicazioni, che è il Tema 2; quali sono le capacità e i limiti e come valutarne l'affidabilità, che è il Tema 3; come è organizzato l'ecosistema, che è questo tema; come scegliere con criteri, che è questo tema; come interagire bene con l'AI e formulare richieste efficaci, che sono i Temi 5 e 6; come verificare i risultati, che è il Tema 7, e usare l'AI in modo responsabile, che sono i Temi 17 e 18. Chi possiede queste competenze può passare da uno strumento all'altro adattandosi in poco tempo, e sa valutare con lucidità ogni novità. È lo stesso messaggio con cui abbiamo chiuso il Tema 1: l'obiettivo della AI Literacy non è formare utenti di un prodotto, ma persone capaci di usare l'AI in modo consapevole, qualunque forma assuma.");
    txt(s, "Cambia rapidamente", { x: 0.5, y: 1.15, w: 3.6, h: 0.35, fontSize: 15, bold: true, color: C.text2 });
    ["Nomi dei prodotti", "Interfacce e funzioni", "Piani e prezzi", "Classifica dei modelli"].forEach((t, i) => { shapeBox(s, 0.5, 1.6 + i * 0.7, 3.6, 0.58, C.background2, t); txt(s, t, { x: 0.7, y: 1.6 + i * 0.7, w: 3.3, h: 0.58, fontSize: 14, color: C.text2, valign: "middle" }); });
    arrow(s, 4.3, 2.75, 0.6, C.accent1);
    txt(s, "Resta valido nel tempo", { x: 5.1, y: 1.15, w: 4.4, h: 0.35, fontSize: 15, bold: true, color: C.accent1 });
    const k = [["FiCpu", "Come funzionano modelli e applicazioni"], ["FiEye", "Capacità, limiti, affidabilità"], ["FiMap", "Come è organizzato l'ecosistema"], ["FiSliders", "Come scegliere con criteri"], ["FiMessageSquare", "Come interagire e formulare richieste"], ["FiCheckSquare", "Come verificare e usare in modo responsabile"]];
    for (let i = 0; i < 6; i++) {
      const y = 1.6 + i * 0.5;
      await iconCircle(s, 5.1, y, 0.4, k[i][0]);
      txt(s, k[i][1], { x: 5.65, y, w: 3.85, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
    }
    txt(s, "Non utenti di un prodotto, ma persone capaci di usare l'AI in modo consapevole.", { x: 0.5, y: 4.7, w: 9, h: 0.35, fontSize: 14, italic: true, color: C.text1 });
  }
  {
    const s = content("Orientarsi senza inseguire ogni novità", "Come restare aggiornati senza essere travolti dal flusso di novità? Ecco alcuni suggerimenti pratici, utili sia per le persone sia per l'organizzazione. Distinguere tra ciò che è annunciato e ciò che è disponibile, applicando le verifiche viste nel 4.3 e nel 4.7. Valutare le novità rispetto alle proprie esigenze: la domanda non è 'che cosa c'è di nuovo?', ma 'questa novità risolve un problema che abbiamo?'. Scegliere poche fonti affidabili, come la documentazione ufficiale e le note di rilascio dei fornitori in uso, e alcune fonti indipendenti di qualità, invece di inseguire ogni annuncio sui social. Definire momenti periodici di revisione, per esempio ogni sei mesi, per riconsiderare gli strumenti in uso e le loro condizioni. Condividere le scoperte all'interno dell'azienda, per esempio con una comunità interna di utenti, in modo che l'aggiornamento non dipenda da pochi appassionati. E sperimentare in modo controllato, in piccolo, prima di adottare su larga scala. Il messaggio centrale del tema lo riassume: conoscere l'ecosistema significa capire come sono organizzate le soluzioni e scegliere consapevolmente quelle adatte alle esigenze, anziché inseguire ogni nuovo prodotto.");
    const t = [["FiFilter", "Annunciato o disponibile?", "Applicare le verifiche"], ["FiTarget", "Risolve un nostro problema?", "Partire dalle esigenze"], ["FiBookOpen", "Poche fonti affidabili", "Documentazione ufficiale e fonti indipendenti"], ["FiCalendar", "Revisioni periodiche", "Per esempio ogni sei mesi"], ["FiUsers", "Condividere in azienda", "Una comunità interna di utenti"], ["FiPlay", "Sperimentare in piccolo", "Prima di adottare su larga scala"]];
    await iconGrid(s, t.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 3.1, headSize: 13, bodySize: 12 });
    banner(s, 4.45, "Capire come sono organizzate le soluzioni e scegliere consapevolmente, anziché inseguire ogni nuovo prodotto.", { h: 0.55, fontSize: 12 });
  }
  keySlide("I principi di funzionamento e valutazione hanno maggiore durata rispetto alle caratteristiche di una singola versione di un prodotto.", "Sottotema 4.8  ·  L'evoluzione e la dinamicità dell'ecosistema AI", "Concetto chiave dell'ultimo sottotema. L'ecosistema cambia su più fronti: capacità, funzionalità, convergenza, prezzi, concorrenza. Ne derivano l'obsolescenza di strumenti, procedure e competenze specifiche, e la necessità di rivedere periodicamente scelte e valutazioni. Le competenze trasferibili, cioè capire il funzionamento, valutare l'affidabilità, conoscere l'ecosistema, scegliere con criteri, interagire bene e verificare, sono l'investimento più duraturo. Domanda di verifica: che cosa di ciò che avete imparato in questi quattro temi sarà ancora valido tra tre anni, e che cosa probabilmente no?");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle dieci domande guida, con una risposta sintetica per ciascuna. Modello e applicazione: il modello è un componente, l'applicazione è il prodotto che lo integra con altri elementi. Categorie: famiglie di modelli e categorie di strumenti, dagli assistenti alle applicazioni specializzate. Prodotti simili, condizioni diverse: per funzioni dell'applicazione, integrazioni, controlli, piani e condizioni sui dati. Generalista, specializzato o integrato: dipende dalla varietà dei compiti, dalla specificità del processo e dai software già in uso. Chatbot, assistenti, agenti, automazioni: livelli di autonomia e logiche diverse. Applicazione, API, locale: chi interagisce, che cosa è incluso, come si paga, dove sono i dati. Fattori di confronto: adeguatezza, qualità, uso, funzioni, costi, contratto, dati, controlli, portabilità. Licenze e lock-in: influenzano controllo e reversibilità delle scelte. Verificare una funzione: documentazione, configurazione, prova reale, condizioni. Competenze trasferibili: perché gli strumenti cambiano e i principi restano. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Modello e applicazione?", "Componente e prodotto che lo integra"], ["Quali categorie?", "Famiglie di modelli e categorie di strumenti"], ["Prodotti simili, condizioni diverse?", "Funzioni, integrazioni, controlli, piani, dati"], ["Generalista, specializzato o integrato?", "Varietà dei compiti, processo, software in uso"], ["Chatbot, assistenti, agenti?", "Livelli di autonomia e logiche diverse"], ["App, API o locale?", "Chi interagisce, cosa è incluso, costi, dati"], ["Come confrontare?", "Undici criteri, pesati sulla situazione"], ["Licenze e lock-in?", "Controllo e reversibilità delle scelte"], ["Verificare una funzione?", "Documentazione, configurazione, prova, condizioni"], ["Competenze trasferibili?", "Gli strumenti cambiano, i principi restano"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.79;
      shapeBox(s, x, y, 4.4, 0.71, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.45, h: 0.71, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.05, w: 3.75, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.36, w: 3.75, h: 0.3, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dieci risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere modello, applicazione, piattaforma e infrastruttura; riconoscere le principali famiglie di modelli; orientarsi tra le categorie di strumenti; distinguere soluzioni generaliste, specializzate e integrate; comprendere le differenze tra chatbot, assistenti, agenti e automazioni; identificare le modalità di accesso; applicare criteri iniziali di confronto; riconoscere vantaggi e limiti dei diversi livelli di apertura tecnologica; comprendere la rilevanza della portabilità e del rischio di dipendenza dal fornitore; verificare condizioni e disponibilità effettive delle funzioni di un prodotto. Con questo tema si conclude l'area 'Comprendere l'AI'.");
    const r = ["Distinguere modello, applicazione, piattaforma, infrastruttura", "Riconoscere le famiglie di modelli", "Orientarsi tra le categorie di strumenti", "Distinguere generalista, specializzato, integrato", "Distinguere chatbot, assistenti, agenti, automazioni", "Identificare le modalità di accesso", "Applicare criteri di confronto", "Valutare i livelli di apertura tecnologica", "Comprendere portabilità e vendor lock-in", "Verificare la disponibilità effettiva delle funzioni"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.79;
      shapeBox(s, x, y, 4.4, 0.7, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.45, h: 0.7, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.75, h: 0.7, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Prima di scegliere uno strumento AI: una checklist", "Come per il Tema 3, traduciamo il modulo in una checklist operativa, utile ogni volta che si valuta l'adozione di uno strumento AI, per sé, per il proprio gruppo o per l'azienda. Otto domande. Per quali attività e obiettivi lo useremo, e chi lo userà? È un modello, un'applicazione o una piattaforma, e quali componenti include? Esistono già funzioni AI nei software che usiamo per le stesse attività? Che livello di autonomia ha, e dove interviene la persona? Le funzioni che ci servono sono disponibili nel nostro piano, paese e configurazione? Che cosa succede ai nostri dati, e quali controlli abbiamo? Quanto costa davvero, oltre il listino? Possiamo uscire, portando con noi dati e configurazioni? Se a una domanda non sappiamo rispondere, è un'informazione da cercare prima della scelta.");
    const q = [["FiTarget", "Per quali attività, obiettivi e persone?"], ["FiLayers", "Modello, applicazione o piattaforma? Quali componenti?"], ["FiGrid", "Ci sono già funzioni AI nei software in uso?"], ["FiSliders", "Che autonomia ha? Dove interviene la persona?"], ["FiCheckSquare", "Le funzioni sono disponibili nel nostro piano, paese, configurazione?"], ["FiShield", "Che cosa succede ai dati? Quali controlli abbiamo?"], ["FiDollarSign", "Quanto costa davvero, oltre il listino?"], ["FiLogOut", "Possiamo uscire, portando dati e configurazioni?"]];
    for (let i = 0; i < 8; i++) {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 9.0, 0.41, i % 2 ? C.background1 : C.background2, "check " + (i + 1));
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.62, y: y + 0.08, w: 0.25, h: 0.25, rectRadius: 0.04, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 }, objectName: "casella" });
      await iconCircle(s, 1.0, y + 0.03, 0.35, q[i][0]);
      txt(s, q[i][1], { x: 1.5, y, w: 7.9, h: 0.41, fontSize: 13, color: C.text1, valign: "middle" });
    }
    txt(s, "Se a una domanda non sappiamo rispondere, è un'informazione da cercare prima della scelta.", { x: 0.5, y: 4.9, w: 9, h: 0.25, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei semplificazioni da evitare quando si parla di strumenti AI, una per ciascuno dei principali messaggi del modulo. Primo: 'il prodotto è il modello'. Un'applicazione combina interfaccia, logica, uno o più modelli, software tradizionale e connessioni ai dati, e il modello sottostante può cambiare nel tempo. Secondo: 'aperto vuol dire libero da vincoli'. Open-weight non significa open-source, e la licenza va sempre letta. Terzo: 'l'ho visto nella demo, quindi c'è anche da noi'. Le funzioni dipendono da piano, paese, configurazione e modalità di accesso. Quarto: 'si chiama agente, quindi è autonomo'. La terminologia di mercato non è standardizzata: conta che cosa fa il sistema, con quali permessi e con quale supervisione. Quinto: 'l'account personale va bene anche per lavoro'. Le condizioni sui dati e i controlli sono diversi da quelli della versione aziendale, anche con la stessa interfaccia. Sesto: 'il più noto è il migliore per noi'. La scelta si fa con criteri espliciti e prove sui propri casi, e va rivista nel tempo. Suggerimento: chiedere ai partecipanti quale di queste idee hanno sentito più spesso in azienda.");
    const a = [["FiBox", "\"Il prodotto è il modello\"", "Un'applicazione ha molti componenti", "4.1"], ["FiUnlock", "\"Aperto vuol dire libero da vincoli\"", "Open-weight non è open-source", "4.2"], ["FiPlayCircle", "\"L'ho visto nella demo, quindi c'è\"", "Piano, paese, configurazione", "4.3"], ["FiCpu", "\"Si chiama agente, quindi è autonomo\"", "Conta che cosa fa, non il nome", "4.5"], ["FiUser", "\"L'account personale va bene per lavoro\"", "Dati e controlli diversi", "4.6"], ["FiStar", "\"Il più noto è il migliore per noi\"", "Criteri espliciti e prove reali", "4.7"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Prossimo passo: il Tema 5", "Con il Tema 4 si chiude l'area 'Comprendere l'AI': sappiamo perché l'AI è rilevante, come funziona, quanto possiamo fidarci dei suoi risultati e come è organizzato l'ecosistema degli strumenti. Il percorso prosegue con l'area 'Interagire con l'AI', che si apre con il Tema 5, dedicato al dialogo uomo-AI: il linguaggio naturale come interfaccia, il passaggio dalla domanda alla conversazione, i ruoli che l'AI può assumere, la collaborazione, i livelli di delega e i rischi della relazione conversazionale. Seguirà il Tema 6, dedicato al prompting e alle tecniche di interazione. Tutti i concetti visti finora, dal contesto alla variabilità, dall'affidabilità alla verifica, dalla distinzione tra modello e applicazione ai livelli di autonomia, saranno la base per passare dalla comprensione alla pratica. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.background2, "area comprendere");
    txt(s, "AREA COMPLETATA", { x: 0.75, y: 1.4, w: 3.1, h: 0.35, fontSize: 13, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.8, w: 3.1, h: 0.5, fontSize: 18, bold: true, color: C.text1 });
    txt(s, bullets(["Tema 1: evoluzione e rilevanza", "Tema 2: fondamenti e funzionamento", "Tema 3: capacità, limiti, affidabilità", "Tema 4: ecosistema AI"], { space: 4 }), { x: 0.75, y: 2.45, w: 3.2, h: 2.2, fontSize: 13, color: C.text2 });
    arrow(s, 4.25, 2.9, 0.55, C.accent1);
    shapeBox(s, 4.95, 1.2, 4.55, 3.75, C.text1, "tema 5");
    txt(s, "TEMA 5", { x: 5.2, y: 1.4, w: 4.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Il dialogo uomo-AI", { x: 5.2, y: 1.8, w: 4.1, h: 0.5, fontSize: 18, bold: true, color: C.background1 });
    txt(s, bullets(["Il linguaggio naturale come interfaccia", "Dalla domanda alla conversazione", "Collaborazione e livelli di delega", "A seguire, Tema 6: prompting"], { space: 3 }), { x: 5.2, y: 2.45, w: 4.1, h: 2.3, fontSize: 14, color: C.accent3 });
  }
  {
    const s = content("Nota sull'aggiornamento dei contenuti", "Questa slide è pensata per il relatore e per chi mantiene il materiale; può essere nascosta durante la presentazione. Il documento di perimetro del Tema 4 stabilisce che esempi di piattaforme, caratteristiche, prezzi e disponibilità geografiche devono essere verificati e aggiornati prima di ogni erogazione, perché sono elementi variabili e non costituiscono il nucleo durevole del tema. Le slide contengono pochi riferimenti di questo tipo, concentrati nel sottotema 4.3 e nelle note del 4.2. Prima di ogni edizione verificare: nomi, fornitori e integrazioni degli assistenti citati; disponibilità delle funzioni in Italia e nell'Unione europea; esempi di famiglie di modelli proprietari e open-weight; differenze tra versioni individuali, team ed enterprise; eventuali novità rilevanti, come funzioni introdotte o ritirate, da usare come esempio nel 4.8. Fonti da consultare: documentazione ufficiale e note di rilascio dei fornitori; per la definizione di open-source AI, il sito dell'Open Source Initiative.");
    await iconCircle(s, 0.5, 1.25, 0.6, "FiRefreshCw");
    txt(s, "Da verificare prima di ogni edizione  ·  ultima verifica: ottobre 2026", { x: 1.3, y: 1.25, w: 8.2, h: 0.6, fontSize: 16, bold: true, color: C.text1, valign: "middle" });
    rowList(s, ["Nomi, fornitori e integrazioni degli assistenti citati (4.3)", "Disponibilità delle funzioni in Italia e nell'Unione europea", "Esempi di famiglie di modelli proprietari e open-weight (4.2)", "Differenze tra versioni individuali, team ed enterprise (4.6)", "Novità recenti da usare come esempio (4.8)"], { y: 2.0, h: 0.5, fontSize: 13 });
    txt(s, "Fonti: documentazione ufficiale e note di rilascio dei fornitori; Open Source Initiative, Open Source AI Definition 1.0 (2024).", { x: 0.5, y: 4.95, w: 9, h: 0.25, fontSize: 10, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema4_Ecosistema_AI.pptx" });
  await applyTheme("Tema4_Ecosistema_AI.pptx", THEME);
  console.log("done");
})();
