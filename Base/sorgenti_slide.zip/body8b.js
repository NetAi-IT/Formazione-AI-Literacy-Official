
  // =====================================================================
  section("8.3 Sintesi e analisi");
  divider("8.3", "Sintesi e analisi documentale", "Una sintesi utile rappresenta fedelmente gli elementi essenziali e consente controlli sui contenuti originali", "Entriamo nel nucleo distintivo del tema. Con i sottotemi 8.3, 8.4 e 8.5 l'AI non produce testi nuovi né riscrive testi esistenti: lavora sui documenti per ricavarne qualcosa. In questo sottotema, da comprendere e sperimentare, vediamo la sintesi e l'analisi dei documenti: riassunti, sintesi esecutive, individuazione dei concetti e dei passaggi rilevanti, analisi di documentazione tecnica e organizzativa. E due integrazioni importanti: la tracciabilità, cioè la possibilità di risalire ai passaggi originali, e il rischio di perdita di significato, cioè sintesi che sembrano fedeli ma hanno eliminato elementi decisivi.");
  {
    const s = content("Le possibilità su un documento", "Le possibilità dell'AI nella sintesi e nell'analisi di documenti sono molte e, per chi lavora con grandi quantità di materiale, di grande valore. Riassumere: ridurre un documento ai suoi contenuti principali, con lunghezza e livello di dettaglio scelti. Sintetizzare contenuti lunghi e articolati: rapporti, verbali di più riunioni, documentazione di progetto. Identificare i concetti principali: i temi, le tesi, le decisioni, le richieste. Individuare informazioni e passaggi rilevanti: dove il documento parla di un certo argomento, che cosa dice su penali, scadenze, responsabilità. Produrre sintesi esecutive: una pagina per chi deve decidere, con ciò che serve sapere. Analizzare documentazione tecnica e organizzativa: capire che cosa prevede una procedura, che cosa richiede un capitolato, quali sono i punti aperti di un progetto. I sistemi attuali possono lavorare con i formati più comuni, come PDF, Word e testo, e molti accettano più documenti insieme. Il valore principale è il tempo: un primo orientamento su un documento di cento pagine in pochi minuti. Ma, come vedremo, un primo orientamento non è una lettura completa.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiAlignLeft", head: "Riassumere", body: "Contenuti principali, lunghezza e dettaglio scelti" },
      { icon: "FiTarget", head: "Concetti principali", body: "Temi, tesi, decisioni, richieste" },
      { icon: "FiSearch", head: "Passaggi rilevanti", body: "Dove e che cosa dice su penali, scadenze, responsabilità" },
      { icon: "FiBriefcase", head: "Sintesi esecutive", body: "Una pagina per chi deve decidere" },
      { icon: "FiTool", head: "Documentazione tecnica", body: "Procedure, capitolati, specifiche" },
      { icon: "FiFile", head: "Formati diversi", body: "PDF, Word, testo; spesso più documenti insieme" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Un primo orientamento su cento pagine in pochi minuti. Ma un orientamento non è una lettura completa.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Sintesi diverse per scopi diversi", "Non esiste la sintesi giusta in assoluto: esiste la sintesi adatta a uno scopo. Lo stesso documento, per esempio un contratto di fornitura, può essere sintetizzato in modi molto diversi. Una sintesi informativa generale riassume di che cosa parla e quali sono i contenuti principali: utile per orientarsi. Una sintesi esecutiva evidenzia ciò che serve a chi deve decidere: condizioni economiche, durata, rischi, punti da negoziare. Una sintesi operativa estrae ciò che serve a chi deve applicare il documento: scadenze, adempimenti, responsabilità, contatti. Una sintesi mirata risponde a una domanda specifica: che cosa prevede il contratto in caso di ritardo nelle consegne? Dichiarare lo scopo della sintesi, come visto nel Tema 6, migliora molto il risultato, perché guida il sistema nella scelta di che cosa tenere. Senza indicazioni, il sistema tende a produrre una sintesi generica, equilibrata in apparenza, che dà lo stesso spazio a elementi importanti e secondari, e può trascurare proprio ciò che serviva. Lo scopo determina anche il controllo: una sintesi per orientarsi richiede meno verifica di una sintesi su cui si basa una decisione.");
    modeTag(s, 2);
    table(s, [["Tipo di sintesi", "A chi serve", "Che cosa evidenzia"],
      ["Informativa", "A chi deve orientarsi", "Di che cosa parla, contenuti principali"],
      ["Esecutiva", "A chi deve decidere", "Condizioni, rischi, punti da negoziare"],
      ["Operativa", "A chi deve applicare", "Scadenze, adempimenti, responsabilità"],
      ["Mirata", "A chi ha una domanda", "Solo ciò che risponde alla domanda"]],
      { y: 1.15, colW: [2.2, 2.8, 4.0], rowH: 0.48, fontSize: 13, blankCorner: false });
    banner(s, 3.8, "Dichiarare lo scopo guida la scelta di che cosa tenere. Senza scopo, la sintesi è generica e può trascurare proprio ciò che serviva.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Tracciabilità: risalire alle fonti", "Prima integrazione del sottotema: la tracciabilità delle informazioni e il collegamento alle fonti. Una sintesi è tanto più utile quanto più permette, quando serve, di risalire ai passaggi del documento originale. Se una sintesi dice che il contratto prevede una penale del 2 per cento per ogni settimana di ritardo, poter andare subito all'articolo e al paragrafo in cui lo dice trasforma un'affermazione da prendere sulla fiducia in un'affermazione controllabile in pochi secondi. Per questo, quando l'uso lo richiede, conviene chiedere esplicitamente che ogni punto della sintesi indichi la sezione, l'articolo, la pagina o il passaggio da cui deriva, e, per i punti critici, anche una breve citazione testuale. L'esempio fittizio in slide mostra una sintesi con riferimenti. Il vantaggio è doppio: rende la verifica rapida e mirata, e rende visibili i punti della sintesi che non hanno un riferimento, che sono quelli da trattare con più cautela, perché potrebbero essere interpretazioni del sistema o informazioni non presenti nel documento. La tracciabilità è richiesta anche da molti strumenti aziendali di consultazione documentale, come vedremo nell'8.7.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 5.6, 2.9, "Sintesi con riferimenti (esempio fittizio)", "", { fill: C.background2 });
    const pts = [["Durata: tre anni, rinnovo tacito annuale", "art. 4.1"], ["Penale: 2% per settimana di ritardo, massimo 10%", "art. 9.2"], ["Recesso: preavviso di 90 giorni", "art. 12.1"], ["Esclusiva territoriale per il Nord Italia", "nessun riferimento"]];
    pts.forEach((p, i) => {
      const y = 1.62 + i * 0.58;
      const none = i === 3;
      txt(s, p[0], { x: 0.75, y, w: 3.75, h: 0.48, fontSize: 12, color: C.text1, valign: "middle" });
      chip(s, 4.55, y + 0.06, 1.4, 0.36, p[1], { fill: none ? C.accent5 : C.accent1, color: C.background1, fontSize: 10 });
    });
    await card(s, 6.35, 1.15, 3.15, 2.9, { icon: "FiLink", head: "Perché conta", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Verifica in pochi secondi", "Si vede subito ciò che non ha riferimento", "Per i punti critici: anche la citazione testuale"], { space: 5 }) });
    banner(s, 4.25, "Un punto senza riferimento va trattato con più cautela: può essere un'interpretazione o non essere nel documento.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Riferimenti davvero controllabili", "La seconda parte dell'integrazione sulla tracciabilità è un'avvertenza: un riferimento presentato dall'AI deve essere realmente controllabile. Non basta che la sintesi contenga dei riferimenti: occorre che siano corretti. I sistemi possono indicare un articolo sbagliato, un numero di pagina approssimativo, una sezione che non esiste, o una citazione testuale che in realtà è una parafrasi, magari con piccole differenze di significato. È lo stesso fenomeno visto nel Tema 3 per le fonti inventate, applicato ai riferimenti interni a un documento. Per i numeri di pagina, in particolare, l'affidabilità dipende dal formato del documento e dal modo in cui lo strumento lo elabora. Il controllo, per i punti importanti, è semplice: aprire il documento nel punto indicato e leggere il passaggio. Tre verifiche, coerenti con quelle viste nel Tema 7 per le fonti: il passaggio esiste nel punto indicato; dice ciò che la sintesi afferma, con le stesse condizioni; la citazione, se presentata come testuale, corrisponde parola per parola. Un buon segnale pratico: gli strumenti che mostrano direttamente il passaggio citato, con un collegamento cliccabile al documento, rendono questo controllo molto più rapido.");
    modeTag(s, 2);
    const ck = [["FiMapPin", "Esiste", "Il passaggio è nel punto indicato?"], ["FiCheckCircle", "Sostiene", "Dice ciò che la sintesi afferma, con le stesse condizioni?"], ["FiType", "Corrisponde", "La citazione testuale è davvero parola per parola?"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 1.9, C.background2, ck[i][1]);
      await iconCircle(s, x + 1.08, 1.32, 0.7, ck[i][0]);
      txt(s, (i + 1) + ". " + ck[i][1], { x: x + 0.15, y: 2.08, w: 2.56, h: 0.38, fontSize: 16, bold: true, color: C.text1, align: "center" });
      txt(s, ck[i][2], { x: x + 0.2, y: 2.46, w: 2.46, h: 0.6, fontSize: 12, color: C.text2, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.0, 0.17);
    }
    await card(s, 0.5, 3.3, 9.0, 1.65, { icon: "FiAlertTriangle", inline: true, head: "Che cosa può andare storto", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: "Articolo sbagliato, pagina approssimativa, sezione inesistente, parafrasi presentata come citazione. Lo stesso fenomeno delle fonti inventate (Tema 3), dentro un singolo documento." });
  }
  {
    const s = content("Il rischio di perdita di significato", "Seconda integrazione, forse la più importante del tema: il rischio di perdita di significato nella sintesi. Una sintesi può apparire fedele pur avendo eliminato eccezioni, vincoli, sfumature o elementi decisivi. Il motivo è intrinseco: sintetizzare significa togliere, e il sistema sceglie che cosa togliere secondo criteri che non conosciamo e che non coincidono necessariamente con ciò che per noi è importante. Gli elementi più a rischio sono proprio quelli che, in un testo, occupano poco spazio ma hanno grande peso: una condizione introdotta da 'solo se', un'eccezione introdotta da 'salvo', una negazione, un limite numerico, una scadenza, un'attribuzione di responsabilità, un'espressione di incertezza come 'in via preliminare' o 'da confermare'. L'esempio fittizio in slide mostra un estratto di verbale e una sintesi che sembra corretta: ogni frase è vera, ma la decisione appare definitiva, mentre era condizionata all'approvazione del budget, e l'incertezza sui tempi è sparita. Chi legge la sintesi crede che il progetto sia approvato. Il punto chiave è che queste perdite non si vedono leggendo la sintesi: la sintesi è scorrevole, coerente, ben organizzata. Si vedono solo confrontandola con l'originale, o sapendo che cosa cercare.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 4.35, 2.6, "Verbale originale (esempio fittizio)", "Il comitato approva in via preliminare l'avvio del progetto, subordinatamente all'approvazione del budget nella riunione di aprile. I tempi di consegna indicati dal fornitore sono da confermare.", { fontSize: 12 });
    docBox(s, 5.15, 1.15, 4.35, 2.6, "Sintesi", "Il comitato ha approvato l'avvio del progetto. Sono stati discussi budget e tempi di consegna.", { fontSize: 13, fill: C.accent6 });
    chip(s, 5.35, 2.5, 1.95, 0.42, "Condizione persa", { fill: C.accent5, color: C.background1, fontSize: 11 });
    chip(s, 7.4, 2.5, 1.9, 0.42, "Incertezza persa", { fill: C.accent5, color: C.background1, fontSize: 11 });
    banner(s, 3.95, "Ogni frase è vera, ma chi legge crede che il progetto sia approvato. La perdita non si vede leggendo la sintesi.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Dove si perde il significato", "Per controllare una sintesi in modo efficiente, conviene sapere dove cercare. Gli elementi più a rischio sono quelli che occupano poco spazio nel testo ma cambiano le conseguenze. Condizioni: 'solo se', 'a condizione che', 'subordinatamente a'. Eccezioni: 'salvo', 'tranne', 'ad eccezione di'. Limiti e soglie: importi massimi, percentuali, quantità. Scadenze e tempi: date, termini, durate, preavvisi. Responsabilità: chi deve fare che cosa, chi risponde di che cosa. Gradi di certezza e di obbligo: 'in via preliminare', 'da confermare', 'si raccomanda', 'è obbligatorio'. Negazioni e limitazioni: 'non si applica', 'esclusivamente', 'non oltre'. Posizioni minoritarie o dissenzienti: in un verbale, un'obiezione registrata; in un rapporto, un rischio segnalato in una nota. Una tecnica pratica è chiedere al sistema, insieme alla sintesi, un elenco separato di tutte le condizioni, eccezioni, scadenze e limiti presenti nel documento, con il riferimento. È più facile controllare un elenco mirato che cercare le perdite in una sintesi scorrevole.");
    modeTag(s, 2);
    const it = [["Condizioni", "solo se, a condizione che"], ["Eccezioni", "salvo, tranne"], ["Limiti e soglie", "importi, percentuali"], ["Scadenze", "date, termini, preavvisi"], ["Responsabilità", "chi fa che cosa"], ["Certezza e obbligo", "da confermare, è obbligatorio"], ["Negazioni", "non si applica, esclusivamente"], ["Voci minoritarie", "obiezioni, rischi in nota"]];
    it.forEach((e, i) => {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.15 + row * 1.1;
      shapeBox(s, x, y, 2.15, 0.98, row === 0 ? C.background2 : C.accent6, e[0]);
      txt(s, e[0], { x: x + 0.15, y: y + 0.1, w: 1.9, h: 0.36, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: y + 0.48, w: 1.9, h: 0.42, fontSize: 11, italic: true, color: C.text2 });
    });
    banner(s, 3.5, "Tecnica pratica: chiedere, insieme alla sintesi, un elenco di tutte le condizioni, eccezioni, scadenze e limiti, con il riferimento.", { h: 0.8, fontSize: 13 });
    txt(s, "È più facile controllare un elenco mirato che cercare le perdite in una sintesi scorrevole.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text2 });
  }
  {
    const s = content("Controllare una sintesi", "Mettiamo insieme le tecniche viste in una procedura di controllo, da applicare con intensità proporzionata all'uso della sintesi. Prima di chiedere la sintesi: dichiarare lo scopo e indicare gli elementi che devono essere presenti, come condizioni, scadenze, importi, responsabilità. Durante: chiedere i riferimenti ai passaggi originali e un elenco separato di condizioni ed eccezioni. Dopo, per una sintesi usata per orientarsi, basta una lettura critica: è plausibile? Manca qualcosa che ci si aspetterebbe? Per una sintesi su cui si basa una decisione o un'azione, conviene controllare sul documento i punti critici, usando i riferimenti, e verificare che condizioni ed eccezioni importanti siano state riportate. Per una sintesi destinata ad altri, specie all'esterno o a chi non leggerà l'originale, conviene un controllo sistematico, e indicare nella sintesi stessa che si tratta di una sintesi e dove trovare l'originale. Un principio di fondo: chi legge una sintesi tende a considerarla equivalente al documento. Più la sintesi sostituisce la lettura dell'originale, più deve essere controllata.");
    modeTag(s, 2);
    const ph = [["Prima", ["Dichiarare lo scopo", "Indicare gli elementi da includere"]], ["Durante", ["Chiedere i riferimenti", "Elenco separato di condizioni ed eccezioni"]], ["Dopo", ["Controllo proporzionato all'uso", "Punti critici verificati sul documento"]]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.0, i === 2 ? C.accent6 : C.background2, ph[i][0]);
      txt(s, ph[i][0], { x: x + 0.2, y: 1.25, w: 2.46, h: 0.42, fontSize: 18, bold: true, color: C.accent1 });
      txt(s, bullets(ph[i][1], { space: 6 }), { x: x + 0.2, y: 1.75, w: 2.5, h: 1.3, fontSize: 13, color: C.text1 });
      if (i < 2) arrow(s, x + 2.88, 1.95, 0.17);
    }
    chip(s, 0.5, 3.35, 2.9, 0.55, "Per orientarsi: lettura critica", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.35, 2.9, 0.55, "Per decidere: punti critici", { fill: C.accent6, fontSize: 12 });
    chip(s, 6.6, 3.35, 2.9, 0.55, "Per altri: controllo sistematico", { fill: C.accent1, color: C.background1, fontSize: 12 });
    banner(s, 4.1, "Più la sintesi sostituisce la lettura dell'originale, più deve essere controllata.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Limiti con documenti complessi", "Il sottotema chiede anche di conoscere i limiti dell'analisi di documentazione complessa, che approfondiremo nell'8.8. Ne anticipiamo i principali, per come incidono sulla sintesi. Documenti molto lunghi: anche quando il sistema accetta il documento intero, non è detto che ne consideri tutte le parti con la stessa attenzione. Studi sui modelli linguistici hanno mostrato che le informazioni al centro di testi lunghi tendono a essere usate meno di quelle all'inizio e alla fine. Rimandi interni e allegati: un contratto in cui l'articolo 9 rimanda all'allegato C, che a sua volta modifica l'articolo 4, richiede di collegare parti lontane, e qui gli errori sono più frequenti. Tabelle, grafici e impaginazioni complesse: possono essere lette in modo incompleto o scorretto. Linguaggio tecnico e specialistico: il sistema può riassumere in modo scorrevole un contenuto che non interpreta correttamente. Più documenti insieme: aumentano il rischio di confondere a quale documento appartiene un'informazione. In tutti questi casi, la sintesi resta utile come primo orientamento, ma la lettura dei passaggi critici diventa indispensabile.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiBookOpen", head: "Documenti molto lunghi", body: "Le parti centrali tendono a essere usate meno" },
      { icon: "FiCornerDownRight", head: "Rimandi e allegati", body: "Collegare parti lontane aumenta gli errori" },
      { icon: "FiGrid", head: "Tabelle e impaginazioni", body: "Lette in modo incompleto o scorretto" },
      { icon: "FiCpu", head: "Linguaggio specialistico", body: "Riassunto scorrevole, interpretazione errata" },
      { icon: "FiFolder", head: "Più documenti insieme", body: "Informazioni attribuite al documento sbagliato" },
      { icon: "FiArrowRight", head: "Approfondimento", body: "Nel sottotema 8.8" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "La sintesi resta un primo orientamento: la lettura dei passaggi critici diventa indispensabile.", { h: 0.6, fontSize: 13 });
  }
  keySlide("Una sintesi utile deve rappresentare fedelmente gli elementi essenziali e consentire controlli sui contenuti originali quando richiesto dall'utilizzo previsto.", "Sottotema 8.3  ·  Sintesi e analisi documentale", "Concetto chiave del sottotema 8.3. L'AI offre grandi possibilità nella sintesi e nell'analisi dei documenti: riassunti, sintesi esecutive e operative, individuazione di concetti e passaggi rilevanti. Ma una sintesi va pensata per uno scopo, deve permettere di risalire ai passaggi originali con riferimenti realmente controllabili, e può perdere proprio gli elementi che contano di più: condizioni, eccezioni, limiti, scadenze, gradi di certezza. Il controllo va proporzionato all'uso: più la sintesi sostituisce la lettura dell'originale, più va verificata. Esercizio suggerito: dare ai partecipanti un documento fittizio di due o tre pagine con alcune condizioni ed eccezioni, farlo sintetizzare con l'AI, e chiedere di verificare quali elementi decisivi sono stati conservati e quali persi.");

  // =====================================================================
  section("8.4 Estrazione");
  divider("8.4", "Estrazione e strutturazione delle informazioni", "Un dato estratto non è automaticamente un dato validato", "Passiamo dalla sintesi all'estrazione. Qui l'obiettivo non è ridurre un documento, ma ricavarne informazioni puntuali e organizzarle in una struttura: una tabella, un elenco di campi, una classificazione. È una delle possibilità più concrete e meno conosciute dell'AI generativa, perché permette di trasformare testi non strutturati, come email, contratti, moduli, verbali, in dati utilizzabili da attività successive. In questo sottotema, da comprendere e sperimentare, vediamo che cosa si può estrarre, come si passa dal testo al dato, come gestire campi mancanti o ambigui e, soprattutto, come controllare la qualità dell'estrazione prima di usarla.");
  {
    const s = content("Sintetizzare o estrarre?", "Una domanda guida chiede la differenza tra sintetizzare un documento ed estrarne dati strutturati. La distinzione, indicata anche dal documento di perimetro, è netta. La sintesi produce un testo più breve, che interpreta e seleziona i contenuti: il risultato si legge. L'estrazione produce dati puntuali, organizzati in campi definiti in anticipo, come nome del fornitore, data di scadenza, importo, numero d'ordine: il risultato si usa, per esempio in una tabella, in un confronto, in un sistema gestionale, in un'analisi. Le due attività hanno esigenze diverse. La sintesi richiede di non perdere significato; l'estrazione richiede precisione su ogni singolo valore e completezza su tutti i documenti. In una sintesi, un piccolo errore può passare inosservato senza grandi conseguenze; in un'estrazione, un importo sbagliato o una data invertita entra in un foglio di calcolo e da lì in decisioni e processi, spesso senza che nessuno torni più a guardare il documento originale. Per questo il controllo dell'estrazione è diverso: non si valuta la fedeltà complessiva, ma l'accuratezza campo per campo.");
    modeTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiAlignLeft", head: "Sintesi", headSize: 17, bodySize: 13,
      body: bullets(["Un testo più breve che interpreta e seleziona", "Il risultato si legge", "Rischio: perdita di significato", "Controllo: fedeltà complessiva"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiGrid", head: "Estrazione", headSize: 17, bodySize: 13, fill: C.accent6,
      body: bullets(["Dati puntuali in campi definiti", "Il risultato si usa in attività successive", "Rischio: valore errato, mancante, inventato", "Controllo: accuratezza campo per campo"], { space: 4 }) });
    banner(s, 3.95, "Un importo sbagliato entra in un foglio di calcolo, e da lì in decisioni e processi, spesso senza che nessuno torni al documento.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Che cosa si può estrarre", "Le possibilità di estrazione sono molte. Informazioni anagrafiche e identificative: nomi di persone e aziende, ruoli, indirizzi, codici, numeri di documento. Date e scadenze: data del documento, decorrenza, termini, rinnovi. Importi e quantità: prezzi, totali, sconti, penali, quantità ordinate. Riferimenti: numeri d'ordine, di contratto, di pratica, rimandi normativi. Classificazioni: il tipo di richiesta in un'email, l'argomento di un reclamo, il livello di urgenza, il reparto competente. Elementi ricorrenti: i motivi più frequenti di reclamo in cento email, le clausole presenti o assenti in un gruppo di contratti, i temi che ricorrono in una serie di verbali. Le prime quattro categorie riguardano informazioni esplicitamente scritte nel testo, e l'estrazione è relativamente affidabile, pur con errori possibili. Le ultime due richiedono un'interpretazione: classificare significa giudicare, e due persone potrebbero classificare diversamente la stessa email. In questi casi, la qualità dipende molto dalla chiarezza delle categorie e dei criteri forniti.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiUser", head: "Nomi e identificativi", body: "Persone, aziende, ruoli, codici" },
      { icon: "FiCalendar", head: "Date e scadenze", body: "Decorrenze, termini, rinnovi" },
      { icon: "FiDollarSign", head: "Importi e quantità", body: "Prezzi, totali, sconti, penali" },
      { icon: "FiHash", head: "Riferimenti", body: "Ordini, contratti, pratiche, norme" },
      { icon: "FiTag", head: "Classificazioni", body: "Tipo di richiesta, argomento, urgenza", fill: C.accent6 },
      { icon: "FiBarChart2", head: "Elementi ricorrenti", body: "Motivi frequenti, clausole presenti o assenti", fill: C.accent6 },
    ], 3, { y: 1.15, H: 2.95, headSize: 13, bodySize: 12 });
    chip(s, 0.5, 4.3, 5.95, 0.6, "Informazioni esplicite nel testo: estrazione più affidabile", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 4.3, 2.9, 0.6, "Richiedono interpretazione", { fill: C.accent6, fontSize: 12 });
  }
  {
    const s = content("Dal non strutturato al dato utilizzabile", "Prima integrazione del sottotema: dall'informazione non strutturata al dato utilizzabile. Gran parte delle informazioni aziendali vive in testi: email, contratti, moduli compilati a mano o in formato libero, verbali, segnalazioni, curricula, offerte. Sono informazioni preziose, ma difficili da usare in modo sistematico: per sapere quanti contratti scadono nel prossimo trimestre, bisogna aprirli uno per uno. L'AI può trasformare questi testi in campi e categorie riutilizzabili. L'esempio fittizio in slide mostra un'email di un cliente trasformata in un record strutturato: cliente, numero d'ordine, tipo di richiesta, prodotto, data richiesta, urgenza. Su cento email, questo produce una tabella che si può ordinare, filtrare, contare, collegare ad altri dati. È il passaggio che rende utilizzabile da attività successive un'informazione che prima era solo leggibile. La condizione, indicata esplicitamente dal documento di perimetro, è che la qualità dell'estrazione sia controllata prima dell'impiego operativo. L'analisi quantitativa dei dati così ottenuti appartiene al Tema 9; i flussi automatici che fanno questo in modo continuo, al Tema 11.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 4.1, 2.85, "Email del cliente (esempio fittizio)", "Buongiorno, vi scrivo per l'ordine 4471 del 12 marzo. Le sedie modello Alfa sono arrivate, ma due su dieci hanno la seduta danneggiata. Avremmo bisogno della sostituzione entro fine mese, perché abbiamo un evento. Grazie, M. Rossi, Studio Bianchi", { fontSize: 12 });
    arrow(s, 4.7, 2.4, 0.4);
    table(s, [["Campo", "Valore"], ["Cliente", "Studio Bianchi"], ["Ordine", "4471"], ["Tipo richiesta", "Sostituzione"], ["Prodotto", "Sedia Alfa, 2 pezzi"], ["Scadenza", "Fine mese"], ["Urgenza", "Alta"]],
      { x: 5.2, y: 1.15, w: 4.3, colW: [1.6, 2.7], rowH: 0.4, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 4.2, "Da informazione leggibile a dato utilizzabile: ordinare, filtrare, contare, collegare. Purché l'estrazione sia controllata prima dell'uso.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Classificare e trovare ricorrenze", "Due forme di strutturazione che vanno oltre l'estrazione di singoli valori. La classificazione assegna ogni contenuto a una categoria: il tipo di richiesta, il reparto competente, il tema di un reclamo, il livello di priorità. Le ricorrenze emergono confrontando molti contenuti: quali problemi si ripetono nelle segnalazioni, quali clausole compaiono in tutti i contratti tranne uno, quali argomenti tornano nelle riunioni. Sono utilizzi di grande valore perché permettono di vedere schemi che in una lettura documento per documento sfuggono. Ma richiedono attenzione a tre aspetti. Le categorie devono essere definite bene: se non sono chiare e mutuamente esclusive, il sistema le applicherà in modo incoerente, e anche due persone farebbero lo stesso. Conviene fornire per ogni categoria una definizione e qualche esempio, e prevedere una categoria 'altro' o 'non classificabile', per evitare forzature. La coerenza va controllata: lo stesso tipo di contenuto deve finire sempre nella stessa categoria, anche in documenti elaborati in momenti diversi. I conteggi vanno verificati: se il sistema dice che il 40 per cento dei reclami riguarda le consegne, conviene controllare su un campione, perché i numeri su grandi insiemi sono tra gli errori più difficili da notare.");
    modeTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 1.75, { icon: "FiTag", inline: true, head: "Classificare", headSize: 15, bodySize: 13, body: "Assegnare ogni contenuto a una categoria: tipo, reparto, tema, priorità." });
    await card(s, 5.15, 1.2, 4.35, 1.75, { icon: "FiRepeat", inline: true, head: "Trovare ricorrenze", headSize: 15, bodySize: 13, fill: C.accent6, body: "Schemi che si ripetono in molti contenuti e sfuggono alla lettura singola." });
    const at = [["Categorie ben definite", "Definizione ed esempi per ognuna, più 'altro' o 'non classificabile'"], ["Coerenza", "Lo stesso contenuto sempre nella stessa categoria"], ["Conteggi verificati", "Controllare le percentuali su un campione"]];
    at.forEach((e, i) => {
      const y = 3.15 + i * 0.6;
      shapeBox(s, 0.5, y, 9.0, 0.52, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.6, h: 0.52, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.3, y, w: 6.0, h: 0.52, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Campi mancanti o ambigui", "Uno degli aspetti più importanti dell'estrazione, e uno dei più trascurati, è che cosa succede quando l'informazione cercata non c'è o non è chiara. Il rischio principale è che il sistema, invece di lasciare il campo vuoto, lo riempia con un valore plausibile: una data dedotta, un importo calcolato, un nome preso da un'altra parte del documento. È il comportamento visto nel Tema 3: il sistema tende a produrre una risposta piuttosto che dichiarare che non c'è. In un'estrazione, questo è particolarmente pericoloso, perché un valore inventato in una tabella ha lo stesso aspetto di un valore estratto. La soluzione è definire in anticipo regole esplicite. Se l'informazione non è presente, il campo resta vuoto o riporta 'non presente', mai un valore stimato. Se l'informazione è ambigua, per esempio due date diverse o un importo con e senza IVA, il campo riporta 'ambiguo' con una nota che spiega perché. Se il valore è stato dedotto e non letto, per esempio una scadenza calcolata dalla data di inizio e dalla durata, va segnalato come dedotto. Queste tre etichette rendono visibili i casi da controllare e impediscono che un'incertezza diventi un dato apparentemente certo.");
    modeTag(s, 2);
    const rl = [["Non presente", "Il campo resta vuoto o riporta 'non presente', mai un valore stimato", C.background2], ["Ambiguo", "Più valori possibili: si riporta 'ambiguo' con una nota", C.accent6], ["Dedotto", "Valore calcolato, non letto: va segnalato come tale", C.background2]];
    rl.forEach((r, i) => {
      const y = 1.15 + i * 0.8;
      shapeBox(s, 0.5, y, 5.5, 0.7, r[2], r[0]);
      chip(s, 0.65, y + 0.14, 1.6, 0.42, r[0], { fill: C.accent1, color: C.background1, fontSize: 12 });
      txt(s, r[1], { x: 2.4, y, w: 3.5, h: 0.7, fontSize: 12, color: C.text1, valign: "middle" });
    });
    shapeBox(s, 6.25, 1.15, 3.25, 2.3, C.text1, "rischio");
    txt(s, "Il rischio", { x: 6.45, y: 1.25, w: 2.9, h: 0.38, fontSize: 15, bold: true, color: C.accent6 });
    txt(s, "Un valore inventato in una tabella ha lo stesso aspetto di un valore estratto.", { x: 6.45, y: 1.7, w: 2.9, h: 1.6, fontSize: 13, color: C.background1 });
    banner(s, 3.75, "Regole definite in anticipo rendono visibili i casi da controllare: un'incertezza non deve diventare un dato apparentemente certo.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Accuratezza e completezza", "Come si verifica un'estrazione? Due dimensioni distinte. L'accuratezza: i valori estratti corrispondono a quelli del documento? Errori tipici: cifre invertite, importi con o senza IVA confusi, date in formato diverso interpretate male, come 03/04 letto come 3 aprile o 4 marzo, valori presi dal punto sbagliato del documento, nomi storpiati. La completezza: sono stati estratti tutti i documenti, tutte le righe, tutti i campi? Errori tipici: documenti saltati, righe di una tabella omesse, campi lasciati vuoti anche se l'informazione c'era. Tecniche di controllo pratiche. Controllo a campione: confrontare con gli originali una parte dei record, scelti a caso e tra quelli con valori anomali; se il campione rivela errori, allargare il controllo. Controllo dei conteggi: il numero di record corrisponde al numero di documenti? Le somme tornano con un totale noto? Controllo di plausibilità, come visto nel Tema 7: date future dove non dovrebbero esserci, importi fuori scala, categorie inattese. Controllo dei campi segnalati: tutti i 'non presente', 'ambiguo' e 'dedotto' vanno guardati. Per le estrazioni ripetute nel tempo, una verifica iniziale approfondita può giustificare controlli più leggeri e periodici.");
    modeTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 1.9, { icon: "FiCrosshair", inline: true, head: "Accuratezza", headSize: 15, bodySize: 12,
      body: "Cifre invertite, IVA sì o no, 03/04 marzo o aprile, valore dal punto sbagliato, nomi storpiati." });
    await card(s, 5.15, 1.15, 4.35, 1.9, { icon: "FiLayers", inline: true, head: "Completezza", headSize: 15, bodySize: 12, fill: C.accent6,
      body: "Documenti saltati, righe omesse, campi vuoti anche se l'informazione c'era." });
    const tc = [["A campione", "Casuali e anomali"], ["Conteggi", "Record, somme, totali"], ["Plausibilità", "Date, scale, categorie"], ["Campi segnalati", "Assenti, ambigui, dedotti"]];
    tc.forEach((t, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 3.25, 2.15, 0.95, C.background2, t[0]);
      txt(s, t[0], { x: x + 0.12, y: 3.32, w: 1.95, h: 0.38, fontSize: 13, bold: true, color: C.accent1, align: "center" });
      txt(s, t[1], { x: x + 0.12, y: 3.7, w: 1.95, h: 0.4, fontSize: 11, color: C.text2, align: "center" });
    });
    txt(s, "Estrazioni ripetute: verifica iniziale approfondita, poi controlli più leggeri e periodici.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 13, italic: true, color: C.text2 });
  }
  {
    const s = content("Dato estratto, dato validato", "Il concetto chiave del sottotema merita una slide dedicata: un dato estratto non è automaticamente un dato validato. Tra il momento in cui l'AI produce una tabella e il momento in cui quei dati vengono usati in un processo, in un sistema gestionale o in una decisione, deve esserci un passaggio di controllo. Lo schema in slide mostra il percorso: il documento originale, il dato estratto dall'AI, il dato controllato secondo le tecniche viste, il dato validato per un uso specifico, e infine l'impiego operativo. Il rischio tipico è saltare il passaggio centrale: la tabella sembra ordinata, completa e precisa, e viene usata direttamente. Gli errori, a quel punto, si propagano: un importo sbagliato entra in un report, una scadenza mancata non genera l'avviso, un fornitore classificato male finisce nell'analisi sbagliata. E più ci si allontana dal documento originale, più è difficile accorgersene. Un accorgimento utile è conservare per ogni dato estratto il collegamento al documento e al passaggio da cui proviene: la tracciabilità rende possibile controllare anche a distanza di tempo.");
    modeTag(s, 2);
    const st = ["Documento", "Dato estratto", "Dato controllato", "Dato validato", "Impiego"];
    st.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      chip(s, x, 1.4, 1.6, 0.8, t, { fill: i === 2 ? C.accent5 : (i === 4 ? C.accent1 : C.background2), color: i === 2 || i === 4 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 4) arrow(s, x + 1.62, 1.64, 0.2);
    });
    txt(s, "Il passaggio che si rischia di saltare", { x: 3.68, y: 2.3, w: 1.6, h: 0.6, fontSize: 11, italic: true, bold: true, color: C.accent5, align: "center" });
    await card(s, 0.5, 3.05, 4.35, 1.9, { icon: "FiAlertTriangle", inline: true, head: "Gli errori si propagano", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: "Importo sbagliato nel report, scadenza senza avviso, fornitore nell'analisi sbagliata. Più ci si allontana dal documento, più è difficile accorgersene." });
    await card(s, 5.15, 3.05, 4.35, 1.9, { icon: "FiLink", inline: true, head: "Conservare il collegamento", headSize: 14, bodySize: 12, fill: C.accent6,
      body: "Per ogni dato, il documento e il passaggio da cui proviene: si può controllare anche a distanza di tempo." });
  }
  keySlide("L'AI può rendere più utilizzabile il contenuto informativo dei documenti, ma un dato estratto non è automaticamente un dato validato.", "Sottotema 8.4  ·  Estrazione e strutturazione delle informazioni", "Concetto chiave del sottotema 8.4. L'estrazione trasforma testi non strutturati in dati utilizzabili: nomi, date, importi, riferimenti, classificazioni, ricorrenze. È una delle possibilità più concrete dell'AI, perché rende sistematicamente usabili informazioni che prima erano solo leggibili. Ma richiede regole per i campi mancanti, ambigui o dedotti, categorie ben definite, controlli di accuratezza e completezza, e soprattutto un passaggio di validazione prima dell'impiego operativo. Esercizio suggerito: preparare cinque o sei email fittizie di clienti, chiedere all'AI di estrarne una tabella con campi definiti, e far controllare ai partecipanti ogni valore, contando errori, campi inventati e campi correttamente segnalati come mancanti.");

  // =====================================================================
  section("8.5 Confronto");
  divider("8.5", "Confronto e analisi di più documenti", "Un confronto utile individua differenze rilevanti, ne distingue la natura e permette di verificarle nelle fonti", "Terzo sottotema del nucleo distintivo: il confronto tra documenti. Mentre l'8.3 lavora su un documento per volta, qui il valore sta nelle relazioni tra documenti diversi: due versioni dello stesso contratto, tre offerte di fornitori, una procedura e il regolamento a cui dovrebbe conformarsi. Confrontare documenti è un'attività lunga, faticosa e soggetta a errori di attenzione quando la si fa a mano, e l'AI può renderla molto più rapida. In questo sottotema, da comprendere e sperimentare, vediamo i principali tipi di confronto, le matrici comparative, l'analisi di contraddizioni e lacune, la distinzione tra differenze formali e sostanziali e la tracciabilità delle differenze.");
  {
    const s = content("Tre tipi di confronto", "Il sottotema comprende tre famiglie di confronto, con obiettivi diversi. Il confronto tra versioni di uno stesso documento: che cosa è cambiato tra la bozza di contratto inviata e quella ricevuta dalla controparte? Tra la procedura dell'anno scorso e quella aggiornata? L'obiettivo è identificare le modifiche, e in particolare quelle non dichiarate. Il confronto tra documenti alternativi: tre offerte di fornitori, più proposte progettuali, condizioni di diversi contratti. L'obiettivo è individuare elementi comuni e differenze, per valutare e scegliere. Il confronto tra documenti collegati: una procedura e il regolamento che dovrebbe applicare, un capitolato e l'offerta che dovrebbe rispondervi, un verbale e il piano di progetto. L'obiettivo è trovare contraddizioni, incoerenze e informazioni mancanti. In tutti e tre i casi, l'AI può produrre rapidamente un primo quadro delle differenze. Si noti che per il confronto tra versioni esistono anche strumenti tradizionali, come la funzione di confronto dei programmi di scrittura, che sono esatti sulle modifiche testuali: l'AI aggiunge la capacità di interpretarle, distinguendo quelle rilevanti, e di confrontare documenti con struttura diversa.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiGitCommit", head: "Versioni di un documento", body: "Che cosa è cambiato? Soprattutto: che cosa non è stato dichiarato?" },
      { icon: "FiColumns", head: "Documenti alternativi", body: "Offerte, proposte, contratti: elementi comuni e differenze per scegliere" },
      { icon: "FiGitMerge", head: "Documenti collegati", body: "Procedura e regolamento, capitolato e offerta: contraddizioni e lacune" },
    ], 3, { y: 1.2, h: 2.2, headSize: 14, bodySize: 13 });
    banner(s, 3.65, "Gli strumenti di confronto tradizionali sono esatti sulle modifiche testuali. L'AI aggiunge l'interpretazione e il confronto tra strutture diverse.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Identificare le modifiche", "Il confronto tra versioni è un caso d'uso molto concreto: quando una controparte restituisce un contratto o un accordo, non sempre segnala tutte le modifiche, e controllare a mano un documento di trenta pagine è lungo e soggetto a distrazioni. Gli strumenti tradizionali di confronto mostrano ogni differenza testuale, ma non distinguono un refuso corretto da una clausola modificata, e funzionano male quando il documento è stato riorganizzato o riformattato. L'AI può aiutare in tre modi: elencare le modifiche raggruppandole per importanza, spiegare in linguaggio semplice che cosa cambia in pratica, e segnalare le modifiche che potrebbero avere conseguenze. L'esempio fittizio in slide mostra tre modifiche tra due versioni di un accordo: una formale e due sostanziali, di cui una, il passaggio da 30 a 60 giorni per il pagamento, cambia le condizioni economiche. Due avvertenze. La prima: un elenco di modifiche prodotto dall'AI può non essere completo; per i documenti importanti, conviene usare anche il confronto tradizionale, che è esaustivo sulle differenze testuali. La seconda: la valutazione dell'importanza di una modifica dipende dal contesto, che il sistema conosce solo in parte.");
    modeTag(s, 2);
    table(s, [["Versione 1", "Versione 2", "Natura"],
      ["Il fornitre si impegna", "Il fornitore si impegna", "Formale: refuso"],
      ["Pagamento a 30 giorni", "Pagamento a 60 giorni", "Sostanziale: condizioni economiche"],
      ["Il fornitore garantisce la consegna", "Il fornitore si adopera per la consegna", "Sostanziale: obbligo attenuato"]],
      { y: 1.15, colW: [3.0, 3.2, 2.8], rowH: 0.5, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.2, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    await card(s, 0.5, 3.55, 4.35, 1.4, { head: "L'elenco può non essere completo", headSize: 14, bodySize: 12, body: "Per i documenti importanti, usare anche il confronto tradizionale, esaustivo sulle differenze testuali." });
    await card(s, 5.15, 3.55, 4.35, 1.4, { head: "L'importanza dipende dal contesto", headSize: 14, bodySize: 12, fill: C.accent6, body: "Che il sistema conosce solo in parte: la valutazione finale resta a chi conosce la trattativa." });
  }
  {
    const s = content("La matrice comparativa", "Per i documenti alternativi, lo strumento più utile è la matrice comparativa: una tabella con i documenti in colonna e i criteri di confronto in riga. L'esempio fittizio in slide confronta tre offerte di fornitori su prezzo, tempi di consegna, garanzia e assistenza. L'AI è molto efficace nel costruire queste matrici, a condizione di definire bene i criteri: se li scegliamo noi, in base a ciò che conta per la decisione, il confronto è mirato; se li lasciamo scegliere al sistema, rischiamo un confronto sui criteri più facili da estrarre, non su quelli più importanti. Tre elementi rendono una matrice affidabile. I riferimenti: ogni cella dovrebbe indicare da quale passaggio del documento deriva il valore. La gestione dei vuoti: se un'offerta non specifica un elemento, la cella deve dirlo, come nell'esempio per l'assistenza del fornitore C, invece di riportare un valore dedotto. La comparabilità: i valori devono essere confrontabili, per esempio prezzi tutti con o tutti senza IVA, tempi tutti in giorni lavorativi o tutti in giorni di calendario. Una matrice che mette accanto valori non omogenei produce un confronto sbagliato con l'aspetto di un confronto preciso.");
    modeTag(s, 2);
    table(s, [["Criterio", "Fornitore A", "Fornitore B", "Fornitore C"],
      ["Prezzo (IVA esclusa)", "12.400 € (§3)", "11.900 € (§2.1)", "12.100 € (p. 4)"],
      ["Consegna", "30 giorni (§5)", "45 giorni (§4)", "20 giorni lavorativi (p. 6)"],
      ["Garanzia", "24 mesi (§7)", "36 mesi (§6.2)", "24 mesi (p. 7)"],
      ["Assistenza", "Inclusa 1 anno (§8)", "A pagamento (§6.4)", "Non specificata"]],
      { y: 1.15, colW: [2.1, 2.3, 2.3, 2.3], rowH: 0.45, fontSize: 12, blankCorner: false });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.45, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    chip(s, 0.5, 3.8, 2.9, 0.6, "Riferimento per ogni cella", { fill: C.accent6, fontSize: 12 });
    chip(s, 3.55, 3.8, 2.9, 0.6, "Vuoti dichiarati, non dedotti", { fill: C.accent6, fontSize: 12 });
    chip(s, 6.6, 3.8, 2.9, 0.6, "Valori comparabili", { fill: C.accent6, fontSize: 12 });
    txt(s, "Attenzione: 20 giorni lavorativi non sono confrontabili con 30 giorni di calendario senza conversione.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Contraddizioni e lacune", "Il confronto tra documenti collegati serve soprattutto a trovare due tipi di problemi. Le contraddizioni: due documenti, o due parti dello stesso documento, che dicono cose incompatibili. Una procedura che prevede un'approvazione in due giorni, mentre il regolamento ne prevede cinque. Un'offerta che indica una garanzia di 24 mesi nella premessa e di 12 nelle condizioni generali. Un verbale che attribuisce un'attività a un reparto diverso da quello del piano di progetto. Le informazioni mancanti: elementi richiesti da un documento e assenti nell'altro. Un capitolato che chiede certificazioni, piano di manutenzione e referenze, e un'offerta che risponde solo sulle prime due. Una procedura che non disciplina un caso previsto dal regolamento. L'AI può essere molto utile qui, perché questi problemi richiedono di tenere a mente molti dettagli e incrociarli, attività in cui l'attenzione umana cala rapidamente. Ma due cautele. Le lacune sono più difficili da trovare delle contraddizioni, come visto nel Tema 7 per le omissioni: conviene fornire esplicitamente l'elenco dei requisiti da controllare. E il sistema può segnalare false contraddizioni, dovute a una lettura imprecisa: ogni contraddizione segnalata va verificata sui due passaggi.");
    modeTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.7, { icon: "FiXCircle", head: "Contraddizioni", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Procedura: approvazione in 2 giorni; regolamento: 5", "Offerta: garanzia 24 mesi in premessa, 12 nelle condizioni", "Attività attribuita a reparti diversi"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.7, { icon: "FiMinusCircle", head: "Informazioni mancanti", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Capitolato: certificazioni, manutenzione, referenze; offerta: solo le prime due", "Caso previsto dal regolamento, non disciplinato dalla procedura"], { space: 5 }) });
    const c = [["Lacune più difficili da trovare", "Fornire l'elenco dei requisiti da controllare"], ["Possibili false contraddizioni", "Verificare ogni segnalazione sui due passaggi"]];
    c.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 4.05, 4.35, 0.9, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 4.1, w: 3.95, h: 0.38, fontSize: 13, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.47, w: 3.95, h: 0.4, fontSize: 12, color: C.background1 });
    });
  }
  {
    const s = content("Differenze formali e sostanziali", "Come per le trasformazioni nell'8.2, anche nel confronto è essenziale distinguere differenze formali e sostanziali. Le differenze formali riguardano il modo di esprimersi: un sinonimo, un ordine diverso, una formattazione, una numerazione cambiata, un refuso. Le differenze sostanziali riguardano il contenuto: obblighi, importi, scadenze, responsabilità, condizioni, esclusioni. Un buon confronto non elenca tutte le differenze con lo stesso peso: le seleziona, le classifica, e porta in evidenza quelle sostanziali. Altrimenti si ottiene un elenco lunghissimo in cui la modifica decisiva si perde tra decine di cambiamenti irrilevanti, o, al contrario, un elenco breve che ha scartato come formale una modifica sostanziale. Il caso più insidioso è proprio questo: differenze che sembrano formali ma non lo sono. 'Si impegna a' contro 'si adopera per', 'entro' contro 'indicativamente entro', 'il cliente' contro 'il cliente o i suoi incaricati'. Per i confronti importanti, conviene chiedere al sistema di classificare ogni differenza e di motivare la classificazione, e poi controllare in particolare quelle classificate come formali in clausole rilevanti, come obblighi, importi e scadenze.");
    modeTag(s, 2);
    await twoPanel(s, "Differenze formali", bullets(["Sinonimi equivalenti, ordine, formattazione", "Numerazione, refusi", "Non cambiano il contenuto"], { space: 4 }), "Differenze sostanziali", bullets(["Obblighi, importi, scadenze", "Responsabilità, condizioni, esclusioni", "Cambiano le conseguenze"], { space: 4 }), { li: "FiType", ri: "FiAlertCircle", h: 2.1 });
    txt(s, "Sembrano formali, ma non lo sono", { x: 0.5, y: 3.45, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    chip(s, 0.5, 3.85, 2.9, 0.5, "si impegna / si adopera", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.85, 2.9, 0.5, "entro / indicativamente entro", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.85, 2.9, 0.5, "il cliente / o i suoi incaricati", { fill: C.background2, fontSize: 12 });
    txt(s, "Chiedere di classificare e motivare; controllare le differenze 'formali' nelle clausole rilevanti.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Tracciare le differenze", "Il sottotema riprende l'integrazione sulla tracciabilità: le differenze e le conclusioni di un confronto devono poter essere ricondotte ai passaggi dei documenti confrontati. In un confronto la tracciabilità è ancora più importante che in una sintesi, per due ragioni. Primo, i documenti sono più di uno, e il rischio di attribuire un'informazione al documento sbagliato è reale: il sistema può riportare nella colonna del fornitore A una condizione che compare nell'offerta del fornitore B. Secondo, i confronti sono spesso usati per decisioni con conseguenze, come la scelta di un fornitore o l'accettazione di un contratto, e per comunicazioni a terzi, come la richiesta di chiarimenti a un fornitore. Indicare che 'l'offerta B non prevede assistenza' a un fornitore che invece la prevede a pagina 12 è un errore che si paga. Per ogni differenza rilevante, quindi, il confronto dovrebbe indicare i due passaggi a confronto, con il riferimento nel rispettivo documento, così che la differenza si possa verificare affiancandoli. Le conclusioni, come 'l'offerta A è la più completa', dovrebbero indicare su quali differenze si basano.");
    modeTag(s, 2);
    shapeBox(s, 0.5, 1.15, 9.0, 1.8, C.background2, "differenza tracciata");
    txt(s, "Differenza tracciata (esempio fittizio)", { x: 0.7, y: 1.22, w: 6, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
    docBox(s, 0.7, 1.6, 3.7, 1.2, "Offerta A, §8", "Assistenza tecnica inclusa per 12 mesi dalla consegna.", { fill: C.background1, fontSize: 12 });
    chip(s, 4.55, 1.95, 0.9, 0.5, "≠", { fill: C.accent5, color: C.background1, fontSize: 18 });
    docBox(s, 5.6, 1.6, 3.7, 1.2, "Offerta B, §6.4", "Assistenza tecnica disponibile a pagamento, secondo listino.", { fill: C.background1, fontSize: 12 });
    await card(s, 0.5, 3.15, 4.35, 1.8, { icon: "FiFolder", inline: true, head: "Più documenti, più confusione", headSize: 14, bodySize: 12, body: "Il rischio di attribuire un'informazione al documento sbagliato è reale." });
    await card(s, 5.15, 3.15, 4.35, 1.8, { icon: "FiSend", inline: true, head: "Decisioni e comunicazioni a terzi", headSize: 14, bodySize: 12, fill: C.accent6, body: "Contestare a un fornitore una mancanza che non c'è è un errore che si paga." });
  }
  keySlide("Un confronto documentale è utile se individua differenze rilevanti, ne distingue la natura e permette di verificarle nelle fonti.", "Sottotema 8.5  ·  Confronto e analisi di più documenti", "Concetto chiave del sottotema 8.5. L'AI rende molto più rapido il confronto tra versioni, tra documenti alternativi e tra documenti collegati: identifica modifiche, costruisce matrici comparative, trova contraddizioni e lacune. Il valore del confronto dipende da tre condizioni, che il concetto chiave riassume: individuare le differenze rilevanti, non tutte con lo stesso peso; distinguerne la natura, formale o sostanziale, con attenzione a quelle che sembrano formali; permettere di verificarle nelle fonti, con riferimenti ai passaggi di ciascun documento. Esercizio suggerito: preparare due versioni fittizie di un breve accordo, con alcune modifiche formali e due o tre sostanziali, di cui una mascherata da modifica formale, e chiedere ai partecipanti di confrontarle con l'AI e con il confronto tradizionale, valutando che cosa trova ciascun metodo.");
