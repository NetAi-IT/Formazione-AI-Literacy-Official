  function stepTag(s, active) {
    const st = ["Individuare", "Descrivere", "Valutare", "Confrontare", "Verificare"];
    st.forEach((t, i) => {
      const x = 6.1 + i * 0.68;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.66, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "fase " + t });
      txt(s, t, { x, y: 0.42, w: 0.66, h: 0.26, fontSize: 6.5, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 15", { placeholder: "kicker" });
    s.addText("Individuazione e valutazione delle opportunità AI", { placeholder: "title" });
    s.addText("Area: Comprendere il valore per l'azienda", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al quindicesimo tema, il quarto dell'area 'Comprendere il valore per l'azienda'. Nei tre temi precedenti abbiamo visto come l'AI può creare valore, come trasforma il lavoro e i processi, e quali condizioni informative servono perché funzioni. Ora mettiamo insieme questi elementi per rispondere a una domanda molto pratica: dove potrebbe avere senso usare l'AI nella nostra organizzazione, e quali evidenze servono per scegliere? È una domanda che molte aziende si pongono oggi, spesso sotto pressione: i fornitori propongono soluzioni, i concorrenti annunciano progetti, i vertici chiedono 'che cosa stiamo facendo con l'AI?'. Il rischio è partire dalla tecnologia e cercare dove applicarla. Il modulo propone il percorso inverso: partire dai problemi, descrivere i casi d'uso, valutarli con criteri distinti, confrontarli con prudenza, e verificarli con esperimenti che possano anche dare esito negativo. Il confine cardine è con il Tema 16: qui ci chiediamo dove e perché, là come introdurre e accompagnare l'adozione. Non costruiamo business case dettagliati né piani di progetto: diamo un metodo di ragionamento, utile a chiunque proponga, valuti o riceva un'idea di uso dell'AI. Suggerimento per l'apertura: chiedere ai partecipanti di scrivere, in una riga, un'idea di uso dell'AI che hanno sentito proporre in azienda. Le useremo durante il modulo. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; il modulo è di metodo e cambia poco nel tempo, ma esempi e strumenti citati vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere come individuare, descrivere e valutare preliminarmente opportunità di uso dell'AI nelle attività e nei processi aziendali, considerando benefici potenziali, fattibilità, sostenibilità, rischi, condizioni organizzative e possibilità di verifica. La parola 'preliminarmente' è importante: non si tratta di prendere decisioni di investimento, ma di ragionare bene prima di prenderle. La consapevolezza da sviluppare: un caso d'uso AI non è valido semplicemente perché la tecnologia è capace di realizzarlo. Deve rispondere a un bisogno concreto, promettere un miglioramento rilevante, essere realizzabile e sostenibile, e presentare rischi adeguatamente controllabili. Quattro condizioni, tutte necessarie. Il messaggio chiave del documento di perimetro: un caso d'uso AI merita attenzione quando risponde a un bisogno reale, offre un miglioramento potenzialmente significativo, è sufficientemente fattibile e sostenibile e presenta rischi controllabili; queste condizioni vanno poi verificate attraverso evidenze.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Individuare, descrivere e valutare in modo preliminare le opportunità AI", "Considerare benefici, fattibilità, sostenibilità, rischi, condizioni e verifica"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Un caso d'uso non è valido perché la tecnologia sa realizzarlo.\n\nDeve rispondere a un bisogno concreto, promettere un miglioramento rilevante, essere realizzabile e sostenibile, con rischi controllabili." });
  }
  {
    const s = content("Dal bisogno, non dallo strumento", "Il documento di perimetro articola il ragionamento in quattro momenti, più uno di confronto: individuare il problema, descrivere il caso d'uso, valutare valore, fattibilità, sostenibilità e rischi, confrontare le opportunità, verificare le ipotesi con evidenze. Il principio che lo regge: la scelta deve partire dal bisogno aziendale, non dallo strumento. Lo schema in slide confronta i due percorsi. Il percorso dallo strumento: 'abbiamo questo strumento, o questa tecnologia è di moda: dove possiamo usarla?'. È un percorso molto comune, e non sempre sbagliato, perché conoscere le capacità di uno strumento aiuta a vedere opportunità. Ma porta spesso a soluzioni in cerca di un problema, a progetti dimostrativi senza seguito, a investimenti su attività che non erano un problema. Il percorso dal bisogno: 'abbiamo questo problema, o questo obiettivo: qual è la soluzione migliore? E l'AI è parte di essa?'. Porta a valutare anche alternative non AI, e a misurare i risultati rispetto al problema di partenza. Nel modulo useremo un indicatore in alto a destra per ricordare in quale fase del percorso ci troviamo.");
    shapeBox(s, 0.5, 1.15, 4.35, 2.0, C.background2, "dallo strumento");
    txt(s, "Dallo strumento", { x: 0.7, y: 1.22, w: 3.95, h: 0.4, fontSize: 15, bold: true, color: C.accent5 });
    txt(s, "'Abbiamo questa tecnologia: dove possiamo usarla?'", { x: 0.7, y: 1.62, w: 3.95, h: 0.5, fontSize: 12, italic: true, color: C.text1 });
    txt(s, "Rischio: soluzioni in cerca di un problema, dimostrazioni senza seguito", { x: 0.7, y: 2.2, w: 3.95, h: 0.85, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.15, 4.35, 2.0, C.accent6, "dal bisogno");
    txt(s, "Dal bisogno", { x: 5.35, y: 1.22, w: 3.95, h: 0.4, fontSize: 15, bold: true, color: C.accent1 });
    txt(s, "'Abbiamo questo problema: qual è la soluzione migliore? L'AI ne fa parte?'", { x: 5.35, y: 1.62, w: 3.95, h: 0.5, fontSize: 12, italic: true, color: C.text1 });
    txt(s, "Porta a valutare anche alternative non AI e a misurare i risultati sul problema", { x: 5.35, y: 2.2, w: 3.95, h: 0.85, fontSize: 12, color: C.text2 });
    const ph = ["Individuare", "Descrivere", "Valutare", "Confrontare", "Verificare"];
    ph.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      chip(s, x, 3.4, 1.62, 0.6, t, { fill: i === 4 ? C.accent1 : C.background2, color: i === 4 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 4) arrow(s, x + 1.63, 3.54, 0.19);
    });
    txt(s, "Il percorso del modulo: individuare il problema, descrivere il caso, valutarlo, confrontarlo, verificarlo con evidenze", { x: 0.5, y: 4.15, w: 9, h: 0.5, fontSize: 12, italic: true, color: C.text2, align: "center" });
  }
  {
    const s = content("Otto domande guida", "Le otto domande guida accompagnano il modulo, e seguono il percorso. Quale problema o obiettivo aziendale vogliamo affrontare. Come descrivere chiaramente un caso d'uso. Quali caratteristiche rendono un'opportunità promettente. Come distinguere i benefici ipotizzati da quelli realisticamente ottenibili. Quali dati, competenze, strumenti e integrazioni servono. Quali rischi possono rendere un caso d'uso inappropriato, anche se promettente. Come confrontare opportunità diverse senza attribuire eccessiva certezza ai punteggi. E infine, una domanda che il documento sottolinea: quali esperimenti potrebbero confermare, o smentire, le ipotesi iniziali. L'enfasi su 'smentire' è voluta, e la ritroveremo nell'ultimo sottotema. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Quale problema o obiettivo vogliamo affrontare?", "Come descrivere chiaramente un caso d'uso?", "Che cosa rende promettente un'opportunità?", "Benefici ipotizzati o realisticamente ottenibili?", "Quali dati, competenze, strumenti, integrazioni?", "Quali rischi lo rendono inappropriato?", "Come confrontare senza troppa fiducia nei punteggi?", "Quali esperimenti per confermare, o smentire?"], 4, 1.12, 1.5, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema lungo il percorso individuare, descrivere, valutare, confrontare, verificare. Individuare: i problemi aziendali e le caratteristiche delle opportunità, nei sottotemi 15.1 e 15.3. Descrivere: attività, informazioni, ruoli e risultato atteso, nel 15.2. Valutare: benefici, fattibilità, sostenibilità e rischi, dal 15.4 al 15.6. Confrontare: selezionare che cosa merita ulteriori verifiche, nel 15.7. Verificare: raccogliere evidenze, anche contrarie alle ipotesi, nel 15.8. Quattro integrazioni attraversano il modulo. A: prima chiedersi se serve davvero l'AI. B: il caso d'uso promettente non è necessariamente il più spettacolare. C: distinguere desiderabilità, fattibilità e sostenibilità, insieme all'accettabilità dei rischi. D: la sperimentazione deve poter smentire l'idea iniziale. Sulle slide compaiono senza lettere; nelle note le richiamiamo come integrazioni A, B, C e D. E tre precisazioni: confrontare con alternative realistiche, comprese quelle non AI e la situazione attuale; le condizioni di esclusione, legali, di sicurezza e di controllo, non sono compensate da punteggi elevati; una matrice di opportunità è un ausilio alla discussione, non una prova oggettiva di convenienza.");
    const d = [["FiSearch", "Individuare", "15.1  15.3"], ["FiEdit3", "Descrivere", "15.2"], ["FiSliders", "Valutare", "15.4  15.5  15.6"], ["FiBarChart2", "Confrontare", "15.7"], ["FiCheckCircle", "Verificare", "15.8"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84, dark = i === 4;
      shapeBox(s, x, 1.15, 1.68, 1.65, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.54, 1.25, 0.6, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.08, y: 1.9, w: 1.52, h: 0.4, fontSize: 13, bold: true, color: dark ? C.background1 : C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.08, y: 2.32, w: 1.52, h: 0.35, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
    }
    txt(s, "Quattro messaggi trasversali", { x: 0.5, y: 2.92, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const p = ["Prima chiedersi se serve davvero l'AI", "Il più promettente non è il più spettacolare", "Desiderabilità, fattibilità, sostenibilità", "La sperimentazione deve poter smentire"];
    p.forEach((t, i) => chip(s, 0.5 + (i % 2) * 4.6, 3.27 + Math.floor(i / 2) * 0.55, 4.4, 0.47, t, { fill: C.accent6, fontSize: 12 }));
    txt(s, "Precisazioni: alternative realistiche, anche non AI  ·  condizioni di esclusione non compensabili  ·  la matrice è un ausilio, non una prova", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti con priorità alta. Da approfondire: la definizione del problema, la descrizione del caso d'uso, la valutazione preliminare del valore e il confronto tra alternative. Da conoscere e sperimentare: le alternative non AI, la fattibilità, i rischi, la desiderabilità e la sostenibilità, l'impostazione delle ipotesi di test. Da solo accennare: business case dettagliati, ROI avanzato, gestione di portafogli progetti, progettazione tecnica dei prototipi, sperimentazione statistica specialistica, project management. Confini: usiamo le capacità di assistenti e agenti come possibili soluzioni senza ripetere il Tema 11; applichiamo a casi specifici le dimensioni del valore del Tema 12 senza riprenderne la teoria; usiamo la comprensione di compiti e processi del Tema 13 e i criteri informativi del Tema 14 come criteri di fattibilità. Non elaboriamo piani di implementazione, formazione o comunicazione, che sono del Tema 16, e identifichiamo rischi e vincoli senza approfondimenti normativi, che sono dei Temi 17 e 18.");
    pathSlide(s, [["15.1", "Partire dai problemi", "Alta"], ["15.2", "Descrivere un caso d'uso", "Alta"], ["15.3", "Opportunità promettenti", "Alta"], ["15.4", "Il valore potenziale", "Alta"], ["15.5", "Fattibilità tecnica e organizzativa", "Alta"], ["15.6", "Rischi e condizioni di controllo", "Alta"], ["15.7", "Confronto e priorità", "Alta"], ["15.8", "Dall'idea alla verifica", "Alta"]],
      [["Approfondire", "Problema, descrizione del caso d'uso, valore, confronto tra alternative", C.accent1, C.background1], ["Conoscere e sperimentare", "Alternative non AI, fattibilità, rischi, sostenibilità, ipotesi di test", C.accent6, C.text1], ["Solo accennare", "Business case, ROI avanzato, portafogli, prototipi tecnici, statistica", C.background2, C.text1]]);
  }
  {
    const s = content("Lo scenario del modulo", "Il documento di perimetro propone uno scenario che useremo come filo rosso: un'azienda che riceve molte richieste commerciali, via email e dal sito. Le persone dell'ufficio commerciale passano molto tempo a leggerle, a capire che cosa chiede il cliente, a preparare le risposte e a seguire le trattative. Tre opportunità ipotetiche emergono spesso in discussioni di questo tipo. La sintesi delle richieste: l'AI legge la richiesta e ne estrae i punti essenziali. Il valore possibile è la riduzione dei tempi di lettura; la condizione principale da verificare è la completezza e la correttezza delle sintesi. Le bozze di risposta: l'AI prepara una bozza che il commerciale rivede. Il valore possibile è rapidità e uniformità; la condizione da verificare è l'accuratezza delle condizioni commerciali e la disponibilità delle informazioni, come visto nel Tema 14. La gestione autonoma delle trattative: un agente che risponde, negozia, propone condizioni. Il valore possibile è una trasformazione del processo; le condizioni da verificare riguardano il controllo delle azioni, le eccezioni, le autorizzazioni e il rischio. I giudizi sono illustrativi, non valutazioni di un'azienda reale. Torneremo su queste tre opportunità in molti sottotemi.");
    table(s, [["Opportunità ipotetica", "Possibile valore", "Condizione principale da verificare"],
      ["Sintesi delle richieste", "Meno tempo di lettura", "Completezza e correttezza delle sintesi"],
      ["Bozze di risposta", "Rapidità e uniformità", "Accuratezza delle condizioni, informazioni disponibili"],
      ["Gestione autonoma delle trattative", "Trasformazione del processo", "Controllo delle azioni, eccezioni, autorizzazioni, rischio"]],
      { y: 1.15, colW: [2.8, 2.4, 3.8], rowH: 0.62, accentCol: 2, fontSize: 12, blankCorner: false });
    banner(s, 3.85, "Un'azienda che riceve molte richieste commerciali. Giudizi illustrativi, non valutazioni di un'azienda reale.", { h: 0.85, fontSize: 14 });
  }

  // =====================================================================
  section("15.1 Partire dai problemi");
  divider("15.1", "Partire dai problemi", "Prima di scegliere l'AI occorre comprendere il problema, e chiedersi se serve davvero", "Primo sottotema, da comprendere e applicare, e uno di quelli da approfondire. Il punto di partenza di ogni opportunità è un problema o un obiettivo, non uno strumento. Vediamo la differenza tra problema, bisogno, obiettivo e soluzione; dove cercare i problemi: inefficienze, attività che assorbono tempo, errori e rilavorazioni, informazioni mancanti, servizio da migliorare; come definire il risultato desiderato; come distinguere cause e sintomi; e come confrontare l'AI con soluzioni non AI. Integrazione A: prima chiedersi se serve davvero l'AI.");
  {
    const s = content("Dal problema alla soluzione", "La prima distinzione del sottotema, e la prima domanda guida. Quattro parole spesso usate come sinonimi, che conviene separare. Il problema è una situazione insoddisfacente osservabile: le risposte ai clienti arrivano in tre giorni, mentre i concorrenti rispondono in uno. Il bisogno è ciò che manca per superarla, dal punto di vista di chi la vive: i clienti hanno bisogno di una risposta rapida per decidere; i commerciali hanno bisogno di più tempo per le trattative importanti. L'obiettivo è il risultato desiderato, possibilmente misurabile: rispondere entro un giorno lavorativo al 90 per cento delle richieste. La soluzione è il modo scelto per raggiungerlo: più persone, una diversa organizzazione del lavoro, modelli di risposta, un assistente AI. Il problema più comune nelle discussioni sull'AI è partire dalla quarta: 'vogliamo un chatbot per i clienti'. Una soluzione presentata come obiettivo nasconde il problema, e impedisce di valutare alternative. Un esercizio semplice: quando qualcuno propone una soluzione, chiedere 'quale problema risolve?' e 'come sapremo se l'ha risolto?'. Esempio fittizio, legato allo scenario del modulo.");
    stepTag(s, 0);
    const l = [["Problema", "Situazione insoddisfacente osservabile", "Le risposte arrivano in tre giorni, i concorrenti in uno"], ["Bisogno", "Che cosa manca, per chi la vive", "I clienti vogliono decidere in fretta; i commerciali, tempo per le trattative"], ["Obiettivo", "Il risultato desiderato, misurabile", "Rispondere entro un giorno al 90% delle richieste"], ["Soluzione", "Il modo scelto per raggiungerlo", "Persone, organizzazione, modelli di risposta, un assistente AI"]];
    l.forEach((e, i) => {
      const y = 1.12 + i * 0.78, dark = i === 3;
      shapeBox(s, 0.5, y, 9.0, 0.7, dark ? C.accent6 : (i % 2 ? C.background1 : C.background2), e[0]);
      txt(s, e[0], { x: 0.65, y, w: 1.5, h: 0.7, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.15, y: y + 0.04, w: 7.2, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[2], { x: 2.15, y: y + 0.36, w: 7.2, h: 0.32, fontSize: 11, italic: true, color: C.text2 });
    });
    banner(s, 4.3, "Davanti a una soluzione: quale problema risolve? Come sapremo se l'ha risolto?", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Dove cercare i problemi", "Il sottotema indica cinque aree in cui cercare problemi e opportunità, utili come traccia per un'esplorazione in azienda. Le inefficienze e difficoltà operative: passaggi inutili, attese, lavoro duplicato, procedure macchinose. Le attività che assorbono tempo e risorse: quelle in cui le persone passano molte ore, spesso senza che sia il cuore del loro lavoro, come cercare informazioni, compilare, riformattare. I problemi di qualità, errori e rilavorazioni: dove si sbaglia spesso, dove si deve rifare il lavoro, dove arrivano reclami. I limiti nella disponibilità delle informazioni: dove le persone non trovano ciò che serve, o lo trovano tardi, o non sanno a chi chiedere. Le opportunità di miglioramento del servizio: che cosa i clienti, interni o esterni, vorrebbero e oggi non ricevono, come risposte più rapide o più personalizzate. Il modo migliore per individuarli è chiedere a chi fa il lavoro, osservare il lavoro reale, come visto nel Tema 13, e guardare i dati disponibili: tempi, volumi, errori, reclami. Notate che nessuna di queste aree menziona l'AI: i problemi vengono prima.");
    stepTag(s, 0);
    await iconGrid(s, [
      { icon: "FiAlertTriangle", head: "Inefficienze", body: "Passaggi inutili, attese, lavoro duplicato" },
      { icon: "FiClock", head: "Tempo e risorse", body: "Ore spese a cercare, compilare, riformattare" },
      { icon: "FiRotateCcw", head: "Errori e rilavorazioni", body: "Dove si sbaglia, si rifà, arrivano reclami" },
      { icon: "FiHelpCircle", head: "Informazioni mancanti", body: "Non si trova, si trova tardi, non si sa a chi chiedere" },
      { icon: "FiSmile", head: "Servizio da migliorare", body: "Che cosa i clienti vorrebbero e non ricevono" },
      { icon: "FiEye", head: "Come trovarli", body: "Chiedere a chi lavora, osservare, guardare i dati" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Nessuna di queste aree menziona l'AI: i problemi vengono prima.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Il risultato desiderato", "Il sottotema chiede di definire il risultato desiderato. Sembra ovvio, ma è spesso il passaggio più trascurato. Senza un risultato definito non si può valutare se una soluzione funziona, né confrontarla con altre. Un buon risultato desiderato ha alcune caratteristiche. È riferito al problema, non alla soluzione: 'risposte entro un giorno', non 'usare l'AI per le risposte'. È osservabile: si può capire se è stato raggiunto, possibilmente con un indicatore. Ha un livello di partenza: oggi le risposte arrivano in media in tre giorni. Ha un livello obiettivo realistico. E considera anche ciò che non deve peggiorare: la qualità delle risposte, la correttezza delle condizioni, la soddisfazione dei commerciali. Quest'ultimo punto è importante e spesso dimenticato: molti miglioramenti in una dimensione ne peggiorano un'altra, come visto nel Tema 12. Definire in anticipo i limiti da non superare evita di dichiarare un successo che in realtà ha spostato il problema. L'esempio in slide, fittizio, mostra la differenza tra una formulazione vaga e una formulazione utile.");
    stepTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.1, "Formulazione vaga", "Migliorare la gestione delle richieste commerciali con l'AI.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    shapeBox(s, 5.15, 1.15, 4.35, 2.9, C.accent6, "formulazione utile");
    txt(s, "Formulazione utile (esempio fittizio)", { x: 5.35, y: 1.22, w: 3.95, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
    const r = [["Problema", "Risposte lente ai clienti"], ["Oggi", "In media 3 giorni"], ["Obiettivo", "Entro 1 giorno per il 90%"], ["Non peggiorare", "Correttezza delle condizioni, qualità"], ["Come osservarlo", "Tempi registrati nel CRM"]];
    r.forEach((e, i) => {
      txt(s, e[0], { x: 5.35, y: 1.6 + i * 0.47, w: 1.5, h: 0.42, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[1], { x: 6.85, y: 1.6 + i * 0.47, w: 2.5, h: 0.42, fontSize: 12, color: C.text1, valign: "middle" });
    });
    txt(s, bullets(["Riferito al problema, non alla soluzione", "Osservabile, con un livello di partenza", "Un obiettivo realistico", "Che cosa non deve peggiorare"], { space: 4 }), { x: 0.6, y: 2.45, w: 4.2, h: 1.6, fontSize: 12, color: C.text1 });
    banner(s, 4.25, "Definire prima che cosa non deve peggiorare evita successi che spostano il problema.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Cause e sintomi", "Il sottotema chiede di identificare le cause del problema e distinguerle dai sintomi. È un principio classico del miglioramento dei processi: intervenire sui sintomi dà sollievo temporaneo, intervenire sulle cause risolve. Riprendiamo l'esempio: le risposte ai clienti sono lente. È un sintomo. Le cause possono essere molto diverse. Le richieste arrivano a una casella generica e nessuno le smista per giorni. I commerciali devono chiedere i prezzi all'ufficio tecnico, che risponde lentamente. Le richieste sono incomplete e servono scambi per chiarirle. I commerciali sono pochi rispetto ai volumi. Scrivere le risposte richiede molto tempo. Solo l'ultima causa è direttamente affrontabile con un assistente che prepara bozze. Se la causa principale è l'attesa dell'ufficio tecnico, un assistente che scrive più in fretta non cambierà molto il tempo totale: è il collo di bottiglia del Tema 12 e del Tema 13. Una tecnica semplice e nota è quella dei 'cinque perché', associata alla tradizione del miglioramento continuo giapponese: chiedersi più volte 'perché?' fino ad arrivare a una causa su cui si può intervenire. Esempio fittizio.");
    stepTag(s, 0);
    shapeBox(s, 0.5, 1.15, 2.6, 3.0, C.accent1, "sintomo");
    txt(s, "Sintomo", { x: 0.65, y: 1.3, w: 2.3, h: 0.35, fontSize: 12, bold: true, color: C.accent6 });
    txt(s, "Le risposte ai clienti sono lente", { x: 0.65, y: 1.75, w: 2.3, h: 1.2, fontSize: 16, bold: true, color: C.background1 });
    txt(s, "Esempio fittizio", { x: 0.65, y: 3.6, w: 2.3, h: 0.35, fontSize: 11, italic: true, color: C.accent6 });
    const c = [["Nessuno smista la casella generica", false], ["Si attendono i prezzi dall'ufficio tecnico", false], ["Richieste incomplete, servono chiarimenti", false], ["Pochi commerciali rispetto ai volumi", false], ["Scrivere le risposte richiede tempo", true]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.62;
      arrow(s, 3.2, y + 0.13, 0.35);
      chip(s, 3.65, y, 5.85, 0.52, e[0], { fill: e[1] ? C.accent6 : C.background2, fontSize: 12, bold: e[1] });
    });
    banner(s, 4.3, "Solo l'ultima causa è affrontata da bozze automatiche. I 'cinque perché' aiutano a risalire alle cause.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Le alternative non AI", "Il cuore del sottotema, e l'integrazione A: prima chiedersi se serve davvero l'AI. La prima precisazione trasversale del tema chiede di confrontare il caso d'uso non solo con altre applicazioni AI, ma con alternative realistiche. Il documento ne indica quattro. La situazione attuale, cioè non fare nulla: a volte il problema è tollerabile, o costerebbe di più risolverlo. Una modifica organizzativa: cambiare chi fa che cosa, l'ordine dei passaggi, le regole. Nell'esempio: assegnare a una persona lo smistamento quotidiano delle richieste. Una procedura tradizionale: un modulo strutturato sul sito, che raccolga le informazioni necessarie e riduca le richieste incomplete; un modello di risposta standard. Un'automazione semplice, basata su regole: instradare le richieste in base al prodotto, inviare una conferma automatica di ricezione. Queste alternative sono spesso più economiche, più affidabili, più facili da mantenere. Non sempre bastano: ci sono problemi in cui l'AI offre qualcosa che le alternative non possono dare, come la comprensione di testi liberi e variabili. Ma il confronto va fatto, e va fatto prima. Esempi fittizi.");
    stepTag(s, 0);
    const a = [["FiPauseCircle", "Situazione attuale", "Non intervenire: il problema è tollerabile?"], ["FiUsers", "Modifica organizzativa", "Una persona smista ogni mattina"], ["FiFileText", "Procedura tradizionale", "Un modulo strutturato, risposte standard"], ["FiGitBranch", "Automazione semplice", "Regole di instradamento, conferma automatica"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.3, C.background2, a[i][1]);
      await iconCircle(s, x + 0.75, 1.25, 0.62, a[i][0]);
      txt(s, a[i][1], { x: x + 0.1, y: 1.95, w: 1.95, h: 0.5, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, a[i][2], { x: x + 0.12, y: 2.5, w: 1.91, h: 0.85, fontSize: 11, italic: true, color: C.text2, align: "center" });
    }
    shapeBox(s, 0.5, 3.6, 9.0, 0.6, C.accent6, "quando l'AI");
    txt(s, [{ text: "Quando l'AI aggiunge qualcosa: ", options: { bold: true, color: C.accent1 } }, { text: "per esempio la comprensione di testi liberi e variabili, che le regole non gestiscono.", options: { color: C.text1 } }], { x: 0.7, y: 3.6, w: 8.6, h: 0.6, fontSize: 12, valign: "middle" });
    banner(s, 4.35, "Prima chiedersi se serve davvero l'AI. Il confronto va fatto, e va fatto prima.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Partire dalla tecnologia", "L'ultimo punto del sottotema: i rischi di partire dalla tecnologia anziché dal bisogno. Vale la pena elencarli, perché è un errore molto diffuso e comprensibile, alimentato dall'entusiasmo e dalla pressione esterna. Soluzioni in cerca di un problema: progetti che funzionano tecnicamente ma che nessuno usa, perché non rispondevano a un bisogno sentito. Investimenti sproporzionati: soluzioni sofisticate per problemi che un'alternativa semplice avrebbe risolto. Obiettivi non definiti: senza un problema di partenza, non si sa che cosa misurare, e il progetto non può né riuscire né fallire in modo chiaro. Dimostrazioni senza seguito: un prototipo impressionante, presentato con successo, che non diventa mai uno strumento di lavoro. Problemi spostati: l'AI accelera un passaggio, ma il problema vero era altrove. E una conseguenza meno visibile: delusione e scetticismo, che rendono più difficili anche i progetti successivi, anche quelli validi. Questo non significa che conoscere la tecnologia sia inutile: sapere che cosa l'AI può fare, come nei Temi 8-11, aiuta a riconoscere opportunità. Significa che, una volta vista un'opportunità, bisogna risalire al problema e verificare che sia reale.");
    stepTag(s, 0);
    rowsLabel(s, [["Soluzioni senza problema", "Funzionano, ma nessuno le usa"], ["Investimenti sproporzionati", "Sofisticate dove bastava poco"], ["Obiettivi non definiti", "Il progetto non può né riuscire né fallire in modo chiaro"], ["Dimostrazioni senza seguito", "Il prototipo impressiona, lo strumento non arriva"], ["Delusione e scetticismo", "Anche i progetti validi diventano più difficili"]], { y: 1.15, h: 0.5, lw: 2.8 });
    banner(s, 4.3, "Conoscere la tecnologia aiuta a vedere opportunità. Poi bisogna risalire al problema, e verificare che sia reale.", { h: 0.65, fontSize: 13 });
  }
  keySlide("Prima di scegliere l'AI occorre comprendere il problema, e chiedersi se una soluzione tradizionale, organizzativa o semplice non sia più adatta.", "Sottotema 15.1  ·  Partire dai problemi", "Concetto chiave del primo sottotema. Problema, bisogno, obiettivo e soluzione sono cose diverse, e partire dalla soluzione nasconde il problema. I problemi si cercano in inefficienze, tempo assorbito, errori, informazioni mancanti, servizio. Il risultato desiderato va definito in modo osservabile, con ciò che non deve peggiorare. Le cause vanno distinte dai sintomi. Le alternative non AI vanno confrontate prima. Esercizio suggerito: riprendere l'idea di uso dell'AI scritta all'inizio e riformularla partendo dal problema: quale situazione insoddisfacente, per chi, con quale risultato desiderato, e quali alternative non AI esistono.");

  // =====================================================================
  section("15.2 Descrivere un caso d'uso");
  divider("15.2", "Descrivere un caso d'uso", "Chi svolge quale attività, su quali informazioni, con quale contributo dell'AI e per quale risultato", "Secondo sottotema, da comprendere e applicare, e uno di quelli da approfondire. Dopo aver definito il problema, si descrive il caso d'uso: l'applicazione concreta dell'AI a quel problema. Il documento distingue: il 15.1 definisce il bisogno, il 15.2 descrive l'applicazione. Vediamo che cosa significa caso d'uso, gli elementi di una buona descrizione, la differenza tra un'idea generica e un caso d'uso definito, e l'identificazione delle ipotesi da verificare.");
  {
    const s = content("Che cos'è un caso d'uso", "Il significato di caso d'uso. Il termine viene dall'ingegneria del software, dove indica la descrizione di come un utente interagisce con un sistema per raggiungere un obiettivo. Nel linguaggio aziendale sull'AI ha preso un significato più ampio: un'applicazione specifica dell'AI a un'attività o a un processo, per un certo scopo. La consapevolezza del sottotema lo dice in una frase che conviene ricordare: un caso d'uso deve specificare chi svolge quale attività, su quali informazioni, con quale contributo dell'AI, e per quale risultato. Cinque elementi: il chi, il che cosa, le informazioni, il ruolo dell'AI, il risultato. Se manca uno di questi, non abbiamo ancora un caso d'uso, ma un'idea. 'Usare l'AI nel commerciale' è un ambito. 'Un chatbot per i clienti' è una soluzione. 'I commerciali dell'area nord ricevono, per ogni richiesta arrivata via email, una sintesi preparata dall'AI con prodotto, quantità, tempi e domande aperte, per ridurre il tempo di lettura e non perdere informazioni' è un caso d'uso. Esempio fittizio.");
    stepTag(s, 1);
    const e = [["Chi", "svolge"], ["Quale attività", "o processo"], ["Su quali informazioni", "input"], ["Con quale contributo", "dell'AI"], ["Per quale risultato", "osservabile"]];
    e.forEach((x, i) => {
      const xx = 0.5 + i * 1.84;
      shapeBox(s, xx, 1.15, 1.68, 1.05, i === 3 ? C.accent1 : C.background2, x[0]);
      txt(s, x[0], { x: xx + 0.08, y: 1.18, w: 1.52, h: 0.58, fontSize: 12, bold: true, color: i === 3 ? C.background1 : C.accent1, align: "center", valign: "middle" });
      txt(s, x[1], { x: xx + 0.08, y: 1.8, w: 1.52, h: 0.3, fontSize: 11, color: i === 3 ? C.accent6 : C.text2, align: "center" });
    });
    rowsLabel(s, [["Un ambito", "'Usare l'AI nel commerciale'"], ["Una soluzione", "'Un chatbot per i clienti'"]], { y: 2.4, h: 0.45, lw: 1.8 });
    docBox(s, 0.5, 3.5, 9.0, 1.35, "Un caso d'uso (esempio fittizio)", "I commerciali dell'area nord ricevono, per ogni richiesta via email, una sintesi preparata dall'AI con prodotto, quantità, tempi e domande aperte, per ridurre il tempo di lettura e non perdere informazioni.", { fontSize: 13, fill: C.accent6 });
  }
  {
    const s = content("Gli elementi della descrizione", "Il sottotema elenca gli elementi di una descrizione completa, che possiamo organizzare in una scheda. Contesto e persone coinvolte: in quale reparto, quali ruoli, chi usa e chi riceve il risultato. Attività o processo interessato: quale passaggio cambia. Problema e obiettivo concreto, dal 15.1. Input e informazioni necessarie: che cosa riceve il sistema, da dove, in quale forma; qui entrano le condizioni del Tema 14. Risultato atteso e modo per osservarlo. Ruolo previsto dell'AI: supporta, automatizza in parte, trasforma, come visto nel Tema 13. Intervento e supervisione umana: chi controlla, quando, come corregge. Frequenza e volume: quante volte al giorno, al mese; è un dato decisivo per il valore. Confini e condizioni d'uso: che cosa il sistema non deve fare, in quali casi non si usa, come si gestiscono le eccezioni. La scheda in slide riassume gli elementi: è uno strumento semplice, che chiunque può compilare, e che rende confrontabili idee diverse. Nella pratica, compilarla fa emergere rapidamente che cosa non si sa ancora.");
    stepTag(s, 1);
    const f = [["Contesto e persone", "Reparto, ruoli, chi usa e chi riceve"], ["Attività o processo", "Quale passaggio cambia"], ["Problema e obiettivo", "Dal 15.1"], ["Input e informazioni", "Che cosa, da dove, in quale forma"], ["Risultato atteso", "E come osservarlo"], ["Ruolo dell'AI", "Supporta, automatizza in parte, trasforma"], ["Supervisione umana", "Chi controlla, quando, come corregge"], ["Frequenza e volume", "Quante volte, quanti casi"], ["Confini e condizioni", "Che cosa non fa, eccezioni, quando non si usa"]];
    f.forEach((e, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.15 + row * 1.0;
      shapeBox(s, x, y, 2.9, 0.88, row % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.15, y: y + 0.06, w: 2.6, h: 0.34, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: y + 0.42, w: 2.6, h: 0.4, fontSize: 11, color: C.text1 });
    });
    banner(s, 4.25, "Compilare la scheda fa emergere rapidamente che cosa non si sa ancora.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Un esempio compilato", "Proviamo a compilare la scheda per una delle tre opportunità dello scenario: le bozze di risposta alle richieste commerciali. Esempio interamente fittizio. Contesto: ufficio commerciale, otto commerciali, area Italia. Attività: risposta alle richieste di informazioni e preventivo arrivate via email. Problema e obiettivo: risposte in media in tre giorni, obiettivo un giorno per il 90 per cento, senza errori sulle condizioni. Input: testo della richiesta, listino in vigore, condizioni standard, storico del cliente dal CRM. Risultato: una bozza di risposta pronta da rivedere. Ruolo dell'AI: prepara la bozza, non invia. Supervisione: il commerciale rivede, corregge e invia; le condizioni fuori standard richiedono approvazione del responsabile, come oggi. Volume: circa 60 richieste al giorno. Confini: nessuna bozza per richieste su prodotti personalizzati o clienti con contratti quadro; nessun prezzo non presente nel listino. Notate che la compilazione ha già fatto emergere domande: il listino è aggiornato e accessibile? Lo storico del CRM è affidabile? Le richieste su prodotti personalizzati quante sono? Queste domande diventano le ipotesi da verificare.");
    stepTag(s, 1);
    rowsLabel(s, [["Contesto", "Ufficio commerciale, 8 persone, area Italia"], ["Attività", "Risposta a richieste di informazioni e preventivo via email"], ["Input", "Richiesta, listino in vigore, condizioni standard, storico CRM"], ["Ruolo dell'AI", "Prepara una bozza, non invia"], ["Supervisione", "Il commerciale rivede e invia; fuori standard, approva il responsabile"], ["Volume", "Circa 60 richieste al giorno"], ["Confini", "No prodotti personalizzati, no contratti quadro, no prezzi fuori listino"]], { y: 1.12, h: 0.42, lw: 1.8, fontSize: 11, headSize: 12 });
    txt(s, "Esempio fittizio: bozze di risposta alle richieste commerciali.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.accent5 });
  }
  {
    const s = content("Idea generica o caso definito", "Il sottotema chiede di riconoscere la differenza tra un'idea generica e un caso d'uso definito. Le idee generiche sono il punto di partenza naturale, e non vanno scoraggiate: 'potremmo usare l'AI per le richieste dei clienti'. Ma non sono ancora valutabili. Un'idea generica non permette di stimare il valore, perché non si sa quante attività riguarda e quanto tempo fa risparmiare. Non permette di valutare la fattibilità, perché non si sa quali informazioni servono. Non permette di valutare i rischi, perché non si sa che cosa fa il sistema e chi controlla. Non permette di confrontarla con altre, perché non si sa che cosa si sta confrontando. Il passaggio dall'idea al caso definito è spesso il lavoro più utile di tutta la valutazione, e richiede il contributo di chi conosce il lavoro: le persone che svolgono l'attività sanno quali sono le eccezioni, i volumi, le informazioni davvero necessarie. Un segnale utile: se due persone, leggendo la stessa descrizione, immaginano due sistemi molto diversi, il caso d'uso non è ancora definito.");
    stepTag(s, 1);
    await twoPanel(s, "Idea generica", "'Potremmo usare l'AI per le richieste dei clienti.'\n\nUn buon punto di partenza, ma non valutabile: valore, fattibilità, rischi, confronto restano indefiniti.", "Caso d'uso definito", "Chi, quale attività, quali informazioni, quale ruolo dell'AI, quale supervisione, quale risultato, quale volume, quali confini.\n\nValutabile e confrontabile.", { y: 1.15, h: 2.65, li: "FiCloud", ri: "FiClipboard" });
    banner(s, 4.0, "Segnale: se due persone, leggendo la stessa descrizione, immaginano due sistemi diversi, il caso non è ancora definito.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Le ipotesi da verificare", "L'ultimo punto del sottotema, che prepara il 15.8: l'identificazione delle principali ipotesi da verificare. Ogni caso d'uso, anche ben descritto, si basa su ipotesi: affermazioni che crediamo vere ma che non abbiamo ancora verificato. Conviene renderle esplicite subito, perché sono ciò che il caso d'uso deve dimostrare. Nell'esempio delle bozze di risposta, le ipotesi principali potrebbero essere: che la scrittura delle risposte sia una parte rilevante del tempo totale; che le bozze siano abbastanza buone da richiedere solo una revisione rapida; che il listino e le condizioni siano disponibili e aggiornati; che i commerciali usino le bozze invece di riscrivere da capo; che le richieste escluse, come i prodotti personalizzati, siano una minoranza. Alcune ipotesi sono critiche: se sono false, il caso d'uso non ha senso. Per esempio, se la scrittura occupa solo il 10 per cento del tempo totale, il beneficio massimo è limitato, comunque vadano le bozze. Identificare le ipotesi critiche è il primo passo per decidere che cosa verificare prima di investire. Esempio fittizio.");
    stepTag(s, 1);
    numList(s, ["La scrittura delle risposte è una parte rilevante del tempo totale", "Le bozze richiedono solo una revisione rapida", "Listino e condizioni sono disponibili e aggiornati", "I commerciali useranno le bozze invece di riscrivere", "Le richieste escluse sono una minoranza"], { y: 1.12, h: 0.5, fontSize: 13 });
    shapeBox(s, 0.5, 4.1, 9.0, 0.78, C.accent6, "critica");
    txt(s, [{ text: "Ipotesi critica: ", options: { bold: true, color: C.accent5 } }, { text: "se la scrittura occupa solo il 10% del tempo, il beneficio massimo è limitato, comunque vadano le bozze. Esempio fittizio.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.78, fontSize: 12, valign: "middle" });
  }
  keySlide("Un caso d'uso specifica chi svolge quale attività, su quali informazioni, con quale contributo dell'AI e per quale risultato. Il resto è ancora un'idea.", "Sottotema 15.2  ·  Descrivere un caso d'uso", "Concetto chiave del secondo sottotema. Un caso d'uso è un'applicazione specifica dell'AI a un'attività, per uno scopo. La scheda di descrizione comprende contesto, attività, problema, input, risultato, ruolo dell'AI, supervisione, volume e confini. Compilarla fa emergere ciò che non si sa, e le ipotesi da verificare, alcune delle quali critiche. Esercizio suggerito: in piccoli gruppi, compilare la scheda per l'idea scritta all'inizio, e sottolineare le ipotesi critiche, cioè quelle che, se false, renderebbero il caso d'uso privo di senso.");

  // =====================================================================
  section("15.3 Opportunità promettenti");
  divider("15.3", "Opportunità promettenti", "L'opportunità più promettente non è necessariamente la più complessa o impressionante", "Terzo sottotema, da comprendere. Quali caratteristiche di un'attività segnalano un'opportunità promettente? Riprendiamo, applicandoli alla scelta, alcuni criteri visti nel Tema 13 sulla trasformabilità: frequenza, impegno informativo, standardizzazione, variabilità, informazioni, verificabilità, conseguenze degli errori, giudizio specialistico. Il documento distingue: il 15.3 riconosce i segnali di potenziale, il 15.5 verifica la disponibilità effettiva dei prerequisiti. Integrazioni A e B: prima chiedersi se serve davvero l'AI, e il caso più promettente non è il più spettacolare.");
  {
    const s = content("Segnali di potenziale", "Il sottotema elenca le caratteristiche che possono rendere promettente un'opportunità. Le raggruppiamo in due famiglie. I segnali di valore, che dicono quanto potrebbe valere intervenire: attività frequenti e ripetitive, perché il beneficio si moltiplica; attività con elevato impegno informativo, cioè molto tempo speso a leggere, cercare, scrivere, sintetizzare, l'ambito in cui l'AI generativa interviene di più; volumi e tempi di esecuzione rilevanti. I segnali di adattabilità, che dicono quanto l'AI potrebbe funzionare bene: un certo grado di standardizzazione; variabilità ed eccezioni gestibili; disponibilità delle informazioni necessarie; possibilità di verificare i risultati; conseguenze degli errori limitate o intercettabili; necessità di giudizio specialistico contenuta, o comunque preservata nella supervisione. Nessun segnale da solo è decisivo, e alcuni vanno in direzioni opposte: un'attività molto standardizzata e ripetitiva è promettente, ma potrebbe essere gestita meglio da un'automazione tradizionale, come vediamo tra poco. Il documento sottolinea che questi sono segnali, non prove: un'attività astrattamente adatta può non essere realizzabile nel contesto specifico.");
    stepTag(s, 0);
    await twoPanel(s, "Segnali di valore", bullets(["Attività frequenti e ripetitive", "Elevato impegno informativo", "Volumi e tempi rilevanti"], { space: 6 }), "Segnali di adattabilità", bullets(["Standardizzazione, eccezioni gestibili", "Informazioni disponibili", "Risultati verificabili", "Errori con conseguenze limitate", "Giudizio specialistico contenuto o preservato"], { space: 4 }), { y: 1.15, h: 2.75, li: "FiTrendingUp", ri: "FiCheckSquare" });
    banner(s, 4.1, "Segnali, non prove: un'attività astrattamente adatta può non essere realizzabile nel contesto specifico.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Profilo di un'opportunità", "Uno strumento semplice per applicare i segnali: un profilo, che descrive un'attività su ciascuna caratteristica. Il grafico, con valutazioni illustrative e fittizie, confronta due delle opportunità dello scenario: la sintesi delle richieste e la gestione autonoma delle trattative. Su una scala da 1 a 5, dove 5 è il valore più favorevole. La sintesi delle richieste ha frequenza alta, impegno informativo alto, buona verificabilità, conseguenze degli errori limitate, perché la persona legge comunque la richiesta originale se serve, e poco bisogno di giudizio specialistico. La gestione autonoma delle trattative ha frequenza e impegno informativo simili, ma verificabilità bassa, conseguenze degli errori elevate, perché impegna l'azienda verso il cliente, e molto bisogno di giudizio. Il profilo non produce una decisione, ma rende visibili le differenze, e fa discutere sulle valutazioni: è il suo scopo principale. Le valutazioni sono giudizi, e persone diverse possono darne di diversi: è utile chiedere a più persone e confrontare. Valutazioni illustrative.");
    stepTag(s, 0);
    const labels = ["Frequenza", "Impegno informativo", "Standardizzazione", "Verificabilità", "Errori contenuti", "Poco giudizio specialistico"];
    s.addChart(pres.charts.BAR, [
      { name: "Sintesi delle richieste", labels, values: [5, 5, 3, 4, 4, 4] },
      { name: "Trattative autonome", labels, values: [4, 5, 2, 2, 1, 1] },
    ], { x: 0.5, y: 1.05, w: 6.0, h: 3.75, barDir: "bar", barGrouping: "clustered", chartColors: [HEX.a1, HEX.a5],
      showValue: true, dataLabelColor: HEX.dk1, dataLabelFontSize: 10, dataLabelFontFace: "+mn-lt", dataLabelPosition: "outEnd",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
      valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 5.5, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Profilo, da 1 a 5 (valutazioni illustrative)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 40 });
    await card(s, 6.75, 1.15, 2.75, 1.75, { icon: "FiMessageCircle", inline: true, head: "Fa discutere", headSize: 13, bodySize: 12, body: "Non decide: rende visibili le differenze." });
    await card(s, 6.75, 3.05, 2.75, 1.75, { icon: "FiUsers", inline: true, head: "Sono giudizi", headSize: 13, bodySize: 12, fill: C.accent6, body: "Chiedere a più persone e confrontare." });
  }
  {
    const s = content("Supporto o automazione parziale", "Il sottotema chiede di considerare la possibilità di supporto o automazione parziale. Davanti a un'attività, la scelta non è tra 'l'AI fa tutto' e 'l'AI non fa nulla'. Ci sono molte possibilità intermedie, come visto nei Temi 11 e 13. L'AI può preparare e la persona decidere: la bozza di risposta. Può occuparsi dei casi semplici e passare quelli complessi alla persona: le richieste standard ricevono una bozza, quelle con condizioni particolari no. Può fare un primo passaggio, come la classificazione o l'estrazione delle informazioni, lasciando il resto invariato. Può controllare il lavoro della persona invece di sostituirlo, segnalando possibili errori. Le soluzioni parziali hanno spesso vantaggi importanti: catturano gran parte del valore con una frazione del rischio, sono più facili da verificare, lasciano alla persona il controllo e il giudizio, e permettono di imparare prima di estendere. È una delle ragioni per cui l'opportunità più promettente è spesso più modesta di quella immaginata all'inizio. Esempi fittizi.");
    stepTag(s, 0);
    await iconGrid(s, [
      { icon: "FiEdit3", head: "Prepara, la persona decide", body: "La bozza di risposta" },
      { icon: "FiFilter", head: "I casi semplici", body: "Bozza per le richieste standard, non per le particolari" },
      { icon: "FiTag", head: "Un primo passaggio", body: "Classificare, estrarre informazioni" },
      { icon: "FiShield", head: "Controlla", body: "Segnala possibili errori nel lavoro della persona" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Gran parte del valore con una frazione del rischio, più facile da verificare, e si impara prima di estendere.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Complessità o utilità", "L'integrazione B del tema: il caso d'uso promettente non è necessariamente il più spettacolare. Il sottotema la formula come differenza tra complessità tecnologica e utilità effettiva. C'è una tendenza naturale a considerare più interessanti i progetti più ambiziosi: un agente che gestisce da solo le trattative attira più attenzione di uno strumento che riassume le email. Ma l'utilità non cresce con la complessità. Spesso è il contrario: più un sistema è complesso, più è costoso da costruire e mantenere, più è difficile da verificare, più rischi comporta, più tempo serve prima che produca valore, più facilmente si ferma allo stadio di prototipo. Uno strumento semplice, usato ogni giorno da molte persone, con risultati facili da controllare, può generare più valore complessivo di un sistema sofisticato usato raramente o con riserva. Il grafico illustra questa idea con un andamento ipotetico: oltre un certo punto, la complessità aggiunta porta più costi e rischi che utilità. La consapevolezza del sottotema: una soluzione limitata e controllabile può generare maggiore valore.");
    stepTag(s, 0);
    s.addChart(pres.charts.LINE, [
      { name: "Utilità effettiva", labels: ["Molto semplice", "Semplice", "Media", "Complessa", "Molto complessa"], values: [3, 6, 7, 6.5, 5] },
      { name: "Costi e rischi", labels: ["Molto semplice", "Semplice", "Media", "Complessa", "Molto complessa"], values: [1, 2, 3.5, 6, 9] },
    ], { x: 0.5, y: 1.05, w: 5.4, h: 3.4, chartColors: [HEX.a1, HEX.a5], lineSize: 3, lineDataSymbol: "circle", lineDataSymbolSize: 7,
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 10, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Andamento ipotetico, per complessità della soluzione", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt" });
    await card(s, 6.15, 1.15, 3.35, 1.6, { icon: "FiStar", inline: true, head: "Spettacolare", headSize: 13, bodySize: 12, body: "Più costoso, difficile da verificare, rischioso, lento." });
    await card(s, 6.15, 2.9, 3.35, 1.6, { icon: "FiCheckCircle", inline: true, head: "Utile", headSize: 13, bodySize: 12, fill: C.accent6, body: "Semplice, quotidiano, controllabile." });
  }
  {
    const s = content("Alternative più semplici", "L'ultimo punto del sottotema, e l'integrazione A applicata alle caratteristiche: il riconoscimento di alternative più semplici. Alcuni segnali, che sembrano indicare un'opportunità AI, indicano in realtà un'opportunità per altro. Se l'attività è completamente standardizzata, con regole chiare e senza eccezioni, un'automazione tradizionale basata su regole è probabilmente più affidabile, più economica e più verificabile dell'AI generativa, come visto nel Tema 11. Se il problema è che le informazioni sono disordinate, il primo intervento è mettere ordine, come visto nel Tema 14; l'AI potrà venire dopo. Se il problema è un passaggio organizzativo, come un'approvazione che attende giorni, la soluzione è organizzativa. Se l'attività è rara, il beneficio di automatizzarla è minimo. L'AI generativa aggiunge valore soprattutto dove c'è linguaggio naturale, variabilità dei contenuti, necessità di interpretare testi o produrre testi nuovi. Una domanda semplice da porsi: che cosa fa l'AI qui che una regola, un modulo o una migliore organizzazione non potrebbero fare?");
    stepTag(s, 0);
    table(s, [["Se...", "Probabilmente conviene..."],
      ["L'attività ha regole chiare e nessuna eccezione", "Un'automazione tradizionale"],
      ["Le informazioni sono disordinate", "Mettere prima ordine"],
      ["Il problema è un passaggio organizzativo", "Una soluzione organizzativa"],
      ["L'attività è rara", "Lasciare com'è"],
      ["Ci sono testi liberi, variabili, da interpretare o produrre", "Valutare l'AI generativa"]],
      { y: 1.15, colW: [4.8, 4.2], rowH: 0.47, accentCol: 1, fontSize: 12, blankCorner: false });
    banner(s, 4.2, "Che cosa fa l'AI qui che una regola, un modulo o una migliore organizzazione non potrebbero fare?", { h: 0.7, fontSize: 14 });
  }
  keySlide("L'opportunità più promettente non è necessariamente la più complessa o impressionante: una soluzione limitata e controllabile può generare più valore.", "Sottotema 15.3  ·  Opportunità promettenti", "Concetto chiave del terzo sottotema. I segnali di valore riguardano frequenza, impegno informativo e volumi; quelli di adattabilità riguardano standardizzazione, informazioni, verificabilità, conseguenze degli errori, giudizio. Il profilo fa discutere, non decide. Il supporto o l'automazione parziale catturano molto valore con meno rischio. La complessità non è utilità. E alcuni segnali indicano alternative più semplici. Esercizio suggerito: tracciare il profilo delle tre opportunità dello scenario, ciascuno da solo, poi confrontare in gruppo le valutazioni e discutere quelle più diverse.");
