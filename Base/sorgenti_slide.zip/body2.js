
// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}

function banner(s, y, text, o) {
  o = o || {};
  shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
  txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
}
(async () => {
  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 2", { placeholder: "kicker" });
    s.addText("Fondamenti e funzionamento dell'Intelligenza Artificiale", { placeholder: "title" });
    s.addText("Area: Comprendere l'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al secondo tema del percorso di AI Literacy. Nel Tema 1 abbiamo costruito il contesto: da dove arriva l'Intelligenza Artificiale, perché è diventata centrale e perché riguarda le aziende. In questo tema apriamo il cofano, ma senza trasformarci in ingegneri. L'obiettivo è capire i meccanismi quanto basta per usare e valutare l'AI con consapevolezza: che cosa è davvero l'AI, quali tipi esistono, come un sistema apprende dai dati, come funziona un modello linguistico, che cosa succede quando scriviamo una richiesta, da dove arrivano le informazioni usate per rispondere e perché le risposte possono cambiare. Useremo spiegazioni intuitive ma rigorose: niente formule, ma anche niente semplificazioni fuorvianti. Suggerimento per l'apertura: chiedere ai partecipanti di completare la frase 'Quando scrivo una domanda a un assistente AI, secondo me succede che...'. Le risposte sono un ottimo indicatore delle idee di partenza, spesso molto diverse tra loro, e possono essere riprese durante la sessione. Nota per il relatore: i contenuti sono aggiornati a ottobre 2026. Alcuni elementi cambiano rapidamente, in particolare le dimensioni delle finestre di contesto, le funzioni di memoria dei prodotti e le caratteristiche dei modelli più recenti: prima di ogni edizione conviene ricontrollarli.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è fornire una comprensione concettuale dei principali sistemi di Intelligenza Artificiale: come apprendono dai dati, come generano risultati, come avviene l'interazione e quali fonti informative possono essere utilizzate. Accanto a questo c'è un obiettivo di consapevolezza, che riassume lo spirito del modulo. L'AI non è una forma di intelligenza umana digitale: non pensa, non sente e non capisce come una persona, anche quando ne imita molto bene il linguaggio. Ma non è nemmeno un semplice archivio di informazioni, una specie di enciclopedia che restituisce frasi memorizzate. È un insieme di sistemi con meccanismi differenti, e il comportamento che osserviamo dipende da quattro elementi: il modello, i dati con cui è stato addestrato, il contesto che gli forniamo e il modo in cui lo usiamo. Questi quattro elementi torneranno in tutti i sottotemi.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo comprendere", headSize: 16, bodySize: 14,
      body: bullets(["Le principali famiglie di sistemi AI", "Come apprendono dai dati e generano risultati", "Come funziona un'interazione", "Da quali fonti arrivano le informazioni"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza sviluppare", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "L'AI non è un'intelligenza umana digitale, né un semplice archivio di informazioni.\n\nÈ un insieme di sistemi diversi, il cui comportamento dipende da modello, dati, contesto e modalità di utilizzo." });
  }
  {
    const s = content("Otto domande guida per questo modulo", "Queste otto domande guidano l'intero modulo e corrispondono, più o meno, ai sette sottotemi. Le prime due riguardano la definizione e la classificazione dell'AI. La terza e la quarta il modo in cui i modelli vengono addestrati e, in particolare, i modelli linguistici. La quinta riguarda ciò che accade durante un'interazione. La sesta e la settima, forse le più utili nella pratica quotidiana, riguardano la provenienza delle informazioni e la differenza tra concetti che spesso vengono confusi: addestramento, contesto, memoria, recupero documentale e fine-tuning. L'ultima riguarda la variabilità delle risposte. Suggerimento: chiedere ai partecipanti quale domanda li incuriosisce di più; alla fine del modulo torneremo su tutte con una risposta sintetica.");
    const qs = ["Che cosa intendiamo per Intelligenza Artificiale?", "Come si distinguono AI, ML, Deep Learning e AI generativa?", "Che cos'è un modello AI e come viene addestrato?", "Che cos'è un Large Language Model?", "Che cosa accade quando inviamo un prompt?", "Da dove provengono le informazioni di una risposta?", "Addestramento, contesto, memoria, recupero, fine-tuning: che differenza c'è?", "Perché le risposte possono variare a parità di richiesta?"];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.2 + row * 1.9;
      shapeBox(s, x, y, 2.15, 1.75, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.18, y: y + 0.12, w: 0.5, h: 0.45, fontSize: 22, bold: true, color: C.accent1 });
      txt(s, qs[i], { x: x + 0.18, y: y + 0.6, w: 1.85, h: 1.1, fontSize: 13, color: C.text1 });
    }
  }
  {
    const s = content("Il filo conduttore", "Prima di entrare nei sottotemi, fissiamo il filo conduttore. Il documento di perimetro indica la consapevolezza da sviluppare: l'AI non è un'intelligenza umana digitale né un semplice archivio, e il suo comportamento dipende da quattro elementi. Il modello, cioè che tipo di sistema è e come genera i risultati: sottotemi 2.1, 2.2 e 2.4. I dati, cioè gli esempi da cui il modello ha appreso e le informazioni che può consultare: sottotemi 2.3 e 2.6. Il contesto, cioè tutto ciò che il modello riceve durante l'interazione, dalle istruzioni ai documenti: sottotemi 2.5 e 2.6. Le modalità d'uso, cioè l'applicazione che integra il modello, i suoi strumenti e il modo in cui la usiamo: sottotemi 2.5 e 2.7. Nel modulo torneranno anche tre distinzioni che conviene avere presenti fin da ora: addestramento e inferenza, modello e applicazione, variabilità e correttezza. Suggerimento: ogni volta che emerge una domanda sul comportamento di un assistente, chiedere al gruppo da quale dei quattro elementi dipende.");
    const d = [["FiCpu", "Modello", "Che tipo di sistema è e come genera", "2.1  2.2  2.4"], ["FiDatabase", "Dati", "Da che cosa ha appreso, che cosa consulta", "2.3  2.6"], ["FiLayers", "Contesto", "Ciò che riceve durante l'interazione", "2.5  2.6"], ["FiSliders", "Modalità d'uso", "Applicazione, strumenti, uso", "2.5  2.7"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.15, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.05, w: 1.9, h: 0.38, fontSize: 15, bold: true, color: dark ? C.background1 : C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.43, w: 1.9, h: 0.5, fontSize: 12, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, d[i][3], { x: x + 0.1, y: 2.95, w: 1.9, h: 0.3, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
    }
    txt(s, "Tre distinzioni che tornano in tutto il modulo", { x: 0.5, y: 3.45, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    ["Addestramento e inferenza", "Modello e applicazione", "Variabilità e correttezza"].forEach((q, i) => chip(s, 0.5 + i * 3.07, 3.85, 2.86, 0.95, q, { fill: C.accent6, fontSize: 14 }));
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è organizzato in sette sottotemi, tutti confermati. Non hanno però la stessa profondità. Alcuni concetti vanno compresi bene, perché servono ogni giorno: la differenza tra AI e software tradizionale, tra addestramento e inferenza, il funzionamento generale degli LLM, il contesto, le fonti informative e la variabilità delle risposte. Altri vanno conosciuti, cioè saperli riconoscere e collocare: Machine Learning, Deep Learning, token, Transformer, parametri, fine-tuning, grounding e RAG. Altri ancora vanno solo accennati: la matematica delle reti neurali, l'ottimizzazione, i dettagli delle architetture e le procedure avanzate di addestramento. Confini con gli altri temi: non ripeteremo la storia dell'AI (Tema 1); rimanderemo al Tema 3 allucinazioni, bias, accuratezza e valutazione dell'affidabilità; al Tema 4 il confronto tra modelli e prodotti commerciali; ai Temi 5 e 6 il dialogo con l'AI e le tecniche di prompting; e al Tema 14 la realizzazione pratica di basi documentali e integrazioni.");
    const items = [["2.1", "Che cos'è l'Intelligenza Artificiale"], ["2.2", "Le principali categorie di AI"], ["2.3", "Come un sistema AI apprende dai dati"], ["2.4", "Che cosa sono i Large Language Models"], ["2.5", "Come funziona un'interazione con l'AI"], ["2.6", "Conoscenza e fonti informative"], ["2.7", "Variabilità dei risultati"]];
    items.forEach((it, i) => {
      const y = 1.15 + i * 0.5;
      shapeBox(s, 0.5, y, 5.2, 0.42, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.6, h: 0.42, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.3, y, w: 4.3, h: 0.42, fontSize: 14, color: C.text1, valign: "middle" });
    });
    const lv = [["Comprendere bene", "AI e software tradizionale, addestramento e inferenza, LLM, contesto, fonti, variabilità", C.accent1, C.background1], ["Conoscere", "ML, Deep Learning, token, Transformer, parametri, fine-tuning, grounding, RAG", C.accent6, C.text1], ["Solo accennare", "Matematica delle reti, ottimizzazione, dettagli delle architetture", C.background2, C.text1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 1.2;
      shapeBox(s, 6.0, y, 3.5, 1.05, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.15, y: y + 0.1, w: 3.2, h: 0.3, fontSize: 14, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.15, y: y + 0.42, w: 3.2, h: 0.6, fontSize: 11, color: l[3] });
    });
  }

  // =====================================================================
  section("2.1 Che cos'è l'AI");
  divider("2.1", "Che cos'è l'Intelligenza Artificiale", "Le prestazioni osservabili non autorizzano automaticamente ad attribuire all'AI caratteristiche umane", "Iniziamo dalla domanda più semplice e più difficile: che cosa intendiamo per Intelligenza Artificiale? Il termine è usato in modi molto diversi, a volte per indicare un software qualsiasi con qualche funzione 'intelligente', a volte per evocare macchine pensanti da film di fantascienza. In questo sottotema cerchiamo una definizione operativa, confrontiamo l'AI con l'intelligenza umana, distinguiamo i sistemi specializzati dall'idea di intelligenza artificiale generale e affrontiamo un tema molto concreto: la tendenza ad attribuire all'AI caratteristiche umane che le sue prestazioni non giustificano.");
  {
    const s = content("Una definizione operativa", "Non esiste una definizione di AI universalmente condivisa, ma oggi ne abbiamo una molto autorevole e rilevante per le aziende europee: quella del Regolamento europeo sull'Intelligenza Artificiale, l'AI Act (Regolamento UE 2024/1689, articolo 3), che riprende in larga parte la definizione dell'OCSE. In sintesi, un sistema di AI è un sistema automatizzato, progettato per funzionare con livelli di autonomia variabili, che può adattarsi dopo la messa in funzione e che, per obiettivi espliciti o impliciti, deduce dagli input che riceve come generare output quali previsioni, contenuti, raccomandazioni o decisioni, in grado di influenzare ambienti fisici o virtuali. La parola chiave è 'deduce': a differenza del software tradizionale, che esegue istruzioni scritte riga per riga, un sistema AI ricava come produrre il risultato a partire da ciò che ha appreso o da una base di conoscenza. Non è necessario memorizzare la definizione: basta coglierne gli elementi. La definizione non è stata modificata dal Digital Omnibus del 2026 (Regolamento UE 2026/1744), che ha cambiato altre parti dell'AI Act. Il quadro normativo è approfondito nel Tema 18; qui ci interessa come definizione di riferimento.");
    shapeBox(s, 0.5, 1.2, 4.6, 3.75, C.text1, "definizione");
    txt(s, "LA DEFINIZIONE DELL'AI ACT, IN SINTESI", { x: 0.75, y: 1.38, w: 4.1, h: 0.3, fontSize: 11, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Un sistema automatizzato che, con livelli di autonomia variabili, deduce dagli input che riceve come generare output (previsioni, contenuti, raccomandazioni, decisioni) in grado di influenzare ambienti fisici o virtuali.", { x: 0.75, y: 1.8, w: 4.1, h: 2.4, fontSize: 15, color: C.background1 });
    txt(s, "Fonte: Regolamento UE 2024/1689, art. 3", { x: 0.75, y: 4.5, w: 4.1, h: 0.3, fontSize: 10, color: C.accent3 });
    const k = [["FiInbox", "Riceve input", "Dati, testi, immagini, segnali"], ["FiCpu", "Deduce come rispondere", "Non esegue solo istruzioni scritte riga per riga"], ["FiSend", "Produce output", "Previsioni, contenuti, raccomandazioni, decisioni"], ["FiSliders", "Autonomia variabile", "Da semplice supporto ad azione autonoma"]];
    for (let i = 0; i < 4; i++) {
      const y = 1.2 + i * 0.95;
      await iconCircle(s, 5.4, y, 0.5, k[i][0]);
      txt(s, k[i][1], { x: 6.05, y: y - 0.04, w: 3.45, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
      txt(s, k[i][2], { x: 6.05, y: y + 0.27, w: 3.45, h: 0.5, fontSize: 12, color: C.text2 });
    }
  }
  {
    const s = content("Intelligenza artificiale e intelligenza umana", "Il termine 'intelligenza' può trarre in inganno, perché ci porta a immaginare qualcosa di simile alla mente umana. Il confronto aiuta a capire le differenze. Apprendimento: un sistema AI di norma ha bisogno di enormi quantità di esempi, mentre una persona impara spesso da pochi casi e dall'esperienza diretta. Ambito: le persone vivono in un corpo e in un mondo fisico e sociale, da cui ricavano buon senso e comprensione delle situazioni; i sistemi AI lavorano su rappresentazioni dei dati. Velocità e scala: qui l'AI ha un vantaggio enorme, perché può elaborare in pochi secondi quantità di testo che una persona leggerebbe in mesi. Coerenza: una persona esperta tende ad avere prestazioni relativamente uniformi nel proprio campo, mentre un sistema AI può essere eccellente in un compito e fallire in uno apparentemente più semplice. Consapevolezza e intenzioni: le persone hanno esperienze, scopi propri e responsabilità; per i sistemi AI attuali non esiste evidenza scientifica condivisa di coscienza o intenzioni. Il messaggio non è che uno sia migliore dell'altro, ma che sono diversi, e per questo possono essere complementari.");
    table(s, [["", "Sistemi AI", "Intelligenza umana"], ["Apprendimento", "Da grandi quantità di esempi", "Anche da pochi casi e dall'esperienza"], ["Ambito", "Rappresentazioni dei dati", "Corpo, mondo fisico e sociale, buon senso"], ["Velocità e scala", "Enormi quantità di informazioni in pochi secondi", "Limitate, ma con giudizio sul contesto"], ["Coerenza", "Eccellente in un compito, fragile in uno simile", "Prestazioni più uniformi nel proprio campo"], ["Consapevolezza", "Nessuna evidenza scientifica condivisa", "Esperienze, scopi propri, responsabilità"]], { colW: [1.8, 3.6, 3.6], rowH: 0.6, accentCol: 1 });
  }
  {
    const s = content("Sistemi specializzati e intelligenza artificiale generale", "Possiamo collocare i sistemi AI lungo uno spettro. Da un lato ci sono i sistemi specializzati, detti anche AI ristretta: progettati e addestrati per un compito preciso, come riconoscere difetti su una linea di produzione o prevedere la domanda. Sono la grande maggioranza dei sistemi AI in uso da decenni. In mezzo ci sono i modelli generalisti, come i grandi modelli linguistici: possono svolgere molti compiti diversi, ma restano limitati a ciò che si può fare elaborando testo, immagini e altri dati, e con prestazioni irregolari. All'altro estremo c'è l'AGI, l'intelligenza artificiale generale: un sistema ipotetico capace di svolgere la maggior parte dei compiti cognitivi umani con un livello paragonabile o superiore a quello di una persona, e di adattarsi a situazioni nuove con la stessa flessibilità. Non esiste una definizione condivisa di AGI, né accordo sui tempi o sulla possibilità di realizzarla; alcuni esperti la ritengono vicina, altri lontana o mal definita. Per il nostro lavoro quotidiano conta una cosa: i sistemi che usiamo oggi sono molto versatili, ma non sono intelligenze generali, e vanno usati di conseguenza.");
    const y = 2.2;
    s.addShape(pres.shapes.LINE, { x: 0.8, y: y + 0.45, w: 8.4, h: 0, line: { color: C.accent3, width: 3, endArrowType: "triangle" }, objectName: "spettro" });
    const p = [["AI specializzata", "Un compito preciso", "Controllo qualità, previsione della domanda, antispam", C.background2, C.text1, "FiCrosshair"], ["Modelli generalisti", "Molti compiti diversi", "Grandi modelli linguistici e multimodali", C.accent6, C.text1, "FiLayers"], ["AGI", "Ipotetica e dibattuta", "La maggior parte dei compiti cognitivi umani", C.text1, C.background1, "FiHelpCircle"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.1;
      await iconCircle(s, x + 1.12, y, 0.9, p[i][5], i === 2 ? C.accent2 : C.accent1);
      shapeBox(s, x, 3.3, 2.85, 1.65, p[i][3], p[i][0]);
      txt(s, p[i][0], { x: x + 0.18, y: 3.42, w: 2.5, h: 0.35, fontSize: 16, bold: true, color: p[i][4] });
      txt(s, p[i][1], { x: x + 0.18, y: 3.8, w: 2.5, h: 0.3, fontSize: 13, bold: true, color: i === 2 ? C.accent3 : C.accent1 });
      txt(s, p[i][2], { x: x + 0.18, y: 4.15, w: 2.5, h: 0.7, fontSize: 12, color: p[i][4] });
    }
    txt(s, "Oggi in uso", { x: 0.5, y: 1.25, w: 5.9, h: 0.3, fontSize: 13, bold: true, color: C.accent1, align: "center" });
    txt(s, "Oggetto di dibattito", { x: 6.7, y: 1.25, w: 2.6, h: 0.3, fontSize: 13, bold: true, color: C.accent2, align: "center" });
  }
  {
    const s = content("Comprensione apparente: l'effetto ELIZA", "Questa integrazione del sottotema riguarda un fenomeno psicologico più che tecnico. Nel 1966 Joseph Weizenbaum, ricercatore al MIT, creò ELIZA, un programma molto semplice che simulava uno psicoterapeuta riformulando le frasi dell'utente come domande, sulla base di poche regole. Se l'utente scriveva 'sono triste per mio padre', ELIZA poteva rispondere 'parlami della tua famiglia'. Nonostante la semplicità del meccanismo, molte persone attribuivano al programma comprensione ed empatia, e alcune gli confidavano questioni personali. Weizenbaum ne rimase colpito e preoccupato. Da allora si parla di 'effetto ELIZA': la tendenza ad attribuire comprensione e qualità umane a un sistema che produce linguaggio in modo convincente. Con gli assistenti AI di oggi l'effetto è molto più forte, perché il linguaggio è molto più fluente, il tono è naturale e i sistemi usano espressioni come 'penso', 'mi dispiace', 'capisco'. Queste formule sono il risultato dell'addestramento su testi umani e di scelte di progettazione: non sono, di per sé, prova di pensieri o emozioni. Riconoscere questa tendenza in noi stessi è il primo passo per usare l'AI in modo lucido.");
    shapeBox(s, 0.5, 1.2, 4.0, 3.75, C.background2, "ELIZA");
    txt(s, "1966: ELIZA", { x: 0.7, y: 1.35, w: 3.6, h: 0.4, fontSize: 18, bold: true, color: C.accent1 });
    txt(s, "Un programma di poche regole che simulava uno psicoterapeuta", { x: 0.7, y: 1.78, w: 3.6, h: 0.55, fontSize: 13, color: C.text2 });
    chip(s, 0.7, 2.45, 3.0, 0.5, "Sono triste per mio padre", { fill: C.background1, fontSize: 12, bold: false });
    chip(s, 1.3, 3.05, 3.0, 0.5, "Parlami della tua famiglia", { fill: C.accent1, color: C.background1, fontSize: 12, bold: false });
    txt(s, "Molti utenti gli attribuivano comprensione ed empatia.", { x: 0.7, y: 3.75, w: 3.6, h: 0.6, fontSize: 13, italic: true, color: C.text1 });
    txt(s, "Fonte: Weizenbaum, 1966", { x: 0.7, y: 4.55, w: 3.6, h: 0.3, fontSize: 10, color: C.accent2 });
    txt(s, "L'effetto ELIZA oggi", { x: 4.85, y: 1.2, w: 4.6, h: 0.35, fontSize: 16, bold: true, color: C.text1 });
    const k = [["FiMessageCircle", "Linguaggio molto più fluente e naturale"], ["FiSmile", "Espressioni come \"penso\", \"mi dispiace\", \"capisco\""], ["FiUser", "Interfacce conversazionali che invitano al dialogo"], ["FiEye", "Formule apprese da testi umani: non provano pensieri o emozioni"]];
    for (let i = 0; i < 4; i++) {
      const y = 1.7 + i * 0.8;
      await iconCircle(s, 4.85, y, 0.5, k[i][0], i === 3 ? C.accent5 : C.accent1);
      txt(s, k[i][1], { x: 5.5, y, w: 4.0, h: 0.5, fontSize: 14, color: C.text1, valign: "middle", bold: i === 3 });
    }
  }
  {
    const s = content("Che cosa osserviamo e che cosa possiamo concludere", "Per evitare l'antropomorfizzazione è utile distinguere tre livelli. Primo, le capacità osservabili: il sistema produce un testo fluente, risponde in modo pertinente, risolve un problema, riassume correttamente un documento. Sono fatti che possiamo verificare, e su cui possiamo basare il nostro uso dello strumento. Secondo, il ragionamento: molti sistemi attuali sono in grado di scomporre un problema in passaggi e di arrivare a conclusioni che sembrano frutto di un ragionamento, e alcuni modelli sono progettati proprio per elaborare più passaggi prima di rispondere. È una capacità reale e utile, misurabile sui risultati, ma non infallibile, e quanto somigli al ragionamento umano è oggetto di ricerca e dibattito. Terzo, le caratteristiche mentali: comprensione nel senso umano, intenzioni, emozioni, coscienza, volontà. Le prestazioni osservabili non autorizzano ad attribuirle ai sistemi. Una conseguenza pratica importante: la sicurezza con cui un sistema si esprime non è un indicatore della correttezza di ciò che dice, e il fatto che 'sembri capire' non significa che abbia colto il nostro contesto. L'affidabilità degli output è approfondita nel Tema 3.");
    const lv = [["FiCheckCircle", "Capacità osservabili", "Testo fluente, risposte pertinenti, problemi risolti", "Verificabili: possiamo basarci su di esse", C.accent6], ["FiGitBranch", "Ragionamento", "Scomposizione in passaggi, conclusioni plausibili", "Reale e utile, non infallibile; la somiglianza con quello umano è dibattuta", C.background2], ["FiHelpCircle", "Caratteristiche mentali", "Comprensione umana, intenzioni, emozioni, coscienza", "Non autorizzate dalle prestazioni osservabili", C.background2]];
    txt(s, "Che cosa vediamo", { x: 1.2, y: 1.15, w: 3.6, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    txt(s, "Che cosa possiamo concludere", { x: 5.4, y: 1.15, w: 4.0, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    for (let i = 0; i < 3; i++) {
      const y = 1.5 + i * 1.12;
      shapeBox(s, 0.5, y, 9.0, 1.0, lv[i][4], lv[i][1]);
      await iconCircle(s, 0.65, y + 0.25, 0.55, lv[i][0], i === 2 ? C.accent2 : C.accent1);
      txt(s, lv[i][1], { x: 1.4, y: y + 0.12, w: 3.7, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
      txt(s, lv[i][2], { x: 1.4, y: y + 0.5, w: 3.7, h: 0.5, fontSize: 12, color: C.text2 });
      txt(s, lv[i][3], { x: 5.4, y: y + 0.1, w: 3.95, h: 0.85, fontSize: 13, color: C.text1, valign: "middle" });
    }
    txt(s, "La sicurezza con cui il sistema si esprime non indica la correttezza della risposta.", { x: 0.5, y: 4.85, w: 9, h: 0.25, fontSize: 11, italic: true, color: C.accent5 });
  }
  keySlide("L'AI non è un'unica tecnologia e le prestazioni osservabili non autorizzano automaticamente ad attribuirle caratteristiche umane.", "Sottotema 2.1  ·  Che cos'è l'Intelligenza Artificiale", "Concetto chiave del sottotema. Due messaggi. Primo: 'AI' è un termine ombrello che copre sistemi molto diversi, dai sistemi a regole ai grandi modelli linguistici; quando sentiamo dire 'l'AI fa questo', è sempre utile chiedersi di quale sistema si stia parlando. Secondo: ciò che un sistema sa fare va valutato sulle prestazioni verificabili, senza proiettare su di esso caratteristiche umane come comprensione, intenzioni o emozioni. Domanda di verifica: vi è mai capitato di ringraziare un assistente AI o di arrabbiarvi con lui? È del tutto normale: è proprio l'effetto ELIZA. L'importante è esserne consapevoli quando valutiamo le sue risposte.");

  // =====================================================================
  section("2.2 Categorie di AI");
  divider("2.2", "Le principali categorie di AI", "Approcci e capacità differenti, adatti a problemi differenti", "Nel Tema 1 abbiamo visto come si sono succeduti storicamente diversi approcci all'AI. Ora li riprendiamo da un altro punto di vista: non la storia, ma la classificazione. Vedremo l'AI simbolica, il Machine Learning, il Deep Learning, la distinzione tra AI predittiva, discriminativa e generativa e l'AI multimodale. Un'avvertenza importante fin dall'inizio: queste categorie non sono caselle mutuamente esclusive, perché rispondono a criteri di classificazione diversi.");
  {
    const s = content("Quattro criteri di classificazione diversi", "Questa slide è la chiave di lettura dell'intero sottotema. Le etichette che si sentono più spesso rispondono a domande diverse. Prima domanda: come viene costruita la conoscenza del sistema? Con regole scritte da persone (AI simbolica) oppure apprendendo dai dati (Machine Learning). Seconda domanda: con quale tecnica si apprende? Con metodi di Machine Learning 'classico' oppure con reti neurali profonde (Deep Learning). Terza domanda: che cosa produce il sistema? Una previsione, una classificazione o un contenuto nuovo (AI predittiva, discriminativa, generativa). Quarta domanda: quali tipi di dati tratta? Un solo tipo oppure più tipi insieme (unimodale o multimodale). Ne segue che uno stesso sistema appartiene contemporaneamente a più categorie. Un grande modello linguistico come quelli degli assistenti AI, per esempio, è un sistema di Machine Learning, basato sul Deep Learning, generativo e spesso multimodale. Per questo chiedersi se un sistema sia 'Deep Learning o AI generativa' è come chiedersi se un'auto sia 'diesel o station wagon': sono due aspetti diversi.");
    table(s, [["Domanda", "Criterio", "Categorie"], ["Come costruisce la conoscenza?", "Approccio", "AI simbolica a regole  /  Machine Learning"], ["Con quale tecnica apprende?", "Tecnica", "ML classico  /  Deep Learning"], ["Che cosa produce?", "Funzione", "Predittiva  /  Discriminativa  /  Generativa"], ["Quali dati tratta?", "Modalità", "Unimodale  /  Multimodale"]], { colW: [3.0, 1.6, 4.4], rowH: 0.52, accentCol: 2, blankCorner: false });
    shapeBox(s, 0.5, 3.95, 9.0, 1.0, C.text1, "esempio LLM");
    await iconCircle(s, 0.7, 4.17, 0.56, "FiLayers", C.accent1);
    txt(s, [{ text: "Un grande modello linguistico è insieme: ", options: { color: C.accent3 } }, { text: "Machine Learning, Deep Learning, generativo e spesso multimodale.", options: { bold: true, color: C.background1 } }], { x: 1.45, y: 3.95, w: 7.9, h: 1.0, fontSize: 15, valign: "middle" });
  }
  {
    const s = content("AI simbolica e Machine Learning", "Riprendiamo brevemente la distinzione già incontrata nel Tema 1, guardandola ora dal punto di vista del funzionamento. Nell'AI simbolica la conoscenza è scritta esplicitamente da persone, sotto forma di regole, alberi decisionali o basi di conoscenza. Il sistema applica queste regole ai casi che riceve. È trasparente, perché possiamo sempre leggere la regola applicata, e prevedibile, ma fatica con i casi non previsti e con le attività in cui le regole sono difficili da formulare. Nel Machine Learning nessuno scrive le regole: il sistema le ricava dagli esempi, individuando regolarità nei dati. È adatto a problemi complessi e sfumati, ma il suo comportamento dipende dalla qualità dei dati e può essere meno facile da spiegare. Nella pratica aziendale i due approcci convivono spesso nello stesso sistema: per esempio un modello di Machine Learning stima il rischio di una transazione, e una regola esplicita stabilisce che sopra una certa soglia serve sempre un controllo umano.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiList", head: "AI simbolica a regole", headSize: 16, bodySize: 13,
      body: [{ text: "Le persone scrivono le regole", options: { bold: true, breakLine: true, paraSpaceAfter: 8, color: C.accent1 } }].concat(bullets(["Trasparente: si legge la regola applicata", "Prevedibile e controllabile", "Fragile con i casi non previsti", "Difficile per conoscenze intuitive"], { space: 3 })) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiTrendingUp", head: "Machine Learning", headSize: 16, bodySize: 13, fill: C.accent6,
      body: [{ text: "Il sistema ricava le regole dagli esempi", options: { bold: true, breakLine: true, paraSpaceAfter: 8, color: C.accent1 } }].concat(bullets(["Adatto a problemi complessi e sfumati", "Dipende dalla qualità dei dati", "Talvolta meno facile da spiegare", "Spesso combinato con regole esplicite"], { space: 3 })) });
  }
  {
    const s = content("Deep Learning e reti neurali", "Il Deep Learning è la famiglia di tecniche di Machine Learning basata sulle reti neurali artificiali con molti strati. Il nome 'rete neurale' deriva da una lontana ispirazione al cervello, ma è bene chiarire che una rete neurale artificiale non è un cervello in miniatura: è una struttura matematica. Funziona così, a livello intuitivo. L'input, per esempio i pixel di un'immagine, entra nel primo strato. Ogni 'neurone' artificiale riceve valori dai neuroni dello strato precedente, li combina pesandoli in modo diverso e passa il risultato allo strato successivo. Strato dopo strato, la rete costruisce rappresentazioni sempre più astratte: nel caso delle immagini, i primi strati reagiscono a bordi e linee, quelli intermedi a forme e parti di oggetti, gli ultimi a concetti come 'volto' o 'auto'. I pesi delle connessioni sono i parametri che vengono regolati durante l'addestramento, come vedremo nel sottotema 2.3. Il vantaggio del Deep Learning è che impara da solo quali caratteristiche dei dati sono utili, senza che qualcuno debba indicarle. Non entriamo nella matematica: per i nostri scopi basta questa immagine di strati che trasformano progressivamente l'informazione.");
    const layers = [3, 4, 4, 2];
    const lx = [0.9, 2.2, 3.5, 4.8];
    const pos = layers.map((n, li) => Array.from({ length: n }, (_, k) => [lx[li], 1.75 + (3.0 - (n - 1) * 0.75) / 2 + k * 0.75]));
    for (let li = 0; li < 3; li++) for (const a of pos[li]) for (const b of pos[li + 1]) {
      const x1 = a[0] + 0.15, y1 = a[1] + 0.15, x2 = b[0] + 0.15, y2 = b[1] + 0.15;
      s.addShape(pres.shapes.LINE, { x: x1, y: Math.min(y1, y2), w: x2 - x1, h: Math.abs(y2 - y1), flipV: y2 < y1, line: { color: C.accent3, width: 0.75 }, objectName: "connessione" });
    }
    pos.forEach((L, li) => L.forEach(p => s.addShape(pres.shapes.OVAL, { x: p[0], y: p[1], w: 0.3, h: 0.3, fill: { color: li === 0 || li === 3 ? C.text2 : C.accent1 }, line: { type: "none" }, objectName: "neurone" })));
    const lab = ["Input", "Strato nascosto", "Strato nascosto", "Output"];
    lab.forEach((l, i) => txt(s, l, { x: lx[i] - 0.45, y: 1.25, w: 1.2, h: 0.35, fontSize: 11, bold: true, color: C.text2, align: "center" }));
    txt(s, "Dai pixel ai concetti", { x: 0.5, y: 4.85, w: 5.0, h: 0.3, fontSize: 11, italic: true, color: C.accent2, align: "center" });
    const k = [["Bordi e linee", "I primi strati"], ["Forme e parti di oggetti", "Gli strati intermedi"], ["Concetti: \"volto\", \"auto\"", "Gli ultimi strati"]];
    txt(s, "Rappresentazioni sempre più astratte", { x: 5.8, y: 1.2, w: 3.7, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    k.forEach((e, i) => {
      const y = 1.7 + i * 0.85;
      shapeBox(s, 5.8, y, 3.7, 0.72, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.0, y: y + 0.06, w: 3.4, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
      txt(s, e[1], { x: 6.0, y: y + 0.38, w: 3.4, h: 0.28, fontSize: 12, color: C.text2 });
    });
    txt(s, "Una struttura matematica ispirata al cervello, non un cervello in miniatura.", { x: 5.8, y: 4.35, w: 3.7, h: 0.6, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("AI predittiva, discriminativa e generativa", "Questa classificazione guarda a che cosa produce il sistema. L'AI predittiva stima un valore o un evento futuro a partire dai dati storici: quante unità venderemo il mese prossimo, quando una macchina avrà probabilmente bisogno di manutenzione, quale cliente rischia di abbandonarci. L'AI discriminativa assegna un input a una categoria, distinguendo tra classi: questa email è spam o no, questo pezzo è conforme o difettoso, questa recensione è positiva o negativa. Nella pratica predittiva e discriminativa si sovrappongono molto, e spesso si parla genericamente di 'AI analitica' o 'tradizionale'. L'AI generativa, infine, produce contenuti nuovi, come testi, immagini, codice o audio, coerenti con ciò che ha appreso. Anche qui i confini non sono rigidi: un modello generativo può essere usato per classificare (basta chiedergli 'questa recensione è positiva o negativa?'), e le tre funzioni possono combinarsi nello stesso processo. Domanda per il gruppo: nei processi della nostra azienda, quali esempi riconoscete per ciascuna delle tre categorie?");
    const c = [["FiTrendingUp", "Predittiva", "Stima un valore o un evento futuro", ["Vendite del prossimo mese", "Manutenzione di un macchinario", "Rischio di abbandono di un cliente"], C.background2], ["FiFilter", "Discriminativa", "Assegna un input a una categoria", ["Spam o non spam", "Pezzo conforme o difettoso", "Recensione positiva o negativa"], C.background2], ["FiEdit3", "Generativa", "Produce contenuti nuovi", ["Bozza di una email", "Sintesi di un documento", "Immagine da una descrizione"], C.accent6]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.2, 2.86, 3.45, { icon: c[i][0], head: c[i][1], headSize: 16, bodySize: 13, fill: c[i][4],
        body: [{ text: c[i][2], options: { bold: true, color: C.accent1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(c[i][3], { space: 3 })) });
    }
    txt(s, "I confini non sono rigidi: le tre funzioni si combinano spesso nello stesso processo.", { x: 0.5, y: 4.75, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("AI multimodale", "Una modalità è un tipo di dato: testo, immagini, audio, video, ma anche dati tabellari o segnali di sensori. I primi sistemi AI erano quasi sempre unimodali, cioè lavoravano su un solo tipo di dato. I sistemi multimodali possono ricevere in input e, in alcuni casi, produrre in output tipi di dati diversi, mettendoli in relazione tra loro. Esempi concreti: fotografare un documento cartaceo e chiedere di estrarne i dati principali; caricare un grafico e chiedere di commentarlo; trasformare la registrazione di una riunione in un verbale; descrivere a parole un'immagine da generare; porre una domanda a voce e ricevere una risposta parlata. La multimodalità amplia molto i casi d'uso, perché gran parte delle informazioni aziendali non è solo testo: pensiamo a disegni tecnici, foto di prodotti, moduli scansionati, registrazioni di chiamate. Come sempre, le prestazioni non sono uniformi: un sistema può leggere molto bene un testo stampato e meno bene una tabella complessa o una scrittura a mano.");
    const m = [["FiFileText", "Testo"], ["FiImage", "Immagini"], ["FiMic", "Audio"], ["FiFilm", "Video"], ["FiGrid", "Tabelle"]];
    shapeBox(s, 3.55, 2.35, 2.9, 1.3, C.accent1, "modello multimodale");
    txt(s, "Modello multimodale", { x: 3.6, y: 2.35, w: 2.8, h: 1.3, fontSize: 16, bold: true, color: C.background1, align: "center", valign: "middle" });
    for (let i = 0; i < 5; i++) {
      const y = 1.2 + i * 0.75;
      await iconCircle(s, 0.5, y, 0.55, m[i][0]);
      txt(s, m[i][1], { x: 1.15, y, w: 1.4, h: 0.55, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
    }
    arrow(s, 2.6, 2.84, 0.8);
    arrow(s, 6.6, 2.84, 0.6);
    txt(s, "Esempi", { x: 7.35, y: 1.2, w: 2.15, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    const ex = ["Estrarre i dati da un documento fotografato", "Commentare un grafico", "Dalla registrazione al verbale", "Domanda a voce, risposta parlata"];
    ex.forEach((e, i) => { shapeBox(s, 7.35, 1.6 + i * 0.85, 2.15, 0.75, C.background2, e); txt(s, e, { x: 7.45, y: 1.6 + i * 0.85, w: 1.95, h: 0.75, fontSize: 12, color: C.text1, valign: "middle" }); });
  }
  {
    const s = content("Quale approccio per quale problema", "Il concetto chiave del sottotema dice che approcci diversi sono adatti a problemi diversi. Questa tabella lo rende concreto, con alcuni esempi indicativi. Se le regole sono chiare, stabili e verificabili, come il calcolo di uno sconto contrattuale, un sistema a regole o un normale software deterministico è spesso la scelta migliore: è più economico, prevedibile e verificabile. Se dobbiamo stimare un valore a partire da dati storici strutturati, come la domanda futura, il Machine Learning predittivo è lo strumento naturale. Se dobbiamo riconoscere difetti in immagini, il Deep Learning discriminativo è oggi lo standard. Se dobbiamo scrivere bozze, riassumere o riformulare testi, l'AI generativa è la più adatta. Se le informazioni arrivano in forme diverse, come foto, documenti scansionati e testo, serve un sistema multimodale. Il messaggio pratico: davanti a un problema, la domanda giusta non è 'come possiamo usare l'AI generativa?', ma 'qual è l'approccio più adatto a questo problema?'. A volte la risposta non è nemmeno l'AI.");
    table(s, [["Problema", "Approccio più adatto"], ["Regole chiare e stabili (calcolo di uno sconto contrattuale)", "Regole o software tradizionale"], ["Stimare un valore da dati storici (domanda futura)", "Machine Learning predittivo"], ["Riconoscere difetti in immagini di prodotti", "Deep Learning discriminativo"], ["Scrivere bozze, riassumere, riformulare testi", "AI generativa"], ["Informazioni in forme diverse (foto, scansioni, testo)", "AI multimodale"]], { colW: [5.4, 3.6], rowH: 0.56, accentCol: 1, blankCorner: false });
    txt(s, "La domanda giusta: qual è l'approccio più adatto a questo problema? A volte non è l'AI.", { x: 0.5, y: 4.7, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Esistono approcci e capacità differenti, adatti a problemi differenti. Le categorie rispondono a criteri diversi e non sono tutte mutuamente esclusive.", "Sottotema 2.2  ·  Le principali categorie di AI", "Concetto chiave. Le categorie dell'AI non sono un albero genealogico con rami separati, ma descrivono aspetti diversi dello stesso sistema: come costruisce la conoscenza, con quale tecnica apprende, che cosa produce, quali dati tratta. Saperle distinguere ci permette di leggere con più precisione le descrizioni di prodotti e progetti e di scegliere l'approccio adatto al problema. Domanda di verifica: un sistema che riconosce dalla foto se un pezzo è difettoso, in quali categorie rientra? Risposta: Machine Learning, probabilmente Deep Learning, discriminativo, unimodale (immagini).");

  // =====================================================================
  section("2.3 Come apprende un sistema AI");
  divider("2.3", "Come un sistema AI apprende dai dati", "L'addestramento modifica i parametri del modello; l'inferenza usa il modello per elaborare nuovi input", "Entriamo nel meccanismo dell'apprendimento automatico. È uno dei sottotemi in cui due concetti vanno compresi bene: la differenza tra addestramento e inferenza, che chiarisce molti equivoci sull'uso quotidiano dell'AI. Vedremo che cosa significa apprendere dai dati, che ruolo hanno gli esempi, che cosa sono i parametri e perché la vera prova di un modello è la capacità di generalizzare a casi nuovi. Ricordiamo che non tutti i sistemi AI apprendono dai dati: i sistemi a regole, per esempio, no. Qui parliamo dei sistemi di Machine Learning.");
  {
    const s = content("Che cosa significa apprendere dai dati", "Partiamo da un esempio familiare: stimare il prezzo di un appartamento. Un agente immobiliare esperto lo fa in base all'esperienza: ha visto centinaia di vendite e sa, più o meno, quanto incidono la zona, la superficie, il piano, lo stato dell'immobile. Nessuno gli ha dato una formula: l'ha ricavata dagli esempi. Un sistema di Machine Learning fa qualcosa di simile, in modo matematico e su scala molto più ampia. Riceve migliaia di esempi di vendite passate, ciascuno con le caratteristiche dell'immobile e il prezzo effettivo, e cerca la relazione che collega le caratteristiche al prezzo. Alla fine dell'addestramento ottiene un modello: una sorta di formula, molto complessa, che può applicare a un appartamento nuovo per stimarne il prezzo. Il sistema non 'sa' che cos'è un appartamento: ha individuato regolarità numeriche nei dati. Ed è proprio per questo che la qualità e la rappresentatività degli esempi sono così importanti: se nei dati mancano certi tipi di immobili, il modello non saprà valutarli bene.");
    const ex = [["Zona", "Superficie", "Piano", "Prezzo"], ["Centro", "80 m²", "3", "320.000 €"], ["Periferia", "95 m²", "1", "210.000 €"], ["Semicentro", "60 m²", "5", "195.000 €"], ["...", "...", "...", "..."]];
    txt(s, "Migliaia di esempi", { x: 0.5, y: 1.15, w: 3.6, h: 0.3, fontSize: 13, bold: true, color: C.text2 });
    table(s, ex, { x: 0.5, y: 1.5, w: 3.6, colW: [1.0, 0.95, 0.6, 1.05], rowH: 0.45, fontSize: 11, accentCol: 3, blankCorner: false });
    arrow(s, 4.25, 2.45, 0.5, C.accent1);
    shapeBox(s, 4.9, 1.95, 1.9, 1.35, C.accent1, "addestramento");
    txt(s, "Addestramento", { x: 4.95, y: 1.95, w: 1.8, h: 0.6, fontSize: 14, bold: true, color: C.background1, align: "center", valign: "bottom" });
    txt(s, "cerca la relazione tra caratteristiche e prezzo", { x: 5.0, y: 2.55, w: 1.7, h: 0.7, fontSize: 11, color: C.background1, align: "center" });
    arrow(s, 6.95, 2.45, 0.5, C.accent1);
    shapeBox(s, 7.6, 1.95, 1.9, 1.35, C.accent6, "modello");
    txt(s, "Modello", { x: 7.65, y: 1.95, w: 1.8, h: 0.6, fontSize: 14, bold: true, color: C.text1, align: "center", valign: "bottom" });
    txt(s, "applicabile a un appartamento nuovo", { x: 7.7, y: 2.55, w: 1.7, h: 0.7, fontSize: 11, color: C.text2, align: "center" });
    shapeBox(s, 4.9, 3.75, 4.6, 1.2, C.background2, "nota");
    await iconCircle(s, 5.1, 4.07, 0.55, "FiAlertCircle", C.accent2);
    txt(s, "Il modello individua regolarità numeriche: se nei dati mancano certi casi, non saprà valutarli bene.", { x: 5.8, y: 3.75, w: 3.6, h: 1.2, fontSize: 13, color: C.text1, valign: "middle" });
  }
  {
    const s = content("Dati di addestramento ed esempi", "Gli esempi da cui un sistema apprende possono essere di tipo diverso, e questo dà origine a tre modalità principali di apprendimento. Basta conoscerle a grandi linee. Nell'apprendimento supervisionato ogni esempio è accompagnato dalla risposta corretta, detta etichetta: email marcate come spam o non spam, immagini di pezzi marcate come conformi o difettosi, vendite passate con il prezzo effettivo. È la modalità più diffusa nelle applicazioni aziendali. Nell'apprendimento non supervisionato non ci sono etichette: il sistema cerca da solo strutture nei dati, per esempio gruppi di clienti con comportamenti d'acquisto simili, utili per la segmentazione. Nell'apprendimento per rinforzo il sistema impara per tentativi, ricevendo un segnale positivo o negativo in base al risultato delle sue azioni; è usato per esempio nei giochi, nella robotica e, come vedremo, anche per affinare i modelli linguistici sulla base delle preferenze umane. In tutti i casi vale lo stesso principio: il modello può essere buono solo quanto gli esempi da cui ha imparato. Dati scarsi, sbagliati o non rappresentativi producono modelli scarsi, sbagliati o distorti; il tema dei bias sarà approfondito nel Tema 3.");
    const c = [["FiTag", "Supervisionato", "Esempi con la risposta corretta (etichetta)", "Email spam o non spam, pezzi conformi o difettosi"], ["FiShuffle", "Non supervisionato", "Nessuna etichetta: il sistema cerca strutture", "Gruppi di clienti con comportamenti simili"], ["FiAward", "Per rinforzo", "Impara per tentativi, con segnali positivi o negativi", "Giochi, robotica, affinamento dei modelli linguistici"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.2, 2.86, 2.75, { icon: c[i][0], head: c[i][1], headSize: 16, bodySize: 13, fill: i === 0 ? C.accent6 : C.background2,
        body: [{ text: c[i][2], options: { bold: true, breakLine: true, paraSpaceAfter: 8, color: C.text1 } }, { text: "Esempio: " + c[i][3], options: {} }] });
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.text1, "principio dati");
    await iconCircle(s, 0.7, 4.24, 0.56, "FiDatabase", C.accent1);
    txt(s, "Un modello può essere buono solo quanto gli esempi da cui ha imparato.", { x: 1.45, y: 4.1, w: 7.9, h: 0.85, fontSize: 15, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Individuare schemi e regolarità (es. Spam)", "Che cosa significa, concretamente, 'individuare regolarità'? Prendiamo il filtro antispam. Analizzando migliaia di email etichettate, il sistema scopre che certe combinazioni di elementi compaiono molto più spesso nello spam: parole come 'gratis' o 'urgente' insieme a link verso domini sconosciuti, mittenti mai visti, molti punti esclamativi, richieste di dati personali. Nessun elemento, da solo, è decisivo: anche un'email legittima può contenere la parola 'urgente'. È la combinazione, pesata in base all'esperienza accumulata, a rendere un messaggio più o meno probabilmente spam. Questo esempio illustra tre caratteristiche importanti dell'apprendimento automatico. Le regolarità sono statistiche, non assolute: indicano probabilità, non certezze. Il sistema può cogliere combinazioni troppo numerose o sottili per essere scritte a mano. E può anche cogliere regolarità indesiderate o casuali presenti nei dati, che non hanno un vero rapporto con il fenomeno: se per caso nei dati di addestramento tutte le email di un certo fornitore erano spam, il sistema potrebbe imparare a bloccare quel fornitore anche quando scrive messaggi legittimi.");
    txt(s, "Segnali che il sistema impara a pesare", { x: 0.5, y: 1.15, w: 4.6, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const sig = [["\"gratis\", \"urgente\"", 0.62], ["Link a domini sconosciuti", 0.8], ["Mittente mai visto", 0.55], ["Molti punti esclamativi", 0.4], ["Richiesta di dati personali", 0.9]];
    sig.forEach((g, i) => {
      const y = 1.6 + i * 0.6;
      txt(s, g[0], { x: 0.5, y, w: 2.4, h: 0.45, fontSize: 13, color: C.text1, valign: "middle" });
      s.addShape(pres.shapes.RECTANGLE, { x: 3.0, y: y + 0.12, w: 2.0, h: 0.22, fill: { color: C.background2 }, line: { type: "none" }, objectName: "barra base" });
      s.addShape(pres.shapes.RECTANGLE, { x: 3.0, y: y + 0.12, w: 2.0 * g[1], h: 0.22, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "barra peso" });
    });
    txt(s, "Pesi illustrativi", { x: 3.0, y: 4.6, w: 2.0, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
    const k = [["FiPercent", "Statistiche, non assolute", "Indicano probabilità, non certezze"], ["FiLayers", "Combinazioni complesse", "Troppe o troppo sottili per scriverle a mano"], ["FiAlertTriangle", "Anche regolarità indesiderate", "Il sistema può imparare coincidenze presenti nei dati"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.25 + i * 1.22;
      await iconCircle(s, 5.5, y, 0.5, k[i][0], i === 2 ? C.accent5 : C.accent1);
      txt(s, k[i][1], { x: 6.15, y: y - 0.03, w: 3.35, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
      txt(s, k[i][2], { x: 6.15, y: y + 0.3, w: 3.35, h: 0.6, fontSize: 12, color: C.text2 });
    }
  }
  {
    const s = content("I parametri del modello", "Dove 'vive' ciò che un modello ha appreso? Nei suoi parametri. I parametri sono valori numerici interni al modello, come i pesi delle connessioni di una rete neurale che abbiamo visto prima. Un'immagine utile è quella di un enorme mixer audio con moltissime manopole: ogni manopola regola quanto conta un certo segnale nel produrre il risultato. All'inizio dell'addestramento le manopole sono in posizioni casuali e il modello produce risultati senza senso. L'addestramento consiste nel regolarle, poco alla volta, finché il modello produce risultati corretti sugli esempi. I modelli semplici hanno poche decine o centinaia di parametri. I grandi modelli linguistici ne hanno miliardi: GPT-3, presentato nel 2020, ne aveva 175 miliardi, e molti modelli recenti sono più grandi, anche se spesso le dimensioni non vengono rese pubbliche. Due precisazioni importanti. Primo: i parametri non contengono una copia ordinata dei dati di addestramento, come un archivio, ma una rappresentazione distribuita delle regolarità apprese. Secondo: una volta terminato l'addestramento, i parametri restano fissi durante l'uso normale; quando parliamo con un assistente, non stiamo modificando i suoi parametri.");
    shapeBox(s, 0.5, 1.2, 4.6, 3.75, C.background2, "analogia manopole");
    txt(s, "Un'analogia: un mixer con moltissime manopole", { x: 0.7, y: 1.35, w: 4.2, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    for (let r = 0; r < 3; r++) for (let c = 0; c < 8; c++) {
      const x = 0.85 + c * 0.5, y = 1.95 + r * 0.55;
      s.addShape(pres.shapes.OVAL, { x, y, w: 0.34, h: 0.34, fill: { color: (r * 8 + c) % 5 === 0 ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "manopola" });
    }
    txt(s, "Ogni parametro regola quanto conta un segnale. L'addestramento le regola poco alla volta, finché i risultati sono corretti sugli esempi.", { x: 0.7, y: 3.7, w: 4.2, h: 1.1, fontSize: 13, color: C.text2 });
    shapeBox(s, 5.4, 1.2, 4.1, 1.75, C.text1, "callout parametri");
    txt(s, "175 miliardi", { x: 5.6, y: 1.3, w: 3.7, h: 0.75, fontSize: 34, bold: true, color: C.accent1 });
    txt(s, "i parametri di GPT-3 (2020). Molti modelli recenti sono più grandi.", { x: 5.6, y: 2.1, w: 3.7, h: 0.7, fontSize: 13, color: C.background1 });
    await card(s, 5.4, 3.1, 4.1, 1.85, { inline: true, icon: "FiLock", head: "Fissi durante l'uso", bodySize: 13, body: "Non sono un archivio dei dati ma una rappresentazione delle regolarità. Usando l'assistente non li modifichiamo." });
  }
  {
    const s = content("Il ciclo di addestramento", "Vediamo il meccanismo dell'addestramento in quattro passaggi, ripetuti moltissime volte. Primo: il modello riceve un esempio e produce una previsione, usando i parametri attuali. Secondo: la previsione viene confrontata con la risposta corretta. Terzo: si misura l'errore, cioè quanto la previsione si discosta dalla risposta corretta. Quarto: i parametri vengono aggiustati leggermente, nella direzione che riduce l'errore. Poi si passa all'esempio successivo, e così via, per milioni o miliardi di volte. Il procedimento matematico che calcola in che direzione aggiustare ogni parametro si chiama ottimizzazione, e nelle reti neurali usa la retropropagazione dell'errore che abbiamo citato nel Tema 1: non serve conoscerne i dettagli. Per i grandi modelli questo processo richiede settimane o mesi di calcolo su migliaia di processori specializzati, con costi molto elevati. È per questo che l'addestramento di un grande modello è un'attività svolta da pochi grandi sviluppatori, e non qualcosa che avviene mentre lo usiamo.");
    const st = [["FiPlayCircle", "Previsione", "Il modello elabora un esempio con i parametri attuali"], ["FiColumns", "Confronto", "La previsione è confrontata con la risposta corretta"], ["FiActivity", "Errore", "Si misura quanto la previsione si discosta"], ["FiSliders", "Aggiustamento", "I parametri si modificano per ridurre l'errore"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.3, 2.05, 2.55, i === 3 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.5, 0.6, st[i][0]);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.12, y: 2.2, w: 1.81, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.65, w: 1.75, h: 1.1, fontSize: 12, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.07, 2.4, 0.24);
    }
    shapeBox(s, 0.5, 4.05, 9.0, 0.9, C.text1, "ripetizione");
    await iconCircle(s, 0.7, 4.2, 0.6, "FiRepeat", C.accent1);
    txt(s, "Ripetuto milioni o miliardi di volte. Per i grandi modelli servono settimane o mesi di calcolo: non avviene mentre li usiamo.", { x: 1.5, y: 4.05, w: 7.85, h: 0.9, fontSize: 14, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Generalizzare verso nuovi input", "L'obiettivo dell'addestramento non è che il modello dia risposte corrette sugli esempi che ha già visto, ma che sappia rispondere bene su casi nuovi. Questa capacità si chiama generalizzazione. Pensiamo a due studenti che preparano un esame di matematica. Il primo impara a memoria le soluzioni degli esercizi del libro: se all'esame trova gli stessi esercizi va benissimo, ma se i numeri cambiano è in difficoltà. Il secondo capisce il metodo, e sa applicarlo anche a esercizi mai visti. Un modello che si comporta come il primo studente soffre di quello che in gergo si chiama overfitting, o sovradattamento: si adatta troppo ai dati di addestramento, compresi i loro dettagli casuali, e generalizza male. Per verificare la generalizzazione, una parte dei dati viene tenuta da parte e non usata nell'addestramento: il modello viene poi valutato su questi dati 'nuovi'. Un'implicazione pratica: un modello generalizza bene verso casi simili a quelli da cui ha imparato; quando i casi reali si allontanano molto, per esempio un nuovo prodotto, un nuovo mercato o un cambiamento nei comportamenti dei clienti, le sue prestazioni possono peggiorare.");
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiArchive", head: "Memorizzare (overfitting)", headSize: 16, bodySize: 13,
      body: "Come lo studente che impara a memoria le soluzioni: perfetto sugli esercizi già visti, in difficoltà se cambiano i numeri." });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiAward", head: "Generalizzare", headSize: 16, bodySize: 13, fill: C.accent6,
      body: "Come lo studente che ha capito il metodo: sa risolvere anche esercizi mai visti prima." });
    shapeBox(s, 0.5, 4.0, 9.0, 0.95, C.background2, "implicazione");
    await iconCircle(s, 0.7, 4.2, 0.55, "FiMap");
    txt(s, "Un modello generalizza bene verso casi simili a quelli da cui ha imparato. Se la realtà cambia molto (nuovi prodotti, mercati, comportamenti), le prestazioni possono peggiorare.", { x: 1.45, y: 4.0, w: 7.9, h: 0.95, fontSize: 13, color: C.text1, valign: "middle" });
  }
  {
    const s = content("Addestramento e inferenza", "Questa è una delle distinzioni da comprendere bene. L'addestramento è la fase in cui il modello apprende: si usano grandi quantità di dati, i parametri vengono modificati, servono enormi risorse di calcolo e il processo avviene una volta, o comunque raramente, prima che il modello venga messo a disposizione. L'inferenza è la fase in cui il modello viene usato: riceve un input nuovo, per esempio la nostra domanda, e produce un output applicando i parametri già appresi, che restano invariati. Avviene ogni volta che qualcuno usa il sistema, richiede risorse molto minori per singola richiesta e tempi brevi. Perché è importante saperlo? Perché chiarisce molti equivoci. Quando usiamo un assistente AI, siamo in fase di inferenza: correggere una risposta o fornire un'informazione non 'insegna' al modello in modo permanente. Un fornitore può eventualmente usare le conversazioni per addestrare versioni future, ma si tratta di un processo separato, regolato dalle condizioni d'uso del servizio: un aspetto importante da verificare quando si condividono dati aziendali, che riprenderemo nei Temi 14 e 17.");
    table(s, [["", "Addestramento", "Inferenza"], ["Che cosa avviene", "Il modello apprende dagli esempi", "Il modello elabora un nuovo input"], ["Parametri", "Vengono modificati", "Restano invariati"], ["Dati", "Grandi quantità di esempi", "La singola richiesta e il suo contesto"], ["Quando", "Prima della messa a disposizione, raramente", "Ogni volta che il sistema viene usato"], ["Risorse", "Enormi: settimane o mesi di calcolo", "Molto minori, tempi brevi"], ["Chi lo fa", "Lo sviluppatore del modello", "Chiunque usi il sistema"]], { colW: [1.9, 3.55, 3.55], rowH: 0.47, accentCol: 2 });
    txt(s, "Quando usiamo un assistente siamo in inferenza: correggerlo non lo riaddestra.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Nei sistemi di Machine Learning l'addestramento modifica i parametri del modello, mentre l'inferenza lo utilizza per elaborare nuovi input. Non tutti i sistemi AI apprendono dai dati.", "Sottotema 2.3  ·  Come un sistema AI apprende dai dati", "Concetto chiave. Riassumiamo: un sistema di Machine Learning apprende individuando regolarità negli esempi; ciò che apprende è memorizzato nei parametri; l'addestramento regola i parametri, l'inferenza li usa; e la vera prova di un modello è la capacità di generalizzare a casi nuovi. Ricordiamo anche che non tutti i sistemi AI apprendono: i sistemi a regole applicano conoscenza scritta da persone. Domanda di verifica: se oggi correggo un errore dell'assistente AI, domani il modello lo avrà imparato? Risposta: in generale no, perché l'uso è inferenza e non modifica i parametri. L'applicazione potrebbe però ricordare l'informazione tramite funzioni di memoria, come vedremo nel sottotema 2.5.");

  // =====================================================================
  section("2.4 Large Language Models");
  divider("2.4", "Che cosa sono i Large Language Models", "Generano output usando regolarità apprese e il contesto disponibile: non sono solo un completamento automatico", "Arriviamo ai Large Language Models, i modelli linguistici di grandi dimensioni che stanno alla base degli assistenti AI che usiamo ogni giorno. È uno dei concetti da comprendere bene. Vedremo che cosa sono, come rappresentano il linguaggio attraverso i token, l'idea dell'architettura Transformer e del meccanismo di attenzione, come generano le risposte, quali capacità mostrano e perché uno stesso modello può affrontare compiti molto diversi. Un'avvertenza: spesso si sente dire che un LLM è 'solo un completamento automatico evoluto'. C'è del vero, ma è una semplificazione che rischia di essere fuorviante, e vedremo perché.");
  {
    const s = content("Un modello linguistico di grandi dimensioni", "Un Large Language Model, o LLM, è un modello di Deep Learning addestrato su enormi quantità di testo per elaborare e generare linguaggio. Scomponiamo il nome. 'Language Model', modello linguistico: un modello che ha appreso le regolarità del linguaggio, cioè come le parole e le frasi si combinano, e che in questo modo ha catturato anche molte informazioni sul mondo e molte strutture di ragionamento presenti nei testi. 'Large', di grandi dimensioni: grande per numero di parametri, che sono miliardi, per quantità di testo di addestramento, che include libri, siti web, articoli, codice e molto altro, e per potenza di calcolo usata. L'addestramento di un LLM moderno avviene tipicamente in due grandi fasi. La prima è il pre-addestramento, in cui il modello impara dal testo prevedendo, miliardi di volte, quale parte di testo viene dopo. La seconda è l'affinamento, in cui il modello viene ulteriormente addestrato con esempi di istruzioni e risposte di qualità e con il feedback umano, per diventare un assistente che segue le istruzioni, risponde in modo utile e rispetta regole di sicurezza. È questa seconda fase a trasformare un modello che 'continua testi' in un assistente conversazionale.");
    shapeBox(s, 0.5, 1.2, 4.0, 3.75, C.text1, "definizione LLM");
    txt(s, "LARGE LANGUAGE MODEL", { x: 0.75, y: 1.38, w: 3.5, h: 0.3, fontSize: 11, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Un modello di Deep Learning addestrato su enormi quantità di testo per elaborare e generare linguaggio.", { x: 0.75, y: 1.8, w: 3.5, h: 1.4, fontSize: 16, color: C.background1 });
    const L = [["Large", "Miliardi di parametri, enormi quantità di testo e di calcolo"], ["Language Model", "Ha appreso le regolarità del linguaggio e, con esse, molte informazioni e strutture di ragionamento"]];
    L.forEach((l, i) => { txt(s, l[0], { x: 0.75, y: 3.25 + i * 0.8, w: 3.5, h: 0.3, fontSize: 13, bold: true, color: C.accent1 }); txt(s, l[1], { x: 0.75, y: 3.53 + i * 0.8, w: 3.5, h: 0.5, fontSize: 11, color: C.accent3 }); });
    txt(s, "Due fasi di addestramento", { x: 4.85, y: 1.2, w: 4.6, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    await card(s, 4.85, 1.65, 4.65, 1.55, { inline: true, icon: "FiBookOpen", head: "1. Pre-addestramento", bodySize: 13, body: "Impara dal testo prevedendo, miliardi di volte, quale parte viene dopo." });
    await card(s, 4.85, 3.35, 4.65, 1.6, { inline: true, icon: "FiUserCheck", head: "2. Affinamento", bodySize: 13, fill: C.accent6, body: "Esempi di istruzioni e feedback umano: diventa un assistente utile e sicuro." });
  }
  {
    const s = content("I token: come il modello vede il testo", "Un LLM non legge il testo lettera per lettera né parola per parola, ma in unità chiamate token. Un token può essere una parola intera, una parte di parola, un segno di punteggiatura o uno spazio seguito da una parola. Le parole comuni sono spesso un solo token; quelle lunghe o rare vengono spezzate in più pezzi. L'esempio in slide è illustrativo: la suddivisione effettiva dipende dal modello. Ogni token corrisponde a un numero in un vocabolario di decine o centinaia di migliaia di elementi, e il modello lavora su sequenze di questi numeri. Perché i token sono importanti per chi usa l'AI? Per tre ragioni pratiche. Primo: i limiti dei modelli, come la lunghezza massima di testo che possono considerare, sono misurati in token, e anche i costi dei servizi a consumo sono spesso calcolati in token. Secondo: a parità di contenuto, lingue diverse richiedono un numero diverso di token; l'italiano di solito ne richiede un po' più dell'inglese, perché i vocabolari dei modelli sono costruiti su testi in gran parte inglesi. Terzo: alcuni comportamenti curiosi dei modelli, come le difficoltà a contare le lettere di una parola, si spiegano proprio con il fatto che il modello non vede le singole lettere ma i token.");
    txt(s, "Testo", { x: 0.5, y: 1.2, w: 2, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    shapeBox(s, 0.5, 1.5, 9.0, 0.6, C.background2, "frase");
    txt(s, "L'intelligenza artificiale cambia il lavoro.", { x: 0.7, y: 1.5, w: 8.6, h: 0.6, fontSize: 18, color: C.text1, valign: "middle" });
    txt(s, "Token (esempio illustrativo)", { x: 0.5, y: 2.3, w: 4, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    const tk = ["L'", "intel", "ligenza", " artific", "iale", " cambia", " il", " lavoro", "."];
    const tw = [0.55, 0.85, 1.05, 1.05, 0.7, 1.1, 0.55, 1.05, 0.4];
    let x = 0.5;
    tk.forEach((t, i) => {
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 2.65, w: tw[i], h: 0.55, rectRadius: 0.06, fill: { color: i % 2 ? C.accent6 : C.accent1 }, line: { type: "none" }, objectName: "token " + i });
      txt(s, t.replace(" ", "·"), { x, y: 2.65, w: tw[i], h: 0.55, fontSize: 14, bold: true, color: i % 2 ? C.text1 : C.background1, align: "center", valign: "middle" });
      x += tw[i] + 0.06;
    });
    txt(s, "· indica uno spazio. La suddivisione reale dipende dal modello.", { x: 0.5, y: 3.25, w: 6, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
    const k = [["FiMaximize", "Limiti e costi in token"], ["FiGlobe", "L'italiano usa più token dell'inglese"], ["FiType", "Il modello non vede le singole lettere"]];
    for (let i = 0; i < 3; i++) {
      const xx = 0.5 + i * 3.07;
      shapeBox(s, xx, 3.75, 2.86, 1.2, C.background2, k[i][1]);
      await iconCircle(s, xx + 0.18, 4.07, 0.55, k[i][0]);
      txt(s, k[i][1], { x: xx + 0.85, y: 3.75, w: 1.9, h: 1.2, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
    }
  }
  {
    const s = content("Rappresentare il significato", "Una volta suddiviso il testo in token, il modello trasforma ciascun token in una rappresentazione numerica chiamata embedding: una lunga lista di numeri che si può immaginare come una posizione in uno spazio con moltissime dimensioni. La proprietà fondamentale di questo spazio è che token e concetti con significati simili si trovano in posizioni vicine. Nella slide lo rappresentiamo in due dimensioni, a scopo puramente illustrativo: i documenti commerciali come fattura, preventivo e ordine stanno vicini tra loro; gli animali domestici formano un altro gruppo; le città un altro ancora. Queste posizioni non sono decise da qualcuno, ma emergono durante l'addestramento, perché parole usate in contesti simili finiscono per avere rappresentazioni simili. E, cosa ancora più importante, durante l'elaborazione la rappresentazione di ogni token viene arricchita dal contesto in cui si trova, come vedremo tra poco con il meccanismo di attenzione. È questa capacità di rappresentare il significato, e non solo la forma delle parole, che permette a un LLM di capire che 'fattura' e 'documento contabile' sono collegati, anche se non condividono nessuna lettera. Gli embedding sono anche alla base della ricerca semantica usata nei sistemi RAG, di cui parleremo nel sottotema 2.6.");
    shapeBox(s, 0.5, 1.2, 5.4, 3.75, C.background2, "spazio semantico");
    const groups = [[["fattura", 1.0, 1.7], ["preventivo", 1.6, 2.15], ["ordine", 0.85, 2.45]], [["cane", 3.8, 1.65], ["gatto", 4.45, 1.95], ["criceto", 3.95, 2.4]], [["Roma", 2.3, 3.6], ["Milano", 3.05, 3.95], ["Napoli", 2.2, 4.25]]];
    const col = [C.accent1, C.accent5, C.text2];
    groups.forEach((g, gi) => g.forEach(w => {
      s.addShape(pres.shapes.OVAL, { x: w[1], y: w[2], w: 0.18, h: 0.18, fill: { color: col[gi] }, line: { type: "none" }, objectName: "punto " + w[0] });
      txt(s, w[0], { x: w[1] + 0.24, y: w[2] - 0.07, w: 1.2, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    }));
    txt(s, "Rappresentazione illustrativa in due dimensioni", { x: 0.7, y: 4.6, w: 5.0, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
    const k = [["FiTarget", "Significati simili, posizioni vicine", "Ogni token diventa una lista di numeri: una posizione in uno spazio"], ["FiTrendingUp", "Emergono dall'addestramento", "Parole usate in contesti simili hanno rappresentazioni simili"], ["FiLink", "Arricchite dal contesto", "Il significato di ogni token si precisa in base alla frase"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.25 + i * 1.22;
      await iconCircle(s, 6.2, y, 0.5, k[i][0]);
      txt(s, k[i][1], { x: 6.85, y: y - 0.03, w: 2.65, h: 0.55, fontSize: 13, bold: true, color: C.text1 });
      txt(s, k[i][2], { x: 6.85, y: y + 0.5, w: 2.65, h: 0.6, fontSize: 11, color: C.text2 });
    }
  }
  {
    const s = content("Il Transformer e il meccanismo di attenzione", "Quasi tutti i grandi modelli linguistici attuali si basano sull'architettura Transformer, introdotta nel 2017 da ricercatori di Google nell'articolo 'Attention Is All You Need'. L'idea centrale è il meccanismo di attenzione. Per interpretare ogni parola, il modello considera tutte le altre parole del testo e stabilisce quanto ciascuna sia rilevante, cioè quanta 'attenzione' dedicarle. Prendiamo la parola 'pesca'. Nella frase 'Ho mangiato una pesca matura' il suo significato è determinato da 'mangiato' e 'matura': è un frutto. Nella frase 'Domenica andiamo a pesca sul lago' è determinato da 'andiamo' e 'lago': è un'attività. Il meccanismo di attenzione permette al modello di collegare ogni parola a quelle che ne chiariscono il significato, anche se sono lontane nel testo, per esempio un pronome che si riferisce a un nome citato tre frasi prima. Nei modelli reali questo avviene in molti strati successivi e con molte 'teste' di attenzione in parallelo, ciascuna sensibile a relazioni diverse. Un vantaggio pratico del Transformer è che elabora i token in parallelo anziché uno alla volta, e per questo si presta molto bene all'addestramento su larga scala con le GPU. Non serve approfondire oltre: il concetto da ricordare è che il modello interpreta ogni parola alla luce del contesto.");
    const sent = [[["Ho", 0], ["mangiato", 2], ["una", 0], ["pesca", 1], ["matura", 2]], [["Domenica", 0], ["andiamo", 2], ["a", 0], ["pesca", 1], ["sul", 0], ["lago", 2]]];
    const mean = ["un frutto", "un'attività"];
    for (let r = 0; r < 2; r++) {
      const y = 1.35 + r * 1.55;
      let x = 0.5;
      const words = sent[r];
      const widths = words.map(w => 0.32 + w[0].length * 0.12);
      let px = null; const ctx = [];
      words.forEach((w, i) => {
        const fill = w[1] === 1 ? C.accent1 : (w[1] === 2 ? C.accent6 : C.background2);
        chip(s, x, y + 0.45, widths[i], 0.55, w[0], { fill, color: w[1] === 1 ? C.background1 : C.text1, fontSize: 14, bold: w[1] > 0, line: w[1] === 2 ? { color: C.accent1, width: 1 } : undefined });
        if (w[1] === 1) px = x + widths[i] / 2; if (w[1] === 2) ctx.push(x + widths[i] / 2);
        x += widths[i] + 0.1;
      });
      ctx.forEach(cx => {
        const a = Math.min(px, cx), b = Math.max(px, cx);
        s.addShape(pres.shapes.ARC, { x: a, y: y + 0.05, w: b - a, h: 0.8, angleRange: [180, 0], line: { color: C.accent1, width: 1.5 }, fill: { type: "none" }, objectName: "attenzione" });
      });
      txt(s, "\"pesca\" = " + mean[r], { x: 6.7, y: y + 0.45, w: 3.2, h: 0.55, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
    }
    shapeBox(s, 0.5, 4.2, 9.0, 0.75, C.text1, "messaggio attenzione");
    txt(s, "Il modello interpreta ogni parola alla luce di tutte le altre, anche lontane nel testo.", { x: 0.7, y: 4.2, w: 8.6, h: 0.75, fontSize: 15, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Come viene generata una risposta", "Come genera il testo un LLM? Un token alla volta. Il modello riceve l'intero testo disponibile, cioè le istruzioni, la nostra richiesta e quanto ha già scritto, e calcola, per ogni token del suo vocabolario, la probabilità che sia quello giusto per continuare. Poi ne sceglie uno, lo aggiunge al testo e ripete l'intero processo per il token successivo, considerando anche quello appena aggiunto. Una risposta di qualche paragrafo richiede quindi centinaia di questi cicli, ed è per questo che negli assistenti vediamo spesso la risposta comparire progressivamente. Nell'esempio, dopo 'Oggi il cielo è', il modello assegna probabilità più alte a parole come 'sereno', 'nuvoloso' o 'azzurro' e molto basse a parole incoerenti. Le percentuali in slide sono illustrative. Due conseguenze importanti. Primo: il modello non scrive prima la risposta completa per poi mostrarla; la costruisce passo dopo passo, e ogni scelta condiziona le successive. Secondo: la scelta del token non è sempre quella più probabile, ma avviene con un certo grado di casualità controllata. Questo spiega la variabilità delle risposte, che approfondiremo nel sottotema 2.7.");
    const st = ["Testo disponibile", "Probabilità per ogni token", "Scelta di un token", "Aggiunta al testo"];
    st.forEach((t, i) => {
      const y = 1.25 + i * 0.85;
      chip(s, 0.5, y, 3.2, 0.62, (i + 1) + ". " + t, { fill: i === 2 ? C.accent1 : C.background2, color: i === 2 ? C.background1 : C.text1, fontSize: 14 });
      if (i < 3) s.addShape(pres.shapes.DOWN_ARROW, { x: 1.95, y: y + 0.64, w: 0.3, h: 0.2, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia giù" });
    });
    txt(s, "Si ripete per ogni token: centinaia di cicli per una risposta.", { x: 0.5, y: 4.65, w: 3.4, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
    shapeBox(s, 4.1, 1.2, 5.4, 0.55, C.background2, "prompt esempio");
    txt(s, [{ text: "Oggi il cielo è ", options: { color: C.text1 } }, { text: "...", options: { color: C.accent1, bold: true } }], { x: 4.3, y: 1.2, w: 5.0, h: 0.55, fontSize: 16, valign: "middle" });
    chartBarH(s, ["sereno", "nuvoloso", "azzurro", "coperto", "limpido", "frigorifero"], [0.38, 0.27, 0.17, 0.10, 0.07, 0.001], { x: 4.1, y: 1.85, w: 5.4, h: 2.9, max: 0.5 });
    txt(s, "Probabilità del token successivo, valori illustrativi", { x: 4.1, y: 4.8, w: 5.4, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
  }
  {
    const s = content("Più di un completamento automatico", "È vero che il meccanismo di base di un LLM consiste nel prevedere il token successivo, ed è per questo che talvolta lo si descrive come un 'completamento automatico evoluto', simile ai suggerimenti della tastiera dello smartphone. Ma fermarsi qui sarebbe fuorviante, per almeno tre ragioni. Primo, la scala e la ricchezza delle rappresentazioni: per prevedere bene il testo successivo in miliardi di casi diversi, il modello deve sviluppare rappresentazioni interne di grammatica, significato, fatti, relazioni logiche e stili, molto al di là della semplice frequenza delle parole. Il suggeritore della tastiera guarda poche parole; un LLM considera l'intero contesto. Secondo, l'affinamento: i modelli usati negli assistenti sono addestrati a seguire istruzioni, a dialogare e a rispondere in modo utile, non solo a continuare un testo. Terzo, il contesto: un LLM produce la risposta tenendo conto delle istruzioni, dei documenti forniti e della conversazione, e spesso è integrato con strumenti esterni come la ricerca. All'estremo opposto, va evitato anche l'errore inverso: il fatto che queste capacità siano notevoli non significa che il modello capisca nel senso umano o che non sbagli. La descrizione più corretta è quella del concetto chiave: un LLM genera output usando regolarità apprese e il contesto disponibile.");
    await card(s, 0.5, 1.2, 2.86, 2.7, { icon: "FiSmartphone", head: "Il suggeritore della tastiera", headSize: 15, bodySize: 13, body: "Guarda poche parole precedenti e propone la più frequente." });
    arrow(s, 3.45, 2.4, 0.5, C.accent1);
    shapeBox(s, 4.05, 1.2, 5.45, 2.7, C.accent6, "LLM");
    txt(s, "Un LLM", { x: 4.25, y: 1.32, w: 5.0, h: 0.35, fontSize: 16, bold: true, color: C.text1 });
    const k = [["FiLayers", "Rappresentazioni ricche", "Grammatica, significato, fatti, relazioni logiche"], ["FiUserCheck", "Affinato per seguire istruzioni", "Dialoga e risponde in modo utile"], ["FiPaperclip", "Usa tutto il contesto", "Istruzioni, documenti, conversazione, strumenti"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.78 + i * 0.7;
      await iconCircle(s, 4.25, y, 0.45, k[i][0]);
      txt(s, [{ text: k[i][1] + ": ", options: { bold: true, color: C.text1 } }, { text: k[i][2], options: { color: C.text2 } }], { x: 4.85, y, w: 4.5, h: 0.55, fontSize: 12, valign: "middle" });
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.background2, "equilibrio");
    await iconCircle(s, 0.7, 4.23, 0.56, "FiSliders", C.accent2);
    txt(s, "Capacità notevoli non significano comprensione umana né assenza di errori: genera output da regolarità apprese e dal contesto.", { x: 1.45, y: 4.1, w: 7.9, h: 0.85, fontSize: 13, color: C.text1, valign: "middle" });
  }
  {
    const s = content("Capacità linguistiche, di analisi e di ragionamento", "Che cosa sanno fare, in termini generali, gli LLM? Possiamo raggruppare le loro capacità in tre famiglie. Le capacità linguistiche: scrivere, riformulare, adattare lo stile e il registro, tradurre, correggere, sintetizzare. Sono le più mature e quelle su cui gli LLM sono più affidabili. Le capacità di analisi: estrarre informazioni da un testo, classificare, confrontare documenti, individuare temi ricorrenti, strutturare informazioni disordinate in tabelle o elenchi. Le capacità di ragionamento: scomporre un problema in passaggi, seguire una catena logica, pianificare, risolvere problemi matematici o di programmazione. Negli ultimi anni sono comparsi modelli progettati per dedicare più elaborazione al ragionamento, generando passaggi intermedi prima della risposta finale, con miglioramenti significativi su problemi complessi. Queste capacità sono reali e misurabili, ma con due avvertenze già incontrate: sono irregolari, cioè un modello può risolvere un problema difficile e sbagliarne uno apparentemente facile, e non sono infallibili. Per questo il livello di verifica deve crescere con l'importanza del risultato. L'analisi dei limiti e degli errori è oggetto del Tema 3.");
    const c = [["FiEdit3", "Linguistiche", ["Scrivere e riformulare", "Adattare stile e registro", "Tradurre e correggere", "Sintetizzare"]], ["FiSearch", "Di analisi", ["Estrarre informazioni", "Classificare e confrontare", "Individuare temi ricorrenti", "Strutturare dati disordinati"]], ["FiGitBranch", "Di ragionamento", ["Scomporre problemi", "Seguire catene logiche", "Pianificare", "Matematica e codice"]]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.95, { icon: c[i][0], head: c[i][1], headSize: 16, bodySize: 13, fill: i === 0 ? C.accent6 : C.background2, body: bullets(c[i][2], { space: 3 }) });
    }
    shapeBox(s, 0.5, 4.3, 9.0, 0.65, C.text1, "avvertenza");
    txt(s, "Reali e misurabili, ma irregolari e non infallibili: la verifica cresce con l'importanza del risultato.", { x: 0.7, y: 4.3, w: 8.6, h: 0.65, fontSize: 14, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Perché un modello può affrontare compiti diversi", "Una caratteristica sorprendente degli LLM è la versatilità: lo stesso modello scrive email, riassume contratti, traduce, genera codice, analizza dati e risponde a domande. Fino a pochi anni fa ognuno di questi compiti avrebbe richiesto un modello specifico, addestrato su dati specifici. Perché oggi ne basta uno? La ragione principale è che moltissimi compiti possono essere espressi nella stessa forma: un testo in ingresso e un testo in uscita. Tradurre significa ricevere un testo e produrne un altro; riassumere, classificare, rispondere, perfino scrivere codice, sono tutte trasformazioni di testo in testo. Dato che il modello è stato addestrato su una varietà enorme di testi, che contengono esempi di tutte queste attività, ha appreso le regolarità necessarie per svolgerle. Ed è stato poi affinato per seguire istruzioni, per cui basta descrivere il compito a parole per indirizzarlo. È il motivo per cui, come abbiamo visto nel Tema 1, il linguaggio naturale è diventato l'interfaccia. Precisazione: versatile non significa ugualmente bravo in tutto, e per alcuni compiti specifici un modello specializzato resta la soluzione migliore.");
    const tasks = ["Tradurre", "Riassumere", "Classificare", "Rispondere", "Scrivere codice", "Estrarre dati"];
    shapeBox(s, 0.5, 2.3, 2.0, 1.2, C.background2, "testo input");
    txt(s, "Testo in ingresso + istruzione", { x: 0.6, y: 2.3, w: 1.8, h: 1.2, fontSize: 14, bold: true, color: C.text1, align: "center", valign: "middle" });
    arrow(s, 2.6, 2.74, 0.5, C.accent1);
    shapeBox(s, 3.25, 1.3, 3.0, 3.2, C.accent1, "stesso modello");
    txt(s, "Lo stesso modello", { x: 3.3, y: 1.4, w: 2.9, h: 0.4, fontSize: 15, bold: true, color: C.background1, align: "center" });
    tasks.forEach((t, i) => chip(s, 3.5, 1.9 + i * 0.42, 2.5, 0.34, t, { fill: C.background1, color: C.accent1, fontSize: 12 }));
    arrow(s, 6.35, 2.74, 0.5, C.accent1);
    shapeBox(s, 7.0, 2.3, 2.5, 1.2, C.accent6, "testo output");
    txt(s, "Testo in uscita", { x: 7.1, y: 2.3, w: 2.3, h: 1.2, fontSize: 14, bold: true, color: C.text1, align: "center", valign: "middle" });
    txt(s, "Molti compiti sono trasformazioni di testo in testo. Versatile non significa ugualmente bravo in tutto.", { x: 0.5, y: 4.65, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Gli LLM generano output usando regolarità apprese e il contesto disponibile; la spiegazione non va ridotta alla sola metafora del completamento automatico.", "Sottotema 2.4  ·  Che cosa sono i Large Language Models", "Concetto chiave. Riassumiamo il percorso: un LLM rappresenta il testo come token, trasforma i token in rappresentazioni del significato, li interpreta alla luce del contesto grazie al meccanismo di attenzione, e genera la risposta un token alla volta, scegliendo tra i token più probabili. Tutto questo si basa su regolarità apprese da enormi quantità di testo e su un affinamento per seguire istruzioni. Non è magia e non è comprensione umana, ma nemmeno un semplice completamento automatico. Domanda di verifica: perché un LLM può avere difficoltà a contare quante lettere 'r' ci sono in una parola, pur scrivendo testi complessi? Risposta: perché non vede le singole lettere, ma i token.");

  // =====================================================================
  section("2.5 Come funziona un'interazione");
  divider("2.5", "Come funziona un'interazione con l'AI", "Il risultato dipende dalle informazioni rese disponibili; modello e prodotto non coincidono sempre", "Dopo aver visto come funziona un modello, guardiamo che cosa succede quando lo usiamo. Seguiremo il percorso di una richiesta, dall'input all'output, e chiariremo alcuni concetti molto pratici: la finestra di contesto, la cronologia della conversazione, la differenza tra contesto temporaneo e memoria persistente e la differenza tra il modello e l'applicazione che lo integra. È uno dei sottotemi con le ricadute più dirette sull'uso quotidiano. Ricordiamo che il dialogo con l'AI e le tecniche per scrivere prompt efficaci sono oggetto dei Temi 5 e 6: qui ci interessa capire il meccanismo.");
  {
    const s = content("Input, prompt e output", "Il prompt è il testo che inviamo al sistema: la nostra domanda o richiesta. Ma il modello, in realtà, riceve molto di più del solo messaggio che scriviamo. Riceve un insieme di informazioni che l'applicazione compone e gli passa a ogni richiesta. Le istruzioni di sistema, impostate dall'applicazione o dall'azienda, che definiscono il comportamento dell'assistente, il tono, le regole da rispettare, e che di solito l'utente non vede. La cronologia della conversazione, cioè i messaggi precedenti. Eventuali documenti, file o risultati di ricerche aggiunti al contesto. E infine il nostro messaggio. Tutto questo insieme costituisce l'input effettivo del modello. L'output è la risposta generata, che può essere testo ma anche, nei sistemi multimodali, un'immagine, un file o un'azione eseguita tramite uno strumento. Il messaggio pratico è che la risposta non dipende solo da ciò che scriviamo, ma da tutto ciò che il modello riceve: per questo due persone che fanno la stessa domanda in applicazioni diverse, o in conversazioni diverse, possono ottenere risposte diverse.");
    txt(s, "Ciò che il modello riceve", { x: 0.5, y: 1.15, w: 4.0, h: 0.3, fontSize: 13, bold: true, color: C.accent2 });
    const inp = [["Istruzioni di sistema", "Impostate dall'applicazione, di solito invisibili"], ["Cronologia della conversazione", "I messaggi precedenti"], ["Documenti e risultati di ricerca", "File allegati, fonti recuperate"], ["Il nostro messaggio", "La richiesta che scriviamo: il prompt"]];
    inp.forEach((e, i) => {
      const y = 1.5 + i * 0.86;
      shapeBox(s, 0.5, y, 4.2, 0.74, i === 3 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y: y + 0.06, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
      txt(s, e[1], { x: 0.7, y: y + 0.38, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    });
    arrow(s, 4.85, 2.85, 0.5, C.accent1);
    shapeBox(s, 5.5, 2.3, 1.6, 1.4, C.accent1, "modello");
    txt(s, "Modello", { x: 5.5, y: 2.3, w: 1.6, h: 1.4, fontSize: 16, bold: true, color: C.background1, align: "center", valign: "middle" });
    arrow(s, 7.2, 2.85, 0.45, C.accent1);
    shapeBox(s, 7.75, 2.3, 1.75, 1.4, C.text1, "output");
    txt(s, "Output", { x: 7.8, y: 2.4, w: 1.65, h: 0.4, fontSize: 16, bold: true, color: C.background1, align: "center" });
    txt(s, "Testo, immagine, file, azione", { x: 7.85, y: 2.85, w: 1.55, h: 0.75, fontSize: 12, color: C.accent3, align: "center" });
  }
  {
    const s = content("Il percorso di una richiesta", "Mettiamo in fila i passaggi di una singola richiesta, collegando i concetti visti finora. Primo: scriviamo il prompt. Secondo: l'applicazione compone il contesto completo, aggiungendo istruzioni di sistema, cronologia ed eventuali documenti. Terzo: il testo viene suddiviso in token, la cosiddetta tokenizzazione. Quarto: il modello esegue l'inferenza, elaborando l'intera sequenza di token con i parametri appresi durante l'addestramento, che non cambiano. Quinto: genera la risposta un token alla volta, come abbiamo visto. Sesto: i token generati vengono riconvertiti in testo leggibile e mostrati, spesso progressivamente, man mano che vengono prodotti. In alcune applicazioni, tra il quarto e il quinto passaggio, il modello può decidere di usare uno strumento, per esempio una ricerca sul web o un calcolo, e i risultati vengono aggiunti al contesto prima di proseguire. Tutto questo avviene in pochi secondi. Dopo la risposta, il modello non conserva nulla: alla richiesta successiva il processo ricomincia da capo, come vedremo parlando di cronologia.");
    const st = [["FiEdit3", "Prompt", "Scriviamo la richiesta"], ["FiLayers", "Contesto", "L'applicazione aggiunge istruzioni, cronologia, documenti"], ["FiHash", "Tokenizzazione", "Il testo diventa una sequenza di token"], ["FiCpu", "Inferenza", "Il modello elabora con parametri fissi"], ["FiRepeat", "Generazione", "Un token alla volta"], ["FiMessageSquare", "Output", "I token tornano testo leggibile"]];
    for (let i = 0; i < 6; i++) {
      const x = 0.5 + i * 1.55;
      shapeBox(s, x, 1.35, 1.38, 2.75, i === 3 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.42, 1.55, 0.55, st[i][0]);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.05, y: 2.2, w: 1.28, h: 0.4, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.1, y: 2.65, w: 1.18, h: 1.35, fontSize: 11, color: C.text2, align: "center" });
    }
    shapeBox(s, 0.5, 4.3, 9.0, 0.65, C.text1, "nota strumenti");
    txt(s, "In alcune applicazioni il modello può usare strumenti (ricerca, calcolo) e aggiungerne i risultati al contesto.", { x: 0.7, y: 4.3, w: 8.6, h: 0.65, fontSize: 13, color: C.background1, valign: "middle" });
  }
  {
    const s = content("La finestra di contesto", "La finestra di contesto è la quantità massima di testo, misurata in token, che il modello può considerare in una singola elaborazione. Comprende tutto: istruzioni di sistema, cronologia, documenti, il nostro messaggio e anche la risposta che sta generando. Un'immagine utile è quella di una scrivania: il modello può lavorare solo con i fogli che ci stanno sopra; ciò che non è sulla scrivania, per lui, non esiste. Le dimensioni variano molto da modello a modello e sono cresciute rapidamente negli ultimi anni: da poche migliaia di token dei primi assistenti a centinaia di migliaia o più nei modelli recenti, sufficienti per interi libri o raccolte di documenti. Che cosa succede quando la scrivania è piena? Dipende dall'applicazione: le parti più vecchie della conversazione possono essere escluse o riassunte, oppure il sistema segnala che il limite è stato raggiunto. Inoltre, una finestra più grande non significa attenzione uniforme su tutto: alcune ricerche, come lo studio 'Lost in the Middle' di Liu e colleghi (pubblicato nel 2024), hanno mostrato che i modelli possono trascurare informazioni collocate nel mezzo di contesti molto lunghi. Il messaggio pratico: fornire il contesto giusto conta più che fornirne tanto.");
    shapeBox(s, 0.5, 1.2, 5.2, 3.75, C.background2, "finestra", { color: C.accent1, width: 2, dashType: "dash" });
    txt(s, "Finestra di contesto", { x: 0.7, y: 1.3, w: 4.8, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    const b = [["Istruzioni di sistema", C.background1], ["Cronologia della conversazione", C.background1], ["Documenti allegati", C.background1], ["Il nostro messaggio", C.accent6], ["Risposta in generazione", C.accent1]];
    b.forEach((e, i) => chip(s, 0.75, 1.75 + i * 0.57, 4.7, 0.46, e[0], { fill: e[1], color: i === 4 ? C.background1 : C.text1, fontSize: 13 }));
    txt(s, "Ciò che non entra nella finestra, per il modello non esiste.", { x: 0.7, y: 4.58, w: 4.8, h: 0.25, fontSize: 10, italic: true, color: C.accent2 });
    const k = [["FiMaximize2", "Misurata in token", "Da poche migliaia a centinaia di migliaia o più, secondo il modello"], ["FiScissors", "Quando è piena", "Le parti più vecchie possono essere escluse o riassunte"], ["FiTarget", "Il contesto giusto conta più della quantità", "Informazioni nel mezzo di testi lunghi possono essere trascurate"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.25 + i * 1.22;
      await iconCircle(s, 6.0, y, 0.5, k[i][0]);
      txt(s, k[i][1], { x: 6.65, y: y - 0.03, w: 2.85, h: 0.55, fontSize: 13, bold: true, color: C.text1 });
      txt(s, k[i][2], { x: 6.65, y: y + 0.5, w: 2.85, h: 0.6, fontSize: 11, color: C.text2 });
    }
  }
  {
    const s = content("La cronologia conversazionale", "Ecco un aspetto che sorprende molti: il modello non ricorda la conversazione. Ogni volta che inviamo un messaggio, il modello parte da zero. Come fa allora a 'ricordare' quello che ci siamo detti? È l'applicazione che, a ogni turno, rimanda al modello l'intera cronologia della conversazione insieme al nuovo messaggio. Il modello rilegge tutto e risponde. Lo schema in slide lo mostra: al primo turno il modello riceve istruzioni e prima domanda; al secondo, istruzioni, prima domanda, prima risposta e seconda domanda; e così via. Il contesto cresce a ogni turno. Questo ha tre conseguenze pratiche. Primo: in una conversazione molto lunga il contesto può avvicinarsi al limite della finestra, e le informazioni iniziali possono essere trascurate, riassunte o escluse. Secondo: avviando una nuova conversazione il modello non sa nulla di quella precedente, salvo funzioni di memoria specifiche dell'applicazione. Terzo: un errore o un'impostazione sbagliata all'inizio della conversazione continua a influenzare le risposte successive, perché resta nel contesto; a volte ricominciare una conversazione pulita è la soluzione migliore.");
    const turns = [["Turno 1", [["Istruzioni", 1.2, C.background2], ["Domanda 1", 1.1, C.accent6]]], ["Turno 2", [["Istruzioni", 1.2, C.background2], ["Domanda 1", 1.1, C.background2], ["Risposta 1", 1.5, C.background2], ["Domanda 2", 1.1, C.accent6]]], ["Turno 3", [["Istruzioni", 1.2, C.background2], ["Domanda 1", 1.1, C.background2], ["Risposta 1", 1.5, C.background2], ["Domanda 2", 1.1, C.background2], ["Risposta 2", 1.5, C.background2], ["Domanda 3", 1.1, C.accent6]]]];
    turns.forEach((t, i) => {
      const y = 1.35 + i * 0.85;
      txt(s, t[0], { x: 0.5, y, w: 0.9, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      let x = 1.4;
      t[1].forEach(seg => { chip(s, x, y, seg[1] - 0.05, 0.55, seg[0], { fill: seg[2], fontSize: 11, bold: seg[2] === C.accent6 }); x += seg[1]; });
    });
    s.addShape(pres.shapes.LINE, { x: 9.3, y: 1.2, w: 0, h: 2.65, line: { color: C.accent5, width: 2, dashType: "dash" }, objectName: "limite" });
    txt(s, "Limite", { x: 8.6, y: 3.85, w: 0.9, h: 0.25, fontSize: 10, bold: true, color: C.accent5, align: "right" });
    const k = [["Conversazioni lunghe", "Le parti iniziali possono essere trascurate o escluse"], ["Nuova conversazione", "Il modello non sa nulla della precedente"], ["Errori iniziali", "Restano nel contesto: talvolta conviene ricominciare"]];
    k.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 4.15, 2.86, 0.85, C.background2, e[0]);
      txt(s, e[0], { x: x + 0.15, y: 4.2, w: 2.6, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.15, y: 4.5, w: 2.6, h: 0.45, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Contesto temporaneo e memoria persistente", "Distinguiamo due modi in cui un sistema può 'tenere a mente' le informazioni. Il contesto temporaneo è tutto ciò che si trova nella finestra di contesto durante una conversazione: vale solo per quella conversazione e scompare quando ne iniziamo una nuova. È il meccanismo di base, sempre presente. La memoria persistente è una funzione che alcune applicazioni offrono: il sistema salva certe informazioni, come preferenze, dati sul nostro ruolo o progetti in corso, e le reinserisce automaticamente nel contesto delle conversazioni future. È importante capire che anche la memoria persistente non modifica il modello: è l'applicazione che archivia le informazioni e le ripresenta al modello come parte del contesto. Le funzioni di memoria variano molto tra i prodotti: alcune sono automatiche, altre si attivano su richiesta, quasi sempre l'utente può vederle, modificarle o disattivarle. Dal punto di vista aziendale questo ha implicazioni rilevanti: è bene sapere che cosa viene memorizzato, dove e per quanto tempo, soprattutto quando si lavora con informazioni riservate. Questi aspetti sono ripresi nei Temi 14 e 17, per la protezione dei dati, e nel Tema 4, per il confronto tra strumenti.");
    table(s, [["", "Contesto temporaneo", "Memoria persistente"], ["Che cos'è", "Ciò che è nella finestra di contesto", "Informazioni salvate dall'applicazione"], ["Durata", "Una conversazione", "Tra più conversazioni"], ["Chi la gestisce", "Meccanismo di base del sistema", "Funzione specifica di alcune applicazioni"], ["Esempio", "Il documento allegato a questa chat", "\"Lavoro nell'ufficio acquisti\" ricordato in futuro"], ["Modifica il modello?", "No", "No: viene reinserita nel contesto"]], { colW: [2.0, 3.5, 3.5], rowH: 0.55, accentCol: 2 });
    txt(s, "In azienda: sapere che cosa viene memorizzato, dove e per quanto tempo.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Il modello e l'applicazione", "Ultima distinzione del sottotema, molto importante: il modello e l'applicazione che lo integra non sono la stessa cosa. Il modello è il motore: il sistema addestrato che elabora token e genera risposte. L'applicazione, o prodotto, è tutto ciò che sta intorno: l'interfaccia con cui interagiamo, le istruzioni di sistema, le funzioni di ricerca sul web, la possibilità di caricare file, i collegamenti ad altri strumenti e servizi aziendali, la memoria, i filtri di sicurezza, le regole su come vengono trattati i dati. Un paragone utile è quello dell'automobile: il motore è fondamentale, ma l'esperienza di guida dipende anche dal resto della vettura. Per questo lo stesso modello può comportarsi in modo diverso in prodotti diversi, e due prodotti con modelli diversi possono offrire funzioni simili. Alcuni comportamenti che attribuiamo 'all'AI' sono in realtà dovuti all'applicazione: per esempio la capacità di citare fonti aggiornate dipende dalla presenza di una funzione di ricerca, non dal modello in sé. Quando valutiamo uno strumento, quindi, conviene chiedersi sia quale modello usa sia quali componenti offre. Il confronto tra prodotti e piattaforme è oggetto del Tema 4.");
    const comps = [["FiSettings", "Istruzioni di sistema"], ["FiGlobe", "Ricerca sul web"], ["FiPaperclip", "Caricamento di file"], ["FiLink", "Collegamenti a strumenti"], ["FiSave", "Memoria"], ["FiShield", "Filtri e regole sui dati"]];
    shapeBox(s, 0.5, 1.2, 6.0, 3.75, C.background2, "applicazione");
    txt(s, "Applicazione", { x: 0.7, y: 1.3, w: 5.6, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    shapeBox(s, 2.55, 2.45, 1.9, 1.3, C.accent1, "modello centro");
    txt(s, "Modello", { x: 2.55, y: 2.45, w: 1.9, h: 1.3, fontSize: 17, bold: true, color: C.background1, align: "center", valign: "middle" });
    for (let i = 0; i < 6; i++) {
      const left = i < 3, row = i % 3;
      const x = left ? 0.7 : 4.65, y = 1.8 + row * 0.95;
      await iconCircle(s, x, y + 0.1, 0.42, comps[i][0]);
      txt(s, comps[i][1], { x: x + 0.5, y, w: 1.35, h: 0.62, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    }
    txt(s, "Più interfaccia, ovviamente", { x: 0.7, y: 4.6, w: 5.6, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
    await card(s, 6.8, 1.2, 2.7, 1.75, { head: "Lo stesso modello", headSize: 14, bodySize: 12, body: "può comportarsi in modo diverso in prodotti diversi." });
    await card(s, 6.8, 3.15, 2.7, 1.8, { head: "Fonti aggiornate", headSize: 14, bodySize: 12, fill: C.accent6, body: "dipendono da una funzione di ricerca dell'applicazione, non dal modello in sé." });
  }
  keySlide("Il risultato dipende anche dalle informazioni rese disponibili durante l'interazione; il funzionamento del modello e quello del prodotto che lo utilizza non coincidono sempre.", "Sottotema 2.5  ·  Come funziona un'interazione con l'AI", "Concetto chiave. Riassumiamo: il modello riceve molto più del nostro messaggio; lavora entro una finestra di contesto limitata; non ricorda nulla tra un turno e l'altro, ed è l'applicazione a rimandargli la cronologia; la memoria persistente è una funzione dell'applicazione e non modifica il modello; e molte caratteristiche che attribuiamo all'AI dipendono in realtà dal prodotto che la integra. Domanda di verifica: perché la stessa domanda posta in due assistenti diversi, basati sullo stesso modello, può ricevere risposte diverse? Possibili risposte: istruzioni di sistema diverse, funzioni di ricerca diverse, documenti o memoria diversi, oltre alla normale variabilità che vedremo nel sottotema 2.7.");

  // =====================================================================
  section("2.6 Conoscenza e fonti");
  divider("2.6", "Conoscenza e fonti informative", "Fornire un documento o collegare una fonte non significa necessariamente riaddestrare il modello", "Questo sottotema risponde a una domanda fondamentale per l'uso professionale dell'AI: da dove provengono le informazioni contenute in una risposta? Distingueremo le informazioni apprese durante l'addestramento, quelle fornite durante l'interazione e quelle recuperate da fonti e strumenti esterni. Vedremo i limiti temporali della conoscenza dei modelli, il concetto di grounding e, a livello introduttivo, la Retrieval-Augmented Generation, o RAG. Infine metteremo a confronto le diverse modalità per adattare un sistema AI a un contesto specifico. Non insegneremo a costruire una soluzione RAG: ci interessa capire il concetto.");
  {
    const s = content("Tre fonti di informazione", "Le informazioni che un sistema AI usa per rispondere possono avere tre origini. La prima è l'addestramento: tutto ciò che il modello ha appreso dagli enormi corpus di testo, incorporato nei parametri. È una conoscenza ampia, ma generale, ferma a una certa data e non verificabile direttamente: il modello non sa indicare con certezza da quale testo abbia appreso una certa informazione. La seconda è l'interazione: ciò che forniamo noi durante la conversazione, come istruzioni, testi incollati, documenti allegati. È specifica e aggiornata quanto lo è il materiale che forniamo, e resta nel contesto temporaneo. La terza sono le fonti e gli strumenti esterni: ricerche sul web, basi documentali aziendali, database, altri software collegati, interrogati dall'applicazione al momento della richiesta. Permettono di accedere a informazioni aggiornate o riservate che il modello non ha mai visto in addestramento. In una stessa risposta possono convivere tutte e tre le fonti: per esempio il modello usa la conoscenza generale per capire la domanda e formulare la risposta, ma prende i dati specifici da un documento allegato o da una ricerca. Saper riconoscere da quale fonte proviene un'informazione è essenziale per valutarne l'affidabilità.");
    const c = [["FiDatabase", "Addestramento", "Appresa dai testi di addestramento e incorporata nei parametri", ["Ampia e generale", "Ferma a una certa data", "Non verificabile direttamente"]], ["FiPaperclip", "Interazione", "Fornita da noi durante la conversazione", ["Istruzioni, testi, documenti", "Specifica e controllabile", "Vale nel contesto temporaneo"]], ["FiGlobe", "Fonti esterne", "Recuperata dall'applicazione al momento della richiesta", ["Web, basi documentali, database", "Aggiornata o riservata", "Dipende dalla qualità della fonte"]]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.75, { icon: c[i][0], head: c[i][1], headSize: 16, bodySize: 13, fill: i === 0 ? C.background2 : (i === 1 ? C.accent6 : C.background2),
        body: [{ text: c[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(c[i][3], { space: 3 })) });
    }
  }
  {
    const s = content("Conoscenza incorporata e recupero di informazioni", "Un'analogia efficace è quella dell'esame. La conoscenza incorporata nel modello somiglia a un esame a libro chiuso: lo studente risponde basandosi su ciò che ricorda, che può essere molto, ma è impreciso sui dettagli, non è aggiornato su ciò che è successo dopo lo studio e, quando non ricorda bene, rischia di ricostruire una risposta plausibile ma sbagliata. Il recupero di informazioni somiglia invece a un esame a libro aperto: lo studente può consultare i testi pertinenti e basare la risposta su di essi, con dettagli precisi e la possibilità di indicare la fonte. Nella pratica, quando chiediamo a un assistente un dato preciso, come il valore di un indicatore, un riferimento normativo o una citazione, e il sistema risponde solo dalla conoscenza incorporata, il rischio di imprecisione è più alto. Quando invece la risposta si basa su documenti forniti o recuperati, è più facile che sia precisa e verificabile, anche se non è garantito: il modello può comunque interpretare male un documento o recuperare quello sbagliato. Le cause degli errori, comprese le cosiddette allucinazioni, sono approfondite nel Tema 3.");
    await card(s, 0.5, 1.2, 4.35, 3.0, { icon: "FiBook", head: "Libro chiuso: conoscenza incorporata", headSize: 15, bodySize: 13,
      body: bullets(["Risponde da ciò che ha appreso", "Ampia, ma imprecisa sui dettagli", "Non aggiornata dopo l'addestramento", "Può ricostruire risposte plausibili ma errate"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 3.0, { icon: "FiBookOpen", head: "Libro aperto: recupero di informazioni", headSize: 15, bodySize: 13, fill: C.accent6,
      body: bullets(["Consulta documenti pertinenti", "Dettagli più precisi", "Fonti indicabili e verificabili", "Non infallibile: può leggere male o recuperare il testo sbagliato"], { space: 3 }) });
    shapeBox(s, 0.5, 4.35, 9.0, 0.6, C.text1, "dati precisi");
    txt(s, "Per dati precisi (numeri, norme, citazioni) conviene basarsi su fonti fornite o recuperate.", { x: 0.7, y: 4.35, w: 8.6, h: 0.6, fontSize: 14, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Aggiornamento dei dati e limiti temporali", "Ogni modello ha una data limite della conoscenza, chiamata in inglese knowledge cutoff: il momento fino al quale arrivano i dati di addestramento. Di ciò che è accaduto dopo, il modello non sa nulla, a meno che l'informazione non gli venga fornita nel contesto o recuperata con una ricerca. Inoltre, tra la data limite e il momento in cui il modello viene messo a disposizione passano spesso diversi mesi, e il modello può poi restare in uso per mesi o anni. Il risultato è che il divario tra ciò che il modello sa e la realtà attuale tende a crescere nel tempo. Esempi tipici di informazioni soggette a questo limite: normative modificate di recente, prezzi e listini, organigrammi, versioni di software, notizie di attualità, risultati sportivi, cariche pubbliche. Un aspetto delicato è che il modello non sempre segnala di non essere aggiornato: può rispondere con sicurezza fornendo un'informazione che era corretta in passato ma non lo è più. Indicazioni pratiche: per tutto ciò che può essere cambiato di recente, usare strumenti con ricerca abilitata o fornire documenti aggiornati, e verificare le informazioni sensibili al tempo. Molti fornitori indicano pubblicamente la data limite dei propri modelli.");
    s.addShape(pres.shapes.RECTANGLE, { x: 0.5, y: 1.75, w: 5.2, h: 0.7, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "periodo addestramento" });
    txt(s, "Dati di addestramento", { x: 0.6, y: 1.75, w: 5.0, h: 0.7, fontSize: 15, bold: true, color: C.background1, valign: "middle" });
    s.addShape(pres.shapes.RECTANGLE, { x: 5.7, y: 1.75, w: 3.8, h: 0.7, fill: { color: C.background2 }, line: { color: C.accent3, width: 1, dashType: "dash" }, objectName: "periodo sconosciuto" });
    txt(s, "Eventi successivi: sconosciuti al modello", { x: 5.8, y: 1.75, w: 3.6, h: 0.7, fontSize: 13, bold: true, color: C.text2, valign: "middle" });
    s.addShape(pres.shapes.LINE, { x: 5.7, y: 1.45, w: 0, h: 1.3, line: { color: C.accent5, width: 2.5 }, objectName: "cutoff" });
    txt(s, "Data limite (cutoff)", { x: 4.7, y: 2.8, w: 2.0, h: 0.3, fontSize: 12, bold: true, color: C.accent5, align: "center" });
    txt(s, "Oggi", { x: 8.8, y: 2.8, w: 0.7, h: 0.3, fontSize: 12, bold: true, color: C.text1, align: "right" });
    const ex = ["Normative recenti", "Prezzi e listini", "Organigrammi", "Versioni software", "Notizie e attualità"];
    txt(s, "Informazioni a rischio di essere superate", { x: 0.5, y: 3.3, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ex.forEach((e, i) => chip(s, 0.5 + i * 1.8, 3.7, 1.68, 0.5, e, { fill: C.background1, line: { color: C.accent3, width: 1 }, fontSize: 12 }));
    txt(s, "Il modello non sempre segnala di non essere aggiornato: usare la ricerca o documenti recenti e verificare.", { x: 0.5, y: 4.45, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Grounding: ancorare le risposte alle fonti", "Grounding, che possiamo tradurre come ancoraggio, indica la pratica di basare le risposte di un sistema AI su fonti specifiche e verificabili, invece che solo sulla conoscenza generale incorporata nel modello. Un sistema 'ancorato' riceve nel contesto i documenti o i dati pertinenti, viene istruito a rispondere sulla base di quelli e, idealmente, indica da quale fonte proviene ciascuna informazione, permettendo all'utente di verificarla. Il grounding porta tre benefici principali: risposte più precise e pertinenti al nostro contesto, aggiornamento, perché le fonti possono essere più recenti della data limite del modello, e verificabilità, grazie ai riferimenti alle fonti. Esempi comuni sono l'assistente che risponde citando i risultati di una ricerca web, oppure quello che risponde alle domande dei dipendenti sulla base delle procedure interne, indicando il documento di riferimento. Attenzione però: il grounding riduce gli errori ma non li elimina. Il sistema può interpretare male una fonte, combinare informazioni in modo scorretto, o la fonte stessa può essere sbagliata o non aggiornata. Per questo la possibilità di controllare le fonti citate è preziosa: va usata.");
    const docs = ["Procedura acquisti", "Listino 2026", "Contratto quadro"];
    for (let i = 0; i < docs.length; i++) { const d = docs[i];
      const y = 1.25 + i * 0.9;
      shapeBox(s, 0.5, y, 2.4, 0.72, C.background2, d);
      await iconCircle(s, 0.65, y + 0.13, 0.46, "FiFileText");
      txt(s, d, { x: 1.2, y, w: 1.65, h: 0.72, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
      s.addShape(pres.shapes.LINE, { x: 2.9, y: Math.min(y + 0.36, 2.3), w: 0.9, h: Math.max(Math.abs(2.3 - (y + 0.36)), 0.001), flipV: y + 0.36 > 2.3, line: { color: C.accent1, width: 1.5 }, objectName: "collegamento fonte" });
    }
    shapeBox(s, 3.8, 1.8, 2.1, 1.0, C.accent1, "risposta ancorata");
    txt(s, "Risposta ancorata alle fonti", { x: 3.85, y: 1.8, w: 2.0, h: 1.0, fontSize: 13, bold: true, color: C.background1, align: "center", valign: "middle" });
    txt(s, "con riferimenti verificabili [1] [2] [3]", { x: 3.6, y: 2.85, w: 2.5, h: 0.4, fontSize: 11, italic: true, color: C.text2, align: "center" });
    const k = [["FiTarget", "Più precise e pertinenti"], ["FiClock", "Più aggiornate del modello"], ["FiCheckSquare", "Verificabili tramite le fonti"]];
    txt(s, "Benefici", { x: 6.3, y: 1.2, w: 3.2, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    for (let i = 0; i < 3; i++) {
      const y = 1.6 + i * 0.65;
      await iconCircle(s, 6.3, y, 0.45, k[i][0]);
      txt(s, k[i][1], { x: 6.9, y, w: 2.6, h: 0.45, fontSize: 13, color: C.text1, valign: "middle" });
    }
    shapeBox(s, 0.5, 4.05, 9.0, 0.9, C.text1, "limite grounding");
    await iconCircle(s, 0.7, 4.22, 0.56, "FiAlertTriangle", C.accent5);
    txt(s, "Riduce gli errori ma non li elimina: il sistema può leggere male una fonte, o la fonte può essere sbagliata. Controllare le fonti citate.", { x: 1.45, y: 4.05, w: 7.9, h: 0.9, fontSize: 13, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Introduzione alla Retrieval-Augmented Generation", "La Retrieval-Augmented Generation, abbreviata in RAG e traducibile come 'generazione aumentata dal recupero', è la tecnica più diffusa per realizzare il grounding su grandi raccolte di documenti. Il termine è stato introdotto nel 2020 da un gruppo di ricercatori di Facebook AI Research (oggi Meta), University College London e New York University, con primo autore Patrick Lewis. Il problema che risolve è questo: un'azienda può avere migliaia di documenti, troppi per inserirli tutti nella finestra di contesto a ogni domanda. Il funzionamento, a livello concettuale, avviene in quattro passaggi. Primo: l'utente pone una domanda. Secondo, il recupero: il sistema cerca nella base documentale, preparata in precedenza, i passaggi più pertinenti alla domanda, spesso usando la ricerca semantica basata sugli embedding che abbiamo visto, che trova i testi simili per significato e non solo per parole uguali. Terzo, l'aumento: i passaggi trovati vengono inseriti nel contesto insieme alla domanda. Quarto, la generazione: il modello formula la risposta sulla base di quei passaggi, idealmente citandoli. Il punto chiave: il modello non viene riaddestrato. I documenti restano fuori dal modello, possono essere aggiornati in qualsiasi momento, e l'accesso può essere limitato in base ai permessi degli utenti. La qualità del risultato dipende molto dalla qualità dei documenti e del recupero. Le condizioni per usare la RAG sui documenti aziendali sono trattate nel Tema 14.");
    const st = [["FiHelpCircle", "Domanda", "L'utente chiede"], ["FiSearch", "Recupero", "Si cercano i passaggi pertinenti"], ["FiPlusSquare", "Aumento", "I passaggi entrano nel contesto"], ["FiMessageSquare", "Generazione", "Il modello risponde citando le fonti"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      shapeBox(s, x, 1.25, 2.05, 1.95, i === 3 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.4, 0.6, st[i][0]);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.1, y: 2.08, w: 1.85, h: 0.38, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.48, w: 1.75, h: 0.65, fontSize: 12, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.07, 2.08, 0.24);
    }
    shapeBox(s, 2.83, 3.4, 2.05, 0.75, C.text1, "base documentale");
    txt(s, "Base documentale", { x: 2.85, y: 3.4, w: 2.0, h: 0.75, fontSize: 13, bold: true, color: C.background1, align: "center", valign: "middle" });
    s.addShape(pres.shapes.UP_ARROW, { x: 3.7, y: 3.2, w: 0.35, h: 0.2, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia su" });
    const k = ["Il modello non viene riaddestrato", "I documenti si aggiornano in qualsiasi momento", "L'accesso può seguire i permessi degli utenti"];
    k.forEach((e, i) => { chip(s, 0.5 + i * 3.07, 4.35, 2.86, 0.6, e, { fill: C.accent6, fontSize: 12 }); });
  }
  {
    const s = content("Adattare un sistema AI a un contesto specifico", "Questa integrazione del sottotema mette a confronto quattro modi per adattare un sistema AI alle esigenze di un'azienda o di un'attività. Sono spesso confusi, ma funzionano in modo molto diverso. Le istruzioni: indicazioni su ruolo, tono, formato, regole da seguire, fornite nel prompt o nelle istruzioni di sistema. Sono il modo più semplice e immediato, non modificano il modello e funzionano bene per orientarne il comportamento. I documenti nel contesto: allegare o incollare i materiali pertinenti alla conversazione. Ideale per lavorare su contenuti specifici e limitati, nei limiti della finestra di contesto. Il recupero da basi informative, cioè la RAG: adatto quando i documenti sono molti, cambiano spesso o devono essere accessibili a molte persone con permessi diversi. Neppure questo modifica il modello. Il fine-tuning, o affinamento: un addestramento aggiuntivo del modello su esempi specifici, che modifica effettivamente una parte dei parametri. È utile soprattutto per insegnare uno stile, un formato o un comportamento ricorrente, ma richiede dati di qualità, competenze e costi, ed è meno adatto per aggiungere conoscenze che cambiano spesso, perché ogni aggiornamento richiederebbe un nuovo addestramento. Nella pratica, la maggior parte delle esigenze aziendali si risolve con le prime tre modalità, spesso combinate.");
    table(s, [["Modalità", "Che cosa fa", "Modifica il modello?", "Quando è utile"], ["Istruzioni", "Indica ruolo, tono, formato, regole", "No", "Orientare il comportamento"], ["Documenti nel contesto", "Fornisce i materiali nella conversazione", "No", "Contenuti specifici e limitati"], ["Recupero da basi informative (RAG)", "Cerca i passaggi pertinenti in molti documenti", "No", "Molti documenti, aggiornati spesso, con permessi"], ["Fine-tuning", "Addestramento aggiuntivo su esempi specifici", "Sì, in parte", "Stile, formato, comportamenti ricorrenti"]], { colW: [2.2, 2.6, 1.6, 2.6], rowH: 0.62, accentCol: 2, blankCorner: false });
    txt(s, "La maggior parte delle esigenze aziendali si risolve con le prime tre modalità, spesso combinate.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Tre equivoci frequenti", "Chiudiamo il sottotema con tre equivoci molto diffusi, che conviene smontare esplicitamente. Primo equivoco: 'se carico un documento, il modello lo impara'. In realtà il documento entra nel contesto temporaneo della conversazione: il modello lo legge e lo usa per rispondere, ma i suoi parametri non cambiano. In una nuova conversazione il documento non sarà più disponibile, salvo funzioni specifiche dell'applicazione, come progetti o memorie. Secondo equivoco: 'se collego l'AI ai documenti aziendali, il modello viene addestrato sui nostri dati'. Con la RAG il modello consulta i documenti al momento della domanda, ma non viene riaddestrato. Questo non significa che la questione dei dati sia irrilevante: le condizioni contrattuali del servizio stabiliscono se e come i dati possono essere usati dal fornitore, ed è un aspetto da verificare sempre. Terzo equivoco: 'il modello sa tutto ciò che è su internet ed è sempre aggiornato'. La conoscenza incorporata è ferma alla data limite e non è un archivio completo; l'accesso a informazioni aggiornate dipende dalla presenza di strumenti di ricerca. Domanda per il gruppo: avevate qualcuno di questi dubbi?");
    const m = [["Se carico un documento, il modello lo impara", "Il documento entra nel contesto temporaneo: il modello lo usa, ma i parametri non cambiano"], ["Se collego i documenti aziendali, il modello si addestra sui nostri dati", "Con la RAG il modello consulta i documenti, non si riaddestra. L'uso dei dati da parte del fornitore dipende dalle condizioni contrattuali"], ["Il modello sa tutto ciò che è su internet ed è aggiornato", "La conoscenza è ferma alla data limite; l'aggiornamento dipende dagli strumenti di ricerca"]];
    m.forEach((e, i) => {
      const y = 1.2 + i * 1.25;
      shapeBox(s, 0.5, y, 4.0, 1.1, C.background2, "equivoco " + (i + 1));
      txt(s, [{ text: "Equivoco: ", options: { bold: true, color: C.accent5 } }, { text: e[0], options: { color: C.text1 } }], { x: 0.7, y, w: 3.65, h: 1.1, fontSize: 13, valign: "middle" });
      arrow(s, 4.6, y + 0.39, 0.35, C.accent1);
      shapeBox(s, 5.05, y, 4.45, 1.1, C.accent6, "realtà " + (i + 1));
      txt(s, e[1], { x: 5.25, y, w: 4.1, h: 1.1, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  keySlide("Fornire un documento o collegare una fonte a un sistema AI non significa necessariamente riaddestrare il modello.", "Sottotema 2.6  ·  Conoscenza e fonti informative", "Concetto chiave. Le informazioni di una risposta possono provenire dall'addestramento, dall'interazione o da fonti esterne; la conoscenza incorporata è generale e datata, quella recuperata è più precisa e verificabile; il grounding e la RAG permettono di ancorare le risposte ai documenti senza riaddestrare il modello; e il fine-tuning è solo una delle modalità di adattamento, spesso non la più adatta. Domanda di verifica: un collega dice 'ho caricato il nostro regolamento interno nell'assistente, adesso lo conosce'. Che cosa gli rispondereste? Risposta: lo conosce per quella conversazione, perché il documento è nel contesto; il modello non è stato riaddestrato.");

  // =====================================================================
  section("2.7 Variabilità dei risultati");
  divider("2.7", "Variabilità dei risultati", "Una stessa richiesta può produrre risposte differenti: la variabilità è distinta dalla correttezza", "Ultimo sottotema. Chiunque abbia usato un assistente AI si è accorto che, ponendo due volte la stessa domanda, si ottengono risposte diverse. Per chi è abituato al software tradizionale, questo può sembrare un difetto o un malfunzionamento. In realtà è una conseguenza diretta del modo in cui i modelli generano il testo. In questo sottotema vediamo perché succede, quali fattori influenzano la variabilità, come si può ridurre quando serve e, soprattutto, perché variabilità e correttezza sono due questioni distinte.");
  {
    const s = content("Stessa richiesta, risposte diverse", "Ecco un esempio concreto. La stessa richiesta, 'Proponi un titolo per la newsletter che annuncia il nuovo orario estivo degli uffici', inviata tre volte allo stesso assistente, può produrre tre risposte diverse, come quelle in slide. Sono tutte ragionevoli, con sfumature diverse di tono e formulazione. Questo è il comportamento normale di un modello generativo. Perché accade? Ricordiamo come viene generata una risposta: a ogni passaggio il modello calcola una distribuzione di probabilità sui possibili token successivi e poi ne sceglie uno. Se scegliesse sempre il più probabile, le risposte sarebbero sempre uguali, ma tenderebbero anche a essere ripetitive e poco naturali. Per questo, di norma, la scelta avviene tramite campionamento: il token viene estratto in proporzione alla sua probabilità, per cui di solito vince un token molto probabile, ma talvolta ne viene scelto un altro. Basta una scelta diversa nelle prime parole perché tutta la risposta prenda una strada diversa, dato che ogni token condiziona i successivi. Suggerimento: se possibile, mostrare dal vivo l'esempio rigenerando più volte la stessa risposta in un assistente.");
    shapeBox(s, 0.5, 1.2, 9.0, 0.75, C.text1, "richiesta");
    txt(s, [{ text: "Richiesta: ", options: { bold: true, color: C.accent1 } }, { text: "Proponi un titolo per la newsletter che annuncia il nuovo orario estivo degli uffici", options: { color: C.background1 } }], { x: 0.7, y: 1.2, w: 8.6, h: 0.75, fontSize: 14, valign: "middle" });
    const out = ["Estate in ufficio: ecco i nuovi orari", "Cambiano gli orari: tutto quello che serve sapere per l'estate", "Orario estivo al via: organizziamoci al meglio"];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.25, 2.86, 1.7, C.background2, "risposta " + (i + 1));
      txt(s, "Tentativo " + (i + 1), { x: x + 0.2, y: 2.38, w: 2.4, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, "\"" + out[i] + "\"", { x: x + 0.2, y: 2.72, w: 2.5, h: 1.1, fontSize: 14, italic: true, color: C.text1 });
    }
    shapeBox(s, 0.5, 4.15, 9.0, 0.8, C.accent6, "spiegazione");
    await iconCircle(s, 0.7, 4.27, 0.56, "FiShuffle");
    txt(s, "A ogni passaggio il token viene estratto in proporzione alla sua probabilità: una scelta diversa all'inizio cambia tutta la risposta.", { x: 1.45, y: 4.15, w: 7.9, h: 0.8, fontSize: 13, color: C.text1, valign: "middle" });
  }
  {
    const s = content("Che cosa influenza la variabilità", "Il campionamento è la causa principale della variabilità, ma non l'unica. Possiamo individuare almeno cinque fattori. Primo, il campionamento stesso, che abbiamo appena visto. Secondo, le istruzioni: una richiesta vaga lascia al modello molte strade possibili, mentre una richiesta precisa, con indicazioni su formato, tono, lunghezza ed eventuali esempi, restringe le possibilità e rende le risposte più simili tra loro. Terzo, il contesto: la cronologia della conversazione, i documenti allegati, la memoria e i risultati di ricerca cambiano da una sessione all'altra, e con essi le risposte. Quarto, i parametri di generazione, come la temperatura, che vedremo nella prossima slide. Quinto, la versione del modello e dell'applicazione: i fornitori aggiornano periodicamente modelli e istruzioni di sistema, per cui la stessa richiesta può dare risultati diversi nel corso dei mesi. Questo è un punto importante per chi costruisce procedure di lavoro basate sull'AI: un risultato ottenuto oggi non è garantito per sempre, e conviene riverificare periodicamente.");
    const f = [["FiShuffle", "Campionamento", "La scelta dei token avviene con una casualità controllata"], ["FiEdit3", "Istruzioni", "Richieste vaghe lasciano più strade possibili di quelle precise"], ["FiLayers", "Contesto", "Cronologia, documenti, memoria e ricerche cambiano tra sessioni"], ["FiThermometer", "Parametri di generazione", "Per esempio la temperatura"], ["FiRefreshCw", "Versioni", "Modelli e applicazioni vengono aggiornati nel tempo"]];
    for (let i = 0; i < 5; i++) {
      const col = i % 3, row = Math.floor(i / 3);
      const x = row === 0 ? 0.5 + col * 3.07 : 2.035 + col * 3.07, y = 1.2 + row * 1.9;
      await card(s, x, y, 2.86, 1.75, { inline: true, icon: f[i][0], head: f[i][1], headSize: 14, bodySize: 12, body: f[i][2], fill: i === 0 ? C.accent6 : C.background2 });
    }
  }
  {
    const s = content("I parametri di generazione: la temperatura", "Il parametro di generazione più noto è la temperatura, che regola quanto il campionamento è 'audace'. Con una temperatura bassa, la distribuzione delle probabilità si concentra sui token più probabili: le risposte diventano più prevedibili, conservative e simili tra loro. Con una temperatura alta, la distribuzione si appiattisce e anche i token meno probabili hanno più possibilità di essere scelti: le risposte diventano più varie e creative, ma anche più esposte a scelte poco appropriate. I due grafici mostrano, con valori illustrativi, la stessa scelta tra cinque parole con temperatura bassa e alta. Esistono anche altri parametri simili, che limitano la scelta ai token più probabili. Nella pratica, chi usa un assistente tramite interfaccia conversazionale spesso non vede né controlla questi parametri, che sono impostati dal fornitore; sono invece regolabili da chi usa i modelli tramite API, per esempio quando si integra l'AI in un'applicazione aziendale. Una indicazione generale: valori bassi sono adatti a compiti in cui serve coerenza, come estrazione di dati o classificazione; valori più alti a compiti creativi come la generazione di idee. Attenzione: anche con temperatura minima, i risultati possono non essere perfettamente identici in ogni caso, per ragioni tecniche legate all'esecuzione dei calcoli.");
    const lab = ["sereno", "nuvoloso", "azzurro", "coperto", "limpido"];
    chartBarH(s, lab, [0.78, 0.13, 0.06, 0.02, 0.01], { x: 0.5, y: 1.2, w: 4.35, h: 2.7, title: "Temperatura bassa", max: 1 });
    chartBarH(s, lab, [0.30, 0.25, 0.20, 0.14, 0.11], { x: 5.15, y: 1.2, w: 4.35, h: 2.7, title: "Temperatura alta", max: 1, color: HEX.a4 });
    chip(s, 0.5, 4.05, 4.35, 0.5, "Più coerenza: estrazione dati, classificazione", { fill: C.accent6, fontSize: 12 });
    chip(s, 5.15, 4.05, 4.35, 0.5, "Più varietà: idee, testi creativi", { fill: C.background2, fontSize: 12 });
    txt(s, "Valori illustrativi. Negli assistenti la temperatura è spesso impostata dal fornitore; via API è regolabile.", { x: 0.5, y: 4.7, w: 9, h: 0.35, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Comportamento deterministico e probabilistico", "Riprendiamo la distinzione introdotta nel Tema 1, ora che ne conosciamo il meccanismo. Il software deterministico produce sempre lo stesso output a parità di input: è ciò che ci aspettiamo da una calcolatrice, da un gestionale, da una formula in un foglio di calcolo. Un modello generativo è invece probabilistico: produce output plausibili estratti da una distribuzione di probabilità, e quindi può variare. Nessuno dei due comportamenti è migliore in assoluto: sono adatti a esigenze diverse. La variabilità è una risorsa quando cerchiamo alternative, idee, formulazioni diverse, o quando vogliamo rigenerare una risposta che non ci soddisfa. È invece un problema quando serve coerenza: estrarre gli stessi campi da centinaia di fatture, classificare richieste secondo criteri uniformi, produrre testi che devono rispettare formule fisse. In questi casi bisogna ridurre la variabilità, o combinare l'AI con componenti deterministici, per esempio facendo calcolare i totali a un software tradizionale invece che al modello. Il messaggio pratico: conoscere la natura probabilistica dei modelli aiuta a decidere dove usarli e con quali accorgimenti.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiStar", head: "Una risorsa quando cerchiamo", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Alternative e idee diverse", "Formulazioni e toni differenti", "Una nuova versione di una risposta insoddisfacente", "Spunti creativi e brainstorming"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiAlertTriangle", head: "Un problema quando serve coerenza", headSize: 16, bodySize: 13, iconBg: C.accent5,
      body: bullets(["Estrarre gli stessi campi da molti documenti", "Classificare con criteri uniformi", "Rispettare formule e testi fissi", "Calcoli: meglio affidarli a software deterministico"], { space: 4 }) });
  }
  {
    const s = content("Riproducibilità dei risultati", "Quando un risultato deve essere riproducibile, cioè ottenibile di nuovo in modo coerente, esistono diversi accorgimenti che riducono la variabilità. Formulare istruzioni precise: specificare formato, lunghezza, struttura, tono, criteri. Fornire esempi del risultato atteso: il modello tende a imitarli. Chiedere output strutturati, come tabelle o elenchi con campi fissi, invece di testo libero. Ridurre la temperatura, quando lo strumento lo consente. Salvare e riutilizzare i prompt che funzionano, invece di riscriverli ogni volta, e documentarli se fanno parte di un processo aziendale. Fornire sempre lo stesso contesto, per esempio gli stessi documenti di riferimento. Annotare la versione del modello o dello strumento usato e riverificare dopo gli aggiornamenti. Nessuno di questi accorgimenti garantisce una riproducibilità assoluta, che con i modelli generativi non è di norma ottenibile, ma insieme rendono i risultati molto più coerenti. Le tecniche operative di prompting sono approfondite nel Tema 6.");
    const k = [["FiEdit3", "Istruzioni precise", "Formato, lunghezza, struttura, criteri"], ["FiCopy", "Esempi del risultato atteso", "Il modello tende a imitarli"], ["FiGrid", "Output strutturati", "Tabelle o campi fissi invece di testo libero"], ["FiThermometer", "Temperatura bassa", "Quando lo strumento lo consente"], ["FiSave", "Prompt salvati e documentati", "Riutilizzare ciò che funziona"], ["FiTag", "Versioni annotate", "Riverificare dopo gli aggiornamenti"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.2 + row * 1.6;
      shapeBox(s, x, y, 2.86, 1.45, C.background2, k[i][1]);
      await iconCircle(s, x + 0.18, y + 0.2, 0.5, k[i][0]);
      txt(s, k[i][1], { x: x + 0.82, y: y + 0.15, w: 1.95, h: 0.6, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, k[i][2], { x: x + 0.18, y: y + 0.82, w: 2.5, h: 0.55, fontSize: 12, color: C.text2 });
    }
    txt(s, "Insieme rendono i risultati molto più coerenti, anche se una riproducibilità assoluta non è di norma ottenibile.", { x: 0.5, y: 4.5, w: 9, h: 0.45, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Variabilità non significa errore", "Questa slide chiarisce una distinzione su cui il documento di perimetro insiste: variabilità e correttezza sono due questioni separate. Lo schema incrocia le due dimensioni, e ogni quadrante ha un esempio fittizio in corsivo. In alto a sinistra, risposte che variano ma sono tutte corrette: tre titoli diversi per la stessa newsletter, come quelli visti poco fa nella slide 58, formulazioni diverse ugualmente valide. In alto a destra, risposte stabili e corrette: la situazione ideale per i compiti che richiedono coerenza, come assegnare sempre la stessa categoria allo stesso ticket di assistenza. In basso a destra, risposte stabili ma sbagliate: è il caso più insidioso, perché la ripetizione della stessa risposta può darci un falso senso di sicurezza. Un modello può ripetere con coerenza un'informazione errata, per esempio un prezzo di listino superato, indicato ogni volta allo stesso modo. In basso a sinistra, risposte che variano e sono sbagliate: chiedendo tre volte la stessa scadenza si ottengono tre date diverse. Qui la variabilità può essere un segnale utile, perché risposte molto diverse alla stessa domanda fattuale indicano spesso che il modello non ha un'informazione solida, e che serve verificare. Il messaggio: non dobbiamo considerare la variabilità come un errore, né la stabilità come una garanzia. La correttezza va valutata con altri strumenti, che sono l'oggetto del Tema 3.");
    const q = [["Varia ma corretta", "Formulazioni diverse, tutte valide", C.accent6, C.text1, "Es.: tre titoli diversi per la newsletter"], ["Stabile e corretta", "Ideale per i compiti che richiedono coerenza", C.accent1, C.background1, "Es.: la stessa categoria per lo stesso ticket"], ["Varia ed errata", "Risposte molto diverse a una domanda fattuale: segnale da verificare", C.background2, C.text1, "Es.: tre date diverse per la stessa scadenza"], ["Stabile ma errata", "Il caso più insidioso: la ripetizione dà un falso senso di sicurezza", C.text1, C.background1, "Es.: un prezzo superato, ripetuto ogni volta"]];
    txt(s, "La risposta varia", { x: 1.6, y: 1.15, w: 3.6, h: 0.3, fontSize: 12, bold: true, color: C.accent2, align: "center" });
    txt(s, "La risposta è stabile", { x: 5.4, y: 1.15, w: 3.6, h: 0.3, fontSize: 12, bold: true, color: C.accent2, align: "center" });
    txt(s, "Corretta", { x: 0.5, y: 1.5, w: 1.0, h: 1.55, fontSize: 12, bold: true, color: C.accent2, valign: "middle" });
    txt(s, "Errata", { x: 0.5, y: 3.2, w: 1.0, h: 1.55, fontSize: 12, bold: true, color: C.accent2, valign: "middle" });
    for (let i = 0; i < 4; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 1.6 + col * 3.8, y = 1.5 + row * 1.7;
      shapeBox(s, x, y, 3.6, 1.55, q[i][2], q[i][0]);
      txt(s, q[i][0], { x: x + 0.2, y: y + 0.15, w: 3.2, h: 0.4, fontSize: 16, bold: true, color: q[i][3] });
      txt(s, q[i][1], { x: x + 0.2, y: y + 0.52, w: 3.2, h: 0.52, fontSize: 12, color: q[i][3] });
      txt(s, q[i][4], { x: x + 0.2, y: y + 1.08, w: 3.2, h: 0.35, fontSize: 11, italic: true, color: q[i][3] });
    }
    txt(s, "La variabilità non è un errore; la stabilità non è una garanzia.", { x: 1.6, y: 4.85, w: 7.4, h: 0.3, fontSize: 12, italic: true, color: C.text1, align: "center" });
  }
  keySlide("Una stessa richiesta può produrre risposte differenti; la variabilità è distinta dalla questione della correttezza e dell'affidabilità.", "Sottotema 2.7  ·  Variabilità dei risultati", "Concetto chiave dell'ultimo sottotema. La variabilità deriva dalla natura probabilistica della generazione: a ogni passaggio il modello sceglie tra token possibili, con un grado di casualità regolato da parametri come la temperatura. Istruzioni, contesto e versioni influiscono ulteriormente. La variabilità può essere ridotta con accorgimenti pratici, ma non eliminata del tutto; è una risorsa per i compiti creativi e un aspetto da gestire per quelli che richiedono coerenza. Soprattutto, non va confusa con l'errore: risposte diverse possono essere tutte corrette, e risposte identiche possono essere tutte sbagliate. Domanda di verifica: se chiedo tre volte lo stesso dato e ottengo sempre lo stesso numero, posso considerarlo corretto? Risposta: no, la stabilità non garantisce la correttezza; va verificato su una fonte affidabile. Correttezza e affidabilità sono approfondite nel Tema 3.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida dell'inizio. Che cosa intendiamo per AI? Sistemi che deducono dagli input come generare output, con autonomia variabile; non un'intelligenza umana digitale. Come si distinguono AI, Machine Learning, Deep Learning e AI generativa? Rispondono a criteri diversi: l'AI è il campo, il ML apprende dai dati, il DL usa reti neurali profonde, la generativa produce contenuti. Che cos'è un modello e come viene addestrato? Un insieme di parametri regolati sugli esempi riducendo l'errore. Che cos'è un LLM? Un modello di Deep Learning che genera testo token per token da regolarità apprese e dal contesto. Che cosa accade quando inviamo un prompt? L'applicazione compone il contesto, il modello lo elabora in inferenza e genera la risposta. Da dove provengono le informazioni? Da addestramento, interazione e fonti esterne. Che differenza c'è tra addestramento, contesto, memoria, recupero e fine-tuning? Solo addestramento e fine-tuning modificano il modello; gli altri forniscono informazioni nel contesto. Perché le risposte variano? Per il campionamento probabilistico, e la variabilità non è un errore. Suggerimento: chiedere ai partecipanti di rispondere prima con parole proprie.");
    const qa = [["Che cos'è l'AI?", "Sistemi che deducono dagli input come generare output"], ["AI, ML, DL, generativa?", "Criteri diversi, categorie non esclusive"], ["Come si addestra un modello?", "Regolando i parametri sugli esempi"], ["Che cos'è un LLM?", "Genera testo token per token da regolarità e contesto"], ["Che cosa accade con un prompt?", "Contesto, inferenza, generazione"], ["Da dove arrivano le informazioni?", "Addestramento, interazione, fonti esterne"], ["Addestramento, contesto, RAG, fine-tuning?", "Solo addestramento e fine-tuning modificano il modello"], ["Perché le risposte variano?", "Generazione probabilistica: non è un errore"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.95;
      shapeBox(s, x, y, 4.4, 0.85, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.08, w: 0.4, h: 0.4, fontSize: 18, bold: true, color: C.accent1 });
      txt(s, e[0], { x: x + 0.55, y: y + 0.08, w: 3.75, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.42, w: 3.75, h: 0.38, fontSize: 12, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i sei risultati attesi del modulo. Il partecipante dovrebbe essere in grado di: distinguere le principali famiglie e capacità dei sistemi AI; descrivere a grandi linee come avvengono addestramento e inferenza; spiegare il funzionamento generale di un LLM e di una conversazione con esso; distinguere ciò che un modello ha appreso dalle informazioni fornite o recuperate durante l'uso; comprendere che il comportamento dipende dal modello, dall'applicazione e dal contesto; interpretare la variabilità degli output senza confonderla automaticamente con un errore. Se questi sei punti sono chiari, i partecipanti hanno gli strumenti concettuali per affrontare il Tema 3, dedicato all'affidabilità, e i temi pratici sull'uso dell'AI, dal Tema 5 al Tema 11.");
    const r = [["FiGrid", "Distinguere le principali famiglie e capacità dei sistemi AI"], ["FiSliders", "Descrivere a grandi linee addestramento e inferenza"], ["FiMessageSquare", "Spiegare il funzionamento di un LLM e di una conversazione"], ["FiDatabase", "Distinguere ciò che il modello ha appreso da ciò che riceve durante l'uso"], ["FiLayers", "Comprendere che il comportamento dipende da modello, applicazione e contesto"], ["FiShuffle", "Interpretare la variabilità senza confonderla con un errore"]];
    for (let i = 0; i < 6; i++) {
      const y = 1.15 + i * 0.64;
      shapeBox(s, 0.5, y, 9.0, 0.56, i % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      await iconCircle(s, 0.65, y + 0.07, 0.42, r[i][0]);
      txt(s, r[i][1], { x: 1.25, y, w: 8.1, h: 0.56, fontSize: 14, color: C.text1, valign: "middle" });
    }
  }
  {
    const s = content("Glossario essenziale (1 di 2)", "Questa e la slide successiva raccolgono i termini principali introdotti nel modulo, con una definizione sintetica. Possono essere distribuite ai partecipanti come materiale di riferimento. Suggerimento: usarle come ripasso veloce, chiedendo ai partecipanti di spiegare un termine con parole proprie prima di mostrare la definizione.");
    table(s, [["Termine", "Definizione sintetica"], ["Machine Learning", "Tecniche con cui un sistema apprende regolarità dai dati invece di seguire regole scritte"], ["Deep Learning", "Machine Learning basato su reti neurali artificiali con molti strati"], ["Modello", "Il risultato dell'addestramento: una struttura con parametri appresi, usata per elaborare nuovi input"], ["Parametri", "Valori numerici interni al modello, regolati durante l'addestramento"], ["Addestramento", "Fase in cui il modello apprende dagli esempi e i parametri vengono modificati"], ["Inferenza", "Uso del modello per elaborare un nuovo input; i parametri restano invariati"], ["LLM", "Modello di Deep Learning addestrato su enormi quantità di testo per elaborare e generare linguaggio"]], { colW: [2.2, 6.8], rowH: 0.47, accentCol: 0, blankCorner: false, fontSize: 12 });
  }
  {
    const s = content("Glossario essenziale (2 di 2)", "Seconda parte del glossario. Anche questi termini compaiono spesso nella documentazione dei prodotti e nelle notizie sull'AI: riconoscerli aiuta a leggerle con maggiore consapevolezza.");
    table(s, [["Termine", "Definizione sintetica"], ["Token", "Unità di testo elaborata dal modello: una parola, una parte di parola o un segno"], ["Transformer", "Architettura alla base degli LLM, fondata sul meccanismo di attenzione"], ["Prompt", "Il testo con cui formuliamo una richiesta al sistema"], ["Finestra di contesto", "Quantità massima di testo, in token, che il modello considera in una elaborazione"], ["Grounding", "Ancoraggio delle risposte a fonti specifiche e verificabili"], ["RAG", "Tecnica che recupera passaggi pertinenti da documenti e li inserisce nel contesto"], ["Fine-tuning", "Addestramento aggiuntivo di un modello su esempi specifici"], ["Temperatura", "Parametro che regola quanto è variabile la scelta dei token"]], { colW: [2.2, 6.8], rowH: 0.43, accentCol: 0, blankCorner: false, fontSize: 12 });
  }
  {
    const s = content("Da dove viene questa risposta? Una scheda pratica", "Traduciamo il modulo in una scheda pratica: sei domande da porsi quando una risposta dell'AI conta davvero, per esempio prima di usarla in un documento o in una decisione. Primo: quale sistema sto usando? Non solo quale modello, ma quale applicazione, con quali funzioni di ricerca, file e memoria: sottotema 2.5. Secondo: da dove viene questa informazione? Dalla conoscenza appresa in addestramento, dal contesto che ho fornito o da una fonte esterna recuperata? Sottotema 2.6. Terzo: può essere cambiata di recente? Se sì, la data limite del modello conta, e servono ricerca o documenti aggiornati: ancora 2.6. Quarto: il contesto è quello giusto? Pertinente, completo, e non sepolto nel mezzo di testi molto lunghi: sottotema 2.5. Quinto: che cosa resta dopo la conversazione? Memoria dell'applicazione, uso dei dati da parte del fornitore, condizioni del servizio: sottotemi 2.3 e 2.5. Sesto: se la rigenero, cambia? Risposte molto diverse a una domanda fattuale sono un segnale da verificare, ma una risposta stabile non è una prova: sottotema 2.7. Suggerimento: applicare la scheda insieme ai partecipanti a una risposta reale di un assistente.");
    const f = [["Quale sistema sto usando?", "Modello e applicazione, con quali funzioni", "2.5"], ["Da dove viene l'informazione?", "Addestramento, contesto o fonte esterna", "2.6"], ["Può essere cambiata di recente?", "Data limite, ricerca, documenti aggiornati", "2.6"], ["Il contesto è quello giusto?", "Pertinente, completo, non sepolto", "2.5"], ["Che cosa resta dopo?", "Memoria, dati, condizioni del servizio", "2.3  2.5"], ["Se la rigenero, cambia?", "Un segnale, non una prova", "2.7"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.0;
      shapeBox(s, x, y, 4.4, 0.88, row % 2 ? C.accent6 : C.background2, "scheda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y, w: 0.4, h: 0.88, fontSize: 20, bold: true, color: C.accent1, valign: "middle" });
      txt(s, f[i][0], { x: x + 0.6, y: y + 0.08, w: 2.95, h: 0.38, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, f[i][1], { x: x + 0.6, y: y + 0.46, w: 2.95, h: 0.36, fontSize: 12, color: C.text2 });
      txt(s, f[i][2], { x: x + 3.5, y, w: 0.8, h: 0.88, fontSize: 11, bold: true, color: C.accent1, align: "right", valign: "middle" });
    }
    banner(s, 4.25, "Capire il meccanismo serve a sapere che cosa controllare, non a fidarsi di più.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei semplificazioni da evitare, che riassumono in negativo i messaggi del modulo. Gli equivoci sulle fonti, come 'se carico un documento il modello lo impara', li abbiamo già visti nel sottotema 2.6; qui guardiamo le altre aree. Primo: pensare che l'AI capisca come una persona. Valutiamo le prestazioni osservabili, senza attribuire comprensione, intenzioni o emozioni. Secondo: trattare AI, Machine Learning e AI generativa come sinonimi o come caselle separate. Rispondono a criteri diversi, e uno stesso sistema appartiene a più categorie. Terzo: credere che correggendo un assistente lo si addestri. Durante l'uso siamo in inferenza: i parametri non cambiano. Quarto: liquidare un LLM come un semplice completamento automatico, o all'opposto come una mente. Genera output da regolarità apprese e dal contesto. Quinto: confondere il modello con il prodotto. Molte funzioni, come la ricerca, i file e la memoria, dipendono dall'applicazione. Sesto: pensare che una risposta stabile sia per questo corretta. La stabilità non è una garanzia, e la variabilità non è un errore. Suggerimento: chiedere ai partecipanti quale di queste idee avevano all'inizio del modulo, collegandosi alle risposte raccolte in apertura.");
    const a = [["FiUser", "\"L'AI capisce come una persona\"", "Contano le prestazioni osservabili", "2.1"], ["FiGrid", "\"AI, ML e generativa sono la stessa cosa\"", "Criteri diversi, categorie non esclusive", "2.2"], ["FiEdit3", "\"Se lo correggo, lo addestro\"", "Nell'uso siamo in inferenza", "2.3"], ["FiType", "\"È solo un completamento automatico\"", "Regolarità apprese e contesto", "2.4"], ["FiBox", "\"Il modello è il prodotto\"", "Ricerca, file e memoria sono dell'applicazione", "2.5"], ["FiRepeat", "\"Sempre la stessa risposta, quindi corretta\"", "La stabilità non è una garanzia", "2.7"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Prossimo passo: il Tema 3", "Chiudiamo con uno sguardo al prossimo modulo. In questo tema abbiamo capito come funzionano i sistemi AI: come apprendono, come generano le risposte, da dove arrivano le informazioni e perché le risposte variano. Abbiamo più volte rimandato una domanda fondamentale: quanto possiamo fidarci di ciò che l'AI produce? Il Tema 3 sarà dedicato proprio a questo: perché i modelli possono produrre informazioni false ma plausibili, le cosiddette allucinazioni; da dove nascono i bias; come valutare l'accuratezza e l'affidabilità di un output; e come impostare una verifica proporzionata all'importanza del risultato. I concetti di questo modulo, come la generazione probabilistica, la conoscenza incorporata e datata, il contesto e il grounding, saranno la base per capire le cause degli errori e i modi per gestirli. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.background2, "tema 2");
    txt(s, "TEMA 2", { x: 0.75, y: 1.4, w: 3.1, h: 0.35, fontSize: 13, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Fondamenti e funzionamento", { x: 0.75, y: 1.8, w: 3.1, h: 0.5, fontSize: 18, bold: true, color: C.text1 });
    txt(s, bullets(["Come apprende l'AI", "Come genera le risposte", "Da dove arrivano le informazioni", "Perché le risposte variano"], { space: 4 }), { x: 0.75, y: 2.45, w: 3.1, h: 2.2, fontSize: 14, color: C.text2 });
    arrow(s, 4.25, 2.9, 0.55, C.accent1);
    shapeBox(s, 4.95, 1.2, 4.55, 3.75, C.text1, "tema 3");
    txt(s, "TEMA 3", { x: 5.2, y: 1.4, w: 4.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Capacità, limiti e affidabilità", { x: 5.2, y: 1.8, w: 4.1, h: 0.5, fontSize: 18, bold: true, color: C.background1 });
    txt(s, bullets(["Perché l'AI può sbagliare", "Allucinazioni", "Bias", "Accuratezza e affidabilità", "Come verificare i risultati"], { space: 3 }), { x: 5.2, y: 2.45, w: 4.1, h: 2.3, fontSize: 14, color: C.accent3 });
  }
  {
    const s = content("Fonti e riferimenti", "Questa slide raccoglie le principali fonti citate nel modulo. Le fonti sono state verificate a ottobre 2026; in particolare, la definizione di sistema di AI dell'articolo 3 non è stata modificata dal Digital Omnibus del 2026. Alcune informazioni, come le dimensioni delle finestre di contesto, le funzioni di memoria dei prodotti e le caratteristiche dei modelli più recenti, cambiano rapidamente: prima di ogni edizione del corso è consigliabile verificarne l'attualità.");
    const src = [
      "Regolamento (UE) 2024/1689 sull'intelligenza artificiale (AI Act), art. 3; articolo non modificato dal Regolamento (UE) 2026/1744.",
      "OCSE (2023). Definizione aggiornata di sistema di intelligenza artificiale; memorandum esplicativo (2024).",
      "Weizenbaum, J. (1966). ELIZA: A Computer Program for the Study of Natural Language Communication between Man and Machine. Communications of the ACM, 9(1), 36-45.",
      "Vaswani, A. et al. (2017). Attention Is All You Need. NeurIPS.",
      "Brown, T. et al. (2020). Language Models are Few-Shot Learners. NeurIPS.",
      "Ouyang, L. et al. (2022). Training language models to follow instructions with human feedback. NeurIPS.",
      "Lewis, P. et al. (2020). Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS.",
      "Liu, N. F. et al. (2024). Lost in the Middle: How Language Models Use Long Contexts. Transactions of the ACL, 12, 157-173.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 5 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.45, fontSize: 13, color: C.text1 });
    txt(s, "Dati verificati a ottobre 2026: ricontrollarli prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema2_Fondamenti_e_funzionamento_AI.pptx" });
  await applyTheme("Tema2_Fondamenti_e_funzionamento_AI.pptx", THEME);
  console.log("done");
})();
