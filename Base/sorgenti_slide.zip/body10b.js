
  // =====================================================================
  section("10.3 Immagini: generare");
  divider("10.3", "Generazione e trasformazione delle immagini", "La generazione visiva accelera l'esplorazione creativa, ma non garantisce controllo completo e conformità", "Dalla comprensione alla generazione. I sistemi di generazione di immagini sono tra gli strumenti di AI più noti al grande pubblico: da una descrizione testuale producono in pochi secondi illustrazioni, immagini fotorealistiche, concept, varianti. Possono anche modificare immagini esistenti: aggiungere o rimuovere elementi, cambiare lo stile, adattare il formato. In questo sottotema, da conoscere e sperimentare, vediamo le possibilità e le applicazioni nella comunicazione aziendale, ma anche i limiti di precisione e di riproducibilità, e i requisiti professionali che la generazione non garantisce automaticamente. I modelli di diffusione, la tecnologia su cui si basano molti di questi sistemi, sono solo da accennare.");
  {
    const s = content("Dalla descrizione all'immagine", "La generazione di immagini da descrizioni testuali funziona così, dal punto di vista dell'utente: si descrive ciò che si vuole, e il sistema produce una o più immagini. La descrizione può indicare il soggetto, la composizione, lo stile, i colori, l'atmosfera, il formato. Il risultato può essere un'illustrazione, un'immagine dall'aspetto fotografico, uno schizzo, un'icona, un'immagine astratta. Le tecniche di formulazione delle richieste per le immagini sono specialistiche, e il documento chiede di non svilupparle; i principi generali del Tema 6 restano validi: chiarezza, contesto, esempi, iterazione. Il punto concettuale da cogliere è un altro: la descrizione non determina l'immagine in modo univoco. La stessa richiesta produce immagini diverse a ogni generazione, e molti dettagli non descritti vengono decisi dal sistema: il volto di una persona, la disposizione degli oggetti, la luce, lo sfondo. Questo è un vantaggio per l'esplorazione creativa, perché propone soluzioni a cui non si era pensato. Ed è un limite per il controllo: è difficile ottenere esattamente ciò che si ha in mente, e ancora più difficile ottenere di nuovo la stessa immagine. Per molti sistemi è possibile ripartire da un'immagine generata e chiederne modifiche, procedendo per affinamenti successivi.");
    opTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 1.65, "Una descrizione può indicare", "Soggetto, composizione, stile, colori, atmosfera, formato.", { fontSize: 13 });
    await card(s, 5.15, 1.15, 4.35, 1.65, { icon: "FiShuffle", inline: true, head: "Non determina l'immagine", headSize: 14, bodySize: 12, fill: C.accent6, body: "Molti dettagli non descritti li decide il sistema: volti, disposizione, luce, sfondo." });
    await card(s, 0.5, 3.0, 4.35, 1.4, { head: "Un vantaggio per esplorare", headSize: 14, bodySize: 12, body: "Propone soluzioni a cui non si era pensato." });
    await card(s, 5.15, 3.0, 4.35, 1.4, { head: "Un limite per controllare", headSize: 14, bodySize: 12, body: "Difficile ottenere esattamente ciò che si ha in mente, e ottenerlo di nuovo." });
    txt(s, "Tecniche di richiesta specialistiche: non sviluppate. Valgono i principi del Tema 6.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Che cosa si può produrre", "Le tipologie di immagini che si possono generare sono molte, e il sottotema le elenca. Illustrazioni: immagini disegnate, in stili diversi, per accompagnare testi, presentazioni, materiali formativi. Immagini sintetiche dall'aspetto fotografico: ambienti, oggetti, scene, che sembrano fotografie ma non lo sono. Concept: bozze visive per esplorare un'idea, come l'allestimento di uno stand, il design di un packaging, l'atmosfera di una campagna, prima di affidarne la realizzazione a professionisti. Varianti visive: più versioni della stessa idea, con colori, composizioni o stili diversi, per confrontarle e scegliere. Elementi grafici: icone, sfondi, pattern, decorazioni. Il valore principale, nel contesto aziendale, è l'esplorazione rapida: vedere un'idea prima di investire nella sua realizzazione, provare dieci varianti in pochi minuti, dare forma visiva a un concetto astratto. Come accenna il documento, in contesti professionali la generazione è spesso un punto di partenza, non un prodotto finito: la produzione professionale richiede controllo creativo, revisione e, spesso, il lavoro di professionisti della comunicazione visiva.");
    opTag(s, 1);
    await iconGrid(s, [
      { icon: "FiFeather", head: "Illustrazioni", body: "Per testi, presentazioni, materiali formativi" },
      { icon: "FiCamera", head: "Immagini sintetiche", body: "Sembrano fotografie, ma non lo sono" },
      { icon: "FiPenTool", head: "Concept", body: "Uno stand, un packaging, un'atmosfera" },
      { icon: "FiCopy", head: "Varianti", body: "Colori, composizioni, stili da confrontare" },
      { icon: "FiGrid", head: "Elementi grafici", body: "Icone, sfondi, pattern" },
      { icon: "FiZap", head: "Esplorazione rapida", body: "Vedere un'idea prima di investire", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "In contesti professionali, spesso un punto di partenza, non un prodotto finito.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Modificare immagini esistenti", "Oltre a generare immagini nuove, i sistemi possono trasformare immagini esistenti. Il sottotema elenca le principali operazioni. Aggiungere elementi: inserire un oggetto, una persona, una scritta in una fotografia. Rimuovere elementi: cancellare un oggetto, un passante, un difetto, ricostruendo lo sfondo. Sostituire elementi: cambiare il colore di un prodotto, lo sfondo di una foto, un oggetto con un altro. Trasformare lo stile: rendere una fotografia un disegno, un acquerello, uno schizzo. Modificare la composizione: estendere un'immagine oltre i suoi bordi, cambiarne l'inquadratura. Adattare il formato: da orizzontale a verticale per i social, da alta a bassa risoluzione. Sono operazioni che un tempo richiedevano competenze di fotoritocco e ore di lavoro, e oggi si ottengono con una richiesta. Il loro valore pratico è evidente. Ma è proprio qui che nasce una delle questioni più importanti del tema, che svilupperemo nel 10.8: un'immagine modificata in modo realistico può non essere più distinguibile dall'originale. Rimuovere un elemento da una fotografia che documenta un fatto, come lo stato di un cantiere o un danno, cambia ciò che la fotografia documenta. Le modifiche alle immagini usate come documentazione richiedono quindi particolare cautela e trasparenza.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiPlusCircle", head: "Aggiungere", body: "Un oggetto, una scritta" },
      { icon: "FiMinusCircle", head: "Rimuovere", body: "Un oggetto, un difetto, un passante" },
      { icon: "FiRefreshCw", head: "Sostituire", body: "Colore, sfondo, oggetto" },
      { icon: "FiFeather", head: "Cambiare stile", body: "Da foto a disegno o acquerello" },
      { icon: "FiMaximize", head: "Composizione", body: "Estendere, reinquadrare" },
      { icon: "FiSmartphone", head: "Formato", body: "Orizzontale, verticale, risoluzione" },
    ], 3, { y: 1.15, H: 2.6, headSize: 13, bodySize: 12 });
    shapeBox(s, 0.5, 3.95, 9.0, 1.0, C.text1, "attenzione documentazione");
    txt(s, [{ text: "Attenzione: ", options: { bold: true, color: C.accent6 } }, { text: "rimuovere un elemento da una foto che documenta un fatto, come un cantiere o un danno, cambia ciò che la foto documenta. Cautela e trasparenza (10.8).", options: { color: C.background1 } }], { x: 0.7, y: 3.95, w: 8.6, h: 1.0, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Applicazioni alla comunicazione", "Vediamo alcune applicazioni concrete nella comunicazione aziendale, con il loro valore e la loro principale attenzione. Materiali interni, come presentazioni, newsletter, intranet, materiali formativi: illustrazioni per rendere più chiari e gradevoli i contenuti. È l'uso a minor rischio, a condizione di rispettare lo stile aziendale. Concept e prototipi visivi, per esplorare idee prima di affidarle a professionisti: grande risparmio di tempo nelle fasi iniziali; attenzione a non confondere il concept con il prodotto finale. Adattamento di materiali esistenti a formati diversi, per canali e destinatari differenti: rapido ed efficace; attenzione a mantenere la coerenza con l'originale e con l'identità visiva. Comunicazione esterna, come social, pubblicità, sito: possibile, ma è l'uso che richiede più attenzione, per i requisiti di marchio, i diritti, la rappresentazione delle persone e la trasparenza verso il pubblico sull'uso di immagini generate. In tutti i casi, le linee guida aziendali sull'uso delle immagini generate, quando esistono, vanno seguite. Se non esistono, è un buon segnale per chiederle.");
    opTag(s, [1, 2]);
    table(s, [["Applicazione", "Valore", "Attenzione principale"],
      ["Materiali interni", "Contenuti più chiari e gradevoli", "Coerenza con lo stile aziendale"],
      ["Concept e prototipi", "Esplorare prima di investire", "Non confonderli con il prodotto finale"],
      ["Adattamento di formati", "Rapido, per più canali", "Coerenza con originale e identità visiva"],
      ["Comunicazione esterna", "Contenuti in quantità", "Marchio, diritti, persone, trasparenza"]],
      { y: 1.15, colW: [2.5, 3.0, 3.5], rowH: 0.5, fontSize: 12, blankCorner: false, accentCol: 2 });
    banner(s, 3.85, "Seguire le linee guida aziendali sulle immagini generate. Se non esistono, è il momento di chiederle.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Limiti di precisione e riproducibilità", "Il sottotema chiede di conoscere i limiti nella precisione dei dettagli e nella riproducibilità. I principali, dal punto di vista dell'uso professionale. Il testo nelle immagini: i sistemi sono migliorati molto, ma scritte, etichette e numeri possono ancora risultare errati, deformati o inventati, specialmente se lunghi o in lingue meno comuni. I dettagli anatomici e strutturali: mani, dita, oggetti complessi, meccanismi, architetture possono contenere incoerenze che un occhio attento nota. La fedeltà ai riferimenti: chiedere di riprodurre un prodotto specifico, un luogo reale, un macchinario aziendale porta spesso a immagini simili ma non fedeli, con dettagli sbagliati che chi conosce l'oggetto riconosce subito. La riproducibilità: la stessa richiesta produce immagini diverse, e ottenere una serie di immagini coerenti tra loro, per esempio lo stesso personaggio in più scene o lo stesso prodotto da più angolazioni, è difficile, anche se alcuni strumenti offrono funzioni dedicate. Il controllo fine: spostare un elemento di pochi centimetri, cambiare un solo dettaglio senza alterare il resto, è spesso più difficile di quanto ci si aspetti. Per questi motivi, la generazione visiva è ottima per esplorare e meno adatta quando servono precisione e coerenza rigorose.");
    opTag(s, 1);
    rowsLabel(s, [["Testo nell'immagine", "Scritte, etichette e numeri errati, deformati o inventati"], ["Dettagli", "Mani, oggetti complessi, meccanismi con incoerenze"], ["Fedeltà ai riferimenti", "Un prodotto o un luogo reale: simile, ma non fedele"], ["Riproducibilità", "Stessa richiesta, immagini diverse; serie coerenti difficili"], ["Controllo fine", "Cambiare un solo dettaglio senza alterare il resto"]], { y: 1.15, h: 0.52, lw: 2.6 });
    banner(s, 4.25, "Ottima per esplorare; meno adatta quando servono precisione e coerenza rigorose.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Requisiti professionali", "La consapevolezza del sottotema dice che la generazione visiva non garantisce conformità automatica a requisiti professionali. Quali sono questi requisiti? Quattro famiglie. L'identità visiva: colori, caratteri, stile fotografico e regole d'uso del marchio aziendale. Un'immagine generata non li rispetta automaticamente, e i loghi in particolare vanno inseriti come elementi originali, non generati. I diritti: il documento chiede di introdurre il tema senza analisi normativa. Basti sapere che esistono questioni aperte sui diritti relativi alle immagini generate e ai dati usati per addestrare i sistemi, che le condizioni d'uso degli strumenti variano, e che generare immagini che imitano lo stile riconoscibile di un artista vivente, o riproducono personaggi, opere e marchi altrui, può creare problemi. Le persone: generare immagini di persone reali riconoscibili, colleghi, clienti, personaggi pubblici, solleva questioni di consenso, di immagine e di possibile inganno; molti strumenti lo limitano. La trasparenza: in alcuni contesti è opportuno, o richiesto, dichiarare che un'immagine è generata, specialmente quando potrebbe essere scambiata per una fotografia reale. Le regole specifiche appartengono all'area della responsabilità e della normativa.");
    opTag(s, 1);
    await iconGrid(s, [
      { icon: "FiDroplet", head: "Identità visiva", body: "Colori, caratteri, stile; loghi originali, non generati" },
      { icon: "FiFileText", head: "Diritti", body: "Questioni aperte; stili di artisti, personaggi e marchi altrui" },
      { icon: "FiUsers", head: "Persone reali", body: "Consenso, immagine, possibile inganno" },
      { icon: "FiEye", head: "Trasparenza", body: "Dichiarare che è generata, se può sembrare una foto" },
    ], 2, { y: 1.15, H: 2.65, headSize: 14, bodySize: 12 });
    banner(s, 4.0, "La generazione non garantisce conformità automatica a requisiti professionali. Regole specifiche: area responsabilità e normativa.", { h: 0.85, fontSize: 13 });
  }
  keySlide("La generazione visiva accelera l'esplorazione creativa ma non garantisce controllo completo, fedeltà ai riferimenti o conformità automatica a requisiti professionali.", "Sottotema 10.3  ·  Generazione e trasformazione delle immagini", "Concetto chiave del sottotema 10.3. I sistemi generano illustrazioni, immagini sintetiche, concept e varianti, e modificano immagini esistenti aggiungendo, rimuovendo o sostituendo elementi, cambiando stile e formato. Il valore principale è l'esplorazione rapida. Ma la descrizione non determina l'immagine, i dettagli e i testi possono essere errati, la fedeltà ai riferimenti e la riproducibilità sono limitate, e requisiti di marchio, diritti, persone e trasparenza non sono garantiti automaticamente. Le modifiche a immagini usate come documentazione richiedono particolare cautela. Esercizio suggerito: chiedere ai partecipanti di generare un'immagine per una slide interna su un tema fittizio, poi valutarla con una breve lista di controllo: dettagli corretti, testo corretto, coerenza con lo stile aziendale, assenza di persone reali o marchi altrui.");

  // =====================================================================
  section("10.4 Audio e voce");
  divider("10.4", "AI per audio, voce e linguaggio parlato", "L'accessibilità può migliorare grazie alle tecnologie vocali, ma trascrizioni e traduzioni richiedono controlli", "Passiamo all'audio. Le tecnologie vocali sono forse quelle con l'impatto più immediato sul lavoro quotidiano: trascrivere riunioni, interviste e telefonate, produrne sintesi, interagire con un assistente a voce, tradurre il parlato, generare una voce che legge un testo. In questo sottotema, da conoscere e sperimentare, vediamo queste capacità, i loro limiti tipici, in particolare nel riconoscimento della terminologia e nell'attribuzione delle affermazioni agli interlocutori, e la prima delle integrazioni del tema: l'AI multimodale come strumento di accessibilità.");
  {
    const s = content("Le capacità vocali", "Una panoramica delle capacità che il sottotema elenca. Il riconoscimento del parlato: il sistema capisce che cosa viene detto. È alla base di tutte le altre. La trascrizione da audio a testo: una registrazione diventa un testo, eventualmente con l'indicazione di chi parla e dei tempi. La sintesi vocale: un testo viene letto da una voce artificiale, oggi molto naturale. L'interazione vocale: si conversa a voce con un assistente, con tempi di risposta sempre più simili a una conversazione umana. La traduzione del parlato: ciò che viene detto in una lingua viene restituito in un'altra, come testo o come voce, anche quasi in tempo reale. L'analisi e la sintesi di registrazioni: dal contenuto di una riunione o di un'intervista si ricavano un riassunto, le decisioni, le azioni, i temi principali. Le applicazioni più diffuse riguardano le riunioni, le interviste, le telefonate con i clienti, la formazione, la comunicazione multilingue, e l'accessibilità, che vedremo tra poco. La qualità di tutte queste capacità è molto migliorata negli ultimi anni, ma dipende fortemente dalla qualità dell'audio, dalla lingua, dagli accenti e dalla terminologia.");
    opTag(s, [0, 1, 2]);
    await iconGrid(s, [
      { icon: "FiMic", head: "Riconoscimento", body: "Capire che cosa viene detto" },
      { icon: "FiFileText", head: "Trascrizione", body: "Da audio a testo, con chi parla e quando" },
      { icon: "FiVolume2", head: "Sintesi vocale", body: "Un testo letto da una voce naturale" },
      { icon: "FiMessageCircle", head: "Interazione vocale", body: "Conversare a voce con un assistente" },
      { icon: "FiGlobe", head: "Traduzione del parlato", body: "In un'altra lingua, anche quasi in tempo reale" },
      { icon: "FiList", head: "Analisi e sintesi", body: "Riassunto, decisioni, azioni, temi" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Qualità molto migliorata, ma dipende da audio, lingua, accenti e terminologia.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Riunioni, interviste, comunicazioni", "L'applicazione più diffusa delle tecnologie vocali in azienda è la trascrizione e la sintesi di riunioni. Molti strumenti di videoconferenza la offrono direttamente: al termine della riunione si ottengono la trascrizione completa, un riassunto, le decisioni e le azioni con i responsabili. Il valore è evidente: nessuno deve prendere appunti, chi era assente può recuperare, le azioni concordate non si perdono. Lo stesso vale per interviste, focus group, telefonate di assistenza, colloqui di formazione. Ma il passaggio dalla registrazione al verbale è una catena di trasformazioni, come vedremo nel 10.7, e ogni passaggio può introdurre errori: il riconoscimento può fraintendere parole, la trascrizione può attribuire frasi alla persona sbagliata, la sintesi può omettere obiezioni, trasformare un'ipotesi in una decisione, o un 'ci penso' in un 'sì', come abbiamo visto nel Tema 8 per i verbali. Due buone pratiche. Far rivedere il riassunto e le azioni a chi ha partecipato, prima di diffonderli. E conservare la trascrizione completa, o la registrazione quando consentito, come riferimento per verificare i punti controversi.");
    opTag(s, [0, 2]);
    const ch = [["Registrazione", C.background2], ["Trascrizione", C.accent6], ["Riassunto", C.accent6], ["Decisioni e azioni", C.accent1]];
    ch.forEach((e, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, e[0], { fill: e[1], color: i === 3 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    const r = [["Parole fraintese", "Nel riconoscimento"], ["Frasi attribuite male", "Nella trascrizione"], ["Obiezioni omesse", "Nel riassunto"], ["'Ci penso' diventa 'sì'", "Nelle decisioni"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 2.0, 2.05, 0.95, C.background2, e[0]);
      txt(s, e[0], { x: x + 0.12, y: 2.06, w: 1.85, h: 0.48, fontSize: 12, bold: true, color: C.accent5 });
      txt(s, e[1], { x: x + 0.12, y: 2.55, w: 1.85, h: 0.32, fontSize: 11, color: C.text2 });
    });
    await card(s, 0.5, 3.15, 4.35, 1.8, { icon: "FiUsers", inline: true, head: "Far rivedere ai partecipanti", headSize: 14, bodySize: 12, fill: C.accent6, body: "Riassunto e azioni, prima di diffonderli." });
    await card(s, 5.15, 3.15, 4.35, 1.8, { icon: "FiArchive", inline: true, head: "Conservare la trascrizione", headSize: 14, bodySize: 12, body: "O la registrazione, quando consentito, come riferimento per i punti controversi." });
  }
  {
    const s = content("Errori di riconoscimento", "Il sottotema chiede di conoscere i limiti nel riconoscimento di voci e terminologia. Gli errori tipici delle trascrizioni sono prevedibili, e conoscerli aiuta a controllarle in modo mirato. Nomi propri: persone, aziende, prodotti, luoghi, specialmente se stranieri o poco comuni. Terminologia tecnica e sigle aziendali: parole che il sistema non conosce vengono sostituite con parole simili nel suono ma diverse nel significato. Numeri: cifre, importi, date, percentuali, dove un errore è grave e poco visibile, come 'quindici' e 'cinquanta', o 'diciotto per cento' e 'otto per cento'. Accenti, dialetti, voci poco chiare, persone che parlano velocemente. Sovrapposizioni: quando più persone parlano insieme, parti del discorso si perdono o si mescolano. Rumore di fondo e qualità della registrazione. Lingue miste: riunioni in cui si alternano italiano e inglese. Un fenomeno da conoscere, osservato in alcuni sistemi di trascrizione, è l'aggiunta di frasi mai pronunciate, specialmente durante pause o rumori: un caso di 'allucinazione' applicato all'audio. Alcuni strumenti permettono di fornire un vocabolario di termini specifici, che riduce gli errori su nomi e terminologia.");
    opTag(s, 0);
    table(s, [["Detto", "Trascritto", "Tipo di errore"],
      ["Il fornitore Kessler", "Il fornitore Kessel", "Nome proprio"],
      ["Il modulo SDI", "Il modulo esse di", "Sigla aziendale"],
      ["Sconto del diciotto per cento", "Sconto dell'otto per cento", "Numero"],
      ["(pausa di silenzio)", "Grazie per l'attenzione.", "Frase aggiunta"]],
      { y: 1.15, colW: [3.2, 3.2, 2.6], rowH: 0.45, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Esempi fittizi", { x: 0.5, y: 3.43, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    const o = ["Accenti e dialetti", "Sovrapposizioni", "Rumore di fondo", "Lingue miste"];
    o.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.75, 2.15, 0.5, t, { fill: C.background2, fontSize: 12 }));
    txt(s, "Alcuni strumenti accettano un vocabolario di termini specifici: riduce gli errori su nomi e terminologia.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Chi ha detto che cosa", "Un rischio specifico che il sottotema mette in evidenza: l'errore nell'attribuzione delle affermazioni agli interlocutori. Molti strumenti di trascrizione distinguono le voci e indicano chi sta parlando, una funzione chiamata diarizzazione. Quando le persone sono collegate con account separati in una videoconferenza, l'attribuzione è di solito affidabile. Quando invece più persone parlano nella stessa stanza con un solo microfono, o hanno voci simili, o si interrompono, l'attribuzione può essere sbagliata. L'esempio fittizio in slide mostra due versioni di uno stesso scambio: nella trascrizione, l'impegno a consegnare entro venerdì è attribuito alla persona sbagliata. In un verbale, questo errore cambia chi ha preso un impegno; in un'intervista, chi ha espresso un'opinione; in una telefonata con un cliente, chi ha promesso che cosa. Ed è un errore difficile da notare per chi non era presente, perché la trascrizione è coerente e ben formattata. Le conseguenze possono essere serie, specialmente per impegni, responsabilità e posizioni espresse in contesti delicati. Per questo, nei verbali e nei riassunti, le attribuzioni importanti vanno controllate da chi era presente.");
    opTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.75, "Che cosa è stato detto (esempio fittizio)", "Bianchi: \"Riesci a consegnare entro venerdì?\"\nVerdi: \"Sì, me ne occupo io.\"", { fontSize: 13, fill: C.accent6 });
    docBox(s, 5.15, 1.15, 4.35, 1.75, "Trascrizione con attribuzione errata", "Bianchi: \"Riesci a consegnare entro venerdì? Sì, me ne occupo io.\"", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Un errore di attribuzione cambia", { x: 0.5, y: 3.05, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.43, 2.9, 0.55, "Chi ha preso un impegno", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.43, 2.9, 0.55, "Chi ha espresso un'opinione", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.43, 2.9, 0.55, "Chi ha promesso che cosa", { fill: C.background2, fontSize: 12 });
    banner(s, 4.15, "Difficile da notare per chi non c'era. Le attribuzioni importanti le controlla chi era presente.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Sintesi vocale e interazione", "Due capacità di generazione vocale. La sintesi vocale trasforma un testo in parlato. Le voci attuali sono molto naturali, con intonazione, pause ed espressività, in molte lingue. Applicazioni: narrazione di video formativi, lettura di documenti per chi preferisce ascoltare o non può leggere, messaggi vocali, assistenti telefonici, versioni audio di contenuti. Alcuni sistemi possono anche riprodurre la voce di una persona specifica a partire da pochi secondi di registrazione. È una capacità con usi legittimi, come dare voce a chi l'ha persa, ma anche con rischi seri di inganno, che vedremo nel 10.8: la voce di una persona non va riprodotta senza il suo consenso esplicito. L'interazione vocale permette di conversare a voce con un assistente: porre domande, dettare, ricevere risposte parlate. È utile quando le mani o gli occhi sono occupati, per chi ha difficoltà con la tastiera, o semplicemente perché parlare è più rapido che scrivere. Un'attenzione: nell'interazione vocale la risposta si ascolta una volta e non si rilegge, quindi è più difficile notarne gli errori. Per informazioni importanti, conviene chiedere anche la versione scritta.");
    opTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiVolume2", head: "Sintesi vocale", headSize: 15, bodySize: 12,
      body: bullets(["Voci naturali, in molte lingue", "Video formativi, documenti in audio, assistenti", "Riprodurre una voce specifica: solo con consenso esplicito"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiMessageCircle", head: "Interazione vocale", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Domande, dettatura, risposte parlate", "Mani o occhi occupati, difficoltà con la tastiera", "Si ascolta una volta: errori meno visibili"], { space: 5 }) });
    banner(s, 3.9, "Per informazioni importanti ricevute a voce, chiedere anche la versione scritta.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Tradurre il parlato", "La traduzione del parlato combina riconoscimento, traduzione e, a volte, sintesi vocale. Può avvenire in modi diversi: sottotitoli tradotti in una videoconferenza, traduzione di una registrazione, conversazione bilingue quasi in tempo reale con un dispositivo che ascolta e traduce. Le opportunità sono grandi: riunioni con colleghi o clienti di altri paesi senza una lingua comune, formazione per personale di lingue diverse, assistenza a clienti stranieri. La qualità per le lingue più diffuse e per conversazioni ordinarie è oggi buona. Ma la traduzione del parlato somma i rischi di due passaggi: gli errori di riconoscimento visti prima, e quelli di traduzione visti nel Tema 8, come terminologia, sfumature, gradi di obbligo, registro. In più, la traduzione quasi in tempo reale ha meno contesto: traduce frase per frase, senza sapere come proseguirà il discorso. E chi ascolta la traduzione spesso non può verificarla, perché non conosce la lingua di partenza. Per questo, nelle conversazioni con conseguenze, come trattative, accordi, istruzioni di sicurezza, comunicazioni mediche o legali, la traduzione automatica del parlato può supportare ma non sostituire un interprete o una conferma scritta.");
    opTag(s, [0, 2]);
    const ch = [["Parlato", C.background2], ["Riconoscimento", C.accent6], ["Traduzione", C.accent6], ["Testo o voce", C.background2]];
    ch.forEach((e, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, e[0], { fill: e[1], fontSize: 13 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    await card(s, 0.5, 2.05, 4.35, 1.75, { icon: "FiThumbsUp", inline: true, head: "Opportunità", headSize: 14, bodySize: 12, fill: C.accent6, body: "Riunioni senza lingua comune, formazione multilingue, assistenza a clienti stranieri." });
    await card(s, 5.15, 2.05, 4.35, 1.75, { icon: "FiAlertTriangle", inline: true, head: "Rischi sommati", headSize: 14, bodySize: 12, iconBg: C.accent5, body: "Errori di riconoscimento e di traduzione, meno contesto, ascoltatore che non può verificare." });
    banner(s, 4.0, "Trattative, accordi, sicurezza, ambiti medici o legali: supporto sì, sostituto di un interprete o di una conferma scritta no.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Uno strumento di accessibilità", "Integrazione B del tema: l'AI multimodale come strumento di accessibilità. Trascrizioni, sottotitoli, descrizioni, sintesi vocale e traduzioni possono rendere le informazioni accessibili a persone con esigenze diverse. Le persone sorde o con difficoltà uditive possono seguire riunioni e video grazie ai sottotitoli automatici. Le persone cieche o ipovedenti possono ascoltare documenti con la sintesi vocale, e ricevere descrizioni di immagini e grafici, come visto nel 10.2. Le persone con dislessia o difficoltà di lettura possono ascoltare invece di leggere. Le persone con difficoltà motorie possono interagire con la voce invece che con la tastiera. Le persone che non conoscono bene la lingua possono ricevere traduzioni e versioni semplificate. E chiunque, in situazioni temporanee, come in viaggio, in un ambiente rumoroso, con le mani occupate, può beneficiare di modalità alternative. È uno dei contributi più concreti e meno discussi dell'AI multimodale, e un'opportunità per rendere più inclusiva la comunicazione aziendale. La consapevolezza del sottotema aggiunge però una condizione: trascrizioni e traduzioni richiedono controlli adeguati di accuratezza e contesto. Un sottotitolo sbagliato, per chi non può ascoltare l'audio, è un'informazione sbagliata che non ha modo di correggere.");
    opTag(s, [0, 1, 2]);
    await iconGrid(s, [
      { icon: "FiType", head: "Sottotitoli", body: "Per chi non sente o è in un luogo rumoroso" },
      { icon: "FiVolume2", head: "Sintesi vocale", body: "Per chi non vede o fatica a leggere" },
      { icon: "FiImage", head: "Descrizioni di immagini", body: "Grafici e foto per chi non vede" },
      { icon: "FiMic", head: "Comandi vocali", body: "Per chi non usa la tastiera" },
      { icon: "FiGlobe", head: "Traduzioni", body: "Per chi non conosce bene la lingua" },
      { icon: "FiAlignLeft", head: "Versioni semplificate", body: "Per chi ha bisogno di testi più chiari" },
    ], 3, { y: 1.15, H: 2.7, headSize: 13, bodySize: 12 });
    banner(s, 4.05, "Un sottotitolo sbagliato, per chi non può ascoltare, è un errore che non ha modo di correggere. Servono controlli.", { h: 0.75, fontSize: 13 });
    txt(s, "Integrazione B: AI multimodale come strumento di accessibilità", { x: 0.5, y: 4.85, w: 9, h: 0.25, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Registrare con consenso", "Una considerazione pratica che riguarda tutte le applicazioni vocali sulle riunioni e sulle conversazioni: la registrazione e la trascrizione coinvolgono le voci e le parole di altre persone. Anche senza entrare nell'analisi normativa, che appartiene all'area della responsabilità, alcuni principi di buona pratica sono semplici. Informare i partecipanti che la conversazione viene registrata o trascritta, prima di iniziare, e rispettare chi preferisce di no. Usare solo strumenti autorizzati dall'azienda, perché una registrazione di una riunione contiene spesso informazioni riservate, e caricarla in uno strumento non autorizzato significa trasferirle fuori dal controllo aziendale. Fare attenzione alle conversazioni con esterni, come clienti, fornitori, candidati, per cui possono valere regole più stringenti. Non registrare di nascosto. Definire per quanto tempo conservare registrazioni e trascrizioni, e chi può accedervi. Molti strumenti di videoconferenza mostrano un avviso quando la trascrizione è attiva: è un buon punto di partenza, ma non sostituisce l'informazione esplicita ai partecipanti, specialmente quando la trascrizione viene poi elaborata da sistemi AI.");
    opTag(s, 0);
    numList(s, ["Informare i partecipanti prima di iniziare, e rispettare chi preferisce di no", "Solo strumenti autorizzati: le registrazioni contengono informazioni riservate", "Più attenzione con esterni: clienti, fornitori, candidati", "Non registrare di nascosto", "Definire conservazione e accesso a registrazioni e trascrizioni"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "L'avviso automatico dello strumento è un punto di partenza, non sostituisce l'informazione esplicita.", { h: 0.65, fontSize: 13 });
  }
  keySlide("L'accessibilità può migliorare grazie alle tecnologie vocali, ma trascrizioni e traduzioni richiedono controlli adeguati di accuratezza e contesto.", "Sottotema 10.4  ·  AI per audio, voce e linguaggio parlato", "Concetto chiave del sottotema 10.4. Le tecnologie vocali trascrivono, sintetizzano, traducono e permettono di interagire a voce, con applicazioni immediate a riunioni, interviste, comunicazioni e formazione, e un contributo importante all'accessibilità. Ma gli errori di riconoscimento su nomi, terminologia e numeri, e gli errori di attribuzione tra interlocutori, sono frequenti e poco visibili; la traduzione del parlato somma i rischi; le risposte vocali sono più difficili da controllare. Registrazioni e trascrizioni richiedono consenso e strumenti autorizzati. Esercizio suggerito: registrare, con il consenso dei partecipanti e uno strumento autorizzato, una breve discussione simulata con nomi, numeri e impegni, e confrontare la trascrizione e il riassunto automatici con quanto effettivamente detto.");

  // =====================================================================
  section("10.5 Video");
  divider("10.5", "AI per comprensione e generazione video", "Coerenza visiva e plausibilità di una sequenza non dimostrano che gli eventi siano realmente accaduti", "Il video combina immagini, tempo e spesso audio, ed è la modalità più complessa. Il documento gli assegna priorità media e un livello di conoscenza: vogliamo che i partecipanti sappiano che cosa i sistemi possono fare oggi con i video, sia nell'analizzarli sia nel generarli, e quali sono i limiti principali. La produzione audiovisiva specialistica e l'editing professionale sono solo da accennare. Il punto concettuale del sottotema anticipa il 10.8: un video plausibile non è la prova che qualcosa sia accaduto.");
  {
    const s = content("Comprendere i video", "I sistemi multimodali possono analizzare filmati e sequenze audiovisive. Le capacità principali. Descrivere il contenuto: che cosa succede, chi compare, in quale ambiente. Identificare eventi e momenti: quando avviene un certo fatto, in quale punto del video si parla di un argomento. Riassumere: ricavare una sintesi di un video lungo, come una registrazione di un webinar, una lezione, una presentazione, combinando ciò che si vede e ciò che si sente. Estrarre informazioni: il testo che compare a schermo, le slide mostrate, i passaggi di una procedura dimostrata. Le applicazioni: rendere ricercabili archivi di video formativi, ricavare istruzioni scritte da un video dimostrativo, riassumere webinar, creare capitoli e indici. Un limite tecnico da conoscere: molti sistemi non analizzano ogni fotogramma, ma ne campionano alcuni a intervalli, per esempio uno al secondo o meno. Un evento rapido tra due fotogrammi campionati può sfuggire completamente. Inoltre, le relazioni temporali, come che cosa è successo prima e dopo, quanto è durato un evento, sono una fonte di errori frequente. Per i video usati come documentazione, la sintesi automatica è un indice utile, non un sostituto della visione dei passaggi rilevanti.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiEye", head: "Descrivere", body: "Che cosa succede, chi compare, dove" },
      { icon: "FiClock", head: "Individuare eventi", body: "Quando succede, dove si parla di un tema" },
      { icon: "FiAlignLeft", head: "Riassumere", body: "Webinar, lezioni, presentazioni" },
      { icon: "FiList", head: "Estrarre", body: "Testi a schermo, slide, passaggi di una procedura" },
    ], 2, { y: 1.15, H: 2.4, headSize: 14, bodySize: 12 });
    await card(s, 0.5, 3.75, 4.35, 1.2, { head: "Fotogrammi campionati", headSize: 13, bodySize: 12, body: "Un evento rapido tra due campioni può sfuggire." });
    await card(s, 5.15, 3.75, 4.35, 1.2, { head: "Relazioni temporali", headSize: 13, bodySize: 12, fill: C.accent6, body: "Prima, dopo, durata: errori frequenti." });
  }
  {
    const s = content("Generare e modificare video", "La generazione di video è la capacità multimodale che è progredita più rapidamente negli ultimi anni. Oggi i sistemi possono generare brevi video da una descrizione testuale, animare un'immagine fissa, generare video a partire da altri video cambiandone lo stile, creare animazioni, produrre presentatori virtuali che leggono un testo con una voce sintetica. Possono anche modificare filmati esistenti: rimuovere elementi, cambiare lo sfondo, allungare una scena, tradurre il parlato sincronizzando il movimento delle labbra. Per la comunicazione e la formazione le opportunità sono concrete: video formativi prodotti e aggiornati rapidamente, versioni in più lingue di uno stesso video, animazioni per spiegare processi, brevi contenuti per la comunicazione interna. I limiti principali sono quelli del sottotema: la coerenza temporale e la continuità delle scene, perché oggetti e persone possono cambiare aspetto da un fotogramma all'altro, apparire o scomparire, muoversi in modo fisicamente impossibile; e il controllo degli eventi rappresentati, perché è difficile ottenere esattamente l'azione voluta, nella sequenza voluta. I video generati sono in genere brevi, e la produzione di video lunghi e coerenti richiede ancora un lavoro di montaggio e competenze specialistiche, da accennare.");
    opTag(s, [1, 2]);
    await card(s, 0.5, 1.2, 4.35, 2.45, { icon: "FiFilm", head: "Che cosa si può fare", headSize: 15, bodySize: 12,
      body: bullets(["Brevi video da testo o da immagini", "Animazioni e presentatori virtuali", "Modifiche: sfondi, elementi, doppiaggio con labiale"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.45, { icon: "FiBookOpen", head: "Opportunità", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Video formativi rapidi da aggiornare", "Versioni in più lingue", "Animazioni per spiegare processi"], { space: 5 }) });
    const l = [["Coerenza temporale", "Oggetti e persone che cambiano, appaiono, scompaiono"], ["Controllo degli eventi", "Difficile ottenere l'azione voluta nella sequenza voluta"]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 3.85, 4.35, 1.1, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 3.93, w: 3.95, h: 0.38, fontSize: 14, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.32, w: 3.95, h: 0.55, fontSize: 12, color: C.background1 });
    });
  }
  {
    const s = content("Documentale o sintetico", "La distinzione più importante del sottotema: tra contenuto documentale e contenuto sintetico. Un video documentale è la registrazione di qualcosa che è accaduto davanti a una telecamera: una riunione, un evento, un'ispezione, una testimonianza. Il suo valore sta nel legame con la realtà. Un video sintetico è generato o profondamente modificato da un sistema: rappresenta qualcosa che può non essere mai accaduto. Il suo valore sta nella comunicazione, nella spiegazione, nella creatività. Entrambi sono legittimi, ma non vanno confusi. Il problema è che i video sintetici di alta qualità possono essere indistinguibili, a occhio, da quelli documentali. La consapevolezza del sottotema lo dice chiaramente: la coerenza visiva e la plausibilità di una sequenza video non dimostrano che gli eventi rappresentati siano realmente accaduti. Per molto tempo un video è stato considerato una prova particolarmente forte, più di una fotografia e molto più di un testo. Questa presunzione non è più fondata. Nella comunicazione aziendale ne derivano due regole. Quando si usa un video sintetico, dichiararlo, specialmente se rappresenta persone o situazioni realistiche. Quando si riceve un video come prova di qualcosa, chiedersi da dove viene, come vedremo nel 10.8.");
    opTag(s, [1, 2]);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiVideo", head: "Contenuto documentale", headSize: 15, bodySize: 12,
      body: bullets(["Registra qualcosa che è accaduto", "Valore: il legame con la realtà", "Riunioni, eventi, ispezioni, testimonianze"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiCpu", head: "Contenuto sintetico", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Generato o profondamente modificato", "Valore: comunicazione, spiegazione, creatività", "Può non essere mai accaduto"], { space: 4 }) });
    banner(s, 3.6, "Un video è stato a lungo considerato una prova forte. Questa presunzione non è più fondata.", { h: 0.65, fontSize: 14 });
    chip(s, 0.5, 4.4, 4.4, 0.55, "Se si usa un video sintetico: dichiararlo", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 4.4, 4.4, 0.55, "Se si riceve un video come prova: da dove viene?", { fill: C.background2, fontSize: 12 });
  }
  keySlide("Coerenza visiva e plausibilità di una sequenza video non dimostrano che gli eventi rappresentati siano realmente accaduti.", "Sottotema 10.5  ·  AI per comprensione e generazione video", "Concetto chiave del sottotema 10.5. I sistemi possono descrivere, riassumere e indicizzare video, e generare o modificare brevi filmati, con opportunità concrete per la comunicazione e la formazione. Ma l'analisi può perdere eventi rapidi e sbagliare le relazioni temporali, e la generazione ha limiti di coerenza e di controllo. Soprattutto, contenuto documentale e contenuto sintetico vanno distinti: un video realistico non è più, di per sé, una prova. Esercizio suggerito: mostrare un breve video generato, privo di persone reali e marchi, insieme a un video reale di soggetto simile, e discutere quali elementi aiutano o non aiutano a distinguerli.");
