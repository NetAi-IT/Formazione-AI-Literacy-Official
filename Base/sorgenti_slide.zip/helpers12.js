  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5, X = o.x || 0.5, W = o.w || 9.0;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, X, y, W, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: X + 0.15, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: X + 0.15 + lw, y, w: W - 0.3 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }
