const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 9: AI per dati e analisi";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 9  ·  AI per dati e analisi";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function phaseTag(s, active) {
    const st = ["Comprendere", "Elaborare", "Rappresentare", "Interpretare"];
    st.forEach((t, i) => {
      const x = 6.3 + i * 0.81;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.78, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "fase " + t });
      txt(s, t, { x, y: 0.42, w: 0.78, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function scatter(s, xs, ys, o) {
    s.addChart(pres.charts.SCATTER, [{ name: "X", values: xs }, { name: o.name || "Y", values: ys }], {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: 0, lineDataSymbol: "circle", lineDataSymbolSize: o.size || 6, chartColors: [o.color || HEX.a1],
      valAxisMinVal: o.ymin, valAxisMaxVal: o.ymax, catAxisMinVal: o.xmin, catAxisMaxVal: o.xmax,
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 8, catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 8,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, showLegend: false,
      showTitle: !!o.title, title: o.title || "", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      valAxisLabelFontFace: "+mn-lt", catAxisLabelFontFace: "+mn-lt",
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 9", { placeholder: "kicker" });
    s.addText("AI per dati e analisi", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI", { placeholder: "sub" });
    s.addNotes("Benvenuti al nono tema, il secondo dell'area 'Esplorare le possibilità dell'AI'. Nel Tema 8 abbiamo lavorato su testi, documenti e conoscenza, e nel sottotema 8.4 abbiamo visto come trasformare informazioni non strutturate in dati. Qui facciamo il passo successivo: che cosa si può fare con i dati grazie all'AI. Preparare e capire un dataset, calcolare indicatori, individuare tendenze e anomalie, costruire grafici e report, fare stime e simulazioni, interpretare i risultati e sostenere le decisioni. È un ambito in cui l'AI promette molto, perché rende accessibili attività che prima richiedevano competenze tecniche specifiche. Ed è un ambito in cui i rischi sono particolarmente insidiosi, perché i numeri hanno un'aria di oggettività che i testi non hanno. Il punto di vista resta quello dell'utilizzatore: non entriamo in algoritmi statistici specialistici, modellazione avanzata o architetture di Business Intelligence. Suggerimento per l'apertura: chiedere ai partecipanti quali dati usano nel loro lavoro, in quale forma, e quanto tempo dedicano a prepararli rispetto a interpretarli.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la comprensione delle possibilità offerte dall'AI nella preparazione, elaborazione, analisi, interpretazione e rappresentazione dei dati, con le relative opportunità, condizioni di efficacia e limiti. La consapevolezza da sviluppare ha due facce. Da un lato, l'AI può rendere più accessibili le attività di analisi e facilitare l'individuazione di informazioni utili: chi non sa scrivere una formula complessa o un'interrogazione su un database può ottenere risultati ponendo domande in linguaggio naturale. Dall'altro, l'AI non garantisce automaticamente la correttezza delle elaborazioni, la validità delle interpretazioni o l'adeguatezza delle decisioni. Il valore dell'analisi dipende da tre fattori: la qualità dei dati, la correttezza del metodo, la capacità umana di interpretare i risultati. Il concetto centrale del tema: l'AI può facilitare l'accesso all'analisi dei dati e supportare elaborazioni, interpretazioni e decisioni, ma la correttezza dei risultati dipende da dati, metodi e ipotesi, mentre la responsabilità di attribuire significato alle informazioni e utilizzarle correttamente rimane umana.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Conoscere le possibilità dell'AI su dati e analisi", "Preparare, elaborare, rappresentare, interpretare", "Riconoscere opportunità, condizioni di efficacia e limiti"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Da che cosa dipende il valore", headSize: 16, fill: C.accent6, bodySize: 14,
      body: bullets(["Qualità dei dati", "Correttezza del metodo", "Capacità umana di interpretare i risultati"], { space: 6 }) });
  }
  {
    const s = content("Otto domande guida", "Le otto domande guida accompagnano il modulo. La prima è generale: quali attività di analisi può supportare l'AI. La seconda riguarda la comprensione e l'organizzazione di dataset e fogli di calcolo. La terza le elaborazioni quantitative e statistiche, con una distinzione che svilupperemo a fondo: quella tra un calcolo eseguito e un numero generato. La quarta l'identificazione di tendenze, anomalie e relazioni. La quinta i grafici e i report. La sesta una distinzione concettuale importante: descrivere i dati, interpretarli e fare previsioni sono attività diverse. La settima il supporto alle decisioni aziendali. L'ultima gli errori e i rischi da considerare. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Quali attività di analisi può supportare l'AI?", "Come aiuta a comprendere e organizzare dataset e fogli di calcolo?", "Come esegue elaborazioni quantitative e statistiche?", "Quali possibilità su tendenze, anomalie e relazioni?", "Come supporta la creazione di grafici e report?", "Descrivere, interpretare, prevedere: che differenza c'è?", "Come può supportare le decisioni aziendali?", "Quali errori e rischi dobbiamo considerare?"], 4, 1.2, 1.6, 13);
  }
  {
    const s = content("Il filo conduttore: quattro fasi", "Il documento di perimetro propone un filo concettuale in quattro fasi. Comprendere e preparare: che dati ci sono, come sono strutturati, che cosa significano, quanto sono affidabili. Corrispondono i sottotemi 9.1 e 9.2. Elaborare e analizzare: calcolare, aggregare, costruire indicatori, individuare tendenze e anomalie. Corrispondono il 9.3 e il 9.4. Rappresentare e prevedere: costruire grafici e report, fare stime e simulazioni. Corrispondono il 9.5 e il 9.6. Interpretare e valutare: attribuire significato ai risultati, sostenere le decisioni, controllare l'affidabilità. Corrispondono il 9.7 e il 9.8. Una precisazione importante, indicata dal documento: è uno schema didattico. Il lavoro analitico reale è iterativo: un'anomalia trovata nell'analisi può riportare alla preparazione dei dati, un grafico può suggerire una nuova domanda, un'interpretazione può richiedere un nuovo calcolo. Nelle slide, un indicatore in alto a destra ricorda la fase di cui stiamo parlando.");
    const st = [["FiDatabase", "Comprendere e preparare", "Disponibilità, struttura, definizioni, qualità", "9.1  9.2"], ["FiCpu", "Elaborare e analizzare", "Operazioni, indicatori, tendenze, anomalie", "9.3  9.4"], ["FiBarChart2", "Rappresentare e prevedere", "Visualizzazioni, scenari, stime", "9.5  9.6"], ["FiCheckCircle", "Interpretare e valutare", "Significato, scelte, affidabilità", "9.7  9.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.2, 2.1, 2.75, dark ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.7, 1.35, 0.7, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.1, y: 2.15, w: 1.9, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.8, w: 1.8, h: 0.6, fontSize: 11, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.1, y: 3.5, w: 1.9, h: 0.35, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.4, 0.17);
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.accent6, "iterazione");
    txt(s, [{ text: "Uno schema didattico: ", options: { bold: true, color: C.accent1 } }, { text: "il lavoro analitico reale è iterativo. Un'anomalia riporta ai dati, un grafico suggerisce una nuova domanda.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Quattro tipi di analisi", "Una distinzione che attraversa tutto il modulo, e che compare tra i risultati attesi: i quattro tipi di analisi. L'analisi descrittiva risponde alla domanda 'che cosa è successo?': quanto abbiamo venduto, in quali regioni, con quale andamento. L'analisi diagnostica risponde a 'perché è successo?': quali fattori spiegano il calo delle vendite in una regione. L'analisi predittiva risponde a 'che cosa potrebbe succedere?': quanto venderemo nel prossimo trimestre, con quale margine di incertezza. L'analisi prescrittiva risponde a 'che cosa conviene fare?': quale prezzo fissare, quanto ordinare, dove investire. I quattro tipi hanno un valore crescente per le decisioni, ma anche un grado crescente di incertezza e di dipendenza dalle ipotesi. Descrivere i dati è relativamente oggettivo, se i dati sono corretti. Spiegare richiede di distinguere correlazione e causalità. Prevedere richiede ipotesi sul futuro. Prescrivere richiede anche criteri di valore, cioè che cosa consideriamo un buon risultato. Uno degli errori più frequenti nell'uso dell'AI per l'analisi è passare da un tipo all'altro senza accorgersene: una descrizione diventa una spiegazione, una spiegazione diventa una raccomandazione.");
    const t = [["Descrittiva", "Che cosa è successo?", "Vendite per regione e mese"], ["Diagnostica", "Perché è successo?", "Fattori del calo in una regione"], ["Predittiva", "Che cosa potrebbe succedere?", "Vendite del prossimo trimestre"], ["Prescrittiva", "Che cosa conviene fare?", "Prezzo, ordini, investimenti"]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 2.3, y = 1.2 + (3 - i) * 0.3;
      const f = [C.background2, C.accent6, C.accent2, C.accent1][i];
      const fc = i >= 2 ? C.background1 : C.text1;
      shapeBox(s, x, y, 2.15, 2.4 - (3 - i) * 0.3 + 0.3, f, e[0]);
      txt(s, e[0], { x: x + 0.15, y: y + 0.1, w: 1.9, h: 0.38, fontSize: 15, bold: true, color: i >= 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: y + 0.5, w: 1.9, h: 0.5, fontSize: 12, bold: true, color: fc });
      txt(s, e[2], { x: x + 0.15, y: y + 1.0, w: 1.9, h: 0.5, fontSize: 11, italic: true, color: fc });
    });
    txt(s, "Valore per le decisioni, incertezza e dipendenza dalle ipotesi crescono", { x: 0.5, y: 4.05, w: 6.0, h: 0.4, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 6.6, y: 4.09, w: 2.9, h: 0.32, fill: { color: C.accent5 }, line: { type: "none" }, objectName: "freccia crescita" });
    txt(s, "Errore frequente: passare da un tipo all'altro senza accorgersene.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, previsioni e simulazioni, con priorità media. Vanno compresi e sperimentati: preparazione dei dati, analisi descrittiva, elaborazioni quantitative, tendenze, grafici e interpretazione critica. Vanno conosciuti e compresi: previsioni, simulazioni, correlazioni, incertezza, differenza tra analisi e raccomandazione. Vanno solo accennati: algoritmi statistici specialistici, modellazione avanzata, programmazione analitica complessa e architetture di Business Intelligence. Confini: non ripetiamo i principi del Machine Learning del Tema 2, la teoria degli errori del Tema 3, le tecniche di prompting del Tema 6, i metodi generali di verifica del Tema 7, che qui applichiamo ai dati. Non duplichiamo l'analisi documentale del Tema 8. Il confine principale è con il Tema 14: qui esploriamo che cosa si può fare con i dati grazie all'AI; il Tema 14 tratterà le condizioni organizzative e tecnologiche per renderli disponibili. La selezione e la valutazione economica dei progetti appartengono al Tema 15. Un'avvertenza pratica valida per tutto il modulo: i dati aziendali, specialmente se personali o riservati, vanno caricati solo negli strumenti autorizzati.");
    pathSlide(s, [["9.1", "L'AI come supporto all'analisi", "Alta"], ["9.2", "Preparazione e qualità dei dati", "Alta"], ["9.3", "Elaborazione quantitativa", "Alta"], ["9.4", "Pattern, tendenze e anomalie", "Alta"], ["9.5", "Visualizzazione e comunicazione", "Alta"], ["9.6", "Previsioni e simulazioni", "Media"], ["9.7", "Interpretazione e decisioni", "Alta"], ["9.8", "Limiti e affidabilità", "Alta"]],
      [["Comprendere e sperimentare", "Preparazione, analisi descrittiva, elaborazioni, tendenze, grafici, interpretazione", C.accent1, C.background1], ["Conoscere e comprendere", "Previsioni, simulazioni, correlazioni, incertezza, analisi e raccomandazione", C.accent6, C.text1], ["Solo accennare", "Algoritmi specialistici, modellazione avanzata, programmazione complessa, BI", C.background2, C.text1]]);
  }

  // =====================================================================
  section("9.1 AI e analisi");
  divider("9.1", "L'AI come supporto all'analisi dei dati", "Rendere più facile interrogare i dati non equivale a rendere corretta la loro interpretazione", "Partiamo dal quadro generale: che ruolo può avere l'AI nel lavoro con i dati. In questo sottotema, da comprendere, distinguiamo dati, informazioni e conoscenza, collochiamo l'AI rispetto all'analisi dei dati tradizionale e alla Business Intelligence, vediamo che cosa significa interrogare i dati in linguaggio naturale e affrontiamo la prima integrazione del tema: la democratizzazione dell'analisi, cioè la possibilità per chi non è specialista di fare analisi che prima richiedevano competenze tecniche. Con le sue opportunità e con le sue condizioni.");
  {
    const s = content("Dati, informazioni, conoscenza", "Nel Tema 8 abbiamo distinto dati, informazioni, documenti e conoscenza. Qui riprendiamo la distinzione dal punto di vista dei numeri. Un dato è un valore elementare registrato: 1.240, una data, un codice cliente. Diventa informazione quando ha un significato e un contesto: 'nel mese di marzo, il negozio di Bologna ha venduto 1.240 pezzi'. Diventa conoscenza quando permette di capire e agire: 'le vendite di Bologna sono calate del 15 per cento rispetto a marzo dell'anno scorso, mentre le altre sedi sono stabili; il calo coincide con l'apertura di un concorrente, e conviene valutare un'azione commerciale mirata'. Il passaggio da un livello all'altro non è automatico: richiede di sapere che cosa misura il dato, di scegliere confronti significativi, di interpretare il risultato alla luce del contesto. L'analisi dei dati è proprio il lavoro che compie questi passaggi. L'AI può aiutare in ciascuno di essi, ma il passaggio più delicato, dall'informazione alla conoscenza, dipende dalla conoscenza del dominio: sapere che è arrivato un concorrente, che marzo dell'anno scorso aveva una promozione, che il dato di Bologna include le vendite online.");
    phaseTag(s, 0);
    const lv = [["Dato", "1.240"], ["Informazione", "Marzo, Bologna: 1.240 pezzi venduti"], ["Conoscenza", "Calo del 15% sull'anno, solo a Bologna, con l'arrivo di un concorrente: valutare un'azione mirata"]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.82, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.0, h: 0.82, fontSize: 15, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 2.7, y, w: 6.6, h: 0.82, fontSize: i ? 13 : 20, bold: i === 0, color: i === 2 ? C.background1 : C.text1, valign: "middle" });
    });
    banner(s, 4.1, "Dall'informazione alla conoscenza serve il dominio: un concorrente, una promozione dell'anno scorso, che cosa include il dato.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Analisi dei dati e BI", "Prima dell'AI generativa, l'analisi dei dati in azienda si basava su strumenti e figure consolidate. I fogli di calcolo, usati da quasi tutti, per calcoli, tabelle e grafici. Gli strumenti di Business Intelligence, che raccolgono dati da diversi sistemi aziendali e li presentano in report e cruscotti, con indicatori definiti e aggiornati periodicamente. Gli strumenti statistici e i linguaggi di programmazione, usati dagli analisti per analisi più complesse. E le persone: analisti, controller, data scientist, che conoscono i dati, i metodi e gli strumenti. In questo quadro, chi non aveva competenze tecniche dipendeva dai report predefiniti o dalla disponibilità degli analisti. L'AI non sostituisce questi strumenti, ma si inserisce in modi diversi: come assistente nei fogli di calcolo, che suggerisce formule e grafici; come interfaccia in linguaggio naturale verso gli strumenti di BI; come assistente conversazionale che riceve un file e lo analizza scrivendo ed eseguendo codice; come supporto agli analisti nella scrittura di codice. Le architetture di BI e l'integrazione con i sistemi aziendali sono solo da accennare: appartengono al Tema 14.");
    phaseTag(s, 0);
    txt(s, "Strumenti consolidati", { x: 0.5, y: 1.12, w: 4.35, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const tr = [["FiGrid", "Fogli di calcolo", "Calcoli, tabelle, grafici"], ["FiPieChart", "Business Intelligence", "Report e cruscotti con indicatori definiti"], ["FiTerminal", "Strumenti statistici e codice", "Analisi complesse, per specialisti"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.5 + i * 0.78;
      shapeBox(s, 0.5, y, 4.35, 0.68, C.background2, tr[i][1]);
      await iconCircle(s, 0.62, y + 0.11, 0.46, tr[i][0], C.accent2);
      txt(s, tr[i][1], { x: 1.2, y: y + 0.05, w: 3.5, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
      txt(s, tr[i][2], { x: 1.2, y: y + 0.35, w: 3.5, h: 0.3, fontSize: 11, color: C.text2 });
    }
    txt(s, "Dove si inserisce l'AI", { x: 5.15, y: 1.12, w: 4.35, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    const ai = ["Assistente nei fogli di calcolo", "Linguaggio naturale verso la BI", "Assistente che analizza un file con codice", "Supporto agli analisti nel codice"];
    ai.forEach((t, i) => chip(s, 5.15, 1.5 + i * 0.585, 4.35, 0.5, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.0, "L'AI non sostituisce questi strumenti: vi si inserisce. Architetture di BI e integrazioni: Tema 14.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Il ruolo dell'AI nel processo", "Vediamo dove l'AI può intervenire lungo il processo analitico. Formulare la domanda: aiutare a chiarire che cosa si vuole sapere e quali dati servono. Comprendere i dati: descrivere la struttura di un file, il significato probabile delle colonne, i problemi evidenti. Preparare i dati: suggerire o eseguire pulizia, conversioni, unioni tra tabelle. Elaborare: calcolare indicatori, aggregazioni, statistiche, scrivere formule o codice. Individuare fenomeni: tendenze, anomalie, relazioni. Rappresentare: proporre e creare grafici, tabelle riepilogative, report. Interpretare: proporre spiegazioni, ipotesi, implicazioni. In ciascuna fase l'AI può accelerare molto il lavoro. Ma il suo contributo cambia natura lungo il processo. Nelle prime fasi, il rischio principale è tecnico: un dato interpretato male, un calcolo sbagliato. Nelle ultime fasi, il rischio diventa interpretativo: una spiegazione plausibile ma infondata, una conclusione che va oltre i dati. Ed è proprio nelle ultime fasi che il contributo umano, con la conoscenza del contesto e il giudizio, diventa più importante.");
    phaseTag(s, 0);
    const st = ["Domanda", "Comprendere i dati", "Preparare", "Elaborare", "Individuare fenomeni", "Rappresentare", "Interpretare"];
    st.forEach((t, i) => {
      const x = 0.5 + i * 1.3;
      chip(s, x, 1.3, 1.18, 0.8, t, { fill: i < 4 ? C.background2 : (i < 6 ? C.accent6 : C.accent1), color: i === 6 ? C.background1 : C.text1, fontSize: 11 });
    });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 0.5, y: 2.25, w: 9.0, h: 0.3, fill: { color: C.accent3 }, line: { type: "none" }, objectName: "freccia processo" });
    await card(s, 0.5, 2.75, 4.35, 1.6, { icon: "FiCpu", inline: true, head: "Rischio tecnico", headSize: 14, bodySize: 12, body: "Nelle prime fasi: un dato interpretato male, un calcolo sbagliato." });
    await card(s, 5.15, 2.75, 4.35, 1.6, { icon: "FiMessageCircle", inline: true, head: "Rischio interpretativo", headSize: 14, bodySize: 12, fill: C.accent6, body: "Nelle ultime fasi: una spiegazione plausibile ma infondata, una conclusione oltre i dati." });
    txt(s, "Più si avanza nel processo, più conta il contributo umano: contesto e giudizio.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Domande in linguaggio naturale", "La novità più visibile dell'AI nell'analisi è la possibilità di interrogare i dati ponendo domande in linguaggio naturale, invece di scrivere formule, interrogazioni o codice. L'esempio fittizio in slide mostra una domanda e ciò che il sistema deve fare per rispondere. Sembra semplice, ma per rispondere il sistema deve tradurre la domanda in operazioni precise, e in questa traduzione compie delle scelte. Che cosa significa 'clienti'? Tutti quelli in anagrafica o quelli con almeno un acquisto? 'Ultimo trimestre' è il trimestre solare o gli ultimi novanta giorni? 'Hanno speso di più' significa fatturato lordo o netto di resi e sconti? Ogni scelta è ragionevole, ma una scelta diversa produce un risultato diverso. Il problema è che queste scelte spesso non sono visibili nella risposta: si vede un elenco ordinato di clienti, non le ipotesi che lo hanno prodotto. Per questo, una buona pratica è chiedere al sistema di esplicitare come ha interpretato la domanda e quali operazioni ha eseguito, oppure formulare la domanda in modo più preciso fin dall'inizio, usando le definizioni aziendali.");
    phaseTag(s, 0);
    docBox(s, 0.5, 1.15, 9.0, 0.75, "Domanda (esempio fittizio)", "Quali sono i dieci clienti che hanno speso di più nell'ultimo trimestre?", { fontSize: 14 });
    txt(s, "Le scelte nascoste nella traduzione in operazioni", { x: 0.5, y: 2.05, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const q = [["Clienti", "In anagrafica o con almeno un acquisto?"], ["Ultimo trimestre", "Trimestre solare o ultimi 90 giorni?"], ["Speso di più", "Fatturato lordo o netto di resi e sconti?"]];
    q.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.45, 2.86, 1.15, C.accent6, e[0]);
      txt(s, "'" + e[0] + "'", { x: x + 0.15, y: 2.52, w: 2.56, h: 0.38, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 2.92, w: 2.56, h: 0.6, fontSize: 12, color: C.text1 });
    });
    banner(s, 3.8, "Ogni scelta è ragionevole, ma cambia il risultato. Chiedere come è stata interpretata la domanda, o usare le definizioni aziendali.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Analisi tradizionale e assistita", "Confrontiamo analisi tradizionale e analisi assistita dall'AI. Nell'analisi tradizionale, chi analizza sceglie ed esegue ogni operazione: scrive la formula, costruisce la tabella pivot, sceglie il grafico. Il processo è lento e richiede competenze tecniche, ma ogni passaggio è esplicito e controllabile, e chi analizza sa esattamente che cosa ha fatto. Nell'analisi assistita, si formula la richiesta e il sistema sceglie ed esegue le operazioni. Il processo è molto più rapido e accessibile, ma i passaggi possono essere meno visibili: le scelte di metodo sono state fatte dal sistema, e bisogna ricostruirle per controllarle. Un modo per dirlo: nell'analisi tradizionale il rischio è non riuscire a fare l'analisi; in quella assistita il rischio è fare un'analisi senza sapere esattamente quale. Non si tratta di scegliere l'una o l'altra: nella pratica si combinano. L'AI accelera esplorazione e prime elaborazioni; per i risultati importanti, si rendono espliciti metodo e passaggi, e si controllano. La tracciabilità delle operazioni, che vedremo nel 9.3, è il ponte tra i due approcci.");
    phaseTag(s, 0);
    table(s, [["", "Analisi tradizionale", "Analisi assistita dall'AI"],
      ["Chi sceglie le operazioni", "Chi analizza", "Il sistema, dalla richiesta"],
      ["Velocità", "Lenta", "Molto rapida"],
      ["Competenze tecniche", "Necessarie", "Ridotte"],
      ["Visibilità dei passaggi", "Esplicita", "Da ricostruire"],
      ["Rischio tipico", "Non riuscire a fare l'analisi", "Fare un'analisi senza sapere quale"]],
      { y: 1.15, colW: [2.6, 3.0, 3.4], rowH: 0.45, fontSize: 12, accentCol: 2 });
    banner(s, 4.05, "Nella pratica si combinano. La tracciabilità delle operazioni è il ponte tra i due approcci.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("La democratizzazione dell'analisi", "Prima integrazione del tema: la democratizzazione dell'analisi dei dati. Il linguaggio naturale riduce le barriere tecniche: un responsabile commerciale può analizzare le vendite della sua area senza chiedere un report all'ufficio controllo; un responsabile del personale può esplorare i dati sulle assenze; chiunque può farsi spiegare un foglio di calcolo ricevuto. È un'opportunità reale: più persone possono rispondere alle proprie domande, più rapidamente, con i dati invece che con le impressioni. Ma il documento di perimetro precisa che il linguaggio naturale riduce le barriere tecniche senza eliminare il bisogno di competenze interpretative e giudizio critico. Le barriere tecniche erano anche, in parte, una protezione: chi sapeva fare un'analisi sapeva di solito anche riconoscerne i limiti. Ora chi non ha competenze analitiche può ottenere risultati che non è in grado di valutare: un confronto tra gruppi non omogenei, una media influenzata da pochi valori estremi, una correlazione presentata come causa. La consapevolezza del sottotema lo dice in una frase: rendere più facile interrogare i dati non equivale a rendere automaticamente corretta la loro interpretazione.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.45, { icon: "FiUsers", head: "Che cosa diventa possibile", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Analizzare le vendite della propria area", "Esplorare dati senza chiedere un report", "Farsi spiegare un foglio di calcolo", "Decidere con i dati, non con le impressioni"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.45, { icon: "FiAlertTriangle", head: "Che cosa resta necessario", headSize: 15, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Riconoscere gruppi non confrontabili", "Diffidare di medie influenzate da pochi valori", "Non leggere una correlazione come causa", "Sapere quando chiedere a uno specialista"], { space: 4 }) });
    banner(s, 3.85, "Il linguaggio naturale riduce le barriere tecniche, non il bisogno di competenze interpretative e giudizio critico.", { h: 0.7, fontSize: 13 });
    txt(s, "Integrazione C: democratizzazione dell'analisi dei dati", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Competenze umane e dominio", "Se la tecnica diventa meno necessaria, quali competenze restano centrali? Il sottotema ne indica due famiglie. Le competenze analitiche di base: sapere che cosa si può e non si può concludere da un insieme di dati, riconoscere i confronti non omogenei, distinguere media e mediana, sapere che pochi dati danno risultati instabili, distinguere correlazione e causalità. Non serve diventare statistici, ma conoscere i principali modi in cui un'analisi può ingannare. La conoscenza del dominio: sapere come sono stati raccolti i dati, che cosa misurano davvero, quali eventi possono spiegarne l'andamento, quali valori sono plausibili, quali definizioni usa l'azienda. È la conoscenza che permette di accorgersi che un aumento improvviso coincide con un cambio di sistema gestionale, che un calo stagionale è normale, che un indicatore è calcolato in modo diverso da un anno all'altro. L'AI non possiede questa conoscenza, a meno che non le venga fornita, e anche in quel caso non ne ha l'esperienza. In sintesi: con l'AI cambia il peso relativo delle competenze. Meno tecnica, più interpretazione e conoscenza del contesto.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.65, { icon: "FiBookOpen", head: "Competenze analitiche di base", headSize: 15, bodySize: 12,
      body: bullets(["Che cosa si può concludere", "Confronti omogenei, media e mediana", "Pochi dati, risultati instabili", "Correlazione e causalità"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.65, { icon: "FiBriefcase", head: "Conoscenza del dominio", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Come sono stati raccolti i dati", "Che cosa misurano davvero", "Eventi, stagionalità, cambi di sistema", "Valori plausibili, definizioni aziendali"], { space: 4 }) });
    shapeBox(s, 0.5, 4.05, 9.0, 0.9, C.text1, "peso competenze");
    txt(s, [{ text: "Con l'AI cambia il peso delle competenze: ", options: { color: C.background1 } }, { text: "meno tecnica, più interpretazione e contesto.", options: { color: C.accent6, bold: true } }], { x: 0.7, y: 4.05, w: 8.6, h: 0.9, fontSize: 15, valign: "middle" });
  }
  keySlide("Rendere più facile interrogare dati non equivale a rendere automaticamente corretta la loro interpretazione.", "Sottotema 9.1  ·  L'AI come supporto all'analisi dei dati", "Concetto chiave del primo sottotema. L'AI si inserisce lungo tutto il processo analitico e lo rende accessibile anche a chi non è specialista, grazie al linguaggio naturale. È una democratizzazione reale e di grande valore. Ma ogni domanda in linguaggio naturale viene tradotta in operazioni con scelte implicite, i passaggi sono meno visibili che nell'analisi tradizionale, e il rischio si sposta dalla tecnica all'interpretazione. Restano centrali le competenze analitiche di base e, soprattutto, la conoscenza del dominio. Esercizio suggerito: dare ai partecipanti una domanda in linguaggio naturale su un dataset fittizio e chiedere di elencare tutte le interpretazioni possibili dei termini, poi confrontare i risultati ottenuti con interpretazioni diverse.");

  // =====================================================================
  section("9.2 Preparazione e qualità");
  divider("9.2", "Comprensione, preparazione e qualità dei dati", "Un dataset apparentemente ordinato non è necessariamente corretto, completo o rappresentativo", "Prima di analizzare i dati, bisogna capirli e prepararli. È la fase meno visibile e spesso la più lunga del lavoro analitico, ed è anche quella in cui nascono molti degli errori che si ritrovano nelle conclusioni. In questo sottotema, da comprendere e sperimentare, vediamo i tipi di dati e di formati, come comprendere la struttura di un dataset, i problemi tipici di qualità, come dati mancanti, duplicati e valori anomali, la pulizia e la trasformazione, la rappresentatività del campione, l'importanza delle definizioni e della provenienza. E una distinzione che il documento di perimetro chiede di rendere esplicita: dati, metriche e indicatori.");
  {
    const s = content("Tipi di dati e formati", "Una prima distinzione, già incontrata nel Tema 8. I dati strutturati sono organizzati in righe e colonne con un significato definito: una tabella di vendite, un elenco di clienti, un registro di presenze. I dati non strutturati sono testi, email, documenti, immagini, registrazioni: contengono informazioni, ma non in forma direttamente calcolabile. Nel Tema 8 abbiamo visto come l'AI può trasformare i secondi nei primi; qui ci concentriamo sui dati strutturati. I formati più comuni sono tre. Il foglio di calcolo, come Excel, che può contenere più fogli, formule, formattazioni, celle unite, note: molto flessibile, e proprio per questo spesso disordinato. Il file CSV, cioè valori separati da virgole o punti e virgola: un formato semplice, solo dati, senza formule né formattazioni, molto usato per esportare dati dai sistemi. Le tabelle dei database e dei sistemi gestionali, a cui si accede di solito attraverso esportazioni o strumenti di BI. Un dataset, nel linguaggio dell'analisi, è un insieme di dati organizzato per un'analisi: per esempio l'esportazione delle vendite dell'ultimo anno.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 1.6, { icon: "FiGrid", inline: true, head: "Dati strutturati", headSize: 15, bodySize: 12, fill: C.accent6, body: "Righe e colonne con un significato definito: vendite, clienti, presenze." });
    await card(s, 5.15, 1.2, 4.35, 1.6, { icon: "FiFileText", inline: true, head: "Dati non strutturati", headSize: 15, bodySize: 12, body: "Testi, email, immagini, registrazioni. Trasformarli in dati: Tema 8." });
    const f = [["Foglio di calcolo", "Più fogli, formule, celle unite, note: flessibile e spesso disordinato"], ["CSV", "Solo dati separati da un carattere: semplice, usato per le esportazioni"], ["Database e gestionali", "Accesso con esportazioni o strumenti di BI"]];
    f.forEach((e, i) => {
      const y = 3.0 + i * 0.62;
      shapeBox(s, 0.5, y, 9.0, 0.54, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.5, h: 0.54, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.2, y, w: 6.1, h: 0.54, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Comprendere la struttura", "Il primo uso dell'AI su un dataset è spesso semplicemente capirlo: di che cosa parla, che cosa rappresenta ogni riga, che cosa contiene ogni colonna, quali problemi ci sono. È molto utile quando si riceve un file preparato da altri, o un'esportazione da un sistema poco conosciuto. L'AI può descrivere la struttura, ipotizzare il significato delle colonne dai nomi e dai valori, segnalare righe di totale mescolate ai dati, intestazioni su più righe, celle unite, colonne vuote. L'esempio fittizio in slide mostra un piccolo estratto con alcuni problemi tipici. Una cautela importante: il significato delle colonne è un'ipotesi del sistema. 'Importo' è con o senza IVA? 'Data' è la data dell'ordine, della consegna o della fattura? 'Stato 3' che cosa significa? Il sistema può proporre un'interpretazione plausibile, ma solo chi conosce il dato, o la documentazione del sistema da cui proviene, può confermarla. Un errore in questa fase si propaga a tutta l'analisi: se 'Importo' è interpretato come netto mentre è lordo, ogni calcolo successivo sarà sbagliato, e in modo coerente, quindi difficile da notare.");
    phaseTag(s, 0);
    table(s, [["Data", "Cliente", "Importo", "Stato"],
      ["03/04/2025", "Rossi Srl", "1.200", "3"],
      ["2025-04-05", "ROSSI S.R.L.", "980", "3"],
      ["07/04/2025", "Bianchi Spa", "", "2"],
      ["Totale", "", "2.180", ""]],
      { x: 0.5, y: 1.15, w: 5.0, colW: [1.3, 1.5, 1.1, 1.1], rowH: 0.4, fontSize: 12, blankCorner: false });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.2, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    const iss = ["Due formati di data", "Lo stesso cliente scritto in due modi", "Un importo mancante", "Una riga di totale tra i dati", "'Stato 3': che cosa significa?"];
    iss.forEach((t, i) => chip(s, 5.75, 1.15 + i * 0.42, 3.75, 0.36, t, { fill: C.accent6, fontSize: 11 }));
    banner(s, 3.6, "Il significato delle colonne è un'ipotesi del sistema: 'Importo' con o senza IVA? 'Data' dell'ordine o della fattura? Lo conferma solo chi conosce il dato.", { h: 0.9, fontSize: 12 });
    txt(s, "Un errore qui si propaga a tutta l'analisi, in modo coerente e quindi difficile da notare.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Variabili e formati", "Ogni colonna di un dataset rappresenta una variabile, e il tipo di variabile determina quali operazioni hanno senso. Le variabili numeriche continue, come importi, pesi, durate, si possono sommare, mediare, confrontare. Le variabili numeriche discrete, come numero di pezzi o di ordini, sono conteggi. Le variabili categoriche, come regione, prodotto, canale, servono a raggruppare: non ha senso farne la media. Le variabili ordinali, come una valutazione da 1 a 5 o un livello di priorità, hanno un ordine, ma la distanza tra i livelli non è necessariamente uguale: la media di una scala di soddisfazione va usata con cautela. Le date richiedono attenzione particolare. Alcuni problemi di formato tipici, che l'AI deve riconoscere correttamente e che conviene controllare: numeri memorizzati come testo, che non vengono sommati; separatori decimali diversi, come la virgola italiana e il punto anglosassone, per cui 1.200 può essere milleduecento o uno virgola due; date in formati diversi, come 03/04 che può essere 3 aprile o 4 marzo; codici numerici, come CAP o codici prodotto, trattati come numeri, con la perdita degli zeri iniziali.");
    phaseTag(s, 0);
    table(s, [["Tipo di variabile", "Esempi", "Operazioni sensate"],
      ["Numerica continua", "Importi, durate, pesi", "Somme, medie, confronti"],
      ["Numerica discreta", "Pezzi, ordini", "Conteggi, somme"],
      ["Categorica", "Regione, prodotto, canale", "Raggruppare, contare"],
      ["Ordinale", "Valutazione 1-5, priorità", "Ordinare; medie con cautela"]],
      { y: 1.15, colW: [2.5, 3.0, 3.5], rowH: 0.42, fontSize: 12, blankCorner: false });
    txt(s, "Problemi di formato da controllare", { x: 0.5, y: 3.35, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    const p = ["Numeri come testo", "1.200: mille o uno virgola due?", "03/04: marzo o aprile?", "CAP senza zeri iniziali"];
    p.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.75, 2.15, 0.6, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Il tipo di variabile determina quali operazioni hanno senso.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Mancanti, duplicati, anomali", "Tre problemi di qualità ricorrenti, che l'AI può aiutare molto a individuare. I dati mancanti: celle vuote, o valori convenzionali come zero, 'n.d.', 999. Il punto chiave è che un dato mancante non è uno zero: se un importo mancante viene trattato come zero, la media si abbassa; se viene escluso, il conteggio cambia. Bisogna anche chiedersi perché manca: se mancano soprattutto i dati di una sede o di un periodo, l'analisi può risultare distorta. I duplicati: la stessa riga presente due volte, magari per un'esportazione ripetuta, o lo stesso cliente registrato con nomi leggermente diversi. I duplicati gonfiano totali e conteggi. I valori anomali: valori molto lontani dagli altri, come un ordine da un milione tra ordini da mille euro. Possono essere errori, come una virgola spostata, o casi reali e importanti, come un grande cliente. I valori incoerenti: una data di consegna precedente all'ordine, un'età di 150 anni, una quantità negativa. L'AI è efficace nel segnalare questi casi. Ma la decisione su come trattarli, cioè eliminare, correggere, tenere o analizzare a parte, richiede di conoscere il contesto, e va presa consapevolmente, non lasciata al sistema.");
    phaseTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMinusCircle", head: "Mancanti", body: "Un dato mancante non è uno zero. E perché manca?" },
      { icon: "FiCopy", head: "Duplicati", body: "Righe ripetute, nomi diversi per lo stesso cliente" },
      { icon: "FiZap", head: "Anomali", body: "Errore o caso reale importante? Va capito" },
      { icon: "FiXOctagon", head: "Incoerenti", body: "Consegna prima dell'ordine, quantità negative" },
    ], 4, { y: 1.2, h: 2.0, headSize: 14, bodySize: 12 });
    banner(s, 3.45, "L'AI li segnala bene. Ma eliminare, correggere, tenere o analizzare a parte è una decisione che richiede il contesto.", { h: 0.85, fontSize: 13 });
    txt(s, "Un importo mancante trattato come zero abbassa la media; escluso, cambia il conteggio.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Pulizia e trasformazione", "Una volta individuati i problemi, i dati vanno preparati. Le operazioni principali sono tre. La pulizia: eliminare duplicati, correggere errori evidenti, gestire i mancanti, rimuovere righe di totale o di intestazione. La normalizzazione: rendere omogenei i valori, come date tutte nello stesso formato, nomi di clienti uniformati, unità di misura coerenti, categorie scritte allo stesso modo. La trasformazione: creare nuove colonne a partire da quelle esistenti, come il mese dalla data o il margine dal prezzo e dal costo, unire tabelle diverse, ristrutturare i dati per l'analisi. L'AI è molto efficace in queste operazioni, sia eseguendole direttamente sia scrivendo formule o codice. Ma ogni operazione di pulizia è una scelta che può cambiare i risultati. Unire 'Rossi Srl' e 'ROSSI S.R.L.' è corretto, ma unire due clienti diversi con nomi simili è un errore. Eliminare un valore anomale può togliere un errore o un caso importante. Unire due tabelle con una chiave sbagliata può duplicare o perdere righe senza segnali evidenti. Per questo, due regole pratiche: chiedere sempre l'elenco delle operazioni eseguite, con il numero di righe coinvolte, e conservare i dati originali, così da poter tornare indietro.");
    phaseTag(s, 0);
    const op = [["FiTrash2", "Pulizia", "Duplicati, errori, mancanti, righe di totale"], ["FiSliders", "Normalizzazione", "Formati, nomi, unità, categorie omogenei"], ["FiShuffle", "Trasformazione", "Nuove colonne, unioni tra tabelle"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.2, 2.86, 1.55, { icon: op[i][0], inline: true, head: op[i][1], headSize: 14, bodySize: 12, body: op[i][2] });
    }
    txt(s, "Ogni operazione è una scelta che può cambiare i risultati", { x: 0.5, y: 2.9, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    chip(s, 0.5, 3.3, 2.9, 0.6, "Unire due clienti diversi", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.3, 2.9, 0.6, "Eliminare un caso importante", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.3, 2.9, 0.6, "Unione con chiave sbagliata", { fill: C.background2, fontSize: 12 });
    banner(s, 4.1, "Chiedere l'elenco delle operazioni con il numero di righe coinvolte, e conservare sempre i dati originali.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Rappresentatività e distorsioni", "Un dataset può essere pulito, completo e corretto, e tuttavia non rappresentare il fenomeno che si vuole analizzare. È il problema della rappresentatività. Alcuni esempi tipici. Un questionario di soddisfazione compilato solo dai clienti che hanno voluto rispondere: rappresenta i clienti più motivati, spesso i più soddisfatti o i più scontenti. I dati di un solo canale di vendita usati per trarre conclusioni su tutti i clienti. I dati di un periodo particolare, come i mesi di una promozione o di una crisi, usati come se fossero normali. I dati dei clienti attuali, che escludono quelli persi: se si analizzano solo i clienti rimasti, si perde proprio l'informazione sul perché gli altri se ne sono andati. Quest'ultimo caso è un esempio di distorsione da sopravvivenza: si guardano solo i casi che sono sopravvissuti a una selezione. Il punto importante per chi usa l'AI è che il sistema analizza i dati che riceve, e normalmente non si chiede se rappresentano il fenomeno. Può farlo se glielo si chiede, ma la domanda su che cosa manca, chi non è nel dataset e perché, richiede di conoscere come i dati sono stati raccolti.");
    phaseTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMessageSquare", head: "Chi ha scelto di rispondere", body: "Questionari volontari: i più motivati" },
      { icon: "FiShoppingCart", head: "Un solo canale", body: "Conclusioni estese a tutti i clienti" },
      { icon: "FiCalendar", head: "Un periodo particolare", body: "Promozioni o crisi trattate come normali" },
      { icon: "FiUserX", head: "Solo chi è rimasto", body: "Distorsione da sopravvivenza: mancano i clienti persi" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Il sistema analizza i dati che riceve. Chi non è nel dataset, e perché, lo sa chi conosce come sono stati raccolti.", { h: 0.7, fontSize: 13 });
    txt(s, "Un dataset pulito e corretto può comunque non rappresentare il fenomeno.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Definizioni e provenienza", "Due aspetti della qualità dei dati che spesso non sono scritti nel file. Le definizioni: che cosa misura esattamente ogni dato? Un 'cliente attivo' è chi ha acquistato negli ultimi dodici mesi o negli ultimi sei? Un 'ordine' include quelli annullati? Il 'fatturato' è al netto dei resi? Le definizioni cambiano da un'azienda all'altra, da un reparto all'altro, e a volte nel tempo all'interno della stessa azienda. Se due dataset usano definizioni diverse, confrontarli produce risultati sbagliati con l'aspetto di risultati precisi. E se l'AI non conosce le definizioni aziendali, userà quelle più comuni, che possono essere diverse. La provenienza: da quale sistema vengono i dati, chi li ha estratti, quando, con quali filtri, che trasformazioni hanno subito? Un file che circola da mesi tra colleghi, modificato più volte, ha una provenienza incerta. Alcune domande utili prima di analizzare un dataset: da dove viene? Quando è stato estratto? Con quali criteri? Quali definizioni usa? Chi può confermarle? Fornire queste informazioni al sistema migliora l'analisi; non averle è un'incertezza da dichiarare nei risultati.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiBook", head: "Definizioni", headSize: 15, bodySize: 12,
      body: bullets(["'Cliente attivo': 12 mesi o 6?", "'Ordine': inclusi gli annullati?", "'Fatturato': al netto dei resi?"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiGitCommit", head: "Provenienza", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Da quale sistema, chi li ha estratti", "Quando, con quali filtri", "Quali trasformazioni hanno subito"], { space: 4 }) });
    txt(s, "Prima di analizzare", { x: 0.5, y: 3.55, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    const q = ["Da dove viene?", "Quando è stato estratto?", "Con quali criteri?", "Quali definizioni?", "Chi può confermarle?"];
    q.forEach((t, i) => chip(s, 0.5 + i * 1.82, 3.95, 1.7, 0.55, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Definizioni diverse producono confronti sbagliati con l'aspetto di confronti precisi.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Dati, metriche e indicatori", "Il documento di perimetro chiede di rendere esplicita una distinzione spesso confusa: dati, metriche e indicatori. Il dato è il valore registrato: il singolo ordine, con la sua data, il cliente e l'importo. La metrica è una misura calcolata dai dati con una regola definita: il fatturato mensile, il numero di ordini, il valore medio dell'ordine, il tasso di reso. L'indicatore, spesso chiamato KPI, è una metrica scelta per valutare un obiettivo, con un valore di riferimento: il valore medio dell'ordine confrontato con l'obiettivo di 250 euro, il tasso di reso con la soglia del 3 per cento. Perché la distinzione conta? Perché ogni passaggio comporta scelte. Passando dal dato alla metrica, si sceglie la formula: il valore medio dell'ordine include le spese di spedizione? I resi vengono sottratti? Passando dalla metrica all'indicatore, si sceglie che cosa conta come buon risultato, e questa è una scelta di valore, non un fatto. Quando si chiede all'AI di calcolare un indicatore, conviene fornire la definizione aziendale. Altrimenti il sistema ne userà una plausibile, e il risultato non sarà confrontabile con quello dei report ufficiali.");
    phaseTag(s, 0);
    const lv = [["Dato", "Il valore registrato", "Ordine 4471, 12 marzo, 230 €"], ["Metrica", "Misura calcolata con una regola", "Valore medio dell'ordine: 214 €"], ["Indicatore", "Metrica scelta per un obiettivo", "214 € contro l'obiettivo di 250 €"]];
    lv.forEach((l, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.85, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), l[0]);
      const fc = i === 2 ? C.background1 : C.text1;
      txt(s, l[0], { x: x + 0.15, y: 1.25, w: 2.56, h: 0.42, fontSize: 18, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, l[1], { x: x + 0.15, y: 1.7, w: 2.56, h: 0.5, fontSize: 12, bold: true, color: fc });
      txt(s, l[2], { x: x + 0.15, y: 2.25, w: 2.56, h: 0.6, fontSize: 12, italic: true, color: fc });
      if (i < 2) arrow(s, x + 2.88, 1.92, 0.17);
    });
    chip(s, 2.0, 3.15, 2.9, 0.55, "Scelta della formula", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.15, 2.9, 0.55, "Scelta di che cosa è un buon risultato", { fill: C.background2, fontSize: 12 });
    banner(s, 3.95, "Fornire all'AI le definizioni aziendali: altrimenti ne userà di plausibili, e il risultato non sarà confrontabile con i report ufficiali.", { h: 0.9, fontSize: 13 });
  }
  keySlide("Un dataset apparentemente ordinato non è necessariamente corretto, completo o rappresentativo del fenomeno analizzato.", "Sottotema 9.2  ·  Comprensione, preparazione e qualità dei dati", "Concetto chiave del sottotema 9.2. Prima dell'analisi vengono la comprensione e la preparazione dei dati: struttura, tipi di variabili, formati, mancanti, duplicati, anomalie, pulizia e trasformazione. L'AI è un aiuto prezioso per individuare problemi e preparare i dati, ma ogni operazione di pulizia è una scelta, il significato delle colonne è un'ipotesi da confermare, e la rappresentatività del dataset non si vede guardando i dati. Definizioni e provenienza, e la distinzione tra dati, metriche e indicatori, sono condizioni per risultati confrontabili. Esercizio suggerito: dare ai partecipanti un piccolo file fittizio con problemi di qualità nascosti, come date in due formati, un duplicato con nome diverso, un mancante e un valore anomalo, e chiedere di farlo analizzare all'AI prima e dopo una richiesta esplicita di controllo della qualità.");

  // =====================================================================
  section("9.3 Elaborazione");
  divider("9.3", "Elaborazione e analisi quantitativa", "Metodo, dati e passaggi di elaborazione sono determinanti per l'affidabilità di un risultato numerico", "Con i dati compresi e preparati, passiamo all'elaborazione: calcoli, aggregazioni, indicatori, confronti, statistiche descrittive. In questo sottotema, da comprendere e sperimentare, vediamo che cosa l'AI può calcolare e come, ma soprattutto affrontiamo l'integrazione più importante del tema: la differenza tra un calcolo effettivamente eseguito e un numero generato linguisticamente. È una distinzione che ogni utilizzatore dovrebbe conoscere, perché i due risultati hanno lo stesso aspetto ma un'affidabilità molto diversa. Nel Tema 7 abbiamo visto come verificare dati e calcoli in generale; qui guardiamo a come l'AI li produce.");
  {
    const s = content("Le operazioni tipiche", "Le operazioni quantitative più comuni nell'analisi aziendale sono poche, e l'AI può eseguirle tutte. I calcoli sulle righe: per ogni ordine, il margine come differenza tra prezzo e costo, l'importo con IVA, i giorni tra ordine e consegna. Le aggregazioni: somme, conteggi, medie, minimi e massimi su un insieme di righe, come il fatturato totale o il numero di ordini. I raggruppamenti: le stesse aggregazioni per categoria, come il fatturato per regione, per prodotto, per mese. È l'operazione che nei fogli di calcolo si fa con le tabelle pivot. Gli indicatori: percentuali, rapporti, variazioni, come la quota di una regione sul totale, il tasso di reso, la crescita rispetto all'anno precedente. I confronti: tra periodi, tra gruppi, tra categorie, rispetto a un obiettivo. Queste operazioni sono semplici dal punto di vista matematico, ma ciascuna richiede scelte: quali righe includere, come trattare i mancanti, rispetto a quale base calcolare una percentuale, quali periodi confrontare. Ed è nelle scelte, più che nell'aritmetica, che nascono gli errori più frequenti.");
    phaseTag(s, 1);
    await iconGrid(s, [
      { icon: "FiHash", head: "Calcoli sulle righe", body: "Margine, importo con IVA, giorni di consegna" },
      { icon: "FiPlusSquare", head: "Aggregazioni", body: "Somme, conteggi, medie, minimi, massimi" },
      { icon: "FiLayers", head: "Raggruppamenti", body: "Per regione, prodotto, mese: le tabelle pivot" },
      { icon: "FiPercent", head: "Indicatori", body: "Quote, tassi, rapporti, variazioni" },
      { icon: "FiColumns", head: "Confronti", body: "Tra periodi, gruppi, categorie, obiettivi" },
      { icon: "FiHelpCircle", head: "Scelte", body: "Quali righe, quali mancanti, quale base, quali periodi" , fill: C.accent6},
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Matematicamente semplici. Gli errori nascono più nelle scelte che nell'aritmetica.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Percentuali, rapporti, variazioni", "Gli indicatori relativi sono i più usati e anche i più fraintesi. Nel Tema 7 abbiamo visto la differenza tra punti percentuali e variazioni relative. Qui aggiungiamo tre attenzioni specifiche per l'analisi assistita. La base della percentuale: 'il 30 per cento dei reclami riguarda le consegne' e 'il 30 per cento delle consegne genera reclami' sono affermazioni molto diverse, ma una richiesta vaga può produrre l'una o l'altra. Bisogna sempre chiedersi: percentuale di che cosa? Le variazioni su basi piccole: passare da 2 a 6 reclami è un aumento del 200 per cento, che sembra allarmante ma riguarda quattro casi. Conviene sempre affiancare la variazione percentuale ai valori assoluti. Il periodo di confronto: una crescita rispetto al mese precedente può essere stagionale; rispetto allo stesso mese dell'anno precedente è più significativa. E il periodo scelto può cambiare la conclusione: rispetto all'anno scorso siamo in crescita, rispetto a due anni fa in calo. Quando l'AI produce un indicatore, conviene controllare la formula usata, la base e il periodo di confronto, e chiedere sempre anche i valori assoluti.");
    phaseTag(s, 1);
    const at = [["Percentuale di che cosa?", "'30% dei reclami riguarda le consegne' non è '30% delle consegne genera reclami'"], ["Basi piccole", "Da 2 a 6 reclami: +200%, ma sono quattro casi. Affiancare i valori assoluti"], ["Periodo di confronto", "Sul mese precedente: stagionalità. Sull'anno precedente: più significativo"]];
    at.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.85, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.9, h: 0.85, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.6, y, w: 5.7, h: 0.85, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 4.1, "Controllare formula, base e periodo, e chiedere sempre anche i valori assoluti.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Statistiche descrittive di base", "L'analisi descrittiva riassume i dati con poche misure. Le principali, che conviene conoscere anche senza essere statistici, sono di due tipi. Misure di posizione: la media, cioè la somma divisa per il numero dei valori; la mediana, cioè il valore centrale, che divide i dati a metà. Misure di dispersione: il minimo e il massimo, la deviazione standard, che indica quanto i valori si allontanano in media dalla media. Il grafico in slide mostra un esempio fittizio: il valore degli ordini di dieci clienti. Nove clienti hanno ordini tra 1.000 e 2.000 euro, uno ha un ordine da 20.000. La media è 3.310 euro, ma nessun cliente reale si avvicina a questo valore: è trascinata dal cliente grande. La mediana, 1.450 euro, descrive meglio il cliente tipico. Quando i dati sono asimmetrici, come spesso accade per importi, redditi, tempi, la media da sola è fuorviante. Se si chiede all'AI 'qual è il valore tipico degli ordini?', può rispondere con la media, perché è la misura più comune. Conviene chiedere sempre media e mediana insieme, e un'indicazione della dispersione: se media e mediana sono molto diverse, ci sono valori estremi che vanno guardati.");
    phaseTag(s, 1);
    s.addChart(pres.charts.BAR, [{ name: "Valore ordini (€)", labels: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "L"], values: [1100, 1200, 1300, 1400, 1400, 1500, 1600, 1700, 1900, 20000] }], {
      x: 0.5, y: 1.1, w: 5.4, h: 3.0, barDir: "col", chartColors: [HEX.a1], valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 9, catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 10,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 21000, barGapWidthPct: 40,
      showTitle: true, title: "Valore degli ordini di dieci clienti (esempio fittizio)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt", catAxisLabelFontFace: "+mn-lt",
    });
    shapeBox(s, 6.15, 1.15, 3.35, 1.3, C.background2, "media");
    txt(s, "Media", { x: 6.35, y: 1.22, w: 3.0, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    txt(s, "3.310 €", { x: 6.35, y: 1.55, w: 3.0, h: 0.45, fontSize: 24, bold: true, color: C.text1 });
    txt(s, "Nessun cliente reale vicino", { x: 6.35, y: 2.02, w: 3.0, h: 0.35, fontSize: 11, color: C.text2 });
    shapeBox(s, 6.15, 2.6, 3.35, 1.3, C.accent6, "mediana");
    txt(s, "Mediana", { x: 6.35, y: 2.67, w: 3.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
    txt(s, "1.450 €", { x: 6.35, y: 3.0, w: 3.0, h: 0.45, fontSize: 24, bold: true, color: C.text1 });
    txt(s, "Descrive il cliente tipico", { x: 6.35, y: 3.47, w: 3.0, h: 0.35, fontSize: 11, color: C.text2 });
    banner(s, 4.3, "Chiedere sempre media e mediana insieme: se sono molto diverse, ci sono valori estremi da guardare.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Le statistiche non bastano", "Un esempio classico della statistica mostra perché le misure di sintesi, da sole, non bastano. Nel 1973 lo statistico Francis Anscombe costruì quattro piccoli insiemi di dati, oggi noti come quartetto di Anscombe. I quattro insiemi hanno praticamente le stesse statistiche: la stessa media di x, 9, la stessa media di y, 7,5, la stessa varianza, la stessa correlazione, circa 0,82, e la stessa retta di regressione. Ma, come mostrano i grafici, sono completamente diversi. Il primo è una relazione lineare con un po' di variabilità. Il secondo è una curva, non una retta. Il terzo è una relazione lineare perfetta con un solo valore anomalo che la altera. Il quarto non ha alcuna relazione: tutti i valori di x sono uguali tranne uno, che da solo crea la correlazione. La lezione per l'analisi assistita è diretta: se si chiede all'AI una sintesi statistica, si ottengono numeri corretti che possono nascondere situazioni molto diverse. Guardare i dati, con un grafico, è un controllo semplice e potente, che conviene chiedere sempre prima di trarre conclusioni da medie e correlazioni.");
    phaseTag(s, 1);
    const x = [10, 8, 13, 9, 11, 14, 6, 4, 12, 7, 5], x4 = [8, 8, 8, 8, 8, 8, 8, 19, 8, 8, 8];
    const ys = [[8.04, 6.95, 7.58, 8.81, 8.33, 9.96, 7.24, 4.26, 10.84, 4.82, 5.68], [9.14, 8.14, 8.74, 8.77, 9.26, 8.10, 6.13, 3.10, 9.13, 7.26, 4.74], [7.46, 6.77, 12.74, 7.11, 7.81, 8.84, 6.08, 5.39, 8.15, 6.42, 5.73], [6.58, 5.76, 7.71, 8.84, 8.47, 7.04, 5.25, 12.50, 5.56, 7.91, 6.89]];
    for (let i = 0; i < 4; i++) {
      scatter(s, i === 3 ? x4 : x, ys[i], { x: 0.5 + i * 2.27, y: 1.1, w: 2.2, h: 2.2, xmin: 2, xmax: 20, ymin: 2, ymax: 14, title: "Insieme " + (i + 1), size: 5 });
    }
    shapeBox(s, 0.5, 3.45, 9.0, 0.6, C.background2, "statistiche");
    txt(s, "Per tutti e quattro:  media x = 9   ·   media y = 7,5   ·   correlazione = 0,82   ·   stessa retta di regressione", { x: 0.7, y: 3.45, w: 8.6, h: 0.6, fontSize: 13, bold: true, color: C.text1, valign: "middle", align: "center" });
    banner(s, 4.2, "Numeri corretti possono nascondere situazioni molto diverse. Guardare i dati con un grafico, prima di concludere.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Formule e codice generati dall'AI", "L'AI può produrre risultati quantitativi in due modi molto diversi, e il primo è generare strumenti di calcolo: formule per i fogli di calcolo, codice in linguaggi come Python o SQL, che poi vengono eseguiti. È uno degli usi più utili per chi lavora con i dati: si descrive ciò che si vuole ottenere, per esempio 'una formula che calcoli i giorni lavorativi tra la data dell'ordine e la data di consegna', e si ottiene la formula pronta. Per chi non conosce i linguaggi, è una porta d'accesso a elaborazioni prima impossibili. Per chi li conosce, è un acceleratore. Il vantaggio fondamentale di questo approccio è che il calcolo viene eseguito da uno strumento deterministico, il foglio di calcolo o l'interprete del codice, e che la formula o il codice restano visibili e controllabili. Ma anche qui servono attenzioni. La formula può essere sintatticamente corretta e logicamente sbagliata: per esempio includere anche le righe di totale, o usare un intervallo che non copre tutti i dati. Conviene verificarla su pochi casi di cui si conosce il risultato, e chiedere al sistema di spiegarla passo per passo. La programmazione analitica complessa è solo da accennare: per chi vuole approfondire esistono percorsi specifici.");
    phaseTag(s, 1);
    docBox(s, 0.5, 1.15, 5.0, 1.0, "Richiesta", "Una formula che calcoli i giorni lavorativi tra la data dell'ordine (colonna B) e la data di consegna (colonna C).", { fontSize: 12 });
    promptBox(s, 0.5, 2.3, 5.0, 0.85, "=GIORNI.LAVORATIVI.TOT(B2;C2)", { label: "Formula generata", fontSize: 13 });
    await card(s, 5.75, 1.15, 3.75, 2.0, { icon: "FiCheckCircle", inline: true, head: "Il vantaggio", headSize: 14, bodySize: 12, fill: C.accent6,
      body: "Il calcolo lo esegue uno strumento deterministico, e la formula resta visibile e controllabile." });
    txt(s, "Ma una formula corretta nella forma può essere sbagliata nella logica", { x: 0.5, y: 3.3, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    chip(s, 0.5, 3.7, 2.9, 0.55, "Include le righe di totale?", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.7, 2.9, 0.55, "L'intervallo copre tutti i dati?", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.7, 2.9, 0.55, "Considera le festività?", { fill: C.background2, fontSize: 12 });
    txt(s, "Verificarla su pochi casi di risultato noto, e chiederne la spiegazione passo per passo.", { x: 0.5, y: 4.45, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Calcolo eseguito o numero generato", "Questa è l'integrazione A del tema, e il concetto più importante del sottotema: un numero presente in una risposta non dimostra che sia stato eseguito un calcolo corretto. Come abbiamo visto nel Tema 2, un modello linguistico genera testo prevedendo una parola dopo l'altra. Quando produce un numero senza usare uno strumento di calcolo, quel numero è generato come qualsiasi altra parola: è plausibile, coerente con il contesto, spesso corretto per operazioni semplici, ma non è il risultato di un calcolo. Con molti dati, operazioni complesse o numeri grandi, gli errori diventano frequenti. E il numero generato ha esattamente lo stesso aspetto di un numero calcolato: stesse cifre, stessa sicurezza, stessa formattazione. Molti strumenti attuali, quando ricevono un file di dati, scrivono ed eseguono codice per elaborarlo: in quel caso il calcolo è effettivo, ed è in genere molto più affidabile. Ma non sempre è chiaro quale dei due modi sia stato usato, e anche nella stessa risposta alcuni numeri possono essere calcolati e altri generati, per esempio un commento finale che cita una percentuale non presente nell'output del codice. La regola pratica: per i numeri che contano, accertarsi che derivino da un calcolo eseguito e controllabile.");
    phaseTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiMessageSquare", head: "Numero generato", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Prodotto come qualsiasi altra parola", "Plausibile, spesso giusto su operazioni semplici", "Errori frequenti con molti dati o numeri grandi", "Nessun passaggio da controllare"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiCpu", head: "Calcolo eseguito", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Codice o formula eseguiti da uno strumento", "Deterministico e ripetibile", "In genere molto più affidabile", "Codice e passaggi controllabili"], { space: 4 }) });
    banner(s, 3.95, "Stesse cifre, stessa sicurezza, stessa formattazione. Nella stessa risposta possono convivere numeri calcolati e numeri generati.", { h: 0.7, fontSize: 13 });
    txt(s, "Integrazione A: analisi con codice e generazione di risposte numeriche", { x: 0.5, y: 4.72, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Riconoscere un calcolo eseguito", "Come si capisce, in pratica, se un numero viene da un calcolo eseguito? Alcuni segnali e alcune pratiche. Segnali positivi: lo strumento mostra il codice eseguito o indica di aver usato uno strumento di analisi; mostra i risultati intermedi, come tabelle e conteggi; produce file, grafici o tabelle derivati dai dati; i numeri del commento coincidono con quelli dell'output del calcolo. Segnali di attenzione: la risposta contiene numeri senza alcuna traccia di elaborazione; si chiede un calcolo su dati incollati nel testo della conversazione e la risposta arriva immediata, senza codice; il commento cita valori che non compaiono nei risultati; numeri troppo tondi o troppo precisi rispetto ai dati. Pratiche utili: chiedere esplicitamente di eseguire il calcolo con codice e di mostrarlo; chiedere i valori intermedi; per i risultati importanti, ripetere il calcolo in un foglio di calcolo, o almeno controllare un ordine di grandezza; verificare che il numero di righe elaborate corrisponda a quello del file. Il controllo dell'ordine di grandezza, visto nel Tema 7, resta il primo filtro: un fatturato medio per cliente superiore al fatturato totale è un segnale inequivocabile.");
    phaseTag(s, 1);
    await card(s, 0.5, 1.15, 2.86, 2.9, { icon: "FiCheckCircle", head: "Segnali positivi", headSize: 14, bodySize: 11, fill: C.accent6,
      body: bullets(["Codice mostrato o strumento indicato", "Risultati intermedi visibili", "File, tabelle, grafici derivati", "Commento coerente con l'output"], { space: 4 }) });
    await card(s, 3.57, 1.15, 2.86, 2.9, { icon: "FiAlertTriangle", head: "Segnali di attenzione", headSize: 14, bodySize: 11, iconBg: C.accent5,
      body: bullets(["Numeri senza traccia di elaborazione", "Dati incollati, risposta immediata", "Valori citati ma assenti nei risultati", "Numeri troppo tondi o troppo precisi"], { space: 4 }) });
    await card(s, 6.64, 1.15, 2.86, 2.9, { icon: "FiTool", head: "Pratiche utili", headSize: 14, bodySize: 11,
      body: bullets(["Chiedere il calcolo con codice", "Chiedere i valori intermedi", "Ripetere i calcoli importanti", "Controllare le righe elaborate"], { space: 4 }) });
    banner(s, 4.25, "Primo filtro: l'ordine di grandezza. Una media per cliente superiore al totale è un segnale inequivocabile.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Tracciabilità delle operazioni", "L'ultimo elemento del sottotema è la tracciabilità delle operazioni eseguite: poter ricostruire come si è arrivati a un risultato. Un risultato numerico tracciabile indica da quali dati parte, con quali filtri, quali operazioni sono state eseguite in quale ordine, con quali definizioni e quali scelte, per esempio sul trattamento dei mancanti. L'esempio in slide mostra un registro delle operazioni: è ciò che conviene chiedere al sistema, o tenere da sé, per le analisi importanti. La tracciabilità serve a quattro cose. A verificare: chi controlla può ripercorrere i passaggi. A ripetere: la stessa analisi sul mese successivo produce risultati confrontabili. A spiegare: chi riceve il risultato può capire che cosa significa e quali sono i suoi limiti. A correggere: se emerge un errore nei dati, si sa quali risultati ne sono influenzati. Si ricollega alla distinzione tra dati, metriche e indicatori: un indicatore tracciabile dichiara la sua definizione. E prepara il sottotema 9.8, dove vedremo che l'affidabilità non deriva dall'apparenza professionale del risultato, ma da dati, elaborazioni e ipotesi controllabili.");
    phaseTag(s, 1);
    promptBox(s, 0.5, 1.15, 5.6, 2.9, "1. File: vendite_2025.csv (12.480 righe)\n2. Esclusi ordini annullati: 312 righe\n3. Rimossi duplicati: 41 righe\n4. Importi: netti di IVA e resi\n5. Raggruppamento per regione e mese\n6. Valore medio = fatturato / n. ordini\n7. Mancanti di regione (18): esclusi", { label: "Registro delle operazioni (esempio fittizio)", fontSize: 11 });
    const u = [["Verificare", "Ripercorrere i passaggi"], ["Ripetere", "Risultati confrontabili nel tempo"], ["Spiegare", "Significato e limiti"], ["Correggere", "Sapere che cosa è influenzato"]];
    u.forEach((e, i) => {
      const y = 1.15 + i * 0.74;
      shapeBox(s, 6.35, y, 3.15, 0.64, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.04, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.33, w: 2.9, h: 0.28, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.25, "Un risultato tracciabile dichiara dati, filtri, operazioni, definizioni e scelte.", { h: 0.7, fontSize: 14 });
  }
  keySlide("Metodo, dati e passaggi di elaborazione sono determinanti per l'affidabilità di un risultato numerico.", "Sottotema 9.3  ·  Elaborazione e analisi quantitativa", "Concetto chiave del sottotema 9.3. L'AI può eseguire tutte le operazioni quantitative comuni, generare formule e codice, calcolare indicatori e statistiche descrittive. Ma un numero in una risposta non dimostra che sia stato eseguito un calcolo: bisogna distinguere i numeri generati linguisticamente da quelli calcolati con strumenti verificabili. Le scelte su base, periodo, definizioni e trattamento dei dati contano quanto l'aritmetica, le statistiche di sintesi vanno sempre accompagnate da uno sguardo ai dati, e la tracciabilità delle operazioni rende il risultato verificabile, ripetibile e spiegabile. Esercizio suggerito: dare a uno strumento AI una tabella fittizia di una trentina di righe incollata nel testo e chiedere un totale e una media, poi chiedere lo stesso caricando il file e chiedendo di usare il codice, e confrontare i risultati con quelli di un foglio di calcolo.");

  // =====================================================================
  section("9.4 Pattern e tendenze");
  divider("9.4", "Pattern, tendenze e anomalie", "Individuare una relazione nei dati non prova automaticamente l'esistenza di un nesso causale", "Passiamo dalle operazioni ai fenomeni. Nel 9.3 abbiamo calcolato; qui cerchiamo nei dati qualcosa di significativo: andamenti nel tempo, schemi che si ripetono, anomalie, relazioni tra variabili. È uno degli usi più promettenti dell'AI, che può esplorare rapidamente molte combinazioni e segnalare ciò che merita attenzione. Ed è anche quello in cui il rischio di vedere ciò che non c'è è più alto. In questo sottotema, da comprendere e sperimentare, vediamo tendenze, stagionalità, anomalie e correlazioni, e l'integrazione B: dati corretti possono portare a conclusioni sbagliate.");
  {
    const s = content("Andamenti nel tempo", "L'analisi degli andamenti temporali è una delle più comuni: come sono cambiate le vendite, i costi, i reclami, le assenze nel corso del tempo. Un andamento osservato è di solito la combinazione di tre componenti. La tendenza di fondo, o trend: la direzione di lungo periodo, di crescita, calo o stabilità. La stagionalità: oscillazioni che si ripetono con regolarità, come il picco di dicembre o il calo di agosto. Le variazioni irregolari: oscillazioni casuali, o dovute a eventi particolari. Il grafico in slide mostra un esempio fittizio di vendite mensili su tre anni: c'è una tendenza di crescita moderata, una forte stagionalità con picchi a fine anno, e piccole variazioni irregolari. L'AI può aiutare a separare queste componenti e a descriverle. L'errore più frequente è confondere stagionalità e tendenza: interpretare il calo di gennaio rispetto a dicembre come un segnale negativo, quando si ripete ogni anno. Per questo i confronti temporali più affidabili sono quelli con lo stesso periodo dell'anno precedente. Un altro errore frequente è dichiarare una tendenza a partire da pochi punti: tre mesi di crescita non sono necessariamente un trend.");
    phaseTag(s, 1);
    const lab = [], v = [];
    const base = [80, 78, 85, 88, 90, 87, 82, 70, 92, 98, 115, 135];
    for (let y = 0; y < 3; y++) for (let m = 0; m < 12; m++) { lab.push(m === 0 ? String(2023 + y) : ""); v.push(Math.round(base[m] * (1 + 0.08 * y) + ((m * 7 + y * 3) % 5) - 2)); }
    lineChart(s, lab, [{ name: "Vendite mensili", values: v }], { x: 0.5, y: 1.1, w: 6.0, h: 3.0, min: 60, max: 160, title: "Vendite mensili, tre anni (esempio fittizio)" });
    const c = [["Tendenza", "Direzione di lungo periodo"], ["Stagionalità", "Oscillazioni regolari, come il picco di fine anno"], ["Irregolari", "Casuali o dovute a eventi"]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 6.75, y, 2.75, 0.85, i === 1 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.9, y: y + 0.06, w: 2.5, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.9, y: y + 0.4, w: 2.5, h: 0.4, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.3, "Errori tipici: leggere la stagionalità come tendenza, e dichiarare un trend da pochi punti.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Anomalie e scostamenti", "Un'anomalia è un valore o un comportamento che si discosta in modo significativo da ciò che ci si attende. Le anomalie sono preziose: possono segnalare un errore nei dati, un problema operativo, una frode, un'opportunità. L'AI è molto efficace nel trovarle, anche in grandi quantità di dati e su molte variabili insieme, e può confrontare ogni valore con l'andamento abituale. Il grafico fittizio in slide mostra i reclami settimanali di un servizio: un picco evidente nella settimana 9. Che cosa significa? Le spiegazioni possibili sono molte: un problema con un lotto di prodotto, un cambio di fornitore logistico, un nuovo modulo di reclamo online più facile da usare, un errore di registrazione che ha duplicato le segnalazioni. L'AI può segnalare il picco e proporre ipotesi, ma non può sapere quale sia quella giusta senza informazioni sul contesto. Due attenzioni. Anomalo non significa sbagliato: eliminare i valori anomali in automatico può cancellare proprio l'informazione più importante. E non ogni scostamento è un'anomalia: con molti dati, alcune variazioni ampie sono normali. Conviene chiedere al sistema con quale criterio ha definito anomalo un valore.");
    phaseTag(s, 1);
    const w = [], r = [12, 14, 11, 13, 15, 12, 14, 13, 41, 16, 13, 12, 14, 13];
    for (let i = 0; i < r.length; i++) w.push("S" + (i + 1));
    lineChart(s, w, [{ name: "Reclami", values: r }], { x: 0.5, y: 1.1, w: 5.5, h: 2.6, min: 0, max: 45, symbol: "circle", title: "Reclami settimanali (esempio fittizio)" });
    shapeBox(s, 6.25, 1.15, 3.25, 2.55, C.background2, "ipotesi");
    txt(s, "Settimana 9: perché?", { x: 6.4, y: 1.22, w: 3.0, h: 0.35, fontSize: 14, bold: true, color: C.accent5 });
    txt(s, bullets(["Un lotto difettoso", "Un nuovo fornitore logistico", "Un modulo online più semplice", "Segnalazioni duplicate per errore"], { space: 4 }), { x: 6.4, y: 1.65, w: 3.0, h: 1.9, fontSize: 12, color: C.text1 });
    chip(s, 0.5, 3.9, 4.4, 0.55, "Anomalo non significa sbagliato", { fill: C.accent6, fontSize: 12 });
    chip(s, 5.1, 3.9, 4.4, 0.55, "Non ogni scostamento è un'anomalia", { fill: C.accent6, fontSize: 12 });
    txt(s, "L'AI segnala e propone ipotesi; quale sia giusta lo dice il contesto. Chiedere con quale criterio un valore è definito anomalo.", { x: 0.5, y: 4.55, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Relazioni e correlazioni", "Il confronto tra variabili cerca relazioni: quando una cresce, l'altra cresce o cala? La misura più comune è la correlazione, un numero tra meno uno e più uno che indica quanto due variabili variano insieme in modo lineare. Vicino a più uno, crescono insieme; vicino a meno uno, una cresce quando l'altra cala; vicino a zero, nessuna relazione lineare. Il grafico fittizio in slide mostra la relazione tra il numero di visite commerciali e il fatturato di venti clienti: c'è una correlazione positiva evidente. L'AI può calcolare correlazioni tra molte variabili in pochi secondi, e segnalare quelle più forti. Tre cose da sapere per leggerle correttamente. La correlazione misura solo relazioni lineari: due variabili possono essere fortemente legate in modo non lineare con correlazione bassa, come nel secondo insieme di Anscombe. La correlazione è sensibile ai valori anomali: un solo punto può crearla o cancellarla, come nel quarto insieme. E soprattutto, la correlazione non indica la direzione né la causa: le visite producono fatturato, o i clienti con più fatturato ricevono più visite? Ne parliamo nella prossima slide.");
    phaseTag(s, 1);
    const vx = [2, 3, 3, 4, 5, 5, 6, 6, 7, 8, 8, 9, 10, 10, 11, 12, 13, 14, 15, 16];
    const vy = [18, 22, 30, 26, 35, 41, 38, 47, 44, 52, 58, 55, 63, 70, 66, 74, 80, 78, 90, 94];
    scatter(s, vx, vy, { x: 0.5, y: 1.1, w: 5.0, h: 3.0, xmin: 0, xmax: 18, ymin: 0, ymax: 100, title: "Visite commerciali e fatturato (k€), 20 clienti fittizi", size: 7 });
    const c = [["Solo relazioni lineari", "Legami curvi possono avere correlazione bassa"], ["Sensibile agli anomali", "Un punto può crearla o cancellarla"], ["Né direzione né causa", "Visite che producono fatturato, o il contrario?"]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.98;
      shapeBox(s, 5.75, y, 3.75, 0.88, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 5.9, y: y + 0.06, w: 3.5, h: 0.32, fontSize: 13, bold: true, color: i === 2 ? C.accent5 : C.accent1 });
      txt(s, e[1], { x: 5.9, y: y + 0.4, w: 3.5, h: 0.42, fontSize: 11, color: C.text2 });
    });
    txt(s, "La correlazione va da -1 a +1 e misura quanto due variabili variano insieme in modo lineare.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Correlazione e causalità nei dati", "Nel Tema 7 abbiamo visto la distinzione tra correlazione e causalità come difetto di ragionamento. Qui la applichiamo ai dati, dove il rischio è particolarmente concreto, perché l'AI trova correlazioni rapidamente e tende a commentarle con un linguaggio causale: 'le visite aumentano il fatturato', 'la formazione riduce le assenze'. Le spiegazioni alternative sono le stesse viste nel Tema 7, declinate sui dati aziendali. Causalità inversa: i clienti più grandi ricevono più visite perché sono più importanti, non il contrario. Terzo fattore: le filiali con più formazione e meno assenze sono anche quelle con un responsabile più attento, che spiega entrambe le cose. Selezione: i dipendenti che hanno scelto di partecipare alla formazione erano già i più motivati. Coincidenza: con pochi dati, una correlazione può essere casuale. Come si può avvicinarsi a una prova causale? Con confronti controllati, per esempio introducendo un cambiamento in alcune sedi e non in altre, scelte a caso, e confrontando i risultati. Sono metodi che richiedono competenze specifiche, da accennare. Per l'utilizzatore, la regola è semplice: una correlazione trovata dall'AI è un'ipotesi da esplorare, non una conclusione.");
    phaseTag(s, 1);
    await iconGrid(s, [
      { icon: "FiRepeat", head: "Causalità inversa", body: "I clienti grandi ricevono più visite, non il contrario" },
      { icon: "FiShare2", head: "Terzo fattore", body: "Un responsabile attento spiega formazione e meno assenze" },
      { icon: "FiFilter", head: "Selezione", body: "Alla formazione sono andati i più motivati" },
      { icon: "FiShuffle", head: "Coincidenza", body: "Con pochi dati, una correlazione può essere casuale" },
    ], 2, { y: 1.15, H: 2.55, headSize: 14, bodySize: 12 });
    banner(s, 3.9, "Una correlazione trovata dall'AI è un'ipotesi da esplorare, non una conclusione. Attenzione al linguaggio causale dei commenti.", { h: 0.75, fontSize: 13 });
    txt(s, "Avvicinarsi a una prova causale richiede confronti controllati: metodi specialistici, da accennare.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Relazioni prive di significato", "Il sottotema segnala un rischio specifico: individuare relazioni prive di significato. Il meccanismo è statistico e merita di essere compreso. Se si confrontano due variabili casuali, la probabilità che mostrino una correlazione apparentemente rilevante è bassa. Ma se si confrontano tra loro cinquanta variabili, si eseguono più di mille confronti, e alcune correlazioni forti emergeranno per puro caso. È quello che succede quando si chiede all'AI di 'trovare relazioni interessanti nei dati': il sistema esplora molte combinazioni e riporta quelle più forti, che sono proprio quelle con più probabilità di essere casuali. Esistono raccolte famose di correlazioni assurde, come quella tra il consumo di formaggio pro capite e le morti per aggrovigliamento nelle lenzuola negli Stati Uniti, raccolte da Tyler Vigen, che mostrano quanto sia facile trovare relazioni forti tra fenomeni scollegati. Il problema si aggrava con pochi dati e con molte variabili. Le contromisure: partire da domande e ipotesi, invece di cercare relazioni a caso; diffidare delle relazioni senza una spiegazione plausibile; verificare se la relazione regge su un altro periodo o un altro gruppo di dati.");
    phaseTag(s, 1);
    const n = [["2", "variabili", "1 confronto"], ["10", "variabili", "45 confronti"], ["50", "variabili", "1.225 confronti"]];
    n.forEach((e, i) => {
      const x = 0.5 + i * 2.0;
      shapeBox(s, x, 1.15, 1.85, 1.6, i === 2 ? C.accent1 : C.background2, e[0]);
      txt(s, e[0], { x, y: 1.2, w: 1.85, h: 0.6, fontSize: 30, bold: true, color: i === 2 ? C.background1 : C.accent1, align: "center" });
      txt(s, e[1], { x, y: 1.8, w: 1.85, h: 0.3, fontSize: 12, color: i === 2 ? C.background1 : C.text2, align: "center" });
      txt(s, e[2], { x, y: 2.15, w: 1.85, h: 0.4, fontSize: 13, bold: true, color: i === 2 ? C.background1 : C.text1, align: "center" });
    });
    shapeBox(s, 6.6, 1.15, 2.9, 1.6, C.text1, "caso");
    txt(s, "Più confronti, più correlazioni forti per puro caso", { x: 6.75, y: 1.15, w: 2.6, h: 1.6, fontSize: 14, bold: true, color: C.accent6, valign: "middle" });
    txt(s, "Contromisure", { x: 0.5, y: 2.95, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.35, 2.9, 0.65, "Partire da domande e ipotesi", { fill: C.accent6, fontSize: 12 });
    chip(s, 3.55, 3.35, 2.9, 0.65, "Diffidare delle relazioni senza spiegazione", { fill: C.accent6, fontSize: 12 });
    chip(s, 6.6, 3.35, 2.9, 0.65, "Verificare su altri periodi o gruppi", { fill: C.accent6, fontSize: 12 });
    txt(s, "'Trova relazioni interessanti' porta a galla proprio quelle più probabilmente casuali. Esempi celebri di correlazioni assurde: Tyler Vigen, Spurious Correlations.", { x: 0.5, y: 4.2, w: 9, h: 0.7, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Dati corretti, conclusioni sbagliate", "Questa è l'integrazione B del tema: dati accurati possono comunque portare a interpretazioni improprie e conclusioni infondate. È un punto importante perché va contro un'intuizione diffusa: se i dati sono giusti, anche le conclusioni lo saranno. Non è così. L'esempio fittizio in slide lo mostra. Un'analisi corretta dei dati mostra che i clienti che usano l'app aziendale spendono in media il 40 per cento in più. Ogni numero è giusto. La conclusione proposta, 'spingere tutti i clienti a usare l'app aumenterà la spesa del 40 per cento', è infondata per almeno tre ragioni: i clienti che usano l'app sono probabilmente già i più fedeli e attivi, quindi spenderebbero di più comunque; non sappiamo se chi viene spinto a usarla si comporterà come chi l'ha scelta spontaneamente; e il 40 per cento è una differenza tra gruppi, non l'effetto di un cambiamento. Le conclusioni sbagliate da dati corretti nascono di solito da tre passaggi: dalla correlazione alla causa, dal gruppo osservato a tutti, dalla differenza osservata all'effetto di un intervento. Sono passaggi che i commenti generati dall'AI compiono con facilità, con un linguaggio sicuro.");
    phaseTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 1.1, "Dato corretto (esempio fittizio)", "I clienti che usano l'app spendono in media il 40% in più.", { fontSize: 13, fill: C.accent6 });
    docBox(s, 0.5, 2.4, 4.35, 1.1, "Conclusione infondata", "Spingere tutti a usare l'app aumenterà la spesa del 40%.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    await card(s, 5.15, 1.15, 4.35, 2.35, { icon: "FiHelpCircle", head: "Perché non regge", headSize: 15, bodySize: 12,
      body: bullets(["Chi usa l'app è già più fedele", "Chi viene spinto può comportarsi diversamente", "Una differenza tra gruppi non è l'effetto di un intervento"], { space: 4 }) });
    txt(s, "Tre passaggi a rischio", { x: 0.5, y: 3.65, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.accent5 });
    chip(s, 0.5, 4.0, 2.9, 0.55, "Dalla correlazione alla causa", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 4.0, 2.9, 0.55, "Dal gruppo osservato a tutti", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 4.0, 2.9, 0.55, "Dalla differenza all'effetto", { fill: C.background2, fontSize: 12 });
    txt(s, "Integrazione B: dati corretti, conclusioni sbagliate", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Verificare le ipotesi", "Come si passa da un fenomeno osservato a un'interpretazione solida? Il sottotema parla di interpretazione critica dei fenomeni e di necessità di verificare le ipotesi. In pratica, un metodo in cinque passaggi. Primo, descrivere il fenomeno senza interpretarlo: che cosa si osserva, con quali numeri, in quale periodo e su quali dati. Secondo, formulare più ipotesi, non una sola: l'AI è molto utile qui, perché genera rapidamente spiegazioni alternative, come visto nel Tema 7. Terzo, per ciascuna ipotesi, chiedersi che cosa dovremmo osservare nei dati se fosse vera: se il picco di reclami dipende da un lotto difettoso, i reclami dovrebbero riguardare quel prodotto; se dipende dal nuovo modulo online, dovrebbero arrivare tutti da quel canale. Quarto, controllare quelle conseguenze nei dati, o con altre informazioni: è un'analisi mirata, molto più affidabile della ricerca generica di relazioni. Quinto, dichiarare il livello di certezza della conclusione: confermata, probabile, possibile. Questo metodo trasforma l'AI da generatore di conclusioni a strumento per esplorare e verificare ipotesi, che è il suo uso più sicuro e più utile nell'analisi.");
    phaseTag(s, 1);
    numList(s, ["Descrivere il fenomeno senza interpretarlo", "Formulare più ipotesi, non una sola: l'AI aiuta a generarle", "Per ciascuna: che cosa dovremmo osservare se fosse vera?", "Controllare quelle conseguenze nei dati o con altre informazioni", "Dichiarare il livello di certezza: confermata, probabile, possibile"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "Da generatore di conclusioni a strumento per esplorare e verificare ipotesi: l'uso più sicuro e più utile.", { h: 0.65, fontSize: 13 });
  }
  keySlide("Individuare una relazione nei dati non prova automaticamente l'esistenza di un nesso causale.", "Sottotema 9.4  ·  Identificazione di pattern, tendenze e anomalie", "Concetto chiave del sottotema 9.4. L'AI è molto efficace nel trovare tendenze, stagionalità, anomalie e correlazioni, anche in grandi quantità di dati. Ma la stagionalità va distinta dalla tendenza, un'anomalia va capita prima di essere eliminata, la correlazione non indica né direzione né causa, e chi cerca relazioni tra molte variabili ne troverà alcune per puro caso. Dati corretti possono portare a conclusioni sbagliate. Il metodo più solido è usare l'AI per formulare e verificare ipotesi. Esercizio suggerito: presentare ai partecipanti una correlazione fittizia trovata dall'AI, con il commento causale generato, e chiedere di proporre almeno tre spiegazioni alternative e, per ciascuna, quale dato permetterebbe di verificarla.");

  // =====================================================================
  section("9.5 Visualizzazione");
  divider("9.5", "Visualizzazione e comunicazione dei risultati", "Una rappresentazione persuasiva non garantisce la validità dei dati né delle conclusioni", "Dai fenomeni alla loro comunicazione. Un'analisi serve se qualcuno la capisce e la usa, e per questo i risultati vanno rappresentati e comunicati: grafici, tabelle, dashboard, report, commenti. L'AI è diventata molto efficace in tutte queste attività, e produce in pochi secondi grafici e report dall'aspetto professionale. In questo sottotema, da comprendere e sperimentare, vediamo che cosa può fare, come scegliere la rappresentazione giusta, i rischi dei grafici fuorvianti e dei commenti automatici, e la distinzione tra comunicazione efficace e interpretazione corretta. I principi generali di lettura critica dei grafici li abbiamo visti nel Tema 7; qui guardiamo alla produzione.");
  {
    const s = content("Che cosa può produrre l'AI", "Le possibilità dell'AI nella rappresentazione dei risultati sono ampie. Grafici: a partire dai dati, il sistema propone e crea grafici a barre, linee, torte, dispersione, spesso con poche parole di richiesta. Tabelle riepilogative: i risultati principali organizzati in modo leggibile, con totali, percentuali, evidenziazioni. Dashboard: insiemi di grafici e indicatori su una sola schermata, da consultare periodicamente. Report analitici: documenti che combinano testo, tabelle e grafici per presentare un'analisi. Commenti ai risultati: testi che descrivono e interpretano grafici e tabelle, come 'le vendite sono cresciute del 12 per cento, trainate dalla regione Nord'. Il valore è soprattutto la velocità: un report che richiedeva ore si prepara in minuti, e si possono provare rapidamente rappresentazioni diverse. Ma proprio la facilità di produzione rende più importante il controllo: un grafico ben fatto e un commento ben scritto trasmettono un senso di affidabilità che non dipende dalla correttezza dei dati o dell'interpretazione sottostanti.");
    phaseTag(s, 2);
    await iconGrid(s, [
      { icon: "FiBarChart2", head: "Grafici", body: "Barre, linee, torte, dispersione" },
      { icon: "FiGrid", head: "Tabelle riepilogative", body: "Totali, percentuali, evidenziazioni" },
      { icon: "FiMonitor", head: "Dashboard", body: "Grafici e indicatori in una schermata" },
      { icon: "FiFileText", head: "Report analitici", body: "Testo, tabelle e grafici insieme" },
      { icon: "FiMessageSquare", head: "Commenti ai risultati", body: "Descrizione e interpretazione in parole" },
      { icon: "FiClock", head: "Velocità", body: "Da ore a minuti; più rappresentazioni da provare", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Un grafico ben fatto e un commento ben scritto trasmettono affidabilità, che non dipende dai dati sottostanti.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Scegliere la rappresentazione", "La scelta del grafico dipende da che cosa si vuole mostrare. Per confrontare valori tra categorie, come il fatturato per regione, il grafico a barre è di solito la scelta migliore, perché le lunghezze si confrontano facilmente. Per mostrare un andamento nel tempo, il grafico a linee. Per mostrare la composizione di un totale, come la quota di ciascun canale sulle vendite, si usano barre in pila o, con poche categorie, il grafico a torta, che però diventa illeggibile oltre quattro o cinque fette e rende difficile confrontare quote simili. Per mostrare la relazione tra due variabili, il grafico a dispersione. Per mostrare la distribuzione dei valori, come la frequenza degli importi degli ordini, l'istogramma. Per valori precisi da consultare, una tabella è spesso meglio di qualsiasi grafico. L'AI propone di solito una rappresentazione ragionevole, ma non sempre la migliore: tende a scegliere grafici comuni, ad aggiungere elementi decorativi, a usare troppi colori. Conviene indicare che cosa si vuole far vedere, e chiedere al sistema di motivare la scelta. Un buon grafico ha un messaggio principale, visibile in pochi secondi.");
    phaseTag(s, 2);
    table(s, [["Che cosa mostrare", "Rappresentazione", "Attenzione"],
      ["Confronto tra categorie", "Barre", "Ordinare le barre per valore"],
      ["Andamento nel tempo", "Linee", "Periodo completo, non selezionato"],
      ["Composizione di un totale", "Barre in pila o torta", "Torta solo con poche fette"],
      ["Relazione tra due variabili", "Dispersione", "Relazione non significa causa"],
      ["Distribuzione dei valori", "Istogramma", "Scelta degli intervalli"],
      ["Valori precisi", "Tabella", "Spesso meglio di un grafico"]],
      { y: 1.15, colW: [3.0, 2.6, 3.4], rowH: 0.4, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 4.1, "Indicare che cosa si vuole far vedere, e chiedere di motivare la scelta. Un buon grafico ha un messaggio visibile in pochi secondi.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Tabelle, dashboard e report", "Tre forme di comunicazione con esigenze diverse. Le tabelle riepilogative presentano i risultati principali in forma compatta. L'AI le produce bene; il controllo riguarda la coerenza dei totali con i dati, l'arrotondamento, che può far sì che le percentuali non sommino a cento, e le categorie raggruppate in 'altro', che possono nascondere elementi importanti. Le dashboard sono pensate per un uso ripetuto: si consultano ogni settimana o ogni mese. Qui conta soprattutto la stabilità delle definizioni: se un indicatore cambia formula da un mese all'altro, l'andamento perde significato. Le dashboard aziendali ufficiali sono di solito costruite con strumenti di BI e definizioni concordate; quelle prodotte al volo con l'AI sono utili per esplorare, ma non vanno confuse con le prime. I report analitici combinano testo, numeri e grafici in un racconto. Il rischio specifico è l'incoerenza tra le parti: il testo cita un valore diverso da quello della tabella, un grafico si riferisce a un periodo diverso, una conclusione non è sostenuta dai numeri presentati. Quando l'AI produce un report completo, conviene controllare che ogni numero citato nel testo corrisponda a quelli di tabelle e grafici.");
    phaseTag(s, 2);
    const f = [["FiGrid", "Tabelle riepilogative", ["Totali coerenti con i dati", "Arrotondamenti: somme diverse da 100", "Cosa nasconde 'altro'?"]], ["FiMonitor", "Dashboard", ["Uso ripetuto nel tempo", "Definizioni stabili", "Esplorative o ufficiali?"]], ["FiFileText", "Report analitici", ["Testo, numeri e grafici", "Coerenza tra le parti", "Ogni numero citato va ritrovato"]]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.15, 2.86, 2.9, { icon: f[i][0], head: f[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: bullets(f[i][2], { space: 5 }) });
    }
    banner(s, 4.25, "Le dashboard prodotte al volo servono a esplorare: non vanno confuse con quelle ufficiali, con definizioni concordate.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Commenti generati e storytelling", "Due attività in cui l'AI è particolarmente brava, e che richiedono particolare attenzione. I commenti ai risultati: l'AI descrive in parole ciò che grafici e tabelle mostrano. È utile, perché rende i risultati accessibili a chi non legge facilmente i numeri. Ma il commento può discostarsi dai dati in modi sottili: citare un valore non presente, arrotondare in modo da cambiare il senso, 'quasi raddoppiato' per un aumento del 70 per cento, enfatizzare un elemento secondario, e soprattutto aggiungere interpretazioni causali che i dati non sostengono, come 'grazie alla nuova campagna'. Il data storytelling è l'arte di costruire un racconto attorno ai dati: un messaggio principale, una sequenza logica, un contesto, un'implicazione. È una competenza preziosa, perché i dati senza racconto spesso non vengono capiti né usati. Ma un racconto efficace seleziona: sceglie che cosa mostrare e che cosa lasciare fuori. Quando il racconto viene costruito dall'AI, le scelte di selezione sono del sistema, e il racconto può essere convincente anche quando i dati sono più ambigui di quanto appaia. Il controllo: ogni affermazione del commento o del racconto deve poter essere ricondotta a un numero presentato.");
    phaseTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiMessageSquare", head: "Commenti generati", headSize: 15, bodySize: 12,
      body: bullets(["Valori non presenti nei dati", "'Quasi raddoppiato' per +70%", "Enfasi su elementi secondari", "'Grazie alla campagna': causa non provata"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiBookOpen", head: "Data storytelling", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Messaggio, sequenza, contesto, implicazione", "Rende i dati comprensibili e usati", "Ma seleziona che cosa mostrare", "Se lo costruisce l'AI, la selezione è sua"], { space: 4 }) });
    banner(s, 3.9, "Ogni affermazione del commento o del racconto deve poter essere ricondotta a un numero presentato.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Grafici fuorvianti", "Nel Tema 7 abbiamo visto come un asse che non parte da zero possa ingigantire una differenza. Qui vediamo un altro meccanismo frequente: la scelta del periodo. I due grafici in slide mostrano gli stessi dati fittizi, le vendite mensili di un prodotto. A sinistra, gli ultimi sei mesi: una crescita costante e rassicurante. A destra, gli ultimi trenta mesi: la crescita recente è un recupero parziale dopo un forte calo, e le vendite sono ancora sotto i livelli di due anni fa. Nessuno dei due grafici è falso, ma comunicano messaggi opposti. Altri meccanismi fuorvianti da conoscere: assi diversi per due serie sullo stesso grafico, che fanno sembrare correlati andamenti indipendenti; grafici tridimensionali, che deformano le proporzioni; torte con percentuali che non sommano a cento; categorie ordinate per enfatizzare un risultato; scale logaritmiche non segnalate. L'AI non produce grafici fuorvianti di proposito, ma segue la richiesta: se si chiede di mostrare la crescita, sceglierà il periodo in cui c'è crescita. Il controllo consiste nel chiedersi: quale periodo, quale scala, quali categorie, e che cosa vedrei con scelte diverse?");
    phaseTag(s, 2);
    const full = [100, 102, 99, 101, 98, 96, 97, 94, 90, 88, 85, 82, 80, 78, 75, 73, 70, 68, 66, 65, 64, 63, 62, 64, 66, 68, 70, 72, 74, 77];
    const labF = full.map((v, i) => (i % 6 === 0 ? "M" + (i + 1) : ""));
    lineChart(s, ["M25", "M26", "M27", "M28", "M29", "M30"], [{ name: "Vendite", values: full.slice(24) }], { x: 0.5, y: 1.1, w: 4.3, h: 2.6, min: 60, max: 80, symbol: "circle", title: "Ultimi 6 mesi: crescita costante" });
    lineChart(s, labF, [{ name: "Vendite", values: full, color: HEX.a5 }], { x: 5.2, y: 1.1, w: 4.3, h: 2.6, min: 0, max: 110, title: "Ultimi 30 mesi: un recupero parziale" });
    txt(s, "Stessi dati fittizi", { x: 0.5, y: 3.72, w: 9, h: 0.28, fontSize: 10, italic: true, color: C.accent2, align: "center" });
    const m = ["Due assi diversi", "Effetti 3D", "Torte oltre 100%", "Ordine delle categorie", "Scale logaritmiche"];
    m.forEach((t, i) => chip(s, 0.5 + i * 1.82, 4.05, 1.7, 0.45, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Chiedersi: quale periodo, quale scala, quali categorie, e che cosa vedrei con scelte diverse?", { x: 0.5, y: 4.6, w: 9, h: 0.4, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Dati e grafico coerenti", "Un controllo di base, spesso trascurato: il grafico rappresenta davvero i dati? Quando l'AI produce un grafico, possono verificarsi errori tra i dati e la loro rappresentazione. Il grafico può usare una colonna diversa da quella intesa, per esempio il fatturato lordo invece del netto. Può includere o escludere righe in modo non dichiarato, per esempio le righe di totale, o i mesi incompleti. Può aggregare in modo diverso da quello atteso, per esempio la somma invece della media. Le etichette possono non corrispondere ai dati: un asse etichettato 'migliaia di euro' su dati in euro, una legenda con i colori invertiti. Il periodo dell'ultimo dato può essere parziale: un mese in corso, con pochi giorni di dati, mostra un calo apparente. Quest'ultimo caso è frequentissimo nei grafici prodotti automaticamente da esportazioni recenti. Alcuni controlli rapidi: verificare due o tre valori del grafico sulla tabella dei dati; controllare il titolo, le etichette, le unità di misura, la fonte e il periodo; chiedersi se l'ultimo punto è completo. Un buon grafico dichiara la fonte dei dati, il periodo e le eventuali esclusioni.");
    phaseTag(s, 2);
    const e = [["Colonna sbagliata", "Lordo invece di netto"], ["Righe incluse o escluse", "Totali, mesi incompleti"], ["Aggregazione diversa", "Somma invece di media"], ["Etichette e unità", "Migliaia su dati in euro"], ["Ultimo periodo parziale", "Un calo che non c'è"]];
    e.forEach((x, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const xx = 0.5 + col * 3.07, y = 1.15 + row * 1.0;
      shapeBox(s, xx, y, 2.86, 0.88, i === 4 ? C.accent6 : C.background2, x[0]);
      txt(s, x[0], { x: xx + 0.15, y: y + 0.06, w: 2.56, h: 0.35, fontSize: 13, bold: true, color: i === 4 ? C.accent5 : C.accent1 });
      txt(s, x[1], { x: xx + 0.15, y: y + 0.44, w: 2.56, h: 0.36, fontSize: 12, color: C.text2 });
    });
    shapeBox(s, 6.64, 2.15, 2.86, 0.88, C.text1, "buon grafico");
    txt(s, "Un buon grafico dichiara fonte, periodo ed esclusioni", { x: 6.79, y: 2.15, w: 2.56, h: 0.88, fontSize: 12, bold: true, color: C.accent6, valign: "middle" });
    banner(s, 3.3, "Controlli rapidi: due o tre valori sulla tabella; titolo, etichette, unità, fonte, periodo; l'ultimo punto è completo?", { h: 0.85, fontSize: 13 });
    txt(s, "Il mese in corso con pochi giorni di dati è uno degli errori più frequenti nei grafici automatici.", { x: 0.5, y: 4.35, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Comunicare bene, interpretare bene", "L'ultimo punto del sottotema è una distinzione: comunicazione efficace e interpretazione corretta sono due qualità diverse. Una comunicazione efficace è chiara, visivamente gradevole, convincente, facile da ricordare. Un'interpretazione corretta è fondata sui dati, rispetta i limiti dell'analisi, dichiara le incertezze, non va oltre ciò che i numeri sostengono. L'ideale è avere entrambe. Ma le due qualità possono separarsi: un report può essere molto efficace e basato su un'interpretazione sbagliata, oppure corretto e così poco chiaro da non essere usato. Con l'AI, il rischio prevalente è il primo: la qualità della comunicazione è quasi sempre alta, e questo può far percepire come solida anche un'interpretazione debole. È lo stesso fenomeno visto nel Tema 7 per i testi, la fluidità che produce fiducia, applicato ai numeri e ai grafici, dove è ancora più forte, perché un grafico sembra mostrare i fatti. Il concetto chiave del sottotema lo dice chiaramente: una rappresentazione persuasiva non garantisce la validità dei dati né delle conclusioni. Prima di chiedersi se un report è convincente, conviene chiedersi se è corretto.");
    phaseTag(s, 2);
    const q = [["Comunicazione efficace", "Chiara, gradevole, convincente", C.background2], ["Interpretazione corretta", "Fondata, dichiara limiti e incertezze", C.accent6]];
    q.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 1.15, 4.35, 1.2, e[2], e[0]);
      txt(s, e[0], { x: x + 0.2, y: 1.22, w: 3.95, h: 0.4, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.2, y: 1.65, w: 3.95, h: 0.6, fontSize: 13, color: C.text1 });
    });
    shapeBox(s, 0.5, 2.55, 9.0, 1.05, C.background2, "rischio prevalente");
    txt(s, [{ text: "Con l'AI il rischio prevalente: ", options: { bold: true, color: C.accent5 } }, { text: "comunicazione quasi sempre ottima, che fa sembrare solida anche un'interpretazione debole. Un grafico sembra mostrare i fatti.", options: { color: C.text1 } }], { x: 0.7, y: 2.55, w: 8.6, h: 1.05, fontSize: 13, valign: "middle" });
    banner(s, 3.85, "Prima di chiedersi se un report è convincente, chiedersi se è corretto.", { h: 0.75, fontSize: 16 });
  }
  keySlide("Una rappresentazione persuasiva non garantisce la validità dei dati né delle conclusioni.", "Sottotema 9.5  ·  Visualizzazione dei dati e comunicazione dei risultati", "Concetto chiave del sottotema 9.5. L'AI produce rapidamente grafici, tabelle, dashboard, report e commenti di qualità professionale. La scelta della rappresentazione va guidata dal messaggio da mostrare; i commenti generati possono discostarsi dai dati o aggiungere cause non provate; la scelta del periodo, della scala e delle categorie può cambiare il messaggio; la coerenza tra dati e grafico va controllata. E soprattutto, comunicazione efficace e interpretazione corretta sono qualità diverse: con l'AI la prima è quasi garantita, la seconda no. Esercizio suggerito: dare ai partecipanti un piccolo dataset fittizio e chiedere di produrre con l'AI due grafici degli stessi dati che comunichino messaggi opposti, poi discutere quale sia la rappresentazione più onesta.");

  // =====================================================================
  section("9.6 Previsioni");
  divider("9.6", "AI, analisi predittiva e simulazioni", "Una previsione è una stima condizionata da dati, ipotesi e metodo, non una descrizione certa del futuro", "Finora abbiamo guardato a ciò che è successo. Con questo sottotema guardiamo avanti: previsioni, stime, proiezioni, simulazioni, scenari. Il documento di perimetro gli assegna priorità media e un livello di conoscenza: non entriamo nei modelli statistici o di Machine Learning, di cui il Tema 2 ha dato i principi, ma vogliamo che i partecipanti sappiano che cosa è una previsione, su che cosa si basa, quanto è incerta, e come distinguere una previsione calcolata da una supposizione generata dal modello. E vogliamo preservare con cura una distinzione: quella tra andamento storico osservato e previsione futura.");
  {
    const s = content("Descrivere e prevedere", "Riprendiamo i quattro tipi di analisi dell'introduzione. L'analisi descrittiva lavora su ciò che è accaduto: i dati sono osservazioni, e il risultato, se i dati e i calcoli sono corretti, è un fatto. L'analisi predittiva lavora su ciò che potrebbe accadere: il risultato è una stima, che dipende dai dati storici, dal metodo scelto e dalle ipotesi su come il futuro assomiglierà al passato. La differenza è fondamentale, e il documento chiede di preservarla con cura: un andamento storico osservato non è una previsione. Dire che le vendite sono cresciute del 5 per cento all'anno negli ultimi tre anni è una descrizione; dire che cresceranno del 5 per cento il prossimo anno è una previsione, che presuppone che le condizioni restino simili. Il passaggio tra le due è spesso implicito, e l'AI lo compie facilmente: chiedendo 'come andranno le vendite?', il sistema può semplicemente prolungare la tendenza osservata, presentandola come una previsione. Un'estrapolazione lineare è il metodo previsionale più semplice, e spesso il più fragile: funziona finché nulla cambia.");
    phaseTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiClock", head: "Analisi descrittiva", headSize: 16, bodySize: 13,
      body: bullets(["Che cosa è accaduto", "Dati osservati", "Il risultato è un fatto, se dati e calcoli sono corretti"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiTrendingUp", head: "Analisi predittiva", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Che cosa potrebbe accadere", "Dati storici, metodo, ipotesi", "Il risultato è una stima"], { space: 5 }) });
    shapeBox(s, 0.5, 3.7, 9.0, 1.25, C.text1, "esempio");
    txt(s, [{ text: "Descrizione: ", options: { bold: true, color: C.accent6 } }, { text: "le vendite sono cresciute del 5% all'anno negli ultimi tre anni.", options: { color: C.background1, breakLine: true } }, { text: "Previsione: ", options: { bold: true, color: C.accent6 } }, { text: "cresceranno del 5% il prossimo anno, se le condizioni restano simili.", options: { color: C.background1 } }], { x: 0.75, y: 3.7, w: 8.5, h: 1.25, fontSize: 14, valign: "middle", paraSpaceAfter: 6 });
  }
  {
    const s = content("Modelli previsionali e dati storici", "Una breve introduzione ai modelli previsionali, senza entrare nella tecnica. Un modello previsionale è un metodo che, a partire da dati storici, produce una stima di valori futuri o sconosciuti. I più semplici prolungano una tendenza, eventualmente tenendo conto della stagionalità. Altri usano più variabili: per esempio stimano le vendite a partire da prezzi, promozioni, giorni festivi, condizioni meteo. Altri ancora, basati su Machine Learning, apprendono relazioni complesse da grandi quantità di dati, come visto nel Tema 2. Tutti condividono un'ipotesi di fondo: che le relazioni osservate in passato continuino a valere nel periodo previsto. Questo spiega perché i modelli previsionali funzionano bene in contesti stabili e falliscono davanti a cambiamenti di contesto: una crisi, un nuovo concorrente, un cambio normativo, una pandemia. Spiega anche perché la qualità e la quantità dei dati storici sono decisive: con due anni di dati non si stima bene una stagionalità annuale, con dati di un periodo anomalo si apprendono relazioni anomale. Quando l'AI propone una previsione, la prima domanda è: su quali dati storici si basa, e quanto il futuro previsto assomiglia al passato osservato?");
    phaseTag(s, 2);
    const m = [["Prolungare una tendenza", "Con o senza stagionalità", C.background2], ["Più variabili", "Prezzi, promozioni, festività, meteo", C.accent6], ["Machine Learning", "Relazioni complesse da molti dati (Tema 2)", C.background2]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.25, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.4, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.65, fontSize: 12, color: C.text2 });
    });
    shapeBox(s, 0.5, 2.6, 9.0, 0.85, C.text1, "ipotesi di fondo");
    txt(s, [{ text: "Ipotesi comune: ", options: { bold: true, color: C.accent6 } }, { text: "le relazioni del passato continuano a valere. Funziona in contesti stabili, fallisce davanti ai cambiamenti.", options: { color: C.background1 } }], { x: 0.7, y: 2.6, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
    chip(s, 0.5, 3.65, 4.4, 0.6, "Due anni di dati: stagionalità poco stimabile", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.65, 4.4, 0.6, "Dati di un periodo anomalo: relazioni anomale", { fill: C.background2, fontSize: 12 });
    txt(s, "Prima domanda: su quali dati si basa, e quanto il futuro assomiglia al passato?", { x: 0.5, y: 4.45, w: 9, h: 0.45, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Stime, proiezioni, incertezza", "Ogni previsione è incerta, e una previsione ben fatta lo dichiara. Il grafico fittizio in slide mostra una serie storica di vendite e una proiezione per i sei mesi successivi, con tre linee: una stima centrale e un intervallo tra un valore basso e uno alto. L'intervallo si allarga man mano che ci si allontana dall'ultimo dato osservato: più lontano è il futuro, più è incerto. Questo è il modo corretto di presentare una previsione. Il modo scorretto, molto frequente, è presentare solo la stima centrale, con precisione apparente: 'a giugno venderemo 1.247 pezzi'. Un numero così preciso suggerisce una certezza che non esiste. Quando l'AI produce una previsione, conviene chiedere sempre l'intervallo di incertezza e il metodo usato per calcolarlo; diffidare dei numeri troppo precisi; e ricordare che anche l'intervallo dipende dalle ipotesi: se il contesto cambia, il valore reale può uscire dall'intervallo. Per le decisioni, l'incertezza è un'informazione preziosa, non un difetto della previsione: decidere sapendo che le vendite saranno tra 900 e 1.400 pezzi porta a scelte diverse, più prudenti e più flessibili, rispetto a sapere che saranno 1.247.");
    phaseTag(s, 2);
    const lab = ["G", "F", "M", "A", "M", "G", "L", "A", "S", "O", "N", "D", "G", "F", "M", "A", "M", "G"];
    const hist = [900, 940, 980, 1010, 1000, 1050, 1080, 1020, 1100, 1130, 1150, 1180];
    const n = null;
    const histS = hist.concat([n, n, n, n, n, n]);
    const c = [1180, 1200, 1215, 1230, 1240, 1250, 1260], lo = [1180, 1140, 1100, 1060, 1010, 960, 910], hi = [1180, 1260, 1330, 1400, 1470, 1540, 1610];
    const pad = [n, n, n, n, n, n, n, n, n, n, n];
    lineChart(s, lab, [{ name: "Storico", values: histS, color: HEX.dk1 }, { name: "Stima centrale", values: pad.concat(c), color: HEX.a1 }, { name: "Valore basso", values: pad.concat(lo), color: HEX.a2 }, { name: "Valore alto", values: pad.concat(hi), color: HEX.a2 }], { x: 0.5, y: 1.1, w: 5.6, h: 3.1, min: 800, max: 1700, legend: true, title: "Vendite e proiezione a sei mesi (esempio fittizio)" });
    shapeBox(s, 6.35, 1.15, 3.15, 1.35, C.background2, "scorretto");
    txt(s, "Precisione apparente", { x: 6.5, y: 1.22, w: 2.9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    txt(s, "\"A giugno venderemo 1.247 pezzi\"", { x: 6.5, y: 1.6, w: 2.9, h: 0.8, fontSize: 13, italic: true, color: C.text1 });
    shapeBox(s, 6.35, 2.65, 3.15, 1.55, C.accent6, "corretto");
    txt(s, "Stima con incertezza", { x: 6.5, y: 2.72, w: 2.9, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
    txt(s, "\"Tra 900 e 1.600 pezzi, stima centrale 1.250, se il contesto resta simile\"", { x: 6.5, y: 3.1, w: 2.9, h: 1.0, fontSize: 12, italic: true, color: C.text1 });
    banner(s, 4.4, "Più lontano è il futuro, più è incerto. L'incertezza è un'informazione per decidere, non un difetto.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Simulazioni, scenari, what-if", "Accanto alle previsioni, l'AI può supportare simulazioni e analisi di scenario, che rispondono a domande diverse. Una previsione chiede: che cosa succederà? Uno scenario chiede: che cosa succederebbe se? L'analisi what-if, cioè 'che cosa succede se', modifica una o più variabili e ne calcola le conseguenze: se aumentiamo il prezzo del 5 per cento e i volumi calano del 3, che cosa succede al margine? Le analisi di scenario costruiscono alcune combinazioni coerenti di ipotesi, di solito uno scenario prudente, uno centrale e uno favorevole. La tabella fittizia in slide mostra un esempio. Il valore di questi strumenti è che rendono esplicite le ipotesi e mostrano quanto il risultato dipende da esse: se in tutti gli scenari il progetto è conveniente, la decisione è robusta; se dipende dallo scenario, bisogna capire quale ipotesi conta di più. L'AI è molto efficace nel costruire questi modelli, anche in un foglio di calcolo. Ma le ipotesi di partenza, come l'elasticità dei volumi al prezzo o la crescita del mercato, sono scelte, e il sistema può proporle senza basi solide. Una simulazione è affidabile quanto le sue ipotesi.");
    phaseTag(s, 2);
    table(s, [["Ipotesi", "Prudente", "Centrale", "Favorevole"],
      ["Aumento prezzo", "+5%", "+5%", "+5%"],
      ["Variazione volumi", "-8%", "-3%", "0%"],
      ["Costi unitari", "+4%", "+2%", "+1%"],
      ["Margine risultante", "-3%", "+4%", "+8%"]],
      { y: 1.15, colW: [3.0, 2.0, 2.0, 2.0], rowH: 0.45, fontSize: 13, blankCorner: false, accentCol: 2 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.43, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    chip(s, 0.5, 3.75, 4.4, 0.6, "Previsione: che cosa succederà?", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.75, 4.4, 0.6, "Scenario: che cosa succederebbe se?", { fill: C.accent6, fontSize: 12 });
    txt(s, "Il risultato cambia segno tra gli scenari: la decisione dipende dalla reazione dei volumi. Una simulazione è affidabile quanto le sue ipotesi.", { x: 0.5, y: 4.45, w: 9, h: 0.5, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Le ipotesi alla base", "Ogni previsione e ogni simulazione si basa su ipotesi, spesso implicite. Renderle esplicite è il primo passo per valutarle. Le ipotesi tipiche riguardano quattro aspetti. La continuità: le tendenze e le relazioni del passato continueranno? Il contesto: mercato, concorrenza, norme, prezzi delle materie prime resteranno simili? I comportamenti: come reagiranno clienti, concorrenti, fornitori alle nostre scelte? I dati: sono rappresentativi del periodo da prevedere, o includono periodi anomali? Quando si chiede una previsione all'AI, una buona pratica è chiedere esplicitamente l'elenco delle ipotesi su cui si basa, e per ciascuna quanto è solida e quanto il risultato ne dipende. Spesso emerge che il risultato dipende in modo decisivo da una o due ipotesi, e che proprio quelle sono le più incerte. Su queste conviene concentrare la discussione, magari con chi conosce il mercato o il processo. L'esempio della slide precedente lo mostra: la convenienza dell'aumento di prezzo dipende quasi interamente dall'ipotesi sulla reazione dei volumi, e quella ipotesi non viene dai dati, ma da una valutazione.");
    phaseTag(s, 2);
    await iconGrid(s, [
      { icon: "FiArrowRight", head: "Continuità", body: "Tendenze e relazioni del passato continueranno?" },
      { icon: "FiGlobe", head: "Contesto", body: "Mercato, concorrenza, norme, materie prime" },
      { icon: "FiUsers", head: "Reazioni", body: "Come reagiranno clienti, concorrenti, fornitori?" },
      { icon: "FiDatabase", head: "Dati", body: "Rappresentativi del periodo da prevedere?" },
    ], 4, { y: 1.2, h: 1.9, headSize: 14, bodySize: 12 });
    banner(s, 3.35, "Chiedere l'elenco delle ipotesi: quanto è solida ciascuna, e quanto il risultato ne dipende?", { h: 0.7, fontSize: 14 });
    txt(s, "Spesso il risultato dipende da una o due ipotesi, e proprio quelle sono le più incerte: lì va concentrata la discussione, con chi conosce il mercato.", { x: 0.5, y: 4.2, w: 9, h: 0.7, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Calcolata o supposta?", "Il sottotema chiede di distinguere le previsioni calcolate dalle supposizioni generate dal modello. È l'equivalente, per il futuro, dell'integrazione A del 9.3. Una previsione calcolata è il risultato di un metodo applicato ai dati: un modello statistico, un foglio di calcolo con ipotesi esplicite, un codice eseguito. Si può ripetere, controllare, modificare cambiando le ipotesi. Una supposizione generata è un numero o una tendenza che il modello linguistico produce come testo, sulla base della sua conoscenza generale e del contesto della conversazione: 'il mercato dovrebbe crescere del 7-8 per cento nei prossimi anni'. Può essere ragionevole, può riprendere stime pubblicate, ma non è il risultato di un calcolo sui nostri dati, e spesso non è possibile sapere da dove venga. Il rischio è che le supposizioni generate vengano trattate come previsioni, e magari inserite in un piano o in un business plan. I segnali per distinguerle sono gli stessi del 9.3: c'è un metodo dichiarato? Ci sono i dati e i passaggi? Si può ripetere il calcolo? Se la risposta è no, il numero va trattato come un'opinione da verificare, non come una previsione.");
    phaseTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiCpu", head: "Previsione calcolata", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Un metodo applicato ai nostri dati", "Ipotesi esplicite", "Ripetibile e modificabile"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiMessageSquare", head: "Supposizione generata", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Testo prodotto dalla conoscenza generale", "'Il mercato dovrebbe crescere del 7-8%'", "Origine spesso non ricostruibile"], { space: 5 }) });
    txt(s, "Per distinguerle", { x: 0.5, y: 3.75, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 4.1, 2.9, 0.55, "Un metodo dichiarato?", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 4.1, 2.9, 0.55, "Dati e passaggi visibili?", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 4.1, 2.9, 0.55, "Il calcolo si può ripetere?", { fill: C.background2, fontSize: 12 });
    txt(s, "Se no: un'opinione da verificare, non una previsione.", { x: 0.5, y: 4.72, w: 9, h: 0.3, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Validare le previsioni", "Come si valuta l'affidabilità di una previsione? L'ultimo punto del sottotema riguarda la validazione. Il metodo più semplice e più potente è il confronto con il passato: si applica il metodo previsionale a un periodo passato, usando solo i dati precedenti, e si confronta la previsione con ciò che è effettivamente accaduto. Per esempio, si usano i dati fino a dicembre di due anni fa per prevedere l'anno scorso, e si misura l'errore. Se il metodo avrebbe sbagliato del 20 per cento sull'anno scorso, non c'è motivo di pensare che sarà più preciso sul prossimo. Questo controllo si può chiedere all'AI quando costruisce una previsione. Altri elementi di validazione: confrontare la previsione con metodi diversi, con stime indipendenti, con il giudizio di chi conosce il mercato; verificare che sia plausibile rispetto ai vincoli reali, come la capacità produttiva o la dimensione del mercato. E, nel tempo, monitorare: confrontare regolarmente le previsioni con i risultati effettivi, per capire quanto il metodo è affidabile e quando va rivisto. La modellazione avanzata e le metriche statistiche di errore sono solo da accennare: per le previsioni critiche servono competenze specialistiche.");
    phaseTag(s, 2);
    const st = [["Dati fino a due anni fa", C.background2, C.text1], ["Previsione dell'anno scorso", C.accent6, C.text1], ["Confronto con il reale", C.accent1, C.background1]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      chip(s, x, 1.2, 2.86, 0.75, e[0], { fill: e[1], color: e[2], fontSize: 13 });
      if (i < 2) arrow(s, x + 2.88, 1.42, 0.17);
    });
    txt(s, "Se avrebbe sbagliato del 20% sul passato, perché dovrebbe essere più preciso sul futuro?", { x: 0.5, y: 2.05, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent5, align: "center" });
    await iconGrid(s, [
      { icon: "FiColumns", head: "Confrontare", body: "Metodi diversi, stime indipendenti, esperti" },
      { icon: "FiShield", head: "Vincoli reali", body: "Capacità produttiva, dimensione del mercato" },
      { icon: "FiActivity", head: "Monitorare", body: "Previsioni contro risultati, nel tempo" },
    ], 3, { y: 2.65, h: 1.45, headSize: 14, bodySize: 12 });
    txt(s, "Modellazione avanzata e metriche di errore: solo accennate. Per previsioni critiche servono specialisti.", { x: 0.5, y: 4.35, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Una previsione è una stima condizionata da dati, ipotesi e metodo, non una descrizione certa del futuro.", "Sottotema 9.6  ·  AI, analisi predittiva e simulazioni", "Concetto chiave del sottotema 9.6. L'AI può produrre previsioni, proiezioni, simulazioni e analisi di scenario, rendendo accessibili strumenti prima riservati agli specialisti. Ma l'andamento storico non è una previsione, ogni previsione dipende dalla continuità tra passato e futuro, l'incertezza va dichiarata e usata, le ipotesi vanno rese esplicite, e le supposizioni generate dal modello non vanno confuse con previsioni calcolate. La validazione sul passato è il controllo più semplice e più utile. Esercizio suggerito: chiedere all'AI una previsione su un dataset fittizio, poi chiedere l'elenco delle ipotesi, l'intervallo di incertezza e un test sul periodo precedente, e discutere quanto cambia la fiducia nella previsione.");

  // =====================================================================
  section("9.7 Interpretazione e decisioni");
  divider("9.7", "Interpretazione e decisioni", "La solidità di una decisione non dipende solo dalla correttezza aritmetica degli indicatori", "Arriviamo alla fase finale del processo: dai risultati alle decisioni. In questo sottotema, di consapevolezza decisionale, vediamo come l'AI può aiutare a interpretare i risultati, formulare ipotesi, confrontare alternative e valutare scenari, e dove si collocano i suoi limiti. Due integrazioni sono centrali: dati corretti che portano a conclusioni sbagliate, già vista nel 9.4, e il rischio di decisioni apparentemente oggettive, cioè raccomandazioni numeriche che incorporano assunzioni discutibili. E una distinzione: tra analisi e raccomandazione, tra evidenza quantitativa e giudizio manageriale.");
  {
    const s = content("Dai risultati al significato", "Un'analisi produce risultati; interpretarli significa attribuire loro un significato per una decisione. L'AI può supportare l'interpretazione in diversi modi. Identificare le informazioni rilevanti: in un report con venti indicatori, quali sono quelli che contano per la decisione da prendere? Analizzare possibili cause e conseguenze: perché il margine è calato? Che cosa succederà se il trend continua? Generare ipotesi: quali spiegazioni alternative sono compatibili con i dati? Identificare informazioni mancanti: che cosa servirebbe sapere per decidere con più sicurezza? Su quest'ultimo punto l'AI è particolarmente utile, come visto nel Tema 7 per le omissioni: chiedere 'quali dati mancano per valutare questa decisione?' porta spesso a domande che non ci si era posti. La differenza rispetto alle fasi precedenti è che qui non ci sono più risposte corrette in senso aritmetico. Un'interpretazione può essere più o meno fondata, più o meno completa, più o meno prudente, e dipende dal contesto, dagli obiettivi e dai valori di chi decide. L'AI propone interpretazioni plausibili; la loro adeguatezza al caso concreto va valutata da chi conosce quel caso.");
    phaseTag(s, 3);
    await iconGrid(s, [
      { icon: "FiFilter", head: "Informazioni rilevanti", body: "Quali indicatori contano per questa decisione?" },
      { icon: "FiGitBranch", head: "Cause e conseguenze", body: "Perché è successo? Che cosa succederà?" },
      { icon: "FiHelpCircle", head: "Ipotesi alternative", body: "Quali spiegazioni sono compatibili con i dati?" },
      { icon: "FiSearch", head: "Informazioni mancanti", body: "Che cosa servirebbe sapere per decidere meglio?", fill: C.accent6 },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Qui non ci sono più risposte corrette in senso aritmetico. Un'interpretazione è più o meno fondata, completa, prudente.", { h: 0.7, fontSize: 13 });
    txt(s, "L'AI propone interpretazioni plausibili; la loro adeguatezza la valuta chi conosce il caso.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Confrontare alternative e scenari", "Un uso prezioso dell'AI nel supporto decisionale è il confronto strutturato tra alternative. Data una decisione, per esempio scegliere tra tre fornitori, tra due localizzazioni, tra mantenere o cambiare un processo, il sistema può costruire una matrice con criteri, valori, vantaggi e rischi di ciascuna alternativa; può combinare dati quantitativi, come costi e tempi, con elementi qualitativi, come affidabilità o rischio di dipendenza; può valutare ogni alternativa nei diversi scenari visti nel 9.6. Questo aiuta a non dimenticare criteri, a rendere esplicito il confronto e a discuterlo. Ma un confronto tra alternative richiede scelte che non sono tecniche. Quali criteri considerare? Quanto pesa ciascuno? Il costo conta più della flessibilità? Quale livello di rischio è accettabile? Se si chiede all'AI di scegliere l'alternativa migliore, il sistema dovrà assegnare dei pesi, e lo farà secondo criteri plausibili ma non necessariamente i nostri. Il risultato è una classifica che sembra oggettiva, ma che dipende da pesi che nessuno ha deciso esplicitamente. La pratica corretta è definire i criteri e i pesi, o almeno vedere quelli usati dal sistema, e verificare quanto la classifica cambia modificandoli.");
    phaseTag(s, 3);
    table(s, [["Criterio", "Peso", "Fornitore A", "Fornitore B", "Fornitore C"],
      ["Costo", "?", "Migliore", "Medio", "Peggiore"],
      ["Tempi di consegna", "?", "Medio", "Migliore", "Medio"],
      ["Affidabilità", "?", "Medio", "Medio", "Migliore"],
      ["Rischio di dipendenza", "?", "Alto", "Basso", "Medio"]],
      { y: 1.15, colW: [2.6, 1.0, 1.8, 1.8, 1.8], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.3, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    banner(s, 3.6, "Chi ha deciso i pesi? Una classifica che sembra oggettiva può dipendere da pesi che nessuno ha scelto esplicitamente.", { h: 0.75, fontSize: 13 });
    txt(s, "Definire criteri e pesi, o vedere quelli usati, e verificare quanto la classifica cambia modificandoli.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }
  {
    const s = content("Evidenza e giudizio", "Il sottotema chiede di distinguere l'evidenza quantitativa dal giudizio manageriale. L'evidenza quantitativa è ciò che i dati dicono: il margine del prodotto A è sceso del 4 per cento, il tempo medio di risposta è di due giorni, il 60 per cento dei clienti persi aveva avuto un reclamo. Il giudizio manageriale è ciò che chi decide aggiunge: la conoscenza del mercato, della strategia, delle persone; la valutazione di elementi non misurati, come la reputazione, le relazioni, le opportunità future; i valori e le priorità dell'organizzazione; la responsabilità per le conseguenze. Una buona decisione combina le due cose. Il rischio dell'analisi assistita dall'AI è di sbilanciare la combinazione in due direzioni opposte. Da un lato, dare troppo peso ai numeri, perché sono disponibili, precisi e presentati in modo convincente, trascurando ciò che non è misurato: 'non è nei dati' non significa 'non conta'. Dall'altro, usare i numeri solo per giustificare una decisione già presa, scegliendo l'analisi che la sostiene: con l'AI è facile produrre rapidamente molte analisi e scegliere quella più comoda. In entrambi i casi l'evidenza smette di informare la decisione.");
    phaseTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiBarChart2", head: "Evidenza quantitativa", headSize: 15, bodySize: 12,
      body: bullets(["Ciò che i dati dicono", "Margini, tempi, percentuali", "Precisa, ma parziale"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiUser", head: "Giudizio manageriale", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Mercato, strategia, persone", "Elementi non misurati, valori, priorità", "Responsabilità per le conseguenze"], { space: 4 }) });
    const r = [["Troppo peso ai numeri", "'Non è nei dati' non significa 'non conta'"], ["Numeri per giustificare", "Molte analisi rapide, si sceglie la più comoda"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 3.6, 4.35, 1.3, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 3.7, w: 3.95, h: 0.38, fontSize: 14, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.1, w: 3.95, h: 0.7, fontSize: 12, color: C.background1 });
    });
  }
  {
    const s = content("Analisi o raccomandazione", "Un'altra distinzione del sottotema: tra analisi e raccomandazione decisionale. Un'analisi descrive, spiega, stima: 'il prodotto A ha un margine inferiore del 4 per cento alla media, per l'aumento dei costi di trasporto'. Una raccomandazione dice che cosa fare: 'conviene eliminare il prodotto A dal catalogo'. Tra le due c'è un salto che richiede elementi che non sono nell'analisi: gli obiettivi dell'azienda, i vincoli, le alternative disponibili, gli effetti su altri prodotti e sui clienti, il rischio accettabile. Il prodotto A potrebbe essere poco redditizio ma necessario per mantenere clienti che acquistano anche prodotti molto redditizi. I sistemi AI tendono a produrre raccomandazioni anche quando non sono richieste, perché sono addestrati a essere utili e a concludere: un'analisi finisce spesso con 'si raccomanda di...'. Queste raccomandazioni sono formulate con sicurezza e appaiono come la conseguenza logica dei numeri, ma incorporano ipotesi su obiettivi e vincoli che il sistema non conosce. Conviene separare esplicitamente le due cose: chiedere prima l'analisi, poi, se utile, le opzioni possibili con vantaggi e rischi, e lasciare la raccomandazione a chi conosce obiettivi e vincoli.");
    phaseTag(s, 3);
    docBox(s, 0.5, 1.15, 4.0, 1.25, "Analisi", "Il prodotto A ha un margine inferiore del 4% alla media, per i costi di trasporto.", { fontSize: 13, fill: C.accent6 });
    arrow(s, 4.6, 1.6, 0.4);
    docBox(s, 5.1, 1.15, 4.4, 1.25, "Raccomandazione", "Conviene eliminare il prodotto A dal catalogo.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Il salto richiede elementi che non sono nell'analisi", { x: 0.5, y: 2.55, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const e = ["Obiettivi", "Vincoli", "Alternative", "Effetti su altri prodotti e clienti", "Rischio accettabile"];
    e.forEach((t, i) => chip(s, 0.5 + i * 1.82, 2.95, 1.7, 0.6, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 3.75, "I sistemi tendono a concludere con 'si raccomanda di...'. Chiedere prima l'analisi, poi le opzioni con vantaggi e rischi; la raccomandazione a chi conosce obiettivi e vincoli.", { h: 1.0, fontSize: 13 });
  }
  {
    const s = content("Il rischio di falsa oggettività", "L'integrazione D del tema: il rischio di decisioni apparentemente oggettive. L'esempio, proposto dal documento di perimetro, è questo: un sistema AI conclude che una categoria di clienti è meno redditizia. La conclusione sembra oggettiva, perché viene dai dati. Ma dipende da molte scelte analitiche. Come è stata definita la redditività: margine lordo, margine dopo i costi commerciali, valore nel tempo del cliente? Come sono stati attribuiti i costi: in proporzione al fatturato, al numero di ordini, al tempo dedicato? Quale periodo è stato considerato: un anno normale o un anno anomalo? Sono stati inclusi i costi indiretti, come assistenza e gestione dei resi? Il campione è rappresentativo? La tabella in slide mostra come, con gli stessi dati originali, scelte diverse possono portare a conclusioni diverse, persino opposte. Nessuna delle scelte è sbagliata in sé: sono scelte. Il problema nasce quando vengono fatte implicitamente, dal sistema o dall'analista, e il risultato viene presentato come un fatto. Il messaggio del documento: i dati non producono automaticamente decisioni oggettive; occorrono criteri, interpretazione e valutazione.");
    phaseTag(s, 3);
    docBox(s, 0.5, 1.12, 9.0, 0.62, "Conclusione del sistema (esempio dal perimetro)", "", { fontSize: 12 });
    txt(s, "La categoria di clienti B è meno redditizia.", { x: 4.2, y: 1.18, w: 5.2, h: 0.5, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
    table(s, [["Scelta analitica", "Opzione 1", "Opzione 2"],
      ["Definizione di redditività", "Margine lordo", "Valore del cliente nel tempo"],
      ["Attribuzione dei costi", "Per fatturato", "Per numero di ordini"],
      ["Periodo", "Ultimo anno (anomalo)", "Ultimi tre anni"],
      ["Costi indiretti", "Esclusi", "Inclusi"],
      ["Esito per la categoria B", "Meno redditizia", "Più redditizia"]],
      { y: 1.9, colW: [3.0, 3.0, 3.0], rowH: 0.38, fontSize: 12, blankCorner: false });
    banner(s, 4.35, "Gli stessi dati, scelte diverse, conclusioni opposte. I dati non producono automaticamente decisioni oggettive.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Assunzioni che sembrano fatti", "Generalizziamo l'esempio. Le raccomandazioni numeriche possono incorporare assunzioni discutibili, e non sono necessariamente adeguate al contesto: è ciò che il documento chiama rischio di considerare oggettive valutazioni basate su assunzioni. Le assunzioni più frequenti si nascondono in quattro punti. Nelle definizioni: che cosa si misura e come. Nei pesi: quanto conta ciascun criterio. Nei confini: quali costi, effetti, periodi e soggetti vengono considerati, e quali restano fuori. Negli obiettivi: che cosa si sta ottimizzando, se il margine di breve periodo, la crescita, la soddisfazione dei clienti, la riduzione del rischio. Ognuno di questi punti è una scelta legittima, ma è una scelta, e cambiarla cambia il risultato. Il pericolo specifico dell'AI è duplice. Il sistema fa queste scelte in modo implicito, scegliendo le opzioni più comuni. E presenta il risultato con un linguaggio e un formato che lo fanno apparire oggettivo: numeri precisi, tabelle ordinate, conclusioni nette. Domande utili: quali definizioni, pesi, confini e obiettivi sono stati usati? Chi li ha scelti? Che cosa cambierebbe con scelte diverse? Se la conclusione regge a scelte diverse, è robusta; se no, la decisione dipende dalle scelte, e queste vanno discusse.");
    phaseTag(s, 3);
    await iconGrid(s, [
      { icon: "FiBook", head: "Definizioni", body: "Che cosa si misura e come" },
      { icon: "FiSliders", head: "Pesi", body: "Quanto conta ciascun criterio" },
      { icon: "FiMaximize", head: "Confini", body: "Che cosa resta dentro e fuori" },
      { icon: "FiTarget", head: "Obiettivi", body: "Che cosa si sta ottimizzando" },
    ], 4, { y: 1.2, h: 1.6, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 3.0, 9.0, 0.85, C.background2, "domande");
    txt(s, "Quali scelte sono state fatte?   ·   Chi le ha fatte?   ·   Che cosa cambierebbe con scelte diverse?", { x: 0.7, y: 3.0, w: 8.6, h: 0.85, fontSize: 14, bold: true, color: C.accent1, valign: "middle", align: "center" });
    banner(s, 4.05, "Se la conclusione regge a scelte diverse, è robusta. Se no, la decisione dipende dalle scelte, e queste vanno discusse.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("La responsabilità resta umana", "L'ultimo punto del sottotema è la responsabilità umana nelle decisioni. È il principio che attraversa tutto il percorso, ripreso qui nella sua forma più concreta. Un'analisi assistita dall'AI può essere molto utile per decidere: rende disponibili più informazioni, più rapidamente, con confronti e scenari che prima richiedevano giorni. Ma la decisione resta di chi la prende, e con essa la responsabilità delle conseguenze. 'L'ha detto l'analisi' non è una giustificazione, così come non lo era 'l'ha detto il foglio di calcolo'. Questo ha tre implicazioni pratiche. Chi decide deve capire l'analisi su cui si basa, almeno nelle sue scelte principali: definizioni, ipotesi, limiti. Chi decide deve sapere quanto l'analisi è incerta, e tenerne conto. E chi decide deve poter spiegare la decisione, anche a chi la subisce, con argomenti che vanno oltre il risultato del sistema. Per le decisioni che riguardano le persone, come valutazioni, selezioni, assegnazioni, ci sono anche vincoli etici e normativi specifici, che appartengono all'area della responsabilità e della normativa. Il concetto chiave del sottotema riassume tutto: la solidità di una decisione non dipende solo dalla correttezza aritmetica degli indicatori.");
    phaseTag(s, 3);
    shapeBox(s, 0.5, 1.15, 9.0, 1.0, C.text1, "principio");
    txt(s, "'L'ha detto l'analisi' non è una giustificazione, come non lo era 'l'ha detto il foglio di calcolo'.", { x: 0.75, y: 1.15, w: 8.5, h: 1.0, fontSize: 16, bold: true, color: C.background1, valign: "middle" });
    await iconGrid(s, [
      { icon: "FiEye", head: "Capire l'analisi", body: "Definizioni, ipotesi, limiti principali" },
      { icon: "FiActivity", head: "Conoscerne l'incertezza", body: "E tenerne conto nella decisione" },
      { icon: "FiMessageCircle", head: "Saper spiegare", body: "Con argomenti oltre il risultato del sistema" },
    ], 3, { y: 2.35, h: 1.5, headSize: 14, bodySize: 12 });
    txt(s, "Decisioni sulle persone (valutazioni, selezioni, assegnazioni): vincoli etici e normativi specifici, trattati nell'area responsabilità e normativa.", { x: 0.5, y: 4.1, w: 9, h: 0.75, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("La solidità di una decisione non dipende solo dalla correttezza aritmetica degli indicatori.", "Sottotema 9.7  ·  AI come supporto all'interpretazione e alle decisioni", "Concetto chiave del sottotema 9.7. L'AI può supportare l'interpretazione dei risultati, la generazione di ipotesi, l'individuazione di informazioni mancanti, il confronto tra alternative e scenari. Ma interpretare e decidere richiede criteri, pesi, obiettivi e conoscenza del contesto che non sono nei dati. L'analisi va distinta dalla raccomandazione, l'evidenza quantitativa dal giudizio manageriale, e le scelte analitiche implicite vanno rese esplicite, perché possono cambiare la conclusione pur con dati identici. La responsabilità della decisione resta umana. Esercizio suggerito: partire dall'esempio della redditività dei clienti, con un dataset fittizio, e far calcolare all'AI la redditività con due definizioni diverse, discutendo poi quale sia più adatta alla decisione da prendere.");

  // =====================================================================
  section("9.8 Limiti e affidabilità");
  divider("9.8", "Limiti e condizioni di affidabilità", "Un'analisi AI richiede controlli su dati, metodi e interpretazioni, proporzionati alle conseguenze dell'utilizzo", "Ultimo sottotema, da comprendere bene. Nei sottotemi precedenti abbiamo incontrato i limiti uno per uno, nel punto del processo in cui si presentano. Qui li riuniamo in un quadro complessivo, guardandoli dal punto di vista delle loro conseguenze sull'affidabilità. Due integrazioni si ritrovano qui: il calcolo verificabile, integrazione A, e la falsa oggettività, integrazione D. E il principio conclusivo, coerente con il Tema 7: la validazione proporzionata all'utilizzo previsto. Non ripetiamo i metodi generali di verifica: li applichiamo all'analisi dei dati.");
  {
    const s = content("Dove nascono gli errori", "Una mappa degli errori tipici dell'analisi assistita dall'AI, organizzata lungo il processo. Nei dati: dati incompleti o non rappresentativi del fenomeno, struttura interpretata in modo errato, come una colonna fraintesa o una riga di totale trattata come dato, definizioni diverse da quelle aziendali. Nelle elaborazioni: errori di calcolo, specialmente nei numeri generati senza codice; errori nelle trasformazioni, come unioni tra tabelle che duplicano o perdono righe; errori nelle aggregazioni, come medie di medie o somme di percentuali; mancanti trattati come zeri. Nell'analisi: relazioni casuali presentate come significative, conclusioni tratte da pochi dati, analisi prive di adeguato fondamento statistico. Nella rappresentazione: grafici incoerenti con i dati, periodi selezionati, commenti che vanno oltre i numeri. Nell'interpretazione: correlazioni lette come cause, stime e simulazioni confuse con dati reali, raccomandazioni basate su assunzioni implicite. La mappa mostra un punto importante: gli errori delle prime fasi si propagano a tutte le successive, e diventano più difficili da vedere man mano che il risultato si allontana dai dati di partenza.");
    phaseTag(s, 3);
    const m = [["Dati", ["Incompleti, non rappresentativi", "Struttura fraintesa", "Definizioni diverse"]], ["Elaborazioni", ["Calcoli generati, non eseguiti", "Unioni e aggregazioni errate", "Mancanti come zeri"]], ["Analisi", ["Relazioni casuali", "Conclusioni da pochi dati", "Fondamento statistico debole"]], ["Rappresentazione", ["Grafici incoerenti", "Periodi selezionati", "Commenti oltre i numeri"]], ["Interpretazione", ["Correlazioni come cause", "Stime come dati reali", "Assunzioni implicite"]]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 1.82;
      shapeBox(s, x, 1.15, 1.7, 2.75, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.1, y: 1.22, w: 1.5, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, bullets(e[1], { space: 5 }), { x: x + 0.1, y: 1.68, w: 1.55, h: 2.15, fontSize: 11, color: C.text1 });
    });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 0.5, y: 4.02, w: 9.0, h: 0.3, fill: { color: C.accent5 }, line: { type: "none" }, objectName: "propagazione" });
    txt(s, "Gli errori delle prime fasi si propagano, e diventano più difficili da vedere man mano che ci si allontana dai dati.", { x: 0.5, y: 4.45, w: 9, h: 0.45, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Dati reali, stime, simulazioni", "Un limite specifico, che il sottotema mette in evidenza: la confusione tra dati reali, stime e simulazioni. Nel Tema 7 abbiamo visto la distinzione in generale; nell'analisi assistita il rischio è particolarmente alto, per tre motivi. Primo, nella stessa conversazione o nello stesso report possono convivere numeri di natura diversa: un fatturato osservato, una quota di mercato stimata, una crescita simulata. Se non sono etichettati, vengono letti tutti come dati. Secondo, l'AI può completare i dati mancanti con stime senza dirlo chiaramente: un mese mancante interpolato, un valore di mercato preso dalla sua conoscenza generale, un totale stimato da un campione. Terzo, i risultati vengono riutilizzati: una simulazione prodotta per esplorare uno scenario finisce copiata in una presentazione, dove perde l'etichetta e diventa un dato. Il controllo è semplice da enunciare: per ogni numero importante, sapere se è osservato, stimato o simulato, e da dove viene. Una buona pratica è chiedere al sistema di etichettare esplicitamente la natura di ogni valore in tabelle e report, e mantenere queste etichette quando i risultati vengono riutilizzati.");
    phaseTag(s, 3);
    const t = [["Osservato", "Misurato o registrato", "Fatturato del trimestre", C.accent1, C.background1], ["Stimato", "Calcolato da dati parziali o ipotesi", "Quota di mercato", C.accent6, C.text1], ["Simulato", "Risultato di uno scenario", "Crescita in caso di nuovo prezzo", C.background2, C.text1]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.55, e[3], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.4, fontSize: 17, bold: true, color: i === 0 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.45, fontSize: 12, bold: true, color: e[4] });
      txt(s, e[2], { x: x + 0.15, y: 2.15, w: 2.56, h: 0.45, fontSize: 11, italic: true, color: e[4] });
    });
    const r = [["Convivono", "Numeri di natura diversa nello stesso report"], ["Completamenti silenziosi", "Mancanti stimati senza dirlo"], ["Riutilizzo", "La simulazione perde l'etichetta in una presentazione"]];
    r.forEach((e, i) => {
      const y = 2.9 + i * 0.5;
      txt(s, e[0], { x: 0.5, y, w: 2.6, h: 0.42, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
      txt(s, e[1], { x: 3.1, y, w: 6.4, h: 0.42, fontSize: 12, color: C.text1, valign: "middle" });
    });
    txt(s, "Chiedere di etichettare la natura di ogni valore, e mantenere le etichette nel riutilizzo.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Fondamento statistico", "Un altro limite del sottotema: le analisi prive di adeguato fondamento statistico. Senza entrare in metodi specialistici, tre situazioni frequenti che ogni utilizzatore dovrebbe riconoscere. Pochi dati: una differenza tra due gruppi di dieci persone, o un andamento su quattro mesi, può essere dovuta al caso. L'AI calcolerà comunque percentuali e medie, e le commenterà come se fossero solide. Una domanda utile: su quanti casi si basa questo risultato? Differenze piccole: una differenza del 2 per cento nella soddisfazione tra due sedi può essere rumore, non un fenomeno reale, specialmente se i dati variano molto. Molti confronti: come visto nel 9.4, se si confrontano molte categorie, alcune mostreranno differenze forti per puro caso. Chi analizza con l'AI può sempre chiedere al sistema di valutare se una differenza è statisticamente significativa, cioè se è improbabile che sia dovuta al caso. È un controllo utile, purché si ricordi che la significatività statistica non dice se una differenza è importante nella pratica, e che con pochi dati anche un test può essere poco affidabile. Per analisi destinate a decisioni rilevanti su dati limitati o complessi, conviene coinvolgere chi ha competenze statistiche.");
    phaseTag(s, 3);
    await iconGrid(s, [
      { icon: "FiUsers", head: "Pochi dati", body: "Due gruppi di dieci persone, quattro mesi di andamento" },
      { icon: "FiMinimize2", head: "Differenze piccole", body: "Il 2% tra due sedi può essere solo rumore" },
      { icon: "FiGrid", head: "Molti confronti", body: "Alcune differenze forti emergono per caso" },
    ], 3, { y: 1.2, h: 1.6, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 3.0, 9.0, 0.75, C.accent6, "domanda");
    txt(s, [{ text: "Domanda utile: ", options: { bold: true, color: C.accent1 } }, { text: "su quanti casi si basa questo risultato? La differenza è statisticamente significativa?", options: { color: C.text1 } }], { x: 0.7, y: 3.0, w: 8.6, h: 0.75, fontSize: 13, valign: "middle" });
    banner(s, 3.95, "Significativo non vuol dire importante nella pratica. Per decisioni rilevanti su dati limitati o complessi, coinvolgere competenze statistiche.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Tracciabilità di dati ed elaborazioni", "La tracciabilità, introdotta nel 9.3, è la condizione che rende controllabili tutti gli altri limiti. Un'analisi tracciabile permette di rispondere a quattro domande. Da quali dati parte? Fonte, data di estrazione, filtri, definizioni. Quali elaborazioni sono state eseguite? Pulizia, trasformazioni, calcoli, con il codice o le formule. Su quali ipotesi si basa? Scelte sui mancanti, sugli anomali, sulle definizioni, sulle previsioni. Come si arriva alle conclusioni? Quali risultati sostengono ciascuna affermazione. Senza tracciabilità, l'unico modo per controllare un'analisi è rifarla da capo. Con la tracciabilità, si possono controllare i punti critici in modo mirato. Nel lavoro con l'AI, la tracciabilità non è automatica: alcuni strumenti mostrano il codice e i passaggi, altri solo il risultato. Conviene preferire, per le analisi importanti, strumenti e modalità che lasciano traccia, e chiedere esplicitamente al sistema un registro delle operazioni e delle ipotesi. Un'analisi senza tracciabilità può essere usata per esplorare, ma non dovrebbe sostenere decisioni rilevanti.");
    phaseTag(s, 3);
    const q = [["FiDatabase", "Da quali dati?", "Fonte, estrazione, filtri, definizioni"], ["FiCpu", "Quali elaborazioni?", "Pulizia, trasformazioni, calcoli, codice"], ["FiHelpCircle", "Su quali ipotesi?", "Mancanti, anomali, definizioni, previsioni"], ["FiCheckCircle", "Quali conclusioni?", "Che cosa sostiene ogni affermazione"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.1, i % 2 ? C.accent6 : C.background2, q[i][1]);
      await iconCircle(s, x + 0.75, 1.27, 0.6, q[i][0]);
      txt(s, q[i][1], { x: x + 0.1, y: 1.95, w: 1.95, h: 0.4, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, q[i][2], { x: x + 0.12, y: 2.38, w: 1.91, h: 0.8, fontSize: 11, color: C.text2, align: "center" });
    }
    banner(s, 3.45, "Senza tracciabilità, l'unico controllo è rifare l'analisi. Con la tracciabilità, si controllano i punti critici.", { h: 0.75, fontSize: 13 });
    txt(s, "Un'analisi senza traccia può servire a esplorare, non a sostenere decisioni rilevanti.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("L'apparenza non è affidabilità", "Le integrazioni A e D si incontrano qui, in un'affermazione del documento di perimetro: l'affidabilità non deriva dall'apparenza professionale del risultato, ma da dati, elaborazioni, ipotesi e conclusioni controllabili. È il rischio di falsa oggettività, nella sua forma più generale. Un'analisi prodotta con l'AI ha quasi sempre un'apparenza professionale: tabelle ordinate, grafici curati, numeri con decimali, un linguaggio tecnico e sicuro, conclusioni nette. Sono tutti segnali che, nell'esperienza comune, associamo a un lavoro accurato, perché in passato un'analisi così curata richiedeva tempo e competenza. Con l'AI questo legame si è rotto: la cura formale è diventata gratuita, e non dice più nulla sulla qualità sostanziale. La slide mette a confronto i segnali di apparenza e i segnali di affidabilità. I primi riguardano la forma; i secondi riguardano la possibilità di controllo. Un'analisi affidabile può anche essere presentata in modo semplice; un'analisi presentata in modo impeccabile può non essere affidabile. Per valutare un'analisi, conviene ignorare la forma e cercare i segnali della colonna di destra.");
    phaseTag(s, 3);
    table(s, [["Segnali di apparenza", "Segnali di affidabilità"],
      ["Tabelle ordinate, grafici curati", "Dati di partenza dichiarati"],
      ["Numeri con decimali", "Calcoli eseguiti e controllabili"],
      ["Linguaggio tecnico e sicuro", "Ipotesi esplicite"],
      ["Conclusioni nette", "Incertezze e limiti dichiarati"],
      ["Raccomandazioni precise", "Conclusioni ricondotte ai risultati"]],
      { y: 1.15, colW: [4.5, 4.5], rowH: 0.45, fontSize: 13, blankCorner: false, accentCol: 1 });
    banner(s, 4.0, "Con l'AI la cura formale è diventata gratuita: non dice più nulla sulla qualità sostanziale.", { h: 0.65, fontSize: 14 });
    txt(s, "Integrazioni A e D: calcolo verificabile e falsa oggettività", { x: 0.5, y: 4.72, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Validazione proporzionata all'uso", "Il principio conclusivo del tema, coerente con il Tema 7 e con il Tema 8: la validazione proporzionata all'utilizzo previsto. Non ogni analisi richiede lo stesso controllo, e controllare tutto con la stessa intensità sarebbe impraticabile. Tre livelli, come nel Tema 8. Per esplorare, cioè per farsi un'idea, generare ipotesi, preparare una discussione, basta un controllo di plausibilità: ordini di grandezza, coerenza con ciò che si sa, uno sguardo ai dati. Per lavorare, cioè per analisi interne che orientano attività, conviene controllare i dati di partenza, verificare che i calcoli principali siano eseguiti e non generati, e rifare a campione alcuni risultati. Per decidere o comunicare, cioè per analisi che sostengono decisioni rilevanti, vengono presentate alla direzione o all'esterno, o riguardano persone, serve una validazione completa: tracciabilità di dati, elaborazioni e ipotesi, verifica indipendente dei risultati principali, esplicitazione delle scelte analitiche e della loro influenza, coinvolgimento di competenze specialistiche se necessario. Due fattori alzano il livello: dati di qualità incerta e conseguenze difficili da correggere.");
    phaseTag(s, 3);
    const lv = [["Per esplorare", "Idee, ipotesi, discussioni", "Plausibilità, ordini di grandezza, uno sguardo ai dati", C.background2, C.text1], ["Per lavorare", "Analisi interne che orientano attività", "Dati di partenza, calcoli eseguiti, controlli a campione", C.accent6, C.text1], ["Per decidere o comunicare", "Decisioni rilevanti, direzione, esterno, persone", "Tracciabilità, verifica indipendente, scelte esplicite, specialisti", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.9;
      shapeBox(s, 0.5, y, 9.0, 0.8, l[3], l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.3, h: 0.8, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 3.0, y, w: 2.9, h: 0.8, fontSize: 12, color: l[4], valign: "middle" });
      txt(s, l[2], { x: 6.0, y, w: 3.35, h: 0.8, fontSize: 12, bold: true, color: l[4], valign: "middle" });
    });
    txt(s, "Alzano il livello", { x: 0.5, y: 3.95, w: 2.3, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.8, 3.95, 3.25, 0.55, "Dati di qualità incerta", { fill: C.background2, fontSize: 12 });
    chip(s, 6.2, 3.95, 3.3, 0.55, "Conseguenze difficili da correggere", { fill: C.background2, fontSize: 12 });
    txt(s, "Il principio dei controlli proporzionati è sviluppato nel Tema 7.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Un'analisi AI richiede controlli su dati, metodi e interpretazioni, proporzionati alle conseguenze dell'utilizzo.", "Sottotema 9.8  ·  Limiti e condizioni di affidabilità dell'analisi assistita dall'AI", "Concetto chiave dell'ultimo sottotema. Gli errori dell'analisi assistita nascono nei dati, nelle elaborazioni, nell'analisi, nella rappresentazione e nell'interpretazione, e si propagano. Dati reali, stime e simulazioni vanno distinti ed etichettati; le analisi su pochi dati o con molti confronti vanno lette con cautela; la tracciabilità rende possibile il controllo. E l'affidabilità non deriva dall'apparenza professionale, che con l'AI è diventata gratuita, ma da dati, elaborazioni, ipotesi e conclusioni controllabili. Il controllo va proporzionato all'uso. Esercizio suggerito: dare ai partecipanti un report fittizio prodotto con l'AI, curato nella forma e con alcuni errori sostanziali nascosti, come un mese parziale, una stima non etichettata e una conclusione causale, e chiedere di individuarli usando la tabella dei segnali di affidabilità.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quali attività: tutto il processo, dalla comprensione dei dati all'interpretazione, con un contributo che cambia natura lungo le fasi. Dataset e fogli di calcolo: descrivere la struttura, individuare problemi di qualità, preparare i dati; ma il significato delle colonne e le definizioni vanno confermati. Elaborazioni quantitative: calcoli, aggregazioni, indicatori, statistiche, formule e codice; distinguendo i calcoli eseguiti dai numeri generati. Tendenze, anomalie, relazioni: l'AI le trova rapidamente; ma la correlazione non è causa, e cercando tra molte variabili si trovano relazioni casuali. Grafici e report: rapidi e professionali; ma comunicazione efficace e interpretazione corretta sono diverse. Descrivere, interpretare, prevedere: un fatto, un significato, una stima; e i passaggi tra loro non vanno fatti implicitamente. Decisioni: supporto all'interpretazione, alle alternative e agli scenari; ma analisi e raccomandazione sono diverse, e la responsabilità resta umana. Errori e rischi: lungo tutto il processo, con il rischio trasversale della falsa oggettività. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Quali attività?", "Tutto il processo: il contributo cambia natura lungo le fasi"], ["Dataset e fogli di calcolo?", "Struttura, qualità, preparazione; definizioni da confermare"], ["Elaborazioni quantitative?", "Calcoli, indicatori, codice; eseguiti, non generati"], ["Tendenze, anomalie, relazioni?", "Trovate rapidamente; correlazione non è causa"], ["Grafici e report?", "Rapidi e professionali; efficaci non vuol dire corretti"], ["Descrivere, interpretare, prevedere?", "Un fatto, un significato, una stima"], ["Decisioni aziendali?", "Supporto ad alternative e scenari; la responsabilità resta umana"], ["Errori e rischi?", "Lungo tutto il processo; il rischio trasversale è la falsa oggettività"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.92;
      shapeBox(s, x, y, 4.4, 0.82, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.82, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.08, w: 3.8, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.36, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: comprendere il ruolo dell'AI nel processo di analisi; riconoscere le tipologie di dati e i fattori che ne influenzano la qualità; distinguere dati, metriche e indicatori; comprendere le possibilità di elaborazione quantitativa assistita; distinguere calcoli eseguiti da risultati numerici generati; riconoscere pattern, tendenze, anomalie e correlazioni; comprendere il ruolo dell'AI nella produzione di grafici e report; distinguere analisi descrittiva, diagnostica, predittiva e prescrittiva; comprendere opportunità e limiti di previsioni e simulazioni; distinguere risultati quantitativi e interpretazioni; individuare il rischio di conclusioni errate da dati corretti; comprendere perché le decisioni supportate dall'AI richiedono giudizio e responsabilità umana.");
    const r = ["Il ruolo dell'AI nel processo di analisi", "Tipologie di dati e fattori di qualità", "Dati, metriche e indicatori", "Elaborazione quantitativa assistita", "Calcoli eseguiti o numeri generati", "Pattern, tendenze, anomalie, correlazioni", "Grafici e report con l'AI", "Descrittiva, diagnostica, predittiva, prescrittiva", "Opportunità e limiti delle previsioni", "Risultati quantitativi e interpretazioni", "Conclusioni errate da dati corretti", "Giudizio e responsabilità umana"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Quattro fasi: una scheda pratica", "Traduciamo il modulo in una scheda pratica, organizzata per fasi. Comprendere e preparare: da dove vengono i dati, con quali definizioni? Il significato delle colonne è confermato? Mancanti, duplicati e anomali sono stati gestiti consapevolmente? I dati rappresentano il fenomeno? Elaborare e analizzare: i calcoli sono eseguiti e controllabili? Base, periodo e definizione degli indicatori sono chiari? Media e mediana insieme, e uno sguardo ai dati? Le relazioni trovate sono ipotesi da verificare? Rappresentare e prevedere: il grafico è coerente con i dati, il periodo completo, le etichette giuste? Il commento resta nei numeri? Le previsioni dichiarano ipotesi e incertezza? Interpretare e valutare: dati osservati, stime e simulazioni sono distinti? Le scelte analitiche sono esplicite, e la conclusione regge a scelte diverse? Analisi e raccomandazione sono separate? Il controllo è proporzionato all'uso? E sempre: dati aziendali solo negli strumenti autorizzati, e responsabilità della decisione a chi decide. Non confondere un'analisi dall'aspetto professionale con un'analisi affidabile: è il messaggio centrale del tema.");
    const f = [["Comprendere", ["Provenienza e definizioni", "Colonne confermate", "Mancanti e anomali gestiti", "Rappresentatività"], C.background2], ["Elaborare", ["Calcoli eseguiti", "Base, periodo, definizione", "Media e mediana, e i dati", "Relazioni come ipotesi"], C.accent6], ["Rappresentare", ["Grafico coerente e completo", "Commento nei numeri", "Previsioni con ipotesi e incertezza"], C.background2], ["Interpretare", ["Osservato, stimato, simulato", "Scelte esplicite e robuste", "Analisi separata da raccomandazione"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 5 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 11, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: strumenti autorizzati, controlli proporzionati all'uso, responsabilità a chi decide.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 9 completiamo il secondo tema dell'area 'Esplorare le possibilità dell'AI'. Dopo testi, documenti e conoscenza, abbiamo esplorato i dati e l'analisi. Il tema successivo, il Tema 10, è dedicato all'AI multimodale e alla creazione di contenuti: la capacità dei sistemi di comprendere, generare e trasformare immagini, audio, video, presentazioni e materiali di comunicazione, e di passare da una modalità all'altra. Ritroveremo alcuni principi di questo modulo: un grafico o un'immagine realistica possono convincere senza essere corretti, e ogni trasformazione da una modalità all'altra può introdurre errori, omissioni e alterazioni del significato. I documenti di perimetro richiamano poi altri temi: assistenti, agenti e automazioni, nel Tema 11; AI, dati e conoscenza aziendale, nel Tema 14, dove si affronteranno le condizioni organizzative e tecnologiche per rendere disponibili e utilizzabili i dati di cui abbiamo parlato; opportunità e casi d'uso, nel Tema 15, con la selezione e la valutazione economica dei progetti. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi e documenti\nTema 9: dati e analisi (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.6, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 10: AI multimodale e creazione di contenuti", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Immagini, audio, video, presentazioni", { x: 5.4, y: 2.38, w: 3.9, h: 0.3, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 2.85, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 11: assistenti, agenti e automazioni", "Tema 14: dati e conoscenza aziendale", "Tema 15: opportunità e casi d'uso"], { space: 5 }), { x: 5.4, y: 3.2, w: 3.9, h: 1.5, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo, oltre ai rimandi ai temi precedenti. Il modulo si basa soprattutto su principi consolidati di statistica descrittiva e di lettura critica dei dati, che non dipendono da una singola fonte. Le capacità degli strumenti AI di analisi dei dati, in particolare l'esecuzione di codice e la produzione di grafici, evolvono rapidamente: prima di ogni edizione è consigliabile verificare le funzionalità degli strumenti autorizzati in azienda e aggiornare gli esempi. Tutti gli esempi numerici del modulo sono fittizi, tranne il quartetto di Anscombe.");
    const src = [
      "Anscombe, F. J. (1973). Graphs in Statistical Analysis. The American Statistician, 27(1).",
      "Vigen, T. (2015). Spurious Correlations. Hachette Books.",
      "Gli esempi di dati, grafici, tabelle e report presenti nelle slide sono fittizi, salvo il quartetto di Anscombe.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema9_AI_dati_analisi.pptx" });
  await applyTheme("Tema9_AI_dati_analisi.pptx", THEME);
  console.log("done");
})();
