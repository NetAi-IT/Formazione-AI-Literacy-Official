
  // =====================================================================
  section("12.6 Innovazione");
  divider("12.6", "AI, innovazione e nuove opportunità", "La possibilità tecnica di un nuovo servizio non dimostra che il mercato lo desideri o che sia sostenibile", "Quarto meccanismo: l'innovazione. Finora abbiamo parlato di fare meglio ciò che già si fa, o di fare ciò che prima era troppo costoso. Qui guardiamo a nuovi prodotti, nuovi servizi, nuovi modi di relazionarsi con i clienti. Il documento assegna a questo sottotema una priorità media e un livello di esplorazione: vogliamo che i partecipanti riconoscano le opportunità di innovazione, distinguano ottimizzazione e innovazione, e sappiano che la fattibilità tecnica di un'idea non ne dimostra il valore per i clienti. La valutazione e la selezione delle opportunità appartengono al Tema 15.");
  {
    const s = content("Ottimizzare o innovare", "La distinzione centrale del sottotema, e una delle domande guida: la differenza tra ottimizzazione dell'esistente e innovazione di prodotti e servizi. L'ottimizzazione migliora ciò che l'azienda già fa: lo stesso servizio, più rapido, più economico, di qualità più alta. È ciò di cui abbiamo parlato nei sottotemi 12.3 e 12.4. Il suo valore è di solito più prevedibile e più facile da misurare, ma limitato: si può ridurre un costo fino a un certo punto. L'innovazione cambia ciò che l'azienda offre o il modo in cui lo offre: un servizio nuovo, un prodotto diverso, un nuovo canale, un nuovo modello di relazione con i clienti. Il suo valore potenziale è più alto, ma è più incerto, richiede sperimentazione, e dipende dalla risposta del mercato. Le due strade non sono alternative: molte aziende iniziano dall'ottimizzazione, che produce benefici più rapidi e costruisce competenze, e poi passano all'innovazione. Ma confonderle porta a errori di valutazione: giudicare un'iniziativa di innovazione con i criteri dell'ottimizzazione, chiedendo risparmi immediati, la fa sembrare un fallimento; presentare un'ottimizzazione come innovazione ne gonfia le aspettative.");
    valTag(s, 1);
    table(s, [["", "Ottimizzazione", "Innovazione"],
      ["Che cosa cambia", "Come si fa ciò che già si fa", "Che cosa si offre, o come"],
      ["Esempio", "Risposte ai clienti più rapide", "Un nuovo servizio di consulenza digitale"],
      ["Valore", "Più prevedibile, limitato", "Potenzialmente alto, incerto"],
      ["Come si valuta", "Tempi, costi, qualità", "Sperimentazione, risposta del mercato"]],
      { y: 1.15, colW: [2.4, 3.3, 3.3], rowH: 0.5, fontSize: 12, accentCol: 2 });
    banner(s, 3.85, "Giudicare l'innovazione con i criteri dell'ottimizzazione la fa sembrare un fallimento; il contrario gonfia le aspettative.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Le forme dell'innovazione", "Il sottotema elenca diverse forme in cui l'AI può sostenere l'innovazione. Miglioramento di prodotti e servizi esistenti: aggiungere funzioni basate sull'AI a un prodotto, come un assistente nel software venduto ai clienti. Personalizzazione dell'offerta: proposte, contenuti, servizi adattati al singolo cliente, prima sostenibili solo per i clienti più grandi. Nuove modalità di relazione con i clienti: assistenza disponibile a ogni ora, in più lingue, attraverso canali nuovi. Accelerazione della sperimentazione: prototipi, varianti, test di nuove idee in tempi molto più brevi. Supporto alla generazione di nuove idee: esplorazione di alternative, analisi di tendenze, stimolo alla creatività, come visto nel Tema 5. Nuovi servizi, prima impossibili o non sostenibili. Evoluzione delle modalità di erogazione del valore: per esempio, da un prodotto venduto una volta a un servizio continuativo. Il sottotema richiama anche le opportunità prima economicamente poco praticabili, collegate all'integrazione B: molte innovazioni rese possibili dall'AI non sono tecnicamente nuove, ma diventano sostenibili perché il loro costo si è ridotto drasticamente.");
    valTag(s, 1);
    await iconGrid(s, [
      { icon: "FiPackage", head: "Prodotti migliorati", body: "Funzioni AI in ciò che si vende" },
      { icon: "FiUser", head: "Personalizzazione", body: "Per ogni cliente, non solo i grandi" },
      { icon: "FiMessageCircle", head: "Nuove relazioni", body: "A ogni ora, in più lingue, nuovi canali" },
      { icon: "FiZap", head: "Sperimentazione rapida", body: "Prototipi e test in tempi brevi" },
      { icon: "FiStar", head: "Nuove idee", body: "Alternative, tendenze, creatività" },
      { icon: "FiRefreshCw", head: "Nuovi modelli", body: "Da prodotto a servizio continuativo" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Molte innovazioni non sono tecnicamente nuove: diventano sostenibili perché il loro costo crolla.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Fattibile non vuol dire desiderato", "L'integrazione B nella sua seconda forma: la possibilità tecnica di realizzare un nuovo servizio non dimostra da sola che il mercato lo desideri o che sia economicamente sostenibile. Il sottotema la esprime come differenza tra fattibilità tecnologica e valore per il cliente. È un errore classico dell'innovazione, molto precedente all'AI, ma che l'AI rende più frequente, perché abbassa drasticamente il costo di costruire qualcosa. Si può realizzare in pochi giorni un prototipo di assistente per i clienti, un servizio di analisi personalizzata, un generatore di proposte: la facilità di costruzione crea la tentazione di saltare la domanda più importante, cioè se qualcuno lo vuole. Tre domande, prima di investire. Il cliente ha davvero il problema che il servizio risolve, e quanto gli costa oggi? Preferirebbe questa soluzione a quelle che usa già, comprese quelle senza AI? Sarebbe disposto a pagarla, o ad acquistare di più per averla? E una domanda di sostenibilità: i costi di erogazione, compresi quelli di verifica, supervisione e assistenza visti nel Tema 11, sono compatibili con il prezzo? In alcuni casi i clienti preferiscono esplicitamente un contatto umano, e un servizio basato sull'AI, tecnicamente brillante, peggiora l'esperienza.");
    valTag(s, 1);
    const q = [["Il problema", "Il cliente ce l'ha davvero? Quanto gli costa oggi?"], ["La preferenza", "La preferirebbe alle soluzioni che usa già, anche senza AI?"], ["Il valore", "Pagherebbe, o acquisterebbe di più per averla?"], ["La sostenibilità", "I costi, compresi verifica e supervisione, reggono il prezzo?"]];
    rowsLabel(s, q, { y: 1.15, h: 0.6, lw: 2.3 });
    banner(s, 3.85, "L'AI abbassa il costo di costruire qualcosa, e crea la tentazione di saltare la domanda più importante: qualcuno lo vuole?", { h: 0.8, fontSize: 13 });
    txt(s, "Alcuni clienti preferiscono esplicitamente un contatto umano.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Verificare la domanda reale", "L'ultimo punto del sottotema: la necessità di verificare l'esistenza di una domanda reale. Come si fa, senza entrare nelle metodologie di valutazione del Tema 15? Alcuni principi pratici, comuni a ogni innovazione, che l'AI rende anzi più facili da applicare. Parlare con i clienti prima di costruire: capire il problema dal loro punto di vista, non dal nostro. Sperimentare in piccolo: un prototipo semplice offerto a pochi clienti, un'offerta di prova, un test su un segmento, prima di un investimento completo. L'AI riduce molto il costo di questi esperimenti, ed è uno dei suoi contributi più preziosi all'innovazione. Osservare i comportamenti, non solo le opinioni: i clienti dicono spesso che un servizio è interessante, ma il segnale vero è se lo usano, se ci tornano, se sono disposti a pagare. Definire in anticipo che cosa conterà come successo, e che cosa porterà ad abbandonare l'idea: senza questo criterio, è facile continuare a investire in un'idea perché è tecnicamente riuscita. Il concetto chiave del sottotema riassume: la possibilità tecnica di realizzare un nuovo servizio non dimostra da sola che il mercato lo desideri o che sia economicamente sostenibile.");
    valTag(s, 1);
    numList(s, ["Parlare con i clienti prima di costruire: il problema dal loro punto di vista", "Sperimentare in piccolo: pochi clienti, un segmento, un'offerta di prova", "Osservare i comportamenti, non solo le opinioni: lo usano, ci tornano, pagano?", "Definire prima che cosa conta come successo, e quando abbandonare"], { y: 1.15, h: 0.58, fontSize: 13 });
    banner(s, 3.75, "L'AI riduce molto il costo degli esperimenti: uno dei suoi contributi più preziosi all'innovazione.", { h: 0.75, fontSize: 13 });
    txt(s, "Principi comuni a ogni innovazione; i metodi di valutazione sono un passo successivo.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("La possibilità tecnica di realizzare un nuovo servizio non dimostra da sola che il mercato lo desideri o che sia economicamente sostenibile.", "Sottotema 12.6  ·  AI, innovazione e nuove opportunità", "Concetto chiave del sottotema 12.6. L'AI può sostenere l'innovazione in molte forme: prodotti migliorati, personalizzazione, nuove relazioni con i clienti, sperimentazione rapida, nuove idee, nuovi servizi e modelli. Ottimizzazione e innovazione vanno distinte e valutate con criteri diversi. Ma la fattibilità tecnica non è valore per il cliente, e la facilità di costruire aumenta il rischio di saltare la verifica della domanda, che si fa parlando con i clienti, sperimentando in piccolo, osservando i comportamenti. Esercizio suggerito: in piccoli gruppi, proporre un'idea di nuovo servizio basato sull'AI per i clienti dell'azienda e rispondere alle quattro domande su problema, preferenza, valore e sostenibilità.");

  // =====================================================================
  section("12.7 Costi e condizioni");
  divider("12.7", "Costi, compromessi e condizioni", "Il prezzo dello strumento è solo una componente: formazione, controlli, errori, manutenzione, adattamenti", "Abbiamo visto i meccanismi con cui l'AI crea valore. Ora guardiamo all'altro lato del bilancio: i costi, i compromessi e le condizioni necessarie. In questo sottotema, da comprendere e applicare, vediamo i costi diretti, indiretti e nascosti dell'AI, l'integrazione C sul costo nascosto della verifica, della correzione e dell'integrazione, le condizioni organizzative e informative, la differenza tra beneficio lordo e netto, e l'integrazione D applicata ai costi: la valutazione deve considerare il risultato complessivo del processo. Senza entrare in modelli finanziari, che appartengono al Tema 15.");
  {
    const s = content("Diretti, indiretti, nascosti", "Il sottotema chiede di distinguere tre tipi di costi. I costi diretti sono quelli visibili e preventivati: le licenze degli strumenti, i servizi a consumo, l'infrastruttura, eventuali consulenze per l'introduzione. Sono quelli che compaiono nel budget, e spesso gli unici considerati. I costi indiretti sono reali ma non sempre attribuiti all'AI: il tempo di apprendimento e adozione delle persone, la formazione, il tempo dei referenti interni che supportano i colleghi, l'integrazione con i sistemi esistenti, la manutenzione e l'aggiornamento delle configurazioni, l'adattamento dei processi. I costi nascosti sono quelli che nessuno prevede e spesso nessuno misura: il tempo di verifica e correzione degli output, le rilavorazioni dovute agli errori, le conseguenze degli errori non intercettati, come reclami o danni alla reputazione, il tempo perso con strumenti non adatti al compito, la qualità peggiorata senza che nessuno se ne accorga, il lavoro trasferito ad altri. La distinzione è importante perché, quando si valuta un'iniziativa, si tende a confrontare i benefici lordi con i soli costi diretti: un confronto che sopravvaluta quasi sempre il valore.");
    valTag(s, 2);
    const c = [["Diretti", "Visibili, nel budget", ["Licenze, servizi a consumo", "Infrastruttura", "Consulenze iniziali"], C.background2], ["Indiretti", "Reali, non sempre attribuiti", ["Apprendimento e formazione", "Integrazione e manutenzione", "Adattamento dei processi"], C.accent6], ["Nascosti", "Né previsti né misurati", ["Verifica e correzione", "Errori non intercettati", "Lavoro trasferito ad altri"], C.text1]];
    c.forEach((e, i) => {
      const x = 0.5 + i * 3.07, dark = i === 2;
      shapeBox(s, x, 1.15, 2.86, 2.85, e[3], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.42, fontSize: 18, bold: true, color: dark ? C.accent6 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.35, fontSize: 11, italic: true, color: dark ? C.accent3 : C.text2 });
      txt(s, bullets(e[2], { space: 6 }), { x: x + 0.15, y: 2.1, w: 2.6, h: 1.8, fontSize: 12, color: dark ? C.background1 : C.text1 });
    });
    banner(s, 4.2, "Confrontare benefici lordi con i soli costi diretti sopravvaluta quasi sempre il valore.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Il costo nascosto", "L'integrazione C del tema: il costo nascosto dell'AI, cioè verifica, correzione e integrazione. Il prezzo dello strumento è soltanto una componente dei costi; occorre considerare formazione, controlli, errori, manutenzione e adattamenti operativi. Tre voci meritano un'attenzione particolare. La verifica e la supervisione: come visto nei Temi 7 e 11, gli output e le azioni dell'AI richiedono controlli proporzionati al rischio. Questi controlli hanno un costo in tempo, spesso di persone esperte, che può essere molto rilevante, e che cresce con l'importanza delle attività. La correzione degli errori: gli errori intercettati vanno corretti; quelli non intercettati producono costi più avanti, a volte molto superiori. L'integrazione: perché uno strumento produca valore, deve essere inserito nei processi e collegato ai sistemi e alle informazioni aziendali. Questo richiede lavoro tecnico, ma anche organizzativo: definire chi usa che cosa, come, con quali regole. Il documento chiede di non fermarsi al beneficio lordo apparente. In pratica: per ogni beneficio atteso, chiedersi quali attività di verifica, correzione e integrazione sono necessarie per ottenerlo, e quanto costano. Spesso è proprio questa domanda a distinguere le iniziative che creano valore da quelle che lo promettono.");
    valTag(s, 2);
    await iconGrid(s, [
      { icon: "FiSearch", head: "Verifica e supervisione", body: "Tempo, spesso di persone esperte, che cresce con il rischio" },
      { icon: "FiTool", head: "Correzione degli errori", body: "Intercettati: tempo. Non intercettati: costi più avanti, anche molto maggiori" },
      { icon: "FiLink", head: "Integrazione", body: "Processi, sistemi, informazioni, regole d'uso" },
    ], 3, { y: 1.15, h: 2.0, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 3.35, 9.0, 0.85, C.accent6, "domanda");
    txt(s, [{ text: "Per ogni beneficio atteso: ", options: { bold: true, color: C.accent1 } }, { text: "quali verifiche, correzioni e integrazioni servono per ottenerlo, e quanto costano?", options: { color: C.text1 } }], { x: 0.7, y: 3.35, w: 8.6, h: 0.85, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("La curva dell'adozione", "Un costo indiretto spesso sottovalutato riguarda i tempi di apprendimento e adozione. Quando si introduce un nuovo strumento, la produttività non sale subito: spesso, per un periodo iniziale, scende. Le persone devono imparare a usarlo, capire in quali attività serve e in quali no, sviluppare abitudini di verifica, adattare il modo di lavorare; nel frattempo commettono errori, sperimentano, a volte tornano al metodo precedente. Solo dopo questa fase i benefici iniziano a vedersi, e a volte crescono nel tempo, man mano che le persone diventano più capaci e i processi si adattano. Il grafico in slide, puramente illustrativo e senza dati reali, mostra questa dinamica, che nella letteratura economica sulle tecnologie è nota come curva a J. Le implicazioni sono pratiche. Valutare un'iniziativa troppo presto può far concludere che non funziona, quando è solo nella fase di apprendimento. Al contrario, attendere senza misurare può far continuare un'iniziativa che non produrrà mai benefici. E il costo della fase iniziale, in tempo e in produttività persa, è un investimento che va considerato. La formazione e l'accompagnamento possono ridurlo e accorciarlo; la gestione del cambiamento organizzativo è il tema del Tema 16.");
    valTag(s, 2);
    const lab = ["Avvio", "", "", "", "", "", "", "", "", "", "", "Nel tempo"];
    lineChart(s, lab, [{ name: "Produttività (illustrativa)", values: [100, 94, 90, 89, 92, 97, 103, 108, 112, 115, 117, 118] }, { name: "Prima dell'AI", values: [100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100], color: HEX.a3 }], { x: 0.5, y: 1.1, w: 5.6, h: 3.0, min: 80, max: 125, legend: true, title: "Curva a J dell'adozione (illustrativa, senza dati reali)" });
    const t = [["Apprendimento", "Imparare, sperimentare, sbagliare"], ["Adattamento", "Abitudini di verifica, nuovi modi di lavorare"], ["Benefici", "Crescono con competenze e processi"]];
    t.forEach((e, i) => {
      const y = 1.15 + i * 0.98;
      shapeBox(s, 6.35, y, 3.15, 0.88, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.06, w: 2.9, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.42, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.3, "Valutare troppo presto fa concludere che non funziona; non misurare fa continuare ciò che non funzionerà mai.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Le condizioni per generare valore", "Oltre ai costi, il sottotema indica alcune condizioni senza le quali il valore non si genera, qualunque sia la qualità dello strumento. La disponibilità e la qualità delle informazioni: un assistente sulla documentazione aziendale vale quanto la documentazione; un'analisi vale quanto i dati, come visto nei Temi 8 e 9. Le condizioni informative e tecnologiche sono il tema del Tema 14. La compatibilità con attività e processi: lo strumento deve inserirsi nel modo in cui il lavoro viene svolto, non richiedere passaggi aggiuntivi che ne annullano i vantaggi. Uno strumento ottimo, ma separato dagli applicativi in cui si lavora, viene usato poco. Gli effetti sulle modalità organizzative: l'introduzione dell'AI può richiedere di cambiare ruoli, responsabilità, flussi di approvazione, criteri di valutazione delle prestazioni. Se l'organizzazione non cambia, i benefici restano locali, come visto nel 12.3. La riprogettazione del lavoro è il tema del Tema 13. Le competenze delle persone, per usare bene lo strumento e per verificarne i risultati. E la sostenibilità dei benefici nel tempo: gli strumenti cambiano, i fornitori aggiornano i modelli, i costi variano, le persone cambiano ruolo. Un beneficio ottenuto oggi va mantenuto, con aggiornamenti, monitoraggio, formazione continua.");
    valTag(s, 2);
    await iconGrid(s, [
      { icon: "FiDatabase", head: "Informazioni", body: "Disponibili e di qualità" },
      { icon: "FiGitMerge", head: "Compatibilità", body: "Dentro il modo in cui si lavora, non a lato" },
      { icon: "FiUsers", head: "Organizzazione", body: "Ruoli, flussi, criteri che cambiano" },
      { icon: "FiBookOpen", head: "Competenze", body: "Per usare bene e per verificare" },
      { icon: "FiClock", head: "Sostenibilità", body: "Modelli, costi, persone cambiano: mantenere" },
      { icon: "FiAlertCircle", head: "Senza condizioni", body: "Nessun valore, qualunque sia lo strumento", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Se l'organizzazione non cambia, i benefici restano locali.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Beneficio lordo e beneficio netto", "La distinzione che il sottotema chiede di rendere operativa: beneficio lordo e beneficio netto. Il beneficio lordo è il miglioramento osservato o atteso, prima di sottrarre ciò che è servito per ottenerlo: le ore risparmiate, i costi evitati, i ricavi aggiuntivi. Il beneficio netto è ciò che resta dopo aver sottratto tutti i costi: diretti, indiretti e nascosti. Il grafico fittizio in slide, con numeri inventati e unità arbitrarie, mostra il passaggio. Un beneficio lordo di 100 si riduce per il costo degli strumenti, della verifica, delle correzioni, della formazione e dell'integrazione, fino a un beneficio netto di 35. È ancora un beneficio positivo, ma un terzo di quello lordo. In altri casi, il beneficio netto può essere nullo o negativo, anche con un beneficio lordo evidente. Il documento chiede di introdurre il concetto di beneficio netto senza entrare nei modelli finanziari di calcolo del ritorno sull'investimento, che appartengono al Tema 15. Il punto qui è concettuale: ogni volta che si sente parlare di un beneficio dell'AI, conviene chiedersi se è lordo o netto, e quali costi sono stati considerati.");
    valTag(s, 2);
    const cats = ["Beneficio lordo", "Strumenti", "Verifica", "Correzioni", "Formazione", "Integrazione", "Beneficio netto"];
    const vis = [100, 15, 20, 10, 10, 10, 35], base = [0, 85, 65, 55, 45, 35, 0];
    s.addChart(pres.charts.BAR, [{ name: "base", labels: cats, values: base }, { name: "valore", labels: cats, values: vis }], {
      x: 0.5, y: 1.1, w: 9.0, h: 2.85, barDir: "col", barGrouping: "stacked", chartColors: ["FFFFFF", HEX.a5], showLegend: false,
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 110, valGridLine: { style: "none" }, barGapWidthPct: 40,
      showTitle: true, title: "Dal beneficio lordo al netto (numeri inventati, unità arbitrarie)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
    txt(s, "100", { x: 0.95, y: 1.45, w: 0.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, align: "center" });
    txt(s, "35", { x: 8.15, y: 2.55, w: 0.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, align: "center" });
    banner(s, 4.1, "Ogni volta che si parla di un beneficio dell'AI: è lordo o netto? Quali costi sono stati considerati?", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Benefici locali, vincoli del processo", "L'integrazione D torna in questo sottotema: la valutazione deve tener conto del risultato complessivo del processo, anche quando il miglioramento della singola attività è evidente. Nel 12.3 l'abbiamo vista dal punto di vista dei tempi; qui dal punto di vista dei costi e dei vincoli. Un miglioramento locale può generare costi altrove nel processo: più volume prodotto in una fase può creare code nella fase successiva; più rapidità in una fase può ridurre la qualità che una fase successiva deve correggere; una nuova attività di verifica può essere aggiunta in una fase diversa da quella che ha ottenuto il beneficio, e a carico di un'altra funzione. Inoltre, i vincoli del processo complessivo limitano i benefici possibili: un'attività che non è il collo di bottiglia può essere accelerata indefinitamente senza effetti sul risultato. Per questo, il beneficio netto va calcolato sul processo, non sull'attività. Un esempio fittizio: un'iniziativa che dimezza i tempi di preparazione delle pratiche, ma raddoppia quelli di controllo nell'ufficio di un'altra funzione, e lascia invariato il tempo complessivo di evasione, ha un beneficio locale evidente e un beneficio netto per il processo negativo.");
    valTag(s, 2);
    const e = [["Più volume in una fase", "Code nella fase successiva"], ["Più rapidità", "Meno qualità, da correggere più avanti"], ["Nuova verifica", "A carico di un'altra funzione"], ["Fase non critica accelerata", "Nessun effetto sul risultato"]];
    rowsLabel(s, e, { y: 1.15, h: 0.52, lw: 3.2 });
    docBox(s, 0.5, 3.6, 9.0, 1.3, "Esempio fittizio", "Preparazione delle pratiche dimezzata, controllo raddoppiato nell'ufficio di un'altra funzione, tempo complessivo di evasione invariato: beneficio locale evidente, beneficio netto per il processo negativo.", { fontSize: 13, fill: C.accent6 });
  }
  keySlide("Il costo nascosto dell'AI: il prezzo dello strumento è soltanto una componente; occorre considerare formazione, controlli, errori, manutenzione e adattamenti operativi.", "Sottotema 12.7  ·  Costi, compromessi e condizioni", "Concetto chiave del sottotema 12.7, che coincide con l'integrazione C. I costi dell'AI sono diretti, indiretti e nascosti, e i più rilevanti sono spesso verifica, correzione e integrazione. L'adozione segue una curva a J, con un costo iniziale di apprendimento. Il valore richiede condizioni: informazioni, compatibilità con i processi, cambiamenti organizzativi, competenze, sostenibilità nel tempo. Il beneficio netto, calcolato sul processo e non sulla singola attività, può essere molto diverso dal beneficio lordo. Esercizio suggerito: per un'iniziativa AI fittizia, elencare in gruppo tutti i costi diretti, indiretti e nascosti che verrebbero in mente, e confrontare la lista con quella che comparirebbe in un tipico budget.");

  // =====================================================================
  section("12.8 Valore misurabile");
  divider("12.8", "Dal valore potenziale al valore misurabile", "Verificare che il tempo risparmiato diventi beneficio, includendo i costi per ottenerlo e mantenerlo", "Ultimo sottotema, da comprendere e applicare. Abbiamo visto che cos'è il valore, come si crea, che cosa costa. Resta la domanda finale: come si sa se c'è? In questo sottotema distinguiamo aspettative e risultati, benefici dichiarati e osservati, e introduciamo i concetti di base della misurazione: obiettivi, situazione iniziale, indicatori, confronto con e senza AI. Senza entrare nei sistemi avanzati di misurazione delle prestazioni e nell'analisi del ritorno sull'investimento, che appartengono al Tema 15. Le integrazioni A e C si ritrovano qui come criteri di misurazione: il tempo risparmiato deve tradursi in un beneficio valorizzato, e il beneficio va considerato al netto dei costi.");
  {
    const s = content("Ipotizzato, percepito, misurato", "Una delle domande guida chiede di distinguere valore ipotizzato, beneficio percepito e miglioramento effettivamente misurato. Sono tre livelli diversi di conoscenza del valore, e spesso vengono confusi. Il valore ipotizzato è quello atteso prima di iniziare: le stime di un fornitore, le promesse di un progetto, i risultati di altre aziende o di studi. È utile per decidere se provare, ma non dimostra nulla sul nostro caso. Il beneficio percepito è quello che le persone sentono dopo aver iniziato, come visto nel 12.1: importante per l'adozione, ma soggetto a distorsioni, nei due sensi. Il miglioramento misurato è quello osservato confrontando i risultati prima e dopo, o con e senza AI, con indicatori definiti. È l'unico che permette di dire che il valore c'è. Il sottotema parla di differenza tra aspettative e risultati, e tra benefici dichiarati e osservati. Il passaggio da un livello all'altro è il cuore del sottotema. Un'organizzazione che decide sulla base del valore ipotizzato, e valuta sulla base di quello percepito, non sa davvero se le sue iniziative AI funzionano. Il documento chiede di evitare di trasformare stime o esperienze isolate in promesse generali di produttività.");
    valTag(s, 3);
    const l = [["Ipotizzato", "Prima di iniziare", "Stime, promesse, risultati di altri", "Serve per decidere se provare", C.background2, C.text1], ["Percepito", "Dopo aver iniziato", "Ciò che le persone sentono", "Conta per l'adozione, ma distorto", C.accent6, C.text1], ["Misurato", "Confrontando", "Prima e dopo, con e senza, con indicatori", "L'unico che dice che il valore c'è", C.accent1, C.background1]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.4, e[4], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.42, fontSize: 18, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.66, w: 2.56, h: 0.3, fontSize: 11, italic: true, color: e[5] });
      txt(s, e[2], { x: x + 0.15, y: 2.02, w: 2.56, h: 0.65, fontSize: 12, color: e[5] });
      txt(s, e[3], { x: x + 0.15, y: 2.75, w: 2.56, h: 0.7, fontSize: 12, bold: true, color: i === 2 ? C.accent6 : C.accent5 });
      if (i < 2) arrow(s, x + 2.88, 2.2, 0.17);
    });
    banner(s, 3.8, "Chi decide sul valore ipotizzato e valuta su quello percepito non sa se le sue iniziative funzionano.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Obiettivi e situazione iniziale", "Le basi della misurazione sono due, e vanno definite prima di introdurre l'AI, non dopo. La prima: obiettivi concreti. 'Migliorare l'efficienza con l'AI' non è un obiettivo misurabile. 'Ridurre da tre giorni a uno il tempo medio di risposta alle richieste di offerta, mantenendo il tasso di errori sotto il 2 per cento' lo è. Un obiettivo concreto indica che cosa deve cambiare, di quanto, entro quando, e quali vincoli vanno rispettati. La seconda: la situazione iniziale, cioè come stanno le cose prima. Quanto tempo richiede oggi l'attività? Quanti errori ci sono? Quanto costa? Quanto sono soddisfatti i clienti? Senza la situazione iniziale, non si può dire se qualcosa è migliorato: si può solo dire come stanno le cose dopo. Questo sembra ovvio, ma è uno degli errori più frequenti: si introduce lo strumento, e solo dopo, quando qualcuno chiede quali benefici ha prodotto, ci si accorge di non sapere come si lavorava prima. A quel punto restano le percezioni. Misurare la situazione iniziale richiede un po' di lavoro, ma è la condizione per sapere, più avanti, se l'investimento ha prodotto valore.");
    valTag(s, 3);
    docBox(s, 0.5, 1.15, 4.35, 1.4, "Non misurabile", "\"Migliorare l'efficienza con l'AI.\"", { fontSize: 14, bar: C.accent5, labelColor: C.accent5 });
    docBox(s, 5.15, 1.15, 4.35, 1.4, "Misurabile", "\"Da tre giorni a uno per le offerte, con errori sotto il 2%, entro sei mesi.\"", { fontSize: 13, fill: C.accent6 });
    const q = ["Che cosa cambia", "Di quanto", "Entro quando", "Con quali vincoli"];
    q.forEach((t, i) => chip(s, 0.5 + i * 2.3, 2.7, 2.15, 0.5, t, { fill: C.background2, fontSize: 12 }));
    shapeBox(s, 0.5, 3.4, 9.0, 1.5, C.text1, "situazione iniziale");
    txt(s, "La situazione iniziale, prima di introdurre l'AI", { x: 0.75, y: 3.48, w: 8.5, h: 0.38, fontSize: 15, bold: true, color: C.accent6 });
    txt(s, "Tempi, errori, costi, soddisfazione oggi. Senza, si può dire solo come stanno le cose dopo: restano le percezioni.", { x: 0.75, y: 3.9, w: 8.5, h: 0.9, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Indicatori di risultato", "Il sottotema introduce gli indicatori di risultato, e la misurazione di tempi, qualità, costi e capacità. Riprendiamo, in forma sintetica, gli indicatori principali per ciascuna dimensione. Tempi: tempo per attività, comprensivo di verifica e correzione; tempo complessivo del processo, dalla richiesta alla consegna; tempi di attesa. Qualità: errori, rilavorazioni, completezza, reclami, come visto nel 12.4. Costi: costi diretti e indiretti dell'AI, costo per unità di risultato, come il costo per pratica gestita. Capacità: volumi gestiti, arretrati, attività prima non svolte e ora possibili. A questi si aggiungono gli indicatori dei benefici indiretti, che il sottotema chiede di valutare: soddisfazione dei dipendenti, tempi di inserimento dei nuovi colleghi, soddisfazione dei clienti. Tre avvertenze pratiche. Scegliere pochi indicatori, legati all'obiettivo, invece di misurare tutto. Includere almeno un indicatore di qualità accanto a quelli di tempo, per non premiare la velocità a scapito della correttezza. Misurare a livello del processo, non solo dell'attività, per cogliere l'integrazione D. I sistemi avanzati di misurazione delle prestazioni sono solo da accennare.");
    valTag(s, 3);
    table(s, [["Dimensione", "Indicatori tipici"],
      ["Tempi", "Per attività con verifica; del processo; di attesa"],
      ["Qualità", "Errori, rilavorazioni, completezza, reclami"],
      ["Costi", "Diretti e indiretti; costo per unità di risultato"],
      ["Capacità", "Volumi, arretrati, attività nuove"],
      ["Benefici indiretti", "Soddisfazione, tempi di inserimento, clienti"]],
      { y: 1.15, colW: [2.5, 6.5], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    const a = ["Pochi indicatori, legati all'obiettivo", "Sempre almeno uno di qualità", "Misurare sul processo, non solo sull'attività"];
    a.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.85, 2.86, 0.75, t, { fill: C.accent6, fontSize: 12 }));
  }
  {
    const s = content("Con e senza AI", "Il confronto tra attività con e senza AI è il modo più diretto per misurare un beneficio. Ma va fatto con alcune attenzioni, perché è facile ottenere confronti fuorvianti. Confrontare attività comparabili: se con l'AI si gestiscono le pratiche semplici e senza AI quelle complesse, i tempi non sono confrontabili. Considerare tutto il tempo, compresa la verifica e le rilavorazioni, e non solo quello di produzione, come visto nel 12.3. Considerare la qualità, non solo il tempo. Tenere conto degli altri cambiamenti avvenuti nello stesso periodo: se insieme all'AI è stato introdotto un nuovo processo, o sono arrivati nuovi colleghi, o è cambiata la stagione, il miglioramento non è attribuibile solo all'AI. Tenere conto della curva di apprendimento vista nel 12.7: misurare troppo presto sottostima i benefici. Quando possibile, il confronto più solido è tra due gruppi che lavorano nello stesso periodo su attività simili, uno con e uno senza AI, come negli studi citati nel 12.3. Non sempre è praticabile in azienda, ma anche un confronto semplice, fatto con queste attenzioni, è molto più informativo delle percezioni. Il sottotema richiama anche la distinzione tra beneficio individuale e organizzativo: il confronto va fatto anche sui risultati del team e del processo.");
    valTag(s, 3);
    rowsLabel(s, [["Attività comparabili", "Non pratiche semplici con AI e complesse senza"], ["Tutto il tempo", "Produzione, verifica, rilavorazioni"], ["Anche la qualità", "Non solo la velocità"], ["Altri cambiamenti", "Nuovi processi, persone, stagionalità nello stesso periodo"], ["Curva di apprendimento", "Misurare troppo presto sottostima"]], { y: 1.15, h: 0.5, lw: 2.6 });
    banner(s, 4.15, "Il confronto più solido: due gruppi simili, nello stesso periodo, con e senza AI. Anche un confronto semplice batte le percezioni.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Verso il beneficio netto", "Le integrazioni A e C si ritrovano qui come due verifiche di misurazione. Integrazione A: verificare che il tempo risparmiato si traduca in un beneficio effettivamente valorizzato. Non basta misurare le ore risparmiate: bisogna chiedersi che cosa è successo a quelle ore, come visto nel 12.3. Si sono tradotte in più volumi, in nuove attività, in maggiore qualità, in minori costi esterni? Oppure sono state assorbite o disperse? Solo nel primo caso il tempo risparmiato è diventato valore. Integrazione C: includere i costi necessari per ottenere e mantenere il risultato, senza fermarsi al beneficio lordo apparente. Nel conto vanno messi tutti i costi visti nel 12.7, compresi quelli di verifica, correzione, formazione, integrazione, e i costi di mantenimento nel tempo. Mettendo insieme le due verifiche si arriva al concetto di beneficio netto, che il sottotema chiede di introdurre: il valore effettivamente valorizzato, meno tutti i costi necessari per ottenerlo e mantenerlo. Lo schema in slide riassume il percorso, dal risparmio apparente al beneficio netto. Il calcolo analitico del ritorno sull'investimento, con modelli finanziari e business case, appartiene al Tema 15.");
    valTag(s, 3);
    const st = [["Tempo risparmiato apparente", C.background2, C.text1], ["meno verifica e correzioni", C.background2, C.text1], ["Tempo effettivamente risparmiato", C.accent6, C.text1], ["quanto è valorizzato? (A)", C.background2, C.text1], ["Beneficio valorizzato", C.accent6, C.text1], ["meno tutti i costi (C)", C.background2, C.text1], ["Beneficio netto", C.accent1, C.background1]];
    st.forEach((e, i) => {
      const y = 1.12 + i * 0.44;
      const op = i % 2 === 1;
      shapeBox(s, op ? 2.2 : 1.2, y, op ? 5.6 : 7.6, 0.38, e[1], e[0]);
      txt(s, e[0], { x: op ? 2.3 : 1.3, y, w: op ? 5.4 : 7.4, h: 0.38, fontSize: op ? 11 : 13, bold: !op, italic: op, color: e[2], align: "center", valign: "middle" });
    });
    txt(s, "Un ragionamento, non un modello finanziario: il calcolo analitico del ritorno è un passo successivo.", { x: 0.5, y: 4.3, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2, align: "center" });
  }
  {
    const s = content("Limiti delle misurazioni", "Il sottotema chiede anche di riconoscere i limiti delle misurazioni, per non cadere nell'eccesso opposto: credere che tutto ciò che conta si possa misurare, o che ciò che si misura sia tutto ciò che conta. Alcuni limiti tipici. Non tutto è misurabile con precisione: la qualità di una decisione, l'apprendimento, la reputazione si stimano, non si misurano. Le misure possono essere distorte dal modo in cui vengono raccolte: le persone tendono a migliorare ciò che sanno essere misurato, a volte a scapito di ciò che non lo è. È un fenomeno noto come legge di Goodhart: quando una misura diventa un obiettivo, cessa di essere una buona misura. Attribuire un risultato all'AI è difficile quando molti fattori cambiano insieme. I benefici di lungo periodo, come le competenze o l'innovazione, emergono dopo il periodo di misurazione. Misurare ha un costo, che deve essere proporzionato all'importanza della decisione. Nessuno di questi limiti è un motivo per non misurare: sono motivi per misurare con attenzione, combinare indicatori quantitativi con valutazioni qualitative, e dichiarare l'incertezza dei risultati. È lo stesso equilibrio visto nel Tema 9 per l'analisi dei dati: i numeri sono indispensabili, ma non parlano da soli.");
    valTag(s, 3);
    await iconGrid(s, [
      { icon: "FiHelpCircle", head: "Non tutto è misurabile", body: "Decisioni, apprendimento, reputazione: si stimano" },
      { icon: "FiTarget", head: "Legge di Goodhart", body: "Quando una misura diventa obiettivo, smette di misurare bene" },
      { icon: "FiShuffle", head: "Attribuzione", body: "Molti fattori cambiano insieme" },
      { icon: "FiClock", head: "Lungo periodo", body: "Competenze e innovazione emergono dopo" },
    ], 2, { y: 1.15, H: 2.55, headSize: 14, bodySize: 12 });
    banner(s, 3.9, "Non motivi per non misurare, ma per misurare con attenzione: indicatori e valutazioni qualitative, incertezza dichiarata.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Adozione e impatto, di nuovo", "Chiudiamo il sottotema, e il tema, tornando a una distinzione introdotta nel 12.1: adozione dello strumento e impatto aziendale. Il sottotema la ripropone come criterio di misurazione, perché è l'errore più frequente nel modo in cui le organizzazioni valutano le iniziative AI. Gli indicatori di adozione sono facili da raccogliere, e spesso sono gli unici disponibili: numero di licenze, utenti attivi, richieste al giorno, percentuale di dipendenti che hanno usato lo strumento. Sono utili per capire se lo strumento viene usato, e per individuare dove la formazione o l'accompagnamento servono di più. Ma non sono indicatori di valore. Un'alta adozione è compatibile con un impatto nullo, o persino negativo, se lo strumento è usato per attività poco rilevanti, se gli errori aumentano, se il tempo risparmiato si disperde. Il documento lo indica come prima cosa da evitare: confondere la frequenza d'uso dello strumento con l'impatto aziendale. E il dodicesimo risultato atteso del tema lo riassume: l'adozione dell'AI non costituisce, da sola, una misura del valore prodotto. La misura del valore sta negli indicatori di risultato, collegati agli obiettivi, al netto dei costi, a livello di processo e di organizzazione.");
    valTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiUsers", head: "Indicatori di adozione", headSize: 16, bodySize: 12,
      body: bullets(["Licenze, utenti attivi, richieste al giorno", "Facili da raccogliere", "Utili per formazione e accompagnamento", "Non misurano il valore"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiTrendingUp", head: "Indicatori di risultato", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Collegati agli obiettivi", "Al netto dei costi", "A livello di processo e di organizzazione", "Misurano il valore"], { space: 4 }) });
    banner(s, 3.8, "Un'alta adozione è compatibile con un impatto nullo, o negativo. L'adozione da sola non misura il valore prodotto.", { h: 0.85, fontSize: 13 });
  }
  keySlide("Verificare che il tempo risparmiato si traduca in un beneficio effettivamente valorizzato, includendo i costi necessari per ottenere e mantenere il risultato.", "Sottotema 12.8  ·  Dal valore potenziale al valore misurabile", "Concetto chiave dell'ultimo sottotema, che riunisce le integrazioni A e C. Valore ipotizzato, percepito e misurato sono diversi, e solo l'ultimo dice che il valore c'è. Misurare richiede obiettivi concreti e la situazione iniziale, definiti prima; pochi indicatori di risultato, con almeno uno di qualità, a livello di processo; confronti con e senza AI fatti con attenzione. Il beneficio netto è il beneficio valorizzato meno tutti i costi. Le misurazioni hanno limiti, da gestire e non da usare come scusa. E l'adozione non misura il valore. Esercizio suggerito: per un'iniziativa AI reale o fittizia, scrivere un obiettivo misurabile, indicare la situazione iniziale da rilevare e scegliere tre indicatori, di cui uno di qualità.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle nove domande guida. Creare valore: contribuire a un obiettivo concreto e rilevante, per l'organizzazione, i dipendenti o i clienti, al netto dei costi. Tipi di benefici: efficienza, produttività, qualità, meno errori, esperienza del cliente, decisioni, flessibilità, innovazione; tangibili e intangibili. Tempo e produttività: il tempo va verificato, valorizzato, e non deve riguardare un passaggio che non è il collo di bottiglia. Qualità: con criteri osservabili, attenzione alla qualità apparente e agli errori sistematici. Competenze e cose nuove: amplificare senza sostituire, e riconoscere il valore delle attività prima impossibili. Ottimizzare o innovare: migliorare ciò che si fa o offrire qualcosa di nuovo, con criteri di valutazione diversi. Costi: diretti, indiretti e nascosti, soprattutto verifica, correzione e integrazione. Ipotizzato, percepito, misurato: solo il terzo dice che il valore c'è. Singola attività e processo: il processo va al ritmo del collo di bottiglia, e i costi possono spostarsi altrove. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Che cosa significa creare valore?", "Contribuire a un obiettivo rilevante, al netto dei costi"], ["Quali benefici?", "Otto dimensioni, tangibili e intangibili"], ["Meno tempo, più produttività?", "Solo se verificato, valorizzato, sul collo di bottiglia"], ["Qualità senza nuovi problemi?", "Criteri osservabili, attenzione agli errori sistematici"], ["Competenze e cose nuove?", "Amplificare, non sostituire; attività prima impossibili"], ["Ottimizzare o innovare?", "Criteri di valutazione diversi"], ["Quali costi?", "Diretti, indiretti, nascosti: verifica e integrazione"], ["Ipotizzato, percepito, misurato?", "Solo il misurato dice che il valore c'è"], ["Attività o processo?", "Il ritmo è quello del collo di bottiglia"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.74;
      shapeBox(s, x, y, 4.4, 0.66, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.66, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.04, w: 3.8, h: 0.3, fontSize: 11, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.33, w: 3.8, h: 0.3, fontSize: 10, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere capacità tecnologica, utilizzo e valore aziendale; riconoscere le principali dimensioni del valore dell'AI; comprendere la differenza tra efficienza e produttività; distinguere miglioramenti individuali e organizzativi; riconoscere il ruolo dell'AI nel miglioramento della qualità; comprendere come l'AI possa amplificare competenze e capacità; individuare opportunità di innovazione oltre alla riduzione dei tempi; riconoscere i principali costi diretti e indiretti dell'adozione; comprendere perché migliorare un'attività non significa necessariamente migliorare il processo; distinguere benefici lordi e netti; riconoscere la differenza tra benefici attesi e risultati misurati; comprendere perché l'adozione dell'AI non costituisce, da sola, una misura del valore prodotto.");
    const r = ["Capacità, utilizzo, valore", "Le dimensioni del valore", "Efficienza e produttività", "Individuale e organizzativo", "AI e qualità", "Amplificare competenze e capacità", "Innovazione oltre i tempi", "Costi diretti e indiretti", "Attività migliore, processo uguale", "Benefici lordi e netti", "Attesi e misurati", "Adozione non è valore"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Domande sul valore", "Traduciamo il modulo in una scheda pratica: le domande da porsi davanti a un'iniziativa AI, propria o di altri, per ragionare sul suo valore. Definire: quale problema risolve? Per chi crea valore, e su quali dimensioni? Meccanismi: fa risparmiare tempo, migliora la qualità, amplia le capacità, permette di innovare? Il tempo risparmiato, al netto della verifica, come sarà valorizzato? Riguarda il collo di bottiglia? Condizioni: quali sono i costi diretti, indiretti e nascosti, in particolare di verifica, correzione e integrazione? Ci sono le informazioni, la compatibilità con i processi, le competenze? Verificare: qual è l'obiettivo misurabile e la situazione iniziale? Quali indicatori, con almeno uno di qualità? Il beneficio è lordo o netto, individuale o organizzativo, percepito o misurato? Sono domande che non richiedono competenze finanziarie, ma che fanno emergere la maggior parte delle illusioni sul valore. Il Tema 15 le trasformerà in un metodo di valutazione e selezione delle opportunità.");
    const f = [["Definire", ["Quale problema?", "Per chi, su quali dimensioni?"], C.background2], ["Meccanismi", ["Tempo, qualità, capacità, innovazione?", "Tempo valorizzato?", "Collo di bottiglia?"], C.accent6], ["Condizioni", ["Costi nascosti: verifica, integrazione?", "Informazioni, processi, competenze?"], C.background2], ["Verificare", ["Obiettivo e situazione iniziale?", "Indicatori, uno di qualità?", "Lordo o netto? Misurato?"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Domande senza competenze finanziarie, che fanno emergere la maggior parte delle illusioni sul valore.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei errori tipici quando si parla di valore dell'AI. Quattro sono indicati esplicitamente dal documento di perimetro. Primo: confondere la frequenza d'uso dello strumento con l'impatto aziendale. L'adozione è una condizione, non una misura del valore. Secondo: trasformare stime o esperienze isolate in promesse generali di produttività. Un risultato ottenuto in un'altra azienda, in uno studio, o da un collega entusiasta, non si trasferisce automaticamente. Terzo: misurare soltanto il tempo risparmiato senza considerare revisione, rilavorazione e qualità. Il tempo apparente sopravvaluta il beneficio. Quarto: scambiare la qualità apparente per qualità effettiva. Testi più fluidi e ordinati possono nascondere errori, anche sistematici. Quinto: dare per scontato che, se la tecnologia rende possibile un nuovo servizio, i clienti lo vorranno. Prima va verificata la domanda reale. Sesto: presumere che fattibilità tecnologica e adozione producano automaticamente convenienza. Che si possa fare, e che venga usato, non significa che convenga, al netto dei costi. Queste avvertenze sono anche un filtro critico utile per leggere annunci, presentazioni e articoli sui benefici dell'AI. Il messaggio centrale del tema le riassume: l'AI crea valore quando contribuisce a miglioramenti rilevanti e verificabili per l'organizzazione.");
    const a = [["FiBarChart2", "\"Lo usano tutti, quindi funziona\"", "L'adozione non misura il valore", "12.1"], ["FiVolume2", "\"Altrove ha dato il +30%\"", "Un risultato altrui non si trasferisce", "12.3"], ["FiClock", "\"Risparmiamo due ore a testa\"", "E revisione, rilavorazione, qualità?", "12.3"], ["FiStar", "\"È scritto meglio, vale di più\"", "Qualità apparente non è effettiva", "12.4"], ["FiShoppingBag", "\"Si può fare, i clienti lo vorranno\"", "Prima verificare la domanda reale", "12.6"], ["FiTool", "\"Fattibile e usato, quindi conviene\"", "Conta il beneficio netto", "12.7"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 2.95, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.7, y: y + 0.1, w: 0.55, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 12 abbiamo aperto l'area 'Comprendere il valore per l'azienda', costruendo i concetti per ragionare sul valore dell'AI in modo realistico. Il tema successivo, il Tema 13, è dedicato all'AI e alla trasformazione del lavoro e dei processi: come l'AI modifica le attività professionali, i processi operativi, la collaborazione, le competenze e i ruoli. È il naturale proseguimento di molti punti di questo modulo: abbiamo visto che il tempo liberato va valorizzato con scelte organizzative, che i benefici restano locali se i processi non cambiano, che le competenze vanno mantenute, che il lavoro può essere trasferito invece che eliminato. Il Tema 13 affronterà proprio come riprogettare attività, processi e ruoli, riconoscendo che gli effetti sul lavoro dipendono tanto dalle capacità tecnologiche quanto dalle scelte organizzative. Seguiranno il Tema 14, sui dati e la conoscenza aziendale, e il Tema 15, sulla valutazione e selezione delle opportunità e dei casi d'uso, dove le domande di questo modulo diventeranno un metodo. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 12: creazione di valore (completato)", { x: 0.75, y: 4.07, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 13: AI e trasformazione del lavoro e dei processi", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Attività, processi, collaborazione, competenze, ruoli", { x: 5.4, y: 2.4, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.0, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 14: dati e conoscenza aziendale", "Tema 15: opportunità e casi d'uso"], { space: 5 }), { x: 5.4, y: 3.35, w: 3.9, h: 1.2, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. I due studi sulla produttività sono citati nelle versioni pubblicate, verificate a ottobre 2026; le versioni preliminari del 2023 riportano valori leggermente diversi. La pagina dell'articolo di Solow è indicata a memoria: da verificare. I due studi sono tra i più citati sull'AI generativa al lavoro: conviene verificarne i dettagli e cercare studi più recenti prima di ogni edizione, perché la ricerca in questo campo è molto attiva. Il paradosso di Solow, la teoria dei vincoli e la legge di Goodhart sono concetti consolidati, citati qui come strumenti di ragionamento. Tutti gli esempi numerici del modulo sono inventati a scopo didattico, compreso quello del documento di perimetro.");
    const src = [
      "Brynjolfsson, E., Li, D., Raymond, L. (2025). Generative AI at Work. The Quarterly Journal of Economics, 140(2), 889-942.",
      "Dell'Acqua, F. et al. (2026). Navigating the Jagged Technological Frontier. Organization Science, 37(2), 403-423.",
      "Solow, R. (1987). We'd Better Watch Out. New York Times Book Review, 12 luglio 1987, p. 36.",
      "Goldratt, E. M., Cox, J. (1984). The Goal. North River Press (teoria dei vincoli).",
      "Gli esempi numerici delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema12_AI_creazione_valore_azienda.pptx" });
  await applyTheme("Tema12_AI_creazione_valore_azienda.pptx", THEME);
  console.log("done");
})();
