  function valTag(s, active) {
    const st = ["Definire", "Meccanismi", "Condizioni", "Verificare"];
    st.forEach((t, i) => {
      const x = 6.3 + i * 0.81;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.78, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "dimensione " + t });
      txt(s, t, { x, y: 0.42, w: 0.78, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function checkGrid(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, rh = o.rh || 0.66, gap = o.gap || 0.09;
    items.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = y0 + row * (rh + gap);
      shapeBox(s, x, y, 4.4, rh, row % 2 ? C.accent6 : C.background2, "voce " + (i + 1));
      s.addShape(pres.shapes.RECTANGLE, { x: x + 0.15, y: y + rh / 2 - 0.13, w: 0.26, h: 0.26, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 }, objectName: "casella " + (i + 1) });
      if (Array.isArray(e)) {
        txt(s, e[0], { x: x + 0.55, y, w: 1.9, h: rh, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
        txt(s, e[1], { x: x + 2.45, y, w: 1.85, h: rh, fontSize: 11, color: C.text1, valign: "middle" });
      } else txt(s, e, { x: x + 0.55, y, w: 3.8, h: rh, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 12", { placeholder: "kicker" });
    s.addText("AI e creazione di valore per l'azienda", { placeholder: "title" });
    s.addText("Area: Comprendere il valore per l'azienda", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al dodicesimo tema, che apre una nuova area del percorso: 'Comprendere il valore per l'azienda'. Nelle aree precedenti abbiamo visto che cos'è l'AI, come interagire con essa, e che cosa può fare: con testi e documenti, dati, contenuti multimodali, assistenti e agenti. Ora cambiamo prospettiva. Non ci chiediamo più che cosa l'AI sa fare, ma quando e come quello che sa fare diventa valore per l'azienda, per chi ci lavora, per i clienti. È una domanda meno ovvia di quanto sembri. Usare l'AI non produce automaticamente valore: ci sono costi, compromessi, condizioni, e i benefici che si vedono in una singola attività non sempre si ritrovano nei risultati dell'organizzazione. Questo tema fornisce i concetti per ragionare sul valore in modo realistico, senza entusiasmi ingiustificati e senza scetticismi preconcetti. Non entriamo nel calcolo analitico del ritorno sull'investimento, nei business case e nella selezione dei progetti: saranno ripresi nel Tema 15. Suggerimento per l'apertura: chiedere ai partecipanti di indicare un'attività in cui l'AI li ha fatti risparmiare tempo, e poi chiedere che cosa hanno fatto con quel tempo. La risposta introduce bene uno dei temi centrali del modulo. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026, compresi i dati dei due studi sulla produttività, citati nelle versioni pubblicate; la ricerca in questo campo è molto attiva, quindi conviene cercare studi più recenti prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere attraverso quali meccanismi l'AI possa contribuire alla creazione di valore aziendale, distinguendo opportunità tecnologiche, benefici potenziali, risultati effettivi, costi, compromessi e condizioni necessarie. La consapevolezza da sviluppare: l'utilizzo dell'AI non produce automaticamente valore. Il valore nasce quando le capacità tecnologiche contribuiscono a risultati rilevanti per l'azienda, i dipendenti o i clienti, tenendo conto della qualità, della produttività, dell'innovazione, dei costi e degli effetti sull'organizzazione. Il messaggio centrale del tema: l'AI crea valore quando contribuisce a miglioramenti rilevanti e verificabili per l'organizzazione; il valore dipende dagli obiettivi, dai risultati effettivamente ottenuti, dai costi necessari e dall'impatto complessivo sulle attività e sui processi. Il confine con il Tema 15: qui spieghiamo come l'AI può creare valore; nel Tema 15 vedremo come valutare e scegliere opportunità specifiche per un'azienda.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Capire i meccanismi con cui l'AI crea valore", "Distinguere opportunità, benefici potenziali e risultati effettivi", "Considerare costi, compromessi e condizioni"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Usare l'AI non produce automaticamente valore.\n\nIl valore nasce quando le capacità contribuiscono a risultati rilevanti per azienda, dipendenti o clienti, tenendo conto di qualità, produttività, innovazione, costi ed effetti sull'organizzazione." });
  }
  {
    const s = content("Tre equivalenze da evitare", "Il documento di perimetro indica tre equivalenze da evitare, che riassumono bene lo spirito del tema e che conviene presentare subito. Primo: un maggiore utilizzo dell'AI non equivale automaticamente a un maggiore valore aziendale. Si può usare molto uno strumento per attività poco rilevanti, o in modo che i benefici siano annullati dai costi. Secondo: il tempo risparmiato non equivale necessariamente a un identico aumento della produttività. Il tempo liberato può essere assorbito da controlli, o non essere riutilizzabile, o riguardare un'attività che non era il collo di bottiglia. Terzo: la fattibilità tecnologica non equivale a convenienza economica e organizzativa. Che qualcosa si possa fare con l'AI non significa che convenga farlo. Ciascuna di queste equivalenze corrisponde a un errore frequente nel modo in cui si parla di AI in azienda, e ciascuna verrà sviluppata nel modulo. Suggerimento: chiedere ai partecipanti se hanno sentito, in azienda o nei media, affermazioni che cadono in una di queste equivalenze.");
    const e = [["FiBarChart2", "Più utilizzo", "più valore", "Si può usare molto uno strumento per attività poco rilevanti"], ["FiClock", "Tempo risparmiato", "produttività equivalente", "Il tempo liberato può essere assorbito o non riutilizzabile"], ["FiTool", "Fattibilità tecnologica", "convenienza", "Si può fare non significa che convenga"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.15 + i * 1.08;
      shapeBox(s, 0.5, y, 9.0, 0.96, i % 2 ? C.accent6 : C.background2, e[i][1]);
      await iconCircle(s, 0.68, y + 0.2, 0.56, e[i][0]);
      txt(s, e[i][1], { x: 1.4, y: y + 0.06, w: 2.4, h: 0.84, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, "≠", { x: 3.8, y: y + 0.06, w: 0.5, h: 0.84, fontSize: 28, bold: true, color: C.accent5, align: "center", valign: "middle" });
      txt(s, e[i][2], { x: 4.3, y: y + 0.06, w: 2.4, h: 0.84, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[i][3], { x: 6.7, y: y + 0.06, w: 2.7, h: 0.84, fontSize: 11, color: C.text2, valign: "middle" });
    }
    banner(s, 4.4, "Ciascuna corrisponde a un errore frequente nel modo in cui si parla di AI in azienda.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Nove domande guida", "Le nove domande guida accompagnano il modulo. Le prime due riguardano la definizione: che cosa significa creare valore con l'AI, e quali tipi di benefici, economici e non, possiamo riconoscere. Le successive quattro riguardano i meccanismi: perché ridurre il tempo di un'attività non garantisce più produttività, come migliorare la qualità senza introdurre nuovi problemi, come l'AI può amplificare le competenze e rendere possibili attività prima impraticabili, e la differenza tra ottimizzazione e innovazione. La settima riguarda i costi: diretti, indiretti e nascosti. L'ottava la verifica: distinguere valore ipotizzato, beneficio percepito e miglioramento misurato. L'ultima riprende un tema trasversale: perché il miglioramento di una singola attività può non migliorare l'intero processo. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Che cosa significa creare valore con l'AI?", "Quali benefici economici e non economici?", "Perché meno tempo non vuol dire più produttività?", "Come migliorare la qualità senza nuovi problemi?", "Come amplificare competenze e fare cose prima impossibili?", "Ottimizzare l'esistente o innovare?", "Quali costi diretti, indiretti e nascosti?", "Valore ipotizzato, percepito o misurato?", "Perché un'attività migliore non migliora il processo?"], 3, 1.12, 1.0, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in quattro dimensioni. Definire il valore: che cosa significa e in quali dimensioni si manifesta, nei sottotemi 12.1 e 12.2. Comprenderne i meccanismi: attraverso quali vie l'AI produce valore, cioè efficienza e produttività, qualità, amplificazione delle competenze, innovazione, dal 12.3 al 12.6. Considerarne le condizioni: costi, compromessi e vincoli organizzativi, nel 12.7. Verificarne l'effettività: distinguere benefici attesi, percepiti e misurati, nel 12.8. Tre precisazioni trasversali accompagnano tutto il tema. Distinguere sempre benefici potenziali e risultati effettivi. Separare produttività individuale e produttività organizzativa. Riconoscere il valore non immediatamente monetizzabile, senza considerarlo automaticamente dimostrato. Nelle slide, un indicatore in alto a destra ricorda la dimensione di cui stiamo parlando.");
    const d = [["FiCompass", "Definire il valore", "12.1  12.2"], ["FiSettings", "Comprenderne i meccanismi", "12.3  12.4  12.5  12.6"], ["FiSliders", "Considerarne le condizioni", "12.7"], ["FiCheckCircle", "Verificarne l'effettività", "12.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.0, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.03, w: 1.9, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.65, w: 1.9, h: 0.35, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Tre precisazioni trasversali", { x: 0.5, y: 3.3, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const p = ["Distinguere benefici potenziali e risultati effettivi", "Separare produttività individuale e organizzativa", "Riconoscere il valore non monetizzabile, senza darlo per dimostrato"];
    p.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.7, 2.86, 1.0, t, { fill: C.accent6, fontSize: 12 }));
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, innovazione e business, con priorità media. Vanno compresi e applicati: le dimensioni del valore, efficienza e produttività, benefici netti, risultati individuali e complessivi, benefici attesi e misurati. Vanno conosciuti e compresi: l'ampliamento delle competenze, la qualità, l'innovazione, le opportunità di nuovi prodotti e servizi, i costi indiretti. Vanno solo accennati: ROI analitico, modelli finanziari, business case strutturati, valutazioni di investimento e sistemi avanzati di misurazione delle prestazioni, che saranno ripresi nel Tema 15. Confini: non ripetiamo le funzionalità viste nei Temi dall'8 all'11, perché qui il punto è il valore. Non trattiamo la riprogettazione di flussi, attività e ruoli, del Tema 13; le condizioni informative e tecnologiche, del Tema 14; la selezione delle iniziative, del Tema 15; la gestione del cambiamento, del Tema 16; normativa, sicurezza e governance, dei Temi 17 e 18.");
    pathSlide(s, [["12.1", "Che cosa significa creare valore", "Alta"], ["12.2", "Le dimensioni del valore", "Alta"], ["12.3", "Efficienza e produttività", "Alta"], ["12.4", "Qualità e prestazioni", "Alta"], ["12.5", "Amplificare le competenze", "Alta"], ["12.6", "Innovazione e business", "Media"], ["12.7", "Costi, compromessi, condizioni", "Alta"], ["12.8", "Dal potenziale al misurabile", "Alta"]],
      [["Comprendere e applicare", "Dimensioni, produttività, benefici netti, individuale e organizzativo, atteso e misurato", C.accent1, C.background1], ["Conoscere e comprendere", "Competenze, qualità, innovazione, nuovi servizi, costi indiretti", C.accent6, C.text1], ["Solo accennare", "ROI analitico, modelli finanziari, business case", C.background2, C.text1]]);
  }

  // =====================================================================
  section("12.1 Che cosa significa valore");
  divider("12.1", "Che cosa significa creare valore con l'AI", "Il valore non deriva dalla disponibilità di uno strumento, ma dal suo contributo a un obiettivo concreto", "Partiamo dalla domanda più semplice e più importante: che cosa intendiamo per valore? In questo sottotema, da comprendere, distinguiamo la capacità tecnologica dal valore aziendale, vediamo l'AI come mezzo e non come obiettivo, e chiariamo per chi e a quale livello si crea valore. Introduciamo anche due distinzioni che torneranno per tutto il modulo: tra beneficio percepito ed effettivo, e tra adozione tecnologica e impatto organizzativo.");
  {
    const s = content("Dalla capacità al valore", "Il primo punto del sottotema è la differenza tra capacità tecnologica e valore aziendale. Tra le due c'è una catena di passaggi, e ciascuno può interrompersi. La capacità: che cosa lo strumento sa fare, per esempio riassumere documenti, scrivere bozze, analizzare dati. L'utilizzo: le persone lo usano davvero, nelle attività in cui può servire. Il risultato: l'utilizzo produce un cambiamento osservabile nell'attività, come meno tempo, meno errori, risposte più rapide. Il valore: quel cambiamento conta per l'organizzazione, i dipendenti o i clienti, al netto dei costi necessari. Esempi di interruzione: uno strumento capace che nessuno usa, perché non è integrato nel lavoro; un uso diffuso che non produce risultati, perché riguarda attività marginali; un risultato locale che non cambia nulla per l'organizzazione, perché il tempo risparmiato non viene usato in modo diverso. Gran parte dei discorsi sull'AI si ferma al primo anello, la capacità, e dà per scontati gli altri. Questo modulo serve proprio a guardare gli anelli successivi.");
    valTag(s, 0);
    const ch = [["Capacità", "Che cosa sa fare lo strumento"], ["Utilizzo", "Le persone lo usano davvero"], ["Risultato", "Un cambiamento osservabile"], ["Valore", "Conta per qualcuno, al netto dei costi"]];
    ch.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.05, 1.5, i === 3 ? C.accent1 : (i ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.3, w: 1.8, h: 0.42, fontSize: 17, bold: true, color: i === 3 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.75, w: 1.85, h: 0.85, fontSize: 12, color: i === 3 ? C.background1 : C.text1 });
      if (i < 3) arrow(s, x + 2.07, 1.8, 0.2);
    });
    const br = ["Capace, ma nessuno lo usa", "Usato, ma su attività marginali", "Risultato locale, nulla cambia per l'organizzazione"];
    br.forEach((t, i) => chip(s, 1.3 + i * 2.3, 2.9, 2.15, 0.7, t, { fill: C.background2, color: C.accent5, fontSize: 11 }));
    banner(s, 3.85, "Gran parte dei discorsi sull'AI si ferma alla capacità e dà per scontati gli altri anelli.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("L'AI come mezzo", "Il secondo punto: l'AI è un mezzo, non un obiettivo. Sembra ovvio, ma nella pratica è frequente l'approccio opposto: 'dobbiamo usare l'AI', 'cerchiamo dove applicare l'AI', 'quanti dipendenti usano l'AI?'. È l'atteggiamento della soluzione in cerca di un problema. Il documento indica la relazione corretta: problemi, bisogni, obiettivi, risultati. Si parte da un problema o un bisogno reale: i tempi di risposta ai clienti sono troppo lunghi, le offerte contengono errori, i nuovi colleghi impiegano mesi per diventare autonomi. Si definisce un obiettivo: rispondere entro un giorno, dimezzare gli errori, ridurre i tempi di inserimento. Si valutano le soluzioni possibili, tra cui l'AI, ma anche un cambiamento di processo, una regola, una persona in più, un altro strumento. Si misurano i risultati rispetto all'obiettivo. In questa sequenza, l'AI è una delle possibili risposte, e a volte non è la migliore. Partire dall'AI porta invece a progetti che dimostrano che lo strumento funziona, ma non che risolve qualcosa di importante. Un buon segnale: quando si parla di un progetto AI, si riesce a dire quale problema risolve e come si capirà se l'ha risolto?");
    valTag(s, 0);
    const st = [["Problema o bisogno", "Le risposte ai clienti sono lente"], ["Obiettivo", "Rispondere entro un giorno"], ["Soluzioni possibili", "AI, processo, regole, persone, strumenti"], ["Risultato", "Misurato rispetto all'obiettivo"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.05, 1.5, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.28, w: 1.85, h: 0.5, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.8, w: 1.85, h: 0.8, fontSize: 12, italic: true, color: C.text1 });
      if (i < 3) arrow(s, x + 2.07, 1.8, 0.2);
    });
    shapeBox(s, 0.5, 2.9, 9.0, 0.85, C.text1, "anti modello");
    txt(s, [{ text: "La soluzione in cerca di un problema: ", options: { bold: true, color: C.accent6 } }, { text: "'dobbiamo usare l'AI', 'cerchiamo dove applicarla'. Dimostra che lo strumento funziona, non che risolve qualcosa.", options: { color: C.background1 } }], { x: 0.7, y: 2.9, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
    txt(s, "Un buon segnale: si sa dire quale problema risolve, e come si capirà se l'ha risolto?", { x: 0.5, y: 3.95, w: 9, h: 0.5, fontSize: 14, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Per chi e a quale livello", "Il valore ha un destinatario e un livello. Il documento indica tre destinatari. L'organizzazione: risultati economici, capacità operativa, competitività, gestione dei rischi. I dipendenti: meno attività ripetitive e frustranti, più tempo per il lavoro qualificato, supporto nell'apprendimento, minore stress in alcune attività; ma anche, potenzialmente, nuovi carichi e nuove pressioni. I clienti: risposte più rapide, servizi migliori o nuovi, maggiore personalizzazione. I tre valori non coincidono sempre: un'automazione può ridurre i costi per l'organizzazione peggiorando l'esperienza dei clienti, come un servizio di assistenza solo automatico; o migliorare l'esperienza dei clienti aumentando il carico dei dipendenti. E indica tre livelli. Il valore individuale: la singola persona lavora meglio o più rapidamente. Il valore di team: il gruppo coordina meglio, condivide di più, consegna prima. Il valore organizzativo: l'azienda ottiene risultati migliori. Il passaggio da un livello all'altro non è automatico, ed è uno dei temi centrali del modulo: molti benefici si fermano al livello individuale. Aggiungiamo un'ultima distinzione del sottotema: tra benefici economici, misurabili in denaro, e non economici, come la soddisfazione, la qualità del lavoro, la reputazione, che sono reali ma più difficili da misurare.");
    valTag(s, 0);
    const d = [["FiBriefcase", "Organizzazione", "Risultati, capacità, competitività, rischi"], ["FiUsers", "Dipendenti", "Meno ripetitività, più lavoro qualificato; ma anche nuovi carichi"], ["FiSmile", "Clienti", "Risposte rapide, servizi migliori, personalizzazione"]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.15, 2.86, 1.75, { icon: d[i][0], inline: true, head: d[i][1], headSize: 14, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: d[i][2] });
    }
    txt(s, "Tre livelli", { x: 0.5, y: 3.05, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const l = ["Individuale", "Di team", "Organizzativo"];
    l.forEach((t, i) => {
      chip(s, 0.5 + i * 3.07, 3.42, 2.6, 0.55, t, { fill: [C.background2, C.accent6, C.accent1][i], color: i === 2 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 2) arrow(s, 3.15 + i * 3.07, 3.54, 0.35, C.accent5);
    });
    txt(s, "I valori per i tre destinatari non coincidono sempre, e molti benefici si fermano al livello individuale.", { x: 0.5, y: 4.2, w: 9, h: 0.6, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Percepito o effettivo", "Una distinzione che il sottotema introduce e che il 12.8 svilupperà: tra beneficio percepito e beneficio effettivo. Il beneficio percepito è quello che le persone sentono di ottenere: 'con l'AI scrivo le email in metà tempo', 'mi sento più produttivo'. È importante, perché influenza la soddisfazione e l'adozione. Ma non coincide necessariamente con il beneficio effettivo, cioè il cambiamento osservabile nei risultati. Le ragioni della differenza sono diverse. La percezione tende a considerare il tempo di produzione e a trascurare quello di verifica e correzione. Tende a ricordare i casi riusciti e a dimenticare quelli in cui si è dovuto rifare il lavoro. Può confondere la sensazione di fluidità e di sollievo con un risultato migliore. Al contrario, a volte la percezione sottovaluta i benefici, per esempio quando migliorano la qualità o riducono errori che nessuno vedeva. Alcuni studi sul lavoro con l'AI hanno osservato differenze significative tra il tempo che le persone credevano di aver risparmiato e quello misurato. La conclusione pratica è semplice: la percezione è un'informazione utile, ma non una misura. Per sapere se c'è un beneficio, bisogna osservare i risultati.");
    valTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiSmile", head: "Beneficio percepito", headSize: 16, bodySize: 12,
      body: bullets(["'Scrivo le email in metà tempo'", "Conta per soddisfazione e adozione", "Trascura verifica, correzioni, casi falliti"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiBarChart2", head: "Beneficio effettivo", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Il cambiamento osservabile nei risultati", "Comprende tutto il tempo e la qualità", "A volte maggiore del percepito"], { space: 5 }) });
    banner(s, 3.8, "La percezione è un'informazione utile, non una misura. Per sapere se c'è un beneficio, bisogna osservare i risultati.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Adozione non è impatto", "Gli ultimi due punti del sottotema. La dipendenza del valore dal contesto aziendale: lo stesso strumento può creare molto valore in un'azienda e poco in un'altra, a seconda delle attività svolte, della qualità dei dati, dell'organizzazione del lavoro, delle competenze, dei vincoli normativi. I risultati di un'altra azienda, o di uno studio, non si trasferiscono automaticamente. La differenza tra adozione tecnologica e impatto organizzativo: l'adozione misura quanto uno strumento è usato, per esempio quante persone hanno una licenza, quante richieste fanno ogni giorno; l'impatto misura quanto cambiano i risultati dell'organizzazione. Le due cose possono divergere a lungo. Un riferimento storico utile è il cosiddetto paradosso della produttività, formulato dall'economista Robert Solow nel 1987: 'si vede l'era dei computer dappertutto, tranne che nelle statistiche della produttività'. Ci vollero anni perché la diffusione dei computer si traducesse in aumenti di produttività misurabili, e il motivo principale fu che le organizzazioni dovevano cambiare il modo di lavorare, non solo adottare le nuove tecnologie. Non è detto che con l'AI accada lo stesso, ma la lezione è utile: l'adozione è una condizione necessaria, non una misura del valore prodotto.");
    valTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.0, { icon: "FiUsers", head: "Adozione", headSize: 16, bodySize: 12,
      body: bullets(["Licenze, utenti attivi, richieste", "Quanto è usato lo strumento"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.0, { icon: "FiTrendingUp", head: "Impatto", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Tempi, qualità, costi, risultati", "Quanto cambiano i risultati dell'organizzazione"], { space: 4 }) });
    shapeBox(s, 0.5, 3.4, 9.0, 1.1, C.text1, "solow");
    txt(s, [{ text: "\"Si vede l'era dei computer dappertutto, tranne che nelle statistiche della produttività.\"", options: { italic: true, color: C.background1, breakLine: true } }, { text: "Robert Solow, 1987", options: { color: C.accent6, fontSize: 11 } }], { x: 0.75, y: 3.4, w: 8.5, h: 1.1, fontSize: 14, valign: "middle" });
    txt(s, "L'adozione è una condizione necessaria, non una misura del valore. Il valore dipende anche dal contesto.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }
  keySlide("Il valore non deriva dalla disponibilità di uno strumento, ma dal suo contributo a un obiettivo concreto e rilevante.", "Sottotema 12.1  ·  Che cosa significa creare valore con l'AI", "Concetto chiave del primo sottotema. Tra la capacità di uno strumento e il valore per l'azienda c'è una catena, capacità, utilizzo, risultato, valore, e ogni anello può interrompersi. L'AI è un mezzo: si parte da problemi e obiettivi, non dallo strumento. Il valore ha destinatari diversi, organizzazione, dipendenti e clienti, e livelli diversi, individuale, di team e organizzativo, che non coincidono sempre. Il beneficio percepito non è il beneficio effettivo, e l'adozione non è l'impatto. Esercizio suggerito: prendere un'iniziativa AI nota ai partecipanti e ricostruire la catena, indicando per ciascun anello che cosa si sa e che cosa si dà per scontato.");

  // =====================================================================
  section("12.2 Dimensioni del valore");
  divider("12.2", "Le principali dimensioni del valore", "Il valore è multidimensionale e non coincide soltanto con riduzione dei costi o risparmio di tempo", "Se il valore non è solo risparmio di tempo, in quali forme si presenta? In questo sottotema, da comprendere e distinguere, costruiamo una mappa sintetica delle dimensioni del valore. Il documento chiede che resti una mappa: le dimensioni principali verranno approfondite nei sottotemi successivi, l'efficienza nel 12.3, la qualità nel 12.4, le competenze nel 12.5, l'innovazione nel 12.6. Qui ci interessa vederle insieme, distinguere i benefici tangibili da quelli intangibili, il valore economico diretto da quello strategico, e capire che tra dimensioni diverse ci sono spesso compromessi.");
  {
    const s = content("Una mappa delle dimensioni", "Il sottotema elenca otto dimensioni principali del valore. Efficienza e riduzione dei tempi: fare le stesse cose con meno tempo o meno risorse. Produttività e capacità operativa: fare di più con le stesse risorse, gestire più volumi. Qualità e accuratezza dei risultati: risultati più completi, corretti, coerenti. Riduzione degli errori e delle rilavorazioni: meno lavoro da rifare. Esperienza del cliente: risposte più rapide, più disponibili, più personalizzate. Supporto alle decisioni: decisioni prese con più informazioni, analisi, scenari. Flessibilità e scalabilità: adattarsi a picchi di lavoro, crescere senza aumentare i costi nella stessa misura. Innovazione di prodotti e servizi: offrire qualcosa di nuovo. La mappa serve come promemoria: quando si valuta un'iniziativa AI, conviene chiedersi su quali dimensioni può avere un effetto, positivo o negativo, invece di guardare solo al tempo risparmiato. Molte iniziative hanno il loro valore principale in una dimensione diversa dall'efficienza, come la qualità o l'esperienza del cliente, e rischiano di essere giudicate male se si misura solo il tempo.");
    valTag(s, 0);
    const d = [["FiClock", "Efficienza", "Meno tempo e risorse"], ["FiTrendingUp", "Produttività", "Più volumi, stesse risorse"], ["FiCheckCircle", "Qualità", "Più completo, corretto, coerente"], ["FiRotateCcw", "Meno errori", "Meno rilavorazioni"], ["FiSmile", "Esperienza cliente", "Rapidità, disponibilità, personalizzazione"], ["FiCompass", "Decisioni", "Più informazioni e scenari"], ["FiMaximize", "Flessibilità", "Picchi e crescita"], ["FiStar", "Innovazione", "Prodotti e servizi nuovi"]];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.15 + row * 1.42;
      shapeBox(s, x, y, 2.15, 1.3, row ? C.accent6 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.15, y + 0.15, 0.48, d[i][0]);
      txt(s, d[i][1], { x: x + 0.72, y: y + 0.12, w: 1.38, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, d[i][2], { x: x + 0.15, y: y + 0.72, w: 1.9, h: 0.52, fontSize: 11, color: C.text2 });
    }
    banner(s, 4.1, "Molte iniziative hanno il loro valore principale fuori dall'efficienza: misurare solo il tempo le giudica male.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Tangibili e intangibili", "Due distinzioni che aiutano a classificare i benefici. La prima: benefici tangibili e intangibili. I tangibili si misurano direttamente, spesso in denaro o in unità fisiche: ore risparmiate, costi ridotti, numero di pratiche gestite, errori evitati. Gli intangibili sono reali ma difficili da misurare direttamente: soddisfazione dei dipendenti, reputazione, qualità percepita, capacità di attrarre talenti, apprendimento organizzativo. La seconda: valore economico diretto e valore strategico o organizzativo. Il valore economico diretto si traduce in risultati economici nel breve periodo: minori costi, maggiori ricavi. Il valore strategico o organizzativo prepara risultati futuri o rafforza l'organizzazione: nuove competenze, conoscenza meglio organizzata, capacità di sperimentare, posizionamento rispetto ai concorrenti. Una delle precisazioni trasversali del tema riguarda proprio questi benefici: il valore non immediatamente monetizzabile va riconosciuto, ma senza considerarlo automaticamente dimostrato. Dire che un'iniziativa ha 'valore strategico' non basta: bisogna poter indicare in che cosa consiste e come si riconoscerà. Altrimenti l'etichetta diventa un modo per giustificare iniziative senza risultati.");
    valTag(s, 0);
    table(s, [["", "Tangibile", "Intangibile"],
      ["Economico diretto", "Costi ridotti, ricavi, ore risparmiate", "Minore turnover, meno reclami"],
      ["Strategico o organizzativo", "Capacità di gestire più volumi", "Competenze, conoscenza, reputazione"]],
      { y: 1.15, colW: [2.6, 3.2, 3.2], rowH: 0.6, fontSize: 13 });
    shapeBox(s, 0.5, 3.15, 9.0, 1.75, C.text1, "attenzione strategico");
    txt(s, "Riconoscere, non dare per dimostrato", { x: 0.75, y: 3.25, w: 8.5, h: 0.4, fontSize: 15, bold: true, color: C.accent6 });
    txt(s, "Dire che un'iniziativa ha 'valore strategico' non basta: in che cosa consiste, e come si riconoscerà? Altrimenti l'etichetta giustifica iniziative senza risultati.", { x: 0.75, y: 3.7, w: 8.5, h: 1.1, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Compromessi tra dimensioni", "Le dimensioni del valore non si muovono sempre nella stessa direzione: spesso migliorarne una ne peggiora un'altra. Il sottotema chiede di riconoscere questi compromessi. Alcuni esempi tipici. Velocità contro qualità: produrre più rapidamente le risposte ai clienti con l'AI può ridurre l'accuratezza se la revisione viene compressa. Efficienza contro esperienza del cliente: sostituire il contatto umano con un assistente automatico riduce i costi, ma può peggiorare la soddisfazione dei clienti che hanno problemi complessi. Standardizzazione contro personalizzazione: risposte coerenti e uniformi possono risultare generiche. Produttività contro carico di lavoro: più volumi gestiti con le stesse persone possono aumentare la pressione e lo stress. Costi contro rischi: ridurre i controlli fa risparmiare tempo, ma aumenta la probabilità che un errore arrivi all'esterno. Riconoscere i compromessi non significa rinunciare ai benefici, ma scegliere consapevolmente quale dimensione privilegiare e quale livello delle altre è accettabile. E significa misurare più dimensioni insieme: un'iniziativa che migliora l'efficienza del 30 per cento peggiorando la qualità del 10 per cento può essere un buon affare o un cattivo affare, a seconda del contesto.");
    valTag(s, 0);
    const t = [["Velocità", "Qualità"], ["Efficienza", "Esperienza del cliente"], ["Standardizzazione", "Personalizzazione"], ["Produttività", "Carico di lavoro"], ["Costi", "Rischi"]];
    t.forEach((e, i) => {
      const y = 1.15 + i * 0.6;
      chip(s, 0.5, y, 3.6, 0.5, e[0], { fill: C.accent6, fontSize: 13 });
      txt(s, "↔", { x: 4.1, y, w: 0.8, h: 0.5, fontSize: 20, bold: true, color: C.accent5, align: "center", valign: "middle" });
      chip(s, 4.9, y, 3.6, 0.5, e[1], { fill: C.background2, fontSize: 13 });
    });
    banner(s, 4.25, "Scegliere consapevolmente che cosa privilegiare, e misurare più dimensioni insieme.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Un esempio con più dimensioni", "Un esempio fittizio aiuta a vedere le dimensioni insieme. Un ufficio di assistenza clienti introduce un assistente AI che propone agli operatori una bozza di risposta per ogni richiesta, basata sulla documentazione dei prodotti. Dopo alcuni mesi, i risultati osservati sono quelli in slide, numeri inventati a scopo didattico. Il tempo medio per risposta è sceso. Il numero di richieste gestite per operatore è salito. La coerenza delle risposte è migliorata, perché tutte si basano sulla stessa documentazione. I nuovi operatori diventano autonomi più rapidamente. Ma il tasso di risposte da correggere dopo un reclamo è leggermente aumentato, perché alcune bozze contenevano informazioni non aggiornate e non tutti gli operatori le controllavano. E alcuni operatori esperti riferiscono di sentirsi meno valorizzati. Il valore di questa iniziativa non si riassume in un solo numero. Ci sono benefici di efficienza, di produttività, di qualità e di competenze, e un costo in termini di errori e di soddisfazione di una parte del personale. Una valutazione onesta li considera tutti, e porta a interventi mirati: aggiornare la documentazione, rafforzare la revisione, coinvolgere gli esperti nel miglioramento delle bozze.");
    valTag(s, 0);
    table(s, [["Dimensione", "Effetto osservato", "Segno"],
      ["Efficienza", "Tempo medio per risposta ridotto", "+"],
      ["Produttività", "Più richieste per operatore", "+"],
      ["Qualità", "Risposte più coerenti", "+"],
      ["Competenze", "Nuovi operatori autonomi prima", "+"],
      ["Errori", "Più correzioni dopo reclamo", "-"],
      ["Dipendenti", "Esperti meno valorizzati", "-"]],
      { y: 1.15, colW: [2.2, 5.6, 1.2], rowH: 0.38, fontSize: 12, blankCorner: false });
    txt(s, "Esempio fittizio: assistente che propone bozze di risposta agli operatori", { x: 0.5, y: 3.85, w: 9, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    banner(s, 4.2, "Il valore non si riassume in un numero. Una valutazione onesta considera tutto, e porta a interventi mirati.", { h: 0.7, fontSize: 13 });
  }
  keySlide("Il valore è multidimensionale e non coincide soltanto con riduzione dei costi o risparmio di tempo.", "Sottotema 12.2  ·  Le principali dimensioni del valore", "Concetto chiave del sottotema 12.2. Il valore dell'AI si manifesta in molte dimensioni: efficienza, produttività, qualità, meno errori, esperienza del cliente, decisioni, flessibilità, innovazione. Ci sono benefici tangibili e intangibili, economici diretti e strategici, e il valore non monetizzabile va riconosciuto senza darlo per dimostrato. Tra dimensioni diverse ci sono compromessi, che vanno scelti consapevolmente. Esercizio suggerito: per un'attività del proprio lavoro in cui si usa o si potrebbe usare l'AI, compilare la mappa delle otto dimensioni indicando per ciascuna l'effetto atteso, positivo, negativo o nullo.");
