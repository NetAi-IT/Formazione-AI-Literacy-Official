  // =====================================================================
  section("16.4 Competenze e formazione");
  divider("16.4", "Competenze e formazione", "Un corso introduttivo avvia l'apprendimento; la competenza operativa si consolida con l'applicazione e il confronto", "Quarto sottotema, da comprendere e applicare, e uno di quelli con maggiore attenzione didattica. Riguarda direttamente anche questo percorso di formazione. Vediamo l'alfabetizzazione come punto di partenza, competenze generali e per ruolo, l'applicazione in situazioni reali, il valore delle competenze preesistenti, formazione iniziale e aggiornamento, esempi, esercitazione e confronto, apprendimento tra colleghi, supporto dopo la formazione, perdita delle competenze non usate. Integrazione C: la formazione da sola non produce adozione.");
  {
    const s = content("Generali e per ruolo", "I primi punti del sottotema. L'alfabetizzazione AI come punto di partenza: è ciò che questo percorso cerca di dare, cioè una comprensione di base di che cosa sono questi sistemi, come funzionano, che cosa sanno fare e non fare, come usarli in modo consapevole. È necessaria, ma è un punto di partenza. Le competenze generali e le competenze specifiche per ruolo: le prime servono a tutti, come formulare richieste, verificare gli output, riconoscere i limiti, rispettare le regole. Le seconde dipendono dal lavoro: un commerciale ha bisogno di sapere come usare l'AI per preparare offerte e analizzare richieste; un addetto all'amministrazione per controllare documenti; un tecnico per consultare manuali e diagnosticare problemi. È la seconda precisazione del tema: le esigenze formative sono differenziate. Una base comune è utile, ma ruoli diversi richiedono esempi, competenze e supporti diversi. Una formazione identica per tutti rischia di essere troppo generica per alcuni e troppo specifica per altri. La capacità di impiegare gli strumenti in situazioni professionali reali, infine, è l'obiettivo: non sapere che cosa lo strumento può fare in generale, ma saperlo usare bene nel proprio lavoro.");
    adTag(s, 2);
    shapeBox(s, 0.5, 3.0, 9.0, 0.95, C.accent1, "base comune");
    txt(s, [{ text: "Base comune: alfabetizzazione AI. ", options: { bold: true, color: C.background1 } }, { text: "Che cosa sono, come funzionano, limiti, richieste, verifica, regole.", options: { color: C.background1 } }], { x: 0.7, y: 3.0, w: 8.6, h: 0.95, fontSize: 13, valign: "middle" });
    const r = [["Commerciale", "Offerte, analisi delle richieste"], ["Amministrazione", "Controllo dei documenti"], ["Tecnico", "Manuali, diagnosi"], ["Assistenza", "Risposte, sintesi dei casi"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 1.65, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.25, w: 1.91, h: 0.4, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.7, w: 1.91, h: 0.9, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.1, "Esigenze differenziate: troppo generica per alcuni, troppo specifica per altri. L'obiettivo è usarlo bene nel proprio lavoro.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Le competenze che restano", "Due punti del sottotema che vanno insieme: la comprensione dei limiti e la verifica degli output, e il valore delle competenze professionali preesistenti. Usare bene l'AI non significa solo saper formulare richieste: significa saper giudicare i risultati. E per giudicare un'offerta preparata dall'AI serve sapere com'è fatta una buona offerta; per giudicare una sintesi di un contratto serve capire il contratto. Le competenze professionali preesistenti non diventano inutili: diventano la condizione per usare l'AI in modo appropriato. Come visto nel Tema 13, la ricerca suggerisce che l'esperienza è decisiva per riconoscere gli errori dell'AI, e che i meno esperti rischiano di accettare output sbagliati. Questo ha conseguenze per la formazione. Non basta insegnare lo strumento: bisogna collegarlo alle competenze professionali, mostrando come il giudizio esperto guida e controlla il lavoro dell'AI. E le persone esperte, spesso più scettiche, sono una risorsa preziosa: sono quelle che sanno dove l'AI sbaglia. Coinvolgerle nella formazione e nella definizione delle pratiche è un modo per rendere l'adozione più solida. Il metodo di verifica è quello del Tema 7: qui ne sottolineiamo il ruolo nella formazione.");
    adTag(s, 2);
    await twoPanel(s, "Giudicare richiede competenza", "Per giudicare un'offerta dell'AI serve sapere com'è fatta una buona offerta.\n\nL'esperienza è decisiva per riconoscere gli errori.", "Conseguenze per la formazione", bullets(["Collegare lo strumento alle competenze professionali", "Mostrare il giudizio esperto che guida e controlla", "Coinvolgere gli esperti, anche scettici"], { space: 4 }), { y: 1.15, h: 2.65, li: "FiAward", ri: "FiBookOpen" });
    banner(s, 4.0, "Le competenze professionali non diventano inutili: diventano la condizione per usare l'AI in modo appropriato.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Come si impara davvero", "Il sottotema indica le modalità che favoriscono l'apprendimento, e coincidono con molto di ciò che si sa sulla formazione degli adulti. Esempi pratici vicini alle attività quotidiane: imparare sulle proprie attività, non su esempi generici. Esercitazione, feedback e confronto: provare, ricevere un riscontro, discutere con gli altri. Apprendimento tra colleghi e condivisione delle pratiche: molto di ciò che si impara sull'AI si impara da chi lavora accanto, che ha già affrontato gli stessi problemi. Occasioni concrete per applicare quanto appreso: senza applicazione, la formazione si dissolve. Un riferimento diffuso nella formazione aziendale è il modello 70-20-10, attribuito al Center for Creative Leadership e a Lombardo ed Eichinger negli anni Novanta: circa il 70 per cento dell'apprendimento professionale verrebbe dall'esperienza sul lavoro, il 20 dalle relazioni con gli altri, il 10 dalla formazione formale. Le proporzioni non sono un dato scientifico preciso, e sono state criticate, ma l'idea di fondo è condivisa: la formazione formale è una parte minoritaria dell'apprendimento. Il grafico illustra il modello. La conseguenza per l'AI: la formazione in aula va progettata come innesco di un apprendimento che continua nel lavoro e tra colleghi.");
    adTag(s, 2);
    s.addChart(pres.charts.PIE, [{ name: "Apprendimento", labels: ["Esperienza sul lavoro", "Relazioni con gli altri", "Formazione formale"], values: [70, 20, 10] }], {
      x: 0.4, y: 1.05, w: 4.6, h: 2.75, chartColors: [HEX.a1, HEX.a4, HEX.a5], showPercent: true, showValue: false, dataLabelColor: "FFFFFF", dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt",
      showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Il modello 70-20-10 (indicativo, discusso)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt" });
    rowList(s, ["Esempi vicini alle attività quotidiane", "Esercitazione, feedback, confronto", "Apprendimento tra colleghi", "Occasioni concrete per applicare"], { y: 1.15, h: 0.5, gap: 0.08, x: 5.3, w: 4.2, fontSize: 12 });
    banner(s, 3.95, "La formazione in aula come innesco di un apprendimento che continua nel lavoro e tra colleghi.", { h: 0.8, fontSize: 13, });
  }
  {
    const s = content("Dall'aula al lavoro", "L'integrazione C del tema: la formazione da sola non produce adozione. Le competenze acquisite in aula possono non trasferirsi nel lavoro senza strumenti adeguati, tempo, esercizio e supporto. È un fenomeno studiato da decenni con il nome di transfer della formazione. Una rassegna classica di Baldwin e Ford, del 1988, ha individuato tre gruppi di fattori che influenzano il trasferimento: le caratteristiche delle persone, come la motivazione; il modo in cui la formazione è progettata, come la pertinenza degli esempi; e soprattutto l'ambiente di lavoro, cioè l'opportunità di applicare, il sostegno dei responsabili e dei colleghi. Molte stime, spesso citate ma difficili da verificare, sostengono che solo una parte minoritaria di ciò che si impara in aula venga poi applicata. Il punto non dipende dal numero preciso: la formazione è necessaria ma non sufficiente. Lo schema in slide riassume le condizioni del trasferimento. Per questo percorso significa una cosa concreta: dopo ogni tema, conviene che i partecipanti abbiano occasioni per applicare ciò che hanno imparato, con gli strumenti disponibili, il tempo e il supporto dei loro responsabili.");
    adTag(s, 2);
    const st = [["FiBookOpen", "Formazione", "Necessaria, non sufficiente"], ["FiTool", "Strumenti adeguati", "Disponibili per le proprie attività"], ["FiClock", "Tempo ed esercizio", "Occasioni per applicare"], ["FiLifeBuoy", "Supporto", "Responsabili e colleghi"], ["FiBriefcase", "Lavoro", "Competenza che si applica"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84, dark = i === 4;
      shapeBox(s, x, 1.15, 1.62, 2.2, dark ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.5, 1.25, 0.6, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.08, y: 1.95, w: 1.46, h: 0.5, fontSize: 12, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.08, y: 2.5, w: 1.46, h: 0.75, fontSize: 11, color: dark ? C.background1 : C.text2, align: "center" });
      if (i < 4) arrow(s, x + 1.63, 2.1, 0.19);
    }
    banner(s, 3.6, "Transfer della formazione (Baldwin e Ford, 1988): conta soprattutto l'ambiente di lavoro. La formazione da sola non produce adozione.", { h: 1.0, fontSize: 13 });
  }
  {
    const s = content("Sapere, saper fare, fare", "Una distinzione del sottotema che riassume l'integrazione C: la differenza tra apprendimento teorico, competenza operativa e comportamento abituale. L'apprendimento teorico è sapere: capire come funziona un modello linguistico, conoscere i rischi delle allucinazioni, sapere che cosa è una buona richiesta. È ciò che un corso trasmette più facilmente. La competenza operativa è saper fare: riuscire a usare lo strumento su un compito reale, ottenendo un buon risultato, verificandolo. Si costruisce con l'esercizio. Il comportamento abituale è fare: usare lo strumento in modo appropriato, regolarmente, quando serve, senza doverci pensare ogni volta. Si costruisce con la ripetizione nel lavoro, in un contesto che lo sostiene. Il modello di Kirkpatrick, molto usato per valutare la formazione, distingue in modo simile quattro livelli: la reazione dei partecipanti, l'apprendimento, il comportamento nel lavoro, i risultati per l'organizzazione. La maggior parte delle valutazioni si ferma ai primi due, che sono i più facili da misurare. Il valore, però, si gioca negli ultimi due. Un corso apprezzato e con un buon test finale non dice ancora nulla sul comportamento.");
    adTag(s, 2);
    const l = [["Sapere", "Apprendimento teorico", "Il corso"], ["Saper fare", "Competenza operativa", "L'esercizio"], ["Fare", "Comportamento abituale", "La ripetizione nel lavoro, in un contesto che sostiene"]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.6, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.2, w: 2.56, h: 0.45, fontSize: 18, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.35, fontSize: 12, bold: true, color: i === 2 ? C.background1 : C.text1 });
      txt(s, "Si costruisce con: " + e[2], { x: x + 0.15, y: 2.0, w: 2.56, h: 0.7, fontSize: 11, italic: true, color: i === 2 ? C.accent6 : C.text2 });
      if (i < 2) arrow(s, x + 2.88, 1.8, 0.17);
    });
    txt(s, "I quattro livelli di Kirkpatrick", { x: 0.5, y: 2.9, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    ["Reazione", "Apprendimento", "Comportamento", "Risultati"].forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.27, 2.15, 0.55, (i + 1) + "  " + t, { fill: i < 2 ? C.background2 : C.accent6, fontSize: 13 }));
    banner(s, 4.0, "Si misurano quasi sempre i primi due livelli. Il valore si gioca negli ultimi due.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Dopo la formazione", "Gli ultimi punti del sottotema: formazione iniziale e aggiornamento continuo, il supporto successivo alla formazione, il rischio di perdita delle competenze non usate. L'aggiornamento continuo è particolarmente importante per l'AI, perché gli strumenti cambiano rapidamente: nuove funzioni, nuovi modelli, nuovi limiti. Ciò che si impara oggi può essere parzialmente superato in un anno. Il supporto dopo la formazione: le domande vere arrivano quando si prova a usare lo strumento nel proprio lavoro, spesso settimane dopo il corso. Se in quel momento non c'è nessuno a cui chiedere, molte persone rinunciano. Il rischio di perdita delle competenze non usate: ciò che si impara e non si applica si dimentica. Il fenomeno è noto dagli studi di Hermann Ebbinghaus, alla fine dell'Ottocento, sulla curva dell'oblio: senza ripetizione, la memoria di ciò che si è appreso cala rapidamente nei giorni successivi. Il grafico, con un andamento illustrativo, confronta ciò che resta senza applicazione e con applicazioni ripetute. La consapevolezza del sottotema: un corso introduttivo avvia l'apprendimento; la competenza operativa si consolida con l'applicazione e il confronto.");
    adTag(s, 2);
    const lb = ["Corso", "1 sett.", "2 sett.", "1 mese", "2 mesi", "3 mesi"];
    lineChart(s, lb, [
      { name: "Senza applicazione", values: [100, 45, 35, 28, 22, 20], color: HEX.a5 },
      { name: "Con applicazioni ripetute", values: [100, 80, 82, 85, 87, 88], color: HEX.a1 },
    ], { x: 0.5, y: 1.05, w: 5.4, h: 3.4, min: 0, max: 110, legend: true, symbol: "circle", title: "Ciò che resta, % (andamento illustrativo)" });
    rowsLabel(s, [["Aggiornamento", "Gli strumenti cambiano in fretta"], ["Supporto dopo", "Le domande vere arrivano settimane dopo"], ["Curva dell'oblio", "Senza ripetizione si dimentica (Ebbinghaus)"]], { y: 1.15, h: 0.85, lw: 1.35, x: 6.15, w: 3.35, fontSize: 11 });
    txt(s, "Un corso avvia; l'applicazione e il confronto consolidano.", { x: 6.15, y: 4.05, w: 3.35, h: 0.45, fontSize: 12, bold: true, italic: true, color: C.accent1 });
  }
  keySlide("Un corso introduttivo avvia l'apprendimento: la competenza operativa si consolida con l'applicazione, il confronto e il supporto nel lavoro.", "Sottotema 16.4  ·  Competenze e formazione", "Concetto chiave del quarto sottotema. L'alfabetizzazione è il punto di partenza; le esigenze sono differenziate per ruolo. Le competenze professionali restano la condizione per giudicare l'AI. Si impara soprattutto nel lavoro e tra colleghi. Il trasferimento dall'aula al lavoro dipende da strumenti, tempo, esercizio e supporto. Sapere, saper fare e fare sono livelli diversi, e la valutazione dovrebbe guardare al comportamento e ai risultati. Dopo la formazione servono aggiornamento e supporto, o si dimentica. Esercizio suggerito: ogni partecipante sceglie un'attività del proprio lavoro su cui applicare, nelle prossime due settimane, qualcosa appreso nel percorso, e un collega con cui confrontarsi sui risultati.");

  // =====================================================================
  section("16.5 Sperimentazione e diffusione");
  divider("16.5", "Sperimentazione e diffusione", "Diffondere gradualmente l'AI permette di verificare risultati e condizioni, anziché amplificare rapidamente problemi non compresi", "Quinto sottotema, da comprendere, e uno di quelli con maggiore attenzione didattica. Il documento distingue: il 16.4 tratta lo sviluppo delle competenze, il 16.5 l'introduzione progressiva nel contesto operativo; il 16.5 riguarda il passaggio dal pilota all'estensione, il 16.8 il consolidamento nel tempo. Il confine con il Tema 15: lì il test serviva a verificare un'ipotesi sull'opportunità, qui la sperimentazione serve a imparare come introdurla. Integrazioni C e D: la pratica sostiene l'apprendimento; un pilota riuscito non è automaticamente pronto per tutta l'organizzazione.");
  {
    const s = content("Dimostrazione, pilota, estensione", "Il sottotema chiede di distinguere tre momenti dell'introduzione progressiva. La dimostrazione: si mostra lo strumento, le sue funzioni, alcuni esempi. Serve a far conoscere e a suscitare interesse, ma non è uso. La sperimentazione pilota: un gruppo limitato usa lo strumento nel lavoro reale, per un periodo definito, con attenzione a che cosa succede. Serve a imparare come lo strumento si inserisce nel lavoro, quali difficoltà emergono, quali pratiche funzionano. L'adozione estesa: lo strumento viene introdotto in modo più ampio, con le pratiche, i supporti e le indicazioni sviluppati durante il pilota. Il passaggio da un momento all'altro dovrebbe dipendere da ciò che si è imparato, non dal calendario. Il sottotema chiede anche la scelta di contesti circoscritti per le prime applicazioni: un gruppo, un'attività, un processo in cui l'AI ha buone probabilità di essere utile, in cui le persone sono disponibili a sperimentare, e in cui gli errori hanno conseguenze limitate. Notate la differenza con il Tema 15: lì la sperimentazione serviva a decidere se l'opportunità valeva; qui serve a capire come introdurla bene.");
    adTag(s, 3);
    const l = [["FiMonitor", "Dimostrazione", "Far conoscere, suscitare interesse", "Non è uso"], ["FiUsers", "Pilota", "Un gruppo, nel lavoro reale, per un periodo definito", "Imparare come si inserisce"], ["FiShare2", "Adozione estesa", "Più ampia, con pratiche e supporti del pilota", "Dopo ciò che si è imparato"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.45, i === 1 ? C.accent6 : C.background2, l[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.62, l[i][0]);
      txt(s, l[i][1], { x: x + 0.15, y: 1.95, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, l[i][2], { x: x + 0.15, y: 2.38, w: 2.56, h: 0.6, fontSize: 12, color: C.text1, align: "center" });
      txt(s, l[i][3], { x: x + 0.15, y: 3.0, w: 2.56, h: 0.5, fontSize: 12, bold: true, color: C.accent1, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.2, 0.17);
    }
    banner(s, 3.8, "Il passaggio dipende da ciò che si è imparato, non dal calendario. Contesti circoscritti: utile, disponibili, errori con poche conseguenze.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Il ciclo del pilota", "Il sottotema descrive le attività di un pilota, che possiamo organizzare in un ciclo. Coinvolgere gli utilizzatori: non solo come destinatari, ma come partecipanti che contribuiscono a definire come usare lo strumento. Sono loro a conoscere il lavoro. Osservare le difficoltà concrete: dove lo strumento non funziona, dove richiede troppo tempo, dove le persone si bloccano. Raccogliere feedback in modo strutturato: non solo 'come va?', ma domande precise, momenti dedicati, un modo semplice per segnalare problemi e idee. Valutare i risultati iniziali: che cosa è cambiato, con quale qualità, a quale costo. Rivedere strumenti e pratiche: cambiare le istruzioni, gli esempi, le indicazioni, a volte lo strumento stesso, o l'attività su cui si usa. E poi ricominciare. Il sottotema parla di apprendimento organizzativo attraverso cicli successivi: ogni ciclo migliora la comprensione, e le pratiche. È lo stesso principio dei cicli di miglioramento continuo, come il ciclo Plan-Do-Check-Act associato a Deming, applicato all'adozione. Lo schema mostra il ciclo.");
    adTag(s, 3);
    const st = [["Coinvolgere", "Gli utilizzatori come partecipanti"], ["Osservare", "Le difficoltà concrete"], ["Raccogliere", "Feedback strutturato"], ["Valutare", "Risultati iniziali, qualità, costo"], ["Rivedere", "Istruzioni, esempi, strumento, attività"]];
    const cx = 3.0, cy = 2.75, r = 1.45;
    st.forEach((e, i) => {
      const a = -Math.PI / 2 + i * 2 * Math.PI / 5;
      const x = cx + r * 1.35 * Math.cos(a) - 0.95, y = cy + r * Math.sin(a) - 0.38;
      shapeBox(s, x, y, 1.9, 0.76, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, (i + 1) + "  " + e[0], { x: x + 0.08, y: y + 0.02, w: 1.75, h: 0.33, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.08, y: y + 0.34, w: 1.75, h: 0.4, fontSize: 9, color: C.text1 });
    });
    s.addShape(pres.shapes.OVAL, { x: cx - 0.55, y: cy - 0.55, w: 1.1, h: 1.1, fill: { color: HEX.a1 }, line: { type: "none" }, objectName: "centro ciclo" });
    txt(s, "Cicli successivi", { x: cx - 0.55, y: cy - 0.55, w: 1.1, h: 1.1, fontSize: 10, bold: true, color: C.background1, align: "center", valign: "middle" });
    await card(s, 6.35, 1.15, 3.15, 1.7, { icon: "FiRefreshCw", inline: true, head: "Apprendimento organizzativo", headSize: 13, bodySize: 12, body: "Ogni ciclo migliora comprensione e pratiche." });
    await card(s, 6.35, 3.0, 3.15, 1.55, { icon: "FiRotateCw", inline: true, head: "Plan-Do-Check-Act", headSize: 13, bodySize: 12, fill: C.accent6, body: "Il miglioramento continuo (Deming), applicato all'adozione." });
  }
  {
    const s = content("Pratiche replicabili", "Il sottotema chiede di condividere le pratiche replicabili e di adattarle a funzioni e gruppi diversi. Il prodotto più prezioso di un pilota non è il risultato in sé, ma ciò che se ne impara: quali attività si prestano, quali istruzioni funzionano, quali errori evitare, come verificare, quanto tempo serve. Queste conoscenze vanno rese trasferibili: esempi documentati, istruzioni riutilizzabili, casi d'uso descritti, errori comuni, suggerimenti. È ciò che permette a chi viene dopo di partire da un punto più avanzato, e di non ripetere gli stessi errori. Ma il sottotema aggiunge una cautela: le pratiche vanno adattate. Ciò che funziona per l'ufficio commerciale di una sede può non funzionare per quello di un'altra, con clienti diversi, o per l'assistenza clienti, con attività diverse. L'adattamento richiede di nuovo il coinvolgimento delle persone, e talvolta un piccolo pilota locale. Nell'esempio dello scenario B, fittizio: dopo il pilota sui documenti commerciali, il gruppo ha prodotto una raccolta di istruzioni per le offerte standard, cinque esempi commentati, una lista degli errori più frequenti e una procedura di verifica. Sono il punto di partenza per gli altri gruppi, non una ricetta da applicare.");
    adTag(s, 3);
    docBox(s, 0.5, 1.15, 4.35, 2.65, "Che cosa si porta via da un pilota (scenario B, fittizio)", "Una raccolta di istruzioni per le offerte standard\n\nCinque esempi commentati\n\nGli errori più frequenti\n\nUna procedura di verifica", { fontSize: 13, fill: C.accent6 });
    await card(s, 5.15, 1.15, 4.35, 1.25, { icon: "FiCopy", inline: true, head: "Rendere trasferibile", headSize: 13, bodySize: 12, body: "Chi viene dopo parte più avanti." });
    await card(s, 5.15, 2.55, 4.35, 1.25, { icon: "FiSliders", inline: true, head: "Adattare", headSize: 13, bodySize: 12, fill: C.accent6, body: "Altre sedi, altri clienti, altre attività." });
    banner(s, 4.0, "Il prodotto più prezioso di un pilota è ciò che se ne impara. Un punto di partenza, non una ricetta.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Locale o replicabile?", "Una distinzione centrale del sottotema, e l'integrazione D: la differenza tra successo locale e replicabilità. Un pilota riuscito non implica automaticamente che la soluzione sia pronta per tutta l'organizzazione. Ci sono buone ragioni per cui un successo locale può non ripetersi. Il gruppo pilota era scelto: persone motivate, interessate, spesso con più competenze digitali della media. Riceveva attenzione speciale: supporto dedicato, contatto diretto con chi guidava il progetto. L'attività era scelta perché adatta. Il contesto era favorevole: un responsabile convinto, carichi di lavoro gestibili. E l'effetto della novità e dell'attenzione può aver migliorato i risultati, come accennato nel Tema 15. Estendendo, si incontrano persone meno motivate, attività meno adatte, responsabili meno coinvolti, supporto più diluito. Il sottotema chiede di chiarire le condizioni necessarie per estendere: quali condizioni del pilota sono state decisive, e sono presenti anche negli altri contesti? Se il successo dipendeva dal supporto dedicato, e il supporto non si può estendere, il successo non si estenderà. La tabella confronta le condizioni tipiche di un pilota e di un'estensione.");
    adTag(s, 3);
    table(s, [["", "Pilota", "Estensione"],
      ["Persone", "Motivate, scelte", "Tutte, anche le meno interessate"],
      ["Attività", "Scelte perché adatte", "Più varie"],
      ["Supporto", "Dedicato, diretto", "Più diluito"],
      ["Responsabili", "Convinti", "Più o meno coinvolti"],
      ["Attenzione", "Alta: effetto novità", "Normale"]],
      { y: 1.15, colW: [1.8, 3.4, 3.8], rowH: 0.45, accentCol: 2, fontSize: 12 });
    banner(s, 4.0, "Quali condizioni del pilota sono state decisive, e ci sono anche altrove? Un pilota riuscito non è pronto per tutti.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("I rischi della fretta", "L'ultimo punto del sottotema: i rischi della diffusione prematura. Ci sono molte pressioni a estendere rapidamente: le licenze sono già pagate, la direzione vuole risultati, i concorrenti annunciano progetti, il pilota è andato bene. Ma una diffusione prematura ha conseguenze note. Amplifica i problemi non risolti: se le istruzioni non sono ancora buone, ora sono usate da cento persone invece che da dieci; se c'è un errore sistematico, si moltiplica. Satura il supporto: le domande arrivano tutte insieme, e non c'è chi risponda. Produce prime esperienze negative, che come visto nel 16.2 determinano l'atteggiamento successivo, e sono difficili da recuperare. Disperde l'apprendimento: con molte persone che provano in modi diversi, è più difficile capire che cosa funziona. E, nei casi peggiori, porta all'abbandono dell'iniziativa, con la conclusione errata che l'AI non serve. La consapevolezza del sottotema: diffondere gradualmente l'AI permette di verificare risultati e condizioni, anziché amplificare rapidamente problemi non compresi. Gradualità non significa lentezza indefinita: significa estendere quando le condizioni sono pronte.");
    adTag(s, 3);
    await iconGrid(s, [
      { icon: "FiMaximize2", head: "Problemi amplificati", body: "Istruzioni imperfette ed errori moltiplicati" },
      { icon: "FiInbox", head: "Supporto saturato", body: "Domande tutte insieme, nessuno che risponda" },
      { icon: "FiThumbsDown", head: "Prime esperienze negative", body: "Difficili da recuperare (16.2)" },
      { icon: "FiShuffle", head: "Apprendimento disperso", body: "Troppi modi diversi, difficile capire che cosa funziona" },
      { icon: "FiXCircle", head: "Abbandono", body: "La conclusione errata che l'AI non serve" },
      { icon: "FiCheckCircle", head: "Gradualità", body: "Non lentezza indefinita: estendere quando le condizioni sono pronte" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Verificare risultati e condizioni, invece di amplificare problemi non compresi.", { h: 0.6, fontSize: 14 });
  }
  keySlide("Un pilota riuscito non è automaticamente pronto per tutta l'organizzazione: si estende quando le condizioni del successo sono presenti anche altrove.", "Sottotema 16.5  ·  Sperimentazione e diffusione", "Concetto chiave del quinto sottotema. Dimostrazione, pilota ed estensione sono momenti diversi. Il pilota è un ciclo: coinvolgere, osservare, raccogliere feedback, valutare, rivedere, e ricominciare. Il suo prodotto principale sono pratiche replicabili, da adattare. Il successo locale non è replicabilità: conta capire quali condizioni sono state decisive. La diffusione prematura amplifica i problemi. Esercizio suggerito: per un'iniziativa AI in corso o immaginata, scegliere un contesto adatto per un pilota, e indicare quali informazioni bisognerebbe raccogliere per decidere se e come estenderlo.");

  // =====================================================================
  section("16.6 Cultura, fiducia, partecipazione");
  divider("16.6", "Cultura, fiducia, partecipazione", "Una cultura favorevole all'AI promuove confronto e fiducia informata, non entusiasmo obbligatorio", "Sesto sottotema, da comprendere. Il documento lo indica come l'approfondimento delle dinamiche sociali, mentre il 16.2 era la mappa dei fattori. Vediamo gli atteggiamenti verso l'AI, i timori, la partecipazione, la fiducia informata, la possibilità di discutere errori e dubbi, le differenze tra gruppi, i rischi della pressione e dell'entusiasmo acritico, e la distinzione tra opposizione al cambiamento e obiezioni fondate. Integrazione B: la resistenza può essere un'informazione utile.");
  {
    const s = content("Atteggiamenti diversi", "Il sottotema parte dagli atteggiamenti individuali e collettivi verso l'AI. In qualsiasi gruppo convivono atteggiamenti diversi: entusiasmo, curiosità, scetticismo, preoccupazione. Spesso nella stessa persona, in momenti diversi. Nessuno di questi atteggiamenti è giusto o sbagliato in sé. L'entusiasmo porta a sperimentare, ma può portare a sovrastimare le capacità. La curiosità porta a esplorare. Lo scetticismo porta a verificare, ma può bloccare la sperimentazione. La preoccupazione segnala qualcosa che conta per la persona, e merita ascolto. Il sottotema dedica attenzione specifica ai timori relativi a mansioni, competenze e autonomia. Sono timori comprensibili, alimentati dal dibattito pubblico visto nel Tema 13: perderò il lavoro? Le mie competenze varranno ancora? Dovrò lavorare come dice la macchina? Ignorarli o liquidarli come irrazionali non li fa scomparire; li rende sotterranei. Riconoscerli, rispondere con onestà a ciò che si sa, e ammettere ciò che non si sa, è più efficace. Le finalità chiare della direzione, viste nel 16.3, sono parte della risposta.");
    adTag(s, 1);
    const a = [["FiZap", "Entusiasmo", "Porta a sperimentare; rischia di sovrastimare"], ["FiSearch", "Curiosità", "Porta a esplorare"], ["FiHelpCircle", "Scetticismo", "Porta a verificare; può bloccare"], ["FiAlertCircle", "Preoccupazione", "Segnala ciò che conta, merita ascolto"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 1.85, C.background2, a[i][1]);
      await iconCircle(s, x + 0.75, 1.22, 0.6, a[i][0]);
      txt(s, a[i][1], { x: x + 0.1, y: 1.88, w: 1.95, h: 0.38, fontSize: 14, bold: true, color: C.text1, align: "center" });
      txt(s, a[i][2], { x: x + 0.12, y: 2.27, w: 1.91, h: 0.68, fontSize: 11, color: C.text2, align: "center" });
    }
    txt(s, "Timori su mansioni, competenze, autonomia", { x: 0.5, y: 3.15, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    ["Perderò il lavoro?", "Le mie competenze varranno ancora?", "Dovrò lavorare come dice la macchina?"].forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.52, 2.86, 0.55, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.25, "Ignorati, i timori diventano sotterranei. Riconoscerli, dire ciò che si sa e ciò che non si sa.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Fiducia informata", "La sesta domanda guida chiede come sostenere fiducia informata, sperimentazione e partecipazione. Il sottotema parla di fiducia informata e proporzionata alle capacità effettive, e di rischi di pressione all'uso e di entusiasmo acritico. La fiducia informata è una fiducia calibrata: si basa su una comprensione realistica di che cosa lo strumento sa fare bene, che cosa sa fare male, quando sbaglia. È il punto di arrivo dei Temi 3 e 7, visto qui come caratteristica di una cultura organizzativa, non solo individuale. Due squilibri sono possibili. La fiducia eccessiva, o entusiasmo acritico: si accettano gli output senza verifica, si usa lo strumento anche dove non è adatto, si ignorano i segnali di problema. La sfiducia eccessiva: si rifiuta lo strumento anche dove sarebbe utile, si sottolineano solo gli errori. Una cultura che premia l'entusiasmo, per esempio celebrando chi usa di più l'AI senza guardare come, spinge verso il primo squilibrio. Una cultura che punisce gli errori spinge verso il secondo, o verso l'uso nascosto. La consapevolezza del sottotema: una cultura favorevole all'AI promuove confronto e fiducia informata, non entusiasmo obbligatorio.");
    adTag(s, 1);
    const z = [["Sfiducia eccessiva", "Rifiuto anche dove sarebbe utile; si vedono solo gli errori", C.background2, C.text1], ["Fiducia informata", "Calibrata sulle capacità effettive: dove funziona, dove sbaglia", C.accent1, C.background1], ["Entusiasmo acritico", "Output senza verifica, uso dove non serve, segnali ignorati", C.background2, C.text1]];
    z.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.0, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.25, w: 2.56, h: 0.45, fontSize: 15, bold: true, color: i === 1 ? C.background1 : C.accent1, align: "center" });
      txt(s, e[1], { x: x + 0.15, y: 1.75, w: 2.56, h: 1.3, fontSize: 12, color: e[3], align: "center" });
    });
    await twoPanel(s, "Premiare l'entusiasmo", "Celebrare chi usa di più, senza guardare come: spinge verso l'entusiasmo acritico.", "Punire gli errori", "Spinge verso la sfiducia, o verso l'uso nascosto.", { y: 3.3, h: 1.55, li: "FiAward", ri: "FiSlash" });
  }
  {
    const s = content("Poter parlare di ciò che non va", "Il sottotema chiede la possibilità di discutere errori, dubbi e risultati insoddisfacenti, e la legittimità delle segnalazioni di problemi. È una condizione decisiva per l'adozione, e per un uso sicuro. Quando le persone usano l'AI, sbagliano: accettano un output sbagliato, la usano su un'attività non adatta, ottengono risultati deludenti. Se possono parlarne senza timore, gli errori diventano apprendimento: per loro, per i colleghi, per l'organizzazione. Se temono di essere giudicate, li nascondono: gli errori si ripetono, i problemi restano invisibili, e le pratiche non migliorano. Amy Edmondson, della Harvard Business School, ha studiato a lungo questo fenomeno con il concetto di sicurezza psicologica: la convinzione condivisa, in un gruppo, che si possa esprimere un dubbio, ammettere un errore o segnalare un problema senza conseguenze negative. I suoi studi, a partire da quello del 1999, mostrano che i gruppi con maggiore sicurezza psicologica apprendono di più. Per l'AI, la sicurezza psicologica significa poter dire 'ho usato l'AI e ho sbagliato', 'non ho capito come usarla', 'secondo me qui non funziona', senza essere visti come incompetenti o resistenti.");
    adTag(s, 1);
    await twoPanel(s, "Se si può parlarne", bullets(["Gli errori diventano apprendimento", "Per la persona, i colleghi, l'organizzazione", "Le pratiche migliorano"], { space: 5 }), "Se si teme il giudizio", bullets(["Gli errori si nascondono e si ripetono", "I problemi restano invisibili", "Le pratiche non migliorano"], { space: 5 }), { y: 1.15, h: 2.2, li: "FiMessageCircle", ri: "FiVolumeX" });
    shapeBox(s, 0.5, 3.55, 9.0, 1.25, C.accent1, "sicurezza psicologica");
    txt(s, [{ text: "Sicurezza psicologica (Edmondson, 1999): ", options: { bold: true, color: C.accent6 } }, { text: "poter dire 'ho usato l'AI e ho sbagliato', 'non ho capito come usarla', 'qui non funziona', senza essere visti come incompetenti o resistenti.", options: { color: C.background1 } }], { x: 0.7, y: 3.55, w: 8.6, h: 1.25, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Opposizione o obiezione fondata?", "L'integrazione B del tema, nella sua forma più completa: la resistenza può essere un'informazione utile. Il sottotema chiede di distinguere tra opposizione al cambiamento e obiezioni fondate. Quando le persone resistono all'uso di uno strumento, la reazione organizzativa più comune è considerarle resistenti al cambiamento, e cercare di convincerle. Ma le obiezioni possono segnalare problemi reali. Il documento ne indica quattro tipi. Scarsa adeguatezza: lo strumento non serve davvero per quelle attività. Problemi di qualità: gli output non sono abbastanza buoni, e chi conosce il lavoro lo vede. Carichi aggiuntivi: lo strumento crea lavoro, per esempio di verifica o di correzione, che nessuno ha considerato, come visto nel Tema 13. Ambiguità nelle responsabilità: non è chiaro chi risponde degli errori, e le persone non vogliono rispondere di ciò che non controllano. Esistono anche resistenze di altro tipo, per abitudine o per timori generici. Ma trattare tutte le obiezioni come resistenza fa perdere informazioni preziose. La domanda utile davanti a un'obiezione è: che cosa ci sta dicendo? La tabella propone esempi fittizi.");
    adTag(s, 1);
    table(s, [["Obiezione (esempio fittizio)", "Che cosa potrebbe segnalare"],
      ["'Per le mie offerte tecniche non serve'", "Scarsa adeguatezza allo strumento"],
      ["'Le bozze hanno sempre errori sui codici'", "Problemi di qualità"],
      ["'Ci metto più tempo a controllarle che a scriverle'", "Carichi aggiuntivi"],
      ["'Se il cliente riceve un errore, chi ne risponde?'", "Ambiguità nelle responsabilità"]],
      { y: 1.15, colW: [4.8, 4.2], rowH: 0.52, accentCol: 1, fontSize: 12, blankCorner: false });
    banner(s, 3.9, "Davanti a un'obiezione: che cosa ci sta dicendo? Trattare tutto come resistenza fa perdere informazioni.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Partecipazione", "Gli ultimi punti del sottotema: la partecipazione delle persone al percorso di adozione, l'ascolto delle esperienze positive e negative, la collaborazione e l'apprendimento tra colleghi, le differenze culturali e professionali tra gruppi, e il coinvolgimento per migliorare le decisioni organizzative. La partecipazione non è un gesto di cortesia: migliora le decisioni. Chi svolge il lavoro sa dove l'AI può servire, quali eccezioni esistono, quali problemi emergeranno. Coinvolgerlo nella scelta delle attività, nella definizione delle pratiche, nella valutazione dei risultati porta a soluzioni migliori, e anche a una maggiore disponibilità a usarle. Forme concrete di partecipazione: gruppi di lavoro sui casi d'uso, momenti di confronto periodici, raccolta di proposte, persone di riferimento all'interno dei gruppi, che riprenderemo nel 16.7. Le differenze culturali e professionali tra gruppi vanno rispettate: professioni diverse hanno rapporti diversi con la tecnologia, con l'autonomia, con l'errore. Ciò che funziona per un team di marketing può non funzionare per un gruppo di tecnici o di legali. Il coinvolgimento serve anche a vedere queste differenze.");
    adTag(s, 1);
    await iconGrid(s, [
      { icon: "FiUsers", head: "Gruppi di lavoro", body: "Sui casi d'uso e sulle pratiche" },
      { icon: "FiMessageSquare", head: "Confronto periodico", body: "Esperienze positive e negative" },
      { icon: "FiInbox", head: "Raccolta di proposte", body: "Usi, problemi, idee" },
      { icon: "FiUserCheck", head: "Riferimenti nei gruppi", body: "Colleghi a cui chiedere (16.7)" },
      { icon: "FiGrid", head: "Differenze tra professioni", body: "Tecnologia, autonomia, errore: rapporti diversi" },
      { icon: "FiCheckCircle", head: "Decisioni migliori", body: "Chi lavora sa dove serve, e dove no" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "La partecipazione non è cortesia: migliora le decisioni, e la disponibilità a usarle.", { h: 0.6, fontSize: 14 });
  }
  keySlide("Una cultura favorevole all'AI promuove confronto e fiducia informata, non entusiasmo obbligatorio. E le obiezioni sono spesso informazioni.", "Sottotema 16.6  ·  Cultura, fiducia, partecipazione", "Concetto chiave del sesto sottotema. Atteggiamenti diversi convivono, e i timori vanno riconosciuti. La fiducia informata sta tra la sfiducia e l'entusiasmo acritico, e la cultura può spingere verso l'uno o l'altro. Poter parlare di errori e dubbi, la sicurezza psicologica, è decisivo per apprendere. Le obiezioni possono segnalare inadeguatezza, qualità scarsa, carichi aggiuntivi, responsabilità ambigue. La partecipazione migliora le decisioni. Esercizio suggerito: ciascuno scrive un dubbio o un'obiezione sull'uso dell'AI nel proprio lavoro; in gruppo si discute che cosa potrebbe segnalare e come l'organizzazione potrebbe tenerne conto.");
