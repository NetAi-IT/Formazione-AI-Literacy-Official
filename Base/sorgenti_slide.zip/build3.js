const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 3: Capacità, limiti e affidabilità dell'Intelligenza Artificiale";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 3  ·  Capacità, limiti e affidabilità dell'AI";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 3", { placeholder: "kicker" });
    s.addText("Capacità, limiti e affidabilità dell'Intelligenza Artificiale", { placeholder: "title" });
    s.addText("Area: Comprendere l'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al terzo tema del percorso di AI Literacy, che chiude l'area 'Comprendere l'AI'. Nel Tema 1 abbiamo visto perché l'AI è diventata centrale; nel Tema 2 come funziona. Ora affrontiamo la domanda più pratica di tutte: quanto possiamo fidarci di ciò che produce? Vedremo che cosa sanno fare i sistemi AI, quali sono i loro limiti, perché possono produrre informazioni false o distorte, come valutarne l'affidabilità, come verificarne i risultati e, infine, quando conviene usarli e quando limitarne l'uso. Il filo conduttore è un'idea semplice ma impegnativa: calibrare la fiducia. Suggerimento per l'apertura: chiedere ai partecipanti di raccontare un episodio in cui un assistente AI li ha sorpresi in positivo e uno in cui li ha delusi. Le due liste, di solito molto ricche, sono un ottimo punto di partenza per tutto il modulo. Nota per il relatore: i contenuti sono aggiornati a ottobre 2026. Capacità di ragionamento, frequenza delle allucinazioni e funzioni dei sistemi cambiano con ogni nuova versione dei modelli: prima di ogni edizione conviene ricontrollare esempi ed evidenze.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la capacità di riconoscere le potenzialità e i limiti dei sistemi AI, di comprenderne le principali fonti di errore e di valutare l'affidabilità dei risultati rispetto al contesto in cui li usiamo. La consapevolezza da sviluppare parte da un'osservazione: un sistema AI può produrre risultati estremamente utili e sofisticati, ma la qualità delle risposte non è garantita. Bisogna quindi distinguere tre cose: ciò che il sistema ha dimostrato di saper fare in generale, quanto è affidabile nella pratica, e se è adatto al compito specifico che abbiamo davanti. Lo scopo non è insegnare a diffidare dell'AI, né a fidarsene ciecamente, ma a sapere quando, quanto e a quali condizioni fare affidamento sui suoi risultati.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Riconoscere potenzialità e limiti dei sistemi AI", "Comprendere le principali fonti di errore", "Valutare l'affidabilità rispetto al contesto d'uso"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "La qualità delle risposte non è garantita.\n\nDistinguere capacità dimostrate, affidabilità effettiva e adeguatezza al compito specifico." });
  }
  {
    const s = content("Calibrare la fiducia", "Questa slide sintetizza lo spirito dell'intero modulo. Immaginiamo una scala. A un estremo c'è la fiducia eccessiva: si accetta qualunque risposta perché è scritta bene, si copiano dati senza controllarli, si delegano decisioni importanti. Il rischio è usare informazioni false o distorte, con conseguenze anche gravi. All'altro estremo c'è la sfiducia totale: si scarta l'AI perché 'sbaglia', anche per attività in cui sarebbe molto utile e facilmente verificabile. Il rischio è perdere opportunità reali e restare indietro. In mezzo c'è la fiducia calibrata: il livello di fiducia e di controllo viene regolato in base al compito, al sistema e alle conseguenze di un possibile errore. Per scrivere la bozza di un'email interna basta una rilettura; per un dato da inserire in un contratto serve una verifica sulla fonte; per una decisione che riguarda la salute o la sicurezza di una persona l'AI può essere al massimo un supporto per un esperto. Domanda per il gruppo: in quale punto della scala vi collochereste oggi?");
    const z = [["Fiducia eccessiva", "Si accetta tutto perché è scritto bene", "Rischio: errori e decisioni sbagliate", C.background2, C.text1, "FiThumbsUp"], ["Fiducia calibrata", "Fiducia e controlli regolati su compito, sistema e conseguenze", "L'obiettivo di questo modulo", C.accent1, C.background1, "FiSliders"], ["Sfiducia totale", "Si scarta l'AI perché \"sbaglia\"", "Rischio: perdere opportunità reali", C.background2, C.text1, "FiThumbsDown"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.3, 2.86, 2.75, z[i][3], z[i][0]);
      await iconCircle(s, x + 1.1, 1.5, 0.66, z[i][5], i === 1 ? C.background1 : C.accent2, i === 1 ? HEX.a1 : HEX.lt1);
      txt(s, z[i][0], { x: x + 0.15, y: 2.3, w: 2.56, h: 0.4, fontSize: 17, bold: true, color: z[i][4], align: "center" });
      txt(s, z[i][1], { x: x + 0.2, y: 2.75, w: 2.46, h: 0.65, fontSize: 13, color: z[i][4], align: "center" });
      txt(s, z[i][2], { x: x + 0.2, y: 3.45, w: 2.46, h: 0.5, fontSize: 12, bold: true, color: i === 1 ? C.accent6 : C.accent5, align: "center" });
    }
    banner(s, 4.25, "Sapere quando, quanto e a quali condizioni fare affidamento su un risultato AI.");
  }
  {
    const s = content("Otto domande guida per questo modulo", "Le otto domande guida accompagnano il modulo e corrispondono, in larga parte, agli otto sottotemi. Le prime due riguardano le capacità: che cosa sa fare l'AI e quali limiti incontra nel ragionamento e nella creatività. La terza e la quarta riguardano le principali fonti di errore: informazioni false ma convincenti, e distorsioni. La quinta e la settima riguardano l'affidabilità e il fatto che dipenda dal compito. La sesta riguarda i controlli da fare prima di usare un risultato. L'ultima, forse la più importante, riguarda la decisione di usare o non usare l'AI in base alle conseguenze di un errore. Alla fine del modulo torneremo su ciascuna con una risposta sintetica.");
    const qs = ["Quali attività l'AI svolge efficacemente, e da cosa dipende la qualità?", "Quali limiti hanno ragionamento, creatività e problem solving?", "Perché una risposta convincente può contenere informazioni false?", "Come emergono bias e distorsioni negli output?", "In cosa differiscono accuratezza, affidabilità, consistenza e utilità?", "Quali controlli servono prima di usare un risultato?", "Perché lo stesso modello va bene in un compito e male in un altro?", "Quando le conseguenze di un errore richiedono più supervisione o sconsigliano l'AI?"];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.2 + row * 1.9;
      shapeBox(s, x, y, 2.15, 1.75, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.18, y: y + 0.12, w: 0.5, h: 0.45, fontSize: 22, bold: true, color: C.accent1 });
      txt(s, qs[i], { x: x + 0.18, y: y + 0.6, w: 1.85, h: 1.1, fontSize: 12, color: C.text1 });
    }
  }
  {
    const s = content("Il filo conduttore", "Il filo conduttore del modulo è il percorso che porta a calibrare la fiducia, in quattro passi. Primo: che cosa sa fare l'AI, cioè le capacità e il ragionamento, nei sottotemi 3.1 e 3.2. Secondo: dove può sbagliare, cioè allucinazioni e bias, nei sottotemi 3.3 e 3.4. Terzo: quanto è affidabile e come si verifica, cioè accuratezza e affidabilità, controllo dei risultati e fattori che influenzano le prestazioni, nei sottotemi 3.5, 3.6 e 3.7. Quarto: quando usarla, limitarla o evitarla, nel sottotema 3.8. Lungo tutto il percorso il documento di perimetro chiede di tenere distinte tre cose che spesso si confondono: le capacità dimostrate, cioè ciò che un sistema ha mostrato di saper fare in generale; l'affidabilità effettiva, cioè quanto fa bene quel compito nella pratica, in modo costante; l'adeguatezza al compito, cioè se è adatto a questo compito specifico, con queste conseguenze. Suggerimento: riprendere le due liste raccolte in apertura, sorprese positive e delusioni, e chiedere in quale dei quattro passi si collocano.");
    const d = [["FiZap", "Che cosa sa fare", "Capacità e ragionamento", "3.1  3.2"], ["FiAlertTriangle", "Dove può sbagliare", "Allucinazioni e bias", "3.3  3.4"], ["FiCheckSquare", "Quanto è affidabile", "Affidabilità, verifica, fattori", "3.5  3.6  3.7"], ["FiSliders", "Quando usarla", "Usare, limitare, evitare", "3.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.15, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.05, w: 1.9, h: 0.38, fontSize: 15, bold: true, color: dark ? C.background1 : C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.43, w: 1.9, h: 0.5, fontSize: 12, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, d[i][3], { x: x + 0.1, y: 2.95, w: 1.9, h: 0.3, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Tre cose da tenere distinte", { x: 0.5, y: 3.45, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    ["Capacità dimostrate", "Affidabilità effettiva", "Adeguatezza al compito"].forEach((q, i) => chip(s, 0.5 + i * 3.07, 3.85, 2.86, 0.95, q, { fill: C.accent6, fontSize: 14 }));
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti confermati. Sette hanno priorità alta, uno, quello sui fattori che influenzano le prestazioni, priorità media. Alcuni concetti vanno compresi bene: le allucinazioni, l'autorevolezza apparente, i bias, l'affidabilità, la verifica e il rapporto tra affidabilità e conseguenze degli errori. Altri vanno conosciuti: le capacità cognitive, il ragionamento, la creatività, la robustezza, la ripetibilità, i fattori che influenzano le prestazioni. Altri ancora vanno solo accennati: i benchmark specialistici, le metriche statistiche avanzate, i metodi quantitativi di valutazione e il red teaming. Confini: non ripeteremo il funzionamento tecnico visto nel Tema 2, se non con brevi richiami; rimanderemo al Tema 4 il confronto tra prodotti e modelli; ai Temi 5 e 6 le tecniche di formulazione delle richieste; ai Temi 12 e 15 il ROI e la selezione dei progetti; ai Temi 17 e 18 privacy, sicurezza, normativa e policy. Un'avvertenza di metodo: non vogliamo trasformare il modulo in un catalogo di errori, né in un corso di statistica.");
    const items = [["3.1", "Le principali capacità dell'AI", "Alta"], ["3.2", "Ragionamento, problem solving e creatività", "Alta"], ["3.3", "Allucinazioni e informazioni false", "Alta"], ["3.4", "Bias e distorsioni nei risultati", "Alta"], ["3.5", "Accuratezza, affidabilità e consistenza", "Alta"], ["3.6", "Verificabilità e controllo dei risultati", "Alta"], ["3.7", "I fattori che influenzano le prestazioni", "Media"], ["3.8", "Quando utilizzare o limitare l'AI", "Alta"]];
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    const lv = [["Comprendere bene", "Allucinazioni, autorevolezza apparente, bias, affidabilità, verifica, affidabilità e conseguenze", C.accent1, C.background1], ["Conoscere", "Capacità cognitive, ragionamento, creatività, robustezza, ripetibilità, fattori", C.accent6, C.text1], ["Solo accennare", "Benchmark specialistici, metriche avanzate, red teaming", C.background2, C.text1]];
    lv.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 11, color: l[3] });
    });
  }

  // =====================================================================
  section("3.1 Capacità dell'AI");
  divider("3.1", "Le principali capacità dell'AI", "Capacità ampie, che variano in funzione dei sistemi e dei compiti", "Partiamo da ciò che l'AI sa fare. È una panoramica concettuale: non entriamo nei casi d'uso delle singole funzioni aziendali, ma costruiamo una mappa delle capacità che permetta di associarle a tipologie di attività. Due messaggi accompagnano il sottotema: le capacità sono davvero ampie, e non vanno sottovalutate; ma variano a seconda del sistema e del compito, e non tutti i prodotti AI dispongono delle stesse funzioni.");
  {
    const s = content("Una mappa delle capacità", "Ecco le sette famiglie di capacità principali dei sistemi AI attuali, in particolare di quelli generativi. L'elaborazione e la generazione del linguaggio: comprendere richieste, scrivere, riformulare, tradurre. La generazione, trasformazione e sintesi di contenuti: produrre bozze, riassumere documenti lunghi, cambiare formato, tono o lunghezza di un testo. La classificazione e l'estrazione di informazioni: assegnare categorie, estrarre dati strutturati da testi non strutturati, come importi e scadenze da un contratto. L'individuazione di schemi e l'analisi di dati: trovare tendenze, anomalie, temi ricorrenti, per esempio in un insieme di feedback dei clienti. L'elaborazione multimodale: lavorare su immagini, audio, video oltre che sul testo. Il supporto ad attività cognitive: ragionare su un problema, pianificare, valutare alternative, generare idee; lo approfondiamo nel sottotema 3.2. Infine l'interazione con strumenti esterni, quando il sistema la prevede: cercare sul web, eseguire codice per fare calcoli, leggere file, collegarsi ad altri software aziendali. Quest'ultima capacità è particolarmente importante, perché cambia molto l'affidabilità del risultato: un calcolo eseguito da codice è molto più affidabile di uno 'stimato' dal modello.");
    const it = [["FiMessageSquare", "Linguaggio", "Comprendere, scrivere, riformulare, tradurre"], ["FiFileText", "Contenuti", "Generare, trasformare, sintetizzare"], ["FiFilter", "Classificazione ed estrazione", "Categorie, dati da testi non strutturati"], ["FiBarChart2", "Schemi e analisi di dati", "Tendenze, anomalie, temi ricorrenti"], ["FiImage", "Multimodalità", "Testo, immagini, audio e video"], ["FiGitBranch", "Supporto cognitivo", "Ragionare, pianificare, generare idee"], ["FiTool", "Strumenti esterni", "Ricerca, esecuzione di codice, file, software"]];
    await iconGrid(s, it.slice(0, 4).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 4, { y: 1.2, h: 1.65 });
    await iconGrid(s, it.slice(4).map((e, i) => ({ icon: e[0], head: e[1], body: e[2], fill: i === 2 ? C.accent6 : C.background2 })), 3, { y: 3.05, h: 1.65, x: 0.5, w: 9.0 });
    txt(s, "Alcune capacità, come l'uso di strumenti, dipendono dal sistema e non sono sempre disponibili.", { x: 0.5, y: 4.8, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Dalle capacità alle attività", "Per rendere la mappa utile, associamo ogni capacità ad alcune tipologie di attività ricorrenti in azienda. Sono esempi trasversali, non casi d'uso di una funzione specifica. Linguaggio e contenuti: bozze di email e documenti, sintesi di riunioni o report, traduzioni, adattamento di testi a pubblici diversi. Classificazione ed estrazione: smistare richieste, estrarre dati da fatture, contratti o moduli, etichettare documenti. Schemi e analisi: individuare temi nei feedback, confrontare versioni di documenti, analizzare tabelle. Multimodalità: trascrivere riunioni, leggere documenti scansionati, descrivere immagini di prodotti. Supporto cognitivo: preparare un piano, valutare alternative, generare idee per un problema. Strumenti esterni: ricerche aggiornate, calcoli eseguiti con codice, interrogazione di archivi aziendali. La colonna di destra anticipa un punto che svilupperemo nel modulo: per ogni tipologia, qual è il controllo minimo ragionevole. Notate come cambia: per una bozza basta rileggere, per un dato estratto serve un confronto con l'originale.");
    table(s, [["Capacità", "Tipologie di attività", "Controllo tipico"], ["Linguaggio e contenuti", "Bozze, sintesi, traduzioni, adattamento di testi", "Rilettura critica"], ["Classificazione ed estrazione", "Smistare richieste, estrarre dati da documenti", "Confronto a campione con l'originale"], ["Schemi e analisi", "Temi nei feedback, confronto di documenti, tabelle", "Verifica dei dati e delle conclusioni"], ["Multimodalità", "Trascrizioni, documenti scansionati, immagini", "Controllo dei passaggi critici"], ["Supporto cognitivo", "Piani, alternative, idee", "Valutazione esperta"], ["Strumenti esterni", "Ricerche aggiornate, calcoli, archivi", "Controllo delle fonti e dei risultati"]], { colW: [2.5, 4.0, 2.5], rowH: 0.52, accentCol: 2, blankCorner: false });
  }
  {
    const s = content("Non tutti i sistemi hanno le stesse capacità", "Nel Tema 2 abbiamo distinto il modello dall'applicazione che lo integra. Questa distinzione ha una conseguenza diretta sulle capacità. Alcune dipendono soprattutto dal modello: la qualità della scrittura, la capacità di ragionamento, la comprensione di immagini. Altre dipendono dall'applicazione: la possibilità di cercare sul web, di eseguire codice, di leggere file di grandi dimensioni, di collegarsi a sistemi aziendali, di ricordare informazioni tra conversazioni. Due strumenti basati su modelli simili possono quindi avere capacità molto diverse, e lo stesso strumento può cambiare capacità nel tempo, con gli aggiornamenti o in base alla versione o al piano di abbonamento. In pratica: prima di affidare un compito a uno strumento AI, conviene verificare quali funzioni offre davvero. Per esempio, chiedere un'informazione aggiornata a un sistema senza ricerca web, o un calcolo complesso a un sistema senza esecuzione di codice, espone a errori evitabili. Il confronto tra prodotti e piattaforme specifiche è oggetto del Tema 4.");
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiCpu", head: "Dipendono soprattutto dal modello", headSize: 15, bodySize: 13,
      body: bullets(["Qualità della scrittura", "Capacità di ragionamento", "Comprensione di immagini e audio"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiPackage", head: "Dipendono dall'applicazione", headSize: 15, bodySize: 13, fill: C.accent6,
      body: bullets(["Ricerca sul web, esecuzione di codice", "Lettura di file, collegamenti a sistemi aziendali", "Memoria tra conversazioni"], { space: 3 }) });
    shapeBox(s, 0.5, 3.95, 9.0, 1.0, C.text1, "verifica funzioni");
    await iconCircle(s, 0.7, 4.17, 0.56, "FiCheckSquare", C.accent1);
    txt(s, "Prima di affidare un compito, verificare quali funzioni lo strumento offre davvero: informazioni aggiornate senza ricerca, o calcoli senza esecuzione di codice, espongono a errori evitabili.", { x: 1.45, y: 3.95, w: 7.9, h: 1.0, fontSize: 13, color: C.background1, valign: "middle" });
  }
  keySlide("Le capacità dell'AI sono ampie, ma variano in funzione dei sistemi e dei compiti; non tutti i prodotti AI dispongono delle stesse funzioni.", "Sottotema 3.1  ·  Le principali capacità dell'AI", "Concetto chiave. Le capacità dei sistemi AI coprono linguaggio, contenuti, estrazione, analisi, multimodalità, supporto cognitivo e uso di strumenti. Ma non sono uniformi: dipendono dal modello, dall'applicazione e dal compito. Per questo la domanda utile non è 'l'AI sa fare questa cosa?', ma 'questo sistema sa fare bene questa cosa, nelle nostre condizioni?'. Domanda di verifica: se chiedo il fatturato di un'azienda quotata dell'ultimo trimestre a un assistente senza ricerca web, che cosa rischio? Risposta: un dato non aggiornato o inventato, perché il sistema può contare solo sulla conoscenza incorporata.");

  // =====================================================================
  section("3.2 Ragionamento e creatività");
  divider("3.2", "Ragionamento, problem solving e creatività", "L'AI può supportare attività cognitive avanzate, ma non garantisce ragionamenti sempre corretti o coerenti", "Approfondiamo ora una famiglia di capacità particolarmente rilevante e discussa: il ragionamento, la risoluzione di problemi e la creatività. Sono le capacità che più fanno pensare a un'intelligenza simile alla nostra, e proprio per questo richiedono uno sguardo equilibrato. Vedremo che cosa i sistemi attuali fanno bene, dove incontrano difficoltà e perché le capacità osservabili non vanno confuse con il ragionamento umano.");
  {
    const s = content("Ragionamento logico, matematico e analitico", "I sistemi AI più recenti mostrano capacità di ragionamento notevoli. Nel ragionamento logico possono seguire catene di deduzioni, individuare contraddizioni in un testo, verificare se una conclusione deriva dalle premesse. Nel ragionamento matematico risolvono molti problemi, anche di livello avanzato, soprattutto quando possono mostrare i passaggi o usare codice per i calcoli. Nel ragionamento analitico sanno confrontare opzioni, individuare cause possibili di un problema, organizzare informazioni complesse. Un progresso importante degli ultimi anni sono i modelli che dedicano più elaborazione al ragionamento prima di rispondere, che hanno migliorato in modo significativo i risultati su problemi complessi. Ci sono però tre cautele. Primo: un ragionamento può apparire rigoroso e contenere un errore in un passaggio intermedio, che compromette la conclusione. Secondo: i calcoli eseguiti 'a mente' dal modello, cioè generati come testo, sono meno affidabili di quelli eseguiti tramite strumenti di calcolo. Terzo: le prestazioni sono irregolari, e un problema apparentemente semplice può essere sbagliato. Leggere i passaggi, quando sono disponibili, aiuta a individuare gli errori.");
    const t = [["FiGitBranch", "Logico", "Catene di deduzioni, contraddizioni, coerenza tra premesse e conclusioni"], ["FiHash", "Matematico", "Molti problemi anche avanzati, meglio con passaggi espliciti o codice"], ["FiBarChart2", "Analitico", "Confronti, cause possibili, organizzazione di informazioni complesse"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.15, { inline: true, icon: t[i][0], head: t[i][1], bodySize: 13, body: t[i][2] });
    txt(s, "Tre cautele", { x: 0.5, y: 3.5, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    const c = ["Un errore in un passaggio intermedio compromette la conclusione", "I calcoli generati come testo sono meno affidabili di quelli eseguiti con strumenti", "Le prestazioni sono irregolari: anche un problema semplice può essere sbagliato"];
    c.forEach((e, i) => { shapeBox(s, 0.5 + i * 3.07, 3.85, 2.86, 1.1, C.accent6, "cautela " + i); txt(s, e, { x: 0.65 + i * 3.07, y: 3.85, w: 2.56, h: 1.1, fontSize: 12, color: C.text1, valign: "middle" }); });
  }
  {
    const s = content("Problemi strutturati e non strutturati", "Una distinzione utile per valutare quanto affidarsi all'AI nel problem solving è quella tra problemi strutturati e non strutturati. Un problema strutturato ha obiettivi chiari, dati completi, regole note e una risposta corretta verificabile: calcolare una scadenza contrattuale, verificare se un documento contiene tutti i campi richiesti, convertire dati da un formato a un altro. Qui l'AI è spesso efficace e, soprattutto, il risultato si può controllare. Un problema non strutturato ha obiettivi ambigui o in conflitto, informazioni incomplete, molti fattori di contesto e più soluzioni accettabili: come riorganizzare un ufficio, come gestire un cliente insoddisfatto, quale strategia adottare in un nuovo mercato. Qui l'AI può essere un ottimo interlocutore per esplorare opzioni, porre domande, mettere ordine, ma non ha accesso a tutto il contesto, alle relazioni, ai vincoli non scritti, e la valutazione finale richiede il giudizio di chi conosce la situazione. Nella pratica, molti problemi aziendali stanno a metà strada, e una buona strategia è scomporli: le parti strutturate possono essere affidate all'AI con verifica, quelle non strutturate restano alla persona, con il supporto dell'AI.");
    table(s, [["", "Problemi strutturati", "Problemi non strutturati"], ["Obiettivi", "Chiari", "Ambigui o in conflitto"], ["Informazioni", "Complete, regole note", "Incomplete, contesto non scritto"], ["Soluzione", "Una risposta corretta verificabile", "Più soluzioni accettabili"], ["Esempi", "Calcolare una scadenza, convertire dati", "Riorganizzare un ufficio, entrare in un mercato"], ["Ruolo dell'AI", "Spesso efficace, risultato controllabile", "Interlocutore per esplorare opzioni"], ["Decisione", "Verificabile", "Giudizio di chi conosce la situazione"]], { colW: [1.9, 3.55, 3.55], rowH: 0.5, accentCol: 1 });
  }
  {
    const s = content("Scomporre, pianificare, valutare alternative", "Una delle capacità più utili dell'AI nel problem solving è aiutare a strutturare il lavoro. Può scomporre un problema complesso in sotto-problemi più gestibili, proporre un piano con fasi e dipendenze, generare alternative diverse e confrontarle secondo criteri espliciti, evidenziando pro, contro e rischi. Questo è prezioso soprattutto all'inizio di un'attività, quando serve mettere ordine, e come controllo per non dimenticare aspetti importanti. Lo schema in slide mostra il percorso tipico. Ma ci sono due limiti da tenere presenti. Primo: la qualità della scomposizione e del confronto dipende dalle informazioni fornite; se mancano vincoli importanti, come il budget, le persone disponibili o una scadenza, il piano può essere elegante ma irrealistico. Secondo: le valutazioni comparative dell'AI possono apparire oggettive, ma riflettono i criteri che le sono stati dati o che ha scelto implicitamente, e possono essere influenzate da come è formulata la domanda, come vedremo parlando di bias. Per questo l'ultimo passaggio, la scelta, resta a chi ha la responsabilità e la conoscenza del contesto.");
    const st = [["FiBox", "Problema complesso"], ["FiGrid", "Sotto-problemi"], ["FiList", "Piano e fasi"], ["FiShuffle", "Alternative"], ["FiSliders", "Confronto per criteri"], ["FiUserCheck", "Scelta della persona"]];
    for (let i = 0; i < 6; i++) {
      const x = 0.5 + i * 1.55;
      const last = i === 5;
      shapeBox(s, x, 1.3, 1.38, 1.75, last ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.42, 1.45, 0.55, st[i][0], last ? C.background1 : C.accent1, last ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.08, y: 2.1, w: 1.22, h: 0.85, fontSize: 13, bold: true, color: last ? C.background1 : C.text1, align: "center", valign: "middle" });
    }
    await card(s, 0.5, 3.3, 4.35, 1.65, { inline: true, icon: "FiAlertCircle", head: "Dipende dalle informazioni", bodySize: 12, body: "Senza vincoli reali (budget, persone, scadenze) il piano può essere elegante ma irrealistico." });
    await card(s, 5.15, 3.3, 4.35, 1.65, { inline: true, icon: "FiEye", head: "Oggettività apparente", bodySize: 12, body: "Il confronto riflette i criteri dati o impliciti e la formulazione della domanda." });
  }
  {
    const s = content("Generazione di idee e supporto creativo", "L'AI generativa è un potente strumento di supporto creativo. I suoi punti di forza sono evidenti: produce in pochi secondi molte idee e varianti, combina concetti di ambiti diversi, propone formulazioni alternative, aiuta a superare il blocco della pagina bianca e può assumere punti di vista differenti, per esempio quello di un cliente scettico. Ci sono però alcuni limiti da conoscere. Le idee tendono verso ciò che è frequente nei dati di addestramento, quindi verso soluzioni plausibili e convenzionali, più che davvero originali. Il sistema non conosce i vincoli specifici, la storia e la cultura della nostra organizzazione, se non gli vengono forniti. E c'è un effetto collettivo interessante: uno studio di Anil Doshi e Oliver Hauser, pubblicato su Science Advances nel 2024, ha osservato che i racconti scritti con l'aiuto di idee generate dall'AI venivano giudicati più creativi a livello individuale, soprattutto per gli autori meno creativi, ma erano più simili tra loro. In altre parole, l'AI può migliorare il singolo contributo e ridurre la varietà complessiva. Il suggerimento pratico: usare l'AI per ampliare il ventaglio di idee, non per sostituire il confronto tra persone, e considerare le proposte come materiale grezzo da selezionare, combinare e sviluppare.");
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiZap", head: "Punti di forza", headSize: 15, bodySize: 13, fill: C.accent6,
      body: bullets(["Molte idee e varianti in pochi secondi", "Combinazioni tra ambiti diversi", "Superare la pagina bianca", "Assumere punti di vista diversi"], { space: 2 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiAlertCircle", head: "Limiti", headSize: 15, bodySize: 13,
      body: bullets(["Tende a soluzioni plausibili e convenzionali", "Non conosce vincoli e cultura dell'organizzazione", "Può ridurre la varietà complessiva delle idee"], { space: 2 }) });
    shapeBox(s, 0.5, 3.8, 9.0, 1.15, C.text1, "studio creatività");
    txt(s, "UN ESEMPIO DI EVIDENZA", { x: 0.7, y: 3.9, w: 4, h: 0.28, fontSize: 10, bold: true, color: C.accent3, charSpacing: 2 });
    txt(s, "Racconti scritti con idee generate dall'AI: giudicati più creativi singolarmente, ma più simili tra loro.", { x: 0.7, y: 4.18, w: 8.6, h: 0.45, fontSize: 14, color: C.background1 });
    txt(s, "Fonte: Doshi e Hauser, Science Advances, 2024", { x: 0.7, y: 4.63, w: 8, h: 0.25, fontSize: 10, color: C.accent2 });
  }
  {
    const s = content("Limiti nelle situazioni nuove, ambigue o complesse", "Abbiamo visto nel Tema 2 che le capacità osservabili non autorizzano ad attribuire all'AI un ragionamento uguale a quello umano. Qui lo vediamo in concreto, attraverso tre situazioni in cui i limiti emergono più spesso. Le situazioni nuove: problemi diversi da quelli frequenti nei dati di addestramento. Un esempio classico: se si prende un indovinello molto noto e lo si modifica in modo che la risposta cambi, alcuni modelli rispondono come se fosse la versione originale, perché riconoscono lo schema familiare invece di leggere con attenzione il problema nuovo. Le situazioni ambigue: richieste che si possono interpretare in più modi. Spesso il sistema sceglie un'interpretazione senza segnalarlo, e produce una risposta corretta per una domanda diversa da quella che avevamo in mente. Le situazioni complesse: problemi con molti vincoli, passaggi lunghi o informazioni sparse. Qui aumentano gli errori intermedi e le incoerenze, per esempio una conclusione che contraddice un'affermazione fatta poco prima. Questi limiti non annullano l'utilità dell'AI, ma indicano dove serve più attenzione: quando il problema è insolito, ambiguo o articolato, la verifica deve essere più approfondita.");
    const l = [["FiCompass", "Situazioni nuove", "Problemi lontani da quelli frequenti nei dati", "Un indovinello noto, modificato: il sistema risponde alla versione originale"], ["FiHelpCircle", "Situazioni ambigue", "Richieste interpretabili in più modi", "Sceglie un'interpretazione senza segnalarlo"], ["FiLayers", "Situazioni complesse", "Molti vincoli, passaggi lunghi, informazioni sparse", "Errori intermedi e conclusioni incoerenti"]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.0, { icon: l[i][0], head: l[i][1], headSize: 15, bodySize: 12,
        body: [{ text: l[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Esempio: " + l[i][3], options: {} }] });
    }
    banner(s, 4.35, "Quando il problema è insolito, ambiguo o articolato, la verifica deve essere più approfondita.", { h: 0.6 });
  }
  keySlide("L'AI può supportare attività cognitive avanzate, ma non garantisce ragionamenti sempre corretti o coerenti.", "Sottotema 3.2  ·  Ragionamento, problem solving e creatività", "Concetto chiave. Ragionamento, problem solving e creatività sono tra le capacità più utili dei sistemi attuali: strutturano problemi, generano alternative, propongono idee, risolvono molti problemi logici e matematici. Ma un ragionamento ben presentato può contenere errori, le situazioni nuove, ambigue o complesse mettono in difficoltà i sistemi, e la creatività tende al convenzionale. La regola pratica: usare l'AI per ampliare e strutturare il proprio pensiero, non per sostituirlo. Domanda di verifica: perché è utile chiedere all'AI di mostrare i passaggi di un ragionamento? Risposta: perché permette di individuare l'eventuale errore intermedio e di valutare la solidità della conclusione.");

  // =====================================================================
  section("3.3 Allucinazioni");
  divider("3.3", "Allucinazioni e informazioni false", "La fluidità o la sicurezza del tono non dimostra che un'affermazione sia corretta o verificata", "Entriamo in uno dei sottotemi da comprendere in modo approfondito. Le allucinazioni sono probabilmente il limite più noto dei sistemi generativi, e uno dei più insidiosi, perché si presentano nella stessa forma delle risposte corrette. Vedremo che cosa sono, quali forme assumono, perché si verificano, a livello concettuale, e perché la plausibilità di una risposta non coincide con la sua veridicità. Ci soffermeremo poi sull'autorevolezza apparente, cioè sul rischio di credere a ciò che è scritto bene.");
  {
    const s = content("Che cos'è un'allucinazione", "Nei sistemi generativi si parla di allucinazione quando il sistema produce un contenuto presentato come vero ma falso, inesatto o privo di fondamento. Il termine è entrato nell'uso comune, anche se è una metafora imperfetta: il sistema non 'vede' cose che non ci sono, ma genera testo plausibile che non corrisponde ai fatti. Possiamo distinguere tre forme. Informazioni inventate: fatti, eventi, persone, dati o documenti che non esistono. Informazioni inesatte: elementi reali ma riportati in modo sbagliato, per esempio una data spostata di un anno, un numero errato, una norma attribuita all'articolo sbagliato, una citazione modificata. Informazioni prive di fondamento: affermazioni che potrebbero anche essere vere, ma che non derivano da nessuna fonte disponibile; per esempio, quando chiediamo un riassunto di un documento e il sistema aggiunge un'informazione che il documento non contiene. Quest'ultima forma è particolarmente rilevante in azienda, perché si presenta proprio quando pensiamo di essere al sicuro, cioè quando abbiamo fornito noi il documento.");
    const f = [["FiPlusCircle", "Inventate", "Fatti, persone, dati o documenti che non esistono", "Una sentenza mai pronunciata"], ["FiEdit", "Inesatte", "Elementi reali riportati in modo sbagliato", "Una data spostata, un numero errato, l'articolo sbagliato"], ["FiLink2", "Prive di fondamento", "Affermazioni non supportate dalle fonti disponibili", "Un riassunto che aggiunge ciò che il documento non dice"]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.75, { icon: f[i][0], head: f[i][1], headSize: 16, bodySize: 13, fill: i === 2 ? C.accent6 : C.background2,
        body: [{ text: f[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Esempio: " + f[i][3], options: {} }] });
    }
    banner(s, 4.15, "Contenuti presentati come veri, nella stessa forma delle risposte corrette.", { h: 0.8 });
  }
  {
    const s = content("Citazioni, riferimenti e fonti inesistenti", "Una forma di allucinazione particolarmente insidiosa riguarda le fonti. Un sistema generativo può produrre riferimenti bibliografici con autori, titoli, riviste e anni del tutto verosimili ma inesistenti; link a pagine che non esistono; citazioni attribuite a persone reali che non le hanno mai pronunciate; riferimenti normativi o giurisprudenziali inventati. Il caso più noto è avvenuto negli Stati Uniti nel 2023, nella causa Mata contro Avianca davanti a un tribunale federale di New York. Gli avvocati di una delle parti depositarono una memoria che citava diversi precedenti giudiziari. Quei precedenti, con tanto di nomi delle parti, numeri e citazioni testuali, erano stati generati da ChatGPT e non esistevano. Il giudice sanzionò gli avvocati e lo studio. Il caso è istruttivo per due ragioni: i riferimenti erano formalmente perfetti, e gli avvocati avevano persino chiesto al sistema se i casi fossero reali, ricevendo una conferma. Da allora episodi simili si sono ripetuti in diversi paesi. La lezione: una fonte citata dall'AI va trattata come un'indicazione da verificare, non come una prova. Se la fonte non si trova, va considerata inesistente.");
    shapeBox(s, 0.5, 1.2, 4.6, 3.75, C.text1, "caso Avianca");
    txt(s, "UN CASO REALE", { x: 0.75, y: 1.38, w: 4.1, h: 0.3, fontSize: 11, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Mata contro Avianca, New York, 2023", { x: 0.75, y: 1.7, w: 4.1, h: 0.4, fontSize: 17, bold: true, color: C.background1 });
    txt(s, bullets(["Una memoria legale cita precedenti generati da ChatGPT", "Nomi, numeri e citazioni formalmente perfetti, ma inesistenti", "Il sistema aveva \"confermato\" che i casi erano reali", "Il giudice sanziona avvocati e studio"], { space: 5 }), { x: 0.75, y: 2.2, w: 4.1, h: 2.2, fontSize: 13, color: C.accent3 });
    txt(s, "Fonte: Tribunale distrettuale degli Stati Uniti, S.D.N.Y., giugno 2023", { x: 0.75, y: 4.55, w: 4.2, h: 0.3, fontSize: 10, color: C.accent2 });
    txt(s, "Forme frequenti", { x: 5.4, y: 1.2, w: 4.1, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const f = [["FiBook", "Riferimenti bibliografici verosimili ma inesistenti"], ["FiLink", "Link a pagine che non esistono"], ["FiMessageCircle", "Citazioni attribuite a persone reali"], ["FiFileText", "Norme o sentenze inventate"]];
    for (let i = 0; i < 4; i++) {
      const y = 1.7 + i * 0.68;
      await iconCircle(s, 5.4, y, 0.48, f[i][0]);
      txt(s, f[i][1], { x: 6.05, y, w: 3.45, h: 0.48, fontSize: 13, color: C.text1, valign: "middle" });
    }
    shapeBox(s, 5.4, 4.45, 4.1, 0.5, C.accent6, "regola fonti");
    txt(s, "Una fonte citata è un'indicazione da verificare", { x: 5.5, y: 4.45, w: 3.9, h: 0.5, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
  }
  {
    const s = content("Perché si verificano le allucinazioni", "Senza ripetere il funzionamento visto nel Tema 2, richiamiamo i meccanismi che spiegano le allucinazioni. Primo: un modello linguistico genera il testo più plausibile in base alle regolarità apprese, e non possiede un meccanismo interno che verifichi ogni affermazione rispetto ai fatti. Plausibile e vero coincidono spesso, ma non sempre. Secondo: la conoscenza incorporata è incompleta e imprecisa, soprattutto su argomenti di nicchia, dettagli specifici e informazioni poco presenti nei dati di addestramento; dove la conoscenza è scarsa, il modello tende a ricostruire. Terzo: la conoscenza è ferma alla data limite, e le informazioni successive non sono note. Quarto: i modelli tendono a dare comunque una risposta invece di ammettere di non sapere. Un'analisi pubblicata nel 2025 da ricercatori di OpenAI sostiene che una causa sia proprio il modo in cui i modelli vengono addestrati e valutati, che spesso premia una risposta azzardata più di un'ammissione di incertezza, come uno studente che in un test a crocette tira a indovinare. Quinto: le domande stesse possono indurre l'errore, per esempio quando contengono una premessa falsa ('perché la legge X ha abolito Y?') che il modello asseconda. I sistemi più recenti allucinano in genere meno dei precedenti, soprattutto con ricerca e grounding, ma il fenomeno non è stato eliminato.");
    const c = [["FiShuffle", "Generazione plausibile", "Nessun meccanismo interno verifica ogni affermazione"], ["FiDatabase", "Conoscenza incompleta", "Su dettagli e argomenti di nicchia il modello ricostruisce"], ["FiCalendar", "Data limite", "Le informazioni successive non sono note"], ["FiMessageSquare", "Tendenza a rispondere comunque", "L'addestramento può premiare il tirare a indovinare"], ["FiHelpCircle", "Premesse false", "La domanda stessa può indurre l'errore"]];
    await iconGrid(s, c.slice(0, 3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, h: 1.55 });
    await iconGrid(s, c.slice(3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 2.95, h: 1.3, x: 0.5, w: 9.0 });
    txt(s, "I sistemi recenti allucinano in genere meno, soprattutto con ricerca e grounding, ma il fenomeno non è eliminato.", { x: 0.5, y: 4.45, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Plausibilità linguistica e veridicità", "Questa è la distinzione centrale del sottotema. La plausibilità linguistica riguarda la forma: un testo è plausibile se è grammaticalmente corretto, coerente, scritto nello stile giusto e simile a testi veri sullo stesso argomento. La veridicità riguarda il contenuto: un'affermazione è vera se corrisponde ai fatti, verificabili su fonti affidabili. Un modello linguistico è ottimizzato soprattutto per la prima: è stato addestrato a produrre testo plausibile. Per questo le sue risposte sono quasi sempre plausibili, mentre la veridicità dipende da molti fattori. L'esempio in slide mostra due frasi con la stessa struttura e lo stesso tono: la prima è vera, la seconda è falsa, perché l'articolo dell'AI Act che contiene le definizioni è il 3, non il 5, e la seconda data è sbagliata. Senza conoscere l'argomento o controllare la fonte, è impossibile distinguerle. Ecco perché la qualità della scrittura non può essere usata come indicatore di correttezza. Suggerimento: chiedere ai partecipanti quale delle due frasi sia vera prima di rivelare la risposta.");
    await card(s, 0.5, 1.2, 4.35, 1.6, { inline: true, icon: "FiType", head: "Plausibilità linguistica", bodySize: 13, body: "La forma: corretta, coerente, nello stile giusto. È ciò che il modello sa produrre meglio." });
    await card(s, 5.15, 1.2, 4.35, 1.6, { inline: true, icon: "FiCheckCircle", head: "Veridicità", bodySize: 13, fill: C.accent6, body: "Il contenuto: corrisponde ai fatti, verificabili su fonti affidabili." });
    txt(s, "Quale delle due è vera?", { x: 0.5, y: 3.0, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    const ex = [["A", "Le definizioni dell'AI Act si trovano all'articolo 3 del Regolamento UE 2024/1689, entrato in vigore il 1° agosto 2024."], ["B", "Le definizioni dell'AI Act si trovano all'articolo 5 del Regolamento UE 2024/1689, entrato in vigore il 1° marzo 2024."]];
    ex.forEach((e, i) => {
      const y = 3.4 + i * 0.8;
      shapeBox(s, 0.5, y, 9.0, 0.68, C.background2, "frase " + e[0]);
      txt(s, e[0], { x: 0.7, y, w: 0.4, h: 0.68, fontSize: 20, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 1.15, y, w: 8.2, h: 0.68, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("L'autorevolezza apparente", "Questa integrazione del sottotema riguarda il nostro modo di reagire alle risposte, più che il sistema. Le persone tendono ad attribuire credibilità ai contenuti in base a segnali di forma: un tono sicuro, un linguaggio tecnico appropriato, una struttura ordinata con titoli ed elenchi, la presenza di numeri precisi e di citazioni. Nella comunicazione umana questi segnali sono spesso correlati alla competenza: chi scrive bene di un argomento di solito lo conosce. Con i sistemi generativi questa correlazione si rompe, perché il sistema produce sempre testi ben formulati, sia quando sono corretti sia quando non lo sono, e di norma non esprime dubbi in modo proporzionato all'incertezza reale. Risultato: le risposte sbagliate sono persuasive quanto quelle giuste. I segnali di forma vanno quindi sostituiti con segnali di sostanza: la presenza di fonti verificabili e la loro effettiva consultazione; la coerenza con fonti indipendenti; la coerenza interna della risposta; la nostra competenza sull'argomento. Una precisazione: quando un sistema dichiara di non essere sicuro, è un'informazione utile; ma l'assenza di dubbi non è una garanzia.");
    txt(s, "Segnali di forma: ingannevoli", { x: 0.5, y: 1.15, w: 4.35, h: 0.35, fontSize: 15, bold: true, color: C.accent5 });
    txt(s, "Segnali di sostanza: affidabili", { x: 5.15, y: 1.15, w: 4.35, h: 0.35, fontSize: 15, bold: true, color: C.accent1 });
    const a = [["FiVolume2", "Tono sicuro e assertivo"], ["FiAlignLeft", "Struttura ordinata, titoli ed elenchi"], ["FiHash", "Numeri precisi e dettagli"], ["FiBookmark", "Citazioni e riferimenti"]];
    const b = [["FiExternalLink", "Fonti verificabili, effettivamente consultate"], ["FiCopy", "Coerenza con fonti indipendenti"], ["FiCheckSquare", "Coerenza interna della risposta"], ["FiUser", "La propria competenza sull'argomento"]];
    for (let i = 0; i < 4; i++) {
      const y = 1.6 + i * 0.72;
      shapeBox(s, 0.5, y, 4.35, 0.6, C.background2, a[i][1]);
      await iconCircle(s, 0.6, y + 0.07, 0.46, a[i][0], C.accent2);
      txt(s, a[i][1], { x: 1.2, y, w: 3.55, h: 0.6, fontSize: 13, color: C.text1, valign: "middle" });
      shapeBox(s, 5.15, y, 4.35, 0.6, C.accent6, b[i][1]);
      await iconCircle(s, 5.25, y + 0.07, 0.46, b[i][0]);
      txt(s, b[i][1], { x: 5.85, y, w: 3.55, h: 0.6, fontSize: 13, color: C.text1, valign: "middle" });
    }
    banner(s, 4.5, "Le risposte sbagliate sono scritte bene quanto quelle giuste.", { h: 0.5, fontSize: 13 });
  }
  {
    const s = content("Dove le allucinazioni sono più probabili", "Le allucinazioni non si distribuiscono in modo uniforme: alcune situazioni ne aumentano la probabilità. Conoscerle aiuta a dosare l'attenzione. Dettagli specifici: numeri, date, nomi propri, importi, percentuali. Argomenti di nicchia, locali o specialistici, poco presenti nei dati di addestramento, come una normativa regionale o un prodotto poco noto. Fonti e citazioni, come abbiamo visto. Eventi recenti, successivi alla data limite, se il sistema non usa la ricerca. Domande con premesse false o tendenziose, che il sistema tende ad assecondare. Richieste che vanno oltre i documenti forniti: se chiediamo a un sistema di rispondere su un documento e la risposta non c'è, può colmare il vuoto con un'invenzione. Testi lunghi e compiti articolati, in cui aumentano le occasioni di errore. Al contrario, il rischio è più basso quando il compito è trasformare un testo che forniamo noi, per esempio riformularlo o tradurlo, e quando il risultato è facile da controllare. Suggerimento: chiedere ai partecipanti quali di queste situazioni ricorrono nel loro lavoro.");
    const r = [["FiHash", "Numeri, date, nomi, importi"], ["FiMapPin", "Argomenti di nicchia, locali, specialistici"], ["FiBookmark", "Fonti e citazioni"], ["FiCalendar", "Eventi recenti senza ricerca"], ["FiHelpCircle", "Domande con premesse false"], ["FiFileMinus", "Risposte oltre i documenti forniti"]];
    txt(s, "Rischio più alto", { x: 0.5, y: 1.15, w: 6, h: 0.3, fontSize: 14, bold: true, color: C.accent5 });
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 3.0, y = 1.55 + row * 0.92;
      shapeBox(s, x, y, 2.85, 0.78, C.background2, r[i][1]);
      await iconCircle(s, x + 0.12, y + 0.14, 0.5, r[i][0], C.accent5);
      txt(s, r[i][1], { x: x + 0.72, y, w: 2.05, h: 0.78, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    }
    shapeBox(s, 6.65, 1.15, 2.85, 3.8, C.accent6, "rischio basso");
    txt(s, "Rischio più basso", { x: 6.85, y: 1.3, w: 2.5, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, bullets(["Trasformare un testo fornito: riformulare, tradurre, correggere", "Compiti brevi e ben delimitati", "Risultati facili da controllare"], { space: 8 }), { x: 6.85, y: 1.8, w: 2.5, h: 3.0, fontSize: 13, color: C.text1 });
    txt(s, "Anche testi lunghi e compiti articolati aumentano le occasioni di errore.", { x: 0.5, y: 4.4, w: 5.9, h: 0.55, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("La fluidità o la sicurezza del tono non dimostra che un'affermazione sia corretta o verificata.", "Sottotema 3.3  ·  Allucinazioni e informazioni false", "Concetto chiave. Le allucinazioni sono contenuti falsi, inesatti o privi di fondamento presentati come veri. Derivano dal fatto che il modello genera testo plausibile senza verificare i fatti, dalla conoscenza incompleta e datata, dalla tendenza a rispondere comunque e talvolta dalla formulazione della domanda. Sono più probabili su dettagli, nicchie, fonti, eventi recenti e richieste che vanno oltre le informazioni fornite. E sono insidiose perché si presentano con la stessa autorevolezza delle risposte corrette. Domanda di verifica: se chiedo all'AI 'sei sicuro?' e mi risponde 'sì', ho verificato l'informazione? Risposta: no; come nel caso Avianca, la conferma del sistema non è una verifica. Ne parleremo nel sottotema 3.6.");

  // =====================================================================
  section("3.4 Bias e distorsioni");
  divider("3.4", "Bias e distorsioni nei risultati", "I sistemi AI possono riprodurre o amplificare distorsioni: le risposte non sono automaticamente imparziali", "Passiamo dalle allucinazioni, che sono errori su singoli fatti, ai bias, che sono distorsioni sistematiche. La differenza è importante: un'allucinazione è una risposta sbagliata; un bias è una tendenza ricorrente a sbilanciare le risposte in una certa direzione. Vedremo che cosa significa bias, da dove nascono le distorsioni, come il contesto e le istruzioni le influenzano, che cosa sono stereotipi e rappresentazioni non equilibrate, e un fenomeno molto rilevante nell'uso quotidiano: la tendenza dei sistemi ad assecondare l'utente.");
  {
    const s = content("Che cosa sono bias e distorsioni", "In statistica e nell'AI, un bias è una distorsione sistematica: una tendenza ricorrente a scostarsi in una certa direzione da una rappresentazione corretta o equilibrata. La differenza con un errore casuale è fondamentale. Un errore casuale si presenta in modo imprevedibile, in direzioni diverse, e tende a compensarsi. Un bias va sempre nella stessa direzione, e per questo non si compensa: si accumula. L'analogia della bilancia lo rende chiaro: una bilancia imprecisa dà valori un po' sopra e un po' sotto; una bilancia starata segna sempre cento grammi in più. Nell'AI i bias possono riguardare molti aspetti: la rappresentazione di gruppi sociali, di genere, di età, di provenienza geografica; la prospettiva culturale, per esempio quella anglosassone, dominante nei dati di addestramento; la preferenza per certe fonti, posizioni o soluzioni. Un punto da chiarire: il termine 'bias' non implica un'intenzione. Le distorsioni nascono quasi sempre dai dati, dai processi e dal contesto, non da una volontà di discriminare. Ma gli effetti possono essere reali, e la responsabilità di riconoscerli e gestirli resta a chi usa il sistema.");
    await card(s, 0.5, 1.2, 4.35, 2.2, { inline: true, icon: "FiShuffle", head: "Errore casuale", headSize: 15, bodySize: 13, body: "Imprevedibile, in direzioni diverse, tende a compensarsi.\n\nCome una bilancia imprecisa: un po' sopra, un po' sotto." });
    await card(s, 5.15, 1.2, 4.35, 2.2, { inline: true, icon: "FiTrendingUp", head: "Bias (distorsione sistematica)", headSize: 15, bodySize: 13, fill: C.accent6, body: "Sempre nella stessa direzione: non si compensa, si accumula.\n\nCome una bilancia starata: sempre 100 grammi in più." });
    txt(s, "Che cosa può riguardare", { x: 0.5, y: 3.6, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    ["Gruppi sociali, genere, età", "Prospettiva culturale e geografica", "Preferenza per fonti o posizioni", "Soluzioni proposte"].forEach((e, i) => chip(s, 0.5 + i * 2.3, 4.0, 2.15, 0.55, e, { fill: C.background1, line: { color: C.accent3, width: 1 }, fontSize: 12 }));
    txt(s, "Non implica intenzione, ma gli effetti possono essere reali.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Da dove nascono le distorsioni", "Le distorsioni possono entrare nel sistema in tre punti. Il primo sono i dati di addestramento. I modelli apprendono da testi e immagini prodotti da persone, che riflettono la società con le sue disuguaglianze e i suoi stereotipi. Inoltre i dati non sono equilibrati: alcune lingue, culture, punti di vista e gruppi sono molto più rappresentati di altri. Ciò che è sovrarappresentato tende a diventare il 'normale' per il modello. Il secondo è il processo di addestramento e affinamento. Le scelte su quali dati includere, come filtrarli, quali comportamenti premiare durante l'affinamento con feedback umano possono introdurre ulteriori orientamenti, anche con l'intento di correggerne altri. Il terzo è il contesto d'uso: le istruzioni di sistema, la formulazione delle nostre domande, i documenti che forniamo. Anche questi possono orientare le risposte in una direzione. Un esempio storico istruttivo, anche se precedente all'AI generativa: nel 2018 Reuters riportò che Amazon aveva abbandonato un sistema sperimentale di selezione dei curricula, addestrato sulle assunzioni dei dieci anni precedenti, in prevalenza maschili. Il sistema aveva imparato a penalizzare i curricula che contenevano la parola 'women's', come in 'capitana della squadra femminile di scacchi'. Nessuno lo aveva programmato per discriminare: lo aveva appreso dai dati.");
    const st = [["FiDatabase", "Dati di addestramento", "Riflettono stereotipi e squilibri di rappresentazione"], ["FiSettings", "Addestramento e affinamento", "Scelte su dati, filtri e comportamenti premiati"], ["FiMessageSquare", "Contesto d'uso", "Istruzioni, formulazione delle domande, documenti"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 2.05;
      shapeBox(s, x, 1.2, 1.85, 2.3, C.background2, st[i][1]);
      await iconCircle(s, x + 0.62, 1.35, 0.6, st[i][0]);
      txt(s, st[i][1], { x: x + 0.1, y: 2.0, w: 1.65, h: 0.55, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.12, y: 2.58, w: 1.61, h: 0.85, fontSize: 11, color: C.text2, align: "center" });
      if (i < 2) arrow(s, x + 1.86, 2.2, 0.18);
    }
    shapeBox(s, 0.5, 3.7, 5.95, 1.25, C.accent6, "sintesi origini");
    txt(s, "Ciò che è sovrarappresentato nei dati tende a diventare il \"normale\" per il modello.", { x: 0.7, y: 3.7, w: 5.6, h: 1.25, fontSize: 14, color: C.text1, valign: "middle" });
    shapeBox(s, 6.7, 1.2, 2.8, 3.75, C.text1, "caso Amazon");
    txt(s, "UN CASO NOTO", { x: 6.9, y: 1.35, w: 2.4, h: 0.3, fontSize: 10, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Selezione dei curricula, 2018", { x: 6.9, y: 1.65, w: 2.45, h: 0.6, fontSize: 14, bold: true, color: C.background1 });
    txt(s, "Addestrato su dieci anni di assunzioni in prevalenza maschili, il sistema penalizzava i curricula con la parola \"women's\". Fu abbandonato.", { x: 6.9, y: 2.3, w: 2.45, h: 2.0, fontSize: 12, color: C.accent3 });
    txt(s, "Fonte: Reuters, ottobre 2018", { x: 6.9, y: 4.55, w: 2.45, h: 0.3, fontSize: 10, color: C.accent2 });
  }
  {
    const s = content("Stereotipi e rappresentazioni non equilibrate", "Come si manifestano concretamente i bias nei sistemi generativi? In diversi modi, spesso sottili. Associazioni stereotipate: se chiediamo di generare l'immagine di un 'amministratore delegato' o di un 'infermiere', i generatori di immagini hanno a lungo prodotto in prevalenza uomini nel primo caso e donne nel secondo, riflettendo e talvolta accentuando gli squilibri presenti nei dati. Lo stesso può avvenire nei testi, per esempio nei pronomi o nei ruoli assegnati ai personaggi di un esempio. Prospettive dominanti: alla domanda 'quali sono le pratiche migliori per...' il sistema può proporre soluzioni pensate per il contesto statunitense, per la grande impresa, o per una normativa diversa dalla nostra. Rappresentazioni sbilanciate: nel sintetizzare un dibattito, il sistema può dare più spazio alle posizioni più presenti nei dati, che non sono necessariamente le più fondate. Omissioni: alcuni gruppi, punti di vista o casi possono semplicemente non comparire. I fornitori lavorano per ridurre questi effetti, e i sistemi recenti sono più attenti dei precedenti, ma il problema non è risolto. In azienda il rischio è concreto quando l'AI interviene in attività che riguardano persone: annunci di lavoro, valutazioni, comunicazioni ai clienti, materiali di marketing.");
    const f = [["FiUsers", "Associazioni stereotipate", "Ruoli professionali associati a un genere o a un gruppo"], ["FiGlobe", "Prospettive dominanti", "Soluzioni pensate per altri paesi, normative o dimensioni d'impresa"], ["FiPieChart", "Rappresentazioni sbilanciate", "Più spazio alle posizioni più presenti nei dati"], ["FiEyeOff", "Omissioni", "Gruppi, punti di vista o casi che non compaiono"]];
    await iconGrid(s, f.map((e, i) => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.85 });
    banner(s, 4.25, "Attenzione maggiore quando l'AI interviene su attività che riguardano persone: selezione, valutazioni, comunicazioni.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("L'influenza del contesto e delle istruzioni", "Le distorsioni non vengono solo dai dati: possiamo introdurle noi, con il modo in cui formuliamo le richieste. Un modello linguistico prosegue e sviluppa il contesto che riceve, quindi una domanda orientata tende a produrre una risposta orientata. L'esempio in slide lo mostra. Se chiediamo 'Perché il fornitore A è la scelta migliore?', la domanda presuppone già la conclusione, e il sistema tenderà a elencare argomenti a favore di A. Se chiediamo 'Quali sono vantaggi e svantaggi dei fornitori A e B rispetto a questi criteri?', otteniamo un confronto più equilibrato. Lo stesso vale per i documenti che forniamo: se diamo al sistema solo materiali favorevoli a una tesi, la sua sintesi rifletterà quella tesi. E vale per le istruzioni di sistema impostate da chi configura lo strumento. La conseguenza pratica: quando usiamo l'AI per analizzare, confrontare o valutare, formulare richieste neutre, esplicitare i criteri, chiedere anche gli argomenti contrari. Le tecniche di formulazione sono sviluppate nel Tema 6; qui ci interessa la consapevolezza del meccanismo.");
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiArrowRight", head: "Domanda orientata", headSize: 15, bodySize: 13, iconBg: C.accent5,
      body: [{ text: "\"Perché il fornitore A è la scelta migliore?\"", options: { italic: true, bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 10 } }, { text: "Presuppone la conclusione: la risposta elencherà argomenti a favore di A.", options: {} }] });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiSliders", head: "Domanda neutra", headSize: 15, bodySize: 13, fill: C.accent6,
      body: [{ text: "\"Quali sono vantaggi e svantaggi di A e B rispetto a questi criteri?\"", options: { italic: true, bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 10 } }, { text: "Favorisce un confronto più equilibrato.", options: {} }] });
    txt(s, "Possono orientare le risposte", { x: 0.5, y: 3.9, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    ["La formulazione della domanda", "I documenti forniti", "Le istruzioni di sistema"].forEach((e, i) => chip(s, 0.5 + i * 3.07, 4.3, 2.86, 0.6, e, { fill: C.background2, fontSize: 13 }));
  }
  {
    const s = content("Bias di conferma e tendenza ad assecondare", "Due fenomeni si combinano in modo particolarmente insidioso. Il primo è nostro: il bias di conferma, cioè la tendenza umana a cercare, notare e ricordare le informazioni che confermano ciò che già pensiamo. Il secondo è del sistema: la tendenza ad assecondare l'utente, che in inglese si chiama sycophancy, traducibile come compiacenza o piaggeria. I modelli affinati con il feedback umano imparano che le risposte che danno ragione alle persone tendono a essere apprezzate, e possono quindi sviluppare la tendenza a concordare con le opinioni dell'utente, a lodare il suo lavoro più del dovuto, o a cambiare una risposta corretta quando l'utente insiste. Una ricerca di Anthropic pubblicata nel 2023 (Sharma e colleghi) ha documentato questo comportamento in diversi assistenti AI. Lo schema in slide mostra il circolo: io ho un'ipotesi, la formulo nella domanda, il sistema la asseconda, io mi convinco ancora di più. Esempi pratici: chiedere 'questa proposta è buona, vero?' invece di 'quali sono i punti deboli di questa proposta?'; ribattere 'sei sicuro? Io credo che sia X' e vedere il sistema cambiare idea. Contromisure: chiedere esplicitamente critiche e obiezioni, non rivelare la propria preferenza quando si chiede una valutazione, e diffidare delle risposte che ci danno ragione troppo facilmente. I fornitori stanno lavorando per ridurre il fenomeno, ma conviene tenerlo presente.");
    const cyc = [["La mia ipotesi", 0.5, 1.3], ["La formulo nella domanda", 2.85, 1.3], ["Il sistema la asseconda", 2.85, 3.0], ["Mi convinco ancora di più", 0.5, 3.0]];
    cyc.forEach((c, i) => chip(s, c[1], c[2], 2.1, 0.85, c[0], { fill: i === 2 ? C.accent1 : C.background2, color: i === 2 ? C.background1 : C.text1, fontSize: 13 }));
    arrow(s, 2.6, 1.57, 0.25, C.accent2);
    s.addShape(pres.shapes.DOWN_ARROW, { x: 3.75, y: 2.25, w: 0.32, h: 0.65, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia giù" });
    s.addShape(pres.shapes.LEFT_ARROW, { x: 2.6, y: 3.27, w: 0.25, h: 0.32, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia sinistra" });
    s.addShape(pres.shapes.UP_ARROW, { x: 1.4, y: 2.25, w: 0.32, h: 0.65, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia su" });
    txt(s, "Fonte: Sharma et al., Anthropic, 2023", { x: 0.5, y: 4.0, w: 4.5, h: 0.3, fontSize: 10, color: C.accent2 });
    await card(s, 5.3, 1.2, 4.2, 1.5, { inline: true, icon: "FiUser", head: "Bias di conferma (nostro)", bodySize: 12, body: "Notiamo e ricordiamo ciò che conferma quello che già pensiamo." });
    await card(s, 5.3, 2.9, 4.2, 1.35, { inline: true, icon: "FiThumbsUp", head: "Sycophancy (del sistema)", bodySize: 12, fill: C.accent6, body: "Tende a darci ragione, a lodare troppo, a cambiare una risposta corretta se insistiamo." });
    banner(s, 4.4, "Contromisure: chiedere critiche e obiezioni, non rivelare la propria preferenza.", { h: 0.55, fontSize: 12, fill: C.background2, color: C.text1 });
  }
  {
    const s = content("Neutralità apparente e oggettività effettiva", "Ultimo punto del sottotema. Le risposte dei sistemi AI hanno spesso un tono neutro, pacato, equilibrato: frasi come 'ci sono diverse prospettive', 'da un lato... dall'altro'. Questo tono può dare l'impressione di oggettività. Ma neutralità di tono e oggettività di contenuto sono cose diverse. Una risposta dal tono neutro può comunque contenere scelte non neutrali: quali informazioni includere e quali omettere, in che ordine presentarle, quanto spazio dare a ciascuna posizione, quali esempi usare, quali fonti considerare autorevoli, quale soluzione presentare come 'standard'. Anche il semplice fatto di presentare due posizioni come equivalenti può essere una distorsione, se le evidenze a sostegno sono molto diverse. Inoltre, un sistema può essere istruito dal fornitore o da chi lo configura a evitare certi argomenti o ad adottare certe impostazioni. Ciò non significa che le risposte siano inaffidabili per definizione: significa che non vanno considerate automaticamente imparziali, e che su temi delicati o controversi conviene confrontare più fonti, comprese fonti umane competenti.");
    await card(s, 0.5, 1.2, 3.3, 3.0, { icon: "FiFeather", head: "Neutralità di tono", headSize: 15, bodySize: 13, body: "\"Ci sono diverse prospettive\", \"da un lato... dall'altro\".\n\nDà un'impressione di oggettività." });
    arrow(s, 3.95, 2.55, 0.4, C.accent2);
    txt(s, "Scelte non neutrali che il tono non mostra", { x: 4.55, y: 1.2, w: 4.95, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const c = ["Che cosa includere e che cosa omettere", "Ordine e spazio dato a ogni posizione", "Esempi e fonti considerate autorevoli", "Quale soluzione presentare come \"standard\"", "Posizioni presentate come equivalenti senza esserlo"];
    c.forEach((e, i) => { shapeBox(s, 4.55, 1.62 + i * 0.52, 4.95, 0.44, i % 2 ? C.background1 : C.background2, e); txt(s, e, { x: 4.7, y: 1.62 + i * 0.52, w: 4.7, h: 0.44, fontSize: 12, color: C.text1, valign: "middle" }); });
    banner(s, 4.4, "Su temi delicati o controversi, confrontare più fonti, comprese quelle umane competenti.", { h: 0.55, fontSize: 13 });
  }
  keySlide("I sistemi AI possono riprodurre o amplificare distorsioni; le risposte non devono essere considerate automaticamente imparziali.", "Sottotema 3.4  ·  Bias e distorsioni nei risultati", "Concetto chiave. I bias sono distorsioni sistematiche che possono nascere dai dati, dall'addestramento e dal contesto d'uso, comprese le nostre domande. Si manifestano come stereotipi, prospettive dominanti, rappresentazioni sbilanciate e omissioni. La tendenza dei sistemi ad assecondare l'utente, combinata con il nostro bias di conferma, può rafforzare convinzioni sbagliate. E il tono neutro non garantisce l'oggettività. Domanda di verifica: volete un parere dell'AI su una proposta che avete scritto. Come formulate la richiesta per ridurre il rischio di compiacenza? Possibili risposte: chiedere esplicitamente i punti deboli, presentarla come proposta di un terzo, chiedere le obiezioni che farebbe un interlocutore critico.");

  // =====================================================================
  section("3.5 Accuratezza e affidabilità");
  divider("3.5", "Accuratezza, affidabilità e consistenza", "L'affidabilità non è una proprietà unica e universale di un modello: va valutata per compiti e condizioni d'uso specifici", "Dopo aver visto le principali fonti di errore, facciamo un passo indietro e chiediamoci come si valutano, in generale, le prestazioni di un sistema AI. È un sottotema da comprendere in modo approfondito, ma senza entrare in metriche statistiche. Distingueremo concetti che spesso si confondono, come accuratezza, affidabilità, consistenza e utilità; vedremo perché le prestazioni cambiano da compito a compito e con piccole variazioni dell'input; perché benchmark e dimostrazioni non bastano; e perché conta l'affidabilità del sistema completo, non solo del modello.");
  {
    const s = content("Quattro concetti da distinguere", "Nel linguaggio comune questi termini si usano come sinonimi, ma indicano cose diverse. L'accuratezza è la corrispondenza tra il risultato e la realtà o la risposta corretta: quanto spesso il sistema ha ragione. L'affidabilità è la capacità di mantenere un livello di qualità adeguato in modo costante, nelle condizioni d'uso reali, compresi i casi difficili: possiamo contare su quel sistema per quel compito? La consistenza è la coerenza dei risultati: risposte simili a richieste simili, nessuna contraddizione interna, stesso trattamento per casi equivalenti. L'utilità è il valore che il risultato porta a chi lo usa: fa risparmiare tempo, migliora il lavoro, aiuta a decidere? Le quattro dimensioni non coincidono. Un sistema può essere accurato nel novanta per cento dei casi ma poco affidabile, se non sappiamo prevedere quando sbaglia. Può essere molto consistente e sistematicamente sbagliato, come abbiamo visto nel Tema 2. E un risultato imperfetto può essere molto utile: una bozza con qualche errore che fa risparmiare un'ora di lavoro, se l'errore è facile da correggere. Per valutare un sistema, bisogna chiedersi quale di queste dimensioni conta di più per il compito specifico.");
    const d = [["FiTarget", "Accuratezza", "Quanto spesso il risultato corrisponde alla risposta corretta"], ["FiShield", "Affidabilità", "Qualità adeguata in modo costante, nelle condizioni reali"], ["FiRepeat", "Consistenza", "Risposte coerenti a richieste simili, senza contraddizioni"], ["FiAward", "Utilità", "Il valore che il risultato porta a chi lo usa"]];
    await iconGrid(s, d.map((e, i) => ({ icon: e[0], head: e[1], body: e[2], fill: i === 1 ? C.accent6 : C.background2 })), 4, { y: 1.2, h: 2.1, headSize: 14, bodySize: 12 });
    txt(s, "Non coincidono", { x: 0.5, y: 3.5, w: 9, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    const e = ["Accurato al 90% ma poco affidabile, se non sappiamo quando sbaglia", "Molto consistente, ma sistematicamente sbagliato", "Imperfetto ma utile: una bozza facile da correggere"];
    e.forEach((t, i) => { shapeBox(s, 0.5 + i * 3.07, 3.9, 2.86, 1.05, C.background2, t); txt(s, t, { x: 0.65 + i * 3.07, y: 3.9, w: 2.56, h: 1.05, fontSize: 12, color: C.text1, valign: "middle" }); });
  }
  {
    const s = content("Prestazioni diverse in base al compito", "Lo stesso modello può funzionare molto bene in un compito e male in un altro, anche se i due compiti sembrano simili. È la 'frontiera tecnologica frastagliata' descritta da Dell'Acqua e colleghi in uno studio su 758 consulenti, pubblicato nel 2026 sulla rivista Organization Science e citato anche nel Tema 1: compiti apparentemente simili possono stare da parti opposte del confine di ciò che l'AI sa fare bene. Lo schema in slide propone un profilo qualitativo di un ipotetico assistente generico: non sono misure, ma un modo per visualizzare l'idea. Ottimo nel riformulare e correggere testi, molto buono nelle sintesi e nelle traduzioni, buono nell'estrarre dati da documenti ben strutturati, più incerto su calcoli complessi senza strumenti, su fatti specifici senza fonti e su conteggi precisi. Perché? Perché le prestazioni dipendono da quanto il compito somiglia a ciò che il modello ha visto in addestramento, da quanto richiede conoscenze precise rispetto a competenze linguistiche, da quanto il risultato richiede esattezza assoluta, e dalla disponibilità di strumenti adatti. Il profilo reale varia da sistema a sistema e cambia con gli aggiornamenti. La conseguenza pratica è importante: non si può dire 'questo modello è affidabile' in generale. Si può dire, al massimo, 'questo sistema si è dimostrato affidabile per questo compito, in queste condizioni'.");
    const p = [["Riformulare e correggere testi", 0.95], ["Sintetizzare e tradurre", 0.85], ["Estrarre dati da documenti strutturati", 0.75], ["Calcoli complessi senza strumenti", 0.45], ["Fatti specifici senza fonti", 0.4], ["Conteggi precisi (parole, lettere)", 0.35]];
    p.forEach((e, i) => {
      const y = 1.3 + i * 0.52;
      txt(s, e[0], { x: 0.5, y, w: 3.4, h: 0.42, fontSize: 13, color: C.text1, valign: "middle" });
      s.addShape(pres.shapes.RECTANGLE, { x: 4.0, y: y + 0.1, w: 3.0, h: 0.24, fill: { color: C.background2 }, line: { type: "none" }, objectName: "barra base" });
      s.addShape(pres.shapes.RECTANGLE, { x: 4.0, y: y + 0.1, w: 3.0 * e[1], h: 0.24, fill: { color: e[1] > 0.6 ? C.accent1 : C.accent5 }, line: { type: "none" }, objectName: "barra profilo" });
    });
    txt(s, "Profilo qualitativo di un ipotetico assistente, a scopo illustrativo", { x: 0.5, y: 4.45, w: 6.5, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
    shapeBox(s, 7.3, 1.2, 2.2, 3.75, C.text1, "messaggio profilo");
    txt(s, "Non \"questo modello è affidabile\", ma \"è affidabile per questo compito, in queste condizioni\".", { x: 7.45, y: 1.3, w: 1.95, h: 3.55, fontSize: 14, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Coerenza, ripetibilità e robustezza", "Accanto all'accuratezza, due qualità sono importanti quando l'AI entra in un processo di lavoro. La prima è la ripetibilità: la capacità di produrre risultati coerenti alla stessa richiesta. Ne abbiamo visto il meccanismo nel Tema 2, parlando di variabilità; qui ci interessa come criterio di qualità. Per molti compiti creativi la variabilità non è un problema; per compiti come classificare richieste o estrarre dati, invece, risultati diversi a parità di input rendono il processo poco affidabile. La seconda è la robustezza: la capacità di mantenere risultati corretti quando l'input cambia in modo irrilevante. Un sistema robusto dà la stessa risposta se riformuliamo la domanda con parole diverse, se cambiamo l'ordine delle informazioni, se c'è un errore di battitura o una frase in più non pertinente. I sistemi AI attuali sono abbastanza robusti in molti casi, ma non sempre: una piccola variazione nella formulazione può cambiare il risultato, anche in modo significativo. Un test pratico, semplice e molto istruttivo: porre la stessa domanda in due o tre forme diverse. Se le risposte divergono nella sostanza, è un segnale che il risultato non è solido e va verificato con più attenzione.");
    await card(s, 0.5, 1.2, 4.35, 2.2, { inline: true, icon: "FiRepeat", head: "Ripetibilità", headSize: 15, bodySize: 13, body: "Risultati coerenti alla stessa richiesta. Poco rilevante per compiti creativi, essenziale per classificare o estrarre dati." });
    await card(s, 5.15, 1.2, 4.35, 2.2, { inline: true, icon: "FiAnchor", head: "Robustezza", headSize: 15, bodySize: 13, fill: C.accent6, body: "Risultati corretti anche quando l'input cambia in modo irrilevante." });
    txt(s, "Variazioni irrilevanti che non dovrebbero cambiare la risposta", { x: 0.5, y: 3.55, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Parole diverse", "Ordine delle informazioni", "Errori di battitura", "Frasi non pertinenti"].forEach((e, i) => chip(s, 0.5 + i * 2.3, 3.9, 2.15, 0.5, e, { fill: C.background1, line: { color: C.accent3, width: 1 }, fontSize: 12 }));
    banner(s, 4.5, "Test pratico: porre la stessa domanda in due o tre forme. Se le risposte divergono, verificare.", { h: 0.5, fontSize: 13 });
  }
  {
    const s = content("I limiti di benchmark e dimostrazioni", "Quando un nuovo modello viene presentato, lo si accompagna di solito con due tipi di evidenze: i risultati sui benchmark e le dimostrazioni. I benchmark sono raccolte standardizzate di domande o compiti, su cui si misurano e confrontano i modelli: problemi di matematica, domande di cultura generale, esercizi di programmazione, esami professionali. Sono utili per confrontare i sistemi e misurarne i progressi, ma hanno limiti che è bene conoscere, anche solo a grandi linee. Misurano compiti standardizzati, spesso diversi da quelli reali. Alcune domande dei benchmark possono essere finite nei dati di addestramento, falsando i risultati: si parla di contaminazione. Quando i modelli raggiungono punteggi molto alti, il benchmark smette di distinguere tra loro: si parla di saturazione. E soprattutto, un punteggio medio non dice nulla su come il sistema si comporterà sui nostri casi. Le dimostrazioni, come abbiamo visto nel Tema 1, mostrano il caso migliore in condizioni controllate. Non approfondiamo i benchmark specialistici e le metriche: il messaggio è che punteggi e demo sono indizi utili, ma non sostituiscono la prova sul proprio contesto.");
    await card(s, 0.5, 1.2, 4.35, 3.0, { icon: "FiBarChart", head: "Benchmark", headSize: 15, bodySize: 13,
      body: [{ text: "Raccolte standardizzate di compiti per confrontare i modelli", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }].concat(bullets(["Compiti diversi da quelli reali", "Contaminazione: domande note in addestramento", "Saturazione: punteggi tutti alti", "Media che non descrive i nostri casi"], { space: 2 })) });
    await card(s, 5.15, 1.2, 4.35, 3.0, { icon: "FiMonitor", head: "Dimostrazioni", headSize: 15, bodySize: 13,
      body: [{ text: "Esempi presentati dal fornitore o in pubblico", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 6 } }].concat(bullets(["Casi scelti con cura", "Condizioni controllate", "Nessuna integrazione con processi reali"], { space: 2 })) });
    banner(s, 4.35, "Indizi utili, ma non sostituiscono la prova sul proprio contesto.", { h: 0.6 });
  }
  {
    const s = content("Valutare le prestazioni nel contesto reale", "Se benchmark e dimostrazioni non bastano, come si valuta un sistema per un uso specifico? Senza entrare in metodologie quantitative, possiamo indicare un approccio semplice, applicabile anche da chi non è tecnico. Primo: definire con precisione il compito e che cosa si intende per risultato buono. Secondo: raccogliere un insieme di casi reali, rappresentativi della varietà che incontreremo, compresi i casi difficili, insoliti e ambigui, non solo quelli tipici. Terzo: confrontare i risultati del sistema con quelli attesi, possibilmente con il giudizio di una persona competente. Quarto: annotare dove e come il sistema sbaglia: non conta solo quanti errori fa, ma di che tipo sono, quanto sono gravi e quanto sono facili da individuare. Quinto: ripetere la valutazione nel tempo, perché modelli, applicazioni e dati cambiano. Un esempio: prima di usare l'AI per estrarre dati dalle fatture dei fornitori, provarla su cinquanta fatture reali di formati diversi, comprese quelle scansionate male, e controllare campo per campo. Questo approccio porta a una conclusione molto più utile di qualunque benchmark generico. La progettazione strutturata di queste valutazioni, con criteri di successo e insuccesso definiti prima, è trattata nel Tema 15.");
    const st = [["FiTarget", "Definire il compito", "Che cosa significa un buon risultato"], ["FiFolder", "Raccogliere casi reali", "Anche difficili, insoliti, ambigui"], ["FiColumns", "Confrontare", "Con il risultato atteso e il giudizio esperto"], ["FiAlertTriangle", "Analizzare gli errori", "Tipo, gravità, facilità di individuazione"], ["FiRefreshCw", "Ripetere nel tempo", "Modelli e dati cambiano"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.25, 1.68, 2.35, i === 3 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.56, 1.4, 0.56, st[i][0]);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.08, y: 2.05, w: 1.52, h: 0.6, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.1, y: 2.68, w: 1.48, h: 0.85, fontSize: 11, color: C.text2, align: "center" });
    }
    shapeBox(s, 0.5, 3.8, 9.0, 1.15, C.text1, "esempio fatture");
    txt(s, "ESEMPIO", { x: 0.7, y: 3.9, w: 2, h: 0.28, fontSize: 10, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Prima di usare l'AI per estrarre dati dalle fatture: provarla su 50 fatture reali di formati diversi, comprese quelle scansionate male, e controllare campo per campo.", { x: 0.7, y: 4.18, w: 8.6, h: 0.7, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Il modello e il sistema completo", "Ultimo punto del sottotema. Quando valutiamo l'affidabilità, dobbiamo guardare al sistema completo, non solo al modello. Nel Tema 2 abbiamo visto che il modello è il motore di un'applicazione più ampia. Allo stesso modo, il risultato che arriva sulla nostra scrivania dipende da una catena di elementi: la qualità dei dati e dei documenti disponibili; il modo in cui vengono recuperate le informazioni, per esempio in un sistema RAG; il modello; le istruzioni e la configurazione dell'applicazione; gli strumenti collegati; e infine la persona che usa e controlla il risultato. Come in ogni catena, l'affidabilità complessiva dipende anche dagli anelli più deboli. Un ottimo modello collegato a un archivio documentale disordinato, con versioni obsolete delle procedure, darà risposte obsolete. Un sistema ben configurato usato da una persona che non controlla nulla produrrà errori non intercettati. Al contrario, un modello meno potente, ma con buone fonti, istruzioni chiare e controlli adeguati, può dare risultati più affidabili. Per questo quando un progetto AI non funziona, la causa non è sempre 'il modello'.");
    const ch = [["FiDatabase", "Dati e documenti"], ["FiSearch", "Recupero delle informazioni"], ["FiCpu", "Modello"], ["FiSettings", "Istruzioni e configurazione"], ["FiTool", "Strumenti collegati"], ["FiUserCheck", "Persona che usa e controlla"]];
    for (let i = 0; i < 6; i++) {
      const x = 0.5 + i * 1.55;
      const m = i === 2;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 1.4, w: 1.38, h: 1.9, rectRadius: 0.3, fill: { color: m ? C.accent1 : C.background2 }, line: { color: C.accent1, width: 1.5 }, objectName: "anello " + ch[i][1] });
      await iconCircle(s, x + 0.42, 1.6, 0.55, ch[i][0], m ? C.background1 : C.accent1, m ? HEX.a1 : HEX.lt1);
      txt(s, ch[i][1], { x: x + 0.08, y: 2.25, w: 1.22, h: 0.9, fontSize: 12, bold: true, color: m ? C.background1 : C.text1, align: "center", valign: "middle" });
      if (i < 5) s.addShape(pres.shapes.LINE, { x: x + 1.38, y: 2.35, w: 0.17, h: 0, line: { color: C.accent1, width: 3 }, objectName: "collegamento" });
    }
    txt(s, "L'affidabilità complessiva dipende anche dagli anelli più deboli", { x: 0.5, y: 3.45, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1, align: "center" });
    await card(s, 0.5, 3.85, 4.35, 1.15, { head: "Ottimo modello + archivio obsoleto", headSize: 13, bodySize: 12, body: "= risposte obsolete" });
    await card(s, 5.15, 3.85, 4.35, 1.15, { head: "Buone fonti + istruzioni chiare + controlli", headSize: 13, bodySize: 12, fill: C.accent6, body: "= risultati più affidabili, anche con un modello meno potente" });
  }
  keySlide("L'affidabilità non è una proprietà unica e universale di un modello; deve essere valutata per compiti e condizioni d'uso specifici.", "Sottotema 3.5  ·  Accuratezza, affidabilità e consistenza", "Concetto chiave. Accuratezza, affidabilità, consistenza e utilità sono dimensioni diverse. Le prestazioni cambiano da compito a compito e possono cambiare con piccole variazioni dell'input. Benchmark e dimostrazioni sono indizi, non prove sul nostro contesto. E l'affidabilità riguarda il sistema completo, dalle fonti alla persona che controlla. Domanda di verifica: un collega dice 'ho letto che il modello X è il migliore sui benchmark, quindi possiamo usarlo per estrarre dati dai nostri contratti'. Che cosa gli rispondete? Risposta: che il benchmark è un indizio, ma serve una prova sui nostri contratti reali, compresi i casi difficili, e una valutazione del sistema completo.");

  // =====================================================================
  section("3.6 Verifica dei risultati");
  divider("3.6", "Verificabilità e controllo dei risultati", "La verifica è parte dell'uso consapevole dell'AI ed è proporzionata all'importanza del compito", "Arriviamo alla parte più operativa del modulo. Abbiamo visto che i sistemi AI possono sbagliare in vari modi; ora vediamo come controllare i risultati. Non svilupperemo tecniche dettagliate di prompting, ma principi di controllo applicabili a qualunque strumento. Il punto di partenza è culturale: la verifica non è un segno di sfiducia o un'attività accessoria, ma una parte normale dell'uso dell'AI, come rileggere un documento prima di inviarlo. E deve essere proporzionata: non tutto va verificato con lo stesso livello di attenzione.");
  {
    const s = content("Che cosa verificare", "Possiamo raggruppare i controlli in quattro famiglie, che corrispondono ai principali tipi di errore. Le affermazioni fattuali: nomi, date, eventi, dati, norme, caratteristiche di prodotti. Sono il terreno tipico delle allucinazioni. Le fonti e i riferimenti: esistono? Dicono davvero ciò che viene attribuito loro? Sono autorevoli e aggiornate? I calcoli, i dati e le informazioni numeriche: i numeri sono corretti, i totali tornano, i dati estratti corrispondono all'originale? La completezza e la coerenza: la risposta copre tutti gli aspetti richiesti, non omette elementi importanti, non contiene contraddizioni interne, è coerente con le istruzioni e con il contesto? Non tutti i controlli servono ogni volta: dipende dal tipo di output. Una bozza di email richiede soprattutto il controllo di coerenza e tono; un report con dati richiede il controllo dei numeri e delle fonti; un riassunto di un contratto richiede il controllo di completezza e di fedeltà al testo originale. Nelle prossime slide vediamo ciascuna famiglia.");
    const f = [["FiCheckCircle", "Affermazioni fattuali", "Nomi, date, eventi, norme, caratteristiche"], ["FiBookmark", "Fonti e riferimenti", "Esistono, dicono questo, sono autorevoli?"], ["FiHash", "Calcoli e dati", "Numeri corretti, totali che tornano, estrazioni fedeli"], ["FiList", "Completezza e coerenza", "Nulla di importante omesso, nessuna contraddizione"]];
    await iconGrid(s, f.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.6, headSize: 15, bodySize: 13 });
    txt(s, "Il controllo dipende dal tipo di output", { x: 0.5, y: 4.0, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Email: coerenza e tono", "Report: numeri e fonti", "Riassunto: completezza e fedeltà"].forEach((e, i) => chip(s, 0.5 + i * 3.07, 4.4, 2.86, 0.55, e, { fill: C.accent6, fontSize: 12 }));
  }
  {
    const s = content("Verificare fatti, fonti e riferimenti", "Per le affermazioni fattuali e le fonti, possiamo seguire tre domande, in ordine. Prima domanda: la fonte esiste? Cercare il documento, l'articolo, la norma, la pagina citata. Se non si trova, va considerata inesistente, anche se sembra perfettamente plausibile. Seconda domanda: la fonte dice davvero ciò che le viene attribuito? Accade spesso che la fonte esista, ma che il sistema le attribuisca un contenuto diverso, la citi in modo impreciso o la estenda oltre ciò che afferma. Bisogna quindi aprirla e leggere il passaggio pertinente, non fermarsi al titolo. Terza domanda: la fonte è autorevole e aggiornata? Una normativa abrogata, un articolo di opinione, un sito poco affidabile, un documento interno superato non sono fonti adeguate per un'informazione importante. Per le affermazioni senza fonte, la regola è confrontarle con una fonte indipendente e affidabile: la documentazione ufficiale, il sito dell'ente competente, il testo normativo, i dati aziendali di riferimento. Un consiglio pratico: quando possibile, usare strumenti che mostrano le fonti e permettono di aprirle con un clic; rende la verifica molto più rapida. Ma il clic va fatto.");
    const q = [["1", "La fonte esiste?", "Cercarla. Se non si trova, considerarla inesistente."], ["2", "Dice davvero questo?", "Aprirla e leggere il passaggio, non fermarsi al titolo."], ["3", "È autorevole e aggiornata?", "Niente norme abrogate, opinioni o documenti superati."]];
    q.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.4, i === 1 ? C.accent6 : C.background2, e[1]);
      txt(s, e[0], { x: x + 0.2, y: 1.3, w: 0.6, h: 0.65, fontSize: 32, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.2, y: 2.0, w: 2.46, h: 0.45, fontSize: 15, bold: true, color: C.text1 });
      txt(s, e[2], { x: x + 0.2, y: 2.5, w: 2.46, h: 1.0, fontSize: 13, color: C.text2 });
      if (i < 2) arrow(s, x + 2.88, 2.25, 0.17);
    });
    await card(s, 0.5, 3.8, 4.35, 1.15, { inline: true, icon: "FiExternalLink", head: "Affermazioni senza fonte", bodySize: 12, body: "Confrontarle con una fonte indipendente e affidabile." });
    await card(s, 5.15, 3.8, 4.35, 1.15, { inline: true, icon: "FiMousePointer", head: "Fonti cliccabili", bodySize: 12, fill: C.accent6, body: "Rendono la verifica rapida. Ma il clic va fatto." });
  }
  {
    const s = content("Controllare calcoli, dati e informazioni", "I numeri meritano un'attenzione particolare, per tre ragioni: sono un terreno frequente di errore, sono spesso difficili da individuare a occhio, e finiscono in documenti e decisioni importanti. Alcuni principi pratici. Ricalcolare i valori importanti con uno strumento affidabile, come un foglio di calcolo; oppure, se l'assistente può eseguire codice, chiedere che i calcoli vengano eseguiti invece che 'stimati' nel testo. Confrontare i dati estratti con il documento originale, almeno a campione: se l'AI ha estratto venti importi da un contratto, controllarne alcuni, e tutti se sono critici. Fare controlli di plausibilità: gli ordini di grandezza sono sensati? I totali corrispondono alla somma delle parti? Le percentuali sommano a cento? Le date sono coerenti tra loro? Prestare attenzione alle unità di misura, alle valute, ai separatori decimali, che cambiano tra formati italiani e anglosassoni. Verificare che i dati siano quelli giusti: l'AI potrebbe aver usato un dato corretto ma riferito a un periodo, un'entità o una versione diversa. Questi controlli richiedono pochi minuti e prevengono gli errori più costosi.");
    const c = [["FiGrid", "Ricalcolare", "Con un foglio di calcolo, o chiedendo l'esecuzione di codice"], ["FiColumns", "Confrontare con l'originale", "A campione, o tutti se i dati sono critici"], ["FiActivity", "Controlli di plausibilità", "Ordini di grandezza, totali, percentuali, date"], ["FiDollarSign", "Unità e formati", "Valute, unità di misura, separatori decimali"], ["FiCalendar", "Dato giusto, riferimento giusto", "Periodo, entità, versione corretti"]];
    await iconGrid(s, c.slice(0, 3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, h: 1.6 });
    await iconGrid(s, c.slice(3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 3.0, h: 1.3 });
    txt(s, "Pochi minuti di controllo prevengono gli errori più costosi.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Completezza, coerenza e tracciabilità", "Due controlli spesso trascurati sono quelli di completezza e coerenza. Completezza: la risposta copre tutto ciò che era richiesto? Le omissioni sono insidiose perché non si vedono: un riassunto di un contratto può essere accurato in ogni frase e omettere proprio la clausola di recesso. Un buon controllo è partire dalla richiesta originale e spuntare ogni punto, oppure, per i documenti, verificare che le sezioni principali siano rappresentate. Coerenza: la risposta è priva di contraddizioni interne? È coerente con le istruzioni date, con il contesto e con ciò che sappiamo? Accanto a questi, un principio organizzativo: la tracciabilità. Significa poter ricostruire da dove viene ogni informazione importante: da quale documento, da quale fonte, da quale elaborazione. In pratica: conservare le fonti usate, annotare quali parti di un documento sono state prodotte o modificate con l'AI quando è rilevante, mantenere il collegamento tra un dato e la sua origine. La tracciabilità rende possibile verificare anche a posteriori, correggere rapidamente se emerge un errore, e rispondere alla domanda 'da dove viene questo numero?'. Le regole aziendali su come documentare l'uso dell'AI sono trattate nei Temi 17 e 18.");
    await card(s, 0.5, 1.2, 2.86, 2.75, { icon: "FiCheckSquare", head: "Completezza", headSize: 15, bodySize: 12, body: "Tutto ciò che era richiesto è presente?\n\nLe omissioni non si vedono: spuntare ogni punto della richiesta." });
    await card(s, 3.57, 1.2, 2.86, 2.75, { icon: "FiGitMerge", head: "Coerenza", headSize: 15, bodySize: 12, body: "Nessuna contraddizione interna.\n\nCoerenza con istruzioni, contesto e ciò che sappiamo." });
    await card(s, 6.64, 1.2, 2.86, 2.75, { icon: "FiMap", head: "Tracciabilità", headSize: 15, bodySize: 12, fill: C.accent6, body: "Sapere da dove viene ogni informazione importante.\n\nConservare le fonti, annotare l'uso dell'AI quando rilevante." });
    banner(s, 4.15, "Esempio: un riassunto accurato in ogni frase, che omette proprio la clausola di recesso.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("I limiti dell'autoverifica", "Una tentazione naturale è chiedere all'AI di verificare il proprio lavoro: 'sei sicuro?', 'controlla la risposta', 'queste fonti esistono?'. Può essere utile, ma ha limiti importanti. L'autoverifica serve come primo filtro: chiedere al sistema di rileggere, di cercare errori o di mostrare i passaggi può far emergere alcuni sbagli evidenti, soprattutto nei calcoli e nella logica, e alcuni sistemi lo fanno anche in automatico. Ma non è una verifica indipendente, per tre ragioni. Primo: il sistema usa la stessa conoscenza e gli stessi meccanismi che hanno prodotto l'errore; se non sa che un'informazione è falsa, non lo saprà nemmeno al secondo controllo. Secondo: la tendenza ad assecondare l'utente può portare a risultati opposti: il sistema può confermare un errore se gli chiediamo conferma, oppure cambiare una risposta corretta se mostriamo un dubbio. Ricordiamo il caso Avianca, in cui il sistema confermò l'esistenza di sentenze inventate. Terzo: un sistema non ha accesso diretto alla verità; a meno che non usi strumenti esterni come la ricerca, 'verificare' significa solo rigenerare. L'autoverifica che usa strumenti esterni, come una ricerca effettiva o l'esecuzione di codice, è più utile, ma anche i suoi risultati vanno controllati. In sintesi: l'autoverifica è un aiuto, non un sostituto della verifica umana o su fonti indipendenti.");
    await card(s, 0.5, 1.2, 3.3, 3.75, { icon: "FiFilter", head: "Utile come primo filtro", headSize: 15, bodySize: 13, fill: C.accent6,
      body: bullets(["Rileggere e cercare errori", "Mostrare i passaggi", "Far emergere sbagli evidenti in calcoli e logica"], { space: 4 }) });
    txt(s, "Ma non è una verifica indipendente", { x: 4.1, y: 1.2, w: 5.4, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const r = [["FiRepeat", "Stessa conoscenza, stessi meccanismi", "Se non sa che un'informazione è falsa, non lo saprà al secondo controllo"], ["FiThumbsUp", "Tendenza ad assecondare", "Può confermare un errore o cambiare una risposta corretta"], ["FiSearch", "Nessun accesso diretto alla verità", "Senza strumenti esterni, verificare significa rigenerare"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.7 + i * 1.08;
      await iconCircle(s, 4.1, y, 0.5, r[i][0], C.accent5);
      txt(s, r[i][1], { x: 4.75, y: y - 0.04, w: 4.75, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
      txt(s, r[i][2], { x: 4.75, y: y + 0.3, w: 4.75, h: 0.6, fontSize: 12, color: C.text2 });
    }
  }
  {
    const s = content("Supervisione umana e verifica proporzionata", "La verifica richiede competenza: per accorgersi di un errore bisogna saperne abbastanza sull'argomento. È un punto delicato, perché l'AI è particolarmente attraente proprio quando non conosciamo bene un tema, ed è proprio allora che siamo meno in grado di controllarla. La regola pratica è che chi verifica deve avere le competenze necessarie per quel tipo di output, o deve coinvolgere chi le ha. Un secondo rischio da conoscere è l'automation bias, o pregiudizio di automazione: la tendenza, documentata da decenni di studi in settori come l'aviazione e la medicina (per una sintesi, Parasuraman e Manzey, 2010), a fidarsi eccessivamente dei sistemi automatici e a ridurre l'attenzione quando funzionano bene la maggior parte delle volte. Più un sistema è affidabile, più rischiamo di non accorgerci del suo errore occasionale. Infine, la verifica deve essere proporzionata. Lo schema in slide propone tre livelli indicativi. Verifica leggera, cioè una rilettura critica, per bozze interne, idee e testi a basso impatto. Verifica standard, cioè controllo dei fatti principali, dei numeri e delle fonti, per documenti che escono dal gruppo di lavoro. Verifica approfondita, con controllo su fonti indipendenti e revisione di un esperto, per contenuti con conseguenze legali, economiche, di sicurezza o reputazionali rilevanti.");
    const l = [["Leggera", "Rilettura critica", "Bozze interne, idee, testi a basso impatto", C.background2, C.text1], ["Standard", "Fatti principali, numeri, fonti", "Documenti che escono dal gruppo di lavoro", C.accent6, C.text1], ["Approfondita", "Fonti indipendenti e revisione esperta", "Conseguenze legali, economiche, di sicurezza, reputazionali", C.accent1, C.background1]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 3.07, h = 1.7 + i * 0.4, y = 3.4 - h + 0.7;
      shapeBox(s, x, y, 2.86, h, e[3], e[0]);
      txt(s, "Verifica " + e[0].toLowerCase(), { x: x + 0.2, y: y + 0.12, w: 2.5, h: 0.38, fontSize: 16, bold: true, color: e[4] });
      txt(s, e[1], { x: x + 0.2, y: y + 0.52, w: 2.5, h: 0.5, fontSize: 13, bold: true, color: i === 2 ? C.accent6 : C.accent1 });
      txt(s, e[2], { x: x + 0.2, y: y + 1.0, w: 2.5, h: h - 1.1, fontSize: 12, color: e[4] });
    });
    await card(s, 0.5, 4.25, 4.35, 0.75, { head: "Chi verifica deve avere le competenze", headSize: 13 });
    await card(s, 5.15, 4.25, 4.35, 0.75, { head: "Automation bias: più funziona, meno controlliamo", headSize: 13 });
  }
  keySlide("La verifica è parte dell'uso consapevole dell'AI e deve essere proporzionata all'importanza del compito e alle possibili conseguenze di un errore.", "Sottotema 3.6  ·  Verificabilità e controllo dei risultati", "Concetto chiave. Verificare significa controllare fatti, fonti, numeri, completezza e coerenza, con l'aiuto della tracciabilità. L'autoverifica del sistema è un primo filtro, non un sostituto. Chi verifica deve avere le competenze necessarie e diffidare dell'automation bias. E la profondità della verifica va commisurata alle conseguenze di un errore: leggera per le bozze interne, approfondita per ciò che ha effetti legali, economici o sulla sicurezza. Domanda di verifica: un assistente vi ha preparato una tabella di confronto tra tre offerte di fornitori, da presentare alla direzione. Quale livello di verifica serve e che cosa controllate? Risposta: almeno standard; controllare i prezzi e le condizioni sulle offerte originali, la completezza dei criteri e la coerenza dei totali.");

  // =====================================================================
  section("3.7 Fattori delle prestazioni");
  divider("3.7", "I fattori che influenzano le prestazioni", "Le prestazioni derivano dall'interazione tra tecnologia, qualità delle informazioni e modalità operative", "Questo sottotema, a priorità media, ha l'obiettivo di dare una comprensione generale dei fattori che determinano la qualità dei risultati. Non è un elenco di tecniche: le tecniche di formulazione delle richieste sono trattate nel Tema 6. Qui ci interessa capire che la qualità di un risultato non dipende solo dallo strumento, ma da una combinazione di fattori, molti dei quali sono sotto il nostro controllo.");
  {
    const s = content("Sette fattori", "Ecco i sette fattori principali. La scelta del modello e le caratteristiche del sistema: modelli diversi hanno capacità diverse, e lo stesso modello si comporta diversamente in applicazioni diverse. La complessità e l'ambiguità del compito: più un compito è complesso, insolito o ambiguo, più aumenta la probabilità di errore. La qualità delle informazioni disponibili: documenti chiari, aggiornati e corretti producono risultati migliori di materiali confusi, incompleti o contraddittori. La formulazione delle istruzioni: richieste chiare, specifiche, con obiettivo, contesto e formato atteso, producono risultati migliori di richieste vaghe. La quantità e la pertinenza del contesto: il contesto giusto aiuta, quello eccessivo o non pertinente può confondere. La disponibilità di strumenti e fonti esterne: ricerca, esecuzione di codice, accesso a basi documentali cambiano molto l'affidabilità per certi compiti. Le differenze tra ambiti applicativi: le prestazioni variano tra settori e domini, come vedremo. Notate che almeno quattro di questi fattori dipendono in gran parte da noi: la scelta dello strumento adatto, la qualità delle informazioni che forniamo, la formulazione delle istruzioni e il contesto.");
    const f = [["FiCpu", "Modello e sistema"], ["FiLayers", "Complessità e ambiguità del compito"], ["FiFileText", "Qualità delle informazioni"], ["FiEdit3", "Formulazione delle istruzioni"], ["FiMaximize2", "Quantità e pertinenza del contesto"], ["FiTool", "Strumenti e fonti esterne"], ["FiGlobe", "Ambito applicativo"]];
    const dep = [true, false, true, true, true, false, false];
    for (let i = 0; i < 7; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = row === 0 ? 0.5 + col * 2.3 : 1.65 + col * 2.3, y = 1.2 + row * 1.6;
      shapeBox(s, x, y, 2.15, 1.42, dep[i] ? C.accent6 : C.background2, f[i][1], dep[i] ? { color: C.accent1, width: 2 } : undefined);
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, f[i][0]);
      txt(s, f[i][1], { x: x + 0.18, y: y + 0.75, w: 1.85, h: 0.6, fontSize: 13, bold: true, color: C.text1 });
    }
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y: 4.55, w: 0.35, h: 0.3, rectRadius: 0.05, fill: { color: C.accent6 }, line: { color: C.accent1, width: 2 }, objectName: "legenda" });
    txt(s, "Fattori in gran parte sotto il nostro controllo", { x: 0.95, y: 4.5, w: 6, h: 0.4, fontSize: 12, color: C.text2, valign: "middle" });
  }
  {
    const s = content("Tecnologia, informazioni e modalità operative", "I sette fattori possono essere raggruppati in tre famiglie, che interagiscono tra loro. La tecnologia: il modello, il sistema, gli strumenti disponibili. Le informazioni: la qualità, la quantità e la pertinenza di ciò che il sistema ha a disposizione. Le modalità operative: come formuliamo il compito, quanto è complesso, in quale ambito lavoriamo. L'esempio in slide mostra come interagiscono. Stessa domanda, stesso modello: 'Quali sono i termini di pagamento concordati con il fornitore Rossi?'. Senza alcun documento, il sistema non può saperlo, e se risponde inventa: è un'allucinazione garantita. Con il contratto allegato, ma con una richiesta vaga, otteniamo una risposta probabilmente corretta ma forse incompleta. Con il contratto allegato e una richiesta precisa, che chiede termini, scadenze e penali citando la clausola, otteniamo una risposta completa e verificabile. La tecnologia è la stessa: è cambiato tutto il resto. Il messaggio è che le prestazioni non sono una proprietà fissa dello strumento, ma il risultato di come lo usiamo.");
    const fam = [["FiCpu", "Tecnologia", "Modello, sistema, strumenti"], ["FiDatabase", "Informazioni", "Qualità, quantità, pertinenza"], ["FiEdit3", "Modalità operative", "Istruzioni, compito, ambito"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 1.25, { inline: true, icon: fam[i][0], head: fam[i][1], bodySize: 12, body: fam[i][2] });
    shapeBox(s, 0.5, 2.6, 9.0, 0.5, C.background2, "domanda esempio");
    txt(s, [{ text: "Stessa domanda, stesso modello: ", options: { bold: true, color: C.text1 } }, { text: "\"Quali sono i termini di pagamento concordati con il fornitore Rossi?\"", options: { italic: true, color: C.text1 } }], { x: 0.7, y: 2.6, w: 8.6, h: 0.5, fontSize: 13, valign: "middle" });
    const sc = [["Nessun documento", "Il sistema non può saperlo: se risponde, inventa", C.background2, C.text1], ["Contratto + richiesta vaga", "Probabilmente corretta, forse incompleta", C.accent6, C.text1], ["Contratto + richiesta precisa", "Termini, scadenze e penali con la clausola: completa e verificabile", C.accent1, C.background1]];
    sc.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 3.25, 2.86, 1.7, e[2], e[0]);
      txt(s, e[0], { x: x + 0.2, y: 3.37, w: 2.46, h: 0.4, fontSize: 14, bold: true, color: e[3] });
      txt(s, e[1], { x: x + 0.2, y: 3.8, w: 2.46, h: 1.05, fontSize: 12, color: e[3] });
    });
  }
  {
    const s = content("Differenze tra ambiti applicativi", "Le prestazioni dei sistemi AI non sono uguali in tutti gli ambiti. Alcuni fattori rendono un ambito più o meno favorevole. Il linguaggio: i sistemi lavorano meglio con il linguaggio generale che con linguaggi molto tecnici o settoriali, come quello di nicchie ingegneristiche o di specifiche procedure interne. La lingua: le prestazioni in italiano sono generalmente buone, ma su terminologia specialistica possono essere inferiori rispetto all'inglese, che domina i dati di addestramento. Il contesto locale: normative nazionali o regionali, prassi di settore, contratti collettivi, realtà di mercato locali sono meno rappresentati dei temi globali, e quindi più esposti a errori o a risposte basate su altri paesi. I dati e le conoscenze aziendali: tutto ciò che è specifico della nostra organizzazione, come prodotti, clienti, procedure e storia, non è noto al modello se non viene fornito. La velocità di cambiamento: in ambiti che cambiano rapidamente, come normative, prezzi o tecnologie, la conoscenza incorporata invecchia in fretta. In sintesi: quanto più un ambito è specialistico, locale, interno o in rapido cambiamento, tanto più contano le fonti fornite e la verifica esperta.");
    table(s, [["Fattore", "Più favorevole", "Meno favorevole"], ["Linguaggio", "Generale, comune", "Molto tecnico o settoriale"], ["Lingua", "Inglese e lingue molto diffuse", "Terminologia specialistica in altre lingue"], ["Contesto", "Temi globali", "Normative e prassi nazionali o locali"], ["Conoscenze", "Pubbliche e diffuse", "Interne all'azienda, se non fornite"], ["Cambiamento", "Ambiti stabili", "Ambiti in rapida evoluzione"]], { colW: [2.0, 3.5, 3.5], rowH: 0.52, accentCol: 1, blankCorner: false });
    banner(s, 4.35, "Più un ambito è specialistico, locale, interno o in rapido cambiamento, più contano fonti fornite e verifica esperta.", { h: 0.6, fontSize: 13 });
  }
  keySlide("Le prestazioni derivano dall'interazione tra caratteristiche tecnologiche, qualità delle informazioni e modalità operative.", "Sottotema 3.7  ·  I fattori che influenzano le prestazioni", "Concetto chiave. La qualità di un risultato AI non dipende solo dallo strumento: dipende anche dalle informazioni che il sistema ha a disposizione e da come lo usiamo. Molti fattori sono sotto il nostro controllo: scegliere lo strumento adatto, fornire informazioni di qualità e pertinenti, formulare richieste chiare. E alcuni ambiti, specialistici, locali o in rapido cambiamento, richiedono più attenzione. Domanda di verifica: un collega lamenta che 'l'AI dà risposte generiche e sbagliate sulle nostre procedure'. Quali fattori controllereste? Possibili risposte: se le procedure sono state fornite, se sono aggiornate, come è formulata la richiesta, se lo strumento ha accesso alle fonti aziendali.");

  // =====================================================================
  section("3.8 Quando usare o limitare l'AI");
  divider("3.8", "Quando utilizzare o limitare l'AI", "Usare l'AI quando prestazioni e controlli sono compatibili con il rischio del compito, non solo quando sembra capace di eseguirlo", "Ultimo sottotema, che raccoglie tutto il modulo in una capacità decisionale. Abbiamo visto che cosa sa fare l'AI, dove sbaglia, come valutarla e come verificarla. Ora la domanda è: in quali attività usarla, con quale ruolo, e quando invece limitarne o evitarne l'uso? Ci concentriamo sulla compatibilità tra capacità, affidabilità e rischio del compito. La selezione dei progetti e il calcolo del ROI sono trattati nei Temi 12 e 15; privacy, sicurezza, normativa e policy nei Temi 17 e 18.");
  {
    const s = content("Possibilità tecnica e opportunità di utilizzo", "Il primo passo è distinguere due domande. La prima: il sistema è tecnicamente in grado di svolgere il compito? Spesso la risposta è sì: può scrivere una valutazione di un collaboratore, rispondere a una domanda medica, redigere un parere legale, decidere a quale cliente concedere una dilazione. La seconda: è opportuno usarlo per questo compito, in questo modo? Qui la risposta dipende da altri fattori: quanto è affidabile per quel compito specifico, quanto è grave un errore, se possiamo verificare il risultato, chi ne subisce le conseguenze, che cosa prevedono le regole aziendali e le normative. Il fatto che un sistema produca un risultato convincente non significa che sia opportuno affidargli quel compito. È la stessa logica che applichiamo alle persone: un neoassunto brillante può scrivere un contratto, ma non lo facciamo firmare senza una revisione. Il concetto chiave del sottotema lo esprime chiaramente: l'AI va usata quando le sue prestazioni e i controlli disponibili sono compatibili con il rischio del compito, non soltanto quando sembra capace di eseguirlo.");
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiCpu", head: "Può farlo?", headSize: 17, bodySize: 13, body: "Possibilità tecnica.\n\nSpesso sì: valutazioni, risposte mediche, pareri legali, decisioni su clienti." });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiHelpCircle", head: "È opportuno farlo?", headSize: 17, bodySize: 13, fill: C.accent6, body: bullets(["Affidabilità per quel compito", "Gravità di un errore", "Possibilità di verificare", "Chi subisce le conseguenze", "Regole aziendali e normative"], { space: 1 }) });
    banner(s, 3.9, "Un neoassunto brillante può scrivere un contratto, ma non lo facciamo firmare senza revisione.", { h: 1.05, fontSize: 14 });
  }
  {
    const s = content("Le conseguenze di un errore", "Per decidere, dobbiamo partire dalle conseguenze di un possibile errore. Possiamo valutarle con quattro domande. Quanto è grave l'errore? Una frase poco elegante in una bozza interna ha conseguenze trascurabili; un importo sbagliato in un'offerta o un'informazione errata a un cliente possono avere conseguenze economiche, legali o reputazionali serie. È reversibile? Un errore in una bozza si corregge facilmente; un'email inviata a mille clienti, un pagamento eseguito, una decisione comunicata a un candidato sono difficili o impossibili da annullare. Chi ne subisce le conseguenze? Un errore che resta a noi è diverso da uno che ricade su clienti, collaboratori, cittadini, soprattutto se riguarda i loro diritti, la loro salute o la loro situazione economica. È rilevabile? Alcuni errori si notano subito, altri restano nascosti a lungo, come un dato sbagliato in un report che alimenta decisioni successive. Più le risposte a queste domande indicano gravità, irreversibilità, impatto su terzi e difficoltà di rilevazione, più l'uso dell'AI richiede cautela.");
    const q = [["FiAlertTriangle", "Gravità", "Una frase poco elegante o un importo sbagliato in un'offerta?"], ["FiRotateCcw", "Reversibilità", "Una bozza da correggere o un'email inviata a mille clienti?"], ["FiUsers", "Chi ne subisce le conseguenze", "Resta a noi o ricade su clienti, collaboratori, cittadini?"], ["FiEyeOff", "Rilevabilità", "Si nota subito o resta nascosto e si propaga?"]];
    await iconGrid(s, q.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.85, headSize: 15, bodySize: 13 });
    banner(s, 4.25, "Più gravità, irreversibilità, impatto su terzi e difficoltà di rilevazione: più cautela.", { h: 0.7 });
  }
  {
    const s = content("Attività a basso e alto impatto", "Combinando l'impatto di un errore con la facilità di verifica, otteniamo una matrice utile per orientare le decisioni. Basso impatto e verifica facile: bozze di email interne, idee, riformulazioni, sintesi per uso personale. Qui l'AI può essere usata liberamente, con una rilettura. Basso impatto ma verifica difficile: per esempio ricerche esplorative su temi che non conosciamo. L'uso è possibile, ma i risultati vanno trattati come indicazioni da approfondire, non come conclusioni. Alto impatto ma verifica facile: per esempio un'offerta commerciale o un documento contrattuale preparato a partire da dati che possiamo controllare. L'AI può essere un ottimo supporto, con verifica sistematica prima dell'uso. Alto impatto e verifica difficile: per esempio decisioni su persone, valutazioni legali, mediche o di sicurezza, dove l'errore è grave e difficile da individuare. Qui l'uso va limitato a un supporto per esperti competenti, oppure evitato. La matrice è indicativa: serve a ragionare, non a sostituire il giudizio e le regole aziendali. Suggerimento: chiedere ai partecipanti di collocare nella matrice tre attività del proprio lavoro.");
    txt(s, "Verifica facile", { x: 1.6, y: 1.15, w: 3.8, h: 0.3, fontSize: 12, bold: true, color: C.accent2, align: "center" });
    txt(s, "Verifica difficile", { x: 5.5, y: 1.15, w: 3.8, h: 0.3, fontSize: 12, bold: true, color: C.accent2, align: "center" });
    txt(s, "Basso impatto", { x: 0.5, y: 1.5, w: 1.0, h: 1.6, fontSize: 12, bold: true, color: C.accent2, valign: "middle" });
    txt(s, "Alto impatto", { x: 0.5, y: 3.25, w: 1.0, h: 1.6, fontSize: 12, bold: true, color: C.accent2, valign: "middle" });
    const q = [["Usare liberamente", "Con una rilettura", "Bozze interne, idee, riformulazioni", C.accent6, C.text1], ["Usare come indicazione", "Da approfondire, non conclusioni", "Ricerche esplorative su temi poco noti", C.background2, C.text1], ["Usare con verifica sistematica", "Controllo completo prima dell'uso", "Offerte, documenti da dati controllabili", C.background2, C.text1], ["Limitare o evitare", "Solo supporto a esperti competenti", "Decisioni su persone, valutazioni legali, mediche, di sicurezza", C.text1, C.background1]];
    for (let i = 0; i < 4; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 1.6 + col * 3.9, y = 1.5 + row * 1.75;
      shapeBox(s, x, y, 3.75, 1.6, q[i][3], q[i][0]);
      txt(s, q[i][0], { x: x + 0.2, y: y + 0.1, w: 3.35, h: 0.38, fontSize: 15, bold: true, color: q[i][4] });
      txt(s, q[i][1], { x: x + 0.2, y: y + 0.5, w: 3.35, h: 0.32, fontSize: 12, bold: true, color: i === 3 ? C.accent6 : C.accent1 });
      txt(s, q[i][2], { x: x + 0.2, y: y + 0.85, w: 3.35, h: 0.7, fontSize: 12, color: q[i][4] });
    }
  }
  {
    const s = content("Affidabilità adeguata allo scopo", "Questa integrazione del sottotema esprime un principio fondamentale: non esiste una soglia di affidabilità valida in assoluto. La soglia richiesta, e i controlli necessari, dipendono dalle conseguenze di un errore. Un sistema che sbaglia una volta su venti può essere più che adeguato per generare idee o bozze, dove l'errore è innocuo e facile da correggere. Lo stesso sistema è del tutto inadeguato per calcolare le buste paga o per rispondere a domande sulla sicurezza degli impianti, dove anche un errore su mille può essere inaccettabile. Lo schema in slide mette in relazione le conseguenze di un errore con l'affidabilità richiesta e con i controlli necessari. Il principio si può applicare in due direzioni. Se il compito ha conseguenze gravi, servono un sistema dimostratamente affidabile per quel compito e controlli robusti. Se il sistema non raggiunge quell'affidabilità, o i controlli non sono possibili, l'uso va ridotto a un ruolo di supporto, o evitato. Ecco perché la domanda 'l'AI è affidabile?' non ha una risposta generale: la domanda giusta è 'è abbastanza affidabile per questo scopo, con i controlli che possiamo mettere in atto?'.");
    const lv = [["Lievi", "Idee, bozze interne", "Moderata", "Rilettura", 0.35], ["Moderate", "Documenti condivisi, comunicazioni", "Buona", "Verifica di fatti e numeri", 0.6], ["Gravi", "Contratti, dati economici, informazioni ai clienti", "Elevata e dimostrata", "Verifica sistematica e revisione esperta", 0.85]];
    txt(s, "Conseguenze di un errore", { x: 0.5, y: 1.15, w: 3.0, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    txt(s, "Affidabilità richiesta", { x: 3.7, y: 1.15, w: 2.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    txt(s, "Controlli necessari", { x: 6.8, y: 1.15, w: 2.7, h: 0.3, fontSize: 12, bold: true, color: C.accent2 });
    lv.forEach((e, i) => {
      const y = 1.5 + i * 0.95;
      shapeBox(s, 0.5, y, 3.0, 0.82, C.background2, "conseguenze " + e[0]);
      txt(s, e[0], { x: 0.65, y: y + 0.06, w: 2.7, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
      txt(s, e[1], { x: 0.65, y: y + 0.38, w: 2.75, h: 0.42, fontSize: 11, color: C.text2 });
      s.addShape(pres.shapes.RECTANGLE, { x: 3.7, y: y + 0.12, w: 2.9, h: 0.26, fill: { color: C.background2 }, line: { type: "none" }, objectName: "barra base" });
      s.addShape(pres.shapes.RECTANGLE, { x: 3.7, y: y + 0.12, w: 2.9 * e[4], h: 0.26, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "barra affidabilità" });
      txt(s, e[2], { x: 3.7, y: y + 0.44, w: 2.9, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      shapeBox(s, 6.8, y, 2.7, 0.82, i === 2 ? C.accent1 : C.accent6, "controlli " + e[0]);
      txt(s, e[3], { x: 6.95, y, w: 2.45, h: 0.82, fontSize: 12, bold: true, color: i === 2 ? C.background1 : C.text1, valign: "middle" });
    });
    banner(s, 4.4, "Non \"l'AI è affidabile?\", ma \"è abbastanza affidabile per questo scopo, con i controlli possibili?\"", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Supporto, supervisione e delega", "Decidere di usare l'AI non è una scelta tutto o niente: possiamo affidarle ruoli diversi. Lo spettro in slide ne propone tre. Supporto: l'AI aiuta la persona, che svolge il compito e decide. Per esempio, suggerisce idee, prepara una bozza, sintetizza materiali; la persona usa ciò che ritiene utile. È il ruolo più diffuso e, in genere, quello con il rischio più basso. Supervisione: l'AI svolge il compito, la persona controlla ogni risultato prima che venga usato. Per esempio, l'AI propone le risposte ai clienti, un operatore le verifica e le invia. Il rischio dipende dalla qualità reale del controllo, e dal rischio di automation bias. Delega: l'AI svolge il compito in autonomia, e la persona interviene solo su eccezioni o a campione. Per esempio, la classificazione automatica di documenti a basso impatto. Richiede un'affidabilità dimostrata nel contesto specifico, conseguenze limitate degli errori e un monitoraggio continuo. Con la diffusione di sistemi sempre più autonomi, spesso chiamati agenti, capaci di svolgere sequenze di azioni, la scelta del ruolo diventa ancora più importante. Il principio: più autonomia diamo, più devono essere alte l'affidabilità dimostrata e basse le conseguenze degli errori.");
    const r = [["FiUser", "Supporto", "L'AI aiuta, la persona svolge il compito e decide", "Idee, bozze, sintesi", C.background2, C.text1], ["FiUserCheck", "Supervisione", "L'AI svolge il compito, la persona controlla ogni risultato", "Risposte ai clienti verificate da un operatore", C.accent6, C.text1], ["FiCpu", "Delega", "L'AI agisce in autonomia, la persona interviene su eccezioni", "Classificazione di documenti a basso impatto", C.accent1, C.background1]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.55, 2.86, 2.6, r[i][4], r[i][1]);
      await iconCircle(s, x + 0.2, 1.72, 0.55, r[i][0], i === 2 ? C.background1 : C.accent1, i === 2 ? HEX.a1 : HEX.lt1);
      txt(s, r[i][1], { x: x + 0.9, y: 1.72, w: 1.8, h: 0.55, fontSize: 17, bold: true, color: r[i][5], valign: "middle" });
      txt(s, r[i][2], { x: x + 0.2, y: 2.45, w: 2.46, h: 0.8, fontSize: 13, bold: true, color: r[i][5] });
      txt(s, "Esempio: " + r[i][3], { x: x + 0.2, y: 3.3, w: 2.46, h: 0.75, fontSize: 12, color: r[i][5] });
    }
    s.addShape(pres.shapes.LINE, { x: 0.5, y: 1.3, w: 9.0, h: 0, line: { color: C.accent2, width: 2, endArrowType: "triangle" }, objectName: "autonomia" });
    txt(s, "Autonomia crescente", { x: 6.5, y: 1.05, w: 3.0, h: 0.25, fontSize: 11, bold: true, color: C.accent2, align: "right" });
    banner(s, 4.35, "Più autonomia diamo, più alta l'affidabilità dimostrata e più basse le conseguenze degli errori.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Quando limitare o evitare l'uso", "Possiamo ora indicare alcune situazioni in cui è opportuno limitare o evitare l'uso dell'AI, o riservarlo a un ruolo di supporto per persone competenti. Quando il compito richiede competenze specialistiche che chi usa lo strumento non possiede, e non è possibile coinvolgere un esperto: se non siamo in grado di valutare il risultato, non possiamo verificarlo. Quando le conseguenze di un errore sono gravi o irreversibili, e non esistono controlli adeguati. Quando il compito riguarda decisioni con effetti significativi sulle persone, come selezione, valutazione, accesso a servizi, salute e sicurezza, che richiedono giudizio umano, trasparenza e spesso garanzie specifiche previste dalla normativa. Quando non è possibile verificare il risultato, né sulla fonte né con una competenza adeguata. Quando servono informazioni aggiornate o interne che il sistema non ha e non può recuperare. Quando sono coinvolti dati riservati e lo strumento non è autorizzato a trattarli: un tema approfondito nel Tema 17. Infine, quando l'attività ha un valore proprio nel fatto di essere svolta da una persona: un messaggio personale di condoglianze, un colloquio delicato, un'attività formativa che serve a imparare.");
    const c = [["FiAward", "Servono competenze che non abbiamo", "e non possiamo coinvolgere un esperto"], ["FiAlertOctagon", "Conseguenze gravi o irreversibili", "senza controlli adeguati"], ["FiUsers", "Decisioni con effetti sulle persone", "selezione, valutazione, servizi, salute, sicurezza"], ["FiSearch", "Risultato non verificabile", "né su fonti né con competenza adeguata"], ["FiLock", "Dati riservati", "con strumenti non autorizzati"], ["FiHeart", "Il valore è nel contributo umano", "messaggi personali, colloqui delicati, apprendimento"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.2 + row * 1.25;
      shapeBox(s, x, y, 4.4, 1.1, C.background2, c[i][1]);
      await iconCircle(s, x + 0.18, y + 0.27, 0.56, c[i][0], i === 1 ? C.accent5 : C.accent1);
      txt(s, c[i][1], { x: x + 0.9, y: y + 0.12, w: 3.4, h: 0.45, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, c[i][2], { x: x + 0.9, y: y + 0.55, w: 3.4, h: 0.45, fontSize: 12, color: C.text2 });
    }
  }
  {
    const s = content("La responsabilità resta umana", "Concludiamo il sottotema, e il modulo, con il principio che li tiene insieme: la responsabilità delle decisioni e dei risultati resta alle persone. Un sistema AI non può essere responsabile di un errore: non risponde delle conseguenze, non può essere chiamato a giustificarsi, non ha obblighi professionali. Quando usiamo un risultato prodotto con l'AI, in un documento, in una comunicazione o in una decisione, ne diventiamo responsabili come se l'avessimo prodotto noi. 'L'ha scritto l'AI' non è una giustificazione, né verso un cliente, né verso l'azienda, né in sede legale, come mostra il caso degli avvocati di New York. Questo principio ha tre implicazioni pratiche. Primo: chi usa l'AI deve sapere che cosa sta usando, cioè conoscerne capacità e limiti: è lo scopo di questo modulo. Secondo: deve mettere in atto controlli proporzionati alle conseguenze. Terzo: deve sapere quando non usarla, o quando coinvolgere qualcun altro. Le regole organizzative, le responsabilità formali e la normativa, a partire dall'AI Act, sono affrontate nel Tema 18. Qui ci interessa la consapevolezza individuale: l'AI può fare molto del lavoro, ma la responsabilità del risultato non si delega.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.text1, "principio responsabilità");
    await iconCircle(s, 0.75, 1.45, 0.7, "FiUserCheck", C.accent1);
    txt(s, "Quando usiamo un risultato prodotto con l'AI, ne diventiamo responsabili come se l'avessimo prodotto noi.", { x: 0.75, y: 2.35, w: 3.85, h: 1.5, fontSize: 16, color: C.background1 });
    txt(s, "\"L'ha scritto l'AI\" non è una giustificazione.", { x: 0.75, y: 4.0, w: 3.85, h: 0.6, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tre implicazioni", { x: 5.15, y: 1.2, w: 4.35, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const im = [["1", "Conoscere capacità e limiti dello strumento"], ["2", "Controllare in modo proporzionato alle conseguenze"], ["3", "Sapere quando non usarlo o chi coinvolgere"]];
    im.forEach((e, i) => {
      const y = 1.7 + i * 1.08;
      shapeBox(s, 5.15, y, 4.35, 0.92, i === 1 ? C.accent6 : C.background2, "implicazione " + e[0]);
      txt(s, e[0], { x: 5.3, y, w: 0.5, h: 0.92, fontSize: 24, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 5.85, y, w: 3.5, h: 0.92, fontSize: 14, color: C.text1, valign: "middle" });
    });
  }
  keySlide("L'AI va utilizzata quando le sue prestazioni e i controlli disponibili sono compatibili con il rischio del compito, non soltanto quando il sistema sembra capace di eseguirlo.", "Sottotema 3.8  ·  Quando utilizzare o limitare l'AI", "Concetto chiave dell'ultimo sottotema. La possibilità tecnica non basta: conta l'opportunità, che dipende dalle conseguenze di un errore, cioè gravità, reversibilità, impatto su terzi e rilevabilità. L'affidabilità richiesta e i controlli necessari crescono con le conseguenze. L'AI può avere ruoli diversi, dal supporto alla delega, e più autonomia richiede più affidabilità dimostrata. Ci sono situazioni in cui conviene limitarne o evitarne l'uso. E in ogni caso la responsabilità del risultato resta umana. Domanda di verifica: pensate a un'attività del vostro lavoro in cui oggi non usereste l'AI. Perché? Che cosa dovrebbe cambiare, nello strumento o nei controlli, per renderla adatta?");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quali attività l'AI svolge efficacemente? Molte, tra linguaggio, contenuti, estrazione, analisi, multimodalità, supporto cognitivo e strumenti; la qualità dipende da sistema, compito, informazioni e modalità d'uso. Quali limiti ha il ragionamento? Ragionamenti convincenti possono contenere errori, e le situazioni nuove, ambigue o complesse aumentano il rischio. Perché una risposta convincente può essere falsa? Perché il modello genera testo plausibile, non verificato; la forma non dimostra la correttezza. Come emergono i bias? Da dati, addestramento e contesto, comprese le nostre domande, e dalla tendenza ad assecondare l'utente. In cosa differiscono accuratezza, affidabilità, consistenza e utilità? Sono dimensioni diverse che non coincidono. Quali controlli servono? Fatti, fonti, numeri, completezza e coerenza, in modo proporzionato. Perché lo stesso modello va bene in un compito e male in un altro? Per la frontiera frastagliata: le prestazioni dipendono dal compito. Quando l'errore richiede più supervisione o sconsiglia l'AI? Quando le conseguenze sono gravi, irreversibili, ricadono su terzi o non si possono controllare. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Che cosa sa fare bene?", "Molto; la qualità dipende da sistema, compito, informazioni"], ["Limiti del ragionamento?", "Errori intermedi; difficoltà su casi nuovi o ambigui"], ["Perché convincente ma falsa?", "Genera testo plausibile, non verificato"], ["Da dove vengono i bias?", "Dati, addestramento, contesto, compiacenza"], ["Accuratezza, affidabilità...?", "Dimensioni diverse, che non coincidono"], ["Quali controlli?", "Fatti, fonti, numeri, completezza, coerenza"], ["Bene in un compito, male in un altro?", "Frontiera frastagliata: dipende dal compito"], ["Quando più supervisione o evitare?", "Conseguenze gravi, irreversibili, non controllabili"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.95;
      shapeBox(s, x, y, 4.4, 0.85, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.08, w: 0.4, h: 0.4, fontSize: 18, bold: true, color: C.accent1 });
      txt(s, e[0], { x: x + 0.55, y: y + 0.08, w: 3.75, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.42, w: 3.75, h: 0.38, fontSize: 12, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo gli otto risultati attesi. Il partecipante dovrebbe essere in grado di: riconoscere le principali capacità dei sistemi AI e associarle a tipologie di attività; comprendere perché un sistema possa produrre risposte plausibili ma errate; identificare possibili bias e distorsioni; distinguere la qualità espressiva di una risposta dalla sua correttezza; comprendere che l'affidabilità dipende da modello, compito e contesto; riconoscere quando verificare le informazioni con fonti indipendenti o controlli appropriati; valutare se il livello di affidabilità è compatibile con le conseguenze di un errore; distinguere i compiti supportabili dall'AI da quelli che richiedono maggiore controllo o competenze specialistiche. Insieme, questi risultati compongono la capacità che abbiamo chiamato calibrare la fiducia.");
    const r = [["FiGrid", "Associare le capacità dell'AI a tipologie di attività"], ["FiAlertCircle", "Capire perché una risposta plausibile può essere errata"], ["FiEye", "Identificare possibili bias e distorsioni"], ["FiType", "Distinguere qualità espressiva e correttezza"], ["FiLayers", "Capire che l'affidabilità dipende da modello, compito e contesto"], ["FiCheckSquare", "Riconoscere quando e come verificare"], ["FiSliders", "Valutare l'affidabilità rispetto alle conseguenze di un errore"], ["FiUserCheck", "Distinguere compiti supportabili da quelli che richiedono più controllo"]];
    for (let i = 0; i < 8; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.95;
      shapeBox(s, x, y, 4.4, 0.82, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      await iconCircle(s, x + 0.15, y + 0.17, 0.48, r[i][0]);
      txt(s, r[i][1], { x: x + 0.78, y, w: 3.5, h: 0.82, fontSize: 13, color: C.text1, valign: "middle" });
    }
  }
  {
    const s = content("Prima di usare un risultato AI: una checklist", "Questa slide traduce il modulo in una checklist operativa, da distribuire ai partecipanti o da appendere vicino alla scrivania. Sei domande da porsi prima di usare un risultato prodotto con l'AI. Il compito è adatto all'AI e allo strumento che ho usato? Le conseguenze di un errore sono basse, o ho previsto controlli adeguati? Ho verificato fatti, numeri e fonti importanti? Ho controllato che non manchi nulla di rilevante e che non ci siano contraddizioni? La risposta potrebbe essere sbilanciata, per come ho posto la domanda o per i limiti del sistema? Sono in grado di valutare questo risultato, e sono pronto ad assumermene la responsabilità? Se la risposta a una di queste domande è no, serve un controllo in più, il coinvolgimento di un collega competente, oppure la scelta di non usare quel risultato.");
    const q = [["FiTarget", "Il compito è adatto all'AI e a questo strumento?"], ["FiAlertTriangle", "Le conseguenze di un errore sono basse, o ho previsto controlli adeguati?"], ["FiCheckCircle", "Ho verificato fatti, numeri e fonti importanti?"], ["FiList", "Manca qualcosa? Ci sono contraddizioni?"], ["FiSliders", "La risposta potrebbe essere sbilanciata?"], ["FiUserCheck", "So valutare il risultato e me ne assumo la responsabilità?"]];
    for (let i = 0; i < 6; i++) {
      const y = 1.15 + i * 0.6;
      shapeBox(s, 0.5, y, 9.0, 0.52, i % 2 ? C.background1 : C.background2, "check " + (i + 1));
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.65, y: y + 0.11, w: 0.3, h: 0.3, rectRadius: 0.05, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 }, objectName: "casella" });
      await iconCircle(s, 1.1, y + 0.06, 0.4, q[i][0]);
      txt(s, q[i][1], { x: 1.65, y, w: 7.7, h: 0.52, fontSize: 14, color: C.text1, valign: "middle" });
    }
    txt(s, "Se una risposta è no: un controllo in più, un collega competente, o non usare quel risultato.", { x: 0.5, y: 4.85, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei semplificazioni da evitare. Le prime cinque spingono verso la fiducia eccessiva, l'ultima verso la sfiducia totale: sono i due estremi della scala vista all'inizio. Primo: 'ha mostrato i passaggi, quindi è corretto'. Un ragionamento ben presentato può contenere un errore intermedio; i passaggi servono proprio a cercarlo. Secondo: 'è scritto bene, quindi è vero'. Le risposte sbagliate sono scritte bene quanto quelle giuste. Terzo: 'il tono è neutro, quindi è imparziale'. Le scelte su che cosa includere e come presentarlo non sono neutre. Quarto: 'è il migliore nei test comparativi, quindi va bene per noi'. Benchmark e dimostrazioni sono indizi; conta la prova sui nostri casi. Quinto: 'gli ho chiesto se è sicuro e ha confermato'. L'autoverifica non è una verifica indipendente, come mostra il caso Avianca. Sesto, all'estremo opposto: 'sbaglia, quindi è meglio non usarla'. Anche le persone sbagliano: la domanda giusta è se l'affidabilità e i controlli sono adeguati alle conseguenze di un errore. Suggerimento: chiedere ai partecipanti quale di queste frasi hanno sentito più spesso in azienda.");
    const a = [["FiList", "\"Ha mostrato i passaggi, quindi è corretto\"", "I passaggi servono a cercare l'errore", "3.2"], ["FiFeather", "\"È scritto bene, quindi è vero\"", "La forma non dimostra la correttezza", "3.3"], ["FiMinus", "\"Il tono è neutro, quindi è imparziale\"", "Che cosa include e come lo presenta", "3.4"], ["FiAward", "\"È il migliore nei test, quindi va bene per noi\"", "Conta la prova sui nostri casi", "3.5"], ["FiHelpCircle", "\"Gli ho chiesto se è sicuro: ha confermato\"", "L'autoverifica non è indipendente", "3.6"], ["FiXCircle", "\"Sbaglia, quindi è meglio non usarla\"", "Affidabilità adeguata allo scopo", "3.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Prossimo passo: il Tema 4", "Con questo modulo si conclude l'area 'Comprendere l'AI'. Abbiamo visto perché l'AI è rilevante, come funziona e quanto possiamo fidarci dei suoi risultati. Il prossimo tema, dedicato all'ecosistema dell'AI, guarderà al panorama concreto di prodotti, piattaforme e modelli. I concetti di questo modulo saranno essenziali per orientarsi: sapere che le capacità dipendono dal sistema e non solo dal modello, che l'affidabilità va valutata sul proprio compito e che benchmark e dimostrazioni non bastano permetterà di leggere con spirito critico le proposte e i confronti tra strumenti. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.background2, "tema 3");
    txt(s, "TEMA 3", { x: 0.75, y: 1.4, w: 3.1, h: 0.35, fontSize: 13, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Capacità, limiti e affidabilità", { x: 0.75, y: 1.8, w: 3.1, h: 0.7, fontSize: 18, bold: true, color: C.text1 });
    txt(s, bullets(["Che cosa sa fare l'AI", "Allucinazioni e bias", "Valutare e verificare", "Quando usarla o limitarla"], { space: 4 }), { x: 0.75, y: 2.6, w: 3.1, h: 2.1, fontSize: 14, color: C.text2 });
    arrow(s, 4.25, 2.9, 0.55, C.accent1);
    shapeBox(s, 4.95, 1.2, 4.55, 3.75, C.text1, "tema 4");
    txt(s, "TEMA 4", { x: 5.2, y: 1.4, w: 4.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Ecosistema AI", { x: 5.2, y: 1.8, w: 4.1, h: 0.5, fontSize: 18, bold: true, color: C.background1 });
    txt(s, bullets(["Prodotti e piattaforme", "Modelli disponibili", "Come leggere confronti e proposte"], { space: 3 }), { x: 5.2, y: 2.45, w: 4.1, h: 2.3, fontSize: 14, color: C.accent3 });
  }
  {
    const s = content("Fonti e riferimenti", "Questa slide raccoglie le principali fonti citate nel modulo. Le capacità dei sistemi e la frequenza di errori come le allucinazioni cambiano rapidamente con le nuove versioni: prima di ogni edizione del corso è consigliabile verificare se ci sono evidenze o casi più recenti da citare. Le fonti sono state verificate a ottobre 2026; per Sharma e Dell'Acqua sono indicate le versioni pubblicate.");
    const src = [
      "Mata v. Avianca, Inc., U.S. District Court, Southern District of New York, giugno 2023.",
      "Kalai, A. T. et al. (2025). Why Language Models Hallucinate. OpenAI, arXiv:2509.04664.",
      "Sharma, M. et al. (2024). Towards Understanding Sycophancy in Language Models. ICLR 2024 (Anthropic).",
      "Dastin, J. (2018). Amazon scraps secret AI recruiting tool that showed bias against women. Reuters.",
      "Doshi, A. R., Hauser, O. P. (2024). Generative AI enhances individual creativity but reduces the collective diversity of novel content. Science Advances, 10(28).",
      "Dell'Acqua, F. et al. (2026). Navigating the Jagged Technological Frontier. Organization Science, 37(2), 403-423.",
      "Parasuraman, R., Manzey, D. H. (2010). Complacency and Bias in Human Use of Automation: An Attentional Integration. Human Factors, 52(3).",
      "Regolamento (UE) 2024/1689 sull'intelligenza artificiale (AI Act).",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 5 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.45, fontSize: 12, color: C.text1 });
    txt(s, "Dati verificati a ottobre 2026: ricontrollarli prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema3_Capacita_limiti_affidabilita_AI.pptx" });
  await applyTheme("Tema3_Capacita_limiti_affidabilita_AI.pptx", THEME);
  console.log("done");
})();
