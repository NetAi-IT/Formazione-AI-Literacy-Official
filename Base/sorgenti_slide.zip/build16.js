const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 16: Adozione dell'AI e cambiamento organizzativo";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 16  ·  Adozione e cambiamento organizzativo";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5, X = o.x || 0.5, W = o.w || 9.0;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, X, y, W, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: X + 0.15, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: X + 0.15 + lw, y, w: W - 0.3 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }
  function adTag(s, active) {
    const st = ["Adozione", "Persone", "Competenze", "Diffusione", "Risultati"];
    st.forEach((t, i) => {
      const x = 6.1 + i * 0.68;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.66, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "dimensione " + t });
      txt(s, t, { x, y: 0.42, w: 0.66, h: 0.26, fontSize: 6.5, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 16", { placeholder: "kicker" });
    s.addText("Adozione dell'AI e cambiamento organizzativo", { placeholder: "title" });
    s.addText("Area: Comprendere il valore per l'azienda", { placeholder: "sub" });
    s.addNotes("Benvenuti al sedicesimo tema, l'ultimo dell'area 'Comprendere il valore per l'azienda'. Nel Tema 15 abbiamo visto come scegliere dove ha senso usare l'AI e come verificarlo. Ora ci chiediamo come sostenere l'utilizzo, l'apprendimento e la diffusione delle iniziative scelte: come si passa da uno strumento disponibile a un uso efficace e duraturo nel lavoro delle persone. È un tema in cui molte organizzazioni scoprono una sorpresa: hanno acquistato licenze, fatto una presentazione, magari un corso, e dopo qualche mese l'uso è basso, irregolare, o concentrato su poche persone. Oppure, al contrario, le persone usano strumenti non approvati, per conto proprio. Il modulo dà strumenti per capire perché accade e che cosa si può fare. Due confini. Con il Tema 13: lì abbiamo visto che cosa cambia nel lavoro; qui come sostenere e accompagnare il cambiamento. Con i Temi 17 e 18: parliamo di strumenti consentiti e di supporto, ma non di normative, sicurezza e governance formale. Vale una nota particolare: questo stesso percorso di formazione è parte di un processo di adozione, e molte cose che diremo riguardano anche noi. Suggerimento per l'apertura: chiedere ai partecipanti di indicare uno strumento digitale introdotto in azienda negli ultimi anni che è stato davvero adottato, e uno che non lo è stato, e perché.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere i principali fattori tecnologici, umani e organizzativi che influenzano l'adozione dell'AI, riconoscendo il ruolo della leadership, delle competenze, della partecipazione, del supporto operativo, della sperimentazione e del miglioramento continuo. La consapevolezza da sviluppare: mettere a disposizione uno strumento AI non significa che verrà adottato efficacemente. L'adozione richiede che le persone ne comprendano l'utilità, abbiano le competenze e le condizioni operative necessarie, e possano integrarlo in modo appropriato nel proprio lavoro. Tre condizioni: comprensione dell'utilità, competenze e condizioni operative, integrazione appropriata. Il messaggio chiave del documento di perimetro: l'adozione efficace dell'AI non dipende dalla sola disponibilità degli strumenti, ma dalla loro utilità concreta, dalle competenze delle persone, dal supporto organizzativo, dalla partecipazione e dalla capacità di apprendere dai risultati. Diffondere l'AI non è un obiettivo sufficiente: conta integrarla nel lavoro quando genera benefici reali e sostenibili.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Comprendere i fattori tecnologici, umani e organizzativi dell'adozione", "Riconoscere il ruolo di leadership, competenze, partecipazione, supporto, sperimentazione, miglioramento continuo"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Uno strumento disponibile non è uno strumento adottato.\n\nServono utilità compresa, competenze e condizioni operative, integrazione appropriata nel lavoro." });
  }
  {
    const s = content("Dalla disponibilità al valore", "Il documento di perimetro propone una sequenza concettuale che useremo per tutto il modulo: disponibilità dello strumento, capacità di usarlo, applicazione nel lavoro, adozione sostenibile, risultati osservabili. Cinque livelli collegati, ma il passaggio dall'uno all'altro non è automatico, né necessariamente lineare. La disponibilità: lo strumento c'è, le licenze sono attive. La capacità: le persone sanno usarlo. L'applicazione: lo usano davvero nel lavoro, su attività reali. L'adozione sostenibile: l'uso è diventato parte delle pratiche, continua nel tempo, è supportato. I risultati: l'uso produce benefici osservabili. Molte iniziative misurano il primo livello, e ne deducono gli altri. Un'osservazione importante, che è la prima precisazione del tema: una bassa adozione può essere razionale quando l'applicazione non è utile o adeguata. L'adozione non è sempre desiderabile: se uno strumento non risponde a un bisogno, non usarlo può essere la decisione corretta. Il modulo non insegna a far usare l'AI a tutti i costi, ma a creare le condizioni perché venga usata dove serve, e bene.");
    const l = [["Disponibilità", "Lo strumento c'è"], ["Capacità", "Le persone sanno usarlo"], ["Applicazione", "Lo usano nel lavoro reale"], ["Adozione sostenibile", "Parte delle pratiche, nel tempo"], ["Risultati", "Benefici osservabili"]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 1.84, dark = i === 4;
      shapeBox(s, x, 1.15, 1.62, 1.6, dark ? C.accent1 : (i % 2 ? C.accent6 : C.background2), e[0]);
      txt(s, String(i + 1), { x: x + 0.1, y: 1.2, w: 0.5, h: 0.42, fontSize: 18, bold: true, color: dark ? C.accent6 : C.accent1 });
      txt(s, e[0], { x: x + 0.1, y: 1.62, w: 1.45, h: 0.5, fontSize: 13, bold: true, color: dark ? C.background1 : C.text1 });
      txt(s, e[1], { x: x + 0.1, y: 2.12, w: 1.45, h: 0.55, fontSize: 11, color: dark ? C.background1 : C.text2 });
      if (i < 4) arrow(s, x + 1.63, 1.8, 0.19);
    });
    txt(s, "Collegati, ma il passaggio non è automatico né necessariamente lineare", { x: 0.5, y: 2.85, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2, align: "center" });
    banner(s, 3.35, "L'adozione non è sempre desiderabile: se lo strumento non risponde a un bisogno, non usarlo può essere la decisione corretta.", { h: 0.85, fontSize: 14 });
    txt(s, "Non far usare l'AI a tutti i costi, ma creare le condizioni perché venga usata dove serve, e bene.", { x: 0.5, y: 4.35, w: 9, h: 0.5, fontSize: 13, bold: true, color: C.accent1, align: "center" });
  }
  {
    const s = content("Otto domande guida", "Le otto domande guida accompagnano il modulo. Quando possiamo dire che un'organizzazione ha realmente adottato l'AI. Perché la disponibilità di uno strumento non ne garantisce l'uso. Quali ostacoli dipendono dalle persone e quali dalle condizioni organizzative. Quali responsabilità hanno leadership, manager e collaboratori. Perché la formazione iniziale non basta a produrre cambiamenti nel lavoro: una domanda che riguarda direttamente anche questo percorso. Come sostenere fiducia informata, sperimentazione e partecipazione. Quali forme di supporto e coordinamento favoriscono l'adozione. Come capire se l'uso è efficace e sostenibile nel tempo. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Quando un'organizzazione ha davvero adottato l'AI?", "Perché lo strumento disponibile non basta?", "Ostacoli delle persone o delle condizioni?", "Responsabilità di leadership, manager, collaboratori?", "Perché la formazione iniziale non basta?", "Come sostenere fiducia, sperimentazione, partecipazione?", "Quale supporto e coordinamento?", "L'uso è efficace e sostenibile?"], 4, 1.12, 1.5, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in cinque dimensioni. Significato e condizioni dell'adozione, nei sottotemi 16.1 e 16.2. Persone, leadership e partecipazione, nel 16.3 e 16.6. Competenze e apprendimento, nel 16.4. Sperimentazione, supporto e coordinamento, nel 16.5 e 16.7. Consolidamento, risultati e sostenibilità, nel 16.8. Le slide useranno un indicatore in alto a destra con cinque etichette brevi: Adozione, Persone, Competenze, Diffusione, Risultati. Quattro integrazioni attraversano il modulo, come concetti trasversali. A: il problema dello Shadow AI, cioè l'uso di servizi non approvati. B: la resistenza può essere un'informazione utile. C: la formazione da sola non produce adozione. D: diffondere rapidamente non significa adottare efficacemente. E tre precisazioni da mantenere: l'adozione non è sempre desiderabile; le esigenze formative sono differenziate; l'adozione dal basso non coincide con lo Shadow AI.");
    const d = [["FiCompass", "Adozione", "16.1  16.2"], ["FiUsers", "Persone", "16.3  16.6"], ["FiBookOpen", "Competenze", "16.4"], ["FiShare2", "Diffusione e supporto", "16.5  16.7"], ["FiTrendingUp", "Risultati", "16.8"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84, dark = i === 4;
      shapeBox(s, x, 1.15, 1.68, 1.65, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.54, 1.25, 0.6, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.08, y: 1.9, w: 1.52, h: 0.42, fontSize: 12, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.08, y: 2.35, w: 1.52, h: 0.33, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
    }
    txt(s, "Quattro integrazioni", { x: 0.5, y: 2.92, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const p = ["A  Il problema dello Shadow AI", "B  La resistenza può essere un'informazione utile", "C  La formazione da sola non produce adozione", "D  Diffondere rapidamente non è adottare efficacemente"];
    p.forEach((t, i) => chip(s, 0.5 + (i % 2) * 4.6, 3.27 + Math.floor(i / 2) * 0.55, 4.4, 0.47, t, { fill: C.accent6, fontSize: 12 }));
    txt(s, "Precisazioni: l'adozione non è sempre desiderabile  ·  esigenze formative differenziate  ·  adozione dal basso non è Shadow AI", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, il supporto e coordinamento, con priorità media. Maggiore attenzione didattica su quattro: fattori e ostacoli, competenze e formazione, sperimentazione e diffusione, monitoraggio e sostenibilità. Da comprendere e applicare: la distinzione tra disponibilità, uso, adozione e valore; il riconoscimento delle barriere; il rapporto tra formazione e pratica; la differenza tra diffusione e risultati. Da conoscere: i referenti di supporto, la diffusione graduale, la differenziazione della formazione, la raccolta di feedback. Da solo accennare: modelli specialistici di change management, centri di eccellenza AI, programmi complessi di implementazione, sistemi avanzati di misurazione. Confini: non ripetiamo le tecniche di interazione del Tema 5, i metodi di verifica del Tema 7, il funzionamento degli strumenti del Tema 11, la classificazione dei benefici del Tema 12, l'analisi dei cambiamenti del lavoro del Tema 13, i prerequisiti informativi del Tema 14, la scelta dei casi d'uso del Tema 15. E non anticipiamo privacy, sicurezza, norme e governance, dei Temi 17 e 18.");
    pathSlide(s, [["16.1", "Che cosa significa adottare", "Alta"], ["16.2", "Fattori e ostacoli", "Alta"], ["16.3", "Leadership e management", "Alta"], ["16.4", "Competenze e formazione", "Alta"], ["16.5", "Sperimentazione e diffusione", "Alta"], ["16.6", "Cultura, fiducia, partecipazione", "Alta"], ["16.7", "Supporto e coordinamento", "Media"], ["16.8", "Monitoraggio e sostenibilità", "Alta"]],
      [["Comprendere e applicare", "Disponibilità, uso, adozione, valore; barriere; formazione e pratica; diffusione e risultati", C.accent1, C.background1], ["Conoscere", "Referenti, diffusione graduale, formazione differenziata, feedback", C.accent6, C.text1], ["Solo accennare", "Change management specialistico, centri di eccellenza, misurazione avanzata", C.background2, C.text1]]);
  }
  {
    const s = content("Lo scenario del modulo", "Il documento di perimetro propone un esempio che useremo come filo rosso: un'azienda introduce un assistente AI per preparare documenti commerciali, come offerte, presentazioni e risposte ai clienti. Lo stesso strumento può essere introdotto in due modi molto diversi. Nello scenario A, centrato sullo strumento: si distribuiscono le licenze; la formazione è una dimostrazione delle funzionalità; il supporto è lasciato all'iniziativa individuale; si osserva il numero di accessi; si estende subito a tutti. Nello scenario B, centrato sul lavoro: si individuano attività concrete su cui sperimentare; la formazione usa esempi operativi pertinenti; ci sono referenti e confronto tra colleghi; si osservano uso, qualità, problemi e risultati; si estende dopo le prime verifiche. La lettura che il documento chiede di dare è precisa: lo scenario B contiene più condizioni favorevoli all'apprendimento e al controllo, ma non garantisce risultati migliori in ogni contesto. L'esempio illustra la differenza tra distribuire una tecnologia e creare le condizioni per usarla efficacemente. Torneremo sui due scenari in ogni sottotema. Esempio fittizio, come gli altri del modulo.");
    table(s, [["", "A: centrato sullo strumento", "B: centrato sul lavoro"],
      ["Introduzione", "Distribuzione di licenze", "Attività concrete su cui sperimentare"],
      ["Formazione", "Dimostrazione delle funzionalità", "Esempi operativi pertinenti"],
      ["Supporto", "Iniziativa individuale", "Referenti e confronto tra colleghi"],
      ["Osservazione", "Numero di accessi", "Uso, qualità, problemi, risultati"],
      ["Diffusione", "Estensione immediata", "Estensione dopo prime verifiche"]],
      { y: 1.15, colW: [1.8, 3.4, 3.8], rowH: 0.45, accentCol: 2, fontSize: 12 });
    banner(s, 4.0, "B ha più condizioni favorevoli, ma non garantisce risultati migliori ovunque. Distribuire una tecnologia non è creare le condizioni per usarla.", { h: 0.85, fontSize: 13 });
  }

  // =====================================================================
  section("16.1 Che cosa significa adottare");
  divider("16.1", "Che cosa significa adottare", "Acquistare licenze e registrare accessi non equivale ad adottare efficacemente l'AI", "Primo sottotema, da comprendere bene. Prima di parlare di come favorire l'adozione, chiariamo che cosa intendiamo con questa parola. Vediamo la differenza tra disponibilità, uso occasionale e adozione effettiva; i livelli individuale, di team e organizzativo; uso sperimentale e integrazione nelle pratiche; diffusione spontanea e introduzione coordinata; utenti, qualità d'uso e impatto; l'adozione come percorso; e il fenomeno dello Shadow AI, integrazione A, distinto dalla sperimentazione autorizzata.");
  {
    const s = content("Disponibile, usato, adottato", "La prima domanda guida: quando possiamo dire che un'organizzazione ha realmente adottato l'AI? Il sottotema parte da tre situazioni diverse. La disponibilità tecnologica: lo strumento è accessibile, le licenze sono attive, le persone hanno ricevuto l'accesso. Non dice nulla sull'uso. L'uso occasionale: alcune persone lo provano, lo usano di tanto in tanto, per curiosità o per compiti isolati. È un primo segnale, ma spesso resta tale: dopo le prime prove, l'uso cala. L'adozione effettiva: lo strumento è entrato nel modo di lavorare, viene usato in modo regolare e appropriato per attività in cui è utile, le persone sanno quando usarlo e quando no. Il sottotema chiede anche di distinguere tra distribuire licenze e sviluppare capacità operative: le prime si comprano, le seconde si costruiscono nel tempo. Una formula semplice per ricordarlo: l'adozione non si misura da quante persone possono usare lo strumento, né da quante lo hanno usato una volta, ma da quante lo usano bene, quando serve. È la consapevolezza del sottotema: acquistare licenze e registrare accessi non equivale ad adottare efficacemente l'AI; conta l'integrazione appropriata nel lavoro.");
    adTag(s, 0);
    const l = [["FiUnlock", "Disponibilità", "Accessi e licenze attivi", "Non dice nulla sull'uso"], ["FiMousePointer", "Uso occasionale", "Prove, compiti isolati", "Un segnale che spesso cala"], ["FiCheckCircle", "Adozione effettiva", "Uso regolare e appropriato", "Si sa quando usarlo, e quando no"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.4, i === 2 ? C.accent6 : C.background2, l[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.66, l[i][0]);
      txt(s, l[i][1], { x: x + 0.15, y: 2.0, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, l[i][2], { x: x + 0.15, y: 2.42, w: 2.56, h: 0.4, fontSize: 12, bold: true, color: C.accent1, align: "center" });
      txt(s, l[i][3], { x: x + 0.15, y: 2.85, w: 2.56, h: 0.6, fontSize: 12, color: C.text2, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.2, 0.17);
    }
    banner(s, 3.8, "Non quante persone possono usarlo, né quante l'hanno usato una volta, ma quante lo usano bene, quando serve.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Individuale, team, organizzazione", "Il sottotema distingue tre livelli di adozione. Individuale: una persona integra lo strumento nel proprio modo di lavorare. È il livello più rapido, ma anche il più fragile: dipende dalla motivazione e dalle competenze di quella persona, e i benefici restano spesso suoi. Di team: un gruppo condivide come usare lo strumento, con pratiche comuni, esempi condivisi, attese chiare su che cosa si fa con l'AI e che cosa no. I benefici diventano più stabili, e chi entra nel gruppo impara dagli altri. Organizzativo: l'uso è integrato nei processi, supportato da indicazioni, strumenti e riferimenti comuni, e coerente tra funzioni diverse. Qui l'AI diventa parte del modo di funzionare dell'organizzazione, non solo di alcune persone. I tre livelli non sono una scala obbligata: si può avere molta adozione individuale e poca organizzativa, ed è una situazione frequente. In quel caso i benefici sono reali ma dispersi, difficili da vedere e da replicare, e dipendono da chi c'è. Un'indicazione pratica: quando qualcuno usa bene uno strumento, la domanda utile è come quella pratica può diventare del team.");
    adTag(s, 0);
    const l = [["Individuale", "Una persona integra lo strumento nel suo lavoro", "Rapida, ma fragile: dipende dalla persona"], ["Di team", "Pratiche comuni, esempi condivisi, attese chiare", "Più stabile: chi entra impara dagli altri"], ["Organizzativa", "Integrata nei processi, con riferimenti comuni", "Parte del modo di funzionare"]];
    l.forEach((e, i) => {
      const y = 1.15 + i * 0.85, w = 6.4 + i * 1.3;
      shapeBox(s, 0.5, y, w, 0.75, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: 0.65, y, w: 1.7, h: 0.75, fontSize: 15, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.35, y: y + 0.05, w: w - 2.0, h: 0.33, fontSize: 12, bold: true, color: i === 2 ? C.background1 : C.text1 });
      txt(s, e[2], { x: 2.35, y: y + 0.38, w: w - 2.0, h: 0.33, fontSize: 11, italic: true, color: i === 2 ? C.accent6 : C.text2 });
    });
    banner(s, 3.85, "Molta adozione individuale e poca organizzativa: benefici reali ma dispersi. Come può una buona pratica diventare del team?", { h: 0.95, fontSize: 14 });
  }
  {
    const s = content("Spontanea o coordinata", "Due coppie di distinzioni del sottotema. La prima: uso sperimentale e integrazione nelle pratiche di lavoro. L'uso sperimentale è esplorativo: si prova, si vede che cosa succede, si impara. È una fase necessaria, ma non è ancora adozione. L'integrazione nelle pratiche significa che l'uso è diventato abituale, stabile, con modi condivisi. La seconda: diffusione spontanea e introduzione coordinata. La diffusione spontanea parte dalle persone: qualcuno scopre uno strumento, lo usa, ne parla ai colleghi. È rapida e spesso molto efficace nel trovare usi utili, perché nasce da bisogni reali. Ma è disomogenea, difficile da supportare, e può produrre pratiche incoerenti o rischiose. L'introduzione coordinata parte dall'organizzazione: si sceglie lo strumento, si definiscono gli usi, si forma, si supporta. È più ordinata e controllabile, ma più lenta, e rischia di non intercettare i bisogni reali se non ascolta chi lavora. Il sottotema osserva che l'uso spontaneo spesso precede le iniziative ufficiali: quando l'azienda decide di introdurre l'AI, molte persone la usano già. È un dato di cui tenere conto, e su cui torneremo con lo Shadow AI.");
    adTag(s, 0);
    await twoPanel(s, "Diffusione spontanea", bullets(["Parte dalle persone, da bisogni reali", "Rapida, trova usi utili", "Disomogenea, difficile da supportare, a volte rischiosa"], { space: 5 }), "Introduzione coordinata", bullets(["Parte dall'organizzazione", "Ordinata e controllabile", "Più lenta; rischia di non intercettare i bisogni"], { space: 5 }), { y: 1.15, h: 2.5, li: "FiZap", ri: "FiLayers" });
    banner(s, 3.85, "L'uso spontaneo spesso precede le iniziative ufficiali: quando l'azienda decide, molte persone usano già l'AI.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Utenti, qualità, impatto", "Una distinzione del sottotema che anticipa il 16.8: numero di utenti, qualità d'uso e impatto sono tre cose diverse. Il numero di utenti dice quante persone usano lo strumento. È facile da misurare, ed è per questo il dato più citato. La qualità d'uso dice come lo usano: per quali attività, con quali risultati, con quale verifica, in modo appropriato o no. È molto più difficile da osservare. L'impatto dice che cosa cambia nel lavoro e nei risultati: tempo, qualità, servizio, come visto nel Tema 12. Le tre grandezze possono andare in direzioni diverse. Molti utenti con un uso superficiale, per esempio per riformulare email, possono produrre un impatto modesto. Pochi utenti con un uso intenso e appropriato su attività importanti possono produrne uno grande. E un uso inappropriato, per esempio senza verifica su attività delicate, può produrre un impatto negativo. Il grafico, con dati inventati, mostra due reparti di un'azienda fittizia: uno con molti utenti e basso impatto, l'altro con meno utenti e impatto maggiore. Guardare solo il primo indicatore porterebbe a conclusioni opposte alla realtà.");
    adTag(s, 0);
    s.addChart(pres.charts.BAR, [
      { name: "Reparto Alfa", labels: ["Utenti attivi, %", "Uso su attività rilevanti, %", "Impatto stimato, indice"], values: [85, 20, 25] },
      { name: "Reparto Beta", labels: ["Utenti attivi, %", "Uso su attività rilevanti, %", "Impatto stimato, indice"], values: [40, 70, 60] },
    ], { x: 0.5, y: 1.05, w: 5.6, h: 3.4, barDir: "col", barGrouping: "clustered", chartColors: [HEX.a4, HEX.a1],
      showValue: true, dataLabelColor: HEX.dk1, dataLabelFontSize: 11, dataLabelFontFace: "+mn-lt", dataLabelPosition: "outEnd",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 10, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 100, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Due reparti di un'azienda fittizia (dati inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50 });
    rowsLabel(s, [["Utenti", "Quanti: facile da misurare"], ["Qualità d'uso", "Come: difficile da osservare"], ["Impatto", "Che cosa cambia (Tema 12)"]], { y: 1.15, h: 0.72, lw: 1.3, x: 6.35, w: 3.15, fontSize: 11 });
    txt(s, "Guardare solo gli utenti porterebbe a conclusioni opposte.", { x: 6.35, y: 3.6, w: 3.15, h: 0.8, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Un percorso, non un evento", "Il sottotema chiede di considerare l'adozione come un percorso progressivo e non come un evento puntuale, e di vedere il rapporto tra adozione, cambiamento delle abitudini e risultati. Nelle organizzazioni si tende a trattare l'introduzione di uno strumento come un evento: c'è una data di lancio, una presentazione, un'email, una formazione. Dopo l'evento, si considera il lavoro fatto. Ma cambiare il modo di lavorare richiede tempo: provare, sbagliare, capire dove serve e dove no, costruire nuove abitudini, abbandonare quelle vecchie. Gli studi sulla diffusione delle innovazioni, a partire da quelli classici di Everett Rogers, mostrano che l'adozione di una novità segue tipicamente un andamento a S: lenta all'inizio, poi più rapida, poi stabile, e che gruppi diversi la adottano in momenti diversi. Il grafico, con dati inventati, mostra un andamento tipico e, accanto, l'andamento che si osserva spesso negli strumenti introdotti come evento: un picco iniziale di curiosità, seguito da un calo, perché l'uso non si è trasformato in abitudine. I risultati, infine, arrivano dopo le abitudini: chi si aspetta risultati subito dopo il lancio rischia di giudicare troppo presto.");
    adTag(s, 0);
    const lb = ["M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "M11", "M12"];
    lineChart(s, lb, [
      { name: "Percorso sostenuto", values: [5, 8, 12, 18, 26, 35, 44, 51, 56, 59, 61, 62], color: HEX.a1 },
      { name: "Lancio come evento", values: [30, 38, 32, 25, 20, 17, 15, 14, 13, 13, 12, 12], color: HEX.a5 },
    ], { x: 0.5, y: 1.05, w: 5.6, h: 3.4, min: 0, max: 70, legend: true, title: "Utenti abituali, % (dati inventati)" });
    await card(s, 6.35, 1.15, 3.15, 1.6, { icon: "FiTrendingUp", inline: true, head: "Andamento a S", headSize: 13, bodySize: 12, body: "Lento, poi rapido, poi stabile (Rogers)." });
    await card(s, 6.35, 2.9, 3.15, 1.6, { icon: "FiClock", inline: true, head: "Risultati dopo le abitudini", headSize: 13, bodySize: 12, fill: C.accent6, body: "Giudicare subito dopo il lancio è giudicare troppo presto." });
  }
  {
    const s = content("Lo Shadow AI", "L'integrazione A del tema: il problema dello Shadow AI. Il termine riprende quello di Shadow IT, usato da anni per indicare l'uso di applicazioni e servizi informatici non approvati dall'organizzazione. Lo Shadow AI è l'uso di strumenti di AI non approvati per scopi di lavoro: per esempio un collaboratore che usa un servizio gratuito, con un account personale, per riassumere documenti aziendali o scrivere offerte. Il fenomeno è diffuso: alcune indagini di settore pubblicate nel 2024, come il Work Trend Index di Microsoft e LinkedIn, riportavano che una larga parte dei lavoratori che usano l'AI porta i propri strumenti al lavoro, senza attendere quelli aziendali; i numeri precisi vanno verificati e variano molto tra le indagini. Il documento chiede di leggere il fenomeno in due modi insieme. Da un lato, lo Shadow AI può indicare bisogni operativi non soddisfatti: le persone hanno trovato uno strumento utile, e l'organizzazione non offre un'alternativa adeguata. Dall'altro, introduce rischi: informazioni aziendali inserite in servizi esterni senza garanzie, risultati non verificati, pratiche non visibili. Gli aspetti di sicurezza e conformità sono dei Temi 17 e 18: qui lo esaminiamo come fenomeno di adozione.");
    adTag(s, 0);
    docBox(s, 0.5, 1.15, 9.0, 0.85, "Che cos'è (esempio fittizio)", "Un collaboratore usa un servizio gratuito, con un account personale, per riassumere documenti aziendali o scrivere offerte.", { fontSize: 13, fill: C.accent6 });
    await twoPanel(s, "Un segnale", "Bisogni operativi non soddisfatti: le persone hanno trovato qualcosa di utile, e l'organizzazione non offre un'alternativa adeguata.", "Un rischio", "Informazioni aziendali in servizi esterni senza garanzie, risultati non verificati, pratiche invisibili (Temi 17 e 18).", { y: 2.15, h: 2.0, li: "FiRadio", ri: "FiAlertTriangle" });
    txt(s, "Indagini di settore 2024 (es. Work Trend Index): molti portano i propri strumenti al lavoro. Numeri da verificare.", { x: 0.5, y: 4.3, w: 9, h: 0.5, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Dal basso non è Shadow AI", "Una precisazione che il documento chiede di mantenere con cura: l'adozione dal basso non coincide con lo Shadow AI, e lo Shadow AI non è sinonimo di ogni iniziativa spontanea. Il sottotema distingue tra sperimentazione autorizzata e uso non approvato. La sperimentazione autorizzata, o adozione dal basso, è positiva: le persone esplorano, con strumenti consentiti, nuovi modi di usare l'AI nel proprio lavoro, e trovano usi che nessuno aveva previsto. Molte delle pratiche migliori nascono così. L'uso non approvato, lo Shadow AI vero e proprio, riguarda strumenti o modalità che l'organizzazione non consente, o non conosce. Richiede attenzione e controlli. La tabella confronta tre situazioni, fittizie. Chiamare Shadow AI ogni iniziativa spontanea ha un effetto negativo: scoraggia la sperimentazione, che è proprio ciò di cui l'adozione ha bisogno. Ignorare lo Shadow AI, al contrario, lascia senza risposta sia i bisogni sia i rischi. La strada indicata dal documento, che riprenderemo nel 16.7, è doppia: offrire strumenti consentiti adatti ai bisogni reali, e rendere chiare le regole.");
    adTag(s, 0);
    table(s, [["Situazione (fittizia)", "Che cos'è", "Che cosa richiede"],
      ["Un commerciale prova lo strumento aziendale per un nuovo tipo di offerta", "Sperimentazione autorizzata", "Incoraggiamento, condivisione"],
      ["Un team crea istruzioni condivise sullo strumento approvato", "Adozione dal basso", "Valorizzazione, diffusione"],
      ["Un collaboratore carica contratti su un servizio personale", "Uso non approvato", "Attenzione, alternativa, controllo"]],
      { y: 1.15, colW: [4.0, 2.4, 2.6], rowH: 0.65, accentCol: 1, fontSize: 12, blankCorner: false });
    banner(s, 3.95, "Chiamare Shadow AI ogni iniziativa scoraggia la sperimentazione. Ignorarlo lascia senza risposta bisogni e rischi.", { h: 0.85, fontSize: 14 });
  }
  keySlide("Acquistare licenze e registrare accessi non equivale ad adottare l'AI: conta l'integrazione appropriata nel lavoro.", "Sottotema 16.1  ·  Che cosa significa adottare l'AI in azienda  ·  Integrazione A", "Concetto chiave del primo sottotema. Disponibilità, uso occasionale e adozione effettiva sono diversi. L'adozione ha livelli individuale, di team e organizzativo. Diffusione spontanea e introduzione coordinata hanno pregi e limiti. Utenti, qualità d'uso e impatto vanno distinti. L'adozione è un percorso, non un evento. Lo Shadow AI è insieme un segnale di bisogni e un rischio, e non coincide con la sperimentazione autorizzata. Esercizio suggerito: per uno strumento digitale introdotto in azienda negli ultimi anni, descrivere a che livello è arrivato: disponibile, usato occasionalmente, adottato da alcuni, adottato da team, integrato nell'organizzazione.");

  // =====================================================================
  section("16.2 Fattori e ostacoli");
  divider("16.2", "Fattori e ostacoli", "Una bassa adozione può dipendere dallo strumento o dalle condizioni operative, non dalla scarsa apertura al cambiamento", "Secondo sottotema, da comprendere e riconoscere, e uno di quelli con maggiore attenzione didattica. Il documento lo indica come la mappa dei fattori, mentre il 16.6 approfondirà le dinamiche sociali, fiducia e partecipazione: evitiamo una doppia trattazione generica delle resistenze. Vediamo utilità percepita e facilità d'uso, fiducia, tempo, competenze, prime esperienze, supporto, chiarezza, compatibilità, ostacoli di vario tipo, differenze tra gruppi, difficoltà individuali e problemi strutturali. Integrazioni A e B.");
  {
    const s = content("Utile e facile", "I primi due fattori del sottotema sono anche i più studiati: l'utilità percepita rispetto ai bisogni lavorativi, e la facilità d'uso e l'accessibilità degli strumenti. Il Technology Acceptance Model, proposto da Fred Davis nel 1989, ha mostrato che l'intenzione di usare una tecnologia dipende soprattutto da questi due fattori: quanto la persona ritiene che la tecnologia la aiuti nel suo lavoro, e quanto la ritiene facile da usare. Modelli successivi, come quello di Venkatesh e colleghi del 2003, hanno aggiunto altri fattori, come l'influenza sociale e le condizioni che facilitano l'uso, ma l'utilità resta in genere il fattore più forte. Notate la parola 'percepita'. Non basta che uno strumento sia utile in astratto: la persona deve vedere come è utile per le sue attività. Una dimostrazione generica che mostra come scrivere una poesia non fa percepire l'utilità a chi prepara offerte tecniche. E la facilità d'uso, per l'AI generativa, ha una particolarità: lo strumento è facile da iniziare, si scrive in linguaggio naturale, ma difficile da usare bene, come visto nei Temi 5 e 6. Molte persone provano, ottengono risultati mediocri, e concludono che lo strumento non serve.");
    adTag(s, 0);
    await twoPanel(s, "Utilità percepita", bullets(["Quanto aiuta nel mio lavoro?", "Percepita: devo vedere come serve per le mie attività", "Una poesia non convince chi fa offerte tecniche"], { space: 5 }), "Facilità d'uso", bullets(["Quanto è facile da usare?", "AI generativa: facile da iniziare, difficile da usare bene (Temi 5 e 6)", "Risultati mediocri: 'non serve'"], { space: 5 }), { y: 1.15, h: 2.6, li: "FiThumbsUp", ri: "FiMousePointer" });
    banner(s, 3.95, "Technology Acceptance Model (Davis, 1989); UTAUT (Venkatesh et al., 2003): l'utilità resta il fattore più forte.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("La mappa dei fattori", "Il sottotema elenca molti fattori. Li organizziamo in una mappa, distinguendo quelli che riguardano più le persone e quelli che riguardano più le condizioni, anche se il confine non è netto. Fattori legati alle persone: la fiducia nelle capacità e la comprensione dei limiti, perché fiducia eccessiva e sfiducia ostacolano entrambe un uso appropriato; le competenze iniziali e le differenze tra utilizzatori; la qualità delle prime esperienze d'uso, che spesso determina l'atteggiamento successivo. Fattori legati alle condizioni: il tempo disponibile per sperimentare e imparare, che è forse il più sottovalutato; il supporto tecnico e organizzativo; la chiarezza sugli strumenti e sulle modalità consentite, perché nel dubbio molte persone si astengono; la compatibilità con le attività e i processi esistenti. E l'utilità e la facilità d'uso, appena viste, che stanno a cavallo. La mappa serve a una domanda pratica, la terza domanda guida: quali ostacoli dipendono dalle persone e quali dalle condizioni organizzative? La risposta conta, perché i rimedi sono diversi.");
    adTag(s, 0);
    const p = ["Fiducia e comprensione dei limiti", "Competenze iniziali, differenze", "Qualità delle prime esperienze"];
    const c = ["Tempo per sperimentare e imparare", "Supporto tecnico e organizzativo", "Chiarezza su strumenti e usi consentiti", "Compatibilità con attività e processi"];
    shapeBox(s, 0.5, 1.15, 3.6, 3.1, C.background2, "persone");
    txt(s, "Più legati alle persone", { x: 0.65, y: 1.2, w: 3.3, h: 0.38, fontSize: 14, bold: true, color: C.accent1 });
    p.forEach((t, i) => chip(s, 0.65, 1.68 + i * 0.75, 3.3, 0.62, t, { fill: C.background1, fontSize: 12 }));
    shapeBox(s, 4.3, 1.15, 1.4, 3.1, C.accent1, "in mezzo");
    txt(s, "Utilità e facilità d'uso", { x: 4.35, y: 1.15, w: 1.3, h: 3.1, fontSize: 13, bold: true, color: C.background1, align: "center", valign: "middle" });
    shapeBox(s, 5.9, 1.15, 3.6, 3.1, C.accent6, "condizioni");
    txt(s, "Più legati alle condizioni", { x: 6.05, y: 1.2, w: 3.3, h: 0.38, fontSize: 14, bold: true, color: C.accent1 });
    c.forEach((t, i) => chip(s, 6.05, 1.65 + i * 0.63, 3.3, 0.53, t, { fill: C.background1, fontSize: 12 }));
    banner(s, 4.4, "Persone o condizioni? I rimedi sono diversi.", { h: 0.5, fontSize: 14 });
  }
  {
    const s = content("Il tempo e le prime esperienze", "Due fattori meritano un approfondimento, perché sono spesso decisivi e trascurati. Il tempo disponibile per sperimentare e imparare. Imparare a usare bene uno strumento di AI richiede tempo: provare su attività reali, sbagliare, riprovare, capire che cosa funziona. Nelle prime settimane, usare lo strumento richiede più tempo che non usarlo. Se le persone sono già al massimo del carico, sceglieranno razionalmente di non investire quel tempo: il beneficio è futuro e incerto, il costo è immediato. È una delle ragioni per cui la curva di adozione è lenta all'inizio, e per cui chi ha più tempo, o più margine, adotta prima. La qualità delle prime esperienze d'uso. Le prime volte che una persona usa lo strumento formano il suo giudizio. Se le prime prove sono su attività adatte, con buoni risultati, l'atteggiamento sarà positivo. Se sono su attività inadatte, o con istruzioni povere, i risultati deludenti portano alla conclusione che lo strumento non serve, ed è difficile tornare indietro. Ne deriva un'indicazione pratica, che riprenderemo nel 16.4 e 16.5: aiutare le persone a fare le prime prove su attività in cui l'AI funziona bene, con esempi pertinenti.");
    adTag(s, 0);
    await card(s, 0.5, 1.15, 4.35, 2.75, { icon: "FiClock", head: "Il tempo per imparare", headSize: 15, bodySize: 12, body: bullets(["Nelle prime settimane, usarlo costa più tempo che non usarlo", "Beneficio futuro e incerto, costo immediato", "Chi è al massimo del carico, razionalmente, rinuncia"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.75, { icon: "FiStar", head: "Le prime esperienze", headSize: 15, bodySize: 12, fill: C.accent6, body: bullets(["Formano il giudizio", "Attività inadatte, istruzioni povere: 'non serve'", "Difficile tornare indietro"], { space: 4 }) });
    banner(s, 4.1, "Dare tempo, e far fare le prime prove su attività in cui l'AI funziona bene (16.4, 16.5).", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Quattro tipi di ostacoli", "Il sottotema chiede di riconoscere ostacoli tecnologici, operativi, economici e culturali. Tecnologici: lo strumento non è adatto al compito, non è integrato con i sistemi che si usano, è lento, ha limiti di qualità, non accede alle informazioni necessarie, come visto nel Tema 14. Operativi: il processo non prevede l'uso dello strumento, i passaggi successivi non lo accettano, mancano indicazioni su come usarlo, la verifica richiede troppo tempo. Economici: le licenze sono disponibili solo per alcuni, i costi per utilizzo scoraggiano l'uso, non ci sono risorse per formazione e supporto. Culturali: il lavoro con l'AI è visto come meno professionale o meno meritevole, c'è timore di essere giudicati, di sbagliare, o di rendere evidente che il proprio lavoro può essere accelerato; o al contrario c'è pressione a usarlo anche dove non serve. Distinguere i tipi di ostacolo è utile perché i rimedi sono diversi: un ostacolo tecnologico non si risolve con una campagna di comunicazione, un ostacolo culturale non si risolve con una licenza in più.");
    adTag(s, 0);
    await iconGrid(s, [
      { icon: "FiCpu", head: "Tecnologici", body: "Strumento inadatto, non integrato, lento, senza le informazioni (Tema 14)" },
      { icon: "FiGitBranch", head: "Operativi", body: "Il processo non lo prevede, mancano indicazioni, verifica troppo lunga" },
      { icon: "FiDollarSign", head: "Economici", body: "Licenze solo per alcuni, costi per uso, niente risorse per supporto" },
      { icon: "FiUsers", head: "Culturali", body: "Visto come meno professionale; timore di giudizio; o pressione a usarlo" },
    ], 2, { y: 1.15, H: 2.65, headSize: 14, bodySize: 12 });
    banner(s, 4.0, "Un ostacolo tecnologico non si risolve con la comunicazione; uno culturale non si risolve con una licenza.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Differenze tra gruppi", "Il sottotema chiede di riconoscere le differenze di adozione tra funzioni e gruppi. L'adozione dell'AI è quasi sempre disomogenea. Tra funzioni: le attività di alcune, come marketing, comunicazione, sviluppo software, assistenza clienti, si prestano più di altre all'AI generativa, come visto nel Tema 13. Tra ruoli: chi lavora molto con testi e informazioni ha più occasioni d'uso. Tra persone: per età, esperienza, competenze digitali, tempo disponibile, atteggiamento. Diverse indagini hanno osservato differenze significative nell'uso dell'AI generativa tra gruppi demografici e professionali, anche se i risultati variano tra paesi e periodi. Le differenze non sono di per sé un problema: se l'AI è più utile in alcune attività, è naturale che sia più usata lì. Diventano un problema in due casi. Quando dipendono da ostacoli evitabili, come la mancanza di tempo, di formazione adatta o di accesso: allora alcune persone restano indietro senza ragione. E quando producono disuguaglianze: chi adotta acquisisce competenze e vantaggi, chi non adotta rischia di essere penalizzato. Il grafico mostra, con dati inventati, una distribuzione tipica in un'azienda fittizia.");
    adTag(s, 0);
    chartBarH(s, ["Marketing e comunicazione", "Assistenza clienti", "Commerciale", "Amministrazione", "Produzione", "Logistica"], [0.72, 0.58, 0.45, 0.34, 0.15, 0.12], { x: 0.5, y: 1.05, w: 5.6, h: 3.4, max: 0.9, title: "Uso abituale per funzione (dati inventati)" });
    await card(s, 6.35, 1.15, 3.15, 1.6, { icon: "FiCheck", inline: true, head: "Naturale", headSize: 13, bodySize: 12, body: "Se l'AI è più utile in alcune attività." });
    await card(s, 6.35, 2.9, 3.15, 1.6, { icon: "FiAlertCircle", inline: true, head: "Un problema", headSize: 13, bodySize: 12, fill: C.accent6, body: "Se dipende da ostacoli evitabili o crea disuguaglianze." });
  }
  {
    const s = content("Individuale o strutturale?", "Una distinzione centrale del sottotema, e la sua consapevolezza: le difficoltà individuali e i problemi strutturali. Quando l'adozione è bassa, la spiegazione più comune è individuale: le persone sono resistenti al cambiamento, non hanno voglia, non hanno capito. A volte è vero. Ma spesso la causa è strutturale: lo strumento non è adatto, il tempo non c'è, le regole non sono chiare, il processo non lo prevede. La consapevolezza del sottotema lo dice chiaramente: una bassa adozione può dipendere dall'inadeguatezza dello strumento o dalle condizioni operative, non dalla scarsa apertura al cambiamento. Un segnale utile per distinguere: se molte persone, in contesti diversi, incontrano la stessa difficoltà, è probabilmente un problema strutturale. Se la difficoltà riguarda poche persone in un contesto in cui altre usano bene lo strumento, può essere individuale, e richiede supporto mirato. La tabella in slide propone alcune domande per distinguere. La differenza conta perché attribuire a problemi individuali difficoltà strutturali porta a rimedi inefficaci, come altra formazione o altra comunicazione, e a frustrazione da entrambe le parti.");
    adTag(s, 0);
    table(s, [["Domanda", "Se sì, probabilmente..."],
      ["Molte persone, in contesti diversi, hanno la stessa difficoltà?", "Strutturale"],
      ["Chi ha tempo e supporto lo usa bene, gli altri no?", "Strutturale: tempo e supporto"],
      ["Lo strumento dà risultati scarsi sulle attività tipiche?", "Strutturale: strumento inadatto"],
      ["Poche persone in difficoltà, dove altre lo usano bene?", "Individuale: supporto mirato"]],
      { y: 1.15, colW: [5.8, 3.2], rowH: 0.52, accentCol: 1, fontSize: 12, blankCorner: false });
    banner(s, 3.9, "Difficoltà strutturali trattate come individuali: altra formazione, altra comunicazione, e frustrazione da entrambe le parti.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Che cosa ci dicono i segnali", "Gli ultimi punti del sottotema, e le integrazioni A e B lette insieme: le esigenze insoddisfatte che possono favorire lo Shadow AI, e il valore informativo dello scetticismo e delle difficoltà segnalate. Due comportamenti, apparentemente opposti, che vanno interpretati. L'uso di servizi non autorizzati: le persone usano strumenti esterni. Può indicare che lo strumento approvato manca, è meno capace, è più scomodo, o non è conosciuto; o che le regole non sono chiare. La riluttanza a usare quelli approvati: le persone non usano lo strumento offerto. Può indicare che non è utile per le loro attività, che dà risultati scarsi, che richiede troppo tempo, che non si sentono sicure su che cosa è consentito. Il documento sottolinea che i due comportamenti possono indicare problemi diversi, e che comprenderne le cause è più utile che attribuirli automaticamente alla resistenza delle persone. Lo scetticismo e le difficoltà segnalate sono informazioni: dicono dove lo strumento, le condizioni o l'introduzione non funzionano. Approfondiremo questa idea, l'integrazione B, nel 16.6.");
    adTag(s, 0);
    await twoPanel(s, "Usano servizi non autorizzati", bullets(["Lo strumento approvato manca o è meno capace", "È più scomodo, o non conosciuto", "Le regole non sono chiare"], { space: 5 }), "Non usano quelli approvati", bullets(["Non è utile per le loro attività", "Dà risultati scarsi, richiede troppo tempo", "Incertezza su che cosa è consentito"], { space: 5 }), { y: 1.15, h: 2.5, li: "FiExternalLink", ri: "FiSlash" });
    banner(s, 3.85, "Comprendere le cause è più utile che attribuire tutto alla resistenza. Lo scetticismo è un'informazione (A, B).", { h: 0.9, fontSize: 14 });
  }
  keySlide("Una bassa adozione può dipendere dallo strumento o dalle condizioni operative, non dalla scarsa apertura al cambiamento.", "Sottotema 16.2  ·  I fattori che favoriscono o ostacolano l'adozione  ·  Integrazioni A e B", "Concetto chiave del secondo sottotema. Utilità percepita e facilità d'uso sono i fattori più forti; per l'AI generativa, facile da iniziare non vuol dire facile da usare bene. I fattori riguardano persone e condizioni; tempo e prime esperienze sono spesso decisivi. Gli ostacoli sono tecnologici, operativi, economici, culturali, con rimedi diversi. Le differenze tra gruppi sono naturali o problematiche a seconda delle cause. Le difficoltà strutturali non vanno trattate come individuali. Shadow AI e riluttanza sono segnali da interpretare. Esercizio suggerito: elencare in piccoli gruppi i tre principali ostacoli all'uso dell'AI nel proprio lavoro, e classificarli come individuali o strutturali, e per tipo.");

  // =====================================================================
  section("16.3 Leadership e management");
  divider("16.3", "Leadership e management", "La leadership non deve solo promuovere l'AI: deve contribuire a renderne possibile l'utilizzo appropriato e utile", "Terzo sottotema, da comprendere. La quarta domanda guida chiede quali responsabilità hanno leadership, manager e collaboratori. Il documento distingue: il 16.3 riguarda orientamento e responsabilità manageriali, il 16.7 i meccanismi di supporto quotidiano. Vediamo la sponsorship della direzione, la chiarezza sulle finalità, il ruolo dei manager nel creare condizioni, la coerenza tra parole e comportamenti, la differenza tra incoraggiare e imporre, il rischio di adozione simbolica e l'importanza di aspettative realistiche.");
  {
    const s = content("Direzione: perché e verso dove", "I primi punti del sottotema riguardano la direzione aziendale. La sponsorship e l'orientamento: un'iniziativa di adozione che non ha il sostegno visibile della direzione tende a perdere priorità, risorse e attenzione. La chiarezza sulle finalità: perché l'azienda introduce l'AI? Per migliorare il servizio, per ridurre il tempo speso in attività ripetitive, per sviluppare competenze, per ridurre i costi? Le persone se lo chiedono, e se la risposta non è chiara la riempiono da sole, spesso con l'ipotesi peggiore, come la riduzione del personale. Il collegamento tra adozione e obiettivi aziendali: l'AI non è un obiettivo in sé, ma un mezzo per obiettivi che le persone conoscono. È il ponte con il Tema 15: le opportunità scelte vanno comunicate come risposte a problemi reali. Un'osservazione importante: la chiarezza sulle finalità non è solo una questione di comunicazione, ma di scelte. Se la direzione non ha deciso che cosa vuole ottenere, nessuna comunicazione potrà renderlo chiaro. E se le finalità dichiarate e quelle reali divergono, le persone se ne accorgono.");
    adTag(s, 1);
    await iconGrid(s, [
      { icon: "FiFlag", head: "Sponsorship", body: "Sostegno visibile: priorità, risorse, attenzione" },
      { icon: "FiHelpCircle", head: "Finalità chiare", body: "Perché? Se non è chiaro, le persone pensano al peggio" },
      { icon: "FiTarget", head: "Obiettivi aziendali", body: "L'AI come mezzo per problemi reali (Tema 15)" },
    ], 3, { y: 1.15, H: 2.0, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 3.35, 9.0, 0.75, C.background2, "scelte");
    txt(s, [{ text: "Non solo comunicazione: ", options: { bold: true, color: C.accent1 } }, { text: "se la direzione non ha deciso che cosa vuole ottenere, nessuna comunicazione potrà renderlo chiaro.", options: { color: C.text1 } }], { x: 0.7, y: 3.35, w: 8.6, h: 0.75, fontSize: 13, valign: "middle" });
    banner(s, 4.25, "Se finalità dichiarate e reali divergono, le persone se ne accorgono.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("I manager: creare condizioni", "Il cuore del sottotema riguarda i responsabili diretti, i manager, che il documento indica come decisivi per creare condizioni operative favorevoli. Se i fattori del 16.2 sono in buona parte condizioni, chi può intervenire su di esse è soprattutto chi organizza il lavoro. Il sottotema indica alcune responsabilità concrete. Mettere a disposizione tempo, risorse e strumenti: per esempio riconoscere che nelle prime settimane l'uso richiede tempo, e alleggerire altri carichi. Individuare gli ostacoli concreti: non chiedere genericamente 'state usando l'AI?', ma capire che cosa impedisce di usarla dove servirebbe. Ascoltare le esperienze e le criticità dei collaboratori, positive e negative. Promuovere la sperimentazione controllata: dare spazio per provare, entro regole chiare, e accettare che alcune prove non funzionino. È un ruolo diverso da quello del promotore: il manager non deve convincere le persone che l'AI è utile, ma rendere possibile scoprire dove lo è, e rimuovere ciò che ostacola l'uso utile. La consapevolezza del sottotema: la leadership non deve solo promuovere l'AI, deve contribuire a rendere possibile il suo uso appropriato e utile.");
    adTag(s, 1);
    numList(s, ["Tempo, risorse e strumenti: alleggerire altri carichi nelle prime settimane", "Individuare gli ostacoli concreti: che cosa impedisce di usarla dove servirebbe?", "Ascoltare esperienze e criticità, positive e negative", "Promuovere la sperimentazione controllata, accettando che alcune prove non funzionino"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 3.7, "Non convincere che l'AI è utile, ma rendere possibile scoprire dove lo è, e rimuovere ciò che ostacola l'uso utile.", { h: 1.0, fontSize: 14 });
  }
  {
    const s = content("Coerenza tra parole e priorità", "Il sottotema chiede coerenza tra comunicazione, comportamenti e priorità. Le persone osservano più quello che i responsabili fanno che quello che dicono. Alcuni esempi di incoerenza, frequenti e comprensibili. Si dice 'sperimentate', ma non si concede tempo, e gli obiettivi di produttività restano invariati. Si dice 'l'AI è importante', ma i responsabili non la usano, o non se ne interessano. Si dice 'segnalate i problemi', ma chi li segnala viene visto come resistente. Si dice 'usatela per migliorare la qualità', ma si valuta solo la velocità. Si dice 'nessuno perderà il lavoro', ma si parla di riduzione dei costi del personale. Ogni incoerenza insegna alle persone che cosa conta davvero, e lo fa in modo più efficace di qualsiasi comunicazione ufficiale. La coerenza non richiede che i responsabili siano esperti o entusiasti utilizzatori: richiede che le priorità dichiarate si vedano nelle decisioni su tempo, valutazione, riconoscimento. Un manager che non usa l'AI ma dà tempo per sperimentare, ascolta i problemi e valuta i risultati in modo equilibrato è più coerente di uno che la usa ma chiede risultati immediati. Esempi fittizi.");
    adTag(s, 1);
    table(s, [["Si dice (esempi fittizi)", "Ma si fa"],
      ["Sperimentate", "Nessun tempo, obiettivi invariati"],
      ["L'AI è importante", "I responsabili non se ne interessano"],
      ["Segnalate i problemi", "Chi li segnala è visto come resistente"],
      ["Usatela per la qualità", "Si valuta solo la velocità"]],
      { y: 1.15, colW: [3.8, 5.2], rowH: 0.5, accentCol: 1, fontSize: 13, blankCorner: false });
    banner(s, 3.8, "Ogni incoerenza insegna che cosa conta davvero. Le priorità si vedono in tempo, valutazione, riconoscimento.", { h: 0.95, fontSize: 14 });
  }
  {
    const s = content("Incoraggiare o imporre", "Il sottotema chiede di distinguere tra incoraggiare e imporre l'uso, e segnala i rischi di un'adozione simbolica basata su obiettivi quantitativi. Incoraggiare significa creare le condizioni, mostrare esempi, dare tempo, riconoscere gli usi utili, lasciando alle persone il giudizio su dove e come usare lo strumento. Imporre significa rendere l'uso obbligatorio, o misurarlo e valutarlo come obiettivo. Ci sono casi in cui uno standard comune ha senso, per esempio quando un processo è stato riprogettato intorno allo strumento. Ma l'imposizione generica dell'uso ha effetti noti. Il più importante è l'adozione simbolica: se il numero di utilizzi diventa un obiettivo, le persone lo raggiungono, magari usando lo strumento per attività inutili, o in modo superficiale, o registrando usi che non hanno valore. È un esempio della cosiddetta legge di Goodhart, dall'economista Charles Goodhart: quando una misura diventa un obiettivo, smette di essere una buona misura. L'organizzazione vede numeri in crescita, e crede di aver adottato l'AI, mentre il lavoro è rimasto uguale, o è peggiorato. E, come visto nel 16.2, la pressione all'uso dove non serve è anch'essa un ostacolo culturale.");
    adTag(s, 1);
    await twoPanel(s, "Incoraggiare", bullets(["Creare condizioni, mostrare esempi", "Dare tempo, riconoscere gli usi utili", "Il giudizio su dove e come resta alle persone"], { space: 5 }), "Imporre", bullets(["Uso obbligatorio o misurato come obiettivo", "Ha senso se il processo è stato riprogettato", "Generico: adozione simbolica"], { space: 5 }), { y: 1.15, h: 2.4, li: "FiSun", ri: "FiLock" });
    shapeBox(s, 0.5, 3.75, 9.0, 1.05, C.accent1, "goodhart");
    txt(s, [{ text: "Legge di Goodhart: ", options: { bold: true, color: C.accent6 } }, { text: "quando una misura diventa un obiettivo, smette di essere una buona misura. Numeri di utilizzo in crescita, lavoro uguale, o peggiore.", options: { color: C.background1 } }], { x: 0.7, y: 3.75, w: 8.6, h: 1.05, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Aspettative realistiche", "L'ultimo punto del sottotema: l'importanza di aspettative realistiche e risultati osservabili. Le aspettative sull'AI sono spesso molto alte, alimentate da annunci, presentazioni dei fornitori, notizie. Il ciclo dell'entusiasmo, descritto dalla società di analisi Gartner con il suo noto 'hype cycle', ipotizza che molte tecnologie passino da un picco di aspettative eccessive a una fase di disillusione, prima di arrivare a un uso produttivo più maturo. Il modello è discusso e non va preso come una legge, ma descrive bene un rischio. Se la direzione promette risultati rapidi e spettacolari, e i primi mesi mostrano miglioramenti modesti, il giudizio può diventare troppo negativo, e l'iniziativa essere abbandonata prima di aver dato i suoi frutti. Aspettative realistiche significano: dichiarare che l'adozione richiede tempo; indicare risultati osservabili, anche modesti, e come verranno osservati; riconoscere che alcune applicazioni non funzioneranno; collegare le attese alle evidenze raccolte nel Tema 15. Risultati osservabili significano: non promesse generiche come 'l'AI ci renderà più produttivi', ma indicazioni concrete come 'ridurre il tempo di preparazione delle offerte standard'.");
    adTag(s, 1);
    lineChart(s, ["Lancio", "", "Picco", "", "", "Delusione", "", "", "Uso maturo", "", ""], [
      { name: "Aspettative (schema illustrativo)", values: [20, 55, 85, 70, 45, 28, 32, 40, 47, 50, 52], color: HEX.a1 },
    ], { x: 0.5, y: 1.05, w: 5.4, h: 3.0, min: 0, max: 100, legend: false, valHidden: true, title: "Lo schema dell'hype cycle (illustrativo, Gartner)" });
    rowsLabel(s, [["Tempo", "L'adozione richiede tempo"], ["Osservabili", "Risultati concreti, anche modesti"], ["Fallimenti", "Alcune applicazioni non funzioneranno"], ["Evidenze", "Attese collegate al Tema 15"]], { y: 1.15, h: 0.62, lw: 1.2, x: 6.15, w: 3.35, fontSize: 11 });
    banner(s, 4.2, "Non 'l'AI ci renderà più produttivi', ma 'ridurre il tempo di preparazione delle offerte standard'.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Una responsabilità condivisa", "La quarta domanda guida chiede quali responsabilità hanno leadership, manager e collaboratori. Abbiamo visto le prime due; anche i collaboratori hanno un ruolo, che il documento richiama nei vari sottotemi, e che conviene rendere esplicito per completezza. Provare con un atteggiamento aperto ma critico: né rifiuto a priori né entusiasmo acritico. Usare lo strumento in modo appropriato, rispettando le indicazioni sugli usi consentiti e verificando gli output, come visto nel Tema 7. Segnalare problemi, difficoltà e anche usi utili, perché le segnalazioni sono informazioni per l'organizzazione. Condividere ciò che si impara con i colleghi. Mantenere le proprie competenze professionali, che restano il fondamento del giudizio. La tabella riassume le responsabilità dei tre livelli. Non è un mansionario, ma uno schema per riconoscere che l'adozione è una responsabilità condivisa: la direzione dà orientamento e risorse, i manager creano condizioni, i collaboratori sperimentano e segnalano. Se uno dei tre livelli manca, gli altri due faticano.");
    adTag(s, 1);
    table(s, [["Livello", "Responsabilità principali"],
      ["Direzione", "Orientamento, finalità chiare, sponsorship, risorse, coerenza"],
      ["Manager", "Tempo, ostacoli concreti, ascolto, sperimentazione controllata, valutazione equilibrata"],
      ["Collaboratori", "Provare con spirito critico, usare in modo appropriato, segnalare, condividere, mantenere le competenze"]],
      { y: 1.15, colW: [2.0, 7.0], rowH: 0.7, accentCol: 1, fontSize: 13, blankCorner: false });
    banner(s, 4.0, "Una responsabilità condivisa: se uno dei tre livelli manca, gli altri due faticano.", { h: 0.8, fontSize: 15 });
  }
  keySlide("La leadership non deve solo promuovere l'AI: deve contribuire a rendere possibile il suo uso appropriato e utile.", "Sottotema 16.3  ·  Il ruolo della leadership e del management", "Concetto chiave del terzo sottotema. La direzione dà sponsorship, finalità chiare e collegamento con gli obiettivi. I manager creano condizioni: tempo, rimozione degli ostacoli, ascolto, sperimentazione controllata. La coerenza tra parole e priorità insegna più della comunicazione. Incoraggiare non è imporre, e gli obiettivi quantitativi d'uso producono adozione simbolica. Le aspettative vanno tenute realistiche e osservabili. I collaboratori condividono la responsabilità. Esercizio suggerito: per i responsabili presenti, individuare una condizione concreta, tempo, indicazioni, ascolto, che potrebbero creare nel proprio gruppo per favorire un uso utile dell'AI; per gli altri, una condizione che vorrebbero ricevere.");
  // =====================================================================
  section("16.4 Competenze e formazione");
  divider("16.4", "Competenze e formazione", "Un corso introduttivo avvia l'apprendimento; la competenza operativa si consolida con l'applicazione e il confronto", "Quarto sottotema, da comprendere e applicare, e uno di quelli con maggiore attenzione didattica. Riguarda direttamente anche questo percorso di formazione. Vediamo l'alfabetizzazione come punto di partenza, competenze generali e per ruolo, l'applicazione in situazioni reali, il valore delle competenze preesistenti, formazione iniziale e aggiornamento, esempi, esercitazione e confronto, apprendimento tra colleghi, supporto dopo la formazione, perdita delle competenze non usate. Integrazione C: la formazione da sola non produce adozione.");
  {
    const s = content("Generali e per ruolo", "I primi punti del sottotema. L'alfabetizzazione AI come punto di partenza: è ciò che questo percorso cerca di dare, cioè una comprensione di base di che cosa sono questi sistemi, come funzionano, che cosa sanno fare e non fare, come usarli in modo consapevole. È necessaria, ma è un punto di partenza. Le competenze generali e le competenze specifiche per ruolo: le prime servono a tutti, come formulare richieste, verificare gli output, riconoscere i limiti, rispettare le regole. Le seconde dipendono dal lavoro: un commerciale ha bisogno di sapere come usare l'AI per preparare offerte e analizzare richieste; un addetto all'amministrazione per controllare documenti; un tecnico per consultare manuali e diagnosticare problemi. È la seconda precisazione del tema: le esigenze formative sono differenziate. Una base comune è utile, ma ruoli diversi richiedono esempi, competenze e supporti diversi. Una formazione identica per tutti rischia di essere troppo generica per alcuni e troppo specifica per altri. La capacità di impiegare gli strumenti in situazioni professionali reali, infine, è l'obiettivo: non sapere che cosa lo strumento può fare in generale, ma saperlo usare bene nel proprio lavoro.");
    adTag(s, 2);
    shapeBox(s, 0.5, 3.0, 9.0, 0.95, C.accent1, "base comune");
    txt(s, [{ text: "Base comune: alfabetizzazione AI. ", options: { bold: true, color: C.background1 } }, { text: "Che cosa sono, come funzionano, limiti, richieste, verifica, regole.", options: { color: C.background1 } }], { x: 0.7, y: 3.0, w: 8.6, h: 0.95, fontSize: 13, valign: "middle" });
    const r = [["Commerciale", "Offerte, analisi delle richieste"], ["Amministrazione", "Controllo dei documenti"], ["Tecnico", "Manuali, diagnosi"], ["Assistenza", "Risposte, sintesi dei casi"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 1.65, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.25, w: 1.91, h: 0.4, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.7, w: 1.91, h: 0.9, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.1, "Esigenze differenziate: troppo generica per alcuni, troppo specifica per altri. L'obiettivo è usarlo bene nel proprio lavoro.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Le competenze che restano", "Due punti del sottotema che vanno insieme: la comprensione dei limiti e la verifica degli output, e il valore delle competenze professionali preesistenti. Usare bene l'AI non significa solo saper formulare richieste: significa saper giudicare i risultati. E per giudicare un'offerta preparata dall'AI serve sapere com'è fatta una buona offerta; per giudicare una sintesi di un contratto serve capire il contratto. Le competenze professionali preesistenti non diventano inutili: diventano la condizione per usare l'AI in modo appropriato. Come visto nel Tema 13, la ricerca suggerisce che l'esperienza è decisiva per riconoscere gli errori dell'AI, e che i meno esperti rischiano di accettare output sbagliati. Questo ha conseguenze per la formazione. Non basta insegnare lo strumento: bisogna collegarlo alle competenze professionali, mostrando come il giudizio esperto guida e controlla il lavoro dell'AI. E le persone esperte, spesso più scettiche, sono una risorsa preziosa: sono quelle che sanno dove l'AI sbaglia. Coinvolgerle nella formazione e nella definizione delle pratiche è un modo per rendere l'adozione più solida. Il metodo di verifica è quello del Tema 7: qui ne sottolineiamo il ruolo nella formazione.");
    adTag(s, 2);
    await twoPanel(s, "Giudicare richiede competenza", "Per giudicare un'offerta dell'AI serve sapere com'è fatta una buona offerta.\n\nL'esperienza è decisiva per riconoscere gli errori (Tema 13).", "Conseguenze per la formazione", bullets(["Collegare lo strumento alle competenze professionali", "Mostrare il giudizio esperto che guida e controlla", "Coinvolgere gli esperti, anche scettici"], { space: 4 }), { y: 1.15, h: 2.65, li: "FiAward", ri: "FiBookOpen" });
    banner(s, 4.0, "Le competenze professionali non diventano inutili: diventano la condizione per usare l'AI in modo appropriato.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Come si impara davvero", "Il sottotema indica le modalità che favoriscono l'apprendimento, e coincidono con molto di ciò che si sa sulla formazione degli adulti. Esempi pratici vicini alle attività quotidiane: imparare sulle proprie attività, non su esempi generici. Esercitazione, feedback e confronto: provare, ricevere un riscontro, discutere con gli altri. Apprendimento tra colleghi e condivisione delle pratiche: molto di ciò che si impara sull'AI si impara da chi lavora accanto, che ha già affrontato gli stessi problemi. Occasioni concrete per applicare quanto appreso: senza applicazione, la formazione si dissolve. Un riferimento diffuso nella formazione aziendale è il modello 70-20-10, attribuito al Center for Creative Leadership e a Lombardo ed Eichinger negli anni Novanta: circa il 70 per cento dell'apprendimento professionale verrebbe dall'esperienza sul lavoro, il 20 dalle relazioni con gli altri, il 10 dalla formazione formale. Le proporzioni non sono un dato scientifico preciso, e sono state criticate, ma l'idea di fondo è condivisa: la formazione formale è una parte minoritaria dell'apprendimento. Il grafico illustra il modello. La conseguenza per l'AI: la formazione in aula va progettata come innesco di un apprendimento che continua nel lavoro e tra colleghi.");
    adTag(s, 2);
    s.addChart(pres.charts.PIE, [{ name: "Apprendimento", labels: ["Esperienza sul lavoro", "Relazioni con gli altri", "Formazione formale"], values: [70, 20, 10] }], {
      x: 0.4, y: 1.05, w: 4.6, h: 2.75, chartColors: [HEX.a1, HEX.a4, HEX.a5], showPercent: true, showValue: false, dataLabelColor: "FFFFFF", dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt",
      showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Il modello 70-20-10 (indicativo, discusso)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt" });
    rowList(s, ["Esempi vicini alle attività quotidiane", "Esercitazione, feedback, confronto", "Apprendimento tra colleghi", "Occasioni concrete per applicare"], { y: 1.15, h: 0.5, gap: 0.08, x: 5.3, w: 4.2, fontSize: 12 });
    banner(s, 3.95, "La formazione in aula come innesco di un apprendimento che continua nel lavoro e tra colleghi.", { h: 0.8, fontSize: 13, });
  }
  {
    const s = content("Dall'aula al lavoro", "L'integrazione C del tema: la formazione da sola non produce adozione. Le competenze acquisite in aula possono non trasferirsi nel lavoro senza strumenti adeguati, tempo, esercizio e supporto. È un fenomeno studiato da decenni con il nome di transfer della formazione. Una rassegna classica di Baldwin e Ford, del 1988, ha individuato tre gruppi di fattori che influenzano il trasferimento: le caratteristiche delle persone, come la motivazione; il modo in cui la formazione è progettata, come la pertinenza degli esempi; e soprattutto l'ambiente di lavoro, cioè l'opportunità di applicare, il sostegno dei responsabili e dei colleghi. Molte stime, spesso citate ma difficili da verificare, sostengono che solo una parte minoritaria di ciò che si impara in aula venga poi applicata. Il punto non dipende dal numero preciso: la formazione è necessaria ma non sufficiente. Lo schema in slide riassume le condizioni del trasferimento. Per questo percorso significa una cosa concreta: dopo ogni tema, conviene che i partecipanti abbiano occasioni per applicare ciò che hanno imparato, con gli strumenti disponibili, il tempo e il supporto dei loro responsabili.");
    adTag(s, 2);
    const st = [["FiBookOpen", "Formazione", "Necessaria, non sufficiente"], ["FiTool", "Strumenti adeguati", "Disponibili per le proprie attività"], ["FiClock", "Tempo ed esercizio", "Occasioni per applicare"], ["FiLifeBuoy", "Supporto", "Responsabili e colleghi"], ["FiBriefcase", "Lavoro", "Competenza che si applica"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84, dark = i === 4;
      shapeBox(s, x, 1.15, 1.62, 2.2, dark ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.5, 1.25, 0.6, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.08, y: 1.95, w: 1.46, h: 0.5, fontSize: 12, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.08, y: 2.5, w: 1.46, h: 0.75, fontSize: 11, color: dark ? C.background1 : C.text2, align: "center" });
      if (i < 4) arrow(s, x + 1.63, 2.1, 0.19);
    }
    banner(s, 3.6, "Transfer della formazione (Baldwin e Ford, 1988): conta soprattutto l'ambiente di lavoro. La formazione da sola non produce adozione (C).", { h: 1.0, fontSize: 13 });
  }
  {
    const s = content("Sapere, saper fare, fare", "Una distinzione del sottotema che riassume l'integrazione C: la differenza tra apprendimento teorico, competenza operativa e comportamento abituale. L'apprendimento teorico è sapere: capire come funziona un modello linguistico, conoscere i rischi delle allucinazioni, sapere che cosa è una buona richiesta. È ciò che un corso trasmette più facilmente. La competenza operativa è saper fare: riuscire a usare lo strumento su un compito reale, ottenendo un buon risultato, verificandolo. Si costruisce con l'esercizio. Il comportamento abituale è fare: usare lo strumento in modo appropriato, regolarmente, quando serve, senza doverci pensare ogni volta. Si costruisce con la ripetizione nel lavoro, in un contesto che lo sostiene. Il modello di Kirkpatrick, molto usato per valutare la formazione, distingue in modo simile quattro livelli: la reazione dei partecipanti, l'apprendimento, il comportamento nel lavoro, i risultati per l'organizzazione. La maggior parte delle valutazioni si ferma ai primi due, che sono i più facili da misurare. Il valore, però, si gioca negli ultimi due. Un corso apprezzato e con un buon test finale non dice ancora nulla sul comportamento.");
    adTag(s, 2);
    const l = [["Sapere", "Apprendimento teorico", "Il corso"], ["Saper fare", "Competenza operativa", "L'esercizio"], ["Fare", "Comportamento abituale", "La ripetizione nel lavoro, in un contesto che sostiene"]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.6, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.2, w: 2.56, h: 0.45, fontSize: 18, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.35, fontSize: 12, bold: true, color: i === 2 ? C.background1 : C.text1 });
      txt(s, "Si costruisce con: " + e[2], { x: x + 0.15, y: 2.0, w: 2.56, h: 0.7, fontSize: 11, italic: true, color: i === 2 ? C.accent6 : C.text2 });
      if (i < 2) arrow(s, x + 2.88, 1.8, 0.17);
    });
    txt(s, "I quattro livelli di Kirkpatrick", { x: 0.5, y: 2.9, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    ["Reazione", "Apprendimento", "Comportamento", "Risultati"].forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.27, 2.15, 0.55, (i + 1) + "  " + t, { fill: i < 2 ? C.background2 : C.accent6, fontSize: 13 }));
    banner(s, 4.0, "Si misurano quasi sempre i primi due livelli. Il valore si gioca negli ultimi due.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Dopo la formazione", "Gli ultimi punti del sottotema: formazione iniziale e aggiornamento continuo, il supporto successivo alla formazione, il rischio di perdita delle competenze non usate. L'aggiornamento continuo è particolarmente importante per l'AI, perché gli strumenti cambiano rapidamente: nuove funzioni, nuovi modelli, nuovi limiti. Ciò che si impara oggi può essere parzialmente superato in un anno. Il supporto dopo la formazione: le domande vere arrivano quando si prova a usare lo strumento nel proprio lavoro, spesso settimane dopo il corso. Se in quel momento non c'è nessuno a cui chiedere, molte persone rinunciano. Il rischio di perdita delle competenze non usate: ciò che si impara e non si applica si dimentica. Il fenomeno è noto dagli studi di Hermann Ebbinghaus, alla fine dell'Ottocento, sulla curva dell'oblio: senza ripetizione, la memoria di ciò che si è appreso cala rapidamente nei giorni successivi. Il grafico, con un andamento illustrativo, confronta ciò che resta senza applicazione e con applicazioni ripetute. La consapevolezza del sottotema: un corso introduttivo avvia l'apprendimento; la competenza operativa si consolida con l'applicazione e il confronto.");
    adTag(s, 2);
    const lb = ["Corso", "1 sett.", "2 sett.", "1 mese", "2 mesi", "3 mesi"];
    lineChart(s, lb, [
      { name: "Senza applicazione", values: [100, 45, 35, 28, 22, 20], color: HEX.a5 },
      { name: "Con applicazioni ripetute", values: [100, 80, 82, 85, 87, 88], color: HEX.a1 },
    ], { x: 0.5, y: 1.05, w: 5.4, h: 3.4, min: 0, max: 110, legend: true, symbol: "circle", title: "Ciò che resta, % (andamento illustrativo)" });
    rowsLabel(s, [["Aggiornamento", "Gli strumenti cambiano in fretta"], ["Supporto dopo", "Le domande vere arrivano settimane dopo"], ["Curva dell'oblio", "Senza ripetizione si dimentica (Ebbinghaus)"]], { y: 1.15, h: 0.85, lw: 1.35, x: 6.15, w: 3.35, fontSize: 11 });
    txt(s, "Un corso avvia; l'applicazione e il confronto consolidano.", { x: 6.15, y: 4.05, w: 3.35, h: 0.45, fontSize: 12, bold: true, italic: true, color: C.accent1 });
  }
  keySlide("Un corso introduttivo avvia l'apprendimento: la competenza operativa si consolida con l'applicazione, il confronto e il supporto nel lavoro.", "Sottotema 16.4  ·  Competenze, formazione e apprendimento continuo  ·  Integrazione C", "Concetto chiave del quarto sottotema. L'alfabetizzazione è il punto di partenza; le esigenze sono differenziate per ruolo. Le competenze professionali restano la condizione per giudicare l'AI. Si impara soprattutto nel lavoro e tra colleghi. Il trasferimento dall'aula al lavoro dipende da strumenti, tempo, esercizio e supporto. Sapere, saper fare e fare sono livelli diversi, e la valutazione dovrebbe guardare al comportamento e ai risultati. Dopo la formazione servono aggiornamento e supporto, o si dimentica. Esercizio suggerito: ogni partecipante sceglie un'attività del proprio lavoro su cui applicare, nelle prossime due settimane, qualcosa appreso nel percorso, e un collega con cui confrontarsi sui risultati.");

  // =====================================================================
  section("16.5 Sperimentazione e diffusione");
  divider("16.5", "Sperimentazione e diffusione", "Diffondere gradualmente l'AI permette di verificare risultati e condizioni, anziché amplificare rapidamente problemi non compresi", "Quinto sottotema, da comprendere, e uno di quelli con maggiore attenzione didattica. Il documento distingue: il 16.4 tratta lo sviluppo delle competenze, il 16.5 l'introduzione progressiva nel contesto operativo; il 16.5 riguarda il passaggio dal pilota all'estensione, il 16.8 il consolidamento nel tempo. Il confine con il Tema 15: lì il test serviva a verificare un'ipotesi sull'opportunità, qui la sperimentazione serve a imparare come introdurla. Integrazioni C e D: la pratica sostiene l'apprendimento; un pilota riuscito non è automaticamente pronto per tutta l'organizzazione.");
  {
    const s = content("Dimostrazione, pilota, estensione", "Il sottotema chiede di distinguere tre momenti dell'introduzione progressiva. La dimostrazione: si mostra lo strumento, le sue funzioni, alcuni esempi. Serve a far conoscere e a suscitare interesse, ma non è uso. La sperimentazione pilota: un gruppo limitato usa lo strumento nel lavoro reale, per un periodo definito, con attenzione a che cosa succede. Serve a imparare come lo strumento si inserisce nel lavoro, quali difficoltà emergono, quali pratiche funzionano. L'adozione estesa: lo strumento viene introdotto in modo più ampio, con le pratiche, i supporti e le indicazioni sviluppati durante il pilota. Il passaggio da un momento all'altro dovrebbe dipendere da ciò che si è imparato, non dal calendario. Il sottotema chiede anche la scelta di contesti circoscritti per le prime applicazioni: un gruppo, un'attività, un processo in cui l'AI ha buone probabilità di essere utile, in cui le persone sono disponibili a sperimentare, e in cui gli errori hanno conseguenze limitate. Notate la differenza con il Tema 15: lì la sperimentazione serviva a decidere se l'opportunità valeva; qui serve a capire come introdurla bene.");
    adTag(s, 3);
    const l = [["FiMonitor", "Dimostrazione", "Far conoscere, suscitare interesse", "Non è uso"], ["FiUsers", "Pilota", "Un gruppo, nel lavoro reale, per un periodo definito", "Imparare come si inserisce"], ["FiShare2", "Adozione estesa", "Più ampia, con pratiche e supporti del pilota", "Dopo ciò che si è imparato"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.45, i === 1 ? C.accent6 : C.background2, l[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.62, l[i][0]);
      txt(s, l[i][1], { x: x + 0.15, y: 1.95, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, l[i][2], { x: x + 0.15, y: 2.38, w: 2.56, h: 0.6, fontSize: 12, color: C.text1, align: "center" });
      txt(s, l[i][3], { x: x + 0.15, y: 3.0, w: 2.56, h: 0.5, fontSize: 12, bold: true, color: C.accent1, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.2, 0.17);
    }
    banner(s, 3.8, "Il passaggio dipende da ciò che si è imparato, non dal calendario. Contesti circoscritti: utile, disponibili, errori con poche conseguenze.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Il ciclo del pilota", "Il sottotema descrive le attività di un pilota, che possiamo organizzare in un ciclo. Coinvolgere gli utilizzatori: non solo come destinatari, ma come partecipanti che contribuiscono a definire come usare lo strumento. Sono loro a conoscere il lavoro. Osservare le difficoltà concrete: dove lo strumento non funziona, dove richiede troppo tempo, dove le persone si bloccano. Raccogliere feedback in modo strutturato: non solo 'come va?', ma domande precise, momenti dedicati, un modo semplice per segnalare problemi e idee. Valutare i risultati iniziali: che cosa è cambiato, con quale qualità, a quale costo. Rivedere strumenti e pratiche: cambiare le istruzioni, gli esempi, le indicazioni, a volte lo strumento stesso, o l'attività su cui si usa. E poi ricominciare. Il sottotema parla di apprendimento organizzativo attraverso cicli successivi: ogni ciclo migliora la comprensione, e le pratiche. È lo stesso principio dei cicli di miglioramento continuo, come il ciclo Plan-Do-Check-Act associato a Deming, applicato all'adozione. Lo schema mostra il ciclo.");
    adTag(s, 3);
    const st = [["Coinvolgere", "Gli utilizzatori come partecipanti"], ["Osservare", "Le difficoltà concrete"], ["Raccogliere", "Feedback strutturato"], ["Valutare", "Risultati iniziali, qualità, costo"], ["Rivedere", "Istruzioni, esempi, strumento, attività"]];
    const cx = 3.0, cy = 2.75, r = 1.45;
    st.forEach((e, i) => {
      const a = -Math.PI / 2 + i * 2 * Math.PI / 5;
      const x = cx + r * 1.35 * Math.cos(a) - 0.95, y = cy + r * Math.sin(a) - 0.38;
      shapeBox(s, x, y, 1.9, 0.76, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, (i + 1) + "  " + e[0], { x: x + 0.08, y: y + 0.02, w: 1.75, h: 0.33, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.08, y: y + 0.34, w: 1.75, h: 0.4, fontSize: 9, color: C.text1 });
    });
    s.addShape(pres.shapes.OVAL, { x: cx - 0.55, y: cy - 0.55, w: 1.1, h: 1.1, fill: { color: HEX.a1 }, line: { type: "none" }, objectName: "centro ciclo" });
    txt(s, "Cicli successivi", { x: cx - 0.55, y: cy - 0.55, w: 1.1, h: 1.1, fontSize: 10, bold: true, color: C.background1, align: "center", valign: "middle" });
    await card(s, 6.35, 1.15, 3.15, 1.7, { icon: "FiRefreshCw", inline: true, head: "Apprendimento organizzativo", headSize: 13, bodySize: 12, body: "Ogni ciclo migliora comprensione e pratiche." });
    await card(s, 6.35, 3.0, 3.15, 1.55, { icon: "FiRotateCw", inline: true, head: "Plan-Do-Check-Act", headSize: 13, bodySize: 12, fill: C.accent6, body: "Il miglioramento continuo (Deming), applicato all'adozione." });
  }
  {
    const s = content("Pratiche replicabili", "Il sottotema chiede di condividere le pratiche replicabili e di adattarle a funzioni e gruppi diversi. Il prodotto più prezioso di un pilota non è il risultato in sé, ma ciò che se ne impara: quali attività si prestano, quali istruzioni funzionano, quali errori evitare, come verificare, quanto tempo serve. Queste conoscenze vanno rese trasferibili: esempi documentati, istruzioni riutilizzabili, casi d'uso descritti, errori comuni, suggerimenti. È ciò che permette a chi viene dopo di partire da un punto più avanzato, e di non ripetere gli stessi errori. Ma il sottotema aggiunge una cautela: le pratiche vanno adattate. Ciò che funziona per l'ufficio commerciale di una sede può non funzionare per quello di un'altra, con clienti diversi, o per l'assistenza clienti, con attività diverse. L'adattamento richiede di nuovo il coinvolgimento delle persone, e talvolta un piccolo pilota locale. Nell'esempio dello scenario B, fittizio: dopo il pilota sui documenti commerciali, il gruppo ha prodotto una raccolta di istruzioni per le offerte standard, cinque esempi commentati, una lista degli errori più frequenti e una procedura di verifica. Sono il punto di partenza per gli altri gruppi, non una ricetta da applicare.");
    adTag(s, 3);
    docBox(s, 0.5, 1.15, 4.35, 2.65, "Che cosa si porta via da un pilota (scenario B, fittizio)", "Una raccolta di istruzioni per le offerte standard\n\nCinque esempi commentati\n\nGli errori più frequenti\n\nUna procedura di verifica", { fontSize: 13, fill: C.accent6 });
    await card(s, 5.15, 1.15, 4.35, 1.25, { icon: "FiCopy", inline: true, head: "Rendere trasferibile", headSize: 13, bodySize: 12, body: "Chi viene dopo parte più avanti." });
    await card(s, 5.15, 2.55, 4.35, 1.25, { icon: "FiSliders", inline: true, head: "Adattare", headSize: 13, bodySize: 12, fill: C.accent6, body: "Altre sedi, altri clienti, altre attività." });
    banner(s, 4.0, "Il prodotto più prezioso di un pilota è ciò che se ne impara. Un punto di partenza, non una ricetta.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Locale o replicabile?", "Una distinzione centrale del sottotema, e l'integrazione D: la differenza tra successo locale e replicabilità. Un pilota riuscito non implica automaticamente che la soluzione sia pronta per tutta l'organizzazione. Ci sono buone ragioni per cui un successo locale può non ripetersi. Il gruppo pilota era scelto: persone motivate, interessate, spesso con più competenze digitali della media. Riceveva attenzione speciale: supporto dedicato, contatto diretto con chi guidava il progetto. L'attività era scelta perché adatta. Il contesto era favorevole: un responsabile convinto, carichi di lavoro gestibili. E l'effetto della novità e dell'attenzione può aver migliorato i risultati, come accennato nel Tema 15. Estendendo, si incontrano persone meno motivate, attività meno adatte, responsabili meno coinvolti, supporto più diluito. Il sottotema chiede di chiarire le condizioni necessarie per estendere: quali condizioni del pilota sono state decisive, e sono presenti anche negli altri contesti? Se il successo dipendeva dal supporto dedicato, e il supporto non si può estendere, il successo non si estenderà. La tabella confronta le condizioni tipiche di un pilota e di un'estensione.");
    adTag(s, 3);
    table(s, [["", "Pilota", "Estensione"],
      ["Persone", "Motivate, scelte", "Tutte, anche le meno interessate"],
      ["Attività", "Scelte perché adatte", "Più varie"],
      ["Supporto", "Dedicato, diretto", "Più diluito"],
      ["Responsabili", "Convinti", "Più o meno coinvolti"],
      ["Attenzione", "Alta: effetto novità", "Normale"]],
      { y: 1.15, colW: [1.8, 3.4, 3.8], rowH: 0.45, accentCol: 2, fontSize: 12 });
    banner(s, 4.0, "Quali condizioni del pilota sono state decisive, e ci sono anche altrove? Un pilota riuscito non è pronto per tutti (D).", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("I rischi della fretta", "L'ultimo punto del sottotema: i rischi della diffusione prematura. Ci sono molte pressioni a estendere rapidamente: le licenze sono già pagate, la direzione vuole risultati, i concorrenti annunciano progetti, il pilota è andato bene. Ma una diffusione prematura ha conseguenze note. Amplifica i problemi non risolti: se le istruzioni non sono ancora buone, ora sono usate da cento persone invece che da dieci; se c'è un errore sistematico, si moltiplica. Satura il supporto: le domande arrivano tutte insieme, e non c'è chi risponda. Produce prime esperienze negative, che come visto nel 16.2 determinano l'atteggiamento successivo, e sono difficili da recuperare. Disperde l'apprendimento: con molte persone che provano in modi diversi, è più difficile capire che cosa funziona. E, nei casi peggiori, porta all'abbandono dell'iniziativa, con la conclusione errata che l'AI non serve. La consapevolezza del sottotema: diffondere gradualmente l'AI permette di verificare risultati e condizioni, anziché amplificare rapidamente problemi non compresi. Gradualità non significa lentezza indefinita: significa estendere quando le condizioni sono pronte.");
    adTag(s, 3);
    await iconGrid(s, [
      { icon: "FiMaximize2", head: "Problemi amplificati", body: "Istruzioni imperfette ed errori moltiplicati" },
      { icon: "FiInbox", head: "Supporto saturato", body: "Domande tutte insieme, nessuno che risponda" },
      { icon: "FiThumbsDown", head: "Prime esperienze negative", body: "Difficili da recuperare (16.2)" },
      { icon: "FiShuffle", head: "Apprendimento disperso", body: "Troppi modi diversi, difficile capire che cosa funziona" },
      { icon: "FiXCircle", head: "Abbandono", body: "La conclusione errata che l'AI non serve" },
      { icon: "FiCheckCircle", head: "Gradualità", body: "Non lentezza indefinita: estendere quando le condizioni sono pronte" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Verificare risultati e condizioni, invece di amplificare problemi non compresi.", { h: 0.6, fontSize: 14 });
  }
  keySlide("Un pilota riuscito non è automaticamente pronto per tutta l'organizzazione: si estende quando le condizioni del successo sono presenti anche altrove.", "Sottotema 16.5  ·  Sperimentazione, apprendimento e diffusione graduale  ·  Integrazioni C e D", "Concetto chiave del quinto sottotema. Dimostrazione, pilota ed estensione sono momenti diversi. Il pilota è un ciclo: coinvolgere, osservare, raccogliere feedback, valutare, rivedere, e ricominciare. Il suo prodotto principale sono pratiche replicabili, da adattare. Il successo locale non è replicabilità: conta capire quali condizioni sono state decisive. La diffusione prematura amplifica i problemi. Esercizio suggerito: per un'iniziativa AI in corso o immaginata, scegliere un contesto adatto per un pilota, e indicare quali informazioni bisognerebbe raccogliere per decidere se e come estenderlo.");

  // =====================================================================
  section("16.6 Cultura, fiducia, partecipazione");
  divider("16.6", "Cultura, fiducia, partecipazione", "Una cultura favorevole all'AI promuove confronto e fiducia informata, non entusiasmo obbligatorio", "Sesto sottotema, da comprendere. Il documento lo indica come l'approfondimento delle dinamiche sociali, mentre il 16.2 era la mappa dei fattori. Vediamo gli atteggiamenti verso l'AI, i timori, la partecipazione, la fiducia informata, la possibilità di discutere errori e dubbi, le differenze tra gruppi, i rischi della pressione e dell'entusiasmo acritico, e la distinzione tra opposizione al cambiamento e obiezioni fondate. Integrazione B: la resistenza può essere un'informazione utile.");
  {
    const s = content("Atteggiamenti diversi", "Il sottotema parte dagli atteggiamenti individuali e collettivi verso l'AI. In qualsiasi gruppo convivono atteggiamenti diversi: entusiasmo, curiosità, scetticismo, preoccupazione. Spesso nella stessa persona, in momenti diversi. Nessuno di questi atteggiamenti è giusto o sbagliato in sé. L'entusiasmo porta a sperimentare, ma può portare a sovrastimare le capacità. La curiosità porta a esplorare. Lo scetticismo porta a verificare, ma può bloccare la sperimentazione. La preoccupazione segnala qualcosa che conta per la persona, e merita ascolto. Il sottotema dedica attenzione specifica ai timori relativi a mansioni, competenze e autonomia. Sono timori comprensibili, alimentati dal dibattito pubblico visto nel Tema 13: perderò il lavoro? Le mie competenze varranno ancora? Dovrò lavorare come dice la macchina? Ignorarli o liquidarli come irrazionali non li fa scomparire; li rende sotterranei. Riconoscerli, rispondere con onestà a ciò che si sa, e ammettere ciò che non si sa, è più efficace. Le finalità chiare della direzione, viste nel 16.3, sono parte della risposta.");
    adTag(s, 1);
    const a = [["FiZap", "Entusiasmo", "Porta a sperimentare; rischia di sovrastimare"], ["FiSearch", "Curiosità", "Porta a esplorare"], ["FiHelpCircle", "Scetticismo", "Porta a verificare; può bloccare"], ["FiAlertCircle", "Preoccupazione", "Segnala ciò che conta, merita ascolto"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 1.85, C.background2, a[i][1]);
      await iconCircle(s, x + 0.75, 1.22, 0.6, a[i][0]);
      txt(s, a[i][1], { x: x + 0.1, y: 1.88, w: 1.95, h: 0.38, fontSize: 14, bold: true, color: C.text1, align: "center" });
      txt(s, a[i][2], { x: x + 0.12, y: 2.27, w: 1.91, h: 0.68, fontSize: 11, color: C.text2, align: "center" });
    }
    txt(s, "Timori su mansioni, competenze, autonomia", { x: 0.5, y: 3.15, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    ["Perderò il lavoro?", "Le mie competenze varranno ancora?", "Dovrò lavorare come dice la macchina?"].forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.52, 2.86, 0.55, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.25, "Ignorati, i timori diventano sotterranei. Riconoscerli, dire ciò che si sa e ciò che non si sa.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Fiducia informata", "La sesta domanda guida chiede come sostenere fiducia informata, sperimentazione e partecipazione. Il sottotema parla di fiducia informata e proporzionata alle capacità effettive, e di rischi di pressione all'uso e di entusiasmo acritico. La fiducia informata è una fiducia calibrata: si basa su una comprensione realistica di che cosa lo strumento sa fare bene, che cosa sa fare male, quando sbaglia. È il punto di arrivo dei Temi 3 e 7, visto qui come caratteristica di una cultura organizzativa, non solo individuale. Due squilibri sono possibili. La fiducia eccessiva, o entusiasmo acritico: si accettano gli output senza verifica, si usa lo strumento anche dove non è adatto, si ignorano i segnali di problema. La sfiducia eccessiva: si rifiuta lo strumento anche dove sarebbe utile, si sottolineano solo gli errori. Una cultura che premia l'entusiasmo, per esempio celebrando chi usa di più l'AI senza guardare come, spinge verso il primo squilibrio. Una cultura che punisce gli errori spinge verso il secondo, o verso l'uso nascosto. La consapevolezza del sottotema: una cultura favorevole all'AI promuove confronto e fiducia informata, non entusiasmo obbligatorio.");
    adTag(s, 1);
    const z = [["Sfiducia eccessiva", "Rifiuto anche dove sarebbe utile; si vedono solo gli errori", C.background2, C.text1], ["Fiducia informata", "Calibrata sulle capacità effettive: dove funziona, dove sbaglia (Temi 3 e 7)", C.accent1, C.background1], ["Entusiasmo acritico", "Output senza verifica, uso dove non serve, segnali ignorati", C.background2, C.text1]];
    z.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.0, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.25, w: 2.56, h: 0.45, fontSize: 15, bold: true, color: i === 1 ? C.background1 : C.accent1, align: "center" });
      txt(s, e[1], { x: x + 0.15, y: 1.75, w: 2.56, h: 1.3, fontSize: 12, color: e[3], align: "center" });
    });
    await twoPanel(s, "Premiare l'entusiasmo", "Celebrare chi usa di più, senza guardare come: spinge verso l'entusiasmo acritico.", "Punire gli errori", "Spinge verso la sfiducia, o verso l'uso nascosto.", { y: 3.3, h: 1.55, li: "FiAward", ri: "FiSlash" });
  }
  {
    const s = content("Poter parlare di ciò che non va", "Il sottotema chiede la possibilità di discutere errori, dubbi e risultati insoddisfacenti, e la legittimità delle segnalazioni di problemi. È una condizione decisiva per l'adozione, e per un uso sicuro. Quando le persone usano l'AI, sbagliano: accettano un output sbagliato, la usano su un'attività non adatta, ottengono risultati deludenti. Se possono parlarne senza timore, gli errori diventano apprendimento: per loro, per i colleghi, per l'organizzazione. Se temono di essere giudicate, li nascondono: gli errori si ripetono, i problemi restano invisibili, e le pratiche non migliorano. Amy Edmondson, della Harvard Business School, ha studiato a lungo questo fenomeno con il concetto di sicurezza psicologica: la convinzione condivisa, in un gruppo, che si possa esprimere un dubbio, ammettere un errore o segnalare un problema senza conseguenze negative. I suoi studi, a partire da quello del 1999, mostrano che i gruppi con maggiore sicurezza psicologica apprendono di più. Per l'AI, la sicurezza psicologica significa poter dire 'ho usato l'AI e ho sbagliato', 'non ho capito come usarla', 'secondo me qui non funziona', senza essere visti come incompetenti o resistenti.");
    adTag(s, 1);
    await twoPanel(s, "Se si può parlarne", bullets(["Gli errori diventano apprendimento", "Per la persona, i colleghi, l'organizzazione", "Le pratiche migliorano"], { space: 5 }), "Se si teme il giudizio", bullets(["Gli errori si nascondono e si ripetono", "I problemi restano invisibili", "Le pratiche non migliorano"], { space: 5 }), { y: 1.15, h: 2.2, li: "FiMessageCircle", ri: "FiVolumeX" });
    shapeBox(s, 0.5, 3.55, 9.0, 1.25, C.accent1, "sicurezza psicologica");
    txt(s, [{ text: "Sicurezza psicologica (Edmondson, 1999): ", options: { bold: true, color: C.accent6 } }, { text: "poter dire 'ho usato l'AI e ho sbagliato', 'non ho capito come usarla', 'qui non funziona', senza essere visti come incompetenti o resistenti.", options: { color: C.background1 } }], { x: 0.7, y: 3.55, w: 8.6, h: 1.25, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Opposizione o obiezione fondata?", "L'integrazione B del tema, nella sua forma più completa: la resistenza può essere un'informazione utile. Il sottotema chiede di distinguere tra opposizione al cambiamento e obiezioni fondate. Quando le persone resistono all'uso di uno strumento, la reazione organizzativa più comune è considerarle resistenti al cambiamento, e cercare di convincerle. Ma le obiezioni possono segnalare problemi reali. Il documento ne indica quattro tipi. Scarsa adeguatezza: lo strumento non serve davvero per quelle attività. Problemi di qualità: gli output non sono abbastanza buoni, e chi conosce il lavoro lo vede. Carichi aggiuntivi: lo strumento crea lavoro, per esempio di verifica o di correzione, che nessuno ha considerato, come visto nel Tema 13. Ambiguità nelle responsabilità: non è chiaro chi risponde degli errori, e le persone non vogliono rispondere di ciò che non controllano. Esistono anche resistenze di altro tipo, per abitudine o per timori generici. Ma trattare tutte le obiezioni come resistenza fa perdere informazioni preziose. La domanda utile davanti a un'obiezione è: che cosa ci sta dicendo? La tabella propone esempi fittizi.");
    adTag(s, 1);
    table(s, [["Obiezione (esempio fittizio)", "Che cosa potrebbe segnalare"],
      ["'Per le mie offerte tecniche non serve'", "Scarsa adeguatezza allo strumento"],
      ["'Le bozze hanno sempre errori sui codici'", "Problemi di qualità"],
      ["'Ci metto più tempo a controllarle che a scriverle'", "Carichi aggiuntivi (Tema 13)"],
      ["'Se il cliente riceve un errore, chi ne risponde?'", "Ambiguità nelle responsabilità"]],
      { y: 1.15, colW: [4.8, 4.2], rowH: 0.52, accentCol: 1, fontSize: 12, blankCorner: false });
    banner(s, 3.9, "Davanti a un'obiezione: che cosa ci sta dicendo? Trattare tutto come resistenza fa perdere informazioni (B).", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Partecipazione", "Gli ultimi punti del sottotema: la partecipazione delle persone al percorso di adozione, l'ascolto delle esperienze positive e negative, la collaborazione e l'apprendimento tra colleghi, le differenze culturali e professionali tra gruppi, e il coinvolgimento per migliorare le decisioni organizzative. La partecipazione non è un gesto di cortesia: migliora le decisioni. Chi svolge il lavoro sa dove l'AI può servire, quali eccezioni esistono, quali problemi emergeranno. Coinvolgerlo nella scelta delle attività, nella definizione delle pratiche, nella valutazione dei risultati porta a soluzioni migliori, e anche a una maggiore disponibilità a usarle. Forme concrete di partecipazione: gruppi di lavoro sui casi d'uso, momenti di confronto periodici, raccolta di proposte, persone di riferimento all'interno dei gruppi, che riprenderemo nel 16.7. Le differenze culturali e professionali tra gruppi vanno rispettate: professioni diverse hanno rapporti diversi con la tecnologia, con l'autonomia, con l'errore. Ciò che funziona per un team di marketing può non funzionare per un gruppo di tecnici o di legali. Il coinvolgimento serve anche a vedere queste differenze.");
    adTag(s, 1);
    await iconGrid(s, [
      { icon: "FiUsers", head: "Gruppi di lavoro", body: "Sui casi d'uso e sulle pratiche" },
      { icon: "FiMessageSquare", head: "Confronto periodico", body: "Esperienze positive e negative" },
      { icon: "FiInbox", head: "Raccolta di proposte", body: "Usi, problemi, idee" },
      { icon: "FiUserCheck", head: "Riferimenti nei gruppi", body: "Colleghi a cui chiedere (16.7)" },
      { icon: "FiGrid", head: "Differenze tra professioni", body: "Tecnologia, autonomia, errore: rapporti diversi" },
      { icon: "FiCheckCircle", head: "Decisioni migliori", body: "Chi lavora sa dove serve, e dove no" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "La partecipazione non è cortesia: migliora le decisioni, e la disponibilità a usarle.", { h: 0.6, fontSize: 14 });
  }
  keySlide("Una cultura favorevole all'AI promuove confronto e fiducia informata, non entusiasmo obbligatorio. E le obiezioni sono spesso informazioni.", "Sottotema 16.6  ·  Cultura organizzativa, fiducia e partecipazione  ·  Integrazione B", "Concetto chiave del sesto sottotema. Atteggiamenti diversi convivono, e i timori vanno riconosciuti. La fiducia informata sta tra la sfiducia e l'entusiasmo acritico, e la cultura può spingere verso l'uno o l'altro. Poter parlare di errori e dubbi, la sicurezza psicologica, è decisivo per apprendere. Le obiezioni possono segnalare inadeguatezza, qualità scarsa, carichi aggiuntivi, responsabilità ambigue. La partecipazione migliora le decisioni. Esercizio suggerito: ciascuno scrive un dubbio o un'obiezione sull'uso dell'AI nel proprio lavoro; in gruppo si discute che cosa potrebbe segnalare e come l'organizzazione potrebbe tenerne conto.");
  // =====================================================================
  section("16.7 Supporto e coordinamento");
  divider("16.7", "Supporto e coordinamento", "L'autonomia individuale è più efficace quando esistono riferimenti operativi e canali di aiuto accessibili", "Settimo sottotema, con priorità media, a livello di conoscenza. Il documento distingue: il 16.3 riguarda orientamento e responsabilità manageriali, il 16.7 i meccanismi di supporto quotidiano; il 16.6 le dinamiche culturali, il 16.7 i riferimenti organizzativi. Vediamo la chiarezza sugli strumenti e sugli usi consentiti, materiali ed esempi, referenti e canali di supporto, raccolta di esigenze, coordinamento tra funzioni, equilibrio tra autonomia e pratiche comuni, gestione degli usi non autorizzati. Integrazione A. Il confine con i Temi 17 e 18: parliamo di supporto operativo, non di governance formale, norme o sicurezza.");
  {
    const s = content("Che cosa si può usare, e come", "I primi punti del sottotema riguardano la chiarezza: sugli strumenti approvati, sugli usi consentiti, e l'orientamento nella scelta tra gli strumenti disponibili. Abbiamo visto nel 16.2 che la mancanza di chiarezza è un ostacolo: nel dubbio, molte persone si astengono, e altre usano ciò che trovano. Le persone hanno bisogno di risposte semplici a domande semplici. Quali strumenti posso usare per il lavoro? Per quali attività? Quali informazioni posso inserire, e quali no? Che cosa devo verificare prima di usare un risultato? A chi chiedo se ho un dubbio? Il sottotema chiede che le indicazioni siano semplici, comprensibili e applicabili: non un regolamento di trenta pagine, ma poche indicazioni chiare, con esempi. Le regole formali, gli aspetti normativi e di sicurezza, saranno trattati nei Temi 17 e 18; qui ci interessa la loro traduzione operativa, ciò che serve a una persona nel momento in cui deve decidere se e come usare uno strumento. L'esempio in slide mostra una scheda di indicazioni, fittizia, del tipo che un'azienda potrebbe distribuire.");
    adTag(s, 3);
    docBox(s, 0.5, 1.15, 5.4, 3.0, "Indicazioni d'uso (esempio fittizio)", "Strumento approvato: l'assistente aziendale, con l'account di lavoro.\nSì: bozze, sintesi, riformulazioni, idee.\nNo: dati personali di clienti e colleghi in strumenti non approvati.\nSempre: verificare cifre, nomi e condizioni prima di inviare.\nDubbi: chiedere al referente del proprio reparto.", { fontSize: 12, fill: C.accent6 });
    rowsLabel(s, [["Semplici", "Poche indicazioni, non trenta pagine"], ["Comprensibili", "Con esempi"], ["Applicabili", "Nel momento della decisione"]], { y: 1.15, h: 0.85, lw: 1.3, x: 6.15, w: 3.35, fontSize: 11 });
    banner(s, 4.3, "Le regole formali sono dei Temi 17 e 18: qui la loro traduzione operativa.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Materiali e referenti", "Il sottotema indica due forme di supporto quotidiano. I materiali, esempi e istruzioni riutilizzabili: raccolte di istruzioni per le attività frequenti, esempi commentati di buon uso, guide brevi per le situazioni tipiche, liste degli errori comuni. Sono il prodotto naturale dei piloti, come visto nel 16.5, e permettono alle persone di non partire da zero. Funzionano se sono facili da trovare, aggiornati e vicini alle attività reali. I referenti e i canali di supporto: persone a cui rivolgersi quando si ha un dubbio o un problema. Una forma diffusa sono i referenti di reparto, a volte chiamati 'champion' o 'ambasciatori': colleghi con più esperienza che dedicano una parte del loro tempo ad aiutare gli altri, a raccogliere problemi, a condividere pratiche. Hanno il vantaggio di conoscere il lavoro del reparto, e di essere vicini. Per funzionare, hanno bisogno di tempo riconosciuto per questo ruolo, di un collegamento con chi coordina l'adozione, e di non diventare l'unico punto di riferimento, con il rischio di sovraccarico. A questi si aggiungono canali più strutturati, come uno spazio di domande e risposte condiviso o un supporto tecnico.");
    adTag(s, 3);
    await card(s, 0.5, 1.15, 4.35, 2.7, { icon: "FiFolder", head: "Materiali riutilizzabili", headSize: 15, bodySize: 12, body: bullets(["Istruzioni per le attività frequenti", "Esempi commentati, guide brevi", "Errori comuni", "Facili da trovare, aggiornati, vicini al lavoro"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.7, { icon: "FiUserCheck", head: "Referenti di reparto", headSize: 15, bodySize: 12, fill: C.accent6, body: bullets(["Colleghi più esperti, vicini al lavoro", "Aiutano, raccolgono problemi, condividono", "Servono tempo riconosciuto e collegamento", "Rischio di sovraccarico"], { space: 4 }) });
    banner(s, 4.05, "Nello scenario B, referenti e confronto tra colleghi; nello scenario A, solo l'iniziativa individuale.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Raccogliere e coordinare", "Il sottotema chiede di raccogliere problemi, esigenze e proposte; di coordinare tra funzioni e reparti; di condividere le esperienze efficaci; di ridurre duplicazioni e frammentazione. Quando l'adozione cresce, emergono problemi di coordinamento. Reparti diversi scelgono strumenti diversi per esigenze simili. Più gruppi sviluppano in parallelo le stesse istruzioni, o risolvono gli stessi problemi, senza saperlo. Le buone pratiche restano locali. Le esigenze che richiederebbero un intervento comune, come un'integrazione o una nuova funzione, non arrivano a chi può decidere. Un coordinamento leggero può aiutare molto: un punto in cui le esigenze e le proposte vengono raccolte; momenti periodici di scambio tra i referenti dei diversi reparti; uno spazio condiviso per le pratiche e i materiali; qualcuno che abbia una visione d'insieme. Alcune organizzazioni costruiscono strutture dedicate, come i centri di eccellenza AI: il documento chiede di solo accennarvi. Per la maggior parte delle aziende, il punto non è creare una struttura, ma assicurarsi che le informazioni circolino e che qualcuno se ne occupi.");
    adTag(s, 3);
    await twoPanel(s, "Senza coordinamento", bullets(["Strumenti diversi per esigenze simili", "Stesse istruzioni sviluppate in parallelo", "Buone pratiche locali", "Esigenze comuni che non arrivano a chi decide"], { space: 4 }), "Un coordinamento leggero", bullets(["Un punto di raccolta di esigenze e proposte", "Scambi periodici tra referenti", "Uno spazio condiviso per pratiche e materiali", "Qualcuno con una visione d'insieme"], { space: 4 }), { y: 1.15, h: 2.75, li: "FiGrid", ri: "FiGitMerge" });
    banner(s, 4.1, "Non serve per forza una struttura (centri di eccellenza: solo un accenno): serve che le informazioni circolino.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Autonomia e pratiche comuni", "Il sottotema chiede di trovare un equilibrio tra autonomia individuale e pratiche comuni, e di distinguere tra supporto operativo e governance formale. L'autonomia ha molti vantaggi: le persone conoscono il proprio lavoro, trovano usi che nessuno aveva previsto, adattano lo strumento alle proprie esigenze. Ma un'autonomia senza riferimenti produce frammentazione, pratiche incoerenti, rischi non visti, e lascia sole le persone meno esperte. Le pratiche comuni danno coerenza, facilitano l'apprendimento e il controllo, ma se sono troppe o troppo rigide soffocano la sperimentazione. L'equilibrio dipende dall'attività: per attività con rischi elevati o con effetti verso l'esterno servono pratiche comuni più definite; per attività interne e a basso rischio, più autonomia. La consapevolezza del sottotema lo riassume: l'autonomia individuale è più efficace quando esistono riferimenti operativi e canali di aiuto accessibili. Quanto alla distinzione con la governance formale: il supporto operativo aiuta le persone a usare bene gli strumenti; la governance definisce regole, responsabilità, controlli e conformità a livello di organizzazione. Sono collegati, ma diversi: la governance sarà trattata nei Temi 17 e 18.");
    adTag(s, 3);
    s.addShape(pres.shapes.RECTANGLE, { x: 0.5, y: 1.75, w: 9.0, h: 0.08, fill: { color: HEX.a3 }, line: { type: "none" }, objectName: "asse" });
    txt(s, "Più autonomia", { x: 0.5, y: 1.15, w: 3.0, h: 0.5, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Più pratiche comuni", { x: 6.5, y: 1.15, w: 3.0, h: 0.5, fontSize: 14, bold: true, color: C.accent1, align: "right" });
    docBox(s, 0.5, 2.0, 4.35, 1.4, "Attività interne, basso rischio", "Bozze per uso personale, idee, sintesi di lavoro: più spazio all'iniziativa.", { fontSize: 12 });
    docBox(s, 5.15, 2.0, 4.35, 1.4, "Rischi elevati, effetti all'esterno", "Comunicazioni ai clienti, documenti contrattuali: pratiche più definite.", { fontSize: 12, fill: C.accent6 });
    rowsLabel(s, [["Supporto operativo", "Aiuta le persone a usare bene gli strumenti (16.7)"], ["Governance formale", "Regole, responsabilità, controlli, conformità (Temi 17 e 18)"]], { y: 3.6, h: 0.55, lw: 2.2 });
  }
  {
    const s = content("Gestire gli usi non autorizzati", "L'ultimo punto del sottotema, e l'integrazione A nella sua forma operativa: il riconoscimento e la gestione degli usi non autorizzati. Il documento propone una lettura equilibrata. Chiarezza sugli strumenti consentiti e supporto alle esigenze reali possono ridurre gli incentivi all'uso improprio di servizi non autorizzati, senza eliminarlo automaticamente. Che cosa significa in pratica? Primo, capire: perché le persone usano strumenti non approvati? Quali esigenze soddisfano? Spesso la risposta indica che cosa manca nell'offerta aziendale. Secondo, offrire alternative: se esiste uno strumento approvato adeguato, facile da usare e conosciuto, l'incentivo a usare altro si riduce molto. Terzo, chiarire: indicazioni semplici su che cosa non si può fare, e perché, con particolare attenzione alle informazioni aziendali. Quarto, accompagnare: chi usava uno strumento non autorizzato ha spesso sviluppato competenze utili, che vanno portate sugli strumenti approvati. E infine, controllare dove serve: alcuni usi comportano rischi che richiedono misure specifiche, che saranno trattate nei Temi 17 e 18. Il documento è chiaro su un punto: lo Shadow AI va considerato qui come fenomeno di adozione, non come tema tecnico di cybersecurity.");
    adTag(s, 3);
    numList(s, ["Capire: perché? quali esigenze soddisfa?", "Offrire alternative: approvate, adeguate, facili, conosciute", "Chiarire: che cosa non si può fare, e perché", "Accompagnare: portare le competenze sugli strumenti approvati", "Controllare dove serve (Temi 17 e 18)"], { y: 1.15, h: 0.5, fontSize: 13 });
    banner(s, 4.1, "Chiarezza e supporto riducono gli incentivi allo Shadow AI, senza eliminarlo automaticamente (A).", { h: 0.8, fontSize: 14 });
  }
  keySlide("L'autonomia individuale è più efficace quando esistono riferimenti operativi chiari e canali di aiuto accessibili.", "Sottotema 16.7  ·  Regole operative, supporto e coordinamento dell'adozione  ·  Integrazione A", "Concetto chiave del settimo sottotema. Servono indicazioni semplici su strumenti e usi consentiti. Materiali riutilizzabili e referenti di reparto sono il supporto quotidiano. Un coordinamento leggero fa circolare esigenze e pratiche. L'equilibrio tra autonomia e pratiche comuni dipende dal rischio. Gli usi non autorizzati si gestiscono capendo, offrendo alternative, chiarendo, accompagnando e controllando dove serve. Esercizio suggerito: scrivere in gruppo una scheda di indicazioni d'uso di cinque righe per il proprio reparto, con strumenti consentiti, usi sì e no, verifica e a chi rivolgersi.");

  // =====================================================================
  section("16.8 Monitoraggio e sostenibilità");
  divider("16.8", "Monitoraggio e sostenibilità", "Monitorare significa osservare non soltanto quanto l'AI viene usata, ma come, perché e con quali risultati", "L'ultimo sottotema, da comprendere, e uno di quelli con maggiore attenzione didattica. Il documento distingue: il 16.1 definisce il fenomeno dell'adozione, il 16.8 ne osserva continuità, qualità e impatti; il 16.5 riguarda il passaggio all'estensione, il 16.8 il consolidamento nel tempo. Vediamo che cosa osservare, la differenza tra diffusione, intensità e qualità, tra metriche di adozione e indicatori di impatto, i costi, la sostenibilità, e la possibilità di modificare, ridimensionare o interrompere. Integrazione D. Sistemi avanzati di misurazione vanno solo accennati; le dimensioni del valore sono quelle del Tema 12.");
  {
    const s = content("Diffusione, intensità, qualità", "L'ottava domanda guida: come capire se l'uso è efficace e sostenibile nel tempo? Il sottotema parte dalla differenza tra diffusione, intensità e qualità dell'utilizzo, e dalla frequenza e continuità d'uso. La diffusione dice quante persone usano lo strumento. L'intensità dice quanto lo usano: con quale frequenza, per quante attività, con quale continuità nel tempo. La qualità dice come lo usano: su attività adatte, in modo appropriato, con verifica, con buoni risultati. Le tre dimensioni possono divergere. Molte persone che usano lo strumento una volta al mese: alta diffusione, bassa intensità. Poche persone che lo usano ogni giorno su attività importanti: bassa diffusione, alta intensità. Molte persone che lo usano spesso, ma senza verifica o per attività inadatte: alta diffusione e intensità, bassa qualità. La continuità è particolarmente informativa: un uso che si mantiene nel tempo indica che lo strumento è entrato nelle abitudini; un uso che cala dopo le prime settimane indica che qualcosa non funziona, come visto nel 16.1. La diffusione è la più facile da misurare, la qualità la più difficile: per questo la tentazione è guardare solo la prima.");
    adTag(s, 4);
    const d = [["FiUsers", "Diffusione", "Quante persone?", "Facile da misurare"], ["FiActivity", "Intensità", "Quanto: frequenza, attività, continuità", "Abbastanza facile"], ["FiAward", "Qualità", "Come: attività adatte, verifica, risultati", "Difficile da osservare"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.3, i === 2 ? C.accent6 : C.background2, d[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.62, d[i][0]);
      txt(s, d[i][1], { x: x + 0.15, y: 1.95, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.15, y: 2.37, w: 2.56, h: 0.55, fontSize: 12, color: C.text1, align: "center" });
      txt(s, d[i][3], { x: x + 0.15, y: 2.95, w: 2.56, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "center" });
    }
    banner(s, 3.7, "Possono divergere. La continuità nel tempo è molto informativa. La tentazione è guardare solo la più facile.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Adozione o impatto?", "La distinzione centrale del sottotema: metriche di adozione e indicatori di impatto. Le metriche di adozione descrivono l'uso: numero di utenti attivi, frequenza, numero di richieste, attività coperte. Sono spesso disponibili direttamente dagli strumenti, ed è per questo che sono le più usate nei rapporti. Gli indicatori di impatto descrivono gli effetti sul lavoro e sui risultati: tempo per completare un'attività, qualità degli output, errori, soddisfazione dei clienti, capacità operativa, come visto nel Tema 12. Sono più difficili da raccogliere, e spesso richiedono un confronto con la situazione precedente, come visto nel Tema 15. Le metriche di adozione sono utili per capire se lo strumento viene usato, e dove. Ma non dicono se l'uso produce benefici. È possibile un'alta adozione con impatto nullo, o negativo. La tabella confronta i due tipi di indicatori nello scenario dei documenti commerciali. Il sottotema chiede di osservare entrambi, e di non trattare i primi come prova dei secondi. Nello scenario A del modulo si osservava il numero di accessi; nello scenario B uso, qualità, problemi e risultati.");
    adTag(s, 4);
    table(s, [["Scenario fittizio", "Metriche di adozione", "Indicatori di impatto"],
      ["Che cosa misurano", "L'uso", "Gli effetti su lavoro e risultati"],
      ["Esempi", "Utenti attivi, richieste al giorno, documenti generati", "Tempo per offerta, errori nelle offerte, tasso di risposta dei clienti"],
      ["Fonte", "Spesso lo strumento stesso", "Processi, clienti, confronto con il prima"],
      ["Dicono", "Se e dove viene usato", "Se l'uso produce benefici (Tema 12)"]],
      { y: 1.15, colW: [2.0, 3.4, 3.6], rowH: 0.55, accentCol: 2, fontSize: 12 });
    banner(s, 4.05, "Alta adozione con impatto nullo, o negativo, è possibile. Osservare entrambi.", { h: 0.8, fontSize: 15 });
  }
  {
    const s = content("Che cosa osservare", "Il sottotema elenca diverse cose da osservare nel tempo, che vanno oltre i numeri dell'uso. Raccogliamole in un piccolo cruscotto, utile come traccia. L'uso effettivo: diffusione, intensità, continuità. I risultati osservati nelle attività: tempo, qualità, errori, effetti sul servizio. Il feedback e la soddisfazione degli utilizzatori: che cosa dicono, che cosa trovano utile, che cosa li frustra. Le difficoltà e gli ostacoli persistenti: quelli che non si sono risolti con il tempo, e che probabilmente sono strutturali. I costi di supporto e aggiornamento: quanto costa mantenere l'adozione, in tempo dei referenti, materiali, licenze, interventi. L'evoluzione dei bisogni formativi: che cosa le persone hanno bisogno di imparare ora, che non serviva all'inizio. La revisione delle pratiche operative: le istruzioni e le indicazioni sono ancora adeguate? La combinazione di dati quantitativi, come l'uso e i tempi, e qualitativi, come il feedback e le difficoltà, è importante: i numeri dicono che cosa succede, le persone dicono perché. Il documento chiede di solo accennare ai sistemi avanzati di misurazione: per la maggior parte delle organizzazioni, poche osservazioni regolari valgono più di un sistema complesso.");
    adTag(s, 4);
    await iconGrid(s, [
      { icon: "FiActivity", head: "Uso effettivo", body: "Diffusione, intensità, continuità" },
      { icon: "FiTarget", head: "Risultati nelle attività", body: "Tempo, qualità, errori, servizio" },
      { icon: "FiMessageCircle", head: "Feedback degli utilizzatori", body: "Che cosa è utile, che cosa frustra" },
      { icon: "FiAlertTriangle", head: "Ostacoli persistenti", body: "Probabilmente strutturali" },
      { icon: "FiDollarSign", head: "Costi di supporto", body: "Referenti, materiali, licenze, interventi" },
      { icon: "FiBookOpen", head: "Bisogni formativi e pratiche", body: "Che cosa serve ora? Le indicazioni reggono?" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "I numeri dicono che cosa succede, le persone dicono perché. Poche osservazioni regolari bastano.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Diffondere non è adottare", "L'integrazione D del tema: diffondere rapidamente non significa adottare efficacemente. Numerosità degli utenti e velocità di distribuzione non dimostrano benefici o sostenibilità. Il sottotema segnala anche il rischio di amplificare inefficienze attraverso una diffusione rapida: se un'attività era inefficiente, e l'AI la accelera, una diffusione rapida moltiplica l'inefficienza, come visto nel Tema 13. Il grafico confronta, con dati inventati, due iniziative in due aziende fittizie. L'iniziativa A ha distribuito rapidamente lo strumento a tutti: in tre mesi l'ottanta per cento delle persone lo aveva usato almeno una volta; ma l'uso abituale si è stabilizzato intorno al 15 per cento, e i benefici osservati sono modesti. L'iniziativa B è partita con un pilota e ha esteso gradualmente: in tre mesi solo il 20 per cento aveva accesso; ma l'uso abituale tra chi aveva accesso è stato alto, e i benefici osservati maggiori. Alla fine dell'anno, l'iniziativa B aveva meno utenti 'totali' ma più utenti abituali e più impatto. Un rapporto che mostrasse solo gli utenti totali al terzo mese avrebbe premiato l'iniziativa sbagliata.");
    adTag(s, 4);
    const lb = ["M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "M11", "M12"];
    lineChart(s, lb, [
      { name: "A: hanno usato almeno una volta", values: [40, 65, 80, 83, 85, 86, 87, 87, 88, 88, 88, 88], color: HEX.a2 },
      { name: "A: uso abituale", values: [12, 18, 17, 16, 15, 15, 15, 14, 15, 15, 15, 15], color: HEX.a5 },
      { name: "B: uso abituale", values: [3, 6, 10, 14, 18, 23, 28, 32, 36, 39, 41, 43], color: HEX.a1 },
    ], { x: 0.5, y: 1.05, w: 5.6, h: 3.5, min: 0, max: 100, legend: true, title: "% dei dipendenti, due iniziative (dati inventati)" });
    await card(s, 6.35, 1.15, 3.15, 1.65, { icon: "FiFastForward", inline: true, head: "Rapida", headSize: 13, bodySize: 12, body: "Molti hanno provato, pochi usano davvero." });
    await card(s, 6.35, 2.95, 3.15, 1.6, { icon: "FiTrendingUp", inline: true, head: "Graduale", headSize: 13, bodySize: 12, fill: C.accent6, body: "Meno utenti totali, più abituali, più impatto (D)." });
  }
  {
    const s = content("Sostenibile nel tempo", "Il sottotema chiede di valutare la sostenibilità dell'uso nel tempo. Un'adozione sostenibile è un'adozione che regge quando l'attenzione iniziale finisce: quando il progetto si chiude, quando i referenti cambiano ruolo, quando lo strumento si aggiorna, quando arriva una nuova priorità. Alcune domande per valutarla. L'uso dipende da poche persone, o è diffuso nei gruppi? Se il referente se ne va, che cosa succede? I materiali e le indicazioni vengono aggiornati, e da chi? I costi, di licenze e di supporto, sono sostenibili rispetto ai benefici osservati? Lo strumento è integrato nei processi, o è un'aggiunta che si può abbandonare senza che nessuno se ne accorga? I nuovi arrivati imparano a usarlo? Ci sono segnali di deterioramento, come un calo della qualità d'uso, verifiche sempre più superficiali, o un ritorno ai vecchi metodi? Come visto nel Tema 14 per le fonti informative e nel Tema 15 per i prototipi, molti sistemi funzionano finché qualcuno se ne occupa attivamente, e si degradano quando l'attenzione cala. La sostenibilità va progettata, non si produce da sola.");
    adTag(s, 4);
    qGrid(s, ["L'uso dipende da poche persone?", "Se il referente se ne va?", "Chi aggiorna materiali e indicazioni?", "Costi sostenibili rispetto ai benefici?", "È integrato, o un'aggiunta abbandonabile?", "I nuovi arrivati imparano a usarlo?"], 3, 1.12, 1.05, 12);
    banner(s, 3.65, "Regge quando l'attenzione iniziale finisce? Attenzione ai segnali di deterioramento: verifiche superficiali, ritorno ai vecchi metodi.", { h: 0.9, fontSize: 13 });
    txt(s, "La sostenibilità va progettata, non si produce da sola (Temi 14 e 15).", { x: 0.5, y: 4.62, w: 9, h: 0.3, fontSize: 12, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Che cosa decidere", "Gli ultimi punti del sottotema: la possibilità di modificare, ridimensionare o interrompere le iniziative, e l'apprendimento e il miglioramento continuo. Il monitoraggio serve a decidere. Alcune decisioni possibili. Consolidare: l'iniziativa funziona, si mantiene e si cura. Estendere: le condizioni sono presenti anche altrove, come visto nel 16.5. Modificare: cambiare le pratiche, la formazione, il supporto, le attività su cui si usa lo strumento. Ridimensionare: limitare l'uso alle attività o ai gruppi in cui produce benefici, e abbandonarlo dove non li produce. Interrompere: l'iniziativa non produce benefici sufficienti, o i costi e i rischi superano i vantaggi. Come per la sperimentazione del Tema 15, l'interruzione o il ridimensionamento non sono fallimenti: sono decisioni corrette sulla base di ciò che si è osservato. È la prima precisazione del tema applicata al livello dell'organizzazione: l'adozione non è sempre desiderabile. Un'organizzazione che non ridimensiona mai nulla probabilmente non sta guardando davvero i risultati. La consapevolezza del sottotema: monitorare significa osservare non soltanto quanto l'AI viene usata, ma come, perché e con quali risultati.");
    adTag(s, 4);
    const d = [["Consolidare", "Funziona: mantenere e curare"], ["Estendere", "Condizioni presenti altrove (16.5)"], ["Modificare", "Pratiche, formazione, supporto, attività"], ["Ridimensionare", "Solo dove produce benefici"], ["Interrompere", "Benefici insufficienti, costi o rischi maggiori"]];
    d.forEach((e, i) => {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.72, 1.85, i >= 3 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.1, y: 1.22, w: 1.55, h: 0.45, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.1, y: 1.7, w: 1.55, h: 1.2, fontSize: 11, color: C.text1 });
    });
    shapeBox(s, 0.5, 3.2, 9.0, 0.75, C.accent1, "non fallimenti");
    txt(s, "Ridimensionare o interrompere non sono fallimenti: sono decisioni corrette su ciò che si è osservato.", { x: 0.7, y: 3.2, w: 8.6, h: 0.75, fontSize: 14, bold: true, color: C.background1, valign: "middle" });
    txt(s, "Un'organizzazione che non ridimensiona mai nulla probabilmente non sta guardando davvero i risultati.", { x: 0.5, y: 4.1, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.accent5 });
  }
  keySlide("Monitorare significa osservare non soltanto quanto l'AI viene usata, ma come, perché e con quali risultati. Diffondere rapidamente non è adottare efficacemente.", "Sottotema 16.8  ·  Monitoraggio, consolidamento e sostenibilità dell'adozione  ·  Integrazione D", "Concetto chiave dell'ultimo sottotema. Diffusione, intensità e qualità sono diverse. Le metriche di adozione non sono indicatori di impatto. Da osservare: uso, risultati, feedback, ostacoli persistenti, costi, bisogni formativi, pratiche. La diffusione rapida può produrre molti utenti e poco impatto, e amplificare inefficienze. La sostenibilità va progettata. Il monitoraggio porta a consolidare, estendere, modificare, ridimensionare o interrompere. Esercizio suggerito: per un'iniziativa AI reale o immaginata, scegliere due metriche di adozione e due indicatori di impatto, e indicare quale risultato porterebbe a ridimensionarla.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quando c'è adozione reale: quando l'uso è integrato in modo appropriato e continuo nel lavoro, e produce risultati, non quando ci sono licenze e accessi. Perché la disponibilità non basta: servono utilità percepita, competenze, tempo, condizioni operative. Ostacoli delle persone o delle condizioni: spesso strutturali, e i rimedi sono diversi. Responsabilità: la direzione orienta e dà risorse, i manager creano condizioni, i collaboratori sperimentano e segnalano. Formazione: avvia l'apprendimento, ma il trasferimento nel lavoro richiede strumenti, tempo, esercizio e supporto. Fiducia, sperimentazione, partecipazione: fiducia informata, sicurezza psicologica, obiezioni ascoltate come informazioni. Supporto e coordinamento: indicazioni semplici, materiali, referenti, coordinamento leggero. Efficacia e sostenibilità: osservare qualità e impatto, non solo diffusione, ed essere pronti a modificare, ridimensionare o interrompere. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Quando c'è adozione reale?", "Uso appropriato, continuo, con risultati"], ["Perché lo strumento non basta?", "Utilità percepita, competenze, tempo, condizioni"], ["Persone o condizioni?", "Spesso strutturali; rimedi diversi"], ["Quali responsabilità?", "Direzione orienta, manager abilitano, tutti segnalano"], ["Perché la formazione non basta?", "Trasferimento: strumenti, tempo, esercizio, supporto"], ["Fiducia e partecipazione?", "Fiducia informata, sicurezza psicologica, obiezioni ascoltate"], ["Quale supporto?", "Indicazioni semplici, materiali, referenti, coordinamento"], ["Efficace e sostenibile?", "Qualità e impatto; modificare o interrompere"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.9;
      shapeBox(s, x, y, 4.4, 0.8, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.06, w: 3.8, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.34, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere disponibilità tecnologica, uso, adozione e valore; riconoscere i principali fattori abilitanti e gli ostacoli all'adozione; comprendere il ruolo della direzione e dei responsabili aziendali; spiegare perché la formazione iniziale non garantisce l'applicazione delle competenze; comprendere il valore della sperimentazione progressiva e del feedback; distinguere fiducia informata ed entusiasmo acritico; riconoscere che dubbi e resistenze possono segnalare problemi reali; comprendere il fenomeno dello Shadow AI dal punto di vista organizzativo; riconoscere il ruolo di supporto, indicazioni pratiche e coordinamento; distinguere diffusione rapida e adozione efficace; comprendere perché monitorare anche la qualità dell'uso e i risultati; riconoscere quando un'iniziativa dovrebbe essere adattata, ridimensionata o interrotta.");
    const r = ["Disponibilità, uso, adozione, valore", "Fattori abilitanti e ostacoli", "Ruolo di direzione e responsabili", "Formazione e applicazione", "Sperimentazione progressiva e feedback", "Fiducia informata o entusiasmo acritico", "Dubbi e resistenze come segnali", "Lo Shadow AI come fenomeno organizzativo", "Supporto, indicazioni, coordinamento", "Diffusione rapida o adozione efficace", "Monitorare qualità e risultati", "Adattare, ridimensionare, interrompere"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Domande per un'iniziativa di adozione", "Traduciamo il modulo in una scheda pratica: le domande da porsi quando si introduce, si gestisce o si partecipa a un'iniziativa di adozione dell'AI. Cinque colonne, come le dimensioni del tema. Adozione: a che livello siamo, disponibilità, uso, adozione, valore? L'uso è utile per le attività reali? Quali ostacoli, individuali o strutturali? Persone: le finalità sono chiare? I responsabili creano condizioni, con tempo e ascolto? Le obiezioni vengono ascoltate? Si può parlare di errori? Competenze: la formazione è adatta al ruolo, con esempi vicini al lavoro? Ci sono occasioni per applicare e supporto dopo? Diffusione: c'è stato un pilota? Che cosa ne abbiamo imparato? Le condizioni del successo ci sono anche altrove? Ci sono indicazioni semplici, materiali, referenti? Risultati: osserviamo qualità e impatto, non solo utenti? È sostenibile? Che cosa ci porterebbe a modificare, ridimensionare o interrompere? Sono domande utili a chiunque, non solo a chi guida il progetto. E valgono anche per questo percorso di formazione.");
    const f = [["Adozione", ["A che livello?", "Utile per le attività reali?", "Ostacoli strutturali?"], C.background2], ["Persone", ["Finalità chiare?", "Tempo e ascolto?", "Obiezioni ascoltate?", "Si parla di errori?"], C.accent6], ["Competenze", ["Formazione per ruolo?", "Occasioni per applicare?", "Supporto dopo?"], C.background2], ["Diffusione", ["Pilota, che cosa imparato?", "Condizioni altrove?", "Indicazioni, referenti?"], C.accent6], ["Risultati", ["Qualità e impatto?", "Sostenibile?", "Quando ridimensionare?"], C.background2]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.72, 3.0, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.1, y: 1.22, w: 1.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.1, y: 1.68, w: 1.58, h: 2.4, fontSize: 11, color: C.text1 });
    }
    banner(s, 4.3, "Domande utili a chiunque, non solo a chi guida il progetto. E valgono anche per questo percorso.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Che cosa evitare", "Gli errori più comuni da evitare, che riassumono il modulo in negativo. Considerare adottato uno strumento perché le licenze sono state distribuite. Trattare il lancio come un evento concluso. Attribuire alla resistenza delle persone difficoltà che sono strutturali. Ignorare lo Shadow AI, o al contrario chiamare Shadow AI ogni iniziativa spontanea. Promuovere l'AI a parole senza dare tempo e risorse. Imporre obiettivi quantitativi d'uso, producendo adozione simbolica. Pensare che un corso basti. Estendere un pilota senza chiedersi quali condizioni lo hanno reso riuscito. Premiare l'entusiasmo e punire gli errori. Misurare solo gli utenti e gli accessi. Non ridimensionare mai nulla. Sono errori comprensibili, perché distribuire una tecnologia è molto più facile, e più visibile, che creare le condizioni per usarla bene.");
    rowList(s, ["Licenze distribuite = strumento adottato; il lancio come evento concluso", "Attribuire alla resistenza difficoltà strutturali", "Ignorare lo Shadow AI, o chiamare così ogni iniziativa spontanea", "Promuovere a parole senza tempo e risorse; imporre obiettivi d'uso", "Pensare che un corso basti; estendere un pilota senza capirne le condizioni", "Premiare l'entusiasmo e punire gli errori", "Misurare solo utenti e accessi; non ridimensionare mai nulla"], { y: 1.12, h: 0.47, gap: 0.07, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 16 si chiude l'area 'Comprendere il valore per l'azienda'. Abbiamo visto come l'AI crea valore, come trasforma il lavoro, quali condizioni informative servono, come scegliere le opportunità e, ora, come sostenerne l'adozione. I prossimi temi, il 17 e il 18, sono dedicati all'utilizzo responsabile dell'AI. Molte questioni che abbiamo toccato in quest'area, rimandandone l'approfondimento, verranno trattate lì: la protezione dei dati e delle informazioni riservate, la sicurezza, i rischi per le persone, le norme, le responsabilità formali, la governance. In particolare lo Shadow AI, che qui abbiamo esaminato come fenomeno di adozione, verrà ripreso dal punto di vista dei rischi e delle regole. Un'ultima osservazione, che riguarda questo percorso: tutto ciò che abbiamo detto sull'adozione vale anche per la formazione che state seguendo. Le competenze acquisite si consolideranno se ci saranno occasioni per applicarle, tempo, strumenti adatti, supporto e confronto tra colleghi. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Temi 12-16 (area completata)", { x: 0.75, y: 4.07, w: 3.9, h: 0.4, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMA AREA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Utilizzo responsabile dell'AI", { x: 5.4, y: 1.72, w: 3.9, h: 0.5, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Temi 17 e 18: dati, sicurezza, persone, norme, responsabilità, governance", { x: 5.4, y: 2.25, w: 3.9, h: 0.65, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "DA RIPRENDERE", { x: 5.4, y: 3.05, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Lo Shadow AI dal punto di vista dei rischi e delle regole", "Le condizioni di esclusione del Tema 15"], { space: 5 }), { x: 5.4, y: 3.4, w: 3.9, h: 1.3, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Gli studi sull'adozione delle tecnologie e sulla formazione sono consolidati, ma l'adozione dell'AI generativa è un fenomeno recente, e le indagini sul suo uso nelle aziende, come quelle sullo Shadow AI, vengono aggiornate di frequente, con numeri che variano molto: è consigliabile verificarle prima di ogni edizione. Il modello 70-20-10, la curva dell'oblio e l'hype cycle sono presentati come schemi indicativi, con le cautele dovute. Gli esempi aziendali e i numeri del modulo sono fittizi; lo scenario dei documenti commerciali è tratto dal documento di perimetro.");
    const src = [
      "Rogers, E. M. (2003). Diffusion of Innovations, 5a ed. Free Press (ed. orig. 1962).",
      "Davis, F. D. (1989). Perceived Usefulness, Perceived Ease of Use, and User Acceptance of Information Technology. MIS Quarterly, 13(3).",
      "Venkatesh, V. et al. (2003). User Acceptance of Information Technology: Toward a Unified View. MIS Quarterly, 27(3).",
      "Baldwin, T. T., Ford, J. K. (1988). Transfer of Training: A Review and Directions for Future Research. Personnel Psychology, 41(1).",
      "Kirkpatrick, D. L. (1994). Evaluating Training Programs: The Four Levels. Berrett-Koehler.",
      "Edmondson, A. (1999). Psychological Safety and Learning Behavior in Work Teams. Administrative Science Quarterly, 44(2).",
      "Microsoft e LinkedIn (2024). Work Trend Index. Per la diffusione dell'uso di strumenti personali.",
      "Gli esempi aziendali e i numeri delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 6 }), { x: 1.3, y: 1.1, w: 8.2, h: 3.8, fontSize: 11, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema16_Adozione_AI_cambiamento_organizzativo.pptx" });
  await applyTheme("Tema16_Adozione_AI_cambiamento_organizzativo.pptx", THEME);
  console.log("done");
})();
