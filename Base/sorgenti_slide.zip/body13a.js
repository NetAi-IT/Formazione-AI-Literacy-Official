  function workTag(s, active) {
    const st = ["Attività", "Processi", "Persone", "Rischi"];
    st.forEach((t, i) => {
      const x = 6.3 + i * 0.81;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.78, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "dimensione " + t });
      txt(s, t, { x, y: 0.42, w: 0.78, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 13", { placeholder: "kicker" });
    s.addText("AI e trasformazione del lavoro e dei processi", { placeholder: "title" });
    s.addText("Area: Comprendere il valore per l'azienda", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al tredicesimo tema, il secondo dell'area 'Comprendere il valore per l'azienda'. Nel Tema 12 abbiamo visto che il valore dell'AI dipende spesso da scelte organizzative: come si usa il tempo liberato, come cambiano i processi, come si mantengono le competenze. Qui guardiamo proprio a questo: come l'AI può modificare le attività professionali, i processi, la collaborazione, le competenze e i ruoli. È un tema delicato, perché tocca da vicino le persone e il loro lavoro, ed è spesso affrontato nei media con toni estremi: o la promessa che l'AI libererà tutti dalle attività noiose, o il timore che sostituirà intere professioni. Il documento di perimetro chiede un approccio diverso: riconoscere che gli effetti sul lavoro dipendono tanto dalle capacità tecnologiche quanto dalle scelte organizzative, e non sono predeterminati. Non facciamo previsioni occupazionali, che richiederebbero analisi specialistiche; diamo strumenti per capire che cosa può cambiare e da che cosa dipende. Il confine con il Tema 16: qui studiamo che cosa cambia nel lavoro; nel Tema 16 vedremo come gestire e accompagnare il cambiamento. Suggerimento per l'apertura: chiedere ai partecipanti di descrivere in tre righe come è cambiato il loro lavoro negli ultimi due anni, se è cambiato, per effetto dell'AI. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; il dibattito sugli effetti dell'AI sul lavoro è molto attivo, e stime e studi vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere come l'AI possa modificare le attività professionali, i processi operativi, la collaborazione, le competenze e i ruoli, riconoscendo che gli effetti sul lavoro dipendono tanto dalle capacità tecnologiche quanto dalle scelte organizzative. La consapevolezza da sviluppare: l'AI può supportare, automatizzare o trasformare singole attività, ma ciò non implica automaticamente né la sostituzione delle professioni né il miglioramento dei processi. Gli esiti dipendono dalla distribuzione del lavoro, dalle interdipendenze tra attività, dalle competenze e dalle modalità di supervisione. Il messaggio centrale del tema: l'AI può modificare come vengono svolti i compiti, organizzati i processi e distribuite competenze e responsabilità; gli effetti non sono predeterminati dalla tecnologia, dipendono dal contesto e dalle scelte organizzative, e possono comprendere sia nuovi benefici sia nuove attività e rischi.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Capire come l'AI può cambiare attività, processi, collaborazione, competenze e ruoli", "Riconoscere il peso delle scelte organizzative"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Supportare, automatizzare o trasformare un'attività non implica sostituire una professione né migliorare un processo.\n\nGli esiti dipendono da distribuzione del lavoro, interdipendenze, competenze e supervisione." });
  }
  {
    const s = content("Compito, processo, ruolo", "Il documento di perimetro indica tre livelli da distinguere, che attraversano tutto il modulo e che conviene presentare subito. Il compito: cambia il modo in cui si svolge un'operazione specifica. Per esempio, scrivere la bozza di una risposta a un cliente, riassumere un documento, compilare un modulo. Il processo: cambiano sequenze di attività, passaggi di consegne, controlli e interdipendenze. Per esempio, l'intero percorso dalla richiesta del cliente alla risposta, con le persone, i sistemi e i controlli coinvolti. Il ruolo: cambia l'insieme di responsabilità, attività e competenze professionali. Per esempio, che cosa fa e di che cosa risponde un addetto all'assistenza clienti. I tre livelli sono collegati, ma un cambiamento a un livello non implica automaticamente un cambiamento agli altri. Si può trasformare un compito senza che il processo migliori, come visto nel Tema 12 per i colli di bottiglia. Si possono automatizzare molti compiti senza che il ruolo scompaia, perché il ruolo comprende anche altre attività. Molta della confusione nel dibattito sull'AI e il lavoro nasce dal passare da un livello all'altro senza accorgersene: 'l'AI può scrivere email, quindi gli addetti all'assistenza verranno sostituiti'.");
    const l = [["FiCheckSquare", "Compito", "Cambia il modo di svolgere un'operazione", "Scrivere la bozza di una risposta"], ["FiGitBranch", "Processo", "Cambiano sequenze, passaggi, controlli, interdipendenze", "Dalla richiesta del cliente alla risposta"], ["FiUser", "Ruolo", "Cambia l'insieme di responsabilità, attività, competenze", "Che cosa fa un addetto all'assistenza"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.55, i === 1 ? C.accent6 : C.background2, l[i][1]);
      await iconCircle(s, x + 1.08, 1.27, 0.7, l[i][0]);
      txt(s, l[i][1], { x: x + 0.15, y: 2.05, w: 2.56, h: 0.42, fontSize: 18, bold: true, color: C.text1, align: "center" });
      txt(s, l[i][2], { x: x + 0.2, y: 2.5, w: 2.46, h: 0.6, fontSize: 12, color: C.text2, align: "center" });
      txt(s, l[i][3], { x: x + 0.2, y: 3.15, w: 2.46, h: 0.45, fontSize: 11, italic: true, color: C.accent1, align: "center" });
    }
    banner(s, 3.9, "Un cambiamento a un livello non implica gli altri. 'L'AI scrive email, quindi gli addetti verranno sostituiti' salta due livelli.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Nove domande guida", "Le nove domande guida accompagnano il modulo. Le prime tre riguardano le attività: come l'AI modifica la natura del lavoro, la differenza tra compiti, mansioni, ruoli e processi, e quali caratteristiche rendono un'attività più o meno trasformabile. La quarta riguarda i processi: perché automatizzare un compito non equivale a migliorare un processo. Le successive tre riguardano le persone: come cambiano collaborazione, supervisione e responsabilità; quali effetti sui ruoli, senza assumere risultati occupazionali predeterminati; come cambiano competenze e opportunità di apprendimento. Le ultime due riguardano gli effetti meno visibili: perché la trasformazione può creare nuove attività oltre a ridurne alcune, e quali rischi emergono quando si introduce l'AI in processi già inefficienti. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Come può l'AI modificare il lavoro quotidiano?", "Compiti, mansioni, ruoli, processi: che differenza?", "Che cosa rende un'attività trasformabile?", "Perché un compito automatizzato non migliora il processo?", "Come cambiano collaborazione, supervisione, responsabilità?", "Quali effetti sui ruoli, senza esiti predeterminati?", "Come cambiano competenze e apprendimento?", "Perché la trasformazione crea anche nuove attività?", "Quali rischi in processi già inefficienti?"], 3, 1.12, 1.0, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in quattro dimensioni. La trasformazione delle attività: come cambia il lavoro e quali attività sono più trasformabili, nei sottotemi 13.1 e 13.2. La trasformazione dei processi: dal compito al processo, nel 13.3. Collaborazione, ruoli e competenze: come si lavora con l'AI, come evolvono ruoli e responsabilità, come cambia la collaborazione nei team, quali competenze servono, dal 13.4 al 13.7. Condizioni e rischi, nel 13.8. Il documento indica 13.1, 13.3, 13.4 e 13.5 come i sottotemi da approfondire maggiormente, perché chiariscono i cambiamenti essenziali di compiti, processi e ruoli. Tre precisazioni trasversali accompagnano tutto il tema. Esposizione non equivale a sostituzione: la possibilità tecnica di automatizzare un'attività non permette di dedurre che sarà adottata, né quali effetti avrà sull'occupazione. Compiti semplici possono essere formativi: affidarli all'AI può ridurre le occasioni di pratica. Il nuovo lavoro va conteggiato: supervisione, eccezioni e controllo modificano il bilancio della trasformazione. Nelle slide, un indicatore in alto a destra ricorda la dimensione di cui stiamo parlando.");
    const d = [["FiCheckSquare", "Attività", "13.1  13.2"], ["FiGitBranch", "Processi", "13.3"], ["FiUsers", "Persone: collaborazione, ruoli, competenze", "13.4  13.5  13.6  13.7"], ["FiAlertTriangle", "Condizioni e rischi", "13.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.0, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.03, w: 1.9, h: 0.6, fontSize: 13, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.65, w: 1.9, h: 0.35, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Tre precisazioni trasversali", { x: 0.5, y: 3.3, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const p = ["Esposizione non equivale a sostituzione", "Compiti semplici possono essere formativi", "Il nuovo lavoro va conteggiato"];
    p.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.7, 2.86, 0.85, t, { fill: C.accent6, fontSize: 13 }));
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, la collaborazione nei team e tra funzioni, con priorità media. Vanno compresi e applicati: le differenze tra livelli di trasformazione, il riconoscimento delle attività, le modifiche nei flussi, la supervisione e la distribuzione delle responsabilità. Vanno conosciuti: l'evoluzione delle mansioni, la collaborazione tra funzioni, le nuove attività e il rischio di erosione dell'esperienza professionale. Vanno solo accennati: Business Process Reengineering, workforce planning, analisi occupazionali specialistiche, progettazione organizzativa avanzata e metodologie complete di change management. Confini: non ripetiamo la collaborazione conversazionale del Tema 5, le tecniche di verifica del Tema 7, il funzionamento degli agenti del Tema 11, la classificazione dei benefici del Tema 12. Non trattiamo il patrimonio informativo, del Tema 14, la scelta dei progetti, del Tema 15, la gestione del cambiamento, del Tema 16, né governance, privacy e normativa, dei Temi 17 e 18.");
    pathSlide(s, [["13.1", "Come l'AI modifica il lavoro", "Alta"], ["13.2", "Attività trasformabili", "Alta"], ["13.3", "Dal compito al processo", "Alta"], ["13.4", "Collaborazione tra persone e AI", "Alta"], ["13.5", "Ruoli e responsabilità", "Alta"], ["13.6", "Team e funzioni", "Media"], ["13.7", "Competenze e modi di lavorare", "Alta"], ["13.8", "Condizioni e rischi", "Alta"]],
      [["Comprendere e applicare", "Livelli di trasformazione, attività, flussi, supervisione, responsabilità", C.accent1, C.background1], ["Conoscere", "Mansioni, collaborazione tra funzioni, nuove attività, erosione dell'esperienza", C.accent6, C.text1], ["Solo accennare", "Reengineering, workforce planning, analisi occupazionali, change management", C.background2, C.text1]]);
  }

  // =====================================================================
  section("13.1 La natura del lavoro");
  divider("13.1", "Come l'AI modifica la natura del lavoro", "Le capacità tecniche dell'AI non consentono, da sole, di dedurre effetti certi su professioni o occupazione", "Partiamo dal quadro generale. In questo sottotema, da comprendere, costruiamo il vocabolario per parlare di lavoro e AI: attività, compiti, mansioni, ruoli. Vediamo i tipi di lavoro e come l'AI interviene su ciascuno, la differenza tra attività assistite, automatizzate e trasformate, e soprattutto la distinzione tra l'automazione dei compiti e la sostituzione delle professioni, che è la prima integrazione del tema. E una distinzione che il dibattito pubblico trascura spesso: tra l'esposizione di un lavoro all'AI e la sua effettiva trasformazione.");
  {
    const s = content("Attività, compiti, mansioni, ruoli", "La prima domanda guida chiede la differenza tra compiti, mansioni, ruoli e processi, e il sottotema parte da qui. Usiamo definizioni semplici e funzionali, utili per ragionare. Un'attività o un compito è un'unità di lavoro con un obiettivo definito: rispondere a un'email, preparare un preventivo, controllare una fattura, condurre un colloquio. La mansione è l'insieme dei compiti assegnati a una posizione, spesso descritto in un mansionario: per esempio, gestire le richieste dei clienti, aggiornare l'anagrafica, preparare i report mensili. Il ruolo è più ampio della mansione: comprende le responsabilità, cioè di che cosa si risponde, le relazioni con gli altri, le competenze richieste, il contributo atteso all'organizzazione, e anche ciò che non è scritto nel mansionario ma che la persona fa, come aiutare i colleghi nuovi o gestire i clienti difficili. Il processo, infine, attraversa i ruoli: è la sequenza di attività, svolte da persone e sistemi diversi, che produce un risultato. Lo schema in slide mostra la gerarchia. Ragionare sull'AI a livello di compiti, invece che di ruoli interi, è uno degli strumenti più utili di questo modulo: l'AI interviene quasi sempre su compiti, non su ruoli.");
    workTag(s, 0);
    const l = [["Compito", "Un'unità di lavoro con un obiettivo", "Preparare un preventivo"], ["Mansione", "L'insieme dei compiti di una posizione", "Gestire richieste, anagrafica, report"], ["Ruolo", "Mansione più responsabilità, relazioni, competenze, contributo", "Anche ciò che non è scritto: aiutare i nuovi, i clienti difficili"]];
    l.forEach((e, i) => {
      const y = 1.15 + i * 0.9, w = 6.0 + i * 0.5;
      shapeBox(s, 0.5, y, w, 0.8, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: 0.65, y, w: 1.5, h: 0.8, fontSize: 15, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.15, y: y + 0.06, w: w - 1.8, h: 0.35, fontSize: 12, bold: true, color: i === 2 ? C.background1 : C.text1 });
      txt(s, e[2], { x: 2.15, y: y + 0.42, w: w - 1.8, h: 0.35, fontSize: 11, italic: true, color: i === 2 ? C.accent6 : C.text2 });
    });
    shapeBox(s, 0.5, 3.95, 9.0, 0.55, C.background2, "processo");
    txt(s, [{ text: "Processo: ", options: { bold: true, color: C.accent1 } }, { text: "attraversa i ruoli, sequenza di attività di persone e sistemi diversi che produce un risultato.", options: { color: C.text1 } }], { x: 0.7, y: 3.95, w: 8.6, h: 0.55, fontSize: 12, valign: "middle" });
    txt(s, "L'AI interviene quasi sempre su compiti, non su ruoli interi.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Tipi di lavoro", "Il sottotema distingue quattro tipi di lavoro, utili per capire dove l'AI generativa interviene di più. Il lavoro manuale: attività fisiche, come produrre, assemblare, trasportare, manutenere. L'AI generativa interviene poco direttamente, anche se può supportare con istruzioni, diagnosi, documentazione; la robotica è un altro discorso. Il lavoro ripetitivo: attività con regole stabili, come compilare, registrare, controllare formalmente. Qui l'automazione tradizionale, vista nel Tema 11, interviene da tempo; l'AI la estende ai casi con informazioni non strutturate. Il lavoro informativo: attività basate sulla gestione di informazioni e documenti, come cercare, riassumere, organizzare, comunicare. È l'ambito in cui l'AI generativa ha l'impatto più diretto, come visto nei Temi 8 e 9. Il lavoro cognitivo: attività che richiedono analisi, interpretazione, giudizio, creatività, relazione. L'AI può supportarle, per esempio esplorando alternative o preparando analisi, ma il giudizio, la relazione e la responsabilità restano umani. Un'osservazione importante, spesso notata dagli economisti: a differenza delle ondate di automazione precedenti, che riguardavano soprattutto il lavoro manuale e ripetitivo, l'AI generativa tocca soprattutto il lavoro informativo e cognitivo, cioè professioni che finora erano state poco esposte all'automazione.");
    workTag(s, 0);
    const t = [["FiTool", "Manuale", "Produrre, assemblare, manutenere", "Intervento indiretto: istruzioni, diagnosi"], ["FiRepeat", "Ripetitivo", "Compilare, registrare, controllare", "Automazione tradizionale, estesa dall'AI"], ["FiFileText", "Informativo", "Cercare, riassumere, comunicare", "L'impatto più diretto dell'AI generativa"], ["FiCpu", "Cognitivo", "Analizzare, giudicare, creare, relazionarsi", "Supporto; giudizio e relazione restano umani"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.75, i === 2 ? C.accent6 : C.background2, t[i][1]);
      await iconCircle(s, x + 0.72, 1.27, 0.66, t[i][0]);
      txt(s, t[i][1], { x: x + 0.1, y: 2.0, w: 1.95, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, t[i][2], { x: x + 0.12, y: 2.42, w: 1.91, h: 0.6, fontSize: 11, color: C.text2, align: "center" });
      txt(s, t[i][3], { x: x + 0.12, y: 3.05, w: 1.91, h: 0.75, fontSize: 11, bold: true, color: C.accent1, align: "center" });
    }
    banner(s, 4.1, "A differenza delle ondate precedenti, l'AI generativa tocca soprattutto il lavoro informativo e cognitivo.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Assistite, automatizzate, trasformate", "Il sottotema distingue tre modi in cui l'AI può intervenire su un'attività. Un'attività assistita resta svolta dalla persona, che usa l'AI come supporto: chiede una bozza, una sintesi, un suggerimento, e poi decide e completa. Il modo di lavorare cambia poco, la responsabilità resta interamente della persona. È il caso più diffuso oggi. Un'attività automatizzata è svolta dal sistema, in tutto o in parte, con la persona che interviene solo per supervisione o eccezioni, come visto nel Tema 11. Il modo di lavorare cambia molto per quella attività. Un'attività trasformata cambia nella sua natura: non si fa più la stessa cosa più rapidamente, ma si fa una cosa diversa. Per esempio, l'analisi dei reclami passa dalla lettura di un campione all'analisi sistematica di tutti i reclami, con un obiettivo nuovo: individuare le cause ricorrenti. Oppure il lavoro di un addetto passa dal redigere le risposte al supervisionare e migliorare le risposte preparate dal sistema. Il sottotema parla anche dell'evoluzione delle modalità di esecuzione del lavoro: per la stessa attività, il passaggio da assistita a automatizzata o trasformata avviene spesso gradualmente, ed è il risultato di scelte, non un esito automatico della tecnologia.");
    workTag(s, 0);
    const t = [["Assistita", "La persona svolge, l'AI supporta", "Bozza, sintesi, suggerimento", C.background2, C.text1], ["Automatizzata", "Il sistema svolge, la persona supervisiona", "Eccezioni e controlli restano umani", C.accent6, C.text1], ["Trasformata", "Si fa una cosa diversa", "Da un campione di reclami a tutti, per trovare le cause", C.accent1, C.background1]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.3, e[3], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.45, fontSize: 18, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.72, w: 2.56, h: 0.6, fontSize: 13, bold: true, color: e[4] });
      txt(s, e[2], { x: x + 0.15, y: 2.4, w: 2.56, h: 0.95, fontSize: 12, italic: true, color: e[4] });
      if (i < 2) arrow(s, x + 2.88, 2.15, 0.17);
    });
    banner(s, 3.7, "Il passaggio da assistita ad automatizzata o trasformata è spesso graduale, ed è il risultato di scelte, non della tecnologia.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Il compito non è il ruolo", "L'integrazione A del tema: un ruolo comprende attività diverse, e l'automazione di alcune non determina automaticamente la scomparsa dell'intero ruolo. È una delle idee più importanti per leggere in modo equilibrato il dibattito sull'AI e il lavoro. Un esempio storico spesso citato dagli economisti è quello degli sportelli bancari automatici. Quando, a partire dagli anni Settanta, si diffusero i bancomat, molti prevedevano la scomparsa dei cassieri di banca, perché il compito principale, distribuire contanti, veniva automatizzato. Negli Stati Uniti, secondo le analisi dell'economista James Bessen, il numero dei cassieri bancari non diminuì per molti anni: il costo di apertura delle filiali si ridusse, le banche aprirono più filiali, e il ruolo del cassiere si spostò verso la relazione con i clienti e la vendita di servizi. Il lavoro cambiò profondamente, ma non scomparve, almeno in quella fase; anni dopo, con altre tecnologie come l'home banking, le dinamiche sono cambiate. L'esempio non dimostra che l'AI non sostituirà mai nessun ruolo: dimostra che dall'automazione di un compito non si può dedurre l'effetto sul ruolo. Gli effetti dipendono da quanta parte del ruolo è automatizzata, da che cosa si fa con il tempo liberato, dalla domanda di mercato, dalle scelte delle organizzazioni.");
    workTag(s, 0);
    shapeBox(s, 0.5, 1.15, 9.0, 1.65, C.background2, "esempio storico");
    txt(s, "Un esempio storico: i bancomat e i cassieri", { x: 0.7, y: 1.22, w: 8.6, h: 0.38, fontSize: 15, bold: true, color: C.accent1 });
    txt(s, bullets(["Previsione: il compito principale è automatizzato, i cassieri scompariranno", "Negli Stati Uniti, per molti anni, i cassieri non diminuirono: più filiali, ruolo spostato verso relazione e servizi (Bessen)", "Anni dopo, con altre tecnologie, le dinamiche sono cambiate"], { space: 4 }), { x: 0.7, y: 1.63, w: 8.6, h: 1.15, fontSize: 12, color: C.text1 });
    txt(s, "Da che cosa dipende l'effetto sul ruolo", { x: 0.5, y: 2.95, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const d = ["Quanta parte del ruolo è automatizzata", "Che cosa si fa con il tempo liberato", "La domanda di mercato", "Le scelte delle organizzazioni"];
    d.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.32, 2.15, 0.7, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.2, "Dall'automazione di un compito non si può dedurre l'effetto sul ruolo.", { h: 0.65, fontSize: 15 });
  }
  {
    const s = content("Esposizione e trasformazione", "Una distinzione che il sottotema chiede di rendere esplicita, ed è anche una delle precisazioni trasversali del tema: l'esposizione di un lavoro all'AI non equivale alla sua effettiva trasformazione. Molti studi stimano l'esposizione delle professioni all'AI: quanti compiti di una professione potrebbero, in teoria, essere svolti o accelerati dall'AI. Per esempio, uno studio di Eloundou e colleghi, pubblicato nel 2023, ha stimato che per circa l'80 per cento dei lavoratori statunitensi almeno il 10 per cento dei compiti fosse esposto ai modelli linguistici, e che per circa il 19 per cento almeno la metà dei compiti lo fosse. Sono stime utili per capire dove l'AI può intervenire. Ma esposizione significa possibilità tecnica, non adozione, e ancora meno sostituzione. Tra l'una e l'altra ci sono molti passaggi: che l'AI sia davvero abbastanza affidabile per quel compito; che convenga economicamente; che l'organizzazione la adotti; che i processi vengano adattati; che le regole lo consentano; che i clienti lo accettino. E l'effetto dell'adozione può essere un aumento della produttività della persona, un cambiamento del ruolo, una riduzione della domanda di lavoro, o anche un aumento, a seconda dei casi. Il messaggio del sottotema è netto: le capacità tecniche dell'AI non consentono, da sole, di dedurre effetti certi su professioni o occupazione.");
    workTag(s, 0);
    const ch = ["Esposizione", "Affidabilità", "Convenienza", "Adozione", "Processi adattati", "Effetto sul lavoro"];
    ch.forEach((t, i) => {
      const x = 0.5 + i * 1.53;
      chip(s, x, 1.2, 1.38, 0.7, t, { fill: i === 0 ? C.accent1 : (i === 5 ? C.text1 : C.background2), color: i === 0 || i === 5 ? C.background1 : C.text1, fontSize: 11 });
      if (i < 5) arrow(s, x + 1.39, 1.39, 0.13);
    });
    txt(s, "Tra la possibilità tecnica e l'effetto ci sono molti passaggi, ciascuno incerto", { x: 0.5, y: 2.0, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2, align: "center" });
    await card(s, 0.5, 2.5, 4.35, 1.6, { icon: "FiBarChart2", inline: true, head: "Uno studio sull'esposizione (2023)", headSize: 13, bodySize: 12, body: "Circa 80% dei lavoratori USA con almeno il 10% dei compiti esposti; circa 19% con almeno la metà." });
    await card(s, 5.15, 2.5, 4.35, 1.6, { icon: "FiShuffle", inline: true, head: "Effetti possibili", headSize: 13, bodySize: 12, fill: C.accent6, body: "Più produttività, ruoli che cambiano, meno domanda di lavoro, o anche di più: dipende dai casi." });
    banner(s, 4.3, "Esposizione significa possibilità tecnica, non adozione, e ancor meno sostituzione.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Effetti diversi, scelte decisive", "Gli ultimi due punti del sottotema. L'eterogeneità degli effetti tra funzioni e professioni: l'AI non tocca allo stesso modo tutti i lavori. Anche all'interno della stessa azienda, l'impatto può essere molto diverso tra l'assistenza clienti, il marketing, l'amministrazione, la produzione, la ricerca, le risorse umane. E all'interno della stessa funzione, tra persone con esperienze e attività diverse, come abbiamo visto nel Tema 12 per i lavoratori meno e più esperti. Le generalizzazioni, come 'l'AI trasformerà il marketing', dicono poco su che cosa accadrà a una specifica persona in una specifica azienda. Il ruolo delle scelte organizzative nel determinare gli impatti: è forse il messaggio più importante del sottotema. Con la stessa tecnologia, due organizzazioni possono fare scelte molto diverse. Una può usare l'AI per ridurre il personale a parità di lavoro; un'altra per gestire più clienti con le stesse persone; un'altra ancora per migliorare la qualità del servizio o liberare tempo per attività di maggior valore. Può automatizzare le attività formative dei giovani o usarle per accelerarne l'apprendimento. Può concentrare la supervisione su pochi esperti o distribuirla. Gli effetti sul lavoro dipendono da queste scelte almeno quanto dalle capacità della tecnologia.");
    workTag(s, 0);
    await card(s, 0.5, 1.15, 4.35, 2.0, { icon: "FiGrid", head: "Effetti eterogenei", headSize: 15, bodySize: 12,
      body: bullets(["Tra funzioni: assistenza, marketing, produzione", "Tra persone: esperienza, attività"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.0, { icon: "FiSliders", head: "Scelte decisive", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Stessa tecnologia, scelte diverse", "Effetti diversi sul lavoro"], { space: 4 }) });
    txt(s, "Con la stessa tecnologia, un'organizzazione può scegliere di", { x: 0.5, y: 3.3, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const c = ["Ridurre il personale a parità di lavoro", "Servire più clienti con le stesse persone", "Migliorare la qualità del servizio", "Accelerare l'apprendimento dei giovani"];
    c.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.68, 2.15, 0.75, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Gli effetti dipendono dalle scelte almeno quanto dalle capacità della tecnologia.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  keySlide("Le capacità tecniche dell'AI non consentono, da sole, di dedurre effetti certi su professioni o occupazione.", "Sottotema 13.1  ·  Come l'AI modifica la natura del lavoro", "Concetto chiave del primo sottotema. Compiti, mansioni, ruoli e processi sono livelli diversi, e l'AI interviene quasi sempre sui compiti. L'AI generativa tocca soprattutto il lavoro informativo e cognitivo. Le attività possono essere assistite, automatizzate o trasformate. L'automazione di un compito non determina la scomparsa del ruolo, come mostra l'esempio storico dei bancomat; l'esposizione non è trasformazione; gli effetti sono eterogenei e dipendono dalle scelte organizzative. Esercizio suggerito: ciascun partecipante elenca i cinque compiti principali del proprio ruolo e indica, per ciascuno, se oggi è svolto senza AI, con AI assistita o in modo automatizzato.");

  // =====================================================================
  section("13.2 Attività trasformabili");
  divider("13.2", "Individuare le attività trasformabili", "Qualità delle informazioni, variabilità, contesto, rischio e organizzazione condizionano l'applicazione", "Se l'AI interviene sui compiti, quali compiti sono più adatti? In questo sottotema, da comprendere e riconoscere, vediamo come scomporre il lavoro in attività e quali caratteristiche rendono un'attività più o meno trasformabile. Il documento pone un confine preciso: qui riconosciamo le caratteristiche delle attività, senza introdurre una metodologia completa di prioritizzazione dei casi d'uso, che appartiene al Tema 15. Alcuni criteri li abbiamo già incontrati nel Tema 11 per gli agenti; qui li guardiamo dal punto di vista del lavoro.");
  {
    const s = content("Scomporre il lavoro in attività", "Il primo passo per capire come l'AI può cambiare un lavoro è scomporlo in attività. Il ruolo nel suo insieme è troppo ampio per una valutazione utile; le singole attività invece si possono esaminare una per una. L'esempio fittizio in slide scompone il ruolo di un addetto all'ufficio acquisti in otto attività, con una stima del tempo dedicato a ciascuna e una prima valutazione del possibile intervento dell'AI. Alcune attività sono candidate al supporto, come la preparazione delle richieste di offerta o il confronto tra offerte, visto nel Tema 8. Alcune a un'automazione parziale, come la registrazione degli ordini e il sollecito delle consegne. Altre restano essenzialmente umane, come la negoziazione con i fornitori o la gestione dei problemi di qualità, anche se l'AI può aiutare a prepararle. Due osservazioni. La prima: la scomposizione mostra che nessun ruolo è interamente trasformabile, e che il tempo liberato da alcune attività può essere spostato verso altre, come la negoziazione o lo sviluppo dei fornitori. La seconda: la scomposizione formale, come quella del mansionario, non coincide con il lavoro reale; per farla bene bisogna chiedere a chi svolge il ruolo come passa davvero il tempo.");
    workTag(s, 0);
    table(s, [["Attività (addetto acquisti, esempio fittizio)", "Tempo", "Intervento possibile dell'AI"],
      ["Preparare richieste di offerta", "15%", "Supporto"],
      ["Confrontare le offerte", "15%", "Supporto"],
      ["Registrare gli ordini", "15%", "Automazione parziale"],
      ["Sollecitare le consegne", "10%", "Automazione parziale"],
      ["Negoziare con i fornitori", "15%", "Preparazione assistita, svolgimento umano"],
      ["Gestire problemi di qualità", "15%", "Supporto all'analisi, gestione umana"],
      ["Sviluppare nuovi fornitori", "10%", "Supporto alla ricerca"],
      ["Coordinarsi con produzione e amministrazione", "5%", "Prevalentemente umano"]],
      { y: 1.12, colW: [4.2, 1.0, 3.8], rowH: 0.36, fontSize: 11, blankCorner: false });
    banner(s, 4.45, "Nessun ruolo è interamente trasformabile. E il mansionario non è il lavoro reale: chiedere a chi lo svolge.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Le caratteristiche delle attività", "Il sottotema elenca alcune caratteristiche che influenzano quanto un'attività sia adatta all'AI. Conviene pensarle come scale, non come categorie: un'attività si colloca in un punto di ciascuna. Ripetitiva e standardizzata, oppure unica e non strutturata: le prime si prestano di più all'automazione, le seconde al supporto. Basata su informazioni e documenti, oppure su attività fisiche o relazionali: l'AI generativa interviene soprattutto sulle prime. Prevedibile, oppure variabile: le attività con molte eccezioni sono più difficili da automatizzare, come visto nel Tema 11. Basata su regole, oppure su interpretazione e giudizio: l'interpretazione e il giudizio possono essere supportati, ma richiedono competenze e controllo umano. Il grafico in slide colloca alcune attività fittizie su due di queste scale, la variabilità e il bisogno di giudizio, e mostra che si formano gruppi con possibilità diverse. Le attività prevedibili e con poco giudizio sono candidate all'automazione; quelle variabili e con molto giudizio, al supporto; quelle intermedie, all'esecuzione parziale con supervisione. Non sono regole rigide, ma una prima mappa.");
    workTag(s, 0);
    shapeBox(s, 0.5, 1.15, 5.6, 3.35, C.background1, "mappa", { color: HEX.a3, width: 1 });
    s.addShape(pres.shapes.LINE, { x: 0.9, y: 4.2, w: 5.0, h: 0, line: { color: HEX.a2, width: 1.5, endArrowType: "triangle" }, objectName: "asse x" });
    s.addShape(pres.shapes.LINE, { x: 0.9, y: 1.3, w: 0, h: 2.9, line: { color: HEX.a2, width: 1.5, beginArrowType: "triangle" }, objectName: "asse y" });
    txt(s, "Variabilità →", { x: 4.3, y: 4.22, w: 1.6, h: 0.25, fontSize: 10, color: C.text2, align: "right" });
    txt(s, "Giudizio ↑", { x: 0.55, y: 1.15, w: 1.2, h: 0.25, fontSize: 10, color: C.text2 });
    const p = [["Registrare ordini", 1.0, 3.7, C.accent1], ["Sollecitare consegne", 1.6, 3.22, C.accent1], ["Preparare richieste", 2.2, 2.74, C.accent2], ["Confrontare offerte", 2.8, 2.26, C.accent2], ["Gestire qualità", 3.7, 1.78, C.accent5], ["Negoziare", 4.4, 1.3, C.accent5]];
    p.forEach(e => chip(s, e[1], e[2], 1.35, 0.36, e[0], { fill: e[3], color: C.background1, fontSize: 9 }));
    const l = [["Prevedibili, poco giudizio", "Candidate all'automazione", C.accent1, C.background1], ["Intermedie", "Esecuzione parziale con supervisione", C.accent2, C.background1], ["Variabili, molto giudizio", "Candidate al supporto", C.accent5, C.background1]];
    l.forEach((e, i) => {
      const y = 1.15 + i * 1.15;
      shapeBox(s, 6.35, y, 3.15, 1.0, e[2], e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.38, fontSize: 13, bold: true, color: e[3] });
      txt(s, e[1], { x: 6.5, y: y + 0.48, w: 2.9, h: 0.45, fontSize: 12, color: e[3] });
    });
    txt(s, "Esempio fittizio. Una prima mappa, non regole rigide.", { x: 0.5, y: 4.6, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Informazioni, rischio, controllo", "Oltre alle caratteristiche dell'attività in sé, il sottotema indica tre condizioni che influenzano la trasformabilità. La disponibilità delle informazioni necessarie: un'attività può essere perfettamente adatta all'AI in teoria, ma se le informazioni necessarie non sono accessibili, sono sparse in luoghi diversi, sono di scarsa qualità o sono nella testa delle persone, l'AI non può svolgerla bene. È il tema del Tema 14. I diversi livelli di rischio operativo: a parità di caratteristiche, un'attività con conseguenze gravi in caso di errore richiede più controllo, e quindi è meno automatizzabile, di una con conseguenze lievi. Preparare la bozza di una comunicazione interna e preparare la bozza di una risposta a un'autorità sono compiti simili, con rischi molto diversi. La necessità di competenze e controllo umano: alcune attività richiedono competenze specialistiche per verificare il risultato, e se queste competenze non sono disponibili nel momento in cui l'attività si svolge, l'AI non può essere usata in sicurezza. Il sottotema distingue di conseguenza tre livelli di intervento: il supporto, in cui la persona svolge l'attività con l'aiuto dell'AI; l'esecuzione parziale, in cui l'AI svolge una parte e la persona il resto; l'automazione, in cui l'AI svolge l'attività con supervisione. Sono gli stessi livelli visti nel Tema 11, ora applicati alla scelta delle attività.");
    workTag(s, 0);
    await iconGrid(s, [
      { icon: "FiDatabase", head: "Informazioni disponibili", body: "Accessibili, di qualità, non solo nella testa delle persone" },
      { icon: "FiAlertTriangle", head: "Rischio operativo", body: "Bozza interna o risposta a un'autorità: compiti simili, rischi diversi" },
      { icon: "FiUserCheck", head: "Competenze e controllo", body: "Chi sa verificare deve esserci, quando serve" },
    ], 3, { y: 1.15, h: 2.0, headSize: 14, bodySize: 12 });
    txt(s, "Tre livelli di intervento", { x: 0.5, y: 3.35, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const l = ["Supporto: la persona svolge, l'AI aiuta", "Esecuzione parziale: l'AI una parte, la persona il resto", "Automazione: l'AI svolge, la persona supervisiona"];
    l.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.72, 2.86, 0.85, t, { fill: [C.background2, C.accent6, C.accent1][i], color: i === 2 ? C.background1 : C.text1, fontSize: 12 }));
  }
  {
    const s = content("Fattibile o trasformabile?", "L'ultimo punto del sottotema: la differenza tra fattibilità tecnica e trasformabilità effettiva, e l'importanza del contesto in cui l'attività viene svolta. È la stessa distinzione vista nel Tema 12 tra fattibilità e convenienza, applicata alle attività. Che l'AI sia tecnicamente in grado di svolgere un compito non significa che quel compito, in quell'azienda, possa essere effettivamente trasformato. Il contesto conta in molti modi. Il volume: un'attività svolta dieci volte l'anno non giustifica lo sforzo di trasformarla. La qualità delle informazioni, come visto. Le regole: norme di settore, contratti, politiche aziendali possono richiedere che certe attività siano svolte o verificate da persone. I clienti: alcuni si aspettano un contatto umano per certe attività, o lo richiedono. Le competenze disponibili per supervisionare. Il modo in cui l'attività è collegata alle altre, che vedremo nel 13.3. Per questo, la stessa attività può essere trasformabile in un'azienda e non in un'altra. La consapevolezza del sottotema lo dice: non tutte le attività sono ugualmente adatte all'AI; qualità delle informazioni, variabilità, contesto, rischio e organizzazione ne condizionano l'applicazione. La valutazione e la scelta delle attività da trasformare, con criteri di priorità, appartengono al Tema 15.");
    workTag(s, 0);
    const c = [["Volume", "Dieci volte l'anno non giustifica lo sforzo"], ["Informazioni", "Disponibili e di qualità?"], ["Regole", "Norme, contratti, politiche che richiedono persone"], ["Clienti", "Alcuni si aspettano un contatto umano"], ["Competenze", "Chi supervisiona?"], ["Collegamenti", "Come l'attività si lega alle altre (13.3)"]];
    rowsLabel(s, c, { y: 1.15, h: 0.4, lw: 2.2 });
    banner(s, 4.05, "La stessa attività può essere trasformabile in un'azienda e non in un'altra.", { h: 0.75, fontSize: 13 });
  }
  keySlide("Non tutte le attività sono ugualmente adatte all'AI: qualità delle informazioni, variabilità, contesto, rischio e organizzazione ne condizionano l'applicazione.", "Sottotema 13.2  ·  Individuare le attività trasformabili", "Concetto chiave del sottotema 13.2. Per capire come l'AI può cambiare un lavoro bisogna scomporlo in attività, partendo dal lavoro reale e non dal mansionario. Le attività si collocano su scale: ripetitive o uniche, informative o relazionali, prevedibili o variabili, basate su regole o su giudizio. Contano anche la disponibilità delle informazioni, il rischio e le competenze per il controllo, e i livelli di intervento vanno dal supporto all'automazione. Fattibilità tecnica e trasformabilità effettiva sono diverse, e il contesto è decisivo. Esercizio suggerito: ciascun partecipante scompone il proprio ruolo in sei o otto attività, stima il tempo per ciascuna e le colloca sulla mappa variabilità e giudizio.");
