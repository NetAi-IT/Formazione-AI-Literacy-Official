  function phaseTag(s, active) {
    const st = ["Comprendere", "Elaborare", "Rappresentare", "Interpretare"];
    st.forEach((t, i) => {
      const x = 6.3 + i * 0.81;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.78, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "fase " + t });
      txt(s, t, { x, y: 0.42, w: 0.78, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function scatter(s, xs, ys, o) {
    s.addChart(pres.charts.SCATTER, [{ name: "X", values: xs }, { name: o.name || "Y", values: ys }], {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: 0, lineDataSymbol: "circle", lineDataSymbolSize: o.size || 6, chartColors: [o.color || HEX.a1],
      valAxisMinVal: o.ymin, valAxisMaxVal: o.ymax, catAxisMinVal: o.xmin, catAxisMaxVal: o.xmax,
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 8, catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 8,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, showLegend: false,
      showTitle: !!o.title, title: o.title || "", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      valAxisLabelFontFace: "+mn-lt", catAxisLabelFontFace: "+mn-lt",
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 9", { placeholder: "kicker" });
    s.addText("AI per dati e analisi", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI", { placeholder: "sub" });
    s.addNotes("Benvenuti al nono tema, il secondo dell'area 'Esplorare le possibilità dell'AI'. Nel Tema 8 abbiamo lavorato su testi, documenti e conoscenza, e nel sottotema 8.4 abbiamo visto come trasformare informazioni non strutturate in dati. Qui facciamo il passo successivo: che cosa si può fare con i dati grazie all'AI. Preparare e capire un dataset, calcolare indicatori, individuare tendenze e anomalie, costruire grafici e report, fare stime e simulazioni, interpretare i risultati e sostenere le decisioni. È un ambito in cui l'AI promette molto, perché rende accessibili attività che prima richiedevano competenze tecniche specifiche. Ed è un ambito in cui i rischi sono particolarmente insidiosi, perché i numeri hanno un'aria di oggettività che i testi non hanno. Il punto di vista resta quello dell'utilizzatore: non entriamo in algoritmi statistici specialistici, modellazione avanzata o architetture di Business Intelligence. Suggerimento per l'apertura: chiedere ai partecipanti quali dati usano nel loro lavoro, in quale forma, e quanto tempo dedicano a prepararli rispetto a interpretarli.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la comprensione delle possibilità offerte dall'AI nella preparazione, elaborazione, analisi, interpretazione e rappresentazione dei dati, con le relative opportunità, condizioni di efficacia e limiti. La consapevolezza da sviluppare ha due facce. Da un lato, l'AI può rendere più accessibili le attività di analisi e facilitare l'individuazione di informazioni utili: chi non sa scrivere una formula complessa o un'interrogazione su un database può ottenere risultati ponendo domande in linguaggio naturale. Dall'altro, l'AI non garantisce automaticamente la correttezza delle elaborazioni, la validità delle interpretazioni o l'adeguatezza delle decisioni. Il valore dell'analisi dipende da tre fattori: la qualità dei dati, la correttezza del metodo, la capacità umana di interpretare i risultati. Il concetto centrale del tema: l'AI può facilitare l'accesso all'analisi dei dati e supportare elaborazioni, interpretazioni e decisioni, ma la correttezza dei risultati dipende da dati, metodi e ipotesi, mentre la responsabilità di attribuire significato alle informazioni e utilizzarle correttamente rimane umana.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Conoscere le possibilità dell'AI su dati e analisi", "Preparare, elaborare, rappresentare, interpretare", "Riconoscere opportunità, condizioni di efficacia e limiti"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Da che cosa dipende il valore", headSize: 16, fill: C.accent6, bodySize: 14,
      body: bullets(["Qualità dei dati", "Correttezza del metodo", "Capacità umana di interpretare i risultati"], { space: 6 }) });
  }
  {
    const s = content("Otto domande guida", "Le otto domande guida accompagnano il modulo. La prima è generale: quali attività di analisi può supportare l'AI. La seconda riguarda la comprensione e l'organizzazione di dataset e fogli di calcolo. La terza le elaborazioni quantitative e statistiche, con una distinzione che svilupperemo a fondo: quella tra un calcolo eseguito e un numero generato. La quarta l'identificazione di tendenze, anomalie e relazioni. La quinta i grafici e i report. La sesta una distinzione concettuale importante: descrivere i dati, interpretarli e fare previsioni sono attività diverse. La settima il supporto alle decisioni aziendali. L'ultima gli errori e i rischi da considerare. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Quali attività di analisi può supportare l'AI?", "Come aiuta a comprendere e organizzare dataset e fogli di calcolo?", "Come esegue elaborazioni quantitative e statistiche?", "Quali possibilità su tendenze, anomalie e relazioni?", "Come supporta la creazione di grafici e report?", "Descrivere, interpretare, prevedere: che differenza c'è?", "Come può supportare le decisioni aziendali?", "Quali errori e rischi dobbiamo considerare?"], 4, 1.2, 1.6, 13);
  }
  {
    const s = content("Il filo conduttore: quattro fasi", "Il documento di perimetro propone un filo concettuale in quattro fasi. Comprendere e preparare: che dati ci sono, come sono strutturati, che cosa significano, quanto sono affidabili. Corrispondono i sottotemi 9.1 e 9.2. Elaborare e analizzare: calcolare, aggregare, costruire indicatori, individuare tendenze e anomalie. Corrispondono il 9.3 e il 9.4. Rappresentare e prevedere: costruire grafici e report, fare stime e simulazioni. Corrispondono il 9.5 e il 9.6. Interpretare e valutare: attribuire significato ai risultati, sostenere le decisioni, controllare l'affidabilità. Corrispondono il 9.7 e il 9.8. Una precisazione importante, indicata dal documento: è uno schema didattico. Il lavoro analitico reale è iterativo: un'anomalia trovata nell'analisi può riportare alla preparazione dei dati, un grafico può suggerire una nuova domanda, un'interpretazione può richiedere un nuovo calcolo. Nelle slide, un indicatore in alto a destra ricorda la fase di cui stiamo parlando.");
    const st = [["FiDatabase", "Comprendere e preparare", "Disponibilità, struttura, definizioni, qualità", "9.1  9.2"], ["FiCpu", "Elaborare e analizzare", "Operazioni, indicatori, tendenze, anomalie", "9.3  9.4"], ["FiBarChart2", "Rappresentare e prevedere", "Visualizzazioni, scenari, stime", "9.5  9.6"], ["FiCheckCircle", "Interpretare e valutare", "Significato, scelte, affidabilità", "9.7  9.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.2, 2.1, 2.75, dark ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.7, 1.35, 0.7, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.1, y: 2.15, w: 1.9, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.8, w: 1.8, h: 0.6, fontSize: 11, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.1, y: 3.5, w: 1.9, h: 0.35, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.4, 0.17);
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.accent6, "iterazione");
    txt(s, [{ text: "Uno schema didattico: ", options: { bold: true, color: C.accent1 } }, { text: "il lavoro analitico reale è iterativo. Un'anomalia riporta ai dati, un grafico suggerisce una nuova domanda.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Quattro tipi di analisi", "Una distinzione che attraversa tutto il modulo, e che compare tra i risultati attesi: i quattro tipi di analisi. L'analisi descrittiva risponde alla domanda 'che cosa è successo?': quanto abbiamo venduto, in quali regioni, con quale andamento. L'analisi diagnostica risponde a 'perché è successo?': quali fattori spiegano il calo delle vendite in una regione. L'analisi predittiva risponde a 'che cosa potrebbe succedere?': quanto venderemo nel prossimo trimestre, con quale margine di incertezza. L'analisi prescrittiva risponde a 'che cosa conviene fare?': quale prezzo fissare, quanto ordinare, dove investire. I quattro tipi hanno un valore crescente per le decisioni, ma anche un grado crescente di incertezza e di dipendenza dalle ipotesi. Descrivere i dati è relativamente oggettivo, se i dati sono corretti. Spiegare richiede di distinguere correlazione e causalità. Prevedere richiede ipotesi sul futuro. Prescrivere richiede anche criteri di valore, cioè che cosa consideriamo un buon risultato. Uno degli errori più frequenti nell'uso dell'AI per l'analisi è passare da un tipo all'altro senza accorgersene: una descrizione diventa una spiegazione, una spiegazione diventa una raccomandazione.");
    const t = [["Descrittiva", "Che cosa è successo?", "Vendite per regione e mese"], ["Diagnostica", "Perché è successo?", "Fattori del calo in una regione"], ["Predittiva", "Che cosa potrebbe succedere?", "Vendite del prossimo trimestre"], ["Prescrittiva", "Che cosa conviene fare?", "Prezzo, ordini, investimenti"]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 2.3, y = 1.2 + (3 - i) * 0.3;
      const f = [C.background2, C.accent6, C.accent2, C.accent1][i];
      const fc = i >= 2 ? C.background1 : C.text1;
      shapeBox(s, x, y, 2.15, 2.4 - (3 - i) * 0.3 + 0.3, f, e[0]);
      txt(s, e[0], { x: x + 0.15, y: y + 0.1, w: 1.9, h: 0.38, fontSize: 15, bold: true, color: i >= 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: y + 0.5, w: 1.9, h: 0.5, fontSize: 12, bold: true, color: fc });
      txt(s, e[2], { x: x + 0.15, y: y + 1.0, w: 1.9, h: 0.5, fontSize: 11, italic: true, color: fc });
    });
    txt(s, "Valore per le decisioni, incertezza e dipendenza dalle ipotesi crescono", { x: 0.5, y: 4.05, w: 6.0, h: 0.4, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 6.6, y: 4.09, w: 2.9, h: 0.32, fill: { color: C.accent5 }, line: { type: "none" }, objectName: "freccia crescita" });
    txt(s, "Errore frequente: passare da un tipo all'altro senza accorgersene.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, previsioni e simulazioni, con priorità media. Vanno compresi e sperimentati: preparazione dei dati, analisi descrittiva, elaborazioni quantitative, tendenze, grafici e interpretazione critica. Vanno conosciuti e compresi: previsioni, simulazioni, correlazioni, incertezza, differenza tra analisi e raccomandazione. Vanno solo accennati: algoritmi statistici specialistici, modellazione avanzata, programmazione analitica complessa e architetture di Business Intelligence. Confini: non ripetiamo i principi del Machine Learning del Tema 2, la teoria degli errori del Tema 3, le tecniche di prompting del Tema 6, i metodi generali di verifica del Tema 7, che qui applichiamo ai dati. Non duplichiamo l'analisi documentale del Tema 8. Il confine principale è con il Tema 14: qui esploriamo che cosa si può fare con i dati grazie all'AI; il Tema 14 tratterà le condizioni organizzative e tecnologiche per renderli disponibili. La selezione e la valutazione economica dei progetti appartengono al Tema 15. Un'avvertenza pratica valida per tutto il modulo: i dati aziendali, specialmente se personali o riservati, vanno caricati solo negli strumenti autorizzati.");
    pathSlide(s, [["9.1", "L'AI come supporto all'analisi", "Alta"], ["9.2", "Preparazione e qualità dei dati", "Alta"], ["9.3", "Elaborazione quantitativa", "Alta"], ["9.4", "Pattern, tendenze e anomalie", "Alta"], ["9.5", "Visualizzazione e comunicazione", "Alta"], ["9.6", "Previsioni e simulazioni", "Media"], ["9.7", "Interpretazione e decisioni", "Alta"], ["9.8", "Limiti e affidabilità", "Alta"]],
      [["Comprendere e sperimentare", "Preparazione, analisi descrittiva, elaborazioni, tendenze, grafici, interpretazione", C.accent1, C.background1], ["Conoscere e comprendere", "Previsioni, simulazioni, correlazioni, incertezza, analisi e raccomandazione", C.accent6, C.text1], ["Solo accennare", "Algoritmi specialistici, modellazione avanzata, programmazione complessa, BI", C.background2, C.text1]]);
  }

  // =====================================================================
  section("9.1 AI e analisi");
  divider("9.1", "L'AI come supporto all'analisi dei dati", "Rendere più facile interrogare i dati non equivale a rendere corretta la loro interpretazione", "Partiamo dal quadro generale: che ruolo può avere l'AI nel lavoro con i dati. In questo sottotema, da comprendere, distinguiamo dati, informazioni e conoscenza, collochiamo l'AI rispetto all'analisi dei dati tradizionale e alla Business Intelligence, vediamo che cosa significa interrogare i dati in linguaggio naturale e affrontiamo la prima integrazione del tema: la democratizzazione dell'analisi, cioè la possibilità per chi non è specialista di fare analisi che prima richiedevano competenze tecniche. Con le sue opportunità e con le sue condizioni.");
  {
    const s = content("Dati, informazioni, conoscenza", "Nel Tema 8 abbiamo distinto dati, informazioni, documenti e conoscenza. Qui riprendiamo la distinzione dal punto di vista dei numeri. Un dato è un valore elementare registrato: 1.240, una data, un codice cliente. Diventa informazione quando ha un significato e un contesto: 'nel mese di marzo, il negozio di Bologna ha venduto 1.240 pezzi'. Diventa conoscenza quando permette di capire e agire: 'le vendite di Bologna sono calate del 15 per cento rispetto a marzo dell'anno scorso, mentre le altre sedi sono stabili; il calo coincide con l'apertura di un concorrente, e conviene valutare un'azione commerciale mirata'. Il passaggio da un livello all'altro non è automatico: richiede di sapere che cosa misura il dato, di scegliere confronti significativi, di interpretare il risultato alla luce del contesto. L'analisi dei dati è proprio il lavoro che compie questi passaggi. L'AI può aiutare in ciascuno di essi, ma il passaggio più delicato, dall'informazione alla conoscenza, dipende dalla conoscenza del dominio: sapere che è arrivato un concorrente, che marzo dell'anno scorso aveva una promozione, che il dato di Bologna include le vendite online.");
    phaseTag(s, 0);
    const lv = [["Dato", "1.240"], ["Informazione", "Marzo, Bologna: 1.240 pezzi venduti"], ["Conoscenza", "Calo del 15% sull'anno, solo a Bologna, con l'arrivo di un concorrente: valutare un'azione mirata"]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.82, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.0, h: 0.82, fontSize: 15, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 2.7, y, w: 6.6, h: 0.82, fontSize: i ? 13 : 20, bold: i === 0, color: i === 2 ? C.background1 : C.text1, valign: "middle" });
    });
    banner(s, 4.1, "Dall'informazione alla conoscenza serve il dominio: un concorrente, una promozione dell'anno scorso, che cosa include il dato.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Analisi dei dati e BI", "Prima dell'AI generativa, l'analisi dei dati in azienda si basava su strumenti e figure consolidate. I fogli di calcolo, usati da quasi tutti, per calcoli, tabelle e grafici. Gli strumenti di Business Intelligence, che raccolgono dati da diversi sistemi aziendali e li presentano in report e cruscotti, con indicatori definiti e aggiornati periodicamente. Gli strumenti statistici e i linguaggi di programmazione, usati dagli analisti per analisi più complesse. E le persone: analisti, controller, data scientist, che conoscono i dati, i metodi e gli strumenti. In questo quadro, chi non aveva competenze tecniche dipendeva dai report predefiniti o dalla disponibilità degli analisti. L'AI non sostituisce questi strumenti, ma si inserisce in modi diversi: come assistente nei fogli di calcolo, che suggerisce formule e grafici; come interfaccia in linguaggio naturale verso gli strumenti di BI; come assistente conversazionale che riceve un file e lo analizza scrivendo ed eseguendo codice; come supporto agli analisti nella scrittura di codice. Le architetture di BI e l'integrazione con i sistemi aziendali sono solo da accennare: appartengono al Tema 14.");
    phaseTag(s, 0);
    txt(s, "Strumenti consolidati", { x: 0.5, y: 1.12, w: 4.35, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const tr = [["FiGrid", "Fogli di calcolo", "Calcoli, tabelle, grafici"], ["FiPieChart", "Business Intelligence", "Report e cruscotti con indicatori definiti"], ["FiTerminal", "Strumenti statistici e codice", "Analisi complesse, per specialisti"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.5 + i * 0.78;
      shapeBox(s, 0.5, y, 4.35, 0.68, C.background2, tr[i][1]);
      await iconCircle(s, 0.62, y + 0.11, 0.46, tr[i][0], C.accent2);
      txt(s, tr[i][1], { x: 1.2, y: y + 0.05, w: 3.5, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
      txt(s, tr[i][2], { x: 1.2, y: y + 0.35, w: 3.5, h: 0.3, fontSize: 11, color: C.text2 });
    }
    txt(s, "Dove si inserisce l'AI", { x: 5.15, y: 1.12, w: 4.35, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    const ai = ["Assistente nei fogli di calcolo", "Linguaggio naturale verso la BI", "Assistente che analizza un file con codice", "Supporto agli analisti nel codice"];
    ai.forEach((t, i) => chip(s, 5.15, 1.5 + i * 0.585, 4.35, 0.5, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.0, "L'AI non sostituisce questi strumenti: vi si inserisce. Architetture di BI e integrazioni: Tema 14.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Il ruolo dell'AI nel processo", "Vediamo dove l'AI può intervenire lungo il processo analitico. Formulare la domanda: aiutare a chiarire che cosa si vuole sapere e quali dati servono. Comprendere i dati: descrivere la struttura di un file, il significato probabile delle colonne, i problemi evidenti. Preparare i dati: suggerire o eseguire pulizia, conversioni, unioni tra tabelle. Elaborare: calcolare indicatori, aggregazioni, statistiche, scrivere formule o codice. Individuare fenomeni: tendenze, anomalie, relazioni. Rappresentare: proporre e creare grafici, tabelle riepilogative, report. Interpretare: proporre spiegazioni, ipotesi, implicazioni. In ciascuna fase l'AI può accelerare molto il lavoro. Ma il suo contributo cambia natura lungo il processo. Nelle prime fasi, il rischio principale è tecnico: un dato interpretato male, un calcolo sbagliato. Nelle ultime fasi, il rischio diventa interpretativo: una spiegazione plausibile ma infondata, una conclusione che va oltre i dati. Ed è proprio nelle ultime fasi che il contributo umano, con la conoscenza del contesto e il giudizio, diventa più importante.");
    phaseTag(s, 0);
    const st = ["Domanda", "Comprendere i dati", "Preparare", "Elaborare", "Individuare fenomeni", "Rappresentare", "Interpretare"];
    st.forEach((t, i) => {
      const x = 0.5 + i * 1.3;
      chip(s, x, 1.3, 1.18, 0.8, t, { fill: i < 4 ? C.background2 : (i < 6 ? C.accent6 : C.accent1), color: i === 6 ? C.background1 : C.text1, fontSize: 11 });
    });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 0.5, y: 2.25, w: 9.0, h: 0.3, fill: { color: C.accent3 }, line: { type: "none" }, objectName: "freccia processo" });
    await card(s, 0.5, 2.75, 4.35, 1.6, { icon: "FiCpu", inline: true, head: "Rischio tecnico", headSize: 14, bodySize: 12, body: "Nelle prime fasi: un dato interpretato male, un calcolo sbagliato." });
    await card(s, 5.15, 2.75, 4.35, 1.6, { icon: "FiMessageCircle", inline: true, head: "Rischio interpretativo", headSize: 14, bodySize: 12, fill: C.accent6, body: "Nelle ultime fasi: una spiegazione plausibile ma infondata, una conclusione oltre i dati." });
    txt(s, "Più si avanza nel processo, più conta il contributo umano: contesto e giudizio.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Domande in linguaggio naturale", "La novità più visibile dell'AI nell'analisi è la possibilità di interrogare i dati ponendo domande in linguaggio naturale, invece di scrivere formule, interrogazioni o codice. L'esempio fittizio in slide mostra una domanda e ciò che il sistema deve fare per rispondere. Sembra semplice, ma per rispondere il sistema deve tradurre la domanda in operazioni precise, e in questa traduzione compie delle scelte. Che cosa significa 'clienti'? Tutti quelli in anagrafica o quelli con almeno un acquisto? 'Ultimo trimestre' è il trimestre solare o gli ultimi novanta giorni? 'Hanno speso di più' significa fatturato lordo o netto di resi e sconti? Ogni scelta è ragionevole, ma una scelta diversa produce un risultato diverso. Il problema è che queste scelte spesso non sono visibili nella risposta: si vede un elenco ordinato di clienti, non le ipotesi che lo hanno prodotto. Per questo, una buona pratica è chiedere al sistema di esplicitare come ha interpretato la domanda e quali operazioni ha eseguito, oppure formulare la domanda in modo più preciso fin dall'inizio, usando le definizioni aziendali.");
    phaseTag(s, 0);
    docBox(s, 0.5, 1.15, 9.0, 0.75, "Domanda (esempio fittizio)", "Quali sono i dieci clienti che hanno speso di più nell'ultimo trimestre?", { fontSize: 14 });
    txt(s, "Le scelte nascoste nella traduzione in operazioni", { x: 0.5, y: 2.05, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const q = [["Clienti", "In anagrafica o con almeno un acquisto?"], ["Ultimo trimestre", "Trimestre solare o ultimi 90 giorni?"], ["Speso di più", "Fatturato lordo o netto di resi e sconti?"]];
    q.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.45, 2.86, 1.15, C.accent6, e[0]);
      txt(s, "'" + e[0] + "'", { x: x + 0.15, y: 2.52, w: 2.56, h: 0.38, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 2.92, w: 2.56, h: 0.6, fontSize: 12, color: C.text1 });
    });
    banner(s, 3.8, "Ogni scelta è ragionevole, ma cambia il risultato. Chiedere come è stata interpretata la domanda, o usare le definizioni aziendali.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Analisi tradizionale e assistita", "Confrontiamo analisi tradizionale e analisi assistita dall'AI. Nell'analisi tradizionale, chi analizza sceglie ed esegue ogni operazione: scrive la formula, costruisce la tabella pivot, sceglie il grafico. Il processo è lento e richiede competenze tecniche, ma ogni passaggio è esplicito e controllabile, e chi analizza sa esattamente che cosa ha fatto. Nell'analisi assistita, si formula la richiesta e il sistema sceglie ed esegue le operazioni. Il processo è molto più rapido e accessibile, ma i passaggi possono essere meno visibili: le scelte di metodo sono state fatte dal sistema, e bisogna ricostruirle per controllarle. Un modo per dirlo: nell'analisi tradizionale il rischio è non riuscire a fare l'analisi; in quella assistita il rischio è fare un'analisi senza sapere esattamente quale. Non si tratta di scegliere l'una o l'altra: nella pratica si combinano. L'AI accelera esplorazione e prime elaborazioni; per i risultati importanti, si rendono espliciti metodo e passaggi, e si controllano. La tracciabilità delle operazioni, che vedremo nel 9.3, è il ponte tra i due approcci.");
    phaseTag(s, 0);
    table(s, [["", "Analisi tradizionale", "Analisi assistita dall'AI"],
      ["Chi sceglie le operazioni", "Chi analizza", "Il sistema, dalla richiesta"],
      ["Velocità", "Lenta", "Molto rapida"],
      ["Competenze tecniche", "Necessarie", "Ridotte"],
      ["Visibilità dei passaggi", "Esplicita", "Da ricostruire"],
      ["Rischio tipico", "Non riuscire a fare l'analisi", "Fare un'analisi senza sapere quale"]],
      { y: 1.15, colW: [2.6, 3.0, 3.4], rowH: 0.45, fontSize: 12, accentCol: 2 });
    banner(s, 4.05, "Nella pratica si combinano. La tracciabilità delle operazioni è il ponte tra i due approcci.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("La democratizzazione dell'analisi", "Prima integrazione del tema: la democratizzazione dell'analisi dei dati. Il linguaggio naturale riduce le barriere tecniche: un responsabile commerciale può analizzare le vendite della sua area senza chiedere un report all'ufficio controllo; un responsabile del personale può esplorare i dati sulle assenze; chiunque può farsi spiegare un foglio di calcolo ricevuto. È un'opportunità reale: più persone possono rispondere alle proprie domande, più rapidamente, con i dati invece che con le impressioni. Ma il documento di perimetro precisa che il linguaggio naturale riduce le barriere tecniche senza eliminare il bisogno di competenze interpretative e giudizio critico. Le barriere tecniche erano anche, in parte, una protezione: chi sapeva fare un'analisi sapeva di solito anche riconoscerne i limiti. Ora chi non ha competenze analitiche può ottenere risultati che non è in grado di valutare: un confronto tra gruppi non omogenei, una media influenzata da pochi valori estremi, una correlazione presentata come causa. La consapevolezza del sottotema lo dice in una frase: rendere più facile interrogare i dati non equivale a rendere automaticamente corretta la loro interpretazione.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.45, { icon: "FiUsers", head: "Che cosa diventa possibile", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Analizzare le vendite della propria area", "Esplorare dati senza chiedere un report", "Farsi spiegare un foglio di calcolo", "Decidere con i dati, non con le impressioni"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.45, { icon: "FiAlertTriangle", head: "Che cosa resta necessario", headSize: 15, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Riconoscere gruppi non confrontabili", "Diffidare di medie influenzate da pochi valori", "Non leggere una correlazione come causa", "Sapere quando chiedere a uno specialista"], { space: 4 }) });
    banner(s, 3.85, "Il linguaggio naturale riduce le barriere tecniche, non il bisogno di competenze interpretative e giudizio critico.", { h: 0.7, fontSize: 13 });
    txt(s, "Integrazione C: democratizzazione dell'analisi dei dati", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Competenze umane e dominio", "Se la tecnica diventa meno necessaria, quali competenze restano centrali? Il sottotema ne indica due famiglie. Le competenze analitiche di base: sapere che cosa si può e non si può concludere da un insieme di dati, riconoscere i confronti non omogenei, distinguere media e mediana, sapere che pochi dati danno risultati instabili, distinguere correlazione e causalità. Non serve diventare statistici, ma conoscere i principali modi in cui un'analisi può ingannare. La conoscenza del dominio: sapere come sono stati raccolti i dati, che cosa misurano davvero, quali eventi possono spiegarne l'andamento, quali valori sono plausibili, quali definizioni usa l'azienda. È la conoscenza che permette di accorgersi che un aumento improvviso coincide con un cambio di sistema gestionale, che un calo stagionale è normale, che un indicatore è calcolato in modo diverso da un anno all'altro. L'AI non possiede questa conoscenza, a meno che non le venga fornita, e anche in quel caso non ne ha l'esperienza. In sintesi: con l'AI cambia il peso relativo delle competenze. Meno tecnica, più interpretazione e conoscenza del contesto.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.65, { icon: "FiBookOpen", head: "Competenze analitiche di base", headSize: 15, bodySize: 12,
      body: bullets(["Che cosa si può concludere", "Confronti omogenei, media e mediana", "Pochi dati, risultati instabili", "Correlazione e causalità"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.65, { icon: "FiBriefcase", head: "Conoscenza del dominio", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Come sono stati raccolti i dati", "Che cosa misurano davvero", "Eventi, stagionalità, cambi di sistema", "Valori plausibili, definizioni aziendali"], { space: 4 }) });
    shapeBox(s, 0.5, 4.05, 9.0, 0.9, C.text1, "peso competenze");
    txt(s, [{ text: "Con l'AI cambia il peso delle competenze: ", options: { color: C.background1 } }, { text: "meno tecnica, più interpretazione e contesto.", options: { color: C.accent6, bold: true } }], { x: 0.7, y: 4.05, w: 8.6, h: 0.9, fontSize: 15, valign: "middle" });
  }
  keySlide("Rendere più facile interrogare dati non equivale a rendere automaticamente corretta la loro interpretazione.", "Sottotema 9.1  ·  L'AI come supporto all'analisi dei dati", "Concetto chiave del primo sottotema. L'AI si inserisce lungo tutto il processo analitico e lo rende accessibile anche a chi non è specialista, grazie al linguaggio naturale. È una democratizzazione reale e di grande valore. Ma ogni domanda in linguaggio naturale viene tradotta in operazioni con scelte implicite, i passaggi sono meno visibili che nell'analisi tradizionale, e il rischio si sposta dalla tecnica all'interpretazione. Restano centrali le competenze analitiche di base e, soprattutto, la conoscenza del dominio. Esercizio suggerito: dare ai partecipanti una domanda in linguaggio naturale su un dataset fittizio e chiedere di elencare tutte le interpretazioni possibili dei termini, poi confrontare i risultati ottenuti con interpretazioni diverse.");

  // =====================================================================
  section("9.2 Preparazione e qualità");
  divider("9.2", "Comprensione, preparazione e qualità dei dati", "Un dataset apparentemente ordinato non è necessariamente corretto, completo o rappresentativo", "Prima di analizzare i dati, bisogna capirli e prepararli. È la fase meno visibile e spesso la più lunga del lavoro analitico, ed è anche quella in cui nascono molti degli errori che si ritrovano nelle conclusioni. In questo sottotema, da comprendere e sperimentare, vediamo i tipi di dati e di formati, come comprendere la struttura di un dataset, i problemi tipici di qualità, come dati mancanti, duplicati e valori anomali, la pulizia e la trasformazione, la rappresentatività del campione, l'importanza delle definizioni e della provenienza. E una distinzione che il documento di perimetro chiede di rendere esplicita: dati, metriche e indicatori.");
  {
    const s = content("Tipi di dati e formati", "Una prima distinzione, già incontrata nel Tema 8. I dati strutturati sono organizzati in righe e colonne con un significato definito: una tabella di vendite, un elenco di clienti, un registro di presenze. I dati non strutturati sono testi, email, documenti, immagini, registrazioni: contengono informazioni, ma non in forma direttamente calcolabile. Nel Tema 8 abbiamo visto come l'AI può trasformare i secondi nei primi; qui ci concentriamo sui dati strutturati. I formati più comuni sono tre. Il foglio di calcolo, come Excel, che può contenere più fogli, formule, formattazioni, celle unite, note: molto flessibile, e proprio per questo spesso disordinato. Il file CSV, cioè valori separati da virgole o punti e virgola: un formato semplice, solo dati, senza formule né formattazioni, molto usato per esportare dati dai sistemi. Le tabelle dei database e dei sistemi gestionali, a cui si accede di solito attraverso esportazioni o strumenti di BI. Un dataset, nel linguaggio dell'analisi, è un insieme di dati organizzato per un'analisi: per esempio l'esportazione delle vendite dell'ultimo anno.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 1.6, { icon: "FiGrid", inline: true, head: "Dati strutturati", headSize: 15, bodySize: 12, fill: C.accent6, body: "Righe e colonne con un significato definito: vendite, clienti, presenze." });
    await card(s, 5.15, 1.2, 4.35, 1.6, { icon: "FiFileText", inline: true, head: "Dati non strutturati", headSize: 15, bodySize: 12, body: "Testi, email, immagini, registrazioni. Trasformarli in dati: Tema 8." });
    const f = [["Foglio di calcolo", "Più fogli, formule, celle unite, note: flessibile e spesso disordinato"], ["CSV", "Solo dati separati da un carattere: semplice, usato per le esportazioni"], ["Database e gestionali", "Accesso con esportazioni o strumenti di BI"]];
    f.forEach((e, i) => {
      const y = 3.0 + i * 0.62;
      shapeBox(s, 0.5, y, 9.0, 0.54, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.5, h: 0.54, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.2, y, w: 6.1, h: 0.54, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Comprendere la struttura", "Il primo uso dell'AI su un dataset è spesso semplicemente capirlo: di che cosa parla, che cosa rappresenta ogni riga, che cosa contiene ogni colonna, quali problemi ci sono. È molto utile quando si riceve un file preparato da altri, o un'esportazione da un sistema poco conosciuto. L'AI può descrivere la struttura, ipotizzare il significato delle colonne dai nomi e dai valori, segnalare righe di totale mescolate ai dati, intestazioni su più righe, celle unite, colonne vuote. L'esempio fittizio in slide mostra un piccolo estratto con alcuni problemi tipici. Una cautela importante: il significato delle colonne è un'ipotesi del sistema. 'Importo' è con o senza IVA? 'Data' è la data dell'ordine, della consegna o della fattura? 'Stato 3' che cosa significa? Il sistema può proporre un'interpretazione plausibile, ma solo chi conosce il dato, o la documentazione del sistema da cui proviene, può confermarla. Un errore in questa fase si propaga a tutta l'analisi: se 'Importo' è interpretato come netto mentre è lordo, ogni calcolo successivo sarà sbagliato, e in modo coerente, quindi difficile da notare.");
    phaseTag(s, 0);
    table(s, [["Data", "Cliente", "Importo", "Stato"],
      ["03/04/2025", "Rossi Srl", "1.200", "3"],
      ["2025-04-05", "ROSSI S.R.L.", "980", "3"],
      ["07/04/2025", "Bianchi Spa", "", "2"],
      ["Totale", "", "2.180", ""]],
      { x: 0.5, y: 1.15, w: 5.0, colW: [1.3, 1.5, 1.1, 1.1], rowH: 0.4, fontSize: 12, blankCorner: false });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.2, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    const iss = ["Due formati di data", "Lo stesso cliente scritto in due modi", "Un importo mancante", "Una riga di totale tra i dati", "'Stato 3': che cosa significa?"];
    iss.forEach((t, i) => chip(s, 5.75, 1.15 + i * 0.42, 3.75, 0.36, t, { fill: C.accent6, fontSize: 11 }));
    banner(s, 3.6, "Il significato delle colonne è un'ipotesi del sistema: 'Importo' con o senza IVA? 'Data' dell'ordine o della fattura? Lo conferma solo chi conosce il dato.", { h: 0.9, fontSize: 12 });
    txt(s, "Un errore qui si propaga a tutta l'analisi, in modo coerente e quindi difficile da notare.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Variabili e formati", "Ogni colonna di un dataset rappresenta una variabile, e il tipo di variabile determina quali operazioni hanno senso. Le variabili numeriche continue, come importi, pesi, durate, si possono sommare, mediare, confrontare. Le variabili numeriche discrete, come numero di pezzi o di ordini, sono conteggi. Le variabili categoriche, come regione, prodotto, canale, servono a raggruppare: non ha senso farne la media. Le variabili ordinali, come una valutazione da 1 a 5 o un livello di priorità, hanno un ordine, ma la distanza tra i livelli non è necessariamente uguale: la media di una scala di soddisfazione va usata con cautela. Le date richiedono attenzione particolare. Alcuni problemi di formato tipici, che l'AI deve riconoscere correttamente e che conviene controllare: numeri memorizzati come testo, che non vengono sommati; separatori decimali diversi, come la virgola italiana e il punto anglosassone, per cui 1.200 può essere milleduecento o uno virgola due; date in formati diversi, come 03/04 che può essere 3 aprile o 4 marzo; codici numerici, come CAP o codici prodotto, trattati come numeri, con la perdita degli zeri iniziali.");
    phaseTag(s, 0);
    table(s, [["Tipo di variabile", "Esempi", "Operazioni sensate"],
      ["Numerica continua", "Importi, durate, pesi", "Somme, medie, confronti"],
      ["Numerica discreta", "Pezzi, ordini", "Conteggi, somme"],
      ["Categorica", "Regione, prodotto, canale", "Raggruppare, contare"],
      ["Ordinale", "Valutazione 1-5, priorità", "Ordinare; medie con cautela"]],
      { y: 1.15, colW: [2.5, 3.0, 3.5], rowH: 0.42, fontSize: 12, blankCorner: false });
    txt(s, "Problemi di formato da controllare", { x: 0.5, y: 3.35, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    const p = ["Numeri come testo", "1.200: mille o uno virgola due?", "03/04: marzo o aprile?", "CAP senza zeri iniziali"];
    p.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.75, 2.15, 0.6, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Il tipo di variabile determina quali operazioni hanno senso.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Mancanti, duplicati, anomali", "Tre problemi di qualità ricorrenti, che l'AI può aiutare molto a individuare. I dati mancanti: celle vuote, o valori convenzionali come zero, 'n.d.', 999. Il punto chiave è che un dato mancante non è uno zero: se un importo mancante viene trattato come zero, la media si abbassa; se viene escluso, il conteggio cambia. Bisogna anche chiedersi perché manca: se mancano soprattutto i dati di una sede o di un periodo, l'analisi può risultare distorta. I duplicati: la stessa riga presente due volte, magari per un'esportazione ripetuta, o lo stesso cliente registrato con nomi leggermente diversi. I duplicati gonfiano totali e conteggi. I valori anomali: valori molto lontani dagli altri, come un ordine da un milione tra ordini da mille euro. Possono essere errori, come una virgola spostata, o casi reali e importanti, come un grande cliente. I valori incoerenti: una data di consegna precedente all'ordine, un'età di 150 anni, una quantità negativa. L'AI è efficace nel segnalare questi casi. Ma la decisione su come trattarli, cioè eliminare, correggere, tenere o analizzare a parte, richiede di conoscere il contesto, e va presa consapevolmente, non lasciata al sistema.");
    phaseTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMinusCircle", head: "Mancanti", body: "Un dato mancante non è uno zero. E perché manca?" },
      { icon: "FiCopy", head: "Duplicati", body: "Righe ripetute, nomi diversi per lo stesso cliente" },
      { icon: "FiZap", head: "Anomali", body: "Errore o caso reale importante? Va capito" },
      { icon: "FiXOctagon", head: "Incoerenti", body: "Consegna prima dell'ordine, quantità negative" },
    ], 4, { y: 1.2, h: 2.0, headSize: 14, bodySize: 12 });
    banner(s, 3.45, "L'AI li segnala bene. Ma eliminare, correggere, tenere o analizzare a parte è una decisione che richiede il contesto.", { h: 0.85, fontSize: 13 });
    txt(s, "Un importo mancante trattato come zero abbassa la media; escluso, cambia il conteggio.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Pulizia e trasformazione", "Una volta individuati i problemi, i dati vanno preparati. Le operazioni principali sono tre. La pulizia: eliminare duplicati, correggere errori evidenti, gestire i mancanti, rimuovere righe di totale o di intestazione. La normalizzazione: rendere omogenei i valori, come date tutte nello stesso formato, nomi di clienti uniformati, unità di misura coerenti, categorie scritte allo stesso modo. La trasformazione: creare nuove colonne a partire da quelle esistenti, come il mese dalla data o il margine dal prezzo e dal costo, unire tabelle diverse, ristrutturare i dati per l'analisi. L'AI è molto efficace in queste operazioni, sia eseguendole direttamente sia scrivendo formule o codice. Ma ogni operazione di pulizia è una scelta che può cambiare i risultati. Unire 'Rossi Srl' e 'ROSSI S.R.L.' è corretto, ma unire due clienti diversi con nomi simili è un errore. Eliminare un valore anomale può togliere un errore o un caso importante. Unire due tabelle con una chiave sbagliata può duplicare o perdere righe senza segnali evidenti. Per questo, due regole pratiche: chiedere sempre l'elenco delle operazioni eseguite, con il numero di righe coinvolte, e conservare i dati originali, così da poter tornare indietro.");
    phaseTag(s, 0);
    const op = [["FiTrash2", "Pulizia", "Duplicati, errori, mancanti, righe di totale"], ["FiSliders", "Normalizzazione", "Formati, nomi, unità, categorie omogenei"], ["FiShuffle", "Trasformazione", "Nuove colonne, unioni tra tabelle"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.2, 2.86, 1.55, { icon: op[i][0], inline: true, head: op[i][1], headSize: 14, bodySize: 12, body: op[i][2] });
    }
    txt(s, "Ogni operazione è una scelta che può cambiare i risultati", { x: 0.5, y: 2.9, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    chip(s, 0.5, 3.3, 2.9, 0.6, "Unire due clienti diversi", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.3, 2.9, 0.6, "Eliminare un caso importante", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.3, 2.9, 0.6, "Unione con chiave sbagliata", { fill: C.background2, fontSize: 12 });
    banner(s, 4.1, "Chiedere l'elenco delle operazioni con il numero di righe coinvolte, e conservare sempre i dati originali.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Rappresentatività e distorsioni", "Un dataset può essere pulito, completo e corretto, e tuttavia non rappresentare il fenomeno che si vuole analizzare. È il problema della rappresentatività. Alcuni esempi tipici. Un questionario di soddisfazione compilato solo dai clienti che hanno voluto rispondere: rappresenta i clienti più motivati, spesso i più soddisfatti o i più scontenti. I dati di un solo canale di vendita usati per trarre conclusioni su tutti i clienti. I dati di un periodo particolare, come i mesi di una promozione o di una crisi, usati come se fossero normali. I dati dei clienti attuali, che escludono quelli persi: se si analizzano solo i clienti rimasti, si perde proprio l'informazione sul perché gli altri se ne sono andati. Quest'ultimo caso è un esempio di distorsione da sopravvivenza: si guardano solo i casi che sono sopravvissuti a una selezione. Il punto importante per chi usa l'AI è che il sistema analizza i dati che riceve, e normalmente non si chiede se rappresentano il fenomeno. Può farlo se glielo si chiede, ma la domanda su che cosa manca, chi non è nel dataset e perché, richiede di conoscere come i dati sono stati raccolti.");
    phaseTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMessageSquare", head: "Chi ha scelto di rispondere", body: "Questionari volontari: i più motivati" },
      { icon: "FiShoppingCart", head: "Un solo canale", body: "Conclusioni estese a tutti i clienti" },
      { icon: "FiCalendar", head: "Un periodo particolare", body: "Promozioni o crisi trattate come normali" },
      { icon: "FiUserX", head: "Solo chi è rimasto", body: "Distorsione da sopravvivenza: mancano i clienti persi" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Il sistema analizza i dati che riceve. Chi non è nel dataset, e perché, lo sa chi conosce come sono stati raccolti.", { h: 0.7, fontSize: 13 });
    txt(s, "Un dataset pulito e corretto può comunque non rappresentare il fenomeno.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Definizioni e provenienza", "Due aspetti della qualità dei dati che spesso non sono scritti nel file. Le definizioni: che cosa misura esattamente ogni dato? Un 'cliente attivo' è chi ha acquistato negli ultimi dodici mesi o negli ultimi sei? Un 'ordine' include quelli annullati? Il 'fatturato' è al netto dei resi? Le definizioni cambiano da un'azienda all'altra, da un reparto all'altro, e a volte nel tempo all'interno della stessa azienda. Se due dataset usano definizioni diverse, confrontarli produce risultati sbagliati con l'aspetto di risultati precisi. E se l'AI non conosce le definizioni aziendali, userà quelle più comuni, che possono essere diverse. La provenienza: da quale sistema vengono i dati, chi li ha estratti, quando, con quali filtri, che trasformazioni hanno subito? Un file che circola da mesi tra colleghi, modificato più volte, ha una provenienza incerta. Alcune domande utili prima di analizzare un dataset: da dove viene? Quando è stato estratto? Con quali criteri? Quali definizioni usa? Chi può confermarle? Fornire queste informazioni al sistema migliora l'analisi; non averle è un'incertezza da dichiarare nei risultati.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiBook", head: "Definizioni", headSize: 15, bodySize: 12,
      body: bullets(["'Cliente attivo': 12 mesi o 6?", "'Ordine': inclusi gli annullati?", "'Fatturato': al netto dei resi?"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiGitCommit", head: "Provenienza", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Da quale sistema, chi li ha estratti", "Quando, con quali filtri", "Quali trasformazioni hanno subito"], { space: 4 }) });
    txt(s, "Prima di analizzare", { x: 0.5, y: 3.55, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    const q = ["Da dove viene?", "Quando è stato estratto?", "Con quali criteri?", "Quali definizioni?", "Chi può confermarle?"];
    q.forEach((t, i) => chip(s, 0.5 + i * 1.82, 3.95, 1.7, 0.55, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Definizioni diverse producono confronti sbagliati con l'aspetto di confronti precisi.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Dati, metriche e indicatori", "Il documento di perimetro chiede di rendere esplicita una distinzione spesso confusa: dati, metriche e indicatori. Il dato è il valore registrato: il singolo ordine, con la sua data, il cliente e l'importo. La metrica è una misura calcolata dai dati con una regola definita: il fatturato mensile, il numero di ordini, il valore medio dell'ordine, il tasso di reso. L'indicatore, spesso chiamato KPI, è una metrica scelta per valutare un obiettivo, con un valore di riferimento: il valore medio dell'ordine confrontato con l'obiettivo di 250 euro, il tasso di reso con la soglia del 3 per cento. Perché la distinzione conta? Perché ogni passaggio comporta scelte. Passando dal dato alla metrica, si sceglie la formula: il valore medio dell'ordine include le spese di spedizione? I resi vengono sottratti? Passando dalla metrica all'indicatore, si sceglie che cosa conta come buon risultato, e questa è una scelta di valore, non un fatto. Quando si chiede all'AI di calcolare un indicatore, conviene fornire la definizione aziendale. Altrimenti il sistema ne userà una plausibile, e il risultato non sarà confrontabile con quello dei report ufficiali.");
    phaseTag(s, 0);
    const lv = [["Dato", "Il valore registrato", "Ordine 4471, 12 marzo, 230 €"], ["Metrica", "Misura calcolata con una regola", "Valore medio dell'ordine: 214 €"], ["Indicatore", "Metrica scelta per un obiettivo", "214 € contro l'obiettivo di 250 €"]];
    lv.forEach((l, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.85, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), l[0]);
      const fc = i === 2 ? C.background1 : C.text1;
      txt(s, l[0], { x: x + 0.15, y: 1.25, w: 2.56, h: 0.42, fontSize: 18, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, l[1], { x: x + 0.15, y: 1.7, w: 2.56, h: 0.5, fontSize: 12, bold: true, color: fc });
      txt(s, l[2], { x: x + 0.15, y: 2.25, w: 2.56, h: 0.6, fontSize: 12, italic: true, color: fc });
      if (i < 2) arrow(s, x + 2.88, 1.92, 0.17);
    });
    chip(s, 2.0, 3.15, 2.9, 0.55, "Scelta della formula", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.15, 2.9, 0.55, "Scelta di che cosa è un buon risultato", { fill: C.background2, fontSize: 12 });
    banner(s, 3.95, "Fornire all'AI le definizioni aziendali: altrimenti ne userà di plausibili, e il risultato non sarà confrontabile con i report ufficiali.", { h: 0.9, fontSize: 13 });
  }
  keySlide("Un dataset apparentemente ordinato non è necessariamente corretto, completo o rappresentativo del fenomeno analizzato.", "Sottotema 9.2  ·  Comprensione, preparazione e qualità dei dati", "Concetto chiave del sottotema 9.2. Prima dell'analisi vengono la comprensione e la preparazione dei dati: struttura, tipi di variabili, formati, mancanti, duplicati, anomalie, pulizia e trasformazione. L'AI è un aiuto prezioso per individuare problemi e preparare i dati, ma ogni operazione di pulizia è una scelta, il significato delle colonne è un'ipotesi da confermare, e la rappresentatività del dataset non si vede guardando i dati. Definizioni e provenienza, e la distinzione tra dati, metriche e indicatori, sono condizioni per risultati confrontabili. Esercizio suggerito: dare ai partecipanti un piccolo file fittizio con problemi di qualità nascosti, come date in due formati, un duplicato con nome diverso, un mancante e un valore anomalo, e chiedere di farlo analizzare all'AI prima e dopo una richiesta esplicita di controllo della qualità.");
