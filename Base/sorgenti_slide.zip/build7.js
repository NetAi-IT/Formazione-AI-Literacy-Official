const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 7: Verifica degli output e pensiero critico";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 7  ·  Verifica degli output e pensiero critico";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 1.5, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }


  function flowTag(s, active) {
    const st = ["Valutare", "Verificare", "Decidere"];
    st.forEach((t, i) => {
      const x = 7.0 + i * 0.85;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "fase " + t });
      txt(s, t, { x, y: 0.42, w: 0.8, h: 0.26, fontSize: 9, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }


  // ---------- helper aggiuntivi della revisione ----------
  function rowBox(s, x, y, w, h, head, body, fill, colorHead, colorBody) {
    shapeBox(s, x, y, w, h, fill || C.background2, head);
    txt(s, head, { x: x + 0.18, y: y + 0.06, w: w - 0.36, h: 0.32, fontSize: 13, bold: true, color: colorHead || C.text1 });
    txt(s, body, { x: x + 0.18, y: y + 0.38, w: w - 0.36, h: h - 0.44, fontSize: 11, color: colorBody || C.text2 });
  }
  async function exFlow(s, a, b, c, note) {
    const cols = [[0.5, 2.6], [3.25, 3.5], [6.9, 2.6]];
    const labels = ["1  Input", "2  Richiesta all'AI", "3  Risultato atteso"];
    const icons = ["FiFileText", "FiMessageSquare", "FiCheckCircle"];
    for (let i = 0; i < 3; i++) {
      const [x, w] = cols[i];
      shapeBox(s, x, 1.2, w, 3.1, i === 1 ? C.accent6 : (i === 2 ? C.background2 : C.background2), labels[i]);
      await iconCircle(s, x + 0.15, 1.3, 0.42, icons[i]);
      txt(s, labels[i], { x: x + 0.65, y: 1.3, w: w - 0.8, h: 0.42, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
    }
    txt(s, a, { x: 0.68, y: 1.85, w: 2.24, h: 2.35, fontSize: 12, color: C.text2 });
    txt(s, b, { x: 3.43, y: 1.85, w: 3.14, h: 2.35, fontSize: 10.5, color: C.text1, fontFace: "Courier New" });
    txt(s, bullets(c, { space: 5 }), { x: 7.05, y: 1.85, w: 2.35, h: 2.35, fontSize: 11, color: C.text2 });
    banner(s, 4.45, note, { h: 0.55, fontSize: 12 });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 7", { placeholder: "kicker" });
    s.addText("Verifica degli output e pensiero critico nell'utilizzo dell'AI", { placeholder: "title" });
    s.addText("Area: Interagire con l'AI\nContenuti aggiornati a ottobre 2026", { placeholder: "sub" });
    s.addNotes("Benvenuti al settimo tema, che completa l'area 'Interagire con l'AI'. Nel Tema 5 abbiamo visto il dialogo e la collaborazione con l'AI, nel Tema 6 come formulare richieste efficaci. Qui affrontiamo la competenza che permette di sfruttarli al meglio: saper valutare e verificare i risultati. Un buon prompt migliora l'aderenza alla richiesta, ma non garantisce da solo la correttezza; d'altra parte, verificare tutto con la stessa intensità farebbe perdere gran parte del valore dell'AI. L'obiettivo del modulo è imparare a scegliere che cosa verificare, come farlo, anche con l'aiuto dell'AI stessa, e quando un risultato è abbastanza affidabile per essere usato. La verifica non è un freno all'adozione: è ciò che permette di affidare all'AI attività via via più importanti. Suggerimento per l'apertura: mostrare un breve testo prodotto dall'AI, ben scritto, con un errore non evidente, e chiedere ai partecipanti se lo userebbero così com'è e per quale scopo. La discussione introduce bene il tema della proporzionalità. Nota per il relatore: contenuti e fonti sono stati verificati a ottobre 2026; il modulo si basa su principi stabili, ma gli studi sulla revisione assistita dall'AI evolvono rapidamente e vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la capacità di valutare criticamente gli output dei sistemi AI, verificare ciò che lo richiede, usare l'AI stessa come supporto alla revisione e stabilire se un risultato è adeguato a un utilizzo specifico. Il punto di partenza è noto: la qualità apparente di una risposta non ne garantisce la correttezza. Ma il punto di arrivo è positivo: chi sa verificare in modo mirato può usare l'AI con più sicurezza, per attività più importanti e con meno tempo perso in controlli inutili. Il principio guida è la proporzionalità: controlli rapidi dove il rischio è basso, controlli accurati dove un errore avrebbe conseguenze serie. E l'atteggiamento richiesto è la fiducia calibrata: né accettare tutto, né diffidare di tutto, ma decidere sulla base delle evidenze. Il messaggio centrale del tema, che ritroveremo in chiusura: l'obiettivo non è verificare tutto, ma sapere che cosa verificare, come farlo e quando un risultato è sufficientemente affidabile per essere utilizzato.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Valutare gli output con metodo", "Verificare ciò che conta: fonti, ragionamenti, numeri", "Usare l'AI anche per rivedere e migliorare i risultati", "Decidere quando un risultato è pronto per l'uso"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Perché conviene", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Saper verificare permette di affidare all'AI attività più importanti, con più sicurezza.\n\nControlli proporzionati: rapidi dove il rischio è basso, accurati dove conta.\n\nFiducia calibrata sulle evidenze, né cieca né preconcetta." });
  }
  {
    const s = content("Il filo conduttore: valutare, verificare, decidere", "Il filo conduttore del modulo è la sequenza valutare, verificare, decidere. Valutare significa esaminare l'output: è pertinente, completo, coerente, chiaro? Quali affermazioni contiene, quali ragionamenti, quali numeri? Che cosa manca? Corrispondono i sottotemi 7.1, 7.2 e 7.4. Verificare significa controllare, con evidenze attendibili, gli elementi che lo richiedono: fonti, fatti, dati, calcoli. Corrispondono i sottotemi 7.3 e 7.5, e il 7.6, che mostra come l'AI possa rendere questa fase più rapida e completa. Decidere significa stabilire se l'output, con le verifiche fatte e le incertezze che restano, è adeguato all'uso previsto: accettarlo, modificarlo, approfondirlo o rifiutarlo. Corrisponde il sottotema 7.8. Il 7.7, sui bias cognitivi, attraversa tutte le fasi, perché riguarda chi valuta. Precisazione importante: non è una procedura identica per ogni attività. Per un'idea o una bozza interna le tre fasi si riducono a una lettura attenta di pochi secondi; per un documento destinato a un cliente o a una decisione importante diventano un processo strutturato. Nelle slide, un indicatore in alto a destra ricorda in quale fase ci troviamo.");
    const st = [["FiEye", "Valutare", "Esaminare l'output: pertinenza, completezza, coerenza, che cosa manca", "7.1  7.2  7.4"], ["FiSearch", "Verificare", "Controllare con evidenze ciò che conta: fonti, fatti, dati, calcoli", "7.3  7.5  7.6"], ["FiCheckCircle", "Decidere", "Stabilire se l'output è adeguato all'uso: accettare, modificare, approfondire, rifiutare", "7.8"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.75, i === 2 ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 1.08, 1.35, 0.7, st[i][0], i === 2 ? C.background1 : C.accent1, i === 2 ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.15, y: 2.15, w: 2.56, h: 0.45, fontSize: 19, bold: true, color: i === 2 ? C.background1 : C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.2, y: 2.65, w: 2.46, h: 0.85, fontSize: 12, color: i === 2 ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.2, y: 3.5, w: 2.46, h: 0.35, fontSize: 12, bold: true, color: i === 2 ? C.accent6 : C.accent1, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.4, 0.17);
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.accent6, "bias trasversali");
    txt(s, [{ text: "7.7 Bias cognitivi: ", options: { bold: true, color: C.accent1 } }, { text: "attraversano tutte le fasi. L'intensità dipende dall'uso: pochi secondi per una bozza interna, un processo strutturato per un documento critico.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti con priorità alta. Vanno compresi e applicati: la valutazione della qualità, la verifica delle fonti, il controllo dei ragionamenti, l'identificazione delle omissioni e la validazione proporzionata al rischio. Vanno conosciuti e sperimentati: le tecniche di revisione assistita dall'AI, con esempi pratici di revisione, verifica quantitativa e confronto tra documenti, il confronto tra modelli, il riconoscimento dei bias cognitivi e la gestione dell'incertezza. Vanno solo accennati: metriche statistiche avanzate, validazione formale dei sistemi, modelli quantitativi di rischio, audit specialistici. Il modulo non è un corso di statistica, di logica formale o di audit: propone controlli pratici, alla portata di chiunque lavori con documenti, analisi e decisioni. Confini: non ripetiamo i meccanismi del Tema 2, né la teoria di allucinazioni e bias del Tema 3, né le dinamiche di collaborazione e delega del Tema 5, né i metodi di formulazione del Tema 6, salvo le richieste usate per la revisione. ROI e obblighi giuridici sono trattati nei Temi 12 e 18: qui la responsabilità è trattata come consapevolezza operativa.");
    pathSlide(s, [["7.1", "Il pensiero critico nell'interazione con l'AI", "Alta"], ["7.2", "Valutare la qualità di un output", "Alta"], ["7.3", "Verifica delle informazioni e delle fonti", "Alta"], ["7.4", "Valutare ragionamenti e conclusioni", "Alta"], ["7.5", "Verifica di dati e calcoli", "Alta"], ["7.6", "Verifica e revisione assistite dall'AI", "Alta"], ["7.7", "Bias cognitivi e fiducia nell'AI", "Alta"], ["7.8", "Validazione e responsabilità", "Alta"]],
      [["Comprendere e applicare", "Qualità, fonti, ragionamenti, omissioni, validazione proporzionata al rischio", C.accent1, C.background1], ["Conoscere e sperimentare", "Revisione assistita dall'AI, verifica quantitativa, confronto documentale, bias, incertezza", C.accent6, C.text1], ["Solo accennare", "Metriche avanzate, validazione formale, modelli di rischio, audit specialistici", C.background2, C.text1]]);
  }

  // =====================================================================
  section("7.1 Pensiero critico");
  divider("7.1", "Il pensiero critico nell'interazione con l'AI", "Valutare informazioni e conclusioni alla luce delle evidenze, senza accettarle o respingerle automaticamente", "Iniziamo dal metodo. Il pensiero critico non è una tecnica specifica per l'AI: è un modo di ragionare che vale per qualsiasi informazione, da un articolo a una presentazione di un fornitore. Con l'AI diventa particolarmente utile, perché riceviamo rapidamente molto testo ben scritto su qualsiasi argomento, e dobbiamo decidere in fretta che cosa usare così com'è e che cosa approfondire. Vediamo che cosa significa pensare criticamente, quali distinzioni e domande lo rendono concreto, e perché coincide con una fiducia calibrata, non con la sfiducia.");
  {
    const s = content("Che cos'è il pensiero critico", "Possiamo definire il pensiero critico come la capacità di valutare informazioni, argomenti e conclusioni in modo ragionato, sulla base delle evidenze, prima di accettarli o respingerli. Non esiste un'unica definizione accademica, ma i diversi approcci condividono alcuni principi: chiedersi su che cosa si basa un'affermazione, distinguere ciò che è stabilito da ciò che è supposto, considerare alternative, essere disposti a cambiare idea di fronte a nuove evidenze. Applicato all'AI, il pensiero critico non significa trattare ogni output come un oggetto sospetto. Significa interrogarlo invece di riceverlo passivamente, con un'intensità proporzionata all'uso. La slide propone tre livelli. Per gli usi a basso rischio, come idee, bozze interne, riformulazioni o sintesi per uso personale, molti risultati si possono usare direttamente dopo una lettura attenta. Per gli usi rilevanti, come un'email a un cliente, un report o un'analisi, servono controlli mirati sui punti critici. Per gli usi critici, come contratti, offerte, dati ufficiali o decisioni importanti, serve una verifica strutturata e, se occorre, un esperto. Un'immagine utile: leggere l'output come il lavoro di un collega molto capace, di cui stiamo imparando a conoscere i punti di forza e i limiti. Non lo scartiamo e non lo accettiamo a scatola chiusa: lo usiamo con il giusto grado di controllo.");
    flowTag(s, 0);
    shapeBox(s, 0.5, 1.2, 4.0, 3.75, C.text1, "definizione pensiero critico");
    txt(s, "PENSIERO CRITICO", { x: 0.75, y: 1.38, w: 3.5, h: 0.3, fontSize: 11, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Valutare informazioni, argomenti e conclusioni in modo ragionato, sulla base delle evidenze, prima di accettarli o respingerli.", { x: 0.75, y: 1.8, w: 3.5, h: 1.6, fontSize: 15, color: C.background1 });
    txt(s, "Con l'AI: interrogare l'output invece di riceverlo, con un'intensità proporzionata all'uso.", { x: 0.75, y: 3.65, w: 3.5, h: 1.1, fontSize: 13, italic: true, color: C.accent3 });
    txt(s, "Valutare non significa controllare tutto", { x: 4.8, y: 1.2, w: 4.7, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    rowBox(s, 4.8, 1.62, 4.7, 0.78, "Uso a basso rischio", "Idee, bozze interne, riformulazioni: si usano dopo una lettura attenta", C.accent6);
    rowBox(s, 4.8, 2.5, 4.7, 0.78, "Uso rilevante", "Email a clienti, report, analisi: controlli mirati sui punti critici", C.background2);
    rowBox(s, 4.8, 3.38, 4.7, 0.78, "Uso critico", "Contratti, offerte, decisioni: verifica strutturata, se serve un esperto", C.accent1, C.background1, C.background1);
    txt(s, "Su che cosa si basa? È stabilito o supposto? Ci sono alternative?", { x: 4.8, y: 4.35, w: 4.7, h: 0.55, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Fatti, opinioni, ipotesi, interpretazioni", "Una distinzione fondamentale per valutare un testo è quella tra quattro tipi di affermazioni, che negli output dell'AI possono comparire mescolati senza segnalazione. I fatti sono affermazioni verificabili, che si possono confermare o smentire con evidenze: 'il fatturato del 2025 è stato di 12 milioni'. Le opinioni sono valutazioni o preferenze: 'è un risultato eccellente'. Le ipotesi sono affermazioni plausibili ma non ancora confermate: 'la crescita potrebbe dipendere dal nuovo listino'. Le interpretazioni sono letture dei fatti, che attribuiscono loro un significato: 'la crescita dimostra che la strategia funziona'. Poiché possono essere presentati con lo stesso tono, un'ipotesi può sembrare un fatto e un'interpretazione una conclusione obbligata. Distinguerli è utile perché dice subito dove concentrare l'attenzione: i fatti importanti si verificano, le interpretazioni e le opinioni si valutano con giudizio, le ipotesi si trattano come incerte. Si può anche chiedere all'AI di etichettare le proprie affermazioni secondo questi quattro tipi, come vedremo nel 7.6. Esercizio utile: prendere un paragrafo prodotto dall'AI ed etichettare ogni frase.");
    flowTag(s, 0);
    const t = [["Fatto", "Verificabile con evidenze", "\"Il fatturato 2025 è stato di 12 milioni.\"", "Da verificare, se importante"], ["Opinione", "Valutazione o preferenza", "\"È un risultato eccellente.\"", "Da valutare con giudizio"], ["Ipotesi", "Plausibile, non confermata", "\"La crescita potrebbe dipendere dal nuovo listino.\"", "Da trattare come incerta"], ["Interpretazione", "Lettura che dà significato ai fatti", "\"La crescita dimostra che la strategia funziona.\"", "Da valutare: ci sono alternative?"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 3.2, i === 0 ? C.accent6 : C.background2, t[i][0]);
      txt(s, t[i][0], { x: x + 0.15, y: 1.3, w: 1.85, h: 0.4, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, t[i][1], { x: x + 0.15, y: 1.72, w: 1.85, h: 0.5, fontSize: 12, bold: true, color: C.text1 });
      txt(s, t[i][2], { x: x + 0.15, y: 2.3, w: 1.85, h: 1.25, fontSize: 12, italic: true, color: C.text2 });
      txt(s, t[i][3], { x: x + 0.15, y: 3.65, w: 1.85, h: 0.65, fontSize: 11, bold: true, color: C.accent5 });
    }
    txt(s, "Possono comparire con lo stesso tono assertivo: distinguerli dice dove concentrare l'attenzione.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Le domande critiche", "Il pensiero critico diventa concreto attraverso le domande, raggruppate in tre famiglie. Sulle affermazioni: che cosa sostiene esattamente? È un fatto, un'opinione, un'ipotesi o un'interpretazione? È verificabile? Sulle evidenze: su che cosa si basa? Ci sono fonti, dati, esempi pertinenti e sufficienti? Che cosa servirebbe per confermarla o smentirla? Sulle conclusioni: deriva davvero dalle premesse? Ci sono alternative? Che cosa manca? Che cosa succederebbe se fosse sbagliata? Non serve porsele tutte ogni volta: con la pratica diventano un'abitudine rapida, e si impara a scegliere quelle utili per il tipo di output. L'ultima, che cosa succede se è sbagliata, è spesso la più importante, perché decide quanto approfondire. Queste domande si possono rivolgere anche all'AI, chiedendole di esplicitare evidenze, assunzioni e alternative, come vedremo nel 7.6: è un modo efficace per accelerare l'esame, ferma restando la valutazione finale della persona. Suggerimento: distribuire le domande come scheda di riferimento.");
    flowTag(s, 0);
    const f = [["FiMessageSquare", "Sulle affermazioni", ["Che cosa sostiene esattamente?", "Fatto, opinione, ipotesi, interpretazione?", "È verificabile?"]], ["FiDatabase", "Sulle evidenze", ["Su che cosa si basa?", "Fonti e dati pertinenti e sufficienti?", "Che cosa la confermerebbe o smentirebbe?"]], ["FiGitBranch", "Sulle conclusioni", ["Deriva davvero dalle premesse?", "Ci sono alternative? Che cosa manca?", "Che cosa succede se è sbagliata?"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.1, { icon: f[i][0], head: f[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: bullets(f[i][2], { space: 5 }) });
    txt(s, "Non tutte ogni volta: con la pratica diventano un'abitudine, e si possono porre anche all'AI (7.6).", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Atteggiamento critico e fiducia calibrata", "Atteggiamento critico e sfiducia non sono la stessa cosa. La fiducia cieca accetta tutto senza esame; la sfiducia indiscriminata respinge tutto, 'perché l'AI sbaglia'. Sono due estremi con una radice comune: la decisione non dipende dalle evidenze, ma da un atteggiamento preso in anticipo. Entrambi hanno un costo: la prima espone agli errori, la seconda fa perdere tempo e benefici, perché porta a rifare lavori validi e a verificare ciò che non serve. La fiducia calibrata, invece, valuta caso per caso: accetta ciò che regge, verifica ciò che conta, scarta ciò che non regge. Tre elementi la rendono possibile. Le evidenze: un'affermazione senza evidenze non è necessariamente falsa, ma va trattata come non dimostrata. Il giudizio autonomo: farsi un'idea prima di leggere la risposta, come visto nel Tema 5, dà un termine di confronto; se l'AI arriva a una conclusione diversa, vale la pena capire perché, e a volte è l'AI ad avere visto qualcosa che ci era sfuggito. Le competenze: nel proprio campo si riconoscono un dato anomalo o un'eccezione dimenticata; fuori dal proprio campo serve il parere di chi lo conosce. Il punto da sottolineare: un comportamento maturo comprende anche la capacità di accettare un risultato valido senza verifiche inutili. Controllare oltre il necessario non è prudenza, è uno spreco che rende l'AI meno utile.");
    flowTag(s, 0);
    const z = [["Fiducia cieca", "Accetta tutto, senza esame", C.background2, C.text1], ["Fiducia calibrata", "Accetta ciò che regge, verifica ciò che conta, scarta ciò che non regge", C.accent1, C.background1], ["Sfiducia indiscriminata", "Respinge tutto, \"perché l'AI sbaglia\"", C.background2, C.text1]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 1.5, z[i][2], z[i][0]);
      txt(s, z[i][0], { x: x + 0.15, y: 1.3, w: 2.56, h: 0.45, fontSize: 16, bold: true, color: z[i][3], align: "center" });
      txt(s, z[i][1], { x: x + 0.2, y: 1.78, w: 2.46, h: 0.85, fontSize: 12, color: z[i][3], align: "center" });
    }
    const e = [["Evidenze", "Senza evidenze un'affermazione non è falsa, ma non è dimostrata."], ["Giudizio autonomo", "Un'idea propria prima di leggere: se l'AI conclude diversamente, capire perché."], ["Competenze", "Nel proprio campo si riconoscono gli errori; fuori, serve un esperto."]];
    for (let i = 0; i < 3; i++) rowBox(s, 0.5 + i * 3.07, 2.9, 2.86, 1.25, e[i][0], e[i][1], i === 1 ? C.accent6 : C.background2);
    banner(s, 4.35, "Maturità significa anche accettare un risultato valido senza verifiche inutili.", { h: 0.6, fontSize: 14 });
  }
  keySlide("Pensare criticamente significa valutare informazioni e conclusioni alla luce delle evidenze, senza accettarle o respingerle automaticamente.", "Sottotema 7.1  ·  Il pensiero critico nell'interazione con l'AI", "Concetto chiave. Il pensiero critico è un'abitudine di interrogazione, applicata con un'intensità proporzionata all'uso: molti output a basso rischio si usano dopo una lettura attenta, quelli importanti richiedono controlli mirati o strutturati. Si basa su distinzioni, come quella tra fatti, opinioni, ipotesi e interpretazioni, e su domande critiche su affermazioni, evidenze e conclusioni. Richiede giudizio autonomo e competenze. E coincide con la fiducia calibrata, non con la sfiducia. Esercizio suggerito: dare ai partecipanti un paragrafo prodotto dall'AI, chiedere di etichettare ogni frase come fatto, opinione, ipotesi o interpretazione, e poi di indicare quali verificherebbero se il testo fosse destinato a un cliente e quali se fosse solo un appunto interno.");

  // =====================================================================
  section("7.2 Qualità di un output");
  divider("7.2", "Valutare la qualità di un output", "Una risposta professionale nella forma può essere errata, incompleta o inadatta allo scopo", "Passiamo dalla postura al metodo concreto di valutazione. In questo sottotema vediamo le dimensioni della qualità di un output, la differenza tra forma e sostanza, come riconoscere le informazioni mancanti e come distinguere livelli diversi di certezza. Il 7.2 valuta la qualità del contenuto; nel 7.8 valuteremo la sua utilizzabilità in un contesto concreto.");
  {
    const s = content("Le dimensioni della qualità", "La qualità di un output si valuta su più dimensioni. Accuratezza: le informazioni sono corrette? Pertinenza: risponde all'obiettivo o a una domanda diversa? Completezza: copre ciò che serve? Coerenza interna: le parti sono coerenti tra loro? Chiarezza: il destinatario lo capirà senza ambiguità? Distinzione tra dati e supposizioni: è chiaro che cosa deriva da informazioni certe e che cosa è supposto? Le dimensioni sono indipendenti: un output può essere accurato ma non pertinente, pertinente ma incompleto, chiaro ma inaccurato. Per gli output importanti conviene valutarle separatamente. A queste si aggiunge una distinzione che attraversa il modulo: quella tra qualità espressiva e qualità sostanziale. La forma, cioè scorrevolezza, lessico, struttura, tono sicuro, negli output generativi è quasi sempre curata; la sostanza, cioè correttezza, completezza, solidità del ragionamento, può variare. Poiché tendiamo a giudicare la sostanza dalla forma, conviene separare i due giudizi. Prova rapida: riscrivere mentalmente l'output come appunti disordinati e chiedersi se il contenuto convincerebbe ancora. Le dimensioni riprendono quelle viste nel Tema 3 sull'affidabilità, ma qui le usiamo come lista di controllo sul singolo output.");
    flowTag(s, 0);
    const d = [["FiTarget", "Accuratezza", "Le informazioni sono corrette?"], ["FiCrosshair", "Pertinenza", "Risponde all'obiettivo?"], ["FiCheckSquare", "Completezza", "Copre ciò che serve?"], ["FiGitMerge", "Coerenza interna", "Nessuna contraddizione?"], ["FiEye", "Chiarezza", "Il destinatario lo capirà?"], ["FiColumns", "Dati e supposizioni", "Che cosa è certo, che cosa supposto?"]];
    await iconGrid(s, d.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 2.6, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 4.0, 9.0, 0.95, C.text1, "forma e sostanza");
    txt(s, [{ text: "Forma curata non significa sostanza corretta. ", options: { bold: true, color: C.accent1 } }, { text: "Prova rapida: se fossero appunti disordinati, il contenuto convincerebbe ancora?", options: { color: C.background1 } }], { x: 0.7, y: 4.0, w: 8.6, h: 0.95, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Informazioni mancanti e omissioni", "Un errore particolarmente insidioso è l'omissione. Un output può contenere solo affermazioni corrette ed essere comunque inadeguato, perché tace informazioni decisive. Le omissioni sono difficili da notare perché valutiamo ciò che c'è scritto, non ciò che manca. Alcuni esempi tipici. Un riassunto di contratto che riporta correttamente durata, prezzo e servizi, ma omette la clausola di rinnovo automatico. Una risposta su una procedura che descrive il caso generale ma non le eccezioni. Un confronto tra fornitori che considera prezzo e qualità ma non i tempi di consegna. Un'analisi che presenta i vantaggi di una scelta ma non i rischi. In ciascun caso, ogni frase è vera, ma il quadro complessivo è fuorviante. Le omissioni sono più probabili quando il materiale è lungo, quando la richiesta non indicava che cosa includere, quando il caso ha eccezioni o condizioni particolari. Per questo una buona richiesta iniziale, che elenca gli elementi attesi, riduce già molto il problema.");
    flowTag(s, 0);
    const ex = [["Riassunto di contratto", "Durata, prezzo, servizi corretti", "Manca la clausola di rinnovo automatico"], ["Risposta su una procedura", "Caso generale corretto", "Mancano le eccezioni"], ["Confronto tra fornitori", "Prezzo e qualità corretti", "Mancano i tempi di consegna"], ["Analisi di una scelta", "Vantaggi corretti", "Mancano i rischi"]];
    txt(s, "Ciò che c'è", { x: 3.2, y: 1.15, w: 2.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
    txt(s, "Ciò che manca", { x: 6.3, y: 1.15, w: 3.2, h: 0.3, fontSize: 12, bold: true, color: C.accent5 });
    ex.forEach((e, i) => {
      const y = 1.5 + i * 0.66;
      shapeBox(s, 0.5, y, 9.0, 0.58, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.65, y, w: 2.5, h: 0.58, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[1], { x: 3.2, y, w: 3.0, h: 0.58, fontSize: 12, color: C.text2, valign: "middle" });
      txt(s, e[2], { x: 6.3, y, w: 3.1, h: 0.58, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
    });
    banner(s, 4.3, "Ogni frase è vera, ma il quadro è incompleto: le omissioni non si vedono, perché valutiamo ciò che c'è scritto.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Cercare ciò che manca e tenere traccia", "Come si individua ciò che non c'è? Partire dalle attese: prima di leggere l'output, annotare che cosa dovrebbe contenere, poi confrontare. È la tecnica più efficace, perché rende visibile l'assenza. Usare la richiesta originale come lista di controllo. Cercare eccezioni e condizioni: in quali casi l'affermazione non vale? Cercare l'altra metà: se ci sono i vantaggi, dove sono gli svantaggi? Confrontare con la fonte: per le sintesi, scorrere l'indice del documento originale e verificare che le parti importanti siano rappresentate. Chiedere all'AI che cosa manca: 'quali aspetti importanti non hai considerato?', 'in quali casi questa risposta non vale?'. È un aiuto rapido ed efficace, da confrontare con le proprie attese. La fascia in basso aggiunge un'abitudine pratica: tenere traccia di che cosa è stato verificato. Quando si lavora su un documento con l'AI, dopo diverse iterazioni è facile perdere traccia di ciò che è stato controllato. Bastano accorgimenti semplici: segnare le affermazioni da verificare e togliere il segno dopo il controllo; chiedere all'AI di contrassegnare ciò che non deriva dai documenti forniti; tenere un elenco dei punti verificati e delle fonti, utile anche per la documentazione del 7.8; dichiarare quando una bozza condivisa contiene parti non ancora verificate. Nel 7.4 vedremo invece le omissioni che rendono ingiustificata una conclusione.");
    flowTag(s, 0);
    const t = [["FiList", "Partire dalle attese", "Annotare che cosa dovrebbe esserci, poi confrontare"], ["FiCheckSquare", "Usare la richiesta originale", "Ogni elemento richiesto è presente?"], ["FiAlertCircle", "Cercare eccezioni e condizioni", "In quali casi non vale?"], ["FiColumns", "Cercare l'altra metà", "Vantaggi e svantaggi, un punto di vista e l'altro"], ["FiBookOpen", "Confrontare con la fonte", "Le parti importanti sono rappresentate?"], ["FiHelpCircle", "Chiedere all'AI che cosa manca", "Aiuto rapido, da confrontare con le attese"]];
    await iconGrid(s, t.map((e, i) => ({ icon: e[0], head: e[1], body: e[2], fill: i === 0 ? C.accent6 : C.background2 })), 3, { y: 1.2, H: 2.7, headSize: 13, bodySize: 11 });
    shapeBox(s, 0.5, 4.08, 9.0, 0.87, C.text1, "tenere traccia");
    txt(s, "Tenere traccia", { x: 0.7, y: 4.08, w: 1.55, h: 0.87, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
    const tr = ["Segnare ciò che è da verificare", "Elenco dei punti verificati e delle fonti", "Dichiarare le parti non ancora verificate"];
    tr.forEach((t2, i) => chip(s, 2.35 + i * 2.38, 4.22, 2.28, 0.6, t2, { fill: C.accent6, fontSize: 11, bold: false }));
  }
  {
    const s = content("Incertezza e livello di fiducia", "I contenuti di un output hanno gradi di certezza diversi. Fatti confermati: verificati su fonti affidabili. Affermazioni probabili: plausibili e coerenti con ciò che sappiamo, ma non verificate. Ipotesi: possibili, ma senza evidenze sufficienti. Contenuti non verificati: affermazioni di cui non conosciamo l'affidabilità. Un output può mescolare questi livelli con lo stesso tono, e il tono non misura la correttezza: un sistema può affermare con sicurezza qualcosa di errato e con cautela qualcosa di corretto. Un punto tecnico importante: se chiediamo al modello di indicare quanto è sicuro, per esempio con una percentuale, il valore dichiarato non è automaticamente una probabilità calibrata. Un '90%' scritto nel testo non significa che, su cento affermazioni simili, novanta siano corrette. È un indizio, non una misura. Per questo è più utile chiedere elementi controllabili: su quali fonti si basa ogni affermazione, quali assunzioni sono state fatte, quali sono i limiti della risposta, quali punti andrebbero verificati. Sono informazioni che la persona può controllare, e che orientano la verifica dove serve. Il livello di fiducia, alla fine, lo attribuisce chi valuta, sulla base delle evidenze.");
    flowTag(s, 0);
    const lv = [["Fatti confermati", "Verificati su fonti affidabili", C.accent1, C.background1], ["Affermazioni probabili", "Plausibili, non verificate", C.accent6, C.text1], ["Ipotesi", "Possibili, senza evidenze sufficienti", C.background2, C.text1], ["Non verificati", "Affidabilità non nota", C.background1, C.text1]];
    lv.forEach((l, i) => {
      const y = 1.2 + i * 0.62;
      const w = 4.6 - i * 0.2;
      shapeBox(s, 0.5, y, w, 0.54, l[2], l[0], i === 3 ? { color: C.accent3, width: 1, dashType: "dash" } : undefined);
      txt(s, l[0], { x: 0.65, y, w: 2.1, h: 0.54, fontSize: 13, bold: true, color: l[3], valign: "middle" });
      txt(s, l[1], { x: 2.75, y, w: w - 2.35, h: 0.54, fontSize: 11, color: l[3], valign: "middle" });
    });
    txt(s, "Livello di certezza decrescente", { x: 0.5, y: 3.68, w: 4.6, h: 0.25, fontSize: 10, italic: true, color: C.accent2 });
    shapeBox(s, 5.4, 1.2, 4.1, 2.73, C.text1, "tono");
    txt(s, "Il tono non misura la correttezza", { x: 5.6, y: 1.32, w: 3.7, h: 0.45, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Anche un grado di certezza dichiarato dal modello, per esempio \"90%\", non è automaticamente una probabilità calibrata: è un indizio, non una misura.", { x: 5.6, y: 1.85, w: 3.7, h: 1.95, fontSize: 13, color: C.accent3 });
    txt(s, "Più utile chiedere elementi controllabili:", { x: 0.5, y: 4.05, w: 9, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
    ["Su quali fonti si basa?", "Quali assunzioni?", "Quali limiti?", "Che cosa va verificato?"].forEach((q, i) => chip(s, 0.5 + i * 2.29, 4.4, 2.16, 0.5, q, { fill: C.accent6, fontSize: 12 }));
  }
  keySlide("Una risposta professionale nella forma può essere errata, incompleta o inadatta allo scopo.", "Sottotema 7.2  ·  Valutare la qualità di un output", "Concetto chiave. La qualità di un output si valuta su più dimensioni indipendenti: accuratezza, pertinenza, completezza, coerenza, chiarezza, distinzione tra dati e supposizioni. Una forma curata non dice nulla sulla sostanza. Le omissioni si cercano partendo dalle attese, dalle eccezioni e dalla fonte, anche con l'aiuto dell'AI. I contenuti hanno livelli diversi di certezza, che il tono non rivela e che un grado di certezza dichiarato non misura con precisione: meglio chiedere fonti, assunzioni e limiti. E conviene tenere traccia di ciò che è stato verificato. Esercizio suggerito: prima di leggere un riassunto prodotto dall'AI, far annotare ai partecipanti che cosa dovrebbe contenere; poi confrontare e individuare le omissioni.");

  // =====================================================================
  section("7.3 Informazioni e fonti");
  divider("7.3", "Verifica delle informazioni e delle fonti", "Una citazione non è automaticamente una prova: la fonte deve essere autentica, pertinente e sostenere l'affermazione", "Entriamo nella fase di verifica. Nel Tema 3 abbiamo visto perché i sistemi generativi possono produrre fonti e citazioni inesatte o inesistenti. Qui sviluppiamo il metodo pratico: come scegliere che cosa verificare, come distinguere le fonti dagli strumenti che le trovano e le sintetizzano, come controllare che una fonte sostenga davvero un'affermazione, come confrontare fonti indipendenti e come trattare ipotesi, stime e scenari.");
  {
    const s = content("Che cosa verificare: i punti critici", "Il primo passo della verifica è decidere che cosa verificare. Non tutto in un output richiede controllo, e verificare tutto con la stessa intensità sarebbe impraticabile. Si procede in due passaggi. Primo, individuare le affermazioni verificabili, cioè i fatti, distinguendoli da opinioni e interpretazioni. Secondo, tra queste, scegliere quelle da controllare secondo tre criteri: l'importanza, cioè quanto pesano sulla decisione o sull'uso del documento; il rischio di errore, più alto per numeri, date, nomi, norme, eventi recenti o argomenti di nicchia; la visibilità, cioè quanto un errore sarebbe esposto, per esempio in un documento per un cliente. L'esempio mostra un breve testo con le affermazioni da verificare evidenziate: la frase introduttiva e la valutazione finale non sono fatti verificabili. La fascia in basso riguarda gli elementi di dettaglio: date, nomi, numeri e riferimenti, come articoli di legge, codici, versioni, link. Sono spesso rapidi da controllare se si ha la fonte, e conviene farlo uno per uno, con la fonte aperta accanto, per i documenti destinati all'esterno o a una decisione: nella lettura scorrevole gli errori di dettaglio sfuggono facilmente. L'AI può aiutare a estrarre l'elenco di questi elementi, come vedremo nel 7.6. Questa selezione è anche il primo passo dell'economia della verifica del 7.8.");
    flowTag(s, 1);
    shapeBox(s, 0.5, 1.2, 5.4, 2.9, C.background2, "testo esempio");
    txt(s, "Esempio: testo prodotto dall'AI", { x: 0.7, y: 1.3, w: 5.0, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
    txt(s, [
      { text: "Il lavoro agile è sempre più diffuso nelle aziende italiane. ", options: { color: C.text2 } },
      { text: "Secondo l'Osservatorio X, nel 2025 lo praticavano 3,5 milioni di lavoratori", options: { highlight: "E6F0EF", bold: true, color: C.text1 } },
      { text: ", ", options: { color: C.text2 } },
      { text: "in crescita del 10% rispetto all'anno precedente", options: { highlight: "E6F0EF", bold: true, color: C.text1 } },
      { text: ". ", options: { color: C.text2 } },
      { text: "La normativa di riferimento è la legge 81 del 2017", options: { highlight: "E6F0EF", bold: true, color: C.text1 } },
      { text: ". Si tratta di un'opportunità importante per migliorare il benessere dei dipendenti.", options: { color: C.text2 } },
    ], { x: 0.7, y: 1.68, w: 5.0, h: 1.9, fontSize: 13 });
    txt(s, "In evidenza: affermazioni da verificare. Esempio illustrativo, dati non verificati.", { x: 0.7, y: 3.65, w: 5.0, h: 0.35, fontSize: 10, italic: true, color: C.accent2 });
    txt(s, "Criteri per scegliere", { x: 6.2, y: 1.2, w: 3.3, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const c = [["FiStar", "Importanza", "Quanto pesa sulla decisione"], ["FiAlertTriangle", "Rischio di errore", "Numeri, date, nomi, norme, novità"], ["FiEye", "Visibilità", "Quanto l'errore sarebbe esposto"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.65 + i * 0.82;
      await iconCircle(s, 6.2, y, 0.5, c[i][0]);
      txt(s, c[i][1], { x: 6.85, y: y - 0.03, w: 2.65, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
      txt(s, c[i][2], { x: 6.85, y: y + 0.28, w: 2.65, h: 0.4, fontSize: 11, color: C.text2 });
    }
    shapeBox(s, 0.5, 4.25, 9.0, 0.7, C.text1, "dettagli");
    txt(s, [{ text: "Date, nomi, numeri, riferimenti: ", options: { bold: true, color: C.accent1 } }, { text: "controllarli uno per uno, con la fonte aperta accanto, nei documenti esterni o per decisioni.", options: { color: C.background1 } }], { x: 0.7, y: 4.25, w: 8.6, h: 0.7, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Fonti, ricerca e sintesi dell'AI", "Per verificare un'informazione conviene distinguere tre cose che spesso si confondono. La fonte documentale è il documento che contiene l'informazione. Può essere primaria, cioè all'origine dell'informazione: il testo ufficiale di una legge, un bilancio pubblicato, il rapporto originale di un istituto, un contratto firmato, i dati del gestionale. Oppure secondaria, se riporta o commenta informazioni di altre fonti: articoli, sintesi, presentazioni, enciclopedie. Per le informazioni importanti si risale alla primaria: se un articolo dice che una norma prevede un obbligo, si legge la norma. Lo strumento di ricerca, come un motore di ricerca, una banca dati o la ricerca interna aziendale, non è una fonte: trova e ordina documenti, e il valore sta nei documenti che restituisce, da aprire e leggere. Il sistema di sintesi o di elaborazione, come un assistente AI, riassume, combina e riformula informazioni: quelle apprese durante l'addestramento, quelle trovate con una ricerca o quelle contenute nei documenti forniti. La sua risposta non è di per sé né una fonte primaria né una secondaria: è un'elaborazione, che vale quanto le fonti a cui può essere ricondotta. Quando lavora su documenti forniti o cita fonti consultate, la verifica è più semplice, perché si può controllare il passaggio citato. Quando non indica la provenienza, le affermazioni importanti vanno ricondotte a una fonte prima dell'uso. Questa distinzione non riduce l'utilità dell'AI: la colloca nel ruolo in cui è più forte, cioè trovare, organizzare e sintetizzare, lasciando alle fonti il ruolo di prova.");
    flowTag(s, 1);
    table(s, [["", "Fonte documentale", "Strumento di ricerca", "Sistema di sintesi o elaborazione"], ["Che cos'è", "Il documento che contiene l'informazione: primaria (legge, bilancio, contratto) o secondaria (articolo, sintesi)", "Trova e ordina documenti: motore di ricerca, banca dati, ricerca interna", "Riassume, combina, riformula: un assistente AI, con o senza ricerca e documenti forniti"], ["Come usarlo", "Si cita e si legge; per le informazioni importanti, la primaria", "Porta alle fonti: i risultati si aprono e si leggono", "Accelera lettura e sintesi; le affermazioni importanti si riconducono alle fonti"], ["Attenzione", "Attendibilità e aggiornamento", "L'ordine dei risultati non è una garanzia", "Non è di per sé una fonte primaria o secondaria"]], { colW: [1.45, 2.6, 2.3, 2.65], rowH: [0.42, 1.05, 0.8, 0.55], accentCol: 3, fontSize: 11 });
    banner(s, 4.3, "Una risposta dell'AI è un'elaborazione: vale quanto le fonti a cui può essere ricondotta.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Una fonte esistente non basta", "Nel Tema 3 abbiamo visto il caso delle fonti inesistenti. Ma anche quando la fonte esiste, non è detto che sostenga l'affermazione. Le situazioni più comuni sono quattro. La fonte tratta un argomento diverso o vicino: per esempio un articolo sul settore, non sull'azienda citata. Tratta l'argomento ma dice una cosa diversa: un numero diverso, una conclusione più cauta, un'eccezione omessa. Dice quella cosa, ma in un contesto diverso: un altro paese, un altro periodo, un'altra categoria. Non è attendibile o è superata. La verifica prevede quindi tre controlli in sequenza: la fonte è autentica, cioè esiste ed è quella indicata? È pertinente, cioè tratta proprio quell'argomento, nello stesso contesto? Sostiene l'affermazione, cioè dice esattamente ciò che le viene attribuito? Per farlo bisogna aprire la fonte e leggere il passaggio: il titolo e l'esistenza del link non bastano. Un aiuto pratico: chiedere all'AI di riportare, per ogni affermazione, il passaggio esatto della fonte su cui si basa. Il controllo diventa molto più rapido, perché si confronta un passaggio con un'affermazione.");
    flowTag(s, 1);
    txt(s, "Quando la fonte esiste ma non sostiene l'affermazione", { x: 0.5, y: 1.15, w: 5.0, h: 0.3, fontSize: 13, bold: true, color: C.accent5 });
    rowList(s, ["Tratta un argomento diverso o vicino", "Dice una cosa diversa: numero, cautela, eccezione", "Vale in un contesto diverso: paese, periodo, categoria", "Non è attendibile o è superata"], { x: 0.5, w: 5.0, y: 1.55, h: 0.55, fontSize: 12 });
    txt(s, "Tre controlli in sequenza", { x: 5.8, y: 1.15, w: 3.7, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
    const c = [["Autentica", "Esiste ed è quella indicata?"], ["Pertinente", "Proprio quell'argomento, nello stesso contesto?"], ["Di supporto", "Dice esattamente ciò che le viene attribuito?"]];
    c.forEach((e, i) => {
      const y = 1.55 + i * 0.8;
      shapeBox(s, 5.8, y, 3.7, 0.7, i === 2 ? C.accent1 : C.accent6, e[0]);
      txt(s, (i + 1) + ". " + e[0], { x: 5.95, y: y + 0.03, w: 3.4, h: 0.32, fontSize: 13, bold: true, color: i === 2 ? C.background1 : C.text1 });
      txt(s, e[1], { x: 5.95, y: y + 0.35, w: 3.4, h: 0.32, fontSize: 11, color: i === 2 ? C.background1 : C.text2 });
    });
    banner(s, 4.15, "Aprire la fonte e leggere il passaggio. Utile chiedere all'AI di riportare il passaggio esatto su cui si basa.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Attendibilità e fonti indipendenti", "Una volta trovata una fonte pertinente, resta da valutarne la qualità. Attendibilità: chi è l'autore o l'ente? Ha competenza sull'argomento? Ha interessi che potrebbero influenzare il contenuto, come un fornitore che pubblica dati sul proprio prodotto? L'informazione è documentata? Aggiornamento: quando è stata pubblicata? È ancora valida? Per norme, prezzi, procedure, organigrammi e dati di mercato, una fonte di due anni fa può essere superata. Fonti indipendenti: per le informazioni importanti, specialmente quando la primaria non è disponibile, conviene confrontare almeno due fonti che non si citano a vicenda e non derivano dalla stessa origine. Se concordano, la fiducia aumenta; se divergono, bisogna risalire all'origine. Attenzione alle false conferme: dieci siti con la stessa informazione possono averla copiata dalla stessa fonte. E due risposte di sistemi AI diversi non sono fonti indipendenti, come vedremo nel 7.6.");
    flowTag(s, 1);
    const q = [["FiAward", "Attendibilità", ["Chi è l'autore o l'ente?", "Ha competenza sull'argomento?", "Ha interessi in gioco?", "L'informazione è documentata?"]], ["FiCalendar", "Aggiornamento", ["Quando è stata pubblicata?", "È ancora valida?", "Attenzione a norme, prezzi, procedure, dati di mercato"]], ["FiCopy", "Fonti indipendenti", ["Almeno due, che non si citano a vicenda", "Se divergono, risalire all'origine", "Attenzione alle false conferme"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.2, { icon: q[i][0], head: q[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2, body: bullets(q[i][2], { space: 4 }) });
    txt(s, "Dieci siti con la stessa informazione possono averla copiata tutti dalla stessa fonte.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Fatti, ipotesi, stime e scenari", "Non tutto ciò che un output contiene è un fatto da verificare: spesso si tratta di ipotesi, stime o scenari, che hanno un valore diverso e vanno trattati in modo diverso. Il fatto non verificato è un dato presentato come certo che non abbiamo ancora controllato: si verifica, si elimina se non è essenziale, oppure si segnala come non verificato. L'ipotesi è una spiegazione possibile, da confermare: è utile per orientare l'analisi, purché dichiarata come tale. La stima è un valore calcolato da dati parziali e assunzioni, come il numero di clienti potenziali o il costo previsto di un progetto: è utile se si indicano metodo e assunzioni, così che chi legge possa valutarla. La simulazione o lo scenario descrive che cosa potrebbe succedere a certe condizioni, come l'effetto di un aumento di prezzo: è uno strumento prezioso per decidere, ma non è un dato. L'AI è molto utile proprio per generare ipotesi alternative, stime di massima e scenari: il punto non è evitarli, ma dichiararli e non confonderli con dati accertati. Un rischio tipico è un numero molto preciso, come '3.247 clienti potenziali', che suona come un dato osservato ma è una stima senza base dichiarata. Nei documenti esterni o a supporto di decisioni, ipotesi, stime e scenari vanno etichettati in modo esplicito, con le loro assunzioni. Nel 7.5 riprenderemo questa distinzione per i numeri.");
    flowTag(s, 1);
    const t = [["Fatto non verificato", "Dato presentato come certo, non ancora controllato", "\"Il mercato vale 2 miliardi\", senza fonte", "Verificarlo, eliminarlo o segnalarlo"], ["Ipotesi", "Spiegazione possibile, da confermare", "\"Il calo potrebbe dipendere dai prezzi\"", "Utile per orientare l'analisi"], ["Stima", "Valore calcolato da dati parziali e assunzioni", "\"Circa 3.000 clienti potenziali\"", "Utile con metodo e assunzioni dichiarati"], ["Simulazione o scenario", "Che cosa succederebbe a certe condizioni", "\"Con prezzo +5%, ricavi tra +2% e +4%\"", "Utile per decidere, non è un dato"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 2.8, i === 0 ? C.background2 : C.accent6, t[i][0]);
      txt(s, t[i][0], { x: x + 0.15, y: 1.28, w: 1.85, h: 0.55, fontSize: 14, bold: true, color: i === 0 ? C.accent5 : C.accent1, valign: "middle" });
      txt(s, t[i][1], { x: x + 0.15, y: 1.85, w: 1.85, h: 0.65, fontSize: 11, bold: true, color: C.text1 });
      txt(s, t[i][2], { x: x + 0.15, y: 2.55, w: 1.85, h: 0.7, fontSize: 11, italic: true, color: C.text2 });
      txt(s, t[i][3], { x: x + 0.15, y: 3.3, w: 1.85, h: 0.6, fontSize: 11, bold: true, color: C.text1 });
    }
    banner(s, 4.2, "Ipotesi, stime e scenari sono utili, purché dichiarati: il problema è presentarli come dati accertati.", { h: 0.75, fontSize: 13 });
  }
  keySlide("Una citazione non costituisce automaticamente una prova: occorre controllare che la fonte sia autentica, pertinente e sostenga l'affermazione.", "Sottotema 7.3  ·  Verifica delle informazioni e delle fonti", "Concetto chiave. Verificare significa scegliere i punti critici, distinguere le fonti dagli strumenti che le trovano e dai sistemi che le sintetizzano, risalire alla fonte primaria per le informazioni importanti, controllare che una fonte sia autentica, pertinente e di supporto, valutarne attendibilità e aggiornamento, confrontare fonti indipendenti. E significa trattare in modo trasparente ciò che non è un fatto: ipotesi, stime e scenari sono utili, purché dichiarati. Esercizio suggerito: dare ai partecipanti un breve testo con tre affermazioni e tre fonti citate, di cui una inesistente, una che esiste ma dice una cosa diversa e una corretta, e chiedere di verificarle; poi ripetere l'esercizio chiedendo all'AI di riportare il passaggio esatto di ogni fonte e confrontare i tempi.");

  // =====================================================================
  section("7.4 Ragionamenti e conclusioni");
  divider("7.4", "Valutare ragionamenti e conclusioni", "Informazioni singolarmente corrette non assicurano che la conclusione tratta da esse sia giustificata", "Torniamo alla valutazione, questa volta dei ragionamenti. Un output può contenere solo informazioni corrette e arrivare comunque a una conclusione debole, perché il collegamento tra le parti ha un difetto. Vediamo come scomporre un ragionamento e quali difetti cercare, senza entrare nella logica formale: bastano poche domande, che valgono per qualsiasi raccomandazione, umana o generata.");
  {
    const s = content("Premesse, dati e conclusioni", "Per valutare un ragionamento lo si scompone. I dati sono le informazioni di fatto. Le premesse sono le affermazioni, spesso generali, che collegano i dati alla conclusione. La conclusione è ciò che il ragionamento sostiene. Esempio: dati, vendite online +30% e vendite in negozio -5%; premessa, i clienti preferiscono sempre più acquistare online; conclusione, conviene chiudere alcuni negozi. Scomposto, il ragionamento mostra i punti da controllare: i dati sono corretti? La premessa è dimostrata o è un'interpretazione? Mancano informazioni, come i margini dei due canali, il ruolo dei negozi nelle vendite online, i costi di chiusura? La fascia in basso riguarda i passaggi deboli. Un testo può suonare logico grazie a connettivi come 'quindi', 'di conseguenza', 'ne deriva che', anche quando il collegamento non è dimostrato: vale per i testi umani come per quelli generati. Segnali tipici: la conclusione è molto più forte delle premesse, per esempio da 'alcuni clienti si sono lamentati' a 'il prodotto ha un problema di qualità'; un elemento nuovo compare solo nella conclusione; il ragionamento salta da una questione a un'altra. Esercizio utile: sottolineare i connettivi e chiedersi se ciascun collegamento è dimostrato. Si può anche chiedere all'AI di esplicitare dati, premesse e conclusione del proprio ragionamento: rende la struttura visibile in pochi secondi.");
    flowTag(s, 0);
    const p = [["Dati", "Vendite online +30%, vendite in negozio -5%", C.background2, C.text1], ["Premessa", "I clienti preferiscono sempre più acquistare online", C.accent6, C.text1], ["Conclusione", "Conviene chiudere alcuni negozi", C.accent1, C.background1]];
    p.forEach((e, i) => {
      const y = 1.2 + i * 0.8;
      shapeBox(s, 0.5, y, 1.8, 0.66, e[2], e[0]);
      txt(s, e[0], { x: 0.55, y, w: 1.7, h: 0.66, fontSize: 14, bold: true, color: e[3], align: "center", valign: "middle" });
      shapeBox(s, 2.4, y, 3.4, 0.66, C.background1, "testo " + e[0], { color: C.accent3, width: 1 });
      txt(s, e[1], { x: 2.55, y, w: 3.15, h: 0.66, fontSize: 12, color: C.text1, valign: "middle" });
      if (i < 2) s.addShape(pres.shapes.DOWN_ARROW, { x: 1.25, y: y + 0.67, w: 0.3, h: 0.12, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia" });
    });
    txt(s, "Domande", { x: 6.1, y: 1.2, w: 3.4, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["I dati sono corretti?", "La premessa è dimostrata o interpretata?", "Mancano informazioni? Margini, ruolo dei negozi, costi"], { x: 6.1, w: 3.4, y: 1.58, h: 0.55, fontSize: 12 });
    shapeBox(s, 0.5, 3.75, 9.0, 1.2, C.text1, "passaggi deboli");
    txt(s, [{ text: "Passaggi deboli: ", options: { bold: true, color: C.accent1 } }, { text: "\"quindi\", \"di conseguenza\" senza dimostrazione; conclusione più forte delle premesse; elementi nuovi solo alla fine. ", options: { color: C.background1 } }, { text: "Esempio: da \"alcuni clienti si sono lamentati\" a \"il prodotto ha un problema di qualità\".", options: { color: C.accent3, italic: true } }], { x: 0.7, y: 3.75, w: 8.6, h: 1.2, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Correlazione e causalità", "Una delle confusioni più comuni nei ragionamenti, umani e generati, è quella tra correlazione e causalità. Due fenomeni sono correlati quando variano insieme; sono in relazione causale quando uno è causa dell'altro. La correlazione non dimostra la causalità, per almeno tre ragioni. Può esserci un terzo fattore: d'estate crescono sia le vendite di gelati sia gli incidenti in spiaggia, ma la causa comune è il caldo. La causalità può essere inversa: le aziende che investono in formazione hanno risultati migliori, ma forse sono i buoni risultati a permettere gli investimenti. La correlazione può essere casuale, soprattutto con pochi dati o molte variabili. Nei testi la confusione si presenta in frasi come 'grazie a', 'a causa di', 'ha portato a', 'dimostra che'. Quando un output attribuisce una causa, chiedersi: ci sono spiegazioni alternative? Ci sono evidenze che il legame sia causale? Una richiesta utile all'AI: 'quali altre spiegazioni sono compatibili con questi dati?'. L'esempio dei negozi della slide precedente contiene proprio questo problema.");
    flowTag(s, 0);
    const r = [["FiShare2", "Un terzo fattore", "Gelati e incidenti in spiaggia crescono insieme: la causa comune è il caldo"], ["FiRepeat", "Causalità inversa", "Formazione e risultati: forse sono i risultati a permettere la formazione"], ["FiShuffle", "Coincidenza", "Pochi dati o molte variabili: correlazioni casuali"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.4, { icon: r[i][0], head: r[i][1], headSize: 15, bodySize: 12, body: r[i][2] });
    shapeBox(s, 0.5, 3.8, 9.0, 1.15, C.text1, "frasi causali");
    txt(s, [{ text: "Attenzione a: ", options: { bold: true, color: C.accent1 } }, { text: "\"grazie a\", \"a causa di\", \"ha portato a\", \"dimostra che\". ", options: { color: C.background1 } }, { text: "Ci sono spiegazioni alternative? Evidenze che il legame sia causale?", options: { color: C.accent3 } }], { x: 0.7, y: 3.8, w: 8.6, h: 1.15, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Assunzioni e generalizzazioni indebite", "Due difetti frequenti in qualsiasi ragionamento. Le assunzioni implicite sono premesse non dichiarate da cui la conclusione dipende: per esempio una proposta di risparmio che dà per scontato che i volumi restino invariati, o un piano che presuppone personale disponibile. Se l'assunzione è falsa, la conclusione cade; poiché non è scritta, è difficile accorgersene. Domanda di controllo: che cosa deve essere vero perché questa conclusione valga? Le generalizzazioni indebite estendono a tutti i casi ciò che vale per alcuni: 'i clienti preferiscono l'online', basato su un'indagine tra clienti giovani di una sola città; 'questa soluzione funziona', perché ha funzionato in un'azienda di un altro settore. Quando una richiesta all'AI è generica, la risposta tende a basarsi su situazioni tipiche, non sul nostro caso: è un punto di partenza utile, ma va adattato. La buona notizia è che si può ridurre molto questo effetto. La fascia in basso propone quattro accorgimenti: dare il contesto, cioè settore, tipo di clienti, dimensione, vincoli; fornire i propri dati invece di lasciare che il sistema li supponga; chiedere a quali condizioni la conclusione vale e quando non vale; chiedere di esplicitare assunzioni e limiti. Con queste indicazioni le risposte diventano più specifiche e più facili da valutare.");
    flowTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiEyeOff", head: "Assunzioni implicite", headSize: 16, bodySize: 12, inline: true,
      body: [{ text: "Esempio: un risparmio che assume volumi invariati.", options: { italic: true, breakLine: true, paraSpaceAfter: 8 } }, { text: "Che cosa deve essere vero perché la conclusione valga?", options: { bold: true, color: C.accent1 } }] });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiMaximize2", head: "Generalizzazioni indebite", headSize: 16, bodySize: 12, fill: C.accent6, inline: true,
      body: [{ text: "Esempio: \"i clienti preferiscono l'online\", da un'indagine su giovani di una città.", options: { italic: true, breakLine: true, paraSpaceAfter: 8 } }, { text: "Su quanti casi, in quale contesto? Vale per noi?", options: { bold: true, color: C.accent1 } }] });
    txt(s, "Per ottenere conclusioni meno generiche", { x: 0.5, y: 3.68, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    ["Dare il contesto: settore, clienti, vincoli", "Fornire i propri dati", "Chiedere a quali condizioni vale", "Chiedere assunzioni e limiti"].forEach((q, i) => chip(s, 0.5 + i * 2.29, 4.08, 2.16, 0.85, q, { fill: C.background2, fontSize: 12, bold: false }));
  }
  {
    const s = content("Alternative e omissioni nel ragionamento", "Un ragionamento solido considera le alternative; uno debole presenta una sola interpretazione dei dati come l'unica possibile. Per ogni conclusione importante: quali altre spiegazioni sono compatibili con gli stessi dati? Nell'esempio dei negozi, il calo potrebbe dipendere da lavori stradali, da un cambio di assortimento, dalla stagionalità. Qui ritroviamo le omissioni, applicate ai ragionamenti: una conclusione apparentemente coerente può poggiare su premesse incomplete. Nel 7.2 l'omissione rendeva incompleto l'output; qui rende ingiustificata la conclusione. Se il ragionamento non considera che una parte delle vendite online nasce da clienti che hanno visto il prodotto in negozio, chiudere i negozi potrebbe ridurre proprio l'online. Il controllo finale riassume il sottotema: la conclusione è proporzionata alle evidenze? Può essere troppo forte, quando presenta come certo ciò che è probabile; troppo debole, quando resta vaga anche con evidenze solide; o non collegata ai dati presentati. L'AI è un ottimo alleato per questo esame: chiedere 'qual è l'argomento più forte contro questa conclusione?' o 'quali informazioni potrebbero cambiarla?' fa emergere in pochi secondi alternative che da soli richiederebbero tempo.");
    flowTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiShuffle", head: "Interpretazioni alternative", headSize: 15, bodySize: 12,
      body: [{ text: "Quali altre spiegazioni sono compatibili con gli stessi dati?", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Calo in negozio: lavori stradali, assortimento, stagionalità.", options: { italic: true } }] });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiAlertTriangle", head: "Omissioni nelle premesse", headSize: 15, bodySize: 12, fill: C.accent6,
      body: [{ text: "Eccezioni, condizioni, controargomentazioni non considerate", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Molti acquisti online nascono da visite in negozio.", options: { italic: true } }] });
    banner(s, 3.7, "Quali informazioni potrebbero cambiare la conclusione? Qual è l'argomento più forte contro?", { h: 0.7, fontSize: 13 });
    txt(s, "Una conclusione solida è proporzionata alle evidenze: né più forte, né più debole di quanto i dati consentano.", { x: 0.5, y: 4.5, w: 9, h: 0.45, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Informazioni singolarmente corrette non assicurano che la conclusione tratta da esse sia giustificata.", "Sottotema 7.4  ·  Valutare ragionamenti e conclusioni", "Concetto chiave. Per valutare un ragionamento lo si scompone in dati, premesse e conclusione, e si cercano i difetti tipici: passaggi non giustificati, confusione tra correlazione e causalità, assunzioni implicite, generalizzazioni indebite, alternative ignorate, omissioni nelle premesse. La conclusione deve essere proporzionata alle evidenze. Contesto, dati e richieste mirate riducono le conclusioni generiche, e l'AI aiuta a far emergere alternative e controargomentazioni. Esercizio suggerito: dare ai partecipanti una breve raccomandazione prodotta dall'AI e chiedere di scomporla, individuare un'assunzione implicita e proporre un'interpretazione alternativa; poi chiedere all'AI l'argomento più forte contro la conclusione e confrontare.");

  // =====================================================================
  section("7.5 Dati e calcoli");
  divider("7.5", "Verifica di dati, calcoli e risultati quantitativi", "Un risultato quantitativo utile alle decisioni deve essere riconducibile a dati e procedimenti controllabili", "I numeri hanno un'autorevolezza particolare: una percentuale precisa o una tabella ordinata sembrano più oggettive di una frase. I risultati quantitativi prodotti con l'AI possono essere molto utili e molto rapidi da ottenere, ma possono contenere errori nei dati di partenza, nelle formule, nelle unità, nelle aggregazioni, nella rappresentazione. Vediamo controlli pratici, alla portata di chiunque lavori con dati, senza entrare in metriche statistiche avanzate. Nel 7.6 vedremo come usare strumenti di calcolo per rendere questi controlli rapidi e riproducibili.");
  {
    const s = content("Dati, formule, unità e plausibilità", "Il controllo di un risultato quantitativo parte dall'inizio della catena. I dati di partenza: provengono dalla fonte corretta, riguardano il periodo, l'entità e la versione giusti? Sono completi? Sono stati letti correttamente, senza confondere colonne o separatori decimali? Un errore qui si propaga a tutto ciò che segue. Le formule: il calcolo è quello appropriato? Una media va ponderata quando i gruppi hanno dimensioni diverse, un margine si calcola secondo la definizione in uso in azienda. Il sistema può scegliere una formula plausibile ma diversa da quella adottata dalla nostra organizzazione: conviene indicarla nella richiesta. Le unità: euro o migliaia di euro, mese o anno, pezzi o confezioni, percentuali o punti percentuali. Da 10% a 12% è un aumento di 2 punti percentuali, ma del 20% in termini relativi. La fascia centrale propone i controlli di plausibilità, rapidi ed efficaci, che richiedono conoscenza del contesto più che calcoli. Ordine di grandezza: se il fatturato annuo è di circa 10 milioni, un risultato di 100 milioni o di 100 mila segnala un errore. Segno: un costo negativo richiede una spiegazione. Totali: le parti sommano al totale, le percentuali a cento? Coerenza con il noto: un reparto di 5 persone non dovrebbe costare più di uno di 50. Variazioni nel tempo: +300% in un mese in un'attività stabile è sospetto. Non dimostrano la correttezza, ma intercettano molti errori in pochi secondi. Infine, distinguere il tipo di numero: misurato, stimato o simulato, come visto nel 7.3. Un valore molto preciso non è necessariamente un dato osservato.");
    flowTag(s, 1);
    const c = [["FiDatabase", "Dati di partenza", ["Fonte, periodo, versione giusti?", "Completi e letti bene?"]], ["FiCode", "Formule", ["Il calcolo appropriato?", "Definizioni aziendali rispettate?"]], ["FiSliders", "Unità di misura", ["Euro o migliaia, mese o anno?", "Percentuale o punti percentuali?"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 1.75, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 12, inline: true, fill: i === 2 ? C.accent6 : C.background2, body: bullets(c[i][2], { space: 4 }) });
    txt(s, "Controlli rapidi di plausibilità", { x: 0.5, y: 3.08, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Ordine di grandezza", "Segno", "Totali e percentuali", "Coerenza con il noto", "Variazioni nel tempo"].forEach((q, i) => chip(s, 0.5 + i * 1.82, 3.45, 1.72, 0.6, q, { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.25, "Da 10% a 12%: +2 punti percentuali, ma +20% in termini relativi. Conoscere i propri numeri è il primo filtro.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Aggregazioni e confronti", "Molti errori quantitativi nascono quando si sommano, si mediano o si raggruppano i dati, e nei confronti. Le medie possono nascondere situazioni molto diverse: un tempo medio di consegna di tre giorni può derivare da metà consegne in un giorno e metà in cinque; a volte la mediana o la distribuzione sono più informative. Le medie di medie sono spesso sbagliate: se due filiali hanno margini del 10% e del 20%, il margine complessivo è il 15% solo se hanno lo stesso fatturato. Le percentuali vanno lette con le basi: +50% su 4 casi significa passare a 6, non è un trend. I confronti devono essere omogenei: stesso periodo, stessa definizione, stesso perimetro. Infine, basta accennare che i dati aggregati possono mostrare un andamento opposto a quello dei sottogruppi, il cosiddetto paradosso di Simpson: per le decisioni importanti conviene guardare anche i dati disaggregati. Una richiesta utile all'AI: 'mostra i risultati anche per area e indica se l'andamento complessivo è coerente con quello delle singole aree'.");
    flowTag(s, 1);
    const c = [["FiBarChart", "Medie che nascondono", "3 giorni di media: metà in 1, metà in 5"], ["FiDivide", "Medie di medie", "Margini 10% e 20%: il complessivo è 15% solo con fatturati uguali"], ["FiPercent", "Percentuali senza base", "+50% su 4 casi: da 4 a 6, non un trend"], ["FiColumns", "Confronti non omogenei", "Trimestre contro anno, una sede contro l'azienda"]];
    await iconGrid(s, c.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.85, headSize: 14, bodySize: 12 });
    txt(s, "I dati aggregati possono mostrare un andamento opposto a quello dei sottogruppi (paradosso di Simpson): per decisioni importanti, guardare anche i dati disaggregati.", { x: 0.5, y: 4.25, w: 9, h: 0.7, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Tabelle, grafici e tracciabilità", "Tabelle e grafici vanno letti con la stessa attenzione dei testi, perché la forma visiva può rafforzare o distorcere il messaggio. Il caso classico è in slide: gli stessi valori, 102 e 105, con un asse verticale che parte da zero e con uno che parte da 100. Nel primo la differenza appare modesta, come è; nel secondo sembra enorme. Nessuno dei due è falso, ma il secondo può indurre a conclusioni sbagliate. Da controllare: assi, etichette e unità; periodo e scale; corrispondenza con le tabelle di origine; categorie omesse o raggruppate in 'altro'; per le tabelle, totali, arrotondamenti e valori mancanti. La fascia in basso riguarda la tracciabilità, che rende i numeri utilizzabili per decidere: deve essere possibile ricostruire quali dati, quali formule e quali passaggi hanno prodotto il risultato. Quando si usa l'AI per un'analisi conviene chiedere passaggi, formule e, se lo strumento esegue codice, il codice stesso, così che possa essere riletto o rieseguito. I valori importanti si ricalcolano con uno strumento indipendente, come un foglio di calcolo partendo dai dati originali, o si confrontano con i report aziendali: uno strumento indipendente è prezioso perché non condivide gli eventuali errori del primo. Il livello di impegno dipende dall'uso: un ordine di grandezza per una discussione interna non richiede lo stesso controllo di un valore da inserire in un'offerta. Nel 7.6 vediamo un esempio pratico.");
    flowTag(s, 1);
    const cOpt = (min, title, color) => ({ barDir: "col", chartColors: [color], showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 11, dataLabelFontFace: "+mn-lt", catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 9, valAxisLabelFontFace: "+mn-lt", valAxisMinVal: min, valAxisMaxVal: 110, valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, showTitle: true, title, titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 80 });
    s.addChart(pres.charts.BAR, [{ name: "Valore", labels: ["2024", "2025"], values: [102, 105] }], Object.assign({ x: 0.5, y: 1.15, w: 2.6, h: 2.45 }, cOpt(0, "Asse da zero", HEX.a1)));
    s.addChart(pres.charts.BAR, [{ name: "Valore", labels: ["2024", "2025"], values: [102, 105] }], Object.assign({ x: 3.2, y: 1.15, w: 2.6, h: 2.45 }, cOpt(100, "Asse da 100", HEX.a5)));
    txt(s, "Stessi dati, impressione molto diversa", { x: 0.5, y: 3.62, w: 5.3, h: 0.3, fontSize: 12, bold: true, color: C.text1, align: "center" });
    txt(s, "Da controllare", { x: 6.1, y: 1.15, w: 3.4, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["Assi, etichette, unità, scale", "Corrispondenza con le tabelle", "Categorie omesse o in \"altro\"", "Totali, arrotondamenti, mancanti"], { x: 6.1, w: 3.4, y: 1.52, h: 0.5, fontSize: 11 });
    shapeBox(s, 0.5, 4.05, 9.0, 0.9, C.text1, "tracciabilità");
    txt(s, [{ text: "Tracciabilità: ", options: { bold: true, color: C.accent1 } }, { text: "dati, formule e passaggi devono poter essere ricostruiti; i valori importanti si ricalcolano con uno strumento indipendente.", options: { color: C.background1 } }], { x: 0.7, y: 4.05, w: 8.6, h: 0.9, fontSize: 13, valign: "middle" });
  }
  keySlide("Un risultato quantitativo utile alle decisioni deve essere riconducibile a dati e procedimenti controllabili.", "Sottotema 7.5  ·  Verifica di dati, calcoli e risultati quantitativi", "Concetto chiave. Verificare i numeri significa controllare dati di partenza, formule e unità; applicare i controlli rapidi di plausibilità; distinguere dati osservati, stime e simulazioni; leggere con attenzione medie, percentuali e confronti; controllare tabelle e grafici; garantire la tracciabilità e ricalcolare i valori importanti con uno strumento indipendente. Esercizio suggerito: dare ai partecipanti una piccola tabella prodotta dall'AI con un errore di unità e un totale che non torna, e chiedere di individuarli con i soli controlli di plausibilità, in meno di due minuti.");

  // =====================================================================
  section("7.6 Revisione assistita dall'AI");
  divider("7.6", "Tecniche di verifica e revisione assistite dall'AI", "L'AI può rendere la revisione più rapida e completa: per le affermazioni importanti servono comunque evidenze attendibili", "Questo è il sottotema in cui l'AI passa dall'altra parte: non solo produce contenuti, ma aiuta a rivederli e migliorarli. Usata bene, la revisione assistita fa risparmiare tempo, trova problemi che a una prima lettura sfuggono e rende i controlli più sistematici. Vediamo il ciclo di miglioramento, le principali tecniche di revisione, tre esempi pratici, cioè la revisione di un'offerta, la verifica di un calcolo e il confronto tra due documenti, e come formulare le richieste di controllo. Chiudiamo con la distinzione che rende tutto questo affidabile: la revisione assistita trova i punti da controllare, la verifica fattuale li conferma con evidenze.");
  {
    const s = content("Un ciclo di miglioramento", "Il modo più efficace di usare l'AI per la qualità è un ciclo in quattro passi. Generare: l'AI produce una prima versione, guidata da una buona richiesta. Revisionare: l'AI, nel ruolo di revisore, cerca contraddizioni, ambiguità, omissioni, punti deboli e requisiti non rispettati; la persona legge le osservazioni e decide quali sono fondate. Migliorare: si correggono i punti emersi, anche chiedendo all'AI di proporre le modifiche puntuali. Validare: la persona verifica le affermazioni importanti con evidenze e decide l'uso, come vedremo nel 7.8. Il ciclo è rapido: spesso basta un giro per una comunicazione interna, mentre per un documento critico se ne fanno due o tre. Il vantaggio rispetto a una revisione solo manuale è duplice: l'AI esamina sistematicamente tutto il testo, senza stancarsi, e la persona concentra il proprio tempo sul giudizio, cioè sulle parti che contano. La fascia in basso elenca ciò che l'AI sa fare particolarmente bene in revisione: sono problemi interni al testo, che si vedono confrontando le sue parti tra loro o con i requisiti forniti. Le affermazioni sul mondo esterno, come dati, norme e fatti, richiedono invece un controllo con le fonti.");
    flowTag(s, 1);
    const st = [["FiEdit3", "Generare", "L'AI produce una prima versione", "AI, guidata dalla richiesta"], ["FiSearch", "Revisionare", "Si cercano errori, lacune, punti deboli", "AI come revisore, persona che giudica"], ["FiTrendingUp", "Migliorare", "Si correggono i punti emersi", "AI e persona"], ["FiCheckCircle", "Validare", "Verifica delle affermazioni importanti e decisione sull'uso", "Persona, con evidenze"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.1, 2.35, i === 3 ? C.accent1 : (i === 1 ? C.accent6 : C.background2), st[i][1]);
      await iconCircle(s, x + 0.78, 1.32, 0.55, st[i][0], i === 3 ? C.background1 : C.accent1, i === 3 ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.1, y: 1.95, w: 1.9, h: 0.38, fontSize: 16, bold: true, color: i === 3 ? C.background1 : C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.35, w: 1.8, h: 0.62, fontSize: 11, color: i === 3 ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.15, y: 3.0, w: 1.8, h: 0.45, fontSize: 10, bold: true, color: i === 3 ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.2, 0.18);
    }
    txt(s, "Che cosa l'AI individua bene in revisione", { x: 0.5, y: 3.7, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Contraddizioni", "Ambiguità", "Omissioni", "Punti deboli", "Requisiti mancanti"].forEach((q, i) => chip(s, 0.5 + i * 1.82, 4.05, 1.72, 0.45, q, { fill: C.accent6, fontSize: 12 }));
    txt(s, "Dati, norme e fatti esterni al testo si confermano con le fonti.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Sei tecniche di revisione assistita", "Ecco sei tecniche, con un esempio di richiesta per ciascuna. Revisione critica: 'Rileggi il testo come un revisore esigente e segnala errori, imprecisioni e punti poco chiari'. Assunzioni e punti deboli: 'Quali assunzioni implicite contiene questo ragionamento? Quali sono i punti più deboli?'. Controargomentazioni: 'Qual è l'argomento più forte contro questa conclusione?'. Alternative: 'Quali altre conclusioni sono compatibili con gli stessi dati?'. Checklist e criteri: 'Verifica se il documento rispetta questi cinque requisiti e indica per ciascuno dove e come'. Contraddizioni e lacune: 'Ci sono affermazioni in contraddizione tra loro? Quali informazioni importanti mancano?'. Applicano gli strumenti dei sottotemi 7.2 e 7.4, chiedendo al sistema un primo esame rapido e sistematico. Un accorgimento utile: avviare la revisione in una nuova conversazione, oppure presentare il testo come lavoro di un collega. Può ridurre alcuni effetti del contesto, cioè l'influenza della conversazione precedente e la tendenza ad assecondare l'utente, già vista nel Tema 3 come compiacenza. È una strategia utile, non una garanzia: il nuovo esame può avere limiti simili, e le osservazioni restano da valutare. In modo analogo, la checklist funziona meglio se i criteri sono scritti dalla persona, sulla base dei requisiti reali del documento.");
    flowTag(s, 1);
    const t = [["FiCheckSquare", "Revisione critica", "\"Rileggi come un revisore esigente: errori, imprecisioni, punti poco chiari.\""], ["FiEyeOff", "Assunzioni e punti deboli", "\"Quali assunzioni implicite? Quali punti più deboli?\""], ["FiShield", "Controargomentazioni", "\"Qual è l'argomento più forte contro questa conclusione?\""], ["FiShuffle", "Alternative", "\"Quali altre conclusioni sono compatibili con i dati?\""], ["FiList", "Checklist e criteri", "\"Verifica questi cinque requisiti, indicando dove e come.\""], ["FiAlertCircle", "Contraddizioni e lacune", "\"Ci sono contraddizioni? Che cosa manca?\""]];
    await iconGrid(s, t.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 2.95, headSize: 13, bodySize: 11 });
    banner(s, 4.3, "Una nuova conversazione, o il testo presentato come lavoro di altri, può ridurre alcuni effetti del contesto e della compiacenza: una strategia utile, non una garanzia.", { h: 0.65, fontSize: 12 });
  }
  {
    const s = content("Esempio 1: revisione critica di un'offerta", "Primo esempio pratico, da proporre come esercitazione. Input: la bozza di un'offerta commerciale per un nuovo cliente, con prezzi, tempi di consegna e condizioni di pagamento. Richiesta all'AI: il testo viene presentato come bozza da rivedere e si chiede di non riscriverlo, ma di segnalare contraddizioni tra prezzi, tempi e condizioni, frasi ambigue per il cliente, informazioni mancanti e affermazioni da verificare su una fonte, indicando per ogni osservazione il punto del testo. Risultato atteso: un elenco numerato di osservazioni collegate al testo. Esempi del tipo di osservazioni che ci si può aspettare: tempi di consegna indicati in modo diverso in due sezioni, una penale citata ma non quantificata, una condizione di pagamento non definita. La persona valuta ogni osservazione, decide che cosa correggere e verifica prezzi e condizioni sui listini e sui documenti aziendali. Perché chiedere osservazioni e non una riscrittura: se si chiede di correggere direttamente, il sistema può modificare anche parti corrette e diventa difficile capire che cosa è cambiato; un elenco di osservazioni lascia la decisione alla persona. Nota per il relatore: il risultato indicato è quello da attendersi, non l'esito di una prova; in aula conviene eseguire la richiesta su una bozza preparata in anticipo, con due o tre errori inseriti di proposito, e discutere che cosa l'AI ha trovato e che cosa no.");
    flowTag(s, 1);
    await exFlow(s, "Bozza di offerta commerciale per un nuovo cliente, con prezzi, tempi di consegna e condizioni di pagamento.",
      "Questa è la bozza di un'offerta.\nNon riscriverla. Segnala:\n1. contraddizioni tra prezzi,\n   tempi e condizioni;\n2. frasi ambigue per il cliente;\n3. informazioni mancanti;\n4. affermazioni da verificare.\nPer ogni punto indica dove si\ntrova nel testo.",
      ["Elenco numerato di osservazioni, collegate al testo", "Per esempio: tempi diversi in due sezioni, penale non quantificata", "La persona decide e verifica prezzi e condizioni"],
      "Osservazioni, non riscrittura: si vede che cosa cambia e le parti corrette restano intatte.");
  }
  {
    const s = content("Esempio 2: verifica quantitativa", "Secondo esempio: verificare risultati numerici con strumenti di calcolo. Input: una tabella delle vendite trimestrali di quattro aree, esportata dal gestionale e allegata alla conversazione. Richiesta all'AI: usare lo strumento di analisi o di esecuzione del codice disponibile, calcolare totale e crescita per area, mostrare formule o codice usati, controllare che la somma delle aree corrisponda al totale e segnalare valori mancanti o anomali. Risultato atteso: una tabella con i risultati e il procedimento, formule o codice che si possono rieseguire, controlli di quadratura con esito esplicito e un elenco di eventuali anomalie. La persona controlla poi due cose che lo strumento non può sapere: che i dati di partenza siano quelli giusti, per periodo e perimetro, e che le definizioni, per esempio di crescita o di margine, siano quelle in uso in azienda. Ricalcolare un valore chiave nel foglio di calcolo richiede pochi minuti e chiude il controllo. Perché funziona: un calcolo eseguito da uno strumento, con il procedimento visibile, è riproducibile e controllabile, mentre un numero scritto nel testo di una risposta non lo è. Se lo strumento in uso non esegue codice, si può chiedere di produrre le formule del foglio di calcolo, da incollare e verificare. Nota per il relatore: le funzioni di analisi dati e di esecuzione del codice variano tra prodotti e versioni; verificare prima dell'edizione quali sono disponibili negli strumenti dei partecipanti.");
    flowTag(s, 1);
    await exFlow(s, "Tabella delle vendite trimestrali di quattro aree, esportata dal gestionale e allegata.",
      "Usa lo strumento di analisi o\ndi esecuzione del codice.\n1. Calcola totale e crescita\n   per area.\n2. Mostra formule o codice.\n3. Controlla che la somma delle\n   aree sia uguale al totale.\n4. Segnala valori mancanti\n   o anomali.",
      ["Risultati con il procedimento visibile", "Formule o codice rieseguibili", "Controlli di quadratura con esito esplicito", "La persona controlla dati di partenza e definizioni"],
      "Un calcolo eseguito e riproducibile vale più di un numero scritto nel testo: dati e definizioni restano da controllare.");
  }
  {
    const s = content("Esempio 3: confronto tra documenti", "Terzo esempio: il confronto documentale, una delle attività in cui l'AI fa risparmiare più tempo. Input: il contratto in vigore con un fornitore e la nuova proposta di rinnovo, entrambi allegati. Richiesta all'AI: elencare le differenze su prezzo, durata, rinnovo, penali e recesso; indicare le clausole presenti in un documento e assenti nell'altro; segnalare incoerenze interne a ciascun documento; per ogni punto, citare sezione e testo di entrambi i documenti. Risultato atteso: una tabella delle differenze con i rimandi alle sezioni e le clausole mancanti evidenziate. Il rimando a sezione e testo è la parte più importante della richiesta: rende ogni osservazione controllabile in pochi secondi, perché basta aprire il documento al punto indicato. La persona rilegge nei documenti originali i punti che contano e, per gli aspetti legali rilevanti, chiede il parere di un esperto. Lo stesso schema vale per molti casi aziendali: due versioni di una procedura, un capitolato e un'offerta ricevuta, una policy e il suo aggiornamento. Attenzione ai documenti molto lunghi o scansionati: conviene chiedere al sistema di indicare le parti che non è riuscito a leggere o confrontare. Nota per il relatore: il risultato indicato è quello da attendersi; per l'esercitazione usare documenti fittizi o autorizzati, mai contratti reali con dati riservati, nel rispetto delle regole aziendali sull'uso dei dati.");
    flowTag(s, 1);
    await exFlow(s, "Contratto in vigore con un fornitore e nuova proposta di rinnovo, entrambi allegati.",
      "Confronta i due documenti.\n1. Differenze su prezzo, durata,\n   rinnovo, penali, recesso.\n2. Clausole presenti in uno e\n   assenti nell'altro.\n3. Incoerenze interne.\nPer ogni punto cita sezione e\ntesto di entrambi.",
      ["Tabella delle differenze con i rimandi alle sezioni", "Clausole mancanti evidenziate", "La persona rilegge i punti chiave; per gli aspetti legali, un esperto"],
      "I rimandi a sezione e testo rendono ogni osservazione controllabile in pochi secondi.");
  }
  {
    const s = content("Richieste di conferma più efficaci", "Un'abitudine diffusa è chiedere all'AI 'sei sicuro?' o 'controlla se è corretto'. Sono richieste poco efficaci, per due motivi. Una domanda che esprime un dubbio generico può portare il sistema ad assecondarlo, cambiando anche una risposta corretta, oppure a confermare un errore con nuove giustificazioni convincenti: è la tendenza alla compiacenza vista nel Tema 3, documentata anche in letteratura, e il caso Mata v. Avianca del 2023, in cui un sistema confermò l'esistenza di sentenze che non esistevano, ne è un esempio noto. La tabella mostra come trasformare la richiesta. Invece di 'Sei sicuro?', chiedere 'Quali assunzioni potrebbero rendere errata questa conclusione?': l'attenzione si sposta sui punti deboli. Invece di 'Controlla tutto', chiedere 'Individua le cinque affermazioni fattuali più importanti da verificare': si ottiene una lista mirata, verificabile in poco tempo. Invece di 'Confermi il calcolo?', chiedere 'Mostra dati, formula e procedimento riproducibile': il calcolo diventa controllabile. Queste richieste migliorano davvero la revisione, perché producono elementi da controllare invece di rassicurazioni. Ma restano una revisione: non sostituiscono la verifica indipendente delle affermazioni importanti con fonti, dati originali o strumenti di calcolo.");
    flowTag(s, 1);
    table(s, [["Meno efficace", "Più efficace", "Perché funziona"], ["\"Sei sicuro?\"", "\"Quali assunzioni potrebbero rendere errata questa conclusione?\"", "Sposta l'attenzione sui punti deboli"], ["\"Controlla tutto\"", "\"Individua le cinque affermazioni fattuali più importanti da verificare\"", "Produce una lista mirata e rapida da verificare"], ["\"Confermi il calcolo?\"", "\"Mostra dati, formula e procedimento riproducibile\"", "Rende il calcolo controllabile e ripetibile"]], { colW: [2.1, 4.0, 2.9], rowH: [0.42, 0.72, 0.72, 0.72], accentCol: 1, blankCorner: false, fontSize: 12 });
    banner(s, 4.0, "Un generico \"Sei sicuro?\" può confermare un errore o cambiare una risposta corretta. Le richieste mirate migliorano la revisione, ma non sostituiscono la verifica indipendente.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Revisione assistita e verifica indipendente", "La tabella distingue i due approcci, che sono complementari. La revisione assistita usa lo stesso sistema, o uno simile, per esaminare l'output. È rapida, economica, sempre disponibile, ed è molto efficace per trovare incoerenze, lacune, ambiguità e per costruire la lista dei punti da controllare. Il suo limite è che condivide in parte conoscenze e limiti di chi ha prodotto l'output e può risentire della compiacenza. La verifica indipendente usa evidenze esterne: fonti primarie, dati originali, strumenti di calcolo, esperti. È più impegnativa, ma fornisce una prova. Quando il sistema usa strumenti esterni, come la ricerca web, i documenti forniti o l'esecuzione di codice, la revisione si avvicina a una verifica, perché produce elementi controllabili: le fonti citate e i calcoli eseguiti vanno comunque aperti e controllati per i punti importanti. Lo stesso vale per il confronto tra modelli diversi. Se divergono su una domanda fattuale, è un segnale utile: almeno uno sbaglia e il punto va verificato. Se concordano, la fiducia aumenta un po', ma non è una prova: modelli addestrati su dati in parte simili possono condividere gli stessi errori. Due modelli non sono due fonti indipendenti. La sequenza efficace è quindi chiara: prima la revisione assistita trova rapidamente i punti dubbi, poi la verifica indipendente conferma quelli importanti.");
    flowTag(s, 1);
    table(s, [["", "Revisione assistita dall'AI", "Verifica indipendente"], ["Che cosa usa", "Lo stesso sistema o uno simile", "Fonti primarie, dati originali, strumenti, esperti"], ["Punti di forza", "Rapida, sistematica, sempre disponibile", "Fornisce una prova"], ["Utile per", "Incoerenze, lacune, ambiguità, lista dei punti dubbi", "Confermare o smentire i punti importanti"], ["Limiti", "Limiti simili a chi ha prodotto, compiacenza", "Più tempo e competenze"]], { colW: [1.8, 3.6, 3.6], rowH: 0.45, accentCol: 2, fontSize: 12 });
    rowBox(s, 0.5, 3.68, 4.4, 0.7, "Due modelli divergono", "Segnale utile: il punto va verificato", C.accent6);
    rowBox(s, 5.1, 3.68, 4.4, 0.7, "Due modelli concordano", "Aumenta un po' la fiducia, ma non è una prova", C.background2);
    banner(s, 4.48, "Prima la revisione assistita trova i punti dubbi, poi la verifica indipendente conferma quelli importanti.", { h: 0.5, fontSize: 12 });
  }
  keySlide("Una revisione assistita dall'AI è un supporto al controllo, non un sostituto delle evidenze indipendenti.", "Sottotema 7.6  ·  Tecniche di verifica e revisione assistite dall'AI", "Concetto chiave. L'AI è un alleato prezioso per la qualità: nel ciclo generare, revisionare, migliorare, validare individua contraddizioni, ambiguità, omissioni e punti deboli; con gli strumenti di calcolo rende i numeri riproducibili; nel confronto documentale trova differenze e clausole mancanti con rimandi controllabili. Le richieste mirate producono elementi da controllare invece di rassicurazioni. Per le affermazioni importanti, però, servono evidenze attendibili: fonti, dati originali, calcoli rieseguibili, esperti. Esercizio suggerito: far applicare ai partecipanti la richiesta dell'esempio 1 a un documento preparato con alcuni errori inseriti, poi verificare in modo indipendente i due punti più importanti emersi e discutere quanto tempo ha fatto risparmiare la revisione assistita.");

  // =====================================================================
  section("7.7 Bias cognitivi");
  divider("7.7", "Bias cognitivi e fiducia nell'AI", "L'affidabilità del processo dipende anche dall'atteggiamento di chi valuta e dalla capacità di riconoscere i propri bias", "Finora abbiamo parlato degli output e dei metodi per valutarli. Ma la valutazione la fa una persona, e le persone hanno tendenze sistematiche di giudizio, i bias cognitivi, che possono spingere verso troppa fiducia o troppo poca. Alcuni li abbiamo incontrati nei Temi 3 e 5: qui li guardiamo dal punto di vista della valutazione e proponiamo contromisure pratiche. L'obiettivo è una consapevolezza operativa, non uno studio psicologico.");
  {
    const s = content("I bias che influenzano la valutazione", "Ecco i principali bias che possono influenzare il modo in cui valutiamo gli output dell'AI. Bias di conferma: accettiamo più facilmente ciò che conferma le nostre convinzioni. Automation bias: tendiamo a privilegiare i suggerimenti dei sistemi automatici riducendo la verifica, un fenomeno studiato a lungo nell'interazione con l'automazione, per esempio da Parasuraman e Manzey. Autorevolezza apparente: attribuiamo credibilità a ciò che ha la forma di un testo competente. Fluidità e sicurezza espressiva: ciò che è facile da leggere tende a sembrare più vero, come mostrato da Reber e Schwarz nel 1999, e un tono sicuro ci sembra un segnale di competenza. Fiducia eccessiva, spesso rafforzata dalle esperienze positive: dopo molte risposte corrette si smette di controllare. Sfiducia non giustificata, l'errore opposto, che porta a scartare output validi e a verifiche che non aggiungono valore, spesso dopo un'esperienza negativa generalizzata a tutti gli usi. Delega del giudizio: lasciare che sia il sistema a decidere che cosa è giusto. Fluidità, sicurezza e autorevolezza agiscono insieme e in modo largamente automatico: non si eliminano con la consapevolezza, si contrastano con il metodo, cioè separando forma e sostanza e controllando i punti critici indipendentemente da quanto suonano convincenti. Sono tendenze comuni a tutti, non segni di superficialità. Domanda per il gruppo: in quale direzione sbagliate più spesso, troppa fiducia o troppo poca, e in quali situazioni?");
    flowTag(s, -1);
    const b = [["FiCheckCircle", "Bias di conferma"], ["FiCpu", "Automation bias"], ["FiAward", "Autorevolezza apparente"], ["FiFeather", "Fluidità e sicurezza"], ["FiThumbsUp", "Fiducia eccessiva"], ["FiThumbsDown", "Sfiducia non giustificata"], ["FiPause", "Delega del giudizio"]];
    for (let i = 0; i < 7; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 2.75, y = 1.2 + row * 0.78;
      shapeBox(s, x, y, 2.6, 0.66, i === 5 ? C.accent6 : C.background2, b[i][1]);
      await iconCircle(s, x + 0.12, y + 0.11, 0.44, b[i][0], i === 5 ? C.accent2 : C.accent1);
      txt(s, b[i][1], { x: x + 0.66, y, w: 1.85, h: 0.66, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    }
    shapeBox(s, 6.2, 1.2, 3.3, 3.0, C.text1, "fluidità");
    txt(s, "Perché un testo fluido convince", { x: 6.4, y: 1.32, w: 2.9, h: 0.6, fontSize: 14, bold: true, color: C.background1 });
    txt(s, "Ciò che è facile da leggere tende a sembrare più vero (Reber e Schwarz, 1999). Tono sicuro, lessico tecnico e numeri precisi rafforzano l'effetto.", { x: 6.4, y: 1.95, w: 2.9, h: 1.3, fontSize: 12, color: C.accent3 });
    txt(s, "Si contrasta con il metodo, non con la sola buona volontà.", { x: 6.4, y: 3.3, w: 2.9, h: 0.8, fontSize: 12, bold: true, color: C.accent1 });
    txt(s, "Tendenze comuni a tutti: spingono verso troppa fiducia o troppo poca.", { x: 0.5, y: 4.4, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Bias di conferma nella verifica", "Il bias di conferma agisce in modo specifico durante la verifica. Quando un output conferma ciò che pensiamo, tendiamo a considerarlo corretto e a verificarlo poco; quando lo contraddice, tendiamo a cercarne i difetti. Il risultato è una verifica asimmetrica: severa con le informazioni scomode, indulgente con quelle gradite. Inoltre, il modo in cui formuliamo le domande può già contenere la risposta desiderata, e il sistema può tendere ad assecondarla. Il bias si manifesta anche nella ricerca delle fonti: smettiamo di cercare quando ne troviamo una che conferma. Contromisure pratiche: applicare lo stesso livello di verifica a ciò che ci piace e a ciò che non ci piace, magari con una checklist fissa; cercare attivamente le evidenze contrarie, chiedendosi che cosa si troverebbe se si avesse torto; chiedere all'AI gli argomenti più forti contro la propria tesi, un uso in cui l'AI è particolarmente efficace; quando possibile, far verificare a qualcuno che non ha preferenze sul risultato.");
    flowTag(s, -1);
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiAlertTriangle", head: "Come agisce", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Verifica indulgente con ciò che conferma", "Severa con ciò che contraddice", "Domande che contengono già la risposta desiderata", "Ci si ferma alla prima fonte che conferma"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiShield", head: "Contromisure", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Stesso livello di verifica, con una checklist fissa", "\"Che cosa troverei se avessi torto?\"", "Chiedere all'AI gli argomenti contrari", "Far verificare a chi non ha preferenze"], { space: 3 }) });
    banner(s, 4.0, "Il rischio: una verifica asimmetrica, severa con le informazioni scomode e indulgente con quelle gradite.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Preservare l'autonomia di giudizio", "Nel Tema 5 abbiamo visto come usare l'AI mantenendo autonomia e competenze. Qui le pratiche diventano contromisure ai bias nella valutazione. Formarsi un'opinione prima di leggere l'output, anche sommaria: dà un termine di confronto e riduce l'ancoraggio alla risposta. Usare checklist e criteri fissati in anticipo: rendono la verifica meno dipendente dall'impressione del momento. Considerare l'opposto: perché la conclusione potrebbe essere sbagliata? Rallentare sui punti critici: la lettura veloce favorisce i giudizi automatici, quella mirata il ragionamento. Separare produzione e verifica: lasciare passare del tempo o affidare la verifica a un'altra persona. Tenere traccia degli errori trovati, e anche dei casi in cui l'output era corretto: aiuta a calibrare la fiducia futura in entrambe le direzioni, cioè a controllare di più dove il sistema ha sbagliato e di meno dove si è dimostrato affidabile. Sono pratiche leggere, da applicare quando l'output conta: non servono per ogni bozza.");
    flowTag(s, -1);
    const p = [["FiZap", "Opinione prima della lettura", "Un termine di confronto contro l'ancoraggio"], ["FiList", "Checklist fissate in anticipo", "Meno dipendenza dall'impressione"], ["FiRepeat", "Considerare l'opposto", "Perché potrebbe essere sbagliata?"], ["FiClock", "Rallentare sui punti critici", "Dal giudizio automatico al ragionamento"], ["FiUsers", "Separare produzione e verifica", "Tempo o un'altra persona"], ["FiBookmark", "Tenere traccia di errori e successi", "Per calibrare la fiducia in entrambe le direzioni"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 3.1, headSize: 13, bodySize: 12 });
    banner(s, 4.5, "Il miglior metodo di verifica funziona solo se chi lo applica riconosce i propri bias.", { h: 0.5, fontSize: 13 });
  }
  keySlide("L'affidabilità del processo dipende anche dall'atteggiamento di chi valuta il risultato e dalla capacità di riconoscere i propri bias.", "Sottotema 7.7  ·  Bias cognitivi e fiducia nell'AI", "Concetto chiave. Bias di conferma, automation bias, fluidità, sicurezza espressiva e autorevolezza apparente spingono verso la fiducia eccessiva; la sfiducia non giustificata è l'errore opposto, con un costo altrettanto reale. Hanno la stessa radice: fiducia basata su impressioni invece che su evidenze. Si contrastano con il metodo: opinione prima della lettura, checklist fisse, considerare l'opposto, rallentare sui punti critici, separare produzione e verifica, tenere traccia di errori e successi. Domanda di verifica: ripensate a un output dell'AI usato di recente. L'avreste controllato con la stessa severità se avesse detto il contrario di ciò che pensavate? E, al contrario, c'è un compito su cui continuate a controllare tutto anche se l'AI si è dimostrata affidabile?");

  // =====================================================================
  section("7.8 Validazione e responsabilità");
  divider("7.8", "Validazione e responsabilità nell'uso", "Validare significa decidere se un output, con le verifiche fatte e le incertezze residue, è adeguato a uno specifico utilizzo", "Arriviamo all'ultima fase della sequenza: decidere. Abbiamo valutato l'output e verificato ciò che lo richiedeva; ora stabiliamo se usarlo, e come. Vediamo la differenza tra plausibile, verificato e validato, come proporzionare i controlli, come valutarne costi e benefici, come trattare le incertezze residue e come si articola la responsabilità. Il 7.2 valutava la qualità del contenuto; qui ne valutiamo l'utilizzabilità in un contesto concreto. La responsabilità è trattata come consapevolezza operativa; gli aspetti normativi sono approfonditi nel Tema 18.");
  {
    const s = content("Plausibile, verificato, validato", "Tre parole per tre stati diversi di un output. Plausibile: sembra corretto, è ben scritto, coerente, credibile. È lo stato di quasi ogni output appena generato, e da solo non dice nulla sulla correttezza. Verificato: gli elementi che lo richiedevano sono stati controllati con evidenze, come fonti, dati, calcoli, esperti. È un passo decisivo, ma non ancora sufficiente. Validato: si è deciso che l'output, con le verifiche fatte e le incertezze che restano, è adeguato a uno specifico utilizzo. La validazione aggiunge lo scopo e la decisione. Un output può essere verificato e non validato: un'analisi corretta nei dati ma troppo generica per la decisione, un testo accurato ma inadatto al destinatario. E lo stesso output può essere validato per un uso e non per un altro: una sintesi adeguata per una discussione interna può non esserlo per un documento ufficiale. Per molti usi a basso rischio, la validazione coincide con una lettura attenta e richiede pochi secondi: il passaggio da plausibile a validato non deve essere lungo, deve essere consapevole.");
    flowTag(s, 2);
    const st = [["Plausibile", "Sembra corretto: ben scritto, coerente, credibile", "Quasi ogni output appena generato", C.background2, C.text1], ["Verificato", "I punti critici sono stati controllati con evidenze", "Decisivo, ma non sufficiente", C.accent6, C.text1], ["Validato", "Si è deciso che è adeguato a uno specifico utilizzo", "Aggiunge scopo e decisione", C.accent1, C.background1]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.5, st[i][3], st[i][0]);
      txt(s, st[i][0], { x: x + 0.2, y: 1.32, w: 2.46, h: 0.45, fontSize: 19, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, st[i][1], { x: x + 0.2, y: 1.85, w: 2.46, h: 0.95, fontSize: 13, color: st[i][4] });
      txt(s, st[i][2], { x: x + 0.2, y: 2.9, w: 2.46, h: 0.7, fontSize: 12, bold: true, italic: true, color: i === 2 ? C.accent6 : C.text2 });
      if (i < 2) arrow(s, x + 2.88, 2.3, 0.17);
    }
    banner(s, 3.9, "Verificato non significa validato: un'analisi corretta può essere troppo generica per la decisione. Validato per un uso, non per un altro.", { h: 1.05, fontSize: 13 });
  }
  {
    const s = content("L'economia della verifica", "La verifica richiede tempo: se ogni output fosse verificato in ogni dettaglio, l'AI farebbe risparmiare poco; se non si verificasse nulla, gli errori passerebbero. L'economia della verifica gradua impegno e profondità del controllo secondo due fattori: la probabilità di un errore e il suo impatto. Probabilità bassa e impatto basso: basta una lettura attenta. Probabilità alta e impatto basso: controlli rapidi e mirati, per esempio su numeri e nomi. Probabilità bassa e impatto alto: verifica dei punti critici, perché anche un errore raro avrebbe conseguenze serie. Probabilità alta e impatto alto: verifica approfondita e, se serve, un esperto. La fascia in basso indica da che cosa dipendono i due fattori. L'impatto dipende dalle conseguenze di un errore, con le quattro dimensioni viste nel Tema 3: gravità, reversibilità, chi subisce l'errore, facilità con cui verrebbe scoperto. Dipende anche dall'adeguatezza richiesta: il livello di dettaglio e di precisione che l'uso previsto richiede. La probabilità dipende dal tipo di contenuto: numeri, fonti, argomenti recenti o di nicchia, complessità. Un errore in una bozza interna che verrà rivista ha conseguenze minime; un errore in un'offerta, in una comunicazione a tutti i dipendenti o in un dato per una decisione d'investimento può avere conseguenze serie. Il principio evita due errori opposti: la verifica indiscriminata di ogni dettaglio, che spreca tempo, e i controlli insufficienti negli usi critici.");
    flowTag(s, 2);
    txt(s, "Impatto basso", { x: 1.6, y: 1.1, w: 3.6, h: 0.28, fontSize: 12, bold: true, color: C.accent2, align: "center" });
    txt(s, "Impatto alto", { x: 5.4, y: 1.1, w: 3.6, h: 0.28, fontSize: 12, bold: true, color: C.accent2, align: "center" });
    txt(s, "Probabilità bassa", { x: 0.5, y: 1.42, w: 1.05, h: 1.15, fontSize: 11, bold: true, color: C.accent2, valign: "middle" });
    txt(s, "Probabilità alta", { x: 0.5, y: 2.67, w: 1.05, h: 1.15, fontSize: 11, bold: true, color: C.accent2, valign: "middle" });
    const q = [["Rilettura", "Sufficiente una lettura attenta", C.accent6, C.text1], ["Verifica dei punti critici", "Anche un errore raro avrebbe conseguenze serie", C.background2, C.text1], ["Controlli rapidi e mirati", "Per esempio su numeri e nomi", C.background2, C.text1], ["Verifica approfondita", "Fonti indipendenti e, se serve, un esperto", C.text1, C.background1]];
    for (let i = 0; i < 4; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 1.6 + col * 3.8, y = 1.42 + row * 1.25;
      shapeBox(s, x, y, 3.65, 1.15, q[i][2], q[i][0]);
      txt(s, q[i][0], { x: x + 0.2, y: y + 0.1, w: 3.25, h: 0.4, fontSize: 15, bold: true, color: q[i][3] });
      txt(s, q[i][1], { x: x + 0.2, y: y + 0.52, w: 3.25, h: 0.55, fontSize: 12, color: q[i][3] });
    }
    shapeBox(s, 0.5, 4.0, 9.0, 0.95, C.background2, "fattori");
    txt(s, [{ text: "Impatto: ", options: { bold: true, color: C.accent1 } }, { text: "gravità, reversibilità, chi subisce l'errore, rilevabilità, precisione richiesta dall'uso.", options: { color: C.text1, breakLine: true } }, { text: "Probabilità: ", options: { bold: true, color: C.accent1 } }, { text: "numeri, fonti, argomenti recenti o di nicchia, complessità.", options: { color: C.text1 } }], { x: 0.7, y: 4.0, w: 8.6, h: 0.95, fontSize: 12, valign: "middle" });
  }
  {
    const s = content("Il bilancio della verifica", "Il costo della verifica va confrontato con l'intero processo, non solo con il tempo che servirebbe a fare il lavoro a mano. Il costo è il tempo di controllo e, a volte, la competenza necessaria. I benefici sono più ampi di quanto sembri. Tempo risparmiato a valle: un errore trovato prima dell'invio evita correzioni, rilavorazioni, chiarimenti con il cliente. Processo riutilizzabile: una richiesta di revisione ben fatta, una checklist, un controllo di quadratura si costruiscono una volta e si riusano su tutti i documenti dello stesso tipo. Qualità migliore: il ciclo di revisione assistita spesso produce un risultato migliore di quello che si otterrebbe senza AI, non solo più rapido. Scalabilità: su compiti ricorrenti, una verifica approfondita iniziale su un campione di casi può giustificare controlli più leggeri e periodici in seguito. Controlli automatizzabili: verifiche ripetitive, come quadrature, formati, campi obbligatori, rimandi tra documenti, si possono affidare a strumenti, fogli di calcolo o codice. Concentrare l'attenzione: poche affermazioni portano gran parte del peso; verificare quelle è il modo più efficiente di ridurre il rischio. Resta un criterio di buon senso: se per un compito specifico la verifica necessaria supera stabilmente il tempo di svolgerlo direttamente, conviene ripensare come usare l'AI su quel compito, per esempio usandola per una parte del lavoro o con documenti di riferimento, prima di rinunciarvi.");
    flowTag(s, 2);
    const p = [["FiClock", "Tempo risparmiato a valle", "Meno correzioni, rilavorazioni, chiarimenti"], ["FiRepeat", "Processo riutilizzabile", "Richieste, checklist e controlli si riusano"], ["FiAward", "Qualità migliore", "La revisione migliora il risultato, non solo la velocità"], ["FiLayers", "Scalabilità", "Verifica iniziale su un campione, poi controlli periodici"], ["FiCpu", "Controlli automatizzabili", "Quadrature, formati, campi, rimandi"], ["FiCrosshair", "Attenzione concentrata", "Poche affermazioni portano gran parte del peso"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 2.7, headSize: 13, bodySize: 11 });
    banner(s, 4.08, "Il confronto giusto riguarda l'intero processo: con un metodo ripetibile, verificare diventa sempre più rapido.", { h: 0.55, fontSize: 13 });
    txt(s, "Se su un compito la verifica supera stabilmente il lavoro diretto, conviene ripensare come usare l'AI su quel compito.", { x: 0.5, y: 4.68, w: 9, h: 0.32, fontSize: 11, italic: true, color: C.text1 });
  }
  {
    const s = content("Incertezze residue e decisione", "Due elementi chiudono il processo. Il primo è l'incertezza residua: anche dopo la verifica resta quasi sempre qualcosa di incerto, come informazioni non verificabili, stime, ipotesi o punti non controllati per mancanza di tempo. Un errore frequente è considerare un output verificato perché i punti controllati sono risultati corretti, dimenticando quelli non controllati. Tre passi: rendere esplicito ciò che resta incerto; valutarne l'impatto, cioè se cambierebbe la conclusione; decidere se accettarlo, ridurlo con altre verifiche o comunicarlo al destinatario. Comunicare l'incertezza con onestà, per esempio indicando che un dato è stimato, è un segno di professionalità. Il secondo è la decisione, con quattro esiti. Accettare: l'output è adeguato allo scopo e le incertezze sono accettabili; per molte attività quotidiane è l'esito più frequente. Modificare: è utilizzabile dopo correzioni o integrazioni, magari con un altro giro del ciclo di revisione. Approfondire: servono ulteriori verifiche, informazioni o un esperto. Rifiutare: contiene errori sostanziali o incertezze troppo alte per l'uso; non è un fallimento, ma l'esito corretto quando l'output non regge, e può portare a rifare il lavoro in altro modo. La fascia in basso riguarda le competenze specialistiche: quando chi valuta non ha le competenze per riconoscere gli errori e le conseguenze sono rilevanti, come in ambito legale, fiscale, medico, tecnico o di sicurezza, la validazione richiede il parere di un esperto.");
    flowTag(s, 2);
    ["1  Rendere esplicito ciò che resta incerto", "2  Valutarne l'impatto sulla conclusione", "3  Accettarlo, ridurlo o comunicarlo"].forEach((q, i) => chip(s, 0.5 + i * 3.07, 1.2, 2.86, 0.6, q, { fill: C.accent6, fontSize: 12 }));
    const d = [["FiCheck", "Accettare", "Adeguato allo scopo, incertezze accettabili", C.accent1, C.background1], ["FiEdit", "Modificare", "Utilizzabile dopo correzioni e integrazioni", C.accent6, C.text1], ["FiSearch", "Approfondire", "Servono verifiche, informazioni o un esperto", C.background2, C.text1], ["FiXCircle", "Rifiutare", "Errori sostanziali o incertezze troppo alte", C.text1, C.background1]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.95, 2.1, 1.85, d[i][3], d[i][1]);
      await iconCircle(s, x + 0.8, 2.05, 0.55, d[i][0], i === 0 || i === 3 ? C.background1 : C.accent1, i === 0 ? HEX.a1 : (i === 3 ? HEX.dk1 : HEX.lt1));
      txt(s, d[i][1], { x: x + 0.1, y: 2.68, w: 1.95, h: 0.38, fontSize: 15, bold: true, color: d[i][4], align: "center" });
      txt(s, d[i][2], { x: x + 0.15, y: 3.08, w: 1.85, h: 0.65, fontSize: 11, color: d[i][4], align: "center" });
    }
    shapeBox(s, 0.5, 3.98, 9.0, 0.97, C.background2, "esperto");
    await iconCircle(s, 0.7, 4.2, 0.5, "FiAward");
    txt(s, [{ text: "Coinvolgere un esperto ", options: { bold: true, color: C.text1 } }, { text: "quando mancano le competenze per riconoscere gli errori e le conseguenze sono rilevanti: aspetti legali, fiscali, medici, tecnici, di sicurezza.", options: { color: C.text2 } }], { x: 1.35, y: 3.98, w: 8.0, h: 0.97, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Documentare e responsabilità", "Due punti finali. La documentazione delle verifiche, quando necessaria: per gli output importanti, come documenti esterni, dati per decisioni rilevanti o contenuti soggetti a controllo, conviene tenere traccia di che cosa è stato verificato, con quali fonti, da chi e quando, e di quali incertezze restano. Non serve per ogni bozza, ma per ciò che potrebbe essere riesaminato o contestato. Permette di ricostruire il processo, correggere rapidamente se emerge un errore e imparare dagli errori trovati. La responsabilità: decidere di usare un risultato significa assumersene la responsabilità, nei termini che dipendono dal proprio ruolo e dal contesto. Conviene distinguere quattro piani. La responsabilità professionale: ciascuno risponde della qualità del proprio lavoro, anche quando è stato preparato con l'AI, come accade per qualsiasi altro strumento o collaboratore. Le procedure aziendali: molte organizzazioni definiscono regole su quali strumenti usare, quali contenuti rivedere e chi approva; vanno conosciute e rispettate. La supervisione: chi approva, firma o pubblica un contenuto risponde dei controlli previsti per il suo ruolo. Gli obblighi giuridici: dipendono dalla normativa applicabile al caso, al settore e al tipo di sistema, e vanno valutati caso per caso, con il supporto delle funzioni competenti; sono approfonditi nel Tema 18. Non esiste quindi una regola unica valida in ogni situazione, ma un principio operativo costante: chi decide di usare un output deve aver svolto i controlli adeguati al suo ruolo e all'uso previsto.");
    flowTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 3.0, { icon: "FiFileText", head: "Documentare, quando necessario", headSize: 15, bodySize: 12,
      body: [{ text: "Che cosa è stato verificato, con quali fonti, da chi, quando; quali incertezze restano.", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["Per ciò che potrebbe essere riesaminato o contestato", "Permette di ricostruire, correggere, imparare"], { space: 3 })) });
    shapeBox(s, 5.15, 1.2, 4.35, 3.0, C.text1, "responsabilità");
    await iconCircle(s, 5.35, 1.32, 0.48, "FiUserCheck", C.accent1);
    txt(s, "Chi decide di usare un risultato ne risponde secondo il proprio ruolo", { x: 5.95, y: 1.28, w: 3.4, h: 0.6, fontSize: 13, bold: true, color: C.background1, valign: "middle" });
    const r = [["Professionale", "la qualità del proprio lavoro, anche se preparato con l'AI"], ["Procedure aziendali", "regole su strumenti, revisione, approvazione"], ["Supervisione", "chi approva o firma risponde dei controlli previsti"], ["Obblighi giuridici", "quelli applicabili al caso e al settore"]];
    txt(s, r.map((e, i) => [{ text: e[0] + ": ", options: { bold: true, color: C.accent1 } }, { text: e[1], options: { color: C.accent3, breakLine: i < r.length - 1, paraSpaceAfter: 5 } }]).flat(), { x: 5.35, y: 2.0, w: 3.95, h: 2.1, fontSize: 11 });
    banner(s, 4.4, "Valutare, verificare e decidere non sono attività accessorie, ma parte essenziale dell'uso consapevole dell'AI.", { h: 0.55, fontSize: 12 });
  }
  keySlide("Validare significa decidere se un output, con le verifiche appropriate e le incertezze residue, sia adeguato a uno specifico utilizzo.", "Sottotema 7.8  ·  Validazione e responsabilità nell'uso", "Concetto chiave dell'ultimo sottotema. Plausibile, verificato e validato sono stati diversi. La validazione considera lo scopo e le conseguenze di un errore, gradua la verifica secondo probabilità e impatto, valuta costi e benefici sull'intero processo, tiene conto delle incertezze residue, coinvolge esperti quando servono e si conclude con una decisione: accettare, modificare, approfondire o rifiutare. Quando necessario, le verifiche si documentano, e la responsabilità si esercita secondo il ruolo, le procedure e le norme applicabili. Esercizio suggerito: presentare tre output con usi diversi, una bozza interna, una comunicazione a un cliente e un dato per una decisione d'investimento, e chiedere ai partecipanti quale livello di verifica applicherebbero, quanto tempo richiederebbe e quale decisione prenderebbero.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Valutare, verificare, decidere: una scheda pratica", "Traduciamo il modulo in una scheda pratica, che sostituisce i riepiloghi e si può distribuire ai partecipanti. Valutare: che cosa sostiene l'output? Distinguere fatti, ipotesi, stime e opinioni. È pertinente, completo, coerente? Che cosa manca? Il ragionamento regge? Verificare: solo i punti critici, scelti per importanza, rischio di errore e visibilità; risalire alle fonti primarie per le informazioni importanti; ricalcolare i numeri chiave con uno strumento; usare l'AI per trovare rapidamente i punti dubbi e le evidenze per confermarli. Decidere: l'output è adeguato all'uso previsto? Quali incertezze restano e quanto pesano? Serve un esperto? Accettare, modificare, approfondire o rifiutare, e documentare se necessario. Per tutto il processo: attenzione ai propri bias, con un'opinione formata prima di leggere e gli stessi controlli per ciò che piace e ciò che non piace. La scheda non è una procedura obbligatoria: per una bozza interna si riduce a pochi secondi, per un documento critico diventa un processo strutturato. Il messaggio conclusivo del modulo è nella fascia in basso: l'obiettivo non è verificare tutto, ma sapere che cosa verificare, come farlo e quando un risultato è sufficientemente affidabile per essere utilizzato. Suggerimento: chiudere chiedendo a ciascun partecipante di scegliere un'attività che svolge abitualmente con l'AI e di indicare quale livello di verifica applicherà da domani.");
    const f = [["Valutare", ["Che cosa sostiene? Fatti, ipotesi, stime, opinioni", "Pertinente, completo, coerente? Che cosa manca?", "Il ragionamento regge?"], C.background2], ["Verificare", ["Solo i punti critici: importanza, rischio, visibilità", "Fonti primarie; numeri ricalcolati con uno strumento", "L'AI trova i dubbi, le evidenze li confermano"], C.accent6], ["Decidere", ["Adeguato all'uso? Quali incertezze restano?", "Serve un esperto?", "Accettare, modificare, approfondire, rifiutare"], C.background2]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.55, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.2, y: 1.23, w: 2.46, h: 0.42, fontSize: 18, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.2, y: 1.7, w: 2.5, h: 1.95, fontSize: 12, color: C.text1 });
    }
    txt(s, "Sempre: attenzione ai propri bias, con gli stessi controlli per ciò che piace e ciò che no.", { x: 0.5, y: 3.78, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text1 });
    shapeBox(s, 0.5, 4.15, 9.0, 0.82, C.text1, "messaggio conclusivo");
    txt(s, "L'obiettivo non è verificare tutto, ma sapere che cosa verificare, come farlo e quando un risultato è sufficientemente affidabile per essere utilizzato.", { x: 0.7, y: 4.15, w: 8.6, h: 0.82, fontSize: 14, bold: true, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 7 si conclude l'area 'Interagire con l'AI', che ha seguito l'intero ciclo dell'interazione: il dialogo e la collaborazione nel Tema 5, la formulazione delle richieste nel Tema 6, la valutazione e la verifica dei risultati in questo tema. Insieme all'area 'Comprendere l'AI' costituisce la base di competenze trasversali del percorso. Con il Tema 8 si apre l'area 'Esplorare le possibilità dell'AI', dedicata a che cosa si può fare concretamente nei diversi ambiti di lavoro: generare e trasformare testi, sintetizzare e analizzare documenti, estrarre informazioni, confrontare documenti, interrogare raccolte documentali. Seguirà il Tema 9, dedicato a dati e analisi. In tutti questi ambiti la capacità di valutare, verificare e decidere costruita qui permette di usare l'AI su attività sempre più rilevanti. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo, può essere nascosta senza perdere contenuti.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree completate");
    txt(s, "AREE COMPLETATE", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.75, w: 3.9, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    txt(s, "Temi 1-4: rilevanza, funzionamento, affidabilità, ecosistema", { x: 0.75, y: 2.1, w: 3.9, h: 0.6, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.85, w: 3.9, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    txt(s, "Temi 5-7: dialogo, prompting, verifica e pensiero critico", { x: 0.75, y: 3.2, w: 3.9, h: 0.6, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "NUOVA AREA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 5.4, y: 1.72, w: 3.9, h: 0.4, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Tema 8: AI per testi, documenti e conoscenza", { x: 5.4, y: 2.2, w: 3.9, h: 0.6, fontSize: 14, bold: true, color: C.accent6 });
    txt(s, bullets(["Generare e trasformare testi", "Sintesi, estrazione, confronto", "Ricerca e conoscenza interrogabile"], { space: 5 }), { x: 5.4, y: 2.85, w: 3.9, h: 1.2, fontSize: 12, color: C.background1 });
    txt(s, "Poi il Tema 9: AI per dati e analisi", { x: 5.4, y: 4.3, w: 3.9, h: 0.35, fontSize: 12, italic: true, color: C.accent3 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Riferimenti verificati il 16 ottobre 2026: Reber e Schwarz, volume 8, numero 3, pagine 338-342, confermati; Parasuraman e Manzey, volume 52, numero 3, pagine 381-410, confermati; Sharma e colleghi, pubblicato negli atti di ICLR 2024, confermato. Il caso Avianca e lo studio di Sharma sono già presentati nel Tema 3, qui richiamati. Il modulo si basa soprattutto su principi consolidati di pensiero critico, analisi delle fonti e lettura dei dati. Tutti gli esempi del modulo, compresi i tre esempi pratici del 7.6, sono illustrativi: non riportano dati reali né esiti di verifiche effettivamente eseguite. Prima di ogni edizione conviene verificare se ci sono studi recenti sull'efficacia della revisione assistita dall'AI, un campo in rapida evoluzione, e quali funzioni di analisi dati ed esecuzione del codice offrono gli strumenti in uso.");
    const src = [
      "Reber, R., Schwarz, N. (1999). Effects of Perceptual Fluency on Judgments of Truth. Consciousness and Cognition, 8(3), 338-342.",
      "Parasuraman, R., Manzey, D. H. (2010). Complacency and Bias in Human Use of Automation: An Attentional Integration. Human Factors, 52(3), 381-410.",
      "Mata v. Avianca, Inc., U.S. District Court, Southern District of New York, giugno 2023.",
      "Sharma, M. et al. (2024). Towards Understanding Sycophancy in Language Models. ICLR 2024.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.0, fontSize: 13, color: C.text1 });
    txt(s, "Esempi del modulo illustrativi. Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.45, w: 8.2, h: 0.4, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema7_Verifica_output_pensiero_critico_REV.pptx" });
  await applyTheme("Tema7_Verifica_output_pensiero_critico_REV.pptx", THEME);
  console.log("done");
})();
