const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 7: Verifica degli output e pensiero critico";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 7  ·  Verifica degli output e pensiero critico";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }


  function flowTag(s, active) {
    const st = ["Valutare", "Verificare", "Decidere"];
    st.forEach((t, i) => {
      const x = 7.0 + i * 0.85;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "fase " + t });
      txt(s, t, { x, y: 0.42, w: 0.8, h: 0.26, fontSize: 9, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 7", { placeholder: "kicker" });
    s.addText("Verifica degli output e pensiero critico nell'utilizzo dell'AI", { placeholder: "title" });
    s.addText("Area: Interagire con l'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al settimo tema, che completa l'area 'Interagire con l'AI'. Nel Tema 5 abbiamo visto il dialogo e la collaborazione con l'AI, nel Tema 6 come formulare richieste efficaci. Più volte abbiamo rimandato a questo tema una fase essenziale: la verifica. Un buon prompt migliora l'aderenza alla richiesta, ma non garantisce la correttezza. Qui sviluppiamo i metodi pratici per valutare criticamente un output, verificare informazioni, fonti, ragionamenti e numeri, usare l'AI come supporto alla revisione senza confondere autoverifica e verifica indipendente, riconoscere i nostri bias e, infine, decidere se un risultato è adeguato all'uso previsto. Non ripetiamo la teoria degli errori del Tema 3: qui ci concentriamo su come riconoscerli e gestirli. Suggerimento per l'apertura: mostrare ai partecipanti un breve testo prodotto dall'AI, ben scritto e con un errore non evidente, e chiedere se lo userebbero così com'è. La discussione introduce bene tutto il modulo. Nota per il relatore: i contenuti e le fonti sono stati verificati a ottobre 2026; il modulo si basa su principi stabili, ma gli studi sull'efficacia della revisione assistita dall'AI sono in rapida evoluzione e vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la capacità di valutare criticamente gli output dei sistemi AI, verificare informazioni e ragionamenti, riconoscere errori e omissioni e stabilire se i risultati sono sufficientemente affidabili per un utilizzo specifico. La consapevolezza da sviluppare parte da un principio ormai familiare: la qualità apparente di una risposta non ne garantisce la correttezza. Bisogna distinguere quattro aspetti: plausibilità, accuratezza, completezza e adeguatezza allo scopo, applicando controlli proporzionati alle conseguenze degli errori. E il fine, come nel Tema 3, non è la sfiducia indiscriminata, ma una fiducia calibrata sulle evidenze. Il messaggio centrale del tema: usare consapevolmente l'AI significa distinguere risultati convincenti da risultati verificati, e stabilire, sulla base di evidenze e controlli proporzionati, se gli output sono adeguati allo scopo.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Valutare criticamente gli output", "Verificare informazioni, fonti, ragionamenti, numeri", "Riconoscere errori e omissioni", "Decidere se un risultato è adeguato all'uso"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "La qualità apparente non garantisce la correttezza.\n\nDistinguere plausibilità, accuratezza, completezza e adeguatezza allo scopo, con controlli proporzionati.\n\nNon sfiducia, ma fiducia calibrata sulle evidenze." });
  }
  {
    const s = content("Undici domande guida per questo modulo", "Le undici domande guida accompagnano il modulo. Le prime tre riguardano la valutazione della qualità di un output: distinguere convincente e corretto, riconoscere pertinenza e completezza, individuare ciò che manca. La quarta e la quinta riguardano la verifica di fonti e ragionamenti. La sesta i dati e i calcoli. La settima la differenza tra chiedere all'AI di verificarsi e verificare in modo indipendente. L'ottava i bias cognitivi di chi valuta. Le ultime tre riguardano la decisione: distinguere fatti, probabilità e incertezze, scegliere il livello di verifica adeguato al rischio, sapere quando coinvolgere un esperto o rinunciare all'output. Alla fine del modulo torneremo su tutte con una risposta sintetica.");
    qGrid(s, ["Come distinguo una risposta convincente da una corretta?", "Che cosa rende un output pertinente, completo, utilizzabile?", "Come individuo ciò che manca in una risposta esaustiva?", "Come verifico che una fonte sostenga davvero un'affermazione?", "Come identifico premesse, ipotesi e conclusioni non giustificate?", "Come controllo dati, formule e grafici generati dall'AI?", "Che differenza c'è tra autoverifica dell'AI e verifica indipendente?", "Quali bias mi fanno fidare troppo, o troppo poco?", "Come distinguo fatti, probabilità, ipotesi, incertezze?", "Quale livello di verifica è adeguato al rischio?", "Quando coinvolgere un esperto o non usare l'output?"], 4, 1.15, 1.08, 11);
  }
  {
    const s = content("Il filo conduttore: valutare, verificare, decidere", "Il documento di perimetro indica un filo conduttore per tutto il modulo: la sequenza valutare, verificare, decidere. Valutare significa esaminare criticamente l'output: è pertinente, completo, coerente, chiaro? Quali affermazioni contiene, quali ragionamenti, quali numeri? Che cosa manca? A questa fase corrispondono i sottotemi 7.1, 7.2 e 7.4. Verificare significa controllare, con evidenze indipendenti, gli elementi che lo richiedono: fonti, fatti, dati, calcoli. Corrispondono i sottotemi 7.3, 7.5 e 7.6. Decidere significa stabilire se l'output, con le verifiche fatte e le incertezze che restano, è adeguato all'uso previsto, e quindi accettarlo, modificarlo, approfondirlo o rifiutarlo. Corrisponde il sottotema 7.8. Il sottotema 7.7, sui bias cognitivi, attraversa tutte e tre le fasi, perché riguarda l'atteggiamento di chi valuta. Una precisazione importante: non è una procedura obbligatoria e identica per ogni attività. Per una bozza interna le tre fasi si riducono a una rilettura attenta; per un documento destinato a un cliente o a una decisione importante diventano un processo strutturato. Nelle slide, un piccolo indicatore in alto a destra ricorda in quale fase ci troviamo.");
    const st = [["FiEye", "Valutare", "Esaminare criticamente l'output: pertinenza, completezza, coerenza, che cosa manca", "7.1  7.2  7.4"], ["FiSearch", "Verificare", "Controllare con evidenze indipendenti fonti, fatti, dati, calcoli", "7.3  7.5  7.6"], ["FiCheckCircle", "Decidere", "Stabilire se l'output è adeguato all'uso: accettare, modificare, approfondire, rifiutare", "7.8"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.75, i === 2 ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 1.08, 1.35, 0.7, st[i][0], i === 2 ? C.background1 : C.accent1, i === 2 ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.15, y: 2.15, w: 2.56, h: 0.45, fontSize: 19, bold: true, color: i === 2 ? C.background1 : C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.2, y: 2.65, w: 2.46, h: 0.85, fontSize: 12, color: i === 2 ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.2, y: 3.5, w: 2.46, h: 0.35, fontSize: 12, bold: true, color: i === 2 ? C.accent6 : C.accent1, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.4, 0.17);
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.accent6, "bias trasversali");
    txt(s, [{ text: "7.7 Bias cognitivi: ", options: { bold: true, color: C.accent1 } }, { text: "attraversano tutte le fasi. La sequenza non è una procedura obbligatoria: la sua intensità dipende dall'attività.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti con priorità alta e tutti mantenuti distinti. Vanno compresi e applicati: la valutazione della qualità, la verifica delle fonti, il controllo dei ragionamenti, l'identificazione delle omissioni e la validazione proporzionata al rischio. Vanno conosciuti e sperimentati: le tecniche di revisione assistita dall'AI, il confronto tra modelli, la verifica quantitativa, il riconoscimento dei bias cognitivi e la gestione dell'incertezza. Vanno solo accennati: metriche statistiche avanzate, validazione formale dei sistemi, modelli quantitativi di rischio, audit specialistici e valutazioni su larga scala. Confini: non ripetiamo i meccanismi del Tema 2, né la teoria di allucinazioni e bias del Tema 3, né le dinamiche di collaborazione e delega cognitiva del Tema 5, né i metodi di formulazione del Tema 6, salvo le richieste usate come supporto al controllo. Non sviluppiamo ROI né obblighi giuridici, trattati nei Temi 12 e 18: la responsabilità è trattata come consapevolezza operativa.");
    pathSlide(s, [["7.1", "Il pensiero critico nell'interazione con l'AI", "Alta"], ["7.2", "Valutare la qualità di un output", "Alta"], ["7.3", "Verifica delle informazioni e delle fonti", "Alta"], ["7.4", "Valutazione dei ragionamenti", "Alta"], ["7.5", "Verifica di dati e calcoli", "Alta"], ["7.6", "Verifica e revisione assistite dall'AI", "Alta"], ["7.7", "Bias cognitivi e fiducia nell'AI", "Alta"], ["7.8", "Validazione e responsabilità", "Alta"]],
      [["Comprendere e applicare", "Qualità, fonti, ragionamenti, omissioni, validazione proporzionata al rischio", C.accent1, C.background1], ["Conoscere e sperimentare", "Revisione assistita dall'AI, confronto tra modelli, verifica quantitativa, bias, incertezza", C.accent6, C.text1], ["Solo accennare", "Metriche avanzate, validazione formale, modelli di rischio, audit specialistici", C.background2, C.text1]]);
  }

  // =====================================================================
  section("7.1 Pensiero critico");
  divider("7.1", "Il pensiero critico nell'interazione con l'AI", "Valutare informazioni e conclusioni alla luce delle evidenze, senza accettarle o respingerle automaticamente", "Iniziamo dal metodo, da comprendere bene. Il pensiero critico non è una tecnica specifica per l'AI: è un modo di ragionare che vale per qualsiasi informazione, da un articolo di giornale a una presentazione di un fornitore. Con l'AI diventa però particolarmente importante, perché riceviamo grandi quantità di testo ben scritto, rapidamente, su qualsiasi argomento. Vediamo che cosa significa pensare criticamente, quali distinzioni e domande lo rendono concreto, e perché non coincide con la sfiducia.");
  {
    const s = content("Che cos'è il pensiero critico", "Possiamo definire il pensiero critico come la capacità di valutare informazioni, argomenti e conclusioni in modo ragionato, sulla base delle evidenze, prima di accettarli o respingerli. Non esiste un'unica definizione accademica, ma i diversi approcci condividono alcuni principi, raccolti in slide. Chiedersi su che cosa si basa un'affermazione: quali evidenze la sostengono. Distinguere ciò che è stabilito da ciò che è supposto. Considerare spiegazioni e punti di vista alternativi. Riconoscere i limiti delle informazioni disponibili e della propria conoscenza. Essere disposti a cambiare idea di fronte a nuove evidenze. Sospendere il giudizio quando le evidenze non sono sufficienti. Applicato all'AI, il pensiero critico significa trattare ogni output non come una risposta da usare, ma come una proposta da valutare. Un'immagine utile: leggere un output dell'AI come leggeremmo il lavoro di un collega nuovo e molto capace, di cui non conosciamo ancora l'affidabilità in quel campo. Non lo scartiamo, non lo accettiamo a scatola chiusa: lo esaminiamo.");
    shapeBox(s, 0.5, 1.2, 4.0, 3.75, C.text1, "definizione pensiero critico");
    txt(s, "PENSIERO CRITICO", { x: 0.75, y: 1.38, w: 3.5, h: 0.3, fontSize: 11, bold: true, color: C.accent1, charSpacing: 3 });
    txt(s, "Valutare informazioni, argomenti e conclusioni in modo ragionato, sulla base delle evidenze, prima di accettarli o respingerli.", { x: 0.75, y: 1.8, w: 3.5, h: 1.7, fontSize: 15, color: C.background1 });
    txt(s, "Un output dell'AI non è una risposta da usare, ma una proposta da valutare.", { x: 0.75, y: 3.7, w: 3.5, h: 1.0, fontSize: 13, italic: true, color: C.accent3 });
    txt(s, "Principi condivisi", { x: 4.8, y: 1.2, w: 4.7, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    rowList(s, ["Su che cosa si basa questa affermazione?", "Distinguere ciò che è stabilito da ciò che è supposto", "Considerare spiegazioni alternative", "Riconoscere i limiti delle informazioni e propri", "Cambiare idea di fronte a nuove evidenze", "Sospendere il giudizio se le evidenze non bastano"], { x: 4.8, w: 4.7, y: 1.62, h: 0.48, fontSize: 12 });
  }
  {
    const s = content("Ricevere informazioni o valutarle", "La prima distinzione del sottotema riguarda il modo in cui ci poniamo di fronte a un output. Ricevere informazioni significa leggerle e usarle, accettandole come date. È il modo naturale in cui ci rapportiamo a fonti di cui ci fidiamo, e il rischio con l'AI è proprio questo: la fluidità e la rapidità delle risposte ci spingono a trattarle come fonti affidabili. Valutare informazioni significa invece interrogarle: chiedersi se sono corrette, complete, pertinenti, e su che cosa si basano. Richiede più tempo e più attenzione, ma trasforma l'output da prodotto finito in materiale di lavoro. Lo schema in slide mette a confronto i due atteggiamenti. Una precisazione: valutare non significa necessariamente controllare tutto. Spesso basta una lettura attenta, con alcune domande, per capire se un output è utilizzabile, se richiede verifiche su punti specifici o se va scartato. Il livello di approfondimento, come vedremo nel 7.8, dipende dalle conseguenze dell'uso. Ma la postura valutativa, cioè l'abitudine di interrogare invece di ricevere, dovrebbe essere sempre presente.");
    flowTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.8, { icon: "FiInbox", head: "Ricevere", headSize: 16, bodySize: 13,
      body: bullets(["Leggere e usare", "Accettare come dato", "L'output è un prodotto finito", "Rapido, ma esposto agli errori"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.8, { icon: "FiEye", head: "Valutare", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Interrogare l'informazione", "È corretta, completa, pertinente?", "L'output è materiale di lavoro", "Più attenzione, risultati affidabili"], { space: 4 }) });
    banner(s, 4.2, "Valutare non significa controllare tutto: significa interrogare invece di ricevere.", { h: 0.75 });
  }
  {
    const s = content("Fatti, opinioni, ipotesi, interpretazioni", "Una distinzione fondamentale per valutare un testo è quella tra quattro tipi di affermazioni, che negli output dell'AI sono spesso mescolati senza segnalazione. I fatti sono affermazioni verificabili, che si possono confermare o smentire con evidenze: 'il fatturato del 2025 è stato di 12 milioni'. Le opinioni sono valutazioni o preferenze, che non si possono dimostrare vere o false: 'è un risultato eccellente'. Le ipotesi sono affermazioni plausibili ma non ancora confermate: 'la crescita potrebbe essere dovuta al nuovo listino'. Le interpretazioni sono letture dei fatti, che li collegano e attribuiscono loro un significato: 'la crescita dimostra che la strategia funziona'. In un output dell'AI questi tipi sono presentati con lo stesso tono assertivo, e un'ipotesi può sembrare un fatto, un'interpretazione può sembrare una conclusione obbligata. Distinguerli serve a capire che cosa verificare, cioè i fatti, che cosa valutare con giudizio, cioè le interpretazioni e le opinioni, e che cosa trattare come incerto, cioè le ipotesi. Un esercizio utile: prendere un paragrafo prodotto dall'AI ed etichettare ogni frase con uno dei quattro tipi.");
    flowTag(s, 0);
    const t = [["Fatto", "Verificabile con evidenze", "\"Il fatturato 2025 è stato di 12 milioni.\"", "Da verificare"], ["Opinione", "Valutazione o preferenza", "\"È un risultato eccellente.\"", "Da valutare con giudizio"], ["Ipotesi", "Plausibile, non confermata", "\"La crescita potrebbe dipendere dal nuovo listino.\"", "Da trattare come incerta"], ["Interpretazione", "Lettura che dà significato ai fatti", "\"La crescita dimostra che la strategia funziona.\"", "Da valutare: ci sono alternative?"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 3.2, i === 0 ? C.accent6 : C.background2, t[i][0]);
      txt(s, t[i][0], { x: x + 0.15, y: 1.3, w: 1.85, h: 0.4, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, t[i][1], { x: x + 0.15, y: 1.72, w: 1.85, h: 0.5, fontSize: 12, bold: true, color: C.text1 });
      txt(s, t[i][2], { x: x + 0.15, y: 2.3, w: 1.85, h: 1.25, fontSize: 12, italic: true, color: C.text2 });
      txt(s, t[i][3], { x: x + 0.15, y: 3.65, w: 1.85, h: 0.65, fontSize: 11, bold: true, color: C.accent5 });
    }
    txt(s, "Negli output dell'AI sono presentati con lo stesso tono assertivo.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Le domande critiche", "Il pensiero critico diventa concreto attraverso le domande. Ecco una serie di domande critiche da porre a un output, raggruppate in tre famiglie. Sulle affermazioni: che cosa sostiene esattamente? È un fatto, un'opinione, un'ipotesi o un'interpretazione? È verificabile? Sulle evidenze: su che cosa si basa? Ci sono fonti, dati, esempi? Sono pertinenti e sufficienti? Che cosa servirebbe per confermarla o smentirla? Sulle conclusioni: deriva davvero dalle premesse? Ci sono spiegazioni alternative? Che cosa manca? Che cosa succederebbe se fosse sbagliata? Non serve porsele tutte ogni volta: con la pratica diventano un'abitudine, e si impara a scegliere quelle più utili per il tipo di output. Queste domande si possono rivolgere anche all'AI, chiedendole di esplicitare evidenze e alternative, come vedremo nel 7.6; ma la risposta del sistema va a sua volta valutata. Suggerimento: distribuire le domande come scheda di riferimento.");
    flowTag(s, 0);
    const f = [["FiMessageSquare", "Sulle affermazioni", ["Che cosa sostiene esattamente?", "Fatto, opinione, ipotesi, interpretazione?", "È verificabile?"]], ["FiDatabase", "Sulle evidenze", ["Su che cosa si basa?", "Fonti e dati pertinenti e sufficienti?", "Che cosa la confermerebbe o smentirebbe?"]], ["FiGitBranch", "Sulle conclusioni", ["Deriva davvero dalle premesse?", "Ci sono alternative? Che cosa manca?", "Che cosa succede se è sbagliata?"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.1, { icon: f[i][0], head: f[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: bullets(f[i][2], { space: 5 }) });
    txt(s, "Non tutte ogni volta: con la pratica diventano un'abitudine.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Evidenze, giudizio e competenze", "Tre elementi completano il metodo. L'analisi delle affermazioni e delle evidenze: per ogni affermazione importante, chiedersi quali evidenze la sostengono e quanto sono solide. Un'affermazione senza evidenze non è necessariamente falsa, ma va trattata come non dimostrata. La valutazione autonoma delle conclusioni: formarsi un giudizio proprio, invece di adottare quello proposto dal sistema. Una pratica utile, già vista nel Tema 5, è pensare alla questione prima di leggere la risposta, così da avere un termine di confronto: se la conclusione dell'AI è diversa dalla nostra, vale la pena capire perché. Il ruolo delle competenze professionali: il pensiero critico ha bisogno di conoscenze. Domande come 'è plausibile?', 'manca qualcosa?', 'questa conclusione è sensata?' si possono porre bene solo conoscendo l'argomento. Chi conosce il dominio riconosce un dato anomalo, una regola applicata male, un'eccezione dimenticata. Per questo, quando l'output riguarda un ambito che non conosciamo, il pensiero critico ci porta a una conclusione precisa: serve il parere di chi lo conosce, come vedremo nel 7.8.");
    flowTag(s, 0);
    const e = [["FiDatabase", "Affermazioni ed evidenze", "Senza evidenze un'affermazione non è falsa, ma non è dimostrata."], ["FiUser", "Giudizio autonomo", "Pensare prima di leggere: se la conclusione dell'AI è diversa dalla nostra, capire perché."], ["FiAward", "Competenze professionali", "Il pensiero critico ha bisogno di conoscenze: fuori dal proprio campo, serve un esperto."]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.75, { icon: e[i][0], head: e[i][1], headSize: 15, bodySize: 13, fill: i === 2 ? C.accent6 : C.background2, body: e[i][2] });
  }
  {
    const s = content("Atteggiamento critico, non sfiducia", "L'ultima distinzione del sottotema è forse la più importante: atteggiamento critico e sfiducia indiscriminata non sono la stessa cosa. La sfiducia indiscriminata respinge gli output dell'AI in blocco, 'perché l'AI sbaglia'. È comoda, perché esonera dal lavoro di valutazione, ma è altrettanto acritica della fiducia cieca: in entrambi i casi la decisione non dipende dalle evidenze, ma da un atteggiamento preso in anticipo. L'atteggiamento critico, invece, valuta caso per caso: accetta ciò che regge all'esame, verifica ciò che lo richiede, scarta ciò che non regge. Può portare ad accettare un output senza modifiche, se è valido, così come a rifiutarlo. Lo schema riprende la scala della fiducia vista nel Tema 3: fiducia cieca, atteggiamento critico, sfiducia indiscriminata. Gli estremi hanno in comune il fatto di non guardare le evidenze. Il concetto chiave del sottotema lo dice con precisione: pensare criticamente significa valutare informazioni e conclusioni alla luce delle evidenze, senza accettarle o respingerle automaticamente.");
    flowTag(s, 0);
    const z = [["Fiducia cieca", "Accetta tutto, senza esame", C.background2, C.text1], ["Atteggiamento critico", "Valuta caso per caso sulle evidenze: accetta, verifica o scarta", C.accent1, C.background1], ["Sfiducia indiscriminata", "Respinge tutto, \"perché l'AI sbaglia\"", C.background2, C.text1]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.3, 2.86, 2.2, z[i][2], z[i][0]);
      txt(s, z[i][0], { x: x + 0.15, y: 1.5, w: 2.56, h: 0.5, fontSize: 17, bold: true, color: z[i][3], align: "center" });
      txt(s, z[i][1], { x: x + 0.2, y: 2.1, w: 2.46, h: 1.2, fontSize: 13, color: z[i][3], align: "center" });
    }
    banner(s, 3.75, "Gli estremi hanno in comune una cosa: non guardano le evidenze.", { h: 0.6 });
    txt(s, "L'atteggiamento critico può portare ad accettare un output senza modifiche, se è valido.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Pensare criticamente significa valutare informazioni e conclusioni alla luce delle evidenze, senza accettarle o respingerle automaticamente.", "Sottotema 7.1  ·  Il pensiero critico nell'interazione con l'AI", "Concetto chiave. Il pensiero critico trasforma l'output da risposta da usare a proposta da valutare. Si basa su alcune distinzioni, come quella tra fatti, opinioni, ipotesi e interpretazioni, e su domande critiche su affermazioni, evidenze e conclusioni. Richiede giudizio autonomo e competenze. E non è sfiducia: è valutazione caso per caso sulle evidenze. Esercizio suggerito: dare ai partecipanti un paragrafo prodotto dall'AI e chiedere di etichettare ogni frase come fatto, opinione, ipotesi o interpretazione, poi di indicare quali andrebbero verificate.");

  // =====================================================================
  section("7.2 Qualità di un output");
  divider("7.2", "Valutare la qualità di un output", "Una risposta professionale nella forma può essere errata, incompleta o inadatta allo scopo", "Passiamo dalla postura al metodo concreto di valutazione. In questo sottotema, da comprendere e applicare, vediamo le dimensioni della qualità di un output, la differenza tra qualità espressiva e sostanziale, e due integrazioni importanti: come riconoscere le informazioni mancanti e le omissioni, e come distinguere livelli diversi di certezza nei contenuti. Il 7.2 valuta la qualità del contenuto; nel 7.8 valuteremo la sua utilizzabilità in un contesto concreto.");
  {
    const s = content("Le dimensioni della qualità", "La qualità di un output si può valutare su più dimensioni, che il documento di perimetro elenca. Accuratezza: le informazioni sono corrette? Pertinenza: il risultato risponde all'obiettivo, o a una domanda diversa? Completezza: copre tutto ciò che serve? Coerenza interna: le parti sono coerenti tra loro, senza contraddizioni? Chiarezza e comprensibilità: il destinatario lo capirà senza ambiguità? Distinzione tra dati e supposizioni: è chiaro che cosa deriva da informazioni certe e che cosa è supposto? Queste dimensioni sono indipendenti: un output può essere accurato ma non pertinente, perché risponde con informazioni corrette a una domanda diversa; pertinente ma incompleto; completo ma incoerente; chiaro ma inaccurato. Per questo conviene valutarle separatamente, almeno per gli output importanti. Le dimensioni si collegano a quelle viste nel Tema 3 parlando di affidabilità, ma qui le usiamo come lista di controllo sul singolo output, non come proprietà del sistema.");
    flowTag(s, 0);
    const d = [["FiTarget", "Accuratezza", "Le informazioni sono corrette?"], ["FiCrosshair", "Pertinenza", "Risponde all'obiettivo o a un'altra domanda?"], ["FiCheckSquare", "Completezza", "Copre tutto ciò che serve?"], ["FiGitMerge", "Coerenza interna", "Nessuna contraddizione tra le parti?"], ["FiEye", "Chiarezza", "Il destinatario lo capirà senza ambiguità?"], ["FiColumns", "Dati e supposizioni", "È chiaro che cosa è certo e che cosa supposto?"]];
    await iconGrid(s, d.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 2.95, headSize: 14, bodySize: 12 });
    banner(s, 4.35, "Dimensioni indipendenti: accurato ma non pertinente, pertinente ma incompleto, chiaro ma inaccurato.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Qualità espressiva e qualità sostanziale", "Una distinzione che attraversa tutto il modulo: quella tra qualità espressiva e qualità sostanziale. La qualità espressiva riguarda la forma: scrittura scorrevole, lessico appropriato, struttura ordinata, impaginazione professionale, tono sicuro. La qualità sostanziale riguarda il contenuto: correttezza, completezza, pertinenza, solidità del ragionamento. Gli output dei sistemi generativi hanno quasi sempre un'alta qualità espressiva, mentre la qualità sostanziale varia. Il problema, già visto nel Tema 3 come autorevolezza apparente, è che tendiamo a giudicare la sostanza dalla forma: un testo ben scritto ci sembra anche più vero. Per contrastare questa tendenza, conviene separare deliberatamente i due giudizi: prima chiedersi se il contenuto è corretto, completo e pertinente, ignorando la forma; solo dopo valutare se la forma è adeguata. Un esercizio istruttivo: riscrivere mentalmente l'output in forma di appunti disordinati, e chiedersi se ci convincerebbe ancora. Il concetto chiave del sottotema lo riassume: una risposta professionale nella forma può essere errata, incompleta o inadatta allo scopo.");
    flowTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiType", head: "Qualità espressiva", headSize: 16, bodySize: 13,
      body: [{ text: "La forma: ", options: { bold: true, color: C.text1 } }, { text: "scorrevolezza, lessico, struttura, impaginazione, tono sicuro.", options: { breakLine: true, paraSpaceAfter: 8 } }, { text: "Quasi sempre alta.", options: { bold: true, color: C.accent2 } }] });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiCheckCircle", head: "Qualità sostanziale", headSize: 16, bodySize: 13, fill: C.accent6,
      body: [{ text: "Il contenuto: ", options: { bold: true, color: C.text1 } }, { text: "correttezza, completezza, pertinenza, solidità del ragionamento.", options: { breakLine: true, paraSpaceAfter: 8 } }, { text: "Variabile.", options: { bold: true, color: C.accent5 } }] });
    banner(s, 3.9, "Prima giudicare la sostanza ignorando la forma. Esercizio: se fossero appunti disordinati, ci convincerebbe ancora?", { h: 1.05, fontSize: 13 });
  }
  {
    const s = content("Informazioni mancanti e omissioni", "Questa integrazione del sottotema affronta un errore particolarmente insidioso: l'omissione. Un output può contenere solo affermazioni corrette ed essere comunque inadeguato, perché tace informazioni decisive. Le omissioni sono difficili da individuare proprio perché non si vedono: valutiamo ciò che c'è scritto, non ciò che manca. Alcuni esempi tipici. Un riassunto di un contratto che riporta correttamente durata, prezzo e servizi, ma omette la clausola di rinnovo automatico. Una risposta su una procedura che descrive il caso generale ma non le eccezioni. Un confronto tra fornitori che considera prezzo e qualità ma non i tempi di consegna. Un'analisi che presenta i vantaggi di una scelta ma non i rischi. In ciascun caso, ogni frase è vera, ma il quadro complessivo è fuorviante. Le omissioni sono più probabili quando il materiale è lungo, quando la richiesta non indicava che cosa includere, quando il caso ha eccezioni o condizioni particolari. Il loro effetto è sottile: non producono un errore evidente, ma una decisione presa su un quadro incompleto.");
    flowTag(s, 0);
    const ex = [["Riassunto di contratto", "Durata, prezzo, servizi corretti", "Manca la clausola di rinnovo automatico"], ["Risposta su una procedura", "Caso generale corretto", "Mancano le eccezioni"], ["Confronto tra fornitori", "Prezzo e qualità corretti", "Mancano i tempi di consegna"], ["Analisi di una scelta", "Vantaggi corretti", "Mancano i rischi"]];
    txt(s, "Ciò che c'è", { x: 3.2, y: 1.15, w: 2.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
    txt(s, "Ciò che manca", { x: 6.3, y: 1.15, w: 3.2, h: 0.3, fontSize: 12, bold: true, color: C.accent5 });
    ex.forEach((e, i) => {
      const y = 1.5 + i * 0.66;
      shapeBox(s, 0.5, y, 9.0, 0.58, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.65, y, w: 2.5, h: 0.58, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[1], { x: 3.2, y, w: 3.0, h: 0.58, fontSize: 12, color: C.text2, valign: "middle" });
      txt(s, e[2], { x: 6.3, y, w: 3.1, h: 0.58, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
    });
    banner(s, 4.3, "Ogni frase è vera, ma il quadro è fuorviante: le omissioni non si vedono, perché valutiamo ciò che c'è scritto.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Come cercare ciò che manca", "Come si individua ciò che non c'è? Alcune tecniche pratiche. Partire dalle attese: prima di leggere l'output, chiedersi che cosa dovrebbe contenere, magari annotando i punti; poi confrontare. È la tecnica più efficace, perché rende visibile l'assenza. Usare la richiesta originale come lista di controllo: ogni elemento richiesto è presente? Cercare le eccezioni e le condizioni: in quali casi questa affermazione non vale? Ci sono limiti, soglie, condizioni particolari? Cercare l'altra metà: se l'output presenta i vantaggi, dove sono gli svantaggi? Se presenta un punto di vista, dov'è l'altro? Confrontare con la fonte: per sintesi e analisi di documenti, scorrere l'indice o i titoli del documento originale e verificare che le parti importanti siano rappresentate. Chiedere all'AI che cosa manca: 'quali aspetti importanti non hai considerato?', 'in quali casi questa risposta non vale?'. È utile, ma, come vedremo nel 7.6, è un supporto e non una garanzia. Il documento di perimetro precisa la distinzione con il 7.4: qui ci interessa la completezza dell'output; nel 7.4 vedremo le omissioni che incidono sulle premesse dei ragionamenti.");
    flowTag(s, 0);
    const t = [["FiList", "Partire dalle attese", "Annotare prima che cosa dovrebbe esserci, poi confrontare"], ["FiCheckSquare", "Usare la richiesta originale", "Ogni elemento richiesto è presente?"], ["FiAlertCircle", "Cercare eccezioni e condizioni", "In quali casi non vale?"], ["FiColumns", "Cercare l'altra metà", "Vantaggi e svantaggi, un punto di vista e l'altro"], ["FiBookOpen", "Confrontare con la fonte", "Le parti importanti sono rappresentate?"], ["FiHelpCircle", "Chiedere all'AI che cosa manca", "Utile, ma non è una garanzia"]];
    await iconGrid(s, t.map((e, i) => ({ icon: e[0], head: e[1], body: e[2], fill: i === 0 ? C.accent6 : C.background2 })), 3, { y: 1.2, H: 3.75, headSize: 13, bodySize: 12 });
  }
  {
    const s = content("Incertezza e livello di fiducia", "Questa integrazione, che ritroveremo nel 7.8, propone di classificare i contenuti di un output secondo il loro grado di certezza. Possiamo distinguere quattro livelli. Fatti confermati: verificati su fonti affidabili o noti con certezza. Affermazioni probabili: plausibili e coerenti con ciò che sappiamo, ma non verificate. Ipotesi: possibili, da considerare, ma senza evidenze sufficienti. Contenuti non verificati: affermazioni di cui non conosciamo l'affidabilità, che non abbiamo controllato e che il sistema potrebbe aver generato senza base. Un output dell'AI mescola normalmente tutti e quattro i livelli, e li presenta con lo stesso tono sicuro. Il punto da sottolineare è che il tono della risposta non misura la sua correttezza: un sistema può affermare con sicurezza qualcosa di inventato, e formulare con cautela qualcosa di corretto. Il livello di fiducia va quindi attribuito da chi valuta, sulla base delle evidenze, non dedotto dal modo in cui il testo è scritto. Si può anche chiedere al sistema di indicare il grado di certezza di ciascuna affermazione, come visto nel Tema 6: è un'indicazione utile, ma anche questa va presa con cautela.");
    flowTag(s, 0);
    const lv = [["Fatti confermati", "Verificati su fonti affidabili", C.accent1, C.background1], ["Affermazioni probabili", "Plausibili e coerenti, non verificate", C.accent6, C.text1], ["Ipotesi", "Possibili, senza evidenze sufficienti", C.background2, C.text1], ["Non verificati", "Affidabilità sconosciuta, forse senza base", C.background1, C.text1]];
    lv.forEach((l, i) => {
      const y = 1.2 + i * 0.7;
      const w = 4.6 - i * 0.25;
      shapeBox(s, 0.5, y, w, 0.6, l[2], l[0], i === 3 ? { color: C.accent3, width: 1, dashType: "dash" } : undefined);
      txt(s, l[0], { x: 0.65, y, w: 1.85, h: 0.6, fontSize: 13, bold: true, color: l[3], valign: "middle" });
      txt(s, l[1], { x: 2.55, y, w: w - 2.15, h: 0.6, fontSize: 11, color: l[3], valign: "middle" });
    });
    txt(s, "Livello di certezza decrescente", { x: 0.5, y: 4.0, w: 4.6, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
    shapeBox(s, 5.4, 1.2, 4.1, 3.05, C.text1, "tono");
    txt(s, "Il tono sicuro non misura la correttezza", { x: 5.6, y: 1.35, w: 3.7, h: 0.75, fontSize: 16, bold: true, color: C.background1 });
    txt(s, "Il sistema può affermare con sicurezza qualcosa di inventato e con cautela qualcosa di corretto. Il livello di fiducia lo attribuisce chi valuta, sulle evidenze.", { x: 5.6, y: 2.15, w: 3.7, h: 1.9, fontSize: 13, color: C.accent3 });
    txt(s, "Si può chiedere al sistema il grado di certezza: indicazione utile, da prendere con cautela.", { x: 0.5, y: 4.45, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Contenuti verificati e non verificati", "Un'abitudine pratica che deriva dall'integrazione precedente: distinguere esplicitamente, nell'output che si sta preparando, i contenuti verificati da quelli non verificati. Quando si lavora su un documento con l'aiuto dell'AI, è facile perdere traccia di quali informazioni sono state controllate e quali no, soprattutto dopo diverse iterazioni. Alcuni modi semplici per mantenere questa distinzione. Evidenziare o annotare, durante la revisione, le affermazioni ancora da verificare, e togliere il segno dopo il controllo. Chiedere al sistema di contrassegnare le affermazioni che non derivano dai documenti forniti, come visto nel Tema 6. Mantenere un elenco dei punti verificati e delle fonti usate, che servirà anche per la documentazione del 7.8. Non far circolare un documento con contenuti non verificati senza segnalarlo: se una bozza deve essere condivisa prima del controllo completo, indicarlo chiaramente. Il beneficio è duplice: si evita che contenuti non verificati passino inosservati nella versione finale, e si concentra l'impegno di verifica dove serve. Sono accorgimenti semplici, ma nella pratica fanno una grande differenza.");
    flowTag(s, 0);
    numList(s, ["Evidenziare le affermazioni da verificare e togliere il segno dopo il controllo", "Chiedere al sistema di contrassegnare ciò che non deriva dai documenti forniti", "Tenere un elenco dei punti verificati e delle fonti usate", "Segnalare chiaramente quando una bozza contiene contenuti non ancora verificati"], { y: 1.2, h: 0.62, fontSize: 13 });
    banner(s, 4.0, "Così i contenuti non verificati non passano inosservati e l'impegno di verifica si concentra dove serve.", { h: 0.9, fontSize: 13 });
  }
  keySlide("Una risposta professionale nella forma può essere errata, incompleta o inadatta allo scopo.", "Sottotema 7.2  ·  Valutare la qualità di un output", "Concetto chiave. La qualità di un output si valuta su più dimensioni indipendenti: accuratezza, pertinenza, completezza, coerenza, chiarezza, distinzione tra dati e supposizioni. La qualità espressiva non dice nulla su quella sostanziale. Le omissioni si cercano partendo dalle attese, dalle eccezioni e dalla fonte. I contenuti hanno livelli diversi di certezza, che il tono non rivela. E conviene tenere traccia di ciò che è stato verificato. Esercizio suggerito: prima di leggere un riassunto prodotto dall'AI, chiedere ai partecipanti di annotare che cosa dovrebbe contenere; poi confrontare e individuare le omissioni.");

  // =====================================================================
  section("7.3 Informazioni e fonti");
  divider("7.3", "Verifica delle informazioni e delle fonti", "Una citazione non è automaticamente una prova: la fonte deve essere autentica, pertinente e sostenere l'affermazione", "Entriamo nella fase di verifica, con un sottotema da applicare. Nel Tema 3 abbiamo visto perché i sistemi generativi possono inventare fonti e citazioni, e abbiamo introdotto alcune domande di controllo. Qui sviluppiamo il metodo pratico: come scegliere che cosa verificare, quali fonti usare, come controllare che una fonte sostenga davvero un'affermazione, come confrontare fonti indipendenti e come gestire ciò che non si può verificare.");
  {
    const s = content("Che cosa verificare: i punti critici", "Il primo passo della verifica è decidere che cosa verificare. Non tutto in un output richiede controllo, e verificare tutto con la stessa intensità sarebbe impraticabile. Si procede in due passaggi. Primo, individuare le affermazioni verificabili, cioè i fatti, distinguendoli da opinioni e interpretazioni come visto nel 7.1. Secondo, tra queste, identificare i punti che richiedono controllo, secondo tre criteri: l'importanza, cioè quanto l'affermazione pesa sulla decisione o sull'uso del documento; il rischio di errore, cioè quanto è probabile che sia sbagliata, per esempio perché riguarda numeri, date, nomi, norme, eventi recenti o argomenti di nicchia; la visibilità, cioè quanto l'errore sarebbe esposto, per esempio in un documento destinato a un cliente. L'esempio in slide mostra un breve testo con le affermazioni da verificare evidenziate. Si noti che non sono tutte: la frase introduttiva e le valutazioni non sono fatti verificabili. Questo lavoro di selezione è anche il primo passo dell'economia della verifica di cui parleremo nel 7.8.");
    flowTag(s, 1);
    shapeBox(s, 0.5, 1.2, 5.4, 3.75, C.background2, "testo esempio");
    txt(s, "Esempio: testo prodotto dall'AI", { x: 0.7, y: 1.3, w: 5.0, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
    txt(s, [
      { text: "Il lavoro agile è sempre più diffuso nelle aziende italiane. ", options: { color: C.text2 } },
      { text: "Secondo l'Osservatorio X, nel 2025 lo praticavano 3,5 milioni di lavoratori", options: { highlight: "E6F0EF", bold: true, color: C.text1 } },
      { text: ", ", options: { color: C.text2 } },
      { text: "in crescita del 10% rispetto all'anno precedente", options: { highlight: "E6F0EF", bold: true, color: C.text1 } },
      { text: ". ", options: { color: C.text2 } },
      { text: "La normativa di riferimento è la legge 81 del 2017", options: { highlight: "E6F0EF", bold: true, color: C.text1 } },
      { text: ". Si tratta di un'opportunità importante per migliorare il benessere dei dipendenti.", options: { color: C.text2 } },
    ], { x: 0.7, y: 1.7, w: 5.0, h: 2.6, fontSize: 14 });
    txt(s, "In evidenza: affermazioni da verificare. Esempio illustrativo, dati non verificati.", { x: 0.7, y: 4.4, w: 5.0, h: 0.45, fontSize: 10, italic: true, color: C.accent2 });
    txt(s, "Criteri per scegliere", { x: 6.2, y: 1.2, w: 3.3, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const c = [["FiStar", "Importanza", "Quanto pesa sulla decisione"], ["FiAlertTriangle", "Rischio di errore", "Numeri, date, nomi, norme, novità"], ["FiEye", "Visibilità", "Quanto l'errore sarebbe esposto"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.65 + i * 1.05;
      await iconCircle(s, 6.2, y, 0.5, c[i][0]);
      txt(s, c[i][1], { x: 6.85, y: y - 0.03, w: 2.65, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
      txt(s, c[i][2], { x: 6.85, y: y + 0.3, w: 2.65, h: 0.5, fontSize: 11, color: C.text2 });
    }
  }
  {
    const s = content("Fonti primarie e secondarie", "Per verificare un'informazione, conta molto il tipo di fonte. Le fonti primarie sono quelle all'origine dell'informazione: il testo ufficiale di una legge, il bilancio pubblicato da un'azienda, il rapporto originale di un istituto di ricerca, il contratto firmato, i dati del proprio gestionale, il sito ufficiale di un ente. Le fonti secondarie riportano, sintetizzano o commentano informazioni provenienti da altre fonti: articoli di giornale, blog, sintesi, presentazioni, voci enciclopediche, e anche le risposte di un sistema AI. Le fonti secondarie sono utili per orientarsi e per trovare le primarie, ma possono semplificare, interpretare o riportare in modo impreciso. Per le informazioni importanti, la regola è risalire alla fonte primaria. Un esempio: un articolo riporta che una certa norma prevede un obbligo; la verifica corretta consiste nel leggere il testo della norma, non un altro articolo che la commenta. Tenere presente che l'output dell'AI è, al massimo, una fonte secondaria, e spesso nemmeno quella, perché non sappiamo da dove derivi l'informazione.");
    flowTag(s, 1);
    table(s, [["", "Fonti primarie", "Fonti secondarie"], ["Che cosa sono", "All'origine dell'informazione", "Riportano, sintetizzano, commentano"], ["Esempi", "Testo di legge, bilancio ufficiale, rapporto originale, contratto, dati del gestionale", "Articoli, blog, sintesi, presentazioni, enciclopedie, risposte dell'AI"], ["Utili per", "Verificare", "Orientarsi e trovare le primarie"], ["Rischio", "Basso, se autentiche e aggiornate", "Semplificazioni, interpretazioni, imprecisioni"]], { colW: [1.9, 3.55, 3.55], rowH: 0.62, accentCol: 1 });
    banner(s, 4.4, "Per le informazioni importanti, risalire alla fonte primaria. L'output dell'AI è al massimo una fonte secondaria.", { h: 0.55, fontSize: 12 });
  }
  {
    const s = content("Una fonte esistente non basta", "Il concetto chiave del sottotema richiama un punto spesso sottovalutato. Nel Tema 3 abbiamo visto il caso delle fonti inesistenti. Ma anche quando la fonte esiste, non è detto che sostenga l'affermazione. Le situazioni più comuni, raccolte in slide, sono quattro. La fonte esiste ma tratta un argomento diverso, o vicino: per esempio un articolo che parla del settore, non dell'azienda citata. La fonte esiste e tratta l'argomento, ma dice una cosa diversa: un numero diverso, una conclusione più cauta, un'eccezione omessa. La fonte esiste e dice quella cosa, ma in un contesto diverso: un altro paese, un altro periodo, un'altra categoria. La fonte esiste ma non è attendibile o è superata. La verifica corretta prevede quindi tre controlli in sequenza: la fonte è autentica, cioè esiste davvero ed è quella indicata? È pertinente, cioè tratta proprio l'argomento in questione, nello stesso contesto? Sostiene l'affermazione, cioè dice esattamente ciò che le viene attribuito? Per farlo bisogna aprire la fonte e leggere il passaggio pertinente: il titolo e l'esistenza del link non bastano.");
    flowTag(s, 1);
    txt(s, "Quando la fonte esiste ma non sostiene l'affermazione", { x: 0.5, y: 1.15, w: 5.0, h: 0.3, fontSize: 13, bold: true, color: C.accent5 });
    rowList(s, ["Tratta un argomento diverso o vicino", "Dice una cosa diversa: numero, cautela, eccezione", "Vale in un contesto diverso: paese, periodo, categoria", "Non è attendibile o è superata"], { x: 0.5, w: 5.0, y: 1.55, h: 0.55, fontSize: 12 });
    txt(s, "Tre controlli in sequenza", { x: 5.8, y: 1.15, w: 3.7, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
    const c = [["Autentica", "Esiste ed è quella indicata?"], ["Pertinente", "Proprio quell'argomento, nello stesso contesto?"], ["Di supporto", "Dice esattamente ciò che le viene attribuito?"]];
    c.forEach((e, i) => {
      const y = 1.55 + i * 0.8;
      shapeBox(s, 5.8, y, 3.7, 0.7, i === 2 ? C.accent1 : C.accent6, e[0]);
      txt(s, (i + 1) + ". " + e[0], { x: 5.95, y: y + 0.03, w: 3.4, h: 0.32, fontSize: 13, bold: true, color: i === 2 ? C.background1 : C.text1 });
      txt(s, e[1], { x: 5.95, y: y + 0.35, w: 3.4, h: 0.32, fontSize: 11, color: i === 2 ? C.background1 : C.text2 });
    });
    banner(s, 4.15, "Aprire la fonte e leggere il passaggio: il titolo e l'esistenza del link non bastano.", { h: 0.8 });
  }
  {
    const s = content("Attendibilità e fonti indipendenti", "Una volta trovata una fonte pertinente, resta da valutarne la qualità. Attendibilità: chi è l'autore o l'ente? Ha competenza e autorevolezza sull'argomento? Ha interessi che potrebbero influenzare il contenuto, come un fornitore che pubblica dati sul proprio prodotto? L'informazione è documentata? Aggiornamento: quando è stata pubblicata o aggiornata? È ancora valida? Nel caso di norme, prezzi, procedure, organigrammi, dati di mercato, una fonte di due anni fa può essere superata. Confronto tra fonti indipendenti: per le informazioni importanti, specialmente quando la fonte primaria non è disponibile, conviene confrontare almeno due fonti indipendenti tra loro, cioè che non si citano a vicenda e non derivano dalla stessa origine. Se concordano, la fiducia aumenta; se divergono, bisogna capire perché e risalire all'origine. Attenzione alle false conferme: dieci siti che riportano la stessa informazione possono averla copiata tutti dalla stessa fonte, magari sbagliata. E due risposte di sistemi AI diversi non sono fonti indipendenti, come vedremo nel 7.6.");
    flowTag(s, 1);
    const q = [["FiAward", "Attendibilità", ["Chi è l'autore o l'ente?", "Ha competenza sull'argomento?", "Ha interessi in gioco?", "L'informazione è documentata?"]], ["FiCalendar", "Aggiornamento", ["Quando è stata pubblicata?", "È ancora valida?", "Attenzione a norme, prezzi, procedure, dati di mercato"]], ["FiCopy", "Fonti indipendenti", ["Almeno due, che non si citano a vicenda", "Se divergono, risalire all'origine", "Attenzione alle false conferme"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 3.2, { icon: q[i][0], head: q[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2, body: bullets(q[i][2], { space: 4 }) });
    txt(s, "Dieci siti con la stessa informazione possono averla copiata tutti dalla stessa fonte sbagliata.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Date, nomi, numeri e riferimenti", "Alcuni elementi richiedono un controllo puntuale, perché sono frequentemente sbagliati e perché un errore su di essi è particolarmente dannoso. Le date: anni, scadenze, periodi di validità, date di entrata in vigore. Un anno sbagliato può cambiare completamente il significato di un'informazione. I nomi: di persone, aziende, prodotti, enti, luoghi, con le relative cariche e ruoli. Gli errori sono frequenti, e possono essere imbarazzanti in un documento esterno. I numeri: importi, percentuali, quantità, statistiche. Vanno controllati sulla fonte, nel valore e nell'unità, come vedremo nel 7.5. I riferimenti: numeri di articoli di legge, codici, versioni di documenti, numeri di pratiche, link. Un riferimento sbagliato rende inutile o fuorviante il rimando. Per questi elementi la verifica è spesso rapida, se si ha la fonte, e conviene farla sistematicamente per qualsiasi documento destinato all'esterno o a una decisione. Un consiglio: controllare questi elementi uno per uno, con la fonte aperta accanto, invece di rileggere il testo nel suo insieme, perché nella lettura scorrevole gli errori di dettaglio sfuggono facilmente.");
    flowTag(s, 1);
    const e = [["FiCalendar", "Date", "Anni, scadenze, validità, entrata in vigore"], ["FiUser", "Nomi", "Persone, aziende, prodotti, enti, cariche"], ["FiHash", "Numeri", "Importi, percentuali, quantità, statistiche"], ["FiLink", "Riferimenti", "Articoli di legge, codici, versioni, link"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 2.3, C.background2, e[i][1]);
      await iconCircle(s, x + 0.73, 1.38, 0.68, e[i][0]);
      txt(s, e[i][1], { x: x + 0.1, y: 2.15, w: 1.95, h: 0.4, fontSize: 16, bold: true, color: C.text1, align: "center" });
      txt(s, e[i][2], { x: x + 0.15, y: 2.6, w: 1.85, h: 0.8, fontSize: 12, color: C.text2, align: "center" });
    }
    banner(s, 3.75, "Controllarli uno per uno, con la fonte aperta accanto: nella lettura scorrevole gli errori di dettaglio sfuggono.", { h: 0.8, fontSize: 13 });
    txt(s, "Sistematicamente per i documenti destinati all'esterno o a una decisione.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Le informazioni non verificabili", "Non tutte le informazioni si possono verificare: a volte la fonte non è accessibile, i dati non sono pubblici, il tempo non è sufficiente, o l'informazione riguarda una stima, una previsione o un'opinione esperta che per sua natura non è verificabile. Come comportarsi? Le opzioni sono quattro, dalla più prudente alla meno. Eliminare l'informazione, se non è essenziale: spesso un documento funziona benissimo anche senza un dato di contorno non verificato. Riformulare in modo prudente, segnalando l'incertezza: invece di 'il mercato crescerà del 15%', 'alcune stime indicano una crescita, che non è stato possibile verificare'. Sostituirla con un'informazione verificabile, anche se meno precisa: un dato ufficiale di un anno prima invece di uno recente non confermato. Mantenerla dichiarandola come non verificata, quando è utile e il destinatario è in grado di valutarla. In nessun caso un'informazione non verificata dovrebbe essere presentata come un fatto, specialmente in documenti esterni o a supporto di decisioni. La scelta tra queste opzioni dipende, come sempre, dall'importanza dell'informazione e dalle conseguenze dell'uso, che vedremo nel 7.8.");
    flowTag(s, 1);
    const o = [["FiTrash2", "Eliminarla", "Se non è essenziale"], ["FiEdit", "Riformularla con prudenza", "\"Alcune stime indicano..., non verificato\""], ["FiRefreshCw", "Sostituirla", "Con un dato verificabile, anche meno preciso"], ["FiFlag", "Mantenerla dichiarata", "Come non verificata, se utile e il destinatario sa valutarla"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.15, 2.6, C.background2, o[i][1]);
      await iconCircle(s, x + 0.18, 1.35, 0.5, o[i][0]);
      txt(s, o[i][1], { x: x + 0.18, y: 1.95, w: 1.85, h: 0.65, fontSize: 14, bold: true, color: C.text1 });
      txt(s, o[i][2], { x: x + 0.18, y: 2.65, w: 1.85, h: 1.05, fontSize: 12, color: C.text2 });
    }
    banner(s, 4.0, "Mai presentare come fatto un'informazione non verificata, soprattutto in documenti esterni o a supporto di decisioni.", { h: 0.9, fontSize: 13 });
  }
  keySlide("Una citazione non costituisce automaticamente una prova: occorre controllare che la fonte sia autentica, pertinente e sostenga l'affermazione.", "Sottotema 7.3  ·  Verifica delle informazioni e delle fonti", "Concetto chiave. Verificare significa scegliere i punti critici, preferire le fonti primarie, controllare che una fonte sia autentica, pertinente e di supporto, valutarne attendibilità e aggiornamento, confrontare fonti indipendenti, controllare date, nomi, numeri e riferimenti uno per uno, e gestire con trasparenza ciò che non si può verificare. Esercizio suggerito: dare ai partecipanti un breve testo con tre affermazioni e tre fonti citate, di cui una inesistente, una pertinente ma che dice una cosa diversa e una corretta, e chiedere di verificarle.");

  // =====================================================================
  section("7.4 Ragionamenti e conclusioni");
  divider("7.4", "Valutare ragionamenti e conclusioni", "Informazioni singolarmente corrette non assicurano che la conclusione tratta da esse sia giustificata", "Torniamo alla valutazione, questa volta dei ragionamenti. Un output può contenere solo informazioni corrette e arrivare comunque a una conclusione sbagliata, perché il ragionamento che le collega ha un difetto. In questo sottotema, da comprendere e applicare, vediamo come scomporre un ragionamento, quali difetti cercare, come riconoscere assunzioni implicite, generalizzazioni indebite, confusione tra correlazione e causalità, e omissioni che indeboliscono le premesse.");
  {
    const s = content("Premesse, dati e conclusioni", "Per valutare un ragionamento bisogna prima scomporlo nei suoi elementi. I dati sono le informazioni di fatto su cui si basa. Le premesse sono le affermazioni, spesso generali, che collegano i dati alla conclusione: regole, principi, assunzioni. La conclusione è ciò che il ragionamento sostiene. L'esempio in slide mostra un ragionamento tipico di un output dell'AI. Dati: le vendite online sono cresciute del 30%, quelle in negozio sono calate del 5%. Premessa: i clienti preferiscono sempre di più acquistare online. Conclusione: conviene chiudere alcuni negozi. Scomposto così, il ragionamento mostra i suoi punti da verificare: i dati sono corretti? La premessa è dimostrata o è un'interpretazione? La conclusione deriva davvero, o servono altre informazioni, come i margini dei due canali, il ruolo dei negozi nelle vendite online, i costi di chiusura? Negli output dell'AI dati, premesse e conclusioni sono spesso intrecciati nel testo, senza distinzione. Scomporli è il primo passo per valutarli. Si può anche chiedere al sistema di esplicitare la struttura del proprio ragionamento.");
    flowTag(s, 0);
    const p = [["Dati", "Vendite online +30%, vendite in negozio -5%", C.background2, C.text1], ["Premessa", "I clienti preferiscono sempre più acquistare online", C.accent6, C.text1], ["Conclusione", "Conviene chiudere alcuni negozi", C.accent1, C.background1]];
    p.forEach((e, i) => {
      const y = 1.2 + i * 0.85;
      shapeBox(s, 0.5, y, 1.8, 0.7, e[2], e[0]);
      txt(s, e[0], { x: 0.55, y, w: 1.7, h: 0.7, fontSize: 14, bold: true, color: e[3], align: "center", valign: "middle" });
      shapeBox(s, 2.4, y, 3.4, 0.7, C.background1, "testo " + e[0], { color: C.accent3, width: 1 });
      txt(s, e[1], { x: 2.55, y, w: 3.15, h: 0.7, fontSize: 12, color: C.text1, valign: "middle" });
      if (i < 2) s.addShape(pres.shapes.DOWN_ARROW, { x: 1.25, y: y + 0.71, w: 0.3, h: 0.13, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia" });
    });
    txt(s, "Domande", { x: 6.1, y: 1.2, w: 3.4, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["I dati sono corretti?", "La premessa è dimostrata o interpretata?", "Mancano informazioni? Margini, ruolo dei negozi, costi"], { x: 6.1, w: 3.4, y: 1.6, h: 0.6, fontSize: 12 });
    banner(s, 3.95, "Negli output dell'AI dati, premesse e conclusioni sono intrecciati: scomporli è il primo passo per valutarli.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Coerenza logica e passaggi deboli", "Una volta scomposto il ragionamento, si valuta la sua coerenza logica. Le domande principali sono due. La conclusione deriva davvero dalle premesse, o c'è un salto? E ogni passaggio è giustificato, o alcuni sono semplicemente affermati? I passaggi non giustificati sono frequenti negli output generati, perché il sistema produce testo che suona logico, con connettivi come 'quindi', 'di conseguenza', 'ne deriva che', anche quando il collegamento tra le parti è debole. Un esercizio utile è sottolineare questi connettivi e chiedersi, per ciascuno, se il collegamento che introducono è davvero dimostrato. Alcuni segnali di passaggi deboli: la conclusione è molto più forte delle premesse, per esempio da 'alcuni clienti si sono lamentati' a 'il prodotto ha un problema di qualità'; si introduce un elemento nuovo, non presente nelle premesse, proprio nella conclusione; il ragionamento salta da una questione a un'altra, per esempio dal costo alla qualità; si usano termini vaghi che cambiano significato tra le premesse e la conclusione. La coerenza interna, vista nel 7.2 come dimensione della qualità, qui diventa analisi della struttura del ragionamento.");
    flowTag(s, 0);
    shapeBox(s, 0.5, 1.2, 4.35, 1.6, C.text1, "connettivi");
    txt(s, "\"quindi\"  \"di conseguenza\"  \"ne deriva che\"", { x: 0.7, y: 1.3, w: 3.95, h: 0.6, fontSize: 15, bold: true, color: C.accent1 });
    txt(s, "Sottolineare i connettivi e chiedersi se il collegamento è davvero dimostrato.", { x: 0.7, y: 1.95, w: 3.95, h: 0.75, fontSize: 13, color: C.background1 });
    txt(s, "Segnali di passaggi deboli", { x: 5.15, y: 1.15, w: 4.35, h: 0.3, fontSize: 14, bold: true, color: C.accent5 });
    rowList(s, ["Conclusione molto più forte delle premesse", "Un elemento nuovo compare solo nella conclusione", "Salto da una questione a un'altra", "Termini vaghi che cambiano significato"], { x: 5.15, w: 4.35, y: 1.55, h: 0.5, fontSize: 12 });
    await card(s, 0.5, 3.0, 4.35, 1.95, { head: "Esempio di salto", headSize: 14, bodySize: 13, fill: C.accent6, body: "Da \"alcuni clienti si sono lamentati\" a \"il prodotto ha un problema di qualità\"." });
    txt(s, "Il sistema produce testo che suona logico anche quando il collegamento tra le parti è debole.", { x: 5.15, y: 3.95, w: 4.35, h: 1.0, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Correlazione e causalità", "Una delle confusioni più comuni nei ragionamenti, umani e generati, è quella tra correlazione e causalità. Due fenomeni sono correlati quando variano insieme: quando uno aumenta, anche l'altro tende ad aumentare, o a diminuire. Sono in relazione causale quando uno è la causa dell'altro. La correlazione non dimostra la causalità, per almeno tre ragioni. Può esserci un terzo fattore che causa entrambi: nei mesi estivi aumentano sia le vendite di gelati sia gli incidenti in spiaggia, ma i gelati non causano incidenti; la causa comune è il caldo. La causalità può andare nel senso opposto: le aziende che investono in formazione hanno risultati migliori, ma forse sono i buoni risultati a permettere gli investimenti. La correlazione può essere casuale, soprattutto con pochi dati o molte variabili osservate. Negli output dell'AI la confusione si presenta spesso in frasi come 'grazie a', 'a causa di', 'ha portato a', 'il risultato dimostra che'. Quando un output attribuisce una causa, la domanda da porsi è: ci sono spiegazioni alternative? Ci sono evidenze che il legame sia davvero causale? L'esempio dei negozi della slide precedente contiene proprio questo problema.");
    flowTag(s, 0);
    const r = [["FiShare2", "Un terzo fattore", "Gelati e incidenti in spiaggia crescono insieme: la causa comune è il caldo"], ["FiRepeat", "Causalità inversa", "Formazione e risultati: forse sono i risultati a permettere la formazione"], ["FiShuffle", "Coincidenza", "Pochi dati o molte variabili: correlazioni casuali"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.4, { icon: r[i][0], head: r[i][1], headSize: 15, bodySize: 12, body: r[i][2] });
    shapeBox(s, 0.5, 3.8, 9.0, 1.15, C.text1, "frasi causali");
    txt(s, [{ text: "Attenzione a: ", options: { bold: true, color: C.accent1 } }, { text: "\"grazie a\", \"a causa di\", \"ha portato a\", \"dimostra che\". ", options: { color: C.background1 } }, { text: "Ci sono spiegazioni alternative? Evidenze che il legame sia causale?", options: { color: C.accent3 } }], { x: 0.7, y: 3.8, w: 8.6, h: 1.15, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Assunzioni e generalizzazioni indebite", "Due altri difetti frequenti. Le assunzioni implicite sono premesse non dichiarate, date per scontate, da cui il ragionamento dipende. Per esempio, una proposta di risparmio che assume implicitamente che i volumi restino invariati, o un piano che assume che il personale sia disponibile. Se l'assunzione è falsa, la conclusione crolla, ma poiché non è scritta, è difficile accorgersene. Per individuarle, chiedersi: che cosa deve essere vero perché questa conclusione valga? Le generalizzazioni indebite estendono a tutti i casi ciò che vale per alcuni: da pochi esempi a una regola generale, da un contesto a un altro, da un periodo a sempre. Per esempio: 'i clienti preferiscono il servizio online', basato su un'indagine tra clienti giovani di una sola città; oppure 'questa soluzione funziona', perché ha funzionato in un'altra azienda di un altro settore. Negli output dell'AI le generalizzazioni sono frequenti, perché il sistema tende a formulare affermazioni generali e a trasferire ai nostri casi soluzioni tipiche di altri contesti, come abbiamo visto nel Tema 3. La domanda di controllo è: su quanti casi e in quale contesto si basa questa affermazione? Vale anche per il nostro?");
    flowTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 3.0, { icon: "FiEyeOff", head: "Assunzioni implicite", headSize: 16, bodySize: 12,
      body: [{ text: "Premesse non dichiarate da cui dipende la conclusione", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Esempio: un risparmio che assume volumi invariati.", options: { italic: true, breakLine: true, paraSpaceAfter: 10 } }, { text: "Domanda: che cosa deve essere vero perché la conclusione valga?", options: { bold: true, color: C.accent1 } }] });
    await card(s, 5.15, 1.2, 4.35, 3.0, { icon: "FiMaximize2", head: "Generalizzazioni indebite", headSize: 16, bodySize: 12, fill: C.accent6,
      body: [{ text: "Da alcuni casi a tutti, da un contesto a un altro", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Esempio: \"i clienti preferiscono l'online\", da un'indagine su giovani di una città.", options: { italic: true, breakLine: true, paraSpaceAfter: 10 } }, { text: "Domanda: su quanti casi, in quale contesto? Vale per noi?", options: { bold: true, color: C.accent1 } }] });
    txt(s, "L'AI tende a formulare affermazioni generali e a trasferire soluzioni tipiche di altri contesti.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Alternative e omissioni nel ragionamento", "Un ragionamento solido considera le alternative. Un ragionamento debole presenta una sola interpretazione dei dati come se fosse l'unica possibile. Per ogni conclusione importante, conviene chiedersi: quali altre spiegazioni sono compatibili con gli stessi dati? Nell'esempio dei negozi: il calo in negozio potrebbe dipendere da lavori stradali in una zona, da un cambio di assortimento, dalla stagionalità, non solo dalla preferenza per l'online. Qui ritroviamo l'integrazione sulle omissioni, applicata ai ragionamenti. Un ragionamento apparentemente coerente può poggiare su premesse incomplete: non considerare eccezioni, condizioni, vincoli, controargomentazioni rilevanti. La differenza con il 7.2 è sottile ma importante: lì l'omissione rendeva incompleto l'output; qui rende ingiustificata la conclusione. Se il ragionamento sui negozi non considera che una parte delle vendite online deriva da clienti che prima hanno visto il prodotto in negozio, la conclusione di chiudere i negozi potrebbe danneggiare proprio le vendite online. Per individuare queste omissioni: chiedersi quali informazioni potrebbero cambiare la conclusione, e se sono state considerate; e chiedersi quale sarebbe l'argomento più forte contro la conclusione.");
    flowTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiShuffle", head: "Interpretazioni alternative", headSize: 15, bodySize: 12,
      body: [{ text: "Quali altre spiegazioni sono compatibili con gli stessi dati?", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Calo in negozio: lavori stradali, assortimento, stagionalità, non solo preferenza per l'online.", options: { italic: true } }] });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiAlertTriangle", head: "Omissioni nelle premesse", headSize: 15, bodySize: 12, fill: C.accent6,
      body: [{ text: "Eccezioni, condizioni, controargomentazioni non considerate", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }, { text: "Molti acquisti online nascono da visite in negozio: chiudere i negozi potrebbe ridurre l'online.", options: { italic: true } }] });
    banner(s, 4.0, "Quali informazioni potrebbero cambiare la conclusione? Sono state considerate? Qual è l'argomento più forte contro?", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Conclusioni coerenti con le evidenze", "L'ultimo controllo sintetizza i precedenti: la conclusione è proporzionata alle evidenze? Una conclusione può essere troppo forte rispetto alle evidenze, quando presenta come certo ciò che è solo probabile, o come generale ciò che vale in alcuni casi. Può essere troppo debole, quando le evidenze sono solide ma la conclusione è vaga o elusiva, cosa che negli output dell'AI accade quando il sistema 'sta sul generico' per prudenza. Oppure può non essere collegata alle evidenze, quando il ragionamento arriva a una conclusione che i dati presentati non trattano. La slide propone una breve lista di controllo, che riassume il sottotema: dati corretti; premesse dichiarate e fondate; passaggi giustificati; nessuna confusione tra correlazione e causalità; nessuna generalizzazione indebita; alternative considerate; informazioni rilevanti non omesse; conclusione proporzionata alle evidenze. Non serve applicarla meccanicamente a ogni testo: per gli output che sostengono decisioni importanti, però, è un buon esercizio, che con la pratica diventa naturale.");
    flowTag(s, 0);
    const c = ["Dati corretti", "Premesse dichiarate e fondate", "Passaggi giustificati", "Correlazione non scambiata per causalità", "Nessuna generalizzazione indebita", "Alternative considerate", "Informazioni rilevanti non omesse", "Conclusione proporzionata alle evidenze"];
    c.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.72;
      shapeBox(s, x, y, 4.4, 0.62, row % 2 ? C.background1 : C.background2, t);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.15, y: y + 0.17, w: 0.28, h: 0.28, rectRadius: 0.04, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 }, objectName: "casella" });
      txt(s, t, { x: x + 0.6, y, w: 3.7, h: 0.62, fontSize: 13, color: C.text1, valign: "middle" });
    });
    txt(s, "Troppo forte, troppo debole, o non collegata alle evidenze: tre modi di sbagliare una conclusione.", { x: 0.5, y: 4.15, w: 9, h: 0.75, fontSize: 13, italic: true, color: C.text1 });
  }
  keySlide("Informazioni singolarmente corrette non assicurano che la conclusione tratta da esse sia giustificata.", "Sottotema 7.4  ·  Valutare ragionamenti e conclusioni", "Concetto chiave. Per valutare un ragionamento lo si scompone in dati, premesse e conclusione, e si cercano i difetti tipici: passaggi non giustificati, confusione tra correlazione e causalità, assunzioni implicite, generalizzazioni indebite, alternative ignorate, omissioni nelle premesse. La conclusione deve essere proporzionata alle evidenze. Esercizio suggerito: dare ai partecipanti una breve raccomandazione prodotta dall'AI e chiedere di scomporla, individuare almeno un'assunzione implicita e proporre un'interpretazione alternativa dei dati.");

  // =====================================================================
  section("7.5 Dati e calcoli");
  divider("7.5", "Verifica di dati, calcoli e risultati quantitativi", "Un risultato quantitativo utile alle decisioni deve essere riconducibile a dati e procedimenti controllabili", "I numeri hanno un'autorevolezza particolare: una percentuale precisa o una tabella ordinata sembrano più oggettive di una frase. Ma i risultati quantitativi prodotti con l'AI possono contenere errori nei dati di partenza, nelle formule, nelle unità, nelle aggregazioni, nella rappresentazione. In questo sottotema, da conoscere e applicare, vediamo come verificarli. Non entriamo in metriche statistiche avanzate, che vanno solo accennate: ci interessano controlli pratici, alla portata di chiunque lavori con dati.");
  {
    const s = content("Dati di partenza, formule e unità", "Il controllo di un risultato quantitativo parte dall'inizio della catena. I dati di partenza: sono quelli giusti? Provengono dalla fonte corretta, riguardano il periodo, l'entità e la versione giusti? Sono completi, o mancano righe, mesi, categorie? Sono stati letti correttamente, per esempio senza confondere colonne o separatori decimali? Un errore qui si propaga a tutto ciò che segue. Le formule e le operazioni: il calcolo è quello appropriato? Una crescita percentuale si calcola rispetto al valore iniziale, una media va ponderata quando i gruppi hanno dimensioni diverse, un margine si calcola sul ricavo o sul costo a seconda della definizione aziendale. Il sistema può scegliere una formula plausibile ma diversa da quella in uso nella nostra organizzazione. Le unità di misura: euro o migliaia di euro, valori mensili o annuali, pezzi o confezioni, percentuali o punti percentuali. Un passaggio da 10% a 12% è un aumento di 2 punti percentuali, ma del 20% in termini relativi: confondere le due cose è un errore frequente e significativo. Per ciascuno di questi elementi, la verifica richiede di conoscere i dati e le definizioni in uso, e di poterli confrontare con l'origine.");
    flowTag(s, 1);
    const c = [["FiDatabase", "Dati di partenza", ["Fonte, periodo, entità, versione giusti?", "Completi?", "Letti correttamente?"]], ["FiCode", "Formule e operazioni", ["Il calcolo appropriato?", "Media ponderata quando serve?", "Definizioni aziendali rispettate?"]], ["FiSliders", "Unità di misura", ["Euro o migliaia, mese o anno?", "Pezzi o confezioni?", "Percentuale o punti percentuali?"]]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.8, { icon: c[i][0], head: c[i][1], headSize: 15, bodySize: 12, fill: i === 2 ? C.accent6 : C.background2, body: bullets(c[i][2], { space: 5 }) });
    banner(s, 4.15, "Da 10% a 12%: +2 punti percentuali, ma +20% in termini relativi. Una confusione frequente.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Plausibilità e ordini di grandezza", "Prima ancora di ricalcolare, un controllo rapido ed efficacissimo è quello di plausibilità: il risultato è sensato? Bastano poche domande, che richiedono conoscenza del contesto più che calcoli. L'ordine di grandezza è giusto? Se il fatturato annuo dell'azienda è di circa 10 milioni, un risultato di 100 milioni o di 100 mila segnala un errore, probabilmente di unità o di un fattore dieci. Il segno è giusto? Un costo che risulta negativo, una crescita dove ci si aspettava un calo, richiedono una spiegazione. I totali tornano? La somma delle parti corrisponde al totale, le percentuali di una ripartizione sommano a cento? I valori sono coerenti con ciò che si conosce? Se un reparto con 5 persone risulta avere costi del personale superiori a uno con 50, qualcosa non va. I confronti nel tempo sono sensati? Una variazione del 300% in un mese, in un'attività stabile, è sospetta. Questi controlli non dimostrano che il risultato è corretto, ma individuano rapidamente molti errori. Sono il primo filtro, e richiedono soprattutto ciò che chi lavora in azienda possiede: la conoscenza dei propri numeri.");
    flowTag(s, 1);
    const q = [["FiMaximize", "Ordine di grandezza", "Fatturato di 10 milioni: 100 milioni o 100 mila segnalano un errore"], ["FiPlusCircle", "Segno", "Un costo negativo, una crescita inattesa: perché?"], ["FiPieChart", "Totali", "La somma delle parti torna? Le percentuali fanno 100?"], ["FiUsers", "Coerenza con il noto", "5 persone con più costi di 50?"], ["FiTrendingUp", "Variazioni nel tempo", "+300% in un mese in un'attività stabile?"]];
    await iconGrid(s, q.slice(0, 3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, h: 1.55, headSize: 14 });
    await iconGrid(s, q.slice(3).map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 2.95, h: 1.25, headSize: 14 });
    banner(s, 4.4, "Il primo filtro: non dimostra la correttezza, ma intercetta molti errori. Serve conoscere i propri numeri.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Dati osservati, stime e simulazioni", "I numeri non sono tutti dello stesso tipo, e negli output dell'AI tipi diversi vengono spesso presentati allo stesso modo. I dati osservati sono misurati o registrati: le vendite del mese scorso, il numero di dipendenti, i reclami ricevuti. Sono i più affidabili, se la fonte è corretta. Le stime sono valori calcolati a partire da dati parziali o da ipotesi: la quota di mercato stimata, il costo previsto di un progetto, il numero di potenziali clienti. Dipendono dalle ipotesi usate, che vanno conosciute. Le simulazioni e le proiezioni descrivono scenari possibili: il fatturato previsto tra tre anni, l'effetto di un aumento di prezzo. Sono utili per ragionare, ma non sono fatti, e dipendono interamente dalle assunzioni. Un rischio specifico con l'AI è che il sistema produca numeri stimati o inventati e li presenti come dati osservati, con la stessa precisione apparente: '3.247 clienti potenziali' suona come un dato, ma potrebbe essere una stima senza base. La domanda da porsi per ogni numero importante è: questo valore è stato misurato, stimato o simulato? E, se è stimato o simulato, su quali ipotesi si basa?");
    flowTag(s, 1);
    const t = [["Dati osservati", "Misurati o registrati", "Vendite del mese, dipendenti, reclami", "I più affidabili, se la fonte è corretta", C.accent6], ["Stime", "Calcolati da dati parziali o ipotesi", "Quota di mercato, costo previsto", "Dipendono dalle ipotesi", C.background2], ["Simulazioni", "Scenari possibili", "Fatturato tra tre anni, effetto di un prezzo", "Non sono fatti: dipendono dalle assunzioni", C.background2]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.75, t[i][4], t[i][0]);
      txt(s, t[i][0], { x: x + 0.2, y: 1.3, w: 2.46, h: 0.4, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, t[i][1], { x: x + 0.2, y: 1.72, w: 2.46, h: 0.5, fontSize: 13, bold: true, color: C.text1 });
      txt(s, "Esempi: " + t[i][2], { x: x + 0.2, y: 2.3, w: 2.46, h: 0.75, fontSize: 12, italic: true, color: C.text2 });
      txt(s, t[i][3], { x: x + 0.2, y: 3.1, w: 2.46, h: 0.75, fontSize: 12, bold: true, color: C.text1 });
    }
    banner(s, 4.15, "\"3.247 clienti potenziali\" suona come un dato, ma può essere una stima senza base. Misurato, stimato o simulato?", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Aggregazioni e confronti", "Molti errori quantitativi nascono nelle aggregazioni, cioè quando si sommano, si mediano o si raggruppano i dati, e nei confronti. Alcuni casi frequenti. Le medie possono nascondere situazioni molto diverse: un tempo medio di consegna di tre giorni può derivare da metà consegne in un giorno e metà in cinque. A volte la mediana o la distribuzione sono più informative. Le medie di medie sono spesso sbagliate: se due filiali hanno margini del 10% e del 20%, il margine complessivo non è il 15%, a meno che abbiano lo stesso fatturato. Le percentuali vanno lette insieme alle basi: un aumento del 50% su 4 casi significa passare a 6; non è un trend. I confronti devono essere omogenei: stesso periodo, stessa definizione, stesso perimetro. Confrontare un trimestre con un anno, o i dati di una sola sede con quelli di tutta l'azienda, produce conclusioni sbagliate. E i dati aggregati possono mostrare un andamento opposto a quello dei sottogruppi, un fenomeno noto in statistica come paradosso di Simpson, che basta accennare: è un ulteriore motivo per guardare i dati disaggregati quando la decisione è importante.");
    flowTag(s, 1);
    const c = [["FiBarChart", "Medie che nascondono", "3 giorni di media: metà in 1, metà in 5"], ["FiDivide", "Medie di medie", "Margini 10% e 20%: il complessivo non è 15% se i fatturati differiscono"], ["FiPercent", "Percentuali senza base", "+50% su 4 casi: da 4 a 6, non un trend"], ["FiColumns", "Confronti non omogenei", "Trimestre contro anno, una sede contro l'azienda"]];
    await iconGrid(s, c.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.85, headSize: 14, bodySize: 12 });
    txt(s, "I dati aggregati possono mostrare un andamento opposto a quello dei sottogruppi (paradosso di Simpson): per decisioni importanti, guardare anche i dati disaggregati.", { x: 0.5, y: 4.25, w: 9, h: 0.7, fontSize: 12, italic: true, color: C.text1 });
  }
  {
    const s = content("Leggere criticamente tabelle e grafici", "Tabelle e grafici prodotti con l'AI vanno letti con la stessa attenzione dei testi, perché la forma visiva può rafforzare o distorcere il messaggio. Il caso più classico è mostrato in slide: gli stessi due valori, 102 e 105, rappresentati con un asse verticale che parte da zero e con uno che parte da 100. Nel primo grafico la differenza appare modesta, come è; nel secondo sembra enorme. Nessuno dei due è falso, ma il secondo può indurre a conclusioni sbagliate. Altri elementi da controllare: le etichette degli assi e le unità di misura; il periodo rappresentato, perché scegliere l'intervallo può cambiare l'impressione di un andamento; le scale, per esempio due serie su assi diversi; l'origine dei dati e la loro corrispondenza con le tabelle; le categorie omesse o raggruppate in 'altro'. Per le tabelle: corrispondenza dei totali, coerenza delle unità tra colonne, valori mancanti, arrotondamenti. Un grafico ben fatto è uno strumento potente; ma, come per i testi, la buona presentazione non dimostra la correttezza dei dati.");
    flowTag(s, 1);
    const cOpt = (min, title, color) => ({ barDir: "col", chartColors: [color], showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisMinVal: min, valAxisMaxVal: 110, valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, showTitle: true, title, titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 80 });
    s.addChart(pres.charts.BAR, [{ name: "Valore", labels: ["2024", "2025"], values: [102, 105] }], Object.assign({ x: 0.5, y: 1.15, w: 2.9, h: 2.9 }, cOpt(0, "Asse da zero", HEX.a1)));
    s.addChart(pres.charts.BAR, [{ name: "Valore", labels: ["2024", "2025"], values: [102, 105] }], Object.assign({ x: 3.5, y: 1.15, w: 2.9, h: 2.9 }, cOpt(100, "Asse da 100", HEX.a5)));
    txt(s, "Stessi dati, impressione molto diversa", { x: 0.5, y: 4.1, w: 5.9, h: 0.3, fontSize: 12, bold: true, color: C.text1, align: "center" });
    txt(s, "Da controllare", { x: 6.7, y: 1.15, w: 2.8, h: 0.3, fontSize: 14, bold: true, color: C.text1 });
    rowList(s, ["Assi, etichette, unità", "Periodo e scale", "Origine e corrispondenza con le tabelle", "Categorie omesse o in \"altro\"", "Totali, arrotondamenti, valori mancanti"], { x: 6.7, w: 2.8, y: 1.55, h: 0.48, fontSize: 11 });
    txt(s, "La buona presentazione non dimostra la correttezza dei dati.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Tracciabilità e strumenti indipendenti", "Il concetto chiave del sottotema dice che un risultato quantitativo utile alle decisioni deve essere riconducibile a dati e procedimenti controllabili. Due pratiche lo rendono possibile. La tracciabilità dei passaggi di calcolo: deve essere possibile ricostruire come si è arrivati al risultato, cioè quali dati, quali formule, quali passaggi intermedi. Quando si usa l'AI per un'analisi, conviene chiedere di mostrare i passaggi, le formule usate e, se lo strumento esegue codice, il codice stesso, così che possa essere riletto o rieseguito. Un numero di cui non si conosce l'origine non dovrebbe sostenere una decisione. L'utilizzo di strumenti indipendenti per la verifica: ricalcolare i valori importanti con uno strumento diverso, come un foglio di calcolo, partendo dai dati originali; confrontare con report o sistemi aziendali che contengono gli stessi dati; per calcoli complessi, chiedere a un collega esperto di rifare il calcolo in modo autonomo. Uno strumento indipendente è prezioso proprio perché non condivide gli eventuali errori del primo. Anche qui il livello di impegno dipende dall'uso: un ordine di grandezza per una discussione interna non richiede lo stesso controllo di un valore da inserire in un bilancio o in un'offerta.");
    flowTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.9, { icon: "FiMap", head: "Tracciabilità", headSize: 16, bodySize: 13,
      body: bullets(["Quali dati, quali formule, quali passaggi", "Chiedere di mostrare passaggi e codice", "Un numero senza origine non sostiene una decisione"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.9, { icon: "FiTool", head: "Strumenti indipendenti", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Ricalcolo con un foglio di calcolo dai dati originali", "Confronto con report e sistemi aziendali", "Calcolo autonomo di un collega esperto"], { space: 4 }) });
    banner(s, 4.3, "Uno strumento indipendente è prezioso perché non condivide gli errori del primo.", { h: 0.65 });
  }
  keySlide("Un risultato quantitativo utile alle decisioni deve essere riconducibile a dati e procedimenti controllabili.", "Sottotema 7.5  ·  Verifica di dati, calcoli e risultati quantitativi", "Concetto chiave. Verificare i numeri significa controllare dati di partenza, formule e unità; applicare controlli di plausibilità; distinguere dati osservati, stime e simulazioni; diffidare di medie, percentuali e confronti non omogenei; leggere criticamente tabelle e grafici; garantire tracciabilità e ricalcolare con strumenti indipendenti. Esercizio suggerito: dare ai partecipanti una piccola tabella prodotta dall'AI con un errore di unità e un totale che non torna, e chiedere di individuarli con i soli controlli di plausibilità.");

  // =====================================================================
  section("7.6 Revisione assistita dall'AI");
  divider("7.6", "Tecniche di verifica e revisione assistite dall'AI", "La revisione assistita dall'AI è un supporto al controllo, non un sostituto delle evidenze indipendenti", "L'AI può essere usata non solo per produrre contenuti, ma anche per aiutarci a rivederli. In questo sottotema, da conoscere e sperimentare, vediamo le principali tecniche di revisione assistita: richieste di revisione critica, ricerca di assunzioni, punti deboli, contraddizioni e lacune, controargomentazioni, checklist, confronto tra modelli. E affrontiamo il punto centrale: la differenza tra chiedere all'AI se una risposta è corretta e verificarla davvero.");
  {
    const s = content("Sei tecniche di revisione assistita", "Ecco le principali tecniche, con un esempio di richiesta per ciascuna. Revisione critica: 'Rileggi il testo come un revisore esigente e segnala errori, imprecisioni e punti poco chiari'. Assunzioni e punti deboli: 'Quali assunzioni implicite contiene questo ragionamento? Quali sono i suoi punti più deboli?'. Controargomentazioni: 'Qual è l'argomento più forte contro questa conclusione?'. Confronto tra alternative: 'Quali altre conclusioni sarebbero compatibili con gli stessi dati?'. Checklist e criteri: 'Verifica se il documento rispetta questi cinque requisiti e indica per ciascuno dove e come'. Contraddizioni e informazioni mancanti: 'Ci sono affermazioni in contraddizione tra loro? Quali informazioni importanti mancano?'. Queste richieste applicano gli strumenti visti nei sottotemi 7.2 e 7.4, chiedendo al sistema di svolgere un primo esame. Funzionano meglio se la revisione avviene in una nuova conversazione, presentando il testo come lavoro di altri, perché il sistema tende a essere meno critico verso ciò che ha appena prodotto e verso ciò che l'utente presenta come proprio, come abbiamo visto parlando di compiacenza.");
    flowTag(s, 1);
    const t = [["FiCheckSquare", "Revisione critica", "\"Rileggi come un revisore esigente: errori, imprecisioni, punti poco chiari.\""], ["FiEyeOff", "Assunzioni e punti deboli", "\"Quali assunzioni implicite? Quali punti più deboli?\""], ["FiShield", "Controargomentazioni", "\"Qual è l'argomento più forte contro questa conclusione?\""], ["FiShuffle", "Alternative", "\"Quali altre conclusioni sono compatibili con i dati?\""], ["FiList", "Checklist e criteri", "\"Verifica questi cinque requisiti, indicando dove e come.\""], ["FiAlertCircle", "Contraddizioni e lacune", "\"Ci sono contraddizioni? Che cosa manca?\""]];
    await iconGrid(s, t.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 3.0, headSize: 13, bodySize: 11 });
    banner(s, 4.4, "Meglio in una nuova conversazione, presentando il testo come lavoro di altri: il sistema è meno compiacente.", { h: 0.55, fontSize: 12 });
  }
  {
    const s = content("Un esempio di richiesta di revisione", "Ecco un esempio di richiesta di revisione che combina più tecniche, da usare in una nuova conversazione dopo aver ottenuto un primo output. Il testo da rivedere viene delimitato e presentato come bozza preparata da un collega. La richiesta chiede di distinguere fatti, stime e interpretazioni, di elencare le affermazioni che andrebbero verificate su una fonte, di indicare assunzioni implicite e informazioni mancanti, e di proporre l'argomento più forte contro la conclusione. Chiede infine di non riscrivere il testo, ma di produrre un elenco di osservazioni. Questo ultimo accorgimento è importante: se si chiede di correggere direttamente il testo, il sistema può introdurre nuovi errori o modificare parti corrette, e diventa difficile capire che cosa è cambiato. Un elenco di osservazioni, invece, lascia alla persona la valutazione e la decisione su ogni punto. Il risultato di questa richiesta è una lista di punti da controllare: non una verifica, ma una mappa per verificare.");
    flowTag(s, 1);
    promptBox(s, 0.5, 1.2, 5.9, 3.75, "Di seguito trovi la bozza di un collega.\n1. Distingui fatti, stime e interpretazioni.\n2. Elenca le affermazioni da verificare su una fonte.\n3. Indica assunzioni implicite e informazioni mancanti.\n4. Proponi l'argomento più forte contro la conclusione.\nNon riscrivere il testo: produci solo un elenco di osservazioni.\n\n-----\n[bozza]\n-----", { label: "Esempio: richiesta di revisione", fill: C.accent6, fontSize: 11 });
    await card(s, 6.65, 1.2, 2.85, 1.75, { head: "Osservazioni, non riscrittura", headSize: 13, bodySize: 12, body: "La riscrittura può introdurre errori e nascondere i cambiamenti." });
    await card(s, 6.65, 3.1, 2.85, 1.85, { head: "Il risultato", headSize: 13, bodySize: 12, fill: C.accent6, body: "Non una verifica, ma una mappa per verificare." });
  }
  {
    const s = content("Il confronto con altri modelli", "Una tecnica sempre più diffusa è confrontare le risposte di modelli diversi alla stessa domanda, o chiedere a un modello di rivedere l'output di un altro. Ha una sua utilità: se due sistemi danno risposte molto diverse a una domanda fattuale, è un segnale chiaro che almeno uno dei due sbaglia, e che l'argomento va verificato con cura. Un modello diverso può anche notare errori o omissioni che il primo non vede, perché ha caratteristiche diverse. Ma il confronto ha un limite importante, sottolineato dal documento di perimetro: anche modelli diversi possono condividere errori. Sono addestrati su dati in buona parte simili, con metodi simili, e possono riprodurre le stesse informazioni sbagliate, le stesse lacune, gli stessi bias, le stesse interpretazioni comuni ma scorrette. Due modelli che concordano non costituiscono quindi due fonti indipendenti: la concordanza aumenta un po' la fiducia, ma non è una prova. La discordanza, invece, è un'informazione preziosa. Il confronto tra modelli serve dunque soprattutto a individuare i punti dubbi, non a confermare quelli certi.");
    flowTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiGitPullRequest", head: "Se divergono", headSize: 16, bodySize: 13, fill: C.accent6,
      body: [{ text: "Segnale chiaro: ", options: { bold: true, color: C.accent1 } }, { text: "almeno uno sbaglia, l'argomento va verificato con cura.", options: { breakLine: true, paraSpaceAfter: 8 } }, { text: "Un modello diverso può notare errori che il primo non vede.", options: {} }] });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiGitMerge", head: "Se concordano", headSize: 16, bodySize: 13,
      body: [{ text: "Non è una prova: ", options: { bold: true, color: C.accent5 } }, { text: "dati e metodi simili possono produrre gli stessi errori, lacune, bias.", options: { breakLine: true, paraSpaceAfter: 8 } }, { text: "Due modelli non sono due fonti indipendenti.", options: { bold: true, color: C.text1 } }] });
    banner(s, 4.0, "Il confronto tra modelli serve a individuare i punti dubbi, non a confermare quelli certi.", { h: 0.9 });
  }
  {
    const s = content("Verificare o chiedere conferma all'AI", "Questa integrazione del sottotema affronta un equivoco molto diffuso: pensare di aver verificato una risposta chiedendo all'AI 'sei sicuro?' o 'controlla se è corretto'. Il documento di perimetro indica tre modi in cui questa richiesta può fallire. Il modello può confermare errori: ripete o giustifica l'informazione sbagliata, come nel caso Avianca visto nel Tema 3, in cui il sistema confermò l'esistenza di sentenze inventate. Il modello può correggere risultati corretti: se la domanda lascia intendere un dubbio, il sistema tende ad assecondarlo, cambiando una risposta giusta in una sbagliata. Il modello può fornire giustificazioni infondate: produce spiegazioni convincenti a sostegno di una conclusione, che sembrano dimostrarla ma non si basano su evidenze reali. Chiedere al sistema di controllarsi può comunque aiutare a individuare problemi, soprattutto errori di calcolo, incoerenze interne o passaggi saltati, specialmente se lo si fa con richieste specifiche come quelle viste prima. Ma non costituisce una prova indipendente: il sistema usa la stessa conoscenza e gli stessi meccanismi che hanno prodotto l'output.");
    flowTag(s, 1);
    txt(s, "\"Sei sicuro?\" può...", { x: 0.5, y: 1.15, w: 9, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const f = [["FiCheck", "Confermare errori", "Ripete o giustifica l'informazione sbagliata (caso Avianca)"], ["FiRotateCcw", "Correggere risultati corretti", "Asseconda il dubbio e cambia una risposta giusta"], ["FiMessageSquare", "Giustificare senza basi", "Spiegazioni convincenti senza evidenze reali"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.55, 2.86, 2.0, { icon: f[i][0], head: f[i][1], headSize: 15, bodySize: 12, iconBg: C.accent5, body: f[i][2] });
    shapeBox(s, 0.5, 3.75, 9.0, 1.2, C.text1, "messaggio autoverifica");
    txt(s, [{ text: "Può aiutare a trovare problemi ", options: { color: C.background1 } }, { text: "(calcoli, incoerenze, passaggi saltati), ", options: { color: C.accent3 } }, { text: "ma non è una prova indipendente: ", options: { bold: true, color: C.accent1 } }, { text: "usa la stessa conoscenza che ha prodotto l'output.", options: { color: C.background1 } }], { x: 0.7, y: 3.75, w: 8.6, h: 1.2, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Autovalutazione e verifica indipendente", "La tabella mette a confronto i due approcci. L'autovalutazione, o revisione assistita dall'AI, usa lo stesso sistema, o un sistema simile, per esaminare l'output. È rapida, economica, sempre disponibile, utile per trovare errori evidenti, incoerenze, lacune, e per costruire una lista di punti da controllare. Ma condivide conoscenze e limiti con chi ha prodotto l'output, è esposta alla compiacenza, e non può accedere alla verità se non attraverso strumenti esterni. La verifica indipendente usa evidenze esterne al sistema: fonti primarie, dati originali, strumenti di calcolo, esperti. È più lenta e impegnativa, ma è l'unica che fornisce una prova. Nella pratica i due approcci sono complementari, e la sequenza tipica è chiara: prima la revisione assistita, che individua i punti dubbi; poi la verifica indipendente sui punti più importanti. Il concetto chiave del sottotema lo riassume: la revisione assistita dall'AI è un supporto al controllo, non un sostituto delle evidenze indipendenti. Un caso particolare è l'uso di strumenti esterni da parte del sistema stesso, come la ricerca web o l'esecuzione di codice: avvicinano la revisione a una verifica, ma i risultati vanno comunque controllati, come abbiamo visto per le fonti.");
    flowTag(s, 1);
    table(s, [["", "Revisione assistita dall'AI", "Verifica indipendente"], ["Che cosa usa", "Lo stesso sistema o uno simile", "Fonti primarie, dati originali, strumenti, esperti"], ["Vantaggi", "Rapida, economica, sempre disponibile", "Fornisce una prova"], ["Utile per", "Errori evidenti, incoerenze, lacune, lista di punti dubbi", "Confermare o smentire i punti importanti"], ["Limiti", "Stessi limiti di chi ha prodotto, compiacenza", "Più lenta e impegnativa"]], { colW: [1.8, 3.6, 3.6], rowH: 0.62, accentCol: 2 });
    banner(s, 4.4, "Sequenza tipica: prima la revisione assistita trova i punti dubbi, poi la verifica indipendente sui più importanti.", { h: 0.55, fontSize: 12 });
  }
  keySlide("Una revisione assistita dall'AI è un supporto al controllo, non un sostituto delle evidenze indipendenti.", "Sottotema 7.6  ·  Tecniche di verifica e revisione assistite dall'AI", "Concetto chiave. L'AI può aiutare a rivedere un output: revisione critica, assunzioni, controargomentazioni, alternative, checklist, contraddizioni e lacune, confronto tra modelli. Conviene chiedere osservazioni invece di riscritture, e presentare il testo come lavoro di altri. Ma chiedere all'AI se ha ragione non è una verifica: può confermare errori, correggere risultati giusti, giustificare senza basi. E modelli diversi possono condividere errori. Esercizio suggerito: far applicare ai partecipanti la richiesta di revisione vista in precedenza a un output reale, poi verificare in modo indipendente i due punti più importanti emersi.");

  // =====================================================================
  section("7.7 Bias cognitivi");
  divider("7.7", "Bias cognitivi e fiducia nell'AI", "L'affidabilità del processo dipende anche dall'atteggiamento di chi valuta e dalla capacità di riconoscere i propri bias", "Finora abbiamo parlato degli output e dei metodi per valutarli. Ma la valutazione la fa una persona, e le persone hanno tendenze sistematiche di giudizio, i bias cognitivi, che possono comprometterla. Il 7.1 ha introdotto il metodo critico; il 7.7 affronta i bias che possono comprometterlo. Alcuni li abbiamo già incontrati nei Temi 3 e 5: qui li guardiamo dal punto di vista specifico della valutazione e della verifica, e proponiamo strategie per contrastarli. L'obiettivo è una consapevolezza critica, non uno studio psicologico approfondito.");
  {
    const s = content("I bias che influenzano la valutazione", "Ecco i principali bias cognitivi che possono influenzare il modo in cui valutiamo gli output dell'AI. Il bias di conferma: notiamo e accettiamo più facilmente ciò che conferma le nostre convinzioni, e verifichiamo con più severità ciò che le contraddice. L'automation bias: tendiamo a privilegiare i suggerimenti dei sistemi automatici, riducendo la verifica. L'effetto dell'autorevolezza apparente: attribuiamo credibilità a ciò che ha la forma di un testo competente. L'influenza della fluidità e della sicurezza espressiva: ciò che è facile da leggere e affermato con sicurezza ci sembra più vero. L'eccessiva fiducia negli output, spesso rafforzata dalle esperienze positive precedenti. La sfiducia non giustificata, l'errore opposto, che porta a scartare output validi. La delega del giudizio e l'accettazione passiva: lasciare che sia il sistema a decidere che cosa è giusto. Sono tendenze comuni a tutti, non segni di superficialità: proprio per questo conviene conoscerle e predisporre contromisure, invece di contare sulla buona volontà.");
    flowTag(s, -1);
    const b = [["FiCheckCircle", "Bias di conferma"], ["FiCpu", "Automation bias"], ["FiAward", "Autorevolezza apparente"], ["FiFeather", "Fluidità e sicurezza"], ["FiThumbsUp", "Fiducia eccessiva"], ["FiThumbsDown", "Sfiducia non giustificata"], ["FiPause", "Delega del giudizio"]];
    for (let i = 0; i < 7; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = row === 0 ? 0.5 + col * 2.3 : 1.65 + col * 2.3, y = 1.2 + row * 1.55;
      shapeBox(s, x, y, 2.15, 1.38, i === 5 ? C.accent6 : C.background2, b[i][1]);
      await iconCircle(s, x + 0.8, y + 0.15, 0.55, b[i][0], i === 5 ? C.accent2 : C.accent1);
      txt(s, b[i][1], { x: x + 0.1, y: y + 0.78, w: 1.95, h: 0.5, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
    }
    banner(s, 4.4, "Tendenze comuni a tutti: servono contromisure, non solo buona volontà.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Bias di conferma nella verifica", "Il bias di conferma merita un approfondimento, perché agisce in modo specifico durante la verifica. Quando un output conferma ciò che pensiamo, tendiamo a considerarlo corretto e a verificarlo poco; quando lo contraddice, tendiamo a cercarne i difetti. Il risultato è una verifica asimmetrica: severa con le informazioni scomode, indulgente con quelle gradite. Inoltre, come visto nel Tema 3, il sistema tende ad assecondare l'utente, e il modo in cui formuliamo le domande può già contenere la risposta che desideriamo. Il bias si manifesta anche nella ricerca delle fonti: cerchiamo, e troviamo, le fonti che confermano, e smettiamo di cercare quando ne abbiamo trovata una. Alcune contromisure pratiche. Applicare lo stesso livello di verifica a ciò che ci piace e a ciò che non ci piace, magari con una checklist fissa. Cercare attivamente le evidenze contrarie: 'che cosa dovrei trovare se avessi torto?'. Chiedere all'AI gli argomenti contro la propria tesi, come visto nel Tema 5. Quando possibile, far verificare a qualcuno che non ha preferenze sul risultato.");
    flowTag(s, -1);
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiAlertTriangle", head: "Come agisce", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Verifica indulgente con ciò che conferma", "Severa con ciò che contraddice", "Domande che contengono già la risposta desiderata", "Ci si ferma alla prima fonte che conferma"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiShield", head: "Contromisure", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Stesso livello di verifica, con una checklist fissa", "\"Che cosa troverei se avessi torto?\"", "Chiedere all'AI gli argomenti contrari", "Far verificare a chi non ha preferenze"], { space: 3 }) });
    banner(s, 4.0, "Il rischio: una verifica asimmetrica, severa con le informazioni scomode e indulgente con quelle gradite.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Fluidità, sicurezza e autorevolezza", "Tre bias collegati spiegano perché gli output dell'AI ci convincono facilmente. La fluidità: le ricerche in psicologia cognitiva hanno mostrato che le informazioni facili da elaborare, per esempio scritte in modo chiaro e leggibile, tendono a essere giudicate più vere. Un lavoro noto in questo campo è quello di Rolf Reber e Norbert Schwarz del 1999. I testi generati dall'AI sono quasi sempre molto fluidi. La sicurezza espressiva: le affermazioni fatte con sicurezza, senza esitazioni, ci sembrano più credibili, perché tra persone la sicurezza è spesso un segnale di competenza. Ma, come visto nel 7.2, il tono di un sistema AI non misura la sua correttezza. L'autorevolezza apparente: lessico tecnico, struttura professionale, citazioni, numeri precisi attivano la nostra fiducia, anche quando il contenuto non la merita. Questi tre effetti agiscono insieme e in modo largamente automatico: non si eliminano con la consapevolezza, ma si possono contrastare con il metodo. Le contromisure sono quelle già viste: separare il giudizio sulla forma da quello sulla sostanza, chiedersi su che cosa si basa ogni affermazione, controllare i punti critici indipendentemente da quanto suonano convincenti.");
    flowTag(s, -1);
    const e = [["FiFeather", "Fluidità", "Ciò che è facile da leggere sembra più vero", "Reber e Schwarz, 1999"], ["FiVolume2", "Sicurezza espressiva", "Il tono sicuro sembra competenza", "Ma non misura la correttezza"], ["FiAward", "Autorevolezza apparente", "Lessico tecnico, struttura, citazioni, numeri", "Attivano fiducia anche se immeritata"]];
    for (let i = 0; i < 3; i++) await card(s, 0.5 + i * 3.07, 1.2, 2.86, 2.6, { icon: e[i][0], head: e[i][1], headSize: 15, bodySize: 12,
      body: [{ text: e[i][2], options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 10 } }, { text: e[i][3], options: { italic: true } }] });
    banner(s, 4.0, "Agiscono in modo automatico: non si eliminano con la consapevolezza, si contrastano con il metodo.", { h: 0.9 });
  }
  {
    const s = content("Troppa fiducia, troppo poca fiducia", "Due errori opposti, entrambi da evitare. L'eccessiva fiducia, insieme all'automation bias e all'accettazione passiva, porta a usare output non verificati, a non accorgersi degli errori, a delegare il giudizio. Si rafforza con l'esperienza: dopo molte risposte corrette, si smette di controllare, proprio quando l'errore occasionale diventa più difficile da notare. La sfiducia non giustificata porta a scartare output validi, a rifare da capo lavori che erano corretti, a perdere i benefici dell'AI, e talvolta a una verifica eccessiva che consuma tempo senza aggiungere valore. Si alimenta spesso di un'esperienza negativa, generalizzata a tutti gli usi. Entrambi gli errori hanno la stessa radice: la fiducia non è calibrata sulle evidenze, ma su impressioni generali. La soluzione è la stessa vista in tutto il percorso: una fiducia calibrata, che varia in base al compito, al sistema, alle evidenze disponibili e alle conseguenze di un errore. Domanda per il gruppo: in quale dei due errori cadete più spesso, e in quali situazioni?");
    flowTag(s, -1);
    await card(s, 0.5, 1.2, 4.35, 2.8, { icon: "FiThumbsUp", head: "Eccessiva fiducia", headSize: 16, bodySize: 12,
      body: bullets(["Output usati senza verifica", "Errori non notati, giudizio delegato", "Cresce con le esperienze positive"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.8, { icon: "FiThumbsDown", head: "Sfiducia non giustificata", headSize: 16, bodySize: 12,
      body: bullets(["Output validi scartati", "Lavori corretti rifatti, verifiche eccessive", "Nasce spesso da un'esperienza negativa generalizzata"], { space: 4 }) });
    banner(s, 4.15, "Stessa radice: fiducia basata su impressioni, non su evidenze. La soluzione: fiducia calibrata.", { h: 0.8 });
  }
  {
    const s = content("Preservare l'autonomia cognitiva", "Nel Tema 5 abbiamo visto il rischio della delega cognitiva e alcune pratiche per preservare l'autonomia. Qui le declinamo nella valutazione degli output, come strategie concrete contro i bias. Formarsi un'opinione prima di leggere l'output, anche sommaria: dà un termine di confronto e riduce l'ancoraggio alla risposta del sistema. Usare checklist e criteri fissati in anticipo: rendono la verifica meno dipendente dall'impressione del momento e dal fatto che il risultato ci piaccia. Considerare l'opposto: chiedersi esplicitamente perché la conclusione potrebbe essere sbagliata. Rallentare sui punti critici: la lettura veloce favorisce i giudizi automatici, quella lenta e mirata il ragionamento. Separare produzione e verifica: lasciare passare del tempo, o affidare la verifica a un'altra persona. Tenere traccia degli errori trovati: sapere dove il sistema ha sbagliato in passato aiuta a calibrare la fiducia futura, in un senso o nell'altro. Il concetto chiave del sottotema lo ricorda: l'affidabilità del processo dipende anche dall'atteggiamento di chi valuta. Il miglior sistema di verifica fallisce se chi lo applica non si accorge dei propri bias.");
    flowTag(s, -1);
    const p = [["FiZap", "Opinione prima della lettura", "Un termine di confronto contro l'ancoraggio"], ["FiList", "Checklist fissate in anticipo", "Meno dipendenza dall'impressione"], ["FiRepeat", "Considerare l'opposto", "Perché potrebbe essere sbagliata?"], ["FiClock", "Rallentare sui punti critici", "Dal giudizio automatico al ragionamento"], ["FiUsers", "Separare produzione e verifica", "Tempo o un'altra persona"], ["FiBookmark", "Tenere traccia degli errori", "Per calibrare la fiducia futura"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 3, { y: 1.2, H: 3.1, headSize: 13, bodySize: 12 });
    banner(s, 4.5, "Il miglior metodo di verifica fallisce se chi lo applica non si accorge dei propri bias.", { h: 0.5, fontSize: 13 });
  }
  keySlide("L'affidabilità del processo dipende anche dall'atteggiamento di chi valuta il risultato e dalla capacità di riconoscere i propri bias.", "Sottotema 7.7  ·  Bias cognitivi e fiducia nell'AI", "Concetto chiave. Bias di conferma, automation bias, fluidità, sicurezza espressiva e autorevolezza apparente spingono verso la fiducia eccessiva; la sfiducia non giustificata è l'errore opposto. Sono tendenze comuni e in parte automatiche, che si contrastano con il metodo: opinione prima della lettura, checklist fisse, considerare l'opposto, rallentare, separare produzione e verifica, tenere traccia degli errori. Domanda di verifica: ripensate a un output dell'AI che avete usato di recente. L'avreste controllato con la stessa severità se avesse detto il contrario di ciò che pensavate?");

  // =====================================================================
  section("7.8 Validazione e responsabilità");
  divider("7.8", "Validazione e responsabilità nell'uso", "Validare significa decidere se un output, con le verifiche fatte e le incertezze residue, è adeguato a uno specifico utilizzo", "Arriviamo all'ultima fase della sequenza: decidere. Abbiamo valutato l'output e verificato ciò che lo richiedeva; ora dobbiamo stabilire se usarlo, e come. È un sottotema di consapevolezza decisionale, che porta due integrazioni importanti: la gestione dell'incertezza residua e l'economia della verifica, cioè la proporzionalità dei controlli. Il 7.2 valutava la qualità del contenuto; qui ne valutiamo l'utilizzabilità in un contesto concreto. La responsabilità è trattata come consapevolezza operativa, non nei suoi aspetti giuridici.");
  {
    const s = content("Plausibile, verificato, validato", "Tre parole che descrivono tre stati diversi di un output. Plausibile: sembra corretto, è ben scritto, coerente, credibile. È lo stato in cui si trova quasi ogni output dell'AI appena generato, e non dice nulla sulla correttezza. Verificato: gli elementi che lo richiedevano sono stati controllati con evidenze indipendenti, come fonti, dati, calcoli, esperti. È un passo avanti decisivo, ma non ancora sufficiente. Validato: si è deciso che l'output, con le verifiche fatte e le incertezze che restano, è adeguato a uno specifico utilizzo. La validazione aggiunge alla verifica due elementi: lo scopo e la decisione. Un output può essere verificato e non validato: per esempio, un'analisi corretta nei dati ma troppo generica per sostenere la decisione per cui serviva, o un testo accurato ma inadatto al destinatario. E lo stesso output può essere validato per un uso e non per un altro: una sintesi adeguata per una discussione interna può non esserlo per un documento ufficiale. Il criterio di approfondimento del documento lo dice così: un risultato apparentemente corretto non è necessariamente verificato; un risultato verificato può comunque non essere adeguato a un utilizzo specifico.");
    flowTag(s, 2);
    const st = [["Plausibile", "Sembra corretto: ben scritto, coerente, credibile", "Quasi ogni output appena generato", C.background2, C.text1], ["Verificato", "I punti critici sono stati controllati con evidenze indipendenti", "Decisivo, ma non sufficiente", C.accent6, C.text1], ["Validato", "Si è deciso che è adeguato a uno specifico utilizzo", "Aggiunge scopo e decisione", C.accent1, C.background1]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.5, st[i][3], st[i][0]);
      txt(s, st[i][0], { x: x + 0.2, y: 1.32, w: 2.46, h: 0.45, fontSize: 19, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, st[i][1], { x: x + 0.2, y: 1.85, w: 2.46, h: 0.95, fontSize: 13, color: st[i][4] });
      txt(s, st[i][2], { x: x + 0.2, y: 2.9, w: 2.46, h: 0.7, fontSize: 12, bold: true, italic: true, color: i === 2 ? C.accent6 : C.text2 });
      if (i < 2) arrow(s, x + 2.88, 2.3, 0.17);
    }
    banner(s, 3.9, "Verificato non significa validato: un'analisi corretta ma troppo generica per la decisione. Validato per un uso, non per un altro.", { h: 1.05, fontSize: 13 });
  }
  {
    const s = content("Adeguatezza allo scopo e conseguenze", "La validazione parte da due domande. La prima riguarda l'adeguatezza allo scopo: il risultato serve davvero all'uso previsto? È al livello di dettaglio, di precisione, di affidabilità richiesto? Risponde alla domanda che conta, per il destinatario che lo userà? Un risultato può essere corretto e inadeguato, come abbiamo appena visto. La seconda riguarda le conseguenze di un errore: se l'output contenesse un errore non individuato, che cosa succederebbe? Nel Tema 3 abbiamo visto quattro dimensioni delle conseguenze: gravità, reversibilità, chi le subisce, rilevabilità. Qui le usiamo per decidere quanto approfondire la verifica e se accettare il risultato. Un errore in una bozza interna che verrà rivista ha conseguenze minime; un errore in un'offerta inviata a un cliente, in una comunicazione a tutti i dipendenti, in un dato che alimenta una decisione d'investimento, può avere conseguenze serie e difficili da correggere. Le due domande insieme definiscono il livello di controllo necessario, e quindi il punto in cui la validazione può essere considerata raggiunta.");
    flowTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.9, { icon: "FiTarget", head: "Adeguatezza allo scopo", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Serve all'uso previsto?", "Dettaglio, precisione, affidabilità richiesti?", "Risponde alla domanda che conta, per chi lo userà?"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.9, { icon: "FiAlertTriangle", head: "Conseguenze di un errore", headSize: 16, bodySize: 13,
      body: bullets(["Gravità", "Reversibilità", "Chi le subisce", "Rilevabilità"], { space: 4 }) });
    banner(s, 4.3, "Insieme definiscono il livello di controllo necessario e il punto in cui la validazione è raggiunta.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("L'economia della verifica", "Questa integrazione del sottotema affronta un problema molto concreto: la verifica costa tempo. Se ogni output dovesse essere verificato in ogni dettaglio, l'AI non farebbe risparmiare nulla; se non si verificasse nulla, gli errori passerebbero. L'economia della verifica propone di graduare impegno e profondità del controllo in funzione di due fattori: la probabilità dell'errore e il suo impatto. La matrice in slide li combina. Probabilità bassa e impatto basso: una rilettura è sufficiente. Probabilità alta e impatto basso: controlli rapidi e mirati, per esempio sui numeri. Probabilità bassa e impatto alto: verifica dei punti critici, perché anche un errore raro avrebbe conseguenze serie. Probabilità alta e impatto alto: verifica approfondita e, se serve, intervento di un esperto. La probabilità dipende da ciò che abbiamo visto nel Tema 3 e in questo modulo: tipo di contenuto, numeri, fonti, argomenti di nicchia, complessità. L'impatto dipende dall'uso. Il principio evita due errori opposti, indicati dal documento: la verifica indiscriminata di ogni dettaglio, che spreca tempo e non migliora la qualità; e i controlli insufficienti per impieghi critici, che espongono a errori gravi.");
    flowTag(s, 2);
    txt(s, "Impatto basso", { x: 1.6, y: 1.12, w: 3.6, h: 0.3, fontSize: 12, bold: true, color: C.accent2, align: "center" });
    txt(s, "Impatto alto", { x: 5.4, y: 1.12, w: 3.6, h: 0.3, fontSize: 12, bold: true, color: C.accent2, align: "center" });
    txt(s, "Probabilità bassa", { x: 0.5, y: 1.45, w: 1.05, h: 1.4, fontSize: 11, bold: true, color: C.accent2, valign: "middle" });
    txt(s, "Probabilità alta", { x: 0.5, y: 3.0, w: 1.05, h: 1.4, fontSize: 11, bold: true, color: C.accent2, valign: "middle" });
    const q = [["Rilettura", "Sufficiente una lettura attenta", C.accent6, C.text1], ["Verifica dei punti critici", "Anche un errore raro avrebbe conseguenze serie", C.background2, C.text1], ["Controlli rapidi e mirati", "Per esempio sui numeri e sui nomi", C.background2, C.text1], ["Verifica approfondita", "Fonti indipendenti e, se serve, un esperto", C.text1, C.background1]];
    for (let i = 0; i < 4; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 1.6 + col * 3.8, y = 1.45 + row * 1.55;
      shapeBox(s, x, y, 3.65, 1.4, q[i][2], q[i][0]);
      txt(s, q[i][0], { x: x + 0.2, y: y + 0.12, w: 3.25, h: 0.4, fontSize: 15, bold: true, color: q[i][3] });
      txt(s, q[i][1], { x: x + 0.2, y: y + 0.6, w: 3.25, h: 0.7, fontSize: 12, color: q[i][3] });
    }
    txt(s, "Evitare sia la verifica indiscriminata di ogni dettaglio sia controlli insufficienti per gli usi critici.", { x: 0.5, y: 4.6, w: 9, h: 0.4, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Rapporto tra costo della verifica e rischio", "L'economia della verifica si traduce in alcune scelte pratiche. Identificare le informazioni più critiche: in quasi ogni output, poche affermazioni portano gran parte del peso, cioè quelle su cui si basa la decisione, quelle visibili all'esterno, quelle con conseguenze economiche o legali. Concentrare lì la verifica è il modo più efficiente per ridurre il rischio. Confrontare il costo della verifica con il rischio: se verificare un dato richiede dieci minuti e un errore costerebbe una figuraccia con un cliente importante, la verifica conviene; se verificare tutti i dettagli di una bozza interna richiede un'ora, probabilmente no. Considerare il costo di non usare l'AI: se la verifica richiesta è così ampia da superare il tempo necessario per fare il lavoro direttamente, forse per quel compito l'AI non è lo strumento giusto, come visto nel Tema 3. Riutilizzare le verifiche: per compiti ricorrenti, una verifica approfondita iniziale su un campione di casi, come visto nel Tema 3, può giustificare controlli più leggeri successivamente, con revisioni periodiche. Il risultato è una verifica proporzionata: abbastanza per l'uso previsto, non di più, non di meno.");
    flowTag(s, 2);
    const p = [["FiCrosshair", "Identificare le informazioni critiche", "Poche affermazioni portano gran parte del peso: concentrare lì la verifica"], ["FiDollarSign", "Costo della verifica contro rischio", "Dieci minuti contro una figuraccia con un cliente importante"], ["FiXCircle", "Il costo di non usare l'AI", "Se verificare costa più che fare da sé, forse non è lo strumento giusto"], ["FiRepeat", "Riutilizzare le verifiche", "Per i compiti ricorrenti: verifica iniziale su un campione, poi controlli più leggeri"]];
    await iconGrid(s, p.map(e => ({ icon: e[0], head: e[1], body: e[2] })), 2, { y: 1.2, H: 2.95, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Verifica proporzionata: abbastanza per l'uso previsto, non di più, non di meno.", { h: 0.6 });
  }
  {
    const s = content("Le incertezze residue", "Ritroviamo qui l'integrazione sull'incertezza, applicata alla decisione. Anche dopo la verifica, quasi sempre resta qualcosa di incerto: informazioni non verificabili, stime, ipotesi, punti che non è stato possibile controllare per mancanza di tempo o di fonti. Il documento di perimetro sottolinea che la decisione sull'utilizzo deve tenere conto di ciò che resta incerto, non solo di ciò che è stato verificato. È un errore frequente considerare un output 'verificato' perché i punti controllati sono risultati corretti, dimenticando quelli non controllati. Tre passi aiutano. Rendere esplicite le incertezze residue: che cosa non sappiamo con certezza? Valutarne l'impatto: se queste informazioni fossero sbagliate, la conclusione o l'uso cambierebbero? Decidere di conseguenza: accettare l'incertezza, se l'impatto è basso; ridurla con ulteriori verifiche, se è possibile e conveniente; comunicarla al destinatario, se deve tenerne conto; oppure rinunciare all'uso, se è troppo alta. Comunicare l'incertezza in modo onesto, per esempio indicando che un dato è stimato o non verificato, è un segno di professionalità, non di debolezza.");
    flowTag(s, 2);
    const st = [["FiEye", "Rendere esplicite", "Che cosa non sappiamo con certezza?"], ["FiActivity", "Valutarne l'impatto", "Se fosse sbagliato, cambierebbe la conclusione?"], ["FiCheckSquare", "Decidere", "Accettare, ridurre, comunicare o rinunciare"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.1, i === 2 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.2, 1.35, 0.55, st[i][0]);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.9, y: 1.35, w: 1.9, h: 0.55, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, st[i][2], { x: x + 0.2, y: 2.1, w: 2.46, h: 1.0, fontSize: 13, color: C.text2 });
      if (i < 2) arrow(s, x + 2.88, 2.1, 0.17);
    }
    banner(s, 3.5, "La decisione tiene conto di ciò che resta incerto, non solo di ciò che è stato verificato.", { h: 0.7 });
    txt(s, "Comunicare l'incertezza con onestà, per esempio indicando che un dato è stimato, è un segno di professionalità.", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Competenze specialistiche e decisione", "Due elementi chiudono il processo. Il coinvolgimento di competenze specialistiche: quando l'output riguarda un ambito in cui chi valuta non ha competenze sufficienti per riconoscere gli errori, come aspetti legali, fiscali, medici, tecnici, di sicurezza, e le conseguenze sono rilevanti, la validazione richiede il parere di un esperto. È la risposta all'ultima domanda guida: quando coinvolgere un esperto o non usare l'output. La decisione finale, che può avere quattro esiti. Accettare: l'output è adeguato allo scopo, con le verifiche fatte e le incertezze accettabili. Modificare: l'output è utilizzabile dopo correzioni, integrazioni, riformulazioni. Approfondire: servono ulteriori verifiche, informazioni o il parere di un esperto prima di decidere. Rifiutare: l'output non è adeguato, contiene errori sostanziali, o le incertezze sono troppo alte per l'uso previsto. Rifiutare non è un fallimento: è l'esito corretto quando l'output non regge all'esame, e può portare a rifare il lavoro diversamente, con o senza l'AI. Il concetto chiave lo definisce così: validare significa decidere se un output, con le verifiche appropriate e le incertezze residue, è adeguato a uno specifico utilizzo.");
    flowTag(s, 2);
    shapeBox(s, 0.5, 1.2, 9.0, 0.9, C.background2, "esperto");
    await iconCircle(s, 0.7, 1.4, 0.5, "FiAward");
    txt(s, [{ text: "Coinvolgere un esperto ", options: { bold: true, color: C.text1 } }, { text: "quando mancano le competenze per riconoscere gli errori e le conseguenze sono rilevanti: aspetti legali, fiscali, medici, tecnici, di sicurezza.", options: { color: C.text2 } }], { x: 1.35, y: 1.2, w: 8.0, h: 0.9, fontSize: 13, valign: "middle" });
    const d = [["FiCheck", "Accettare", "Adeguato allo scopo, incertezze accettabili", C.accent1, C.background1], ["FiEdit", "Modificare", "Utilizzabile dopo correzioni e integrazioni", C.accent6, C.text1], ["FiSearch", "Approfondire", "Servono verifiche, informazioni o un esperto", C.background2, C.text1], ["FiXCircle", "Rifiutare", "Non adeguato: errori sostanziali o incertezze troppo alte", C.text1, C.background1]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 2.3, 2.15, 2.0, d[i][3], d[i][1]);
      await iconCircle(s, x + 0.78, 2.42, 0.58, d[i][0], i === 0 || i === 3 ? C.background1 : C.accent1, i === 0 ? HEX.a1 : (i === 3 ? HEX.dk1 : HEX.lt1));
      txt(s, d[i][1], { x: x + 0.1, y: 3.05, w: 1.95, h: 0.4, fontSize: 15, bold: true, color: d[i][4], align: "center" });
      txt(s, d[i][2], { x: x + 0.15, y: 3.45, w: 1.85, h: 0.8, fontSize: 11, color: d[i][4], align: "center" });
    }
    txt(s, "Rifiutare non è un fallimento: è l'esito corretto quando l'output non regge all'esame.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Documentare e assumere la responsabilità", "Gli ultimi due punti del sottotema. La documentazione delle verifiche, quando necessaria: per gli output importanti, come documenti esterni, dati per decisioni rilevanti, contenuti soggetti a controllo, conviene tenere traccia di che cosa è stato verificato, con quali fonti, da chi e quando, e di quali incertezze restano. Non serve per ogni bozza, ma per ciò che potrebbe essere riesaminato o contestato. La documentazione permette di ricostruire il processo, di rispondere a domande sul risultato, di correggere rapidamente se emerge un errore, e di imparare dagli errori trovati. È collegata alla tracciabilità vista nel Tema 3 e nel 7.5. Le regole aziendali su quando e come documentare appartengono all'area della responsabilità e della normativa. La responsabilità nell'utilizzo dei risultati: riprendiamo il principio che attraversa tutto il percorso. Chi usa un output dell'AI ne risponde come se l'avesse prodotto personalmente. La validazione è il momento in cui questa responsabilità si esercita concretamente: decidere di usare un risultato significa assumersene la responsabilità. Ed è il motivo per cui valutare, verificare e decidere non sono attività accessorie, ma parte essenziale dell'uso consapevole dell'AI.");
    flowTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 3.0, { icon: "FiFileText", head: "Documentare, quando necessario", headSize: 15, bodySize: 12,
      body: [{ text: "Che cosa è stato verificato, con quali fonti, da chi, quando; quali incertezze restano.", options: { bold: true, color: C.text1, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["Per ciò che potrebbe essere riesaminato o contestato", "Permette di ricostruire, correggere, imparare"], { space: 3 })) });
    shapeBox(s, 5.15, 1.2, 4.35, 3.0, C.text1, "responsabilità");
    await iconCircle(s, 5.4, 1.4, 0.6, "FiUserCheck", C.accent1);
    txt(s, "Decidere di usare un risultato significa assumersene la responsabilità.", { x: 5.4, y: 2.15, w: 3.9, h: 1.0, fontSize: 16, bold: true, color: C.background1 });
    txt(s, "Chi usa un output dell'AI ne risponde come se l'avesse prodotto personalmente.", { x: 5.4, y: 3.2, w: 3.9, h: 0.85, fontSize: 13, color: C.accent3 });
    banner(s, 4.4, "Valutare, verificare e decidere non sono attività accessorie, ma parte essenziale dell'uso consapevole dell'AI.", { h: 0.55, fontSize: 12 });
  }
  keySlide("Validare significa decidere se un output, con le verifiche appropriate e le incertezze residue, sia adeguato a uno specifico utilizzo.", "Sottotema 7.8  ·  Validazione e responsabilità nell'uso", "Concetto chiave dell'ultimo sottotema. Plausibile, verificato e validato sono stati diversi. La validazione considera l'adeguatezza allo scopo e le conseguenze di un errore, gradua la verifica secondo probabilità e impatto, tiene conto delle incertezze residue, coinvolge esperti quando servono e si conclude con una decisione: accettare, modificare, approfondire o rifiutare. Quando necessario, le verifiche si documentano. E chi decide di usare un risultato ne assume la responsabilità. Esercizio suggerito: presentare tre output con usi diversi, per esempio una bozza interna, una comunicazione a un cliente e un dato per una decisione d'investimento, e chiedere ai partecipanti quale livello di verifica applicherebbero e quale decisione prenderebbero.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle undici domande guida. Convincente o corretta: si giudica la sostanza, separata dalla forma, sulle evidenze. Che cosa rende un output utilizzabile: accuratezza, pertinenza, completezza, coerenza, chiarezza. Che cosa manca: partire dalle attese, cercare eccezioni e l'altra metà, confrontare con la fonte. Fonti: autentiche, pertinenti, di supporto. Ragionamenti: scomporre in dati, premesse e conclusione, e cercare i difetti tipici. Numeri: dati di partenza, formule, unità, plausibilità, ricalcolo indipendente. Autoverifica e verifica indipendente: la prima trova i punti dubbi, solo la seconda fornisce prove. Bias: conferma, automation bias, fluidità; e la sfiducia ingiustificata. Fatti e incertezze: livelli diversi, che il tono non rivela. Livello di verifica: proporzionato a probabilità e impatto dell'errore. Quando un esperto o il rifiuto: quando mancano le competenze, le conseguenze sono rilevanti o le incertezze troppo alte. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Convincente o corretta?", "Sostanza separata dalla forma, sulle evidenze"], ["Che cosa rende un output utilizzabile?", "Accuratezza, pertinenza, completezza, coerenza"], ["Che cosa manca?", "Attese, eccezioni, l'altra metà, la fonte"], ["La fonte sostiene l'affermazione?", "Autentica, pertinente, di supporto"], ["Premesse e conclusioni?", "Scomporre e cercare i difetti tipici"], ["Numeri, formule, grafici?", "Dati, unità, plausibilità, ricalcolo"], ["Autoverifica o verifica?", "La prima trova dubbi, la seconda prove"], ["Quali bias?", "Conferma, automazione, fluidità, sfiducia"], ["Fatti o incertezze?", "Livelli diversi, il tono non li rivela"], ["Quale livello di verifica?", "Proporzionato a probabilità e impatto"], ["Esperto o rifiuto?", "Competenze mancanti, conseguenze, incertezza"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.6, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.6, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.03, w: 3.8, h: 0.28, fontSize: 11, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.3, w: 3.8, h: 0.28, fontSize: 10, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere plausibilità e correttezza; valutare pertinenza, accuratezza, completezza e coerenza; identificare le affermazioni da verificare; controllare fonti e riferimenti in modo indipendente; riconoscere conclusioni non giustificate, premesse incomplete e passaggi logici deboli; individuare omissioni, ipotesi implicite ed eccezioni; verificare dati, calcoli e risultati quantitativi; usare l'AI come supporto alla revisione senza confondere autoverifica e verifica indipendente; riconoscere i propri bias e regolare la fiducia; distinguere fatti verificati, supposizioni e incertezze residue; applicare controlli proporzionati al rischio; decidere quando accettare, modificare, approfondire o rifiutare un output.");
    const r = ["Distinguere plausibilità e correttezza", "Valutare pertinenza, accuratezza, completezza, coerenza", "Identificare le affermazioni da verificare", "Controllare fonti in modo indipendente", "Riconoscere conclusioni non giustificate", "Individuare omissioni, ipotesi, eccezioni", "Verificare dati e calcoli", "Distinguere autoverifica e verifica indipendente", "Riconoscere i propri bias e regolare la fiducia", "Distinguere fatti, supposizioni, incertezze", "Controlli proporzionati al rischio", "Accettare, modificare, approfondire, rifiutare"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Valutare, verificare, decidere: una scheda pratica", "Traduciamo il modulo in una scheda pratica, da usare per gli output importanti. Valutare: che cosa sostiene l'output? Distinguere fatti, opinioni, ipotesi e interpretazioni. È pertinente, completo, coerente? Che cosa manca? Il ragionamento regge? Verificare: quali sono i punti critici, per importanza, rischio di errore e visibilità? Controllarli su fonti primarie e indipendenti; ricalcolare i numeri importanti; usare la revisione assistita dall'AI per trovare i punti dubbi, non come prova. Decidere: l'output è adeguato allo scopo? Quali incertezze restano e quanto pesano? Serve un esperto? Accettare, modificare, approfondire o rifiutare; documentare se necessario. E per tutto il processo: attenzione ai propri bias, con un'opinione formata prima di leggere e gli stessi controlli per ciò che piace e ciò che non piace. La scheda non è una procedura obbligatoria: per una bozza interna si riduce a pochi secondi di attenzione, per un documento critico diventa un processo strutturato.");
    const f = [["Valutare", ["Che cosa sostiene? Fatti, opinioni, ipotesi, interpretazioni", "Pertinente, completo, coerente? Che cosa manca?", "Il ragionamento regge?"], C.background2], ["Verificare", ["Punti critici: importanza, rischio, visibilità", "Fonti primarie e indipendenti; ricalcolo dei numeri", "Revisione assistita per trovare i dubbi, non come prova"], C.accent6], ["Decidere", ["Adeguato allo scopo? Quali incertezze restano?", "Serve un esperto?", "Accettare, modificare, approfondire, rifiutare; documentare"], C.background2]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 3.0, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.2, y: 1.25, w: 2.46, h: 0.42, fontSize: 18, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.2, y: 1.75, w: 2.5, h: 2.3, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: attenzione ai propri bias. Opinione prima di leggere, stessi controlli per ciò che piace e ciò che no.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei errori tipici nella verifica degli output, uno per ciascuno dei principali messaggi del modulo. Primo: 'è scritto bene, quindi è giusto'. La qualità espressiva è quasi sempre alta e non dice nulla sulla sostanza. Secondo: 'c'è la fonte, quindi è vero'. Una citazione non è una prova: la fonte deve esistere, essere pertinente e sostenere davvero l'affermazione. Terzo: 'i numeri tornano', senza averli ricalcolati. Un risultato quantitativo che serve a decidere va ricondotto a dati e procedimenti controllabili, con uno strumento indipendente. Quarto: 'gliel'ho chiesto due volte'. Chiedere conferma allo stesso sistema non è una verifica indipendente: può confermare l'errore o cambiare una risposta giusta. Quinto: 'verifico solo ciò che non mi convince'. È il bias di conferma: la verifica deve essere ugualmente severa con ciò che ci piace. Sesto: 'verifico tutto allo stesso modo'. La verifica va proporzionata a probabilità e impatto dell'errore: né controlli indiscriminati, né controlli insufficienti per gli usi critici. Suggerimento: chiedere ai partecipanti quale di questi errori hanno visto più spesso, in sé o negli altri.");
    const a = [["FiFeather", "\"È scritto bene, quindi è giusto\"", "La forma non dice nulla sulla sostanza", "7.2"], ["FiLink", "\"C'è la fonte, quindi è vero\"", "Autentica, pertinente, di supporto", "7.3"], ["FiHash", "\"I numeri tornano\"", "Ricalcolare con uno strumento indipendente", "7.5"], ["FiRepeat", "\"Gliel'ho chiesto due volte\"", "Chiedere conferma non è verificare", "7.6"], ["FiThumbsUp", "\"Verifico ciò che non mi convince\"", "Stessa severità con ciò che piace", "7.7"], ["FiSliders", "\"Verifico tutto allo stesso modo\"", "Controlli proporzionati al rischio", "7.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 7 si conclude l'area 'Interagire con l'AI', che ha seguito l'intero ciclo dell'interazione: il dialogo e la collaborazione nel Tema 5, la formulazione delle richieste nel Tema 6, la valutazione e la verifica dei risultati in questo tema. Insieme all'area 'Comprendere l'AI', costituisce la base di competenze trasversali del percorso. Con il Tema 8 si apre una nuova area, 'Esplorare le possibilità dell'AI', che guarda a che cosa si può fare concretamente nei diversi ambiti di lavoro. Il Tema 8 è dedicato all'AI per testi, documenti e conoscenza: generare e trasformare testi, sintetizzare e analizzare documenti, estrarre informazioni strutturate, confrontare documenti, fare ricerca e interrogare raccolte documentali. Seguirà il Tema 9, dedicato all'AI per dati e analisi. In tutti questi ambiti, la capacità di valutare, verificare e decidere costruita in questo modulo sarà applicata a contenuti concreti: la fedeltà di una sintesi, l'accuratezza di un'estrazione, la tracciabilità verso le fonti. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree completate");
    txt(s, "AREE COMPLETATE", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.75, w: 3.9, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    txt(s, "Temi 1-4: rilevanza, funzionamento, affidabilità, ecosistema", { x: 0.75, y: 2.1, w: 3.9, h: 0.6, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.85, w: 3.9, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    txt(s, "Temi 5-7: dialogo, prompting, verifica e pensiero critico", { x: 0.75, y: 3.2, w: 3.9, h: 0.6, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "NUOVA AREA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 5.4, y: 1.72, w: 3.9, h: 0.4, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Tema 8: AI per testi, documenti e conoscenza", { x: 5.4, y: 2.2, w: 3.9, h: 0.6, fontSize: 14, bold: true, color: C.accent6 });
    txt(s, bullets(["Generare e trasformare testi", "Sintesi, estrazione, confronto", "Ricerca e conoscenza interrogabile"], { space: 5 }), { x: 5.4, y: 2.85, w: 3.9, h: 1.2, fontSize: 12, color: C.background1 });
    txt(s, "Poi il Tema 9: AI per dati e analisi", { x: 5.4, y: 4.3, w: 3.9, h: 0.35, fontSize: 12, italic: true, color: C.accent3 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Il caso Avianca e lo studio di Sharma e colleghi sono già presentati nel Tema 3 (affidabilità e compiacenza), qui richiamati. Le pagine di Reber e Schwarz sono indicate a memoria: da verificare. Il modulo si basa soprattutto su principi consolidati di pensiero critico, analisi delle fonti e lettura dei dati, che non dipendono da una singola fonte. Prima di ogni edizione è consigliabile verificare se ci sono casi recenti o studi utili da aggiungere, in particolare sull'efficacia della revisione assistita dall'AI, che è un campo in rapida evoluzione.");
    const src = [
      "Reber, R., Schwarz, N. (1999). Effects of Perceptual Fluency on Judgments of Truth. Consciousness and Cognition, 8(3), 338-342.",
      "Parasuraman, R., Manzey, D. H. (2010). Complacency and Bias in Human Use of Automation: An Attentional Integration. Human Factors, 52(3), 381-410.",
      "Mata v. Avianca, Inc., U.S. District Court, Southern District of New York, giugno 2023.",
      "Sharma, M. et al. (2024). Towards Understanding Sycophancy in Language Models. ICLR 2024 (Anthropic).",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema7_Verifica_output_pensiero_critico.pptx" });
  await applyTheme("Tema7_Verifica_output_pensiero_critico.pptx", THEME);
  console.log("done");
})();
