
  // =====================================================================
  section("13.3 Dal compito al processo");
  divider("13.3", "Dal compito al processo", "Introdurre AI in un processo non equivale automaticamente a riprogettarlo o migliorarlo", "Passiamo dai compiti ai processi. È uno dei sottotemi su cui il documento chiede di approfondire di più, ed è da comprendere e applicare. Nel Tema 12 abbiamo visto, dal punto di vista del valore, che accelerare un'attività non migliora necessariamente il processo. Qui guardiamo al processo dal punto di vista del lavoro: come cambiano le sequenze, i passaggi, i controlli, i punti di intervento umano. E due integrazioni: il rischio di automatizzare processi inefficienti, e il fatto che la trasformazione può creare nuovo lavoro. Il Business Process Reengineering e la progettazione organizzativa avanzata sono solo da accennare.");
  {
    const s = content("Compito e processo", "Il primo punto del sottotema è la differenza tra compito e processo, già introdotta. Un compito è un'unità di lavoro; un processo è una sequenza di attività interdipendenti, svolte da persone e sistemi diversi, che produce un risultato per un cliente, interno o esterno. Le interdipendenze sono la caratteristica chiave del processo: l'output di un'attività è l'input della successiva; un ritardo in un punto si propaga; un errore in un punto si ritrova più avanti; un cambiamento in un'attività può richiedere cambiamenti in altre. Applicare l'AI a un singolo passaggio di un processo, senza considerare le interdipendenze, produce tre effetti possibili. Nel caso migliore, il miglioramento del passaggio si traduce in un miglioramento del processo. Spesso, il miglioramento resta locale, perché il collo di bottiglia è altrove, come visto nel Tema 12. A volte, il miglioramento locale peggiora il processo: più volume prodotto in una fase crea code nella successiva; più velocità riduce la qualità che una fase successiva deve correggere; un nuovo formato di output non è compatibile con ciò che la fase successiva si aspetta. La consapevolezza del sottotema: introdurre AI in un processo non equivale automaticamente a riprogettarlo o migliorarlo.");
    workTag(s, 1);
    const st = ["Attività A", "Attività B", "Attività C", "Risultato"];
    st.forEach((t, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, t, { fill: i === 1 ? C.accent1 : (i === 3 ? C.text1 : C.background2), color: i === 1 || i === 3 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    txt(s, "AI applicata a B", { x: 2.8, y: 1.9, w: 2.05, h: 0.3, fontSize: 11, italic: true, bold: true, color: C.accent1, align: "center" });
    const r = [["Il processo migliora", "Il caso migliore", C.accent6], ["Il miglioramento resta locale", "Il collo di bottiglia è altrove", C.background2], ["Il processo peggiora", "Code dopo, qualità da correggere, formati incompatibili", C.background2]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.4, 2.86, 1.2, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 2.48, w: 2.56, h: 0.4, fontSize: 13, bold: true, color: i === 2 ? C.accent5 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 2.9, w: 2.56, h: 0.65, fontSize: 12, color: C.text1 });
    });
    banner(s, 3.85, "Le interdipendenze sono la chiave: l'output di un'attività è l'input della successiva.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Un processo trasformato", "Il documento propone un esempio illustrativo, che mostra come può cambiare un processo: la risposta a una richiesta di un cliente. La tabella in slide confronta le fasi nella modalità tradizionale e in una possibile trasformazione con l'AI. Nella ricezione, la lettura manuale della richiesta diventa una classificazione e sintesi assistita. Nell'analisi, la ricerca delle informazioni diventa un recupero guidato di fonti pertinenti, come visto nel Tema 8. Nella preparazione, la stesura della risposta diventa la produzione di una bozza. Nella verifica, il controllo manuale diventa la revisione umana della bozza, delle fonti e delle eccezioni: una verifica diversa, più centrata sulla correttezza delle informazioni e sui casi particolari. Nell'invio, la comunicazione al cliente avviene da parte di una persona, o dopo un'approvazione, secondo i livelli visti nel Tema 11. Il documento sottolinea il messaggio dell'esempio: possono cambiare la distribuzione delle attività, i passaggi di controllo e le competenze necessarie, non soltanto i tempi. La persona che prima scriveva le risposte ora le rivede, verifica le fonti e gestisce le eccezioni: un lavoro diverso, che richiede competenze in parte diverse. E una trasformazione utile va valutata sull'intero processo, non sulla singola operazione accelerata.");
    workTag(s, 1);
    table(s, [["Fase", "Modalità tradizionale", "Possibile trasformazione con AI"],
      ["Ricezione", "Lettura manuale", "Classificazione e sintesi assistita"],
      ["Analisi", "Ricerca delle informazioni", "Recupero guidato di fonti pertinenti"],
      ["Preparazione", "Stesura della risposta", "Produzione di una bozza"],
      ["Verifica", "Controllo manuale", "Revisione umana di bozza, fonti, eccezioni"],
      ["Invio", "Comunicazione al cliente", "Invio umano o dopo approvazione"]],
      { y: 1.15, colW: [1.8, 3.2, 4.0], rowH: 0.44, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Esempio dal documento di perimetro", { x: 0.5, y: 3.83, w: 9, h: 0.25, fontSize: 10, italic: true, color: C.accent2 });
    banner(s, 4.15, "Cambiano distribuzione delle attività, controlli e competenze, non solo i tempi. Si valuta sull'intero processo.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Che cosa cambia nel processo", "Il sottotema elenca i principali cambiamenti che l'AI può portare in un processo, al di là dell'accelerazione dei singoli passaggi. Cambiamenti nelle sequenze operative: l'ordine delle attività può cambiare, per esempio la classificazione automatica permette di smistare subito le richieste invece di farle passare tutte dallo stesso ufficio. Eliminazione di attività: alcuni passaggi diventano inutili, come la trascrizione manuale di dati già estratti automaticamente. Modifica di attività: altre cambiano natura, come la stesura che diventa revisione. Accorpamento di attività: passaggi prima svolti da persone diverse possono essere svolti da una sola persona con il supporto dell'AI, riducendo i passaggi di consegne. Introduzione di nuovi controlli e verifiche: servono controlli sugli output dell'AI che prima non esistevano. Ridefinizione dei punti di intervento umano: dove, nel processo, una persona decide, approva, verifica. Quest'ultimo cambiamento è il più delicato: spostare il punto di intervento umano significa cambiare chi vede che cosa e chi risponde di che cosa. Una trasformazione ben progettata decide consapevolmente dove collocare le persone, in base al rischio, come visto nel Tema 11; una trasformazione non progettata li sposta per effetto collaterale.");
    workTag(s, 1);
    await iconGrid(s, [
      { icon: "FiShuffle", head: "Sequenze", body: "Smistare subito invece che tutto da un ufficio" },
      { icon: "FiMinusCircle", head: "Eliminazione", body: "Trascrizioni ora inutili" },
      { icon: "FiEdit", head: "Modifica", body: "La stesura diventa revisione" },
      { icon: "FiLayers", head: "Accorpamento", body: "Meno passaggi di consegne" },
      { icon: "FiCheckSquare", head: "Nuovi controlli", body: "Sugli output dell'AI" },
      { icon: "FiUserCheck", head: "Punti di intervento umano", body: "Chi decide, approva, verifica", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Spostare il punto di intervento umano cambia chi vede che cosa e chi risponde: va deciso, non subito.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Automatizzare l'inefficienza", "L'integrazione B del tema: il rischio di automatizzare processi inefficienti. Rendere più rapidi i passaggi di un processo inefficiente può conservarne i problemi strutturali. È un principio noto da tempo nella gestione dei processi, molto prima dell'AI: automatizzare un processo sbagliato produce un processo sbagliato più veloce. L'esempio fittizio in slide lo mostra. In un'azienda, le richieste di acquisto passano per quattro livelli di approvazione, di cui due raramente modificano la decisione e sono stati aggiunti anni prima per motivi che non esistono più. I documenti vengono compilati in un formato e poi ricopiati in un altro sistema. Si introduce un assistente AI che prepara automaticamente le richieste e le inoltra. Il tempo di preparazione crolla, ma il processo resta lento, perché le quattro approvazioni restano; e ora l'AI produce anche le ricopiature, invece di eliminarle. In più, il processo è più difficile da cambiare, perché ora è incorporato in un sistema automatico. La domanda giusta, prima di introdurre l'AI in un processo, è: questo processo ha senso così com'è? Quali passaggi servono davvero? A volte la semplificazione del processo produce più benefici dell'AI, e non costa nulla. Il Business Process Reengineering, l'approccio sistematico alla riprogettazione dei processi, è solo da accennare.");
    workTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 2.2, "Il processo (esempio fittizio)", "Quattro approvazioni, di cui due quasi mai decisive e nate per motivi che non esistono più. Dati compilati in un formato e ricopiati in un altro sistema.", { fontSize: 12 });
    docBox(s, 5.15, 1.15, 4.35, 2.2, "Con l'AI", "La preparazione crolla, ma le quattro approvazioni restano; l'AI fa le ricopiature invece di eliminarle; il processo ora è più difficile da cambiare.", { fontSize: 12, bar: C.accent5, labelColor: C.accent5 });
    shapeBox(s, 0.5, 3.55, 9.0, 0.7, C.text1, "principio");
    txt(s, "Automatizzare un processo sbagliato produce un processo sbagliato più veloce.", { x: 0.7, y: 3.55, w: 8.6, h: 0.7, fontSize: 15, bold: true, color: C.background1, valign: "middle", align: "center" });
    txt(s, "Prima di introdurre l'AI: questo processo ha senso così com'è? Quali passaggi servono davvero?", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("La trasformazione crea nuovo lavoro", "L'integrazione D del tema: la trasformazione può creare nuovo lavoro. Il risparmio su certe operazioni può essere compensato da nuovi compiti di verifica e coordinamento. È una delle domande guida, e una delle precisazioni trasversali: il nuovo lavoro va conteggiato. Quali sono le nuove attività tipiche introdotte dall'AI in un processo? La verifica degli output, come visto in tutto il percorso. La gestione delle eccezioni che il sistema non sa trattare, spesso i casi più difficili, concentrati su poche persone. La preparazione e l'aggiornamento delle informazioni su cui il sistema si basa, come documentazione, istruzioni, esempi. Il monitoraggio del funzionamento del sistema, visto nel Tema 11. Il coordinamento tra persone e sistemi, e tra persone che usano strumenti diversi. La gestione dei reclami e delle correzioni dovute agli errori del sistema. La formazione delle persone all'uso degli strumenti. Queste attività non sono un fallimento della trasformazione: sono parte di essa. Ma vanno previste, assegnate e conteggiate. Se non lo sono, finiscono per ricadere su qualcuno senza essere riconosciute, spesso sulle persone più esperte, e il bilancio della trasformazione risulta migliore di quanto sia.");
    workTag(s, 1);
    await iconGrid(s, [
      { icon: "FiSearch", head: "Verifica degli output", body: "In tutto il percorso" },
      { icon: "FiAlertCircle", head: "Gestione delle eccezioni", body: "I casi difficili, su poche persone" },
      { icon: "FiBookOpen", head: "Informazioni di base", body: "Documentazione, istruzioni, esempi" },
      { icon: "FiActivity", head: "Monitoraggio", body: "Del funzionamento del sistema" },
      { icon: "FiShare2", head: "Coordinamento", body: "Tra persone e sistemi" },
      { icon: "FiRotateCcw", head: "Correzioni e reclami", body: "Dovuti agli errori del sistema" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Non un fallimento, ma parte della trasformazione: va prevista, assegnata e conteggiata.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Ottimizzare o trasformare", "L'ultimo punto del sottotema: la distinzione tra ottimizzazione locale e trasformazione complessiva. L'ottimizzazione locale migliora uno o più passaggi di un processo, lasciandone invariata la struttura: le stesse fasi, le stesse persone, gli stessi controlli, con alcune attività più rapide. È il modo più comune e più semplice di introdurre l'AI, e può produrre benefici reali, soprattutto se riguarda i colli di bottiglia. La trasformazione complessiva ripensa il processo nel suo insieme, alla luce di ciò che l'AI rende possibile: quali passaggi servono ancora, in quale ordine, chi li svolge, dove si colloca il controllo umano, quali nuove attività sono necessarie, quale risultato si vuole ottenere. Richiede più tempo e più coinvolgimento, e comporta più rischi, ma può produrre benefici molto maggiori. La lezione storica del paradosso di Solow, vista nel Tema 12, riguarda proprio questo: i benefici delle tecnologie dell'informazione arrivarono quando le organizzazioni ripensarono i processi, non quando si limitarono ad accelerare quelli esistenti. Non esiste una scelta giusta in assoluto: spesso conviene partire da ottimizzazioni locali, imparare, e poi trasformare. Ma è importante sapere quale delle due si sta facendo, e non aspettarsi dalla prima i risultati della seconda.");
    workTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiZap", head: "Ottimizzazione locale", headSize: 16, bodySize: 12,
      body: bullets(["Stessa struttura, alcuni passaggi più rapidi", "Semplice e comune", "Benefici reali, soprattutto sui colli di bottiglia"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiRefreshCw", head: "Trasformazione complessiva", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Ripensare passaggi, ordine, persone, controlli", "Più tempo, coinvolgimento e rischi", "Benefici potenzialmente maggiori"], { space: 5 }) });
    banner(s, 3.9, "Spesso conviene ottimizzare, imparare, poi trasformare. Ma non aspettarsi dalla prima i risultati della seconda.", { h: 0.85, fontSize: 13 });
  }
  keySlide("Introdurre AI in un processo non equivale automaticamente a riprogettarlo o migliorarlo.", "Sottotema 13.3  ·  Dall'ottimizzazione del compito alla trasformazione del processo", "Concetto chiave del sottotema 13.3. I processi sono sequenze di attività interdipendenti, e l'AI applicata a un passaggio può migliorare il processo, lasciarlo invariato o peggiorarlo. Possono cambiare sequenze, attività, controlli e punti di intervento umano. Automatizzare un processo inefficiente ne conserva i problemi, e la trasformazione crea anche nuovo lavoro, da conteggiare. Ottimizzazione locale e trasformazione complessiva sono diverse. Esercizio suggerito: partendo dall'esempio della richiesta del cliente, i partecipanti disegnano un processo del proprio lavoro, prima e dopo un possibile intervento dell'AI, indicando le attività eliminate, modificate, accorpate e quelle nuove.");

  // =====================================================================
  section("13.4 Collaborazione persone e AI");
  divider("13.4", "Collaborazione tra persone e AI", "Le persone possono spostarsi verso interpretazione, verifica e supervisione, senza perdere il bisogno di competenze", "Dalle attività e dai processi alle persone. Come si lavora con l'AI, nel quotidiano? Il documento chiede di approfondire questo sottotema, da comprendere, e di tenerlo distinto dal successivo: qui parliamo di come si lavora con l'AI, cioè dei modelli operativi di collaborazione; nel 13.5 parleremo di come evolvono i ruoli nel tempo. Nel Tema 5 abbiamo visto la collaborazione conversazionale, una persona che dialoga con un assistente; nel Tema 11 la distribuzione del lavoro con gli agenti. Qui guardiamo agli effetti sul lavoro delle persone.");
  {
    const s = content("Strumento personale o di processo", "Il sottotema distingue due modi in cui l'AI entra nel lavoro, con effetti diversi sulle persone. L'AI come supporto individuale: ciascuna persona usa l'AI, per sua scelta, per le proprie attività, in modo diverso da un collega all'altro. Il processo resta invariato, e l'AI è uno strumento personale, come lo sono il foglio di calcolo o il motore di ricerca. È la situazione oggi più diffusa. Ha il vantaggio della flessibilità e dell'autonomia, e lo svantaggio che i benefici restano individuali e disomogenei, come vedremo nel 13.6. L'AI come componente operativa delle attività: l'AI è parte del processo, progettata per svolgere una funzione definita, uguale per tutti, come la classificazione delle richieste in arrivo o la preparazione delle bozze di risposta. Il processo cambia, e le persone lavorano con l'AI in un modo stabilito dall'organizzazione. I benefici possono essere più ampi e misurabili, ma l'autonomia individuale si riduce, e il disegno della collaborazione diventa una scelta organizzativa. Le due forme convivono spesso nella stessa azienda, anche per la stessa persona: un addetto può lavorare in un processo con un componente AI e, insieme, usare un assistente personale per altre attività.");
    workTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiUser", head: "Supporto individuale", headSize: 16, bodySize: 12,
      body: bullets(["Ciascuno lo usa a modo suo", "Il processo non cambia", "Flessibilità e autonomia", "Benefici individuali e disomogenei"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiSettings", head: "Componente operativa", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Funzione definita, uguale per tutti", "Il processo cambia", "Benefici più ampi e misurabili", "Meno autonomia: è una scelta organizzativa"], { space: 4 }) });
    banner(s, 3.95, "Spesso convivono, anche per la stessa persona: un processo con l'AI integrata e un assistente personale per il resto.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Distribuire il lavoro", "Il cuore del sottotema è la distribuzione del lavoro tra persona e sistema. Nel Tema 11 abbiamo visto la regola generale: alle persone le decisioni, ai sistemi la preparazione delle decisioni. Qui guardiamo ai modelli di collaborazione più frequenti, che il sottotema elenca. Il modello più diffuso è la preparazione automatica con revisione umana: il sistema prepara, la persona rivede, corregge e approva. Funziona bene se la revisione è reale e se la persona ha le competenze per farla; funziona male se la revisione diventa un'approvazione automatica, come visto nel Tema 11 per l'affaticamento da approvazione. Un secondo modello è la collaborazione nell'esecuzione: persona e sistema lavorano insieme sulla stessa attività, alternandosi, come nel lavoro su un documento in cui la persona scrive alcune parti e chiede al sistema di svilupparne altre. Un terzo modello è il coordinamento tra persone e strumenti: la persona organizza il lavoro di più strumenti e sistemi, come un regista, verificando i risultati e integrandoli. In tutti i modelli conviene chiarire che cosa fa il sistema, che cosa fa la persona, in quale ordine, e chi decide alla fine. Il disegno della collaborazione è più importante della scelta dello strumento.");
    workTag(s, 2);
    const m = [["FiEdit", "Preparazione e revisione", "Il sistema prepara, la persona rivede e approva", "Se la revisione è reale"], ["FiUsers", "Esecuzione condivisa", "Persona e sistema si alternano sulla stessa attività", "Se è chiaro chi fa che cosa"], ["FiSliders", "Coordinamento", "La persona organizza più strumenti, come un regista", "Se sa verificare e integrare"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.55, i === 0 ? C.accent6 : C.background2, m[i][1]);
      await iconCircle(s, x + 1.08, 1.27, 0.7, m[i][0]);
      txt(s, m[i][1], { x: x + 0.15, y: 2.05, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, m[i][2], { x: x + 0.2, y: 2.5, w: 2.46, h: 0.6, fontSize: 12, color: C.text2, align: "center" });
      txt(s, m[i][3], { x: x + 0.2, y: 3.15, w: 2.46, h: 0.45, fontSize: 11, italic: true, bold: true, color: C.accent1, align: "center" });
    }
    banner(s, 3.95, "Chiarire che cosa fa il sistema, che cosa la persona, in quale ordine, chi decide. Il disegno conta più dello strumento.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Dall'esecuzione alla supervisione", "Uno spostamento che il sottotema mette al centro: il passaggio dall'esecuzione alla supervisione. In molti lavori, l'introduzione dell'AI sposta l'attività delle persone dal fare al controllare: invece di scrivere, si rivede; invece di calcolare, si verifica; invece di cercare, si valuta ciò che è stato trovato; invece di gestire tutti i casi, si gestiscono le eccezioni. La consapevolezza del sottotema lo esprime così: le persone possono spostarsi verso interpretazione, verifica e supervisione. E aggiunge subito una precisazione importante: senza che questo elimini il bisogno di competenze professionali. Anzi, la supervisione richiede spesso competenze più solide dell'esecuzione: per riconoscere un errore in un documento preparato da altri, bisogna sapere come andrebbe fatto, e accorgersi di ciò che manca, non solo di ciò che è scritto. Questo spostamento ha anche effetti sulla soddisfazione e sul senso del lavoro, che possono essere positivi o negativi: alcune persone apprezzano liberarsi delle attività ripetitive e concentrarsi su quelle di giudizio; altre trovano la supervisione meno gratificante della creazione, o faticosa per la concentrazione che richiede. Anche la gestione delle eccezioni, che spesso diventa la parte principale del lavoro, concentra sulle persone i casi più difficili.");
    workTag(s, 2);
    const p = [["Scrivere", "Rivedere"], ["Calcolare", "Verificare"], ["Cercare", "Valutare ciò che è stato trovato"], ["Tutti i casi", "Le eccezioni"]];
    p.forEach((e, i) => {
      const y = 1.15 + i * 0.55;
      chip(s, 0.5, y, 2.4, 0.46, e[0], { fill: C.background2, fontSize: 12 });
      arrow(s, 3.0, y + 0.07, 0.45);
      chip(s, 3.55, y, 2.6, 0.46, e[1], { fill: C.accent6, fontSize: 12 });
    });
    shapeBox(s, 6.4, 1.15, 3.1, 2.1, C.text1, "competenze");
    txt(s, "La supervisione richiede spesso competenze più solide dell'esecuzione", { x: 6.55, y: 1.25, w: 2.8, h: 1.0, fontSize: 13, bold: true, color: C.accent6 });
    txt(s, "Per riconoscere un errore bisogna sapere come andrebbe fatto.", { x: 6.55, y: 2.3, w: 2.8, h: 0.85, fontSize: 12, color: C.background1 });
    await card(s, 0.5, 3.45, 4.35, 1.45, { head: "Per alcuni", headSize: 13, bodySize: 12, fill: C.accent6, body: "Liberarsi del ripetitivo e concentrarsi sul giudizio." });
    await card(s, 5.15, 3.45, 4.35, 1.45, { head: "Per altri", headSize: 13, bodySize: 12, body: "Supervisione meno gratificante, faticosa, e i casi più difficili concentrati." });
  }
  {
    const s = content("Autonomia e responsabilità", "Tre ultimi punti del sottotema. La preservazione dell'autonomia professionale: quando l'AI diventa una componente del processo, c'è il rischio che le persone perdano margini di decisione, perché il sistema propone e la persona si limita ad approvare, o perché il modo di lavorare è definito dallo strumento. L'autonomia professionale ha valore sia per le persone, perché incide sulla motivazione e sul senso del lavoro, sia per l'organizzazione, perché è ciò che permette di adattarsi ai casi non previsti e di accorgersi degli errori. Un buon disegno della collaborazione lascia alle persone lo spazio per decidere diversamente da ciò che propone il sistema, e per segnalare quando il sistema non funziona. La responsabilità delle decisioni e dei risultati: come in tutto il percorso, chi decide e chi firma risponde, anche quando il lavoro è stato preparato dall'AI. Nel lavoro quotidiano questo significa che la persona deve avere il tempo e le informazioni per esercitare davvero la propria responsabilità, non solo il nome sul documento. La necessità di conoscere capacità e limiti dell'AI: per collaborare bene con un sistema, bisogna sapere che cosa sa fare e dove sbaglia, cioè le competenze di AI literacy costruite in questo percorso. Senza questa conoscenza, la collaborazione oscilla tra fiducia eccessiva e rifiuto.");
    workTag(s, 2);
    await iconGrid(s, [
      { icon: "FiCompass", head: "Autonomia professionale", body: "Spazio per decidere diversamente dal sistema e segnalare quando non funziona" },
      { icon: "FiAward", head: "Responsabilità reale", body: "Tempo e informazioni per esercitarla, non solo il nome sul documento" },
      { icon: "FiBookOpen", head: "Conoscere capacità e limiti", body: "Senza, si oscilla tra fiducia eccessiva e rifiuto" },
    ], 3, { y: 1.15, h: 2.2, headSize: 14, bodySize: 12 });
    banner(s, 3.6, "L'autonomia conta per le persone, perché dà senso al lavoro, e per l'organizzazione, perché intercetta errori e casi nuovi.", { h: 0.85, fontSize: 13 });
  }
  keySlide("Le persone possono spostarsi verso interpretazione, verifica e supervisione, senza che questo elimini il bisogno di competenze professionali.", "Sottotema 13.4  ·  Nuovi modelli di collaborazione tra persone e AI", "Concetto chiave del sottotema 13.4. L'AI può entrare nel lavoro come supporto individuale o come componente operativa del processo, con effetti diversi su autonomia e benefici. I modelli di collaborazione vanno dalla preparazione con revisione all'esecuzione condivisa e al coordinamento, e il loro disegno conta più dello strumento. Il lavoro si sposta dall'esecuzione alla supervisione, che richiede competenze solide e può essere vissuta in modi diversi. Autonomia professionale, responsabilità reale e conoscenza dei limiti dell'AI sono condizioni di una buona collaborazione. Esercizio suggerito: per un'attività svolta con l'AI, i partecipanti descrivono chi fa che cosa, in quale ordine, e dove hanno spazio per decidere diversamente dal sistema.");

  // =====================================================================
  section("13.5 Ruoli e responsabilità");
  divider("13.5", "Evoluzione dei ruoli e delle responsabilità", "Le conseguenze sui ruoli non sono predeterminate dalla tecnologia", "Se il 13.4 riguardava come si lavora con l'AI, questo sottotema riguarda come evolvono i ruoli nel tempo. È tra quelli da approfondire maggiormente, e tocca la domanda che sta a cuore a molti partecipanti: che cosa succederà al mio lavoro? Il documento chiede di affrontarla con equilibrio, senza assumere risultati occupazionali predeterminati. Vediamo come cambia la composizione delle mansioni, quali competenze acquistano o perdono importanza, quali nuove responsabilità emergono, e un caso trasversale importante: il paradosso del supervisore inesperto. Le analisi occupazionali specialistiche e il workforce planning sono solo da accennare.");
  {
    const s = content("La composizione delle mansioni", "Il primo effetto dell'AI sui ruoli è il cambiamento nella composizione delle mansioni: la stessa posizione continua a esistere, ma il tempo si distribuisce diversamente tra le attività. Il grafico fittizio in slide mostra come potrebbe cambiare il ruolo di un addetto all'assistenza clienti. Prima dell'AI, gran parte del tempo era dedicata alla stesura delle risposte e alla ricerca delle informazioni. Con l'AI, quel tempo si riduce; aumenta il tempo dedicato alla revisione delle bozze, alla gestione dei casi complessi e delle eccezioni, e compaiono attività nuove, come il miglioramento della base di conoscenza su cui il sistema si basa. Il ruolo ha lo stesso nome, ma è diverso. Il sottotema parla di redistribuzione delle attività, e questa può avvenire in più direzioni: all'interno dello stesso ruolo, come nell'esempio; tra ruoli diversi, quando alcune attività passano da una posizione a un'altra; tra persone e sistemi. I numeri del grafico sono inventati e servono solo a mostrare il tipo di cambiamento. In un caso reale, la nuova composizione dipende dalle scelte fatte: per esempio, il tempo liberato può essere dedicato a più clienti, a una relazione più approfondita con ciascuno, o ad altre attività.");
    workTag(s, 2);
    s.addChart(pres.charts.BAR, [
      { name: "Stesura risposte", labels: ["Prima", "Con AI"], values: [40, 10] },
      { name: "Ricerca informazioni", labels: ["Prima", "Con AI"], values: [25, 10] },
      { name: "Revisione bozze", labels: ["Prima", "Con AI"], values: [5, 25] },
      { name: "Casi complessi ed eccezioni", labels: ["Prima", "Con AI"], values: [20, 30] },
      { name: "Base di conoscenza", labels: ["Prima", "Con AI"], values: [0, 10] },
      { name: "Altro", labels: ["Prima", "Con AI"], values: [10, 15] }], {
      x: 0.5, y: 1.1, w: 6.0, h: 3.2, barDir: "bar", barGrouping: "percentStacked", chartColors: [HEX.a2, HEX.a3, HEX.a1, HEX.a5, HEX.a4, "C9CED4"],
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 9, valGridLine: { color: HEX.a3, size: 0.5 }, valAxisLabelFormatCode: "0%",
      showLegend: true, legendPos: "b", legendFontSize: 9, legendFontFace: "+mn-lt", legendColor: HEX.dk2, barGapWidthPct: 40,
      showTitle: true, title: "Addetto all'assistenza: distribuzione del tempo (numeri inventati)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
    const r = [["Diminuiscono", "Stesura, ricerca"], ["Aumentano", "Revisione, casi complessi"], ["Compaiono", "Base di conoscenza"]];
    r.forEach((e, i) => {
      const y = 1.15 + i * 1.0;
      shapeBox(s, 6.75, y, 2.75, 0.88, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.9, y: y + 0.06, w: 2.5, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.9, y: y + 0.44, w: 2.5, h: 0.38, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.4, "Stesso nome, ruolo diverso. La nuova composizione dipende dalle scelte fatte.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Competenze che cambiano peso", "Il sottotema chiede di riconoscere le competenze che acquisiscono maggiore importanza e quelle che possono perdere centralità. Senza pretendere di prevedere il futuro di ogni professione, alcune tendenze sono ragionevolmente chiare, almeno per il lavoro informativo e cognitivo. Acquistano importanza: la capacità di formulare problemi e obiettivi, cioè di sapere che cosa chiedere; la valutazione critica dei risultati, vista nel Tema 7; la conoscenza del dominio e del contesto, che permette di riconoscere gli errori; il giudizio nei casi complessi e nelle eccezioni; la relazione con le persone, clienti e colleghi; la capacità di coordinare il lavoro di persone e strumenti; la responsabilità e la capacità di decidere. Possono perdere centralità: alcune competenze di esecuzione, come la stesura di testi standard, la ricerca manuale di informazioni, la formattazione, alcuni calcoli e trascrizioni. Due cautele. 'Perdere centralità' non significa diventare inutili: molte di queste competenze restano necessarie per verificare il lavoro dell'AI, come vedremo nel 13.7. E le competenze specialistiche, che il sottotema richiama esplicitamente, restano decisive: l'AI amplifica gli esperti, ma non ne fa a meno, soprattutto per i casi difficili e per la supervisione.");
    workTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 2.85, { icon: "FiTrendingUp", head: "Acquistano importanza", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Formulare problemi e obiettivi", "Valutazione critica dei risultati", "Conoscenza del dominio e del contesto", "Giudizio nei casi complessi", "Relazione con le persone", "Coordinare persone e strumenti"], { space: 3 }) });
    await card(s, 5.15, 1.15, 4.35, 2.85, { icon: "FiTrendingDown", head: "Possono perdere centralità", headSize: 15, bodySize: 12,
      body: bullets(["Stesura di testi standard", "Ricerca manuale di informazioni", "Formattazione", "Alcuni calcoli e trascrizioni"], { space: 3 }) });
    banner(s, 4.2, "'Perdere centralità' non è 'diventare inutili': servono per verificare. E le competenze specialistiche restano decisive.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Nuove attività e responsabilità", "Il sottotema richiama la comparsa di nuove attività e responsabilità, e l'integrazione D: la trasformazione può introdurre responsabilità inedite. Alcune riguardano il coordinamento e il controllo dell'AI, che il sottotema elenca esplicitamente: definire come gli strumenti devono essere usati in un'attività, verificare periodicamente la qualità dei risultati, gestire le eccezioni, mantenere aggiornate le informazioni su cui il sistema si basa, segnalare i problemi, rispondere degli esiti delle attività assistite o automatizzate. In alcune organizzazioni queste attività si concentrano in figure specifiche, come referenti interni per l'AI in un reparto, o responsabili della qualità di un processo automatizzato; in altre si distribuiscono tra tutti. Altre nuove attività riguardano il lavoro stesso: attività prima impossibili, che l'AI rende sostenibili, come visto nel Tema 12, e che richiedono qualcuno che le svolga. È importante riconoscere queste nuove responsabilità per tre ragioni: perché richiedono tempo, che va conteggiato; perché richiedono competenze, che vanno sviluppate; e perché, se non vengono assegnate esplicitamente, finiscono per non essere svolte, o per ricadere su chi non le ha scelte.");
    workTag(s, 2);
    await iconGrid(s, [
      { icon: "FiSliders", head: "Definire l'uso", body: "Come gli strumenti si usano in un'attività" },
      { icon: "FiSearch", head: "Verificare la qualità", body: "Periodicamente, sui risultati" },
      { icon: "FiAlertCircle", head: "Gestire le eccezioni", body: "I casi che il sistema non tratta" },
      { icon: "FiDatabase", head: "Aggiornare le informazioni", body: "Su cui il sistema si basa" },
      { icon: "FiFlag", head: "Segnalare problemi", body: "E proporre miglioramenti" },
      { icon: "FiAward", head: "Rispondere degli esiti", body: "Delle attività assistite o automatizzate" },
    ], 3, { y: 1.15, H: 2.8, headSize: 13, bodySize: 12 });
    txt(s, "Da riconoscere perché richiedono", { x: 0.5, y: 4.1, w: 2.6, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 3.1, 4.1, 2.05, 0.55, "Tempo, da conteggiare", { fill: C.background2, fontSize: 11 });
    chip(s, 5.25, 4.1, 2.05, 0.55, "Competenze, da sviluppare", { fill: C.background2, fontSize: 11 });
    chip(s, 7.4, 4.1, 2.1, 0.55, "Assegnazione esplicita", { fill: C.background2, fontSize: 11 });
  }
  {
    const s = content("Il supervisore inesperto", "Il caso trasversale del documento, e l'integrazione C: il paradosso del supervisore inesperto. Quando un lavoratore junior impara una professione, lo fa spesso preparando documenti, analisi, bozze, che un collega esperto rivede e corregge. Facendo e sbagliando, sotto la guida di qualcuno, sviluppa l'esperienza che gli permetterà, un giorno, di fare il lavoro da solo e di rivedere quello degli altri. Se la preparazione viene interamente affidata all'AI, queste occasioni di apprendimento pratico si riducono. E allo stesso tempo, al junior viene spesso chiesto di controllare i documenti preparati dall'AI: un compito di supervisione, che richiede proprio l'esperienza che non ha avuto modo di sviluppare. Il risultato è un paradosso: si chiede più giudizio a chi ha avuto meno occasioni di formarlo. Nel breve periodo il problema non si vede, perché gli esperti attuali possono supervisionare; nel lungo periodo, quando gli esperti attuali lasceranno, potrebbe mancare chi sa davvero come si fa il lavoro. Il documento sottolinea che questo effetto non è inevitabile: l'AI può sostenere l'apprendimento se è impiegata per esercitazioni, spiegazioni e feedback. L'organizzazione deve considerare tanto la produttività immediata quanto lo sviluppo delle competenze nel tempo.");
    workTag(s, 2);
    const st = [["Prima", "Il junior prepara, l'esperto rivede: si impara facendo", C.accent6, C.text1], ["Con l'AI", "L'AI prepara, il junior controlla: meno pratica, più giudizio richiesto", C.background2, C.text1], ["Nel tempo", "Gli esperti lasciano: chi sa davvero come si fa?", C.text1, C.background1]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.7, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.42, fontSize: 16, bold: true, color: i === 2 ? C.accent6 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.68, w: 2.56, h: 1.1, fontSize: 12, color: e[3] });
      if (i < 2) arrow(s, x + 2.88, 1.85, 0.17);
    });
    banner(s, 3.05, "Si chiede più giudizio a chi ha avuto meno occasioni di formarlo.", { h: 0.65, fontSize: 15 });
    shapeBox(s, 0.5, 3.9, 9.0, 1.05, C.accent6, "non inevitabile");
    txt(s, [{ text: "Non è inevitabile: ", options: { bold: true, color: C.accent1 } }, { text: "l'AI può sostenere l'apprendimento con esercitazioni, spiegazioni e feedback. Contano la produttività immediata e lo sviluppo delle competenze nel tempo.", options: { color: C.text1 } }], { x: 0.7, y: 3.9, w: 8.6, h: 1.05, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Compiti e occupazione", "Il sottotema chiede di distinguere il cambiamento dei compiti dagli effetti sull'occupazione, e una delle domande guida chiede quali effetti possano esserci sui ruoli professionali, senza assumere risultati occupazionali predeterminati. È il punto più sensibile del tema, e conviene trattarlo con onestà. Che l'AI cambi i compiti e la composizione delle mansioni è ormai evidente in molti lavori. Che cosa questo comporti per l'occupazione, cioè per il numero di persone che svolgono un certo lavoro, è molto più incerto, e dipende da fattori che vanno oltre la tecnologia: quanto l'AI aumenta la produttività di ciascuna persona; se la domanda di quel lavoro cresce quando il suo costo si riduce, come è accaduto in passato in alcuni casi; quali nuove attività nascono; quali scelte fanno le organizzazioni; come evolvono le regole e il contesto economico. Gli effetti possono essere diversi per professioni diverse, e nel tempo: un ruolo può crescere in una fase e ridursi in un'altra. Le analisi occupazionali specialistiche sono solo da accennare, e richiederebbero dati e metodi che non sono oggetto di questo percorso. Il messaggio del sottotema, condiviso con il 13.1, è che le conseguenze sui ruoli non sono predeterminate dalla tecnologia: dipendono anche, e molto, dalle scelte delle organizzazioni.");
    workTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 1.6, { icon: "FiCheckSquare", inline: true, head: "Il cambiamento dei compiti", headSize: 14, bodySize: 12, fill: C.accent6, body: "Evidente in molti lavori: composizione delle mansioni, attività nuove e ridotte." });
    await card(s, 5.15, 1.15, 4.35, 1.6, { icon: "FiHelpCircle", inline: true, head: "L'effetto sull'occupazione", headSize: 14, bodySize: 12, body: "Molto più incerto: dipende da fattori oltre la tecnologia." });
    txt(s, "Da che cosa dipende", { x: 0.5, y: 2.9, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const d = ["Aumento di produttività", "Domanda che cresce se il costo cala", "Nuove attività", "Scelte delle organizzazioni", "Regole e contesto economico"];
    d.forEach((t, i) => chip(s, 0.5 + i * 1.82, 3.28, 1.7, 0.75, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 4.2, "Le conseguenze sui ruoli non sono predeterminate dalla tecnologia. Analisi occupazionali specialistiche: solo accennate.", { h: 0.75, fontSize: 13 });
  }
  keySlide("Le conseguenze sui ruoli non sono predeterminate dalla tecnologia.", "Sottotema 13.5  ·  Evoluzione dei ruoli e delle responsabilità professionali", "Concetto chiave del sottotema 13.5. L'AI cambia la composizione delle mansioni: alcune attività diminuiscono, altre aumentano, altre compaiono. Acquistano importanza le competenze di formulazione, valutazione, dominio, giudizio, relazione e coordinamento; alcune competenze di esecuzione perdono centralità ma restano necessarie per verificare. Nascono nuove responsabilità, da riconoscere e assegnare. Il paradosso del supervisore inesperto mostra il rischio di ridurre le occasioni di apprendimento, rischio evitabile con scelte consapevoli. Il cambiamento dei compiti è evidente, l'effetto sull'occupazione è incerto e dipende dalle scelte. Esercizio suggerito: discutere in gruppo come organizzare il lavoro di un junior in un'attività in cui l'AI prepara le bozze, in modo che continui a imparare.");
