  function riskTag(s, active) {
    const st = ["Uso", "Dati", "Sicurezza", "Equità", "Contenuti", "Controllo"];
    const act = Array.isArray(active) ? active : [active];
    st.forEach((t, i) => {
      const x = 6.0 + i * 0.58, on = act.includes(i);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.56, h: 0.26, rectRadius: 0.13, fill: { color: on ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "dimensione " + t });
      txt(s, t, { x, y: 0.42, w: 0.56, h: 0.26, fontSize: 6.5, bold: true, color: on ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 17", { placeholder: "kicker" });
    s.addText("Utilizzo consapevole e responsabile dell'AI", { placeholder: "title" });
    s.addText("Rischi, sicurezza e tutela delle informazioni  ·  Area: Utilizzare l'AI responsabilmente", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al diciassettesimo tema, il primo dell'area 'Utilizzare l'AI responsabilmente'. Nei temi precedenti abbiamo rimandato più volte a questo momento: la protezione delle informazioni, la sicurezza, i rischi per le persone, il controllo umano. Ora li affrontiamo direttamente. Il punto di vista di questo tema è quello di chi usa l'AI nel proprio lavoro: quali rischi riconoscere, quali precauzioni adottare, quali comportamenti tenere, quando fermarsi. Il confine decisivo è con il Tema 18: lì guarderemo il punto di vista dell'organizzazione, cioè norme, politiche, ruoli e controlli formali. Qui i riferimenti a regole e autorizzazioni restano applicativi, senza analisi giuridiche. Un'indicazione di metodo dal documento di perimetro, che seguiremo: privilegiare episodi professionali riconoscibili e decisioni pratiche, invece di cataloghi di minacce o approfondimenti specialistici. Il tono che vorremmo trasmettere non è l'allarme né la rinuncia: è la precauzione proporzionata. Suggerimento per l'apertura: chiedere ai partecipanti se, nell'ultima settimana, hanno inserito in uno strumento di AI informazioni che non avrebbero scritto in una email a un estraneo. Non serve rispondere ad alta voce. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; sicurezza e normativa cambiano in fretta, e le fonti, a partire dalla lista OWASP, vanno ricontrollate prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere i principali rischi dell'uso professionale dell'AI, riconoscendo le implicazioni per riservatezza, sicurezza, equità, autenticità, proprietà intellettuale e responsabilità delle decisioni, e sviluppando la capacità di adottare precauzioni proporzionate al contesto. Sei ambiti di rischio, e una capacità: la proporzionalità. La consapevolezza da sviluppare: usare l'AI responsabilmente significa valutarne l'appropriatezza prima dell'impiego, proteggere le informazioni, riconoscere possibili conseguenze indesiderate, verificare i risultati e mantenere un controllo umano effettivo. E una frase che conviene sottolineare: il rischio dipende dall'interazione tra lo strumento, le informazioni trattate, le modalità d'uso e le possibili conseguenze. Non esistono strumenti sicuri o pericolosi in assoluto: lo stesso strumento può essere adatto per riformulare un testo pubblico e inadatto per analizzare i dati sanitari di un collega. Il messaggio chiave del documento di perimetro: usare l'AI responsabilmente significa valutarne l'appropriatezza, proteggere le informazioni, riconoscere rischi ed effetti indesiderati e mantenere un controllo umano effettivo, con precauzioni proporzionate al contesto e alle possibili conseguenze, nel rispetto delle regole aziendali.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 13,
      body: bullets(["Riconoscere i rischi: riservatezza, sicurezza, equità, autenticità, proprietà intellettuale, decisioni", "Adottare precauzioni proporzionate al contesto"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 13,
      body: "Valutare l'appropriatezza, proteggere le informazioni, riconoscere le conseguenze, verificare, mantenere un controllo effettivo.\n\nIl rischio nasce dall'interazione tra strumento, informazioni, modalità d'uso e conseguenze." });
  }
  {
    const s = content("Da che cosa dipende il rischio", "Una slide per fissare l'idea che regge tutto il modulo, e la prima precisazione trasversale del documento: il rischio varia secondo il contesto e le conseguenze dell'uso, non soltanto secondo lo strumento. Quattro fattori interagiscono. Lo strumento: di che tipo è, chi lo fornisce, a quali condizioni, a che cosa è collegato, che cosa può fare. Le informazioni trattate: pubbliche o riservate, personali o no, di chi. Le modalità d'uso: per una bozza da rivedere o per una decisione, con verifica o senza, con azioni automatiche o no. Le possibili conseguenze: per chi, quanto gravi, quanto reversibili. Cambiando uno solo dei fattori, il rischio cambia. Lo stesso assistente usato per riformulare un comunicato già pubblicato ha un rischio basso; usato per riassumere un contratto riservato con un servizio non approvato, un rischio alto; usato per decidere chi assumere, un rischio alto di tipo diverso. Le altre due precisazioni trasversali del documento le riprenderemo nei sottotemi: la protezione delle informazioni riguarda sia ciò che entra sia ciò che esce, e i suoi destinatari; e la sicurezza non può essere delegata interamente all'utilizzatore, ma richiede controlli tecnici e organizzativi.");
    const f = [["FiCpu", "Strumento", "Tipo, fornitore, condizioni, collegamenti, capacità"], ["FiDatabase", "Informazioni", "Pubbliche o riservate, personali, di chi"], ["FiSliders", "Modalità d'uso", "Bozza o decisione, con o senza verifica, con azioni"], ["FiAlertTriangle", "Conseguenze", "Per chi, quanto gravi, quanto reversibili"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.25, i === 3 ? C.accent6 : C.background2, f[i][1]);
      await iconCircle(s, x + 0.75, 1.25, 0.62, f[i][0]);
      txt(s, f[i][1], { x: x + 0.1, y: 1.95, w: 1.95, h: 0.4, fontSize: 14, bold: true, color: C.text1, align: "center" });
      txt(s, f[i][2], { x: x + 0.12, y: 2.38, w: 1.91, h: 0.95, fontSize: 11, color: C.text2, align: "center" });
    }
    txt(s, "Tre precisazioni trasversali", { x: 0.5, y: 3.55, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Il rischio dipende dal contesto, non solo dallo strumento", "Proteggere input, output e destinatari", "La sicurezza non è delegabile solo all'utente"].forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.92, 2.86, 0.85, t, { fill: C.accent6, fontSize: 12 }));
  }
  {
    const s = content("Otto domande guida", "Le otto domande guida accompagnano il modulo. Quando è appropriato usare l'AI in un'attività professionale. Quali informazioni si possono condividere, e a quali condizioni. Come distinguere i rischi di riservatezza da quelli di sicurezza informatica. In che modo contenuti esterni possono manipolare un assistente AI. Come riconoscere output potenzialmente discriminatori o ingannevoli. Quali cautele servono nell'uso di materiali generati dall'AI. Quando la supervisione umana è realmente efficace. E come decidere se procedere, verificare, chiedere supporto o interrompere l'uso. L'ultima domanda è quella che il modulo vuole rendere operativa: alla fine, la responsabilità si traduce in una scelta tra queste quattro azioni.");
    qGrid(s, ["Quando è appropriato usare l'AI?", "Quali informazioni condividere, a quali condizioni?", "Riservatezza o sicurezza informatica?", "Come possono manipolarla contenuti esterni?", "Output discriminatori o ingannevoli?", "Quali cautele sui materiali generati?", "Quando la supervisione è efficace?", "Procedere, verificare, chiedere, interrompere?"], 4, 1.12, 1.5, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in sei dimensioni. L'appropriatezza dell'uso, nel 17.1. La protezione dei dati e la sicurezza, nel 17.2 e 17.3. L'equità e la tutela delle persone, nel 17.4. L'autenticità e i diritti sui contenuti, nel 17.5 e 17.6. Il controllo e la responsabilità umana, nel 17.7. I comportamenti applicabili, nel 17.8, che è la sintesi operativa e non una ripetizione dei rischi. Nelle slide, un indicatore in alto a destra ricorda la dimensione: Uso, Dati, Sicurezza, Equità, Contenuti, Controllo. Quattro integrazioni attraversano il modulo, e il 17.8 le traduce in precauzioni operative. A: un dato rimosso non è necessariamente un dato anonimizzato. B: il prompt injection può arrivare da contenuti apparentemente innocui. C: la supervisione umana può essere soltanto apparente. D: la divulgazione involontaria può avvenire anche attraverso gli output. Il documento propone quattro esempi, uno per integrazione, che useremo nei sottotemi.");
    const d = [["FiCompass", "Uso", "17.1"], ["FiLock", "Dati", "17.2"], ["FiShield", "Sicurezza", "17.3"], ["FiUsers", "Equità", "17.4"], ["FiImage", "Contenuti", "17.5  17.6"], ["FiUserCheck", "Controllo", "17.7"]];
    for (let i = 0; i < 6; i++) {
      const x = 0.5 + i * 1.53;
      shapeBox(s, x, 1.15, 1.4, 1.5, C.background2, d[i][1]);
      await iconCircle(s, x + 0.43, 1.23, 0.54, d[i][0]);
      txt(s, d[i][1], { x: x + 0.05, y: 1.82, w: 1.3, h: 0.38, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.05, y: 2.2, w: 1.3, h: 0.32, fontSize: 11, bold: true, color: C.accent1, align: "center" });
    }
    shapeBox(s, 0.5, 2.75, 9.0, 0.45, C.accent1, "pratiche");
    txt(s, "17.8  Buone pratiche: la sintesi operativa di tutte le dimensioni", { x: 0.7, y: 2.75, w: 8.6, h: 0.45, fontSize: 13, bold: true, color: C.background1, valign: "middle" });
    const p = ["A  Un dato rimosso non è un dato anonimizzato", "B  Il prompt injection da contenuti innocui", "C  La supervisione può essere solo apparente", "D  La divulgazione anche attraverso gli output"];
    p.forEach((t, i) => chip(s, 0.5 + (i % 2) * 4.6, 3.4 + Math.floor(i / 2) * 0.6, 4.4, 0.5, t, { fill: C.accent6, fontSize: 12 }));
    txt(s, "Quattro esempi, ripresi nei sottotemi.", { x: 0.5, y: 4.62, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi. Quattro hanno priorità molto alta: la protezione dei dati, la sicurezza e i rischi specifici, il controllo umano, le buone pratiche. Tre hanno priorità alta: l'appropriatezza, i bias, la proprietà intellettuale. Uno, la trasparenza e i contenuti sintetici, ha priorità media. Da comprendere e applicare: la condivisione appropriata delle informazioni, i rischi di prompt injection, il controllo umano effettivo, le precauzioni quotidiane, la scelta di fermarsi o chiedere supporto. Da conoscere e riconoscere: bias, discriminazioni, contenuti ingannevoli, diritti sui contenuti, divulgazione involontaria. Solo da introdurre: analisi tecnica degli attacchi, crittografia, implementazione dei controlli, analisi giuridiche specialistiche, metodologie formali di gestione del rischio. Confini: non ripetiamo il funzionamento delle allucinazioni del Tema 3, i metodi di verifica del Tema 7, la generazione di media del Tema 10, le architetture degli agenti del Tema 11, l'organizzazione degli accessi del Tema 14, l'analisi organizzativa dello Shadow AI del Tema 16. E non approfondiamo obblighi normativi, responsabilità formali e governance, che sono del Tema 18.");
    pathSlide(s, [["17.1", "Che cosa significa uso responsabile", "Alta"], ["17.2", "Protezione dei dati e riservatezza", "Alta"], ["17.3", "Sicurezza e rischi specifici", "Alta"], ["17.4", "Bias, discriminazioni ed equità", "Alta"], ["17.5", "Trasparenza e contenuti sintetici", "Media"], ["17.6", "Proprietà intellettuale", "Alta"], ["17.7", "Controllo umano e responsabilità", "Alta"], ["17.8", "Buone pratiche per un uso sicuro", "Alta"]],
      [["Comprendere e applicare", "Condivisione delle informazioni, prompt injection, controllo effettivo, precauzioni, fermarsi", C.accent1, C.background1], ["Conoscere e riconoscere", "Bias, contenuti ingannevoli, diritti, divulgazione involontaria", C.accent6, C.text1], ["Solo introdurre", "Analisi degli attacchi, crittografia, controlli tecnici, analisi giuridiche", C.background2, C.text1]]);
    txt(s, "Priorità molto alta: 17.2, 17.3, 17.7, 17.8", { x: 0.5, y: 4.95, w: 5.6, h: 0.25, fontSize: 10, italic: true, color: C.accent5 });
  }

  // =====================================================================
  section("17.1 Uso responsabile");
  divider("17.1", "Che cosa significa uso responsabile", "Valutare l'appropriatezza dell'uso e le sue conseguenze, non soltanto comodità e prestazioni dello strumento", "Primo sottotema, da comprendere. Prima dei rischi specifici, costruiamo il criterio generale: che cosa vuol dire usare l'AI in modo consapevole e responsabile in un contesto professionale? Vediamo la differenza tra ciò che l'AI può fare e ciò che è opportuno farle fare, la valutazione congiunta di benefici e rischi, le conseguenze per le diverse persone coinvolte, i livelli di criticità, la distinzione tra errore, danno e rischio, il ruolo del giudizio professionale e la differenza tra precauzione proporzionata e rinuncia. Il documento distingue: il 17.1 definisce i criteri, il 17.8 i comportamenti.");
  {
    const s = content("Può fare, è opportuno farle fare", "La prima domanda guida: quando è appropriato usare l'AI in un'attività professionale? Il sottotema parte da una distinzione semplice e decisiva: ciò che l'AI può fare non coincide con ciò che è opportuno farle fare. Gli strumenti attuali possono fare molte cose: scrivere, riassumere, analizzare, valutare, generare immagini e voci, agire su applicazioni. La domanda tecnica, 'ci riesce?', ha spesso risposta positiva. Ma la domanda professionale è diversa: è appropriato, qui, per questo scopo, con queste informazioni, con queste conseguenze? Per esempio: l'AI può scrivere un messaggio di condoglianze a un cliente; è opportuno inviarlo senza rileggerlo e personalizzarlo? L'AI può riassumere le valutazioni dei dipendenti; è opportuno caricarle in un servizio non approvato? L'AI può generare la voce di un dirigente per un video interno; è opportuno farlo senza il suo consenso? Consapevolezza e responsabilità, nel senso del sottotema, significano porsi la seconda domanda, non solo la prima. È la stessa logica vista nel Tema 15 per le opportunità, applicata qui al singolo uso quotidiano. Esempi fittizi.");
    riskTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.5, "Che cosa può fare? Una domanda tecnica", "Scrivere, riassumere, valutare, generare voci e immagini, agire su applicazioni: spesso sì.", { fontSize: 13 });
    docBox(s, 5.15, 1.15, 4.35, 1.5, "È opportuno? Una domanda professionale", "Qui, per questo scopo, con queste informazioni, con queste conseguenze?", { fontSize: 13, fill: C.accent6 });
    rowList(s, ["Un messaggio di condoglianze a un cliente: inviato senza rileggerlo?", "Le valutazioni dei dipendenti: caricate in un servizio non approvato?", "La voce di un dirigente per un video: senza il suo consenso?"], { y: 2.95, h: 0.42, gap: 0.06, fontSize: 12 });
    txt(s, "Esempi fittizi", { x: 0.5, y: 4.85, w: 9, h: 0.25, fontSize: 10, italic: true, color: C.text2 });
  }
  {
    const s = content("Chi può essere coinvolto", "Il sottotema chiede di valutare benefici, limiti e rischi insieme, e di considerare le conseguenze per l'organizzazione, i clienti, i collaboratori e i terzi. Valutarli insieme significa non guardare solo ai benefici, come spesso accade nell'entusiasmo, né solo ai rischi, come accade nella paura. Un uso è appropriato quando i benefici giustificano i rischi residui, tenendo conto dei limiti dello strumento. Le conseguenze possono riguardare persone diverse, e non sempre chi usa lo strumento è chi ne subisce gli effetti. L'organizzazione: danni economici, reputazionali, legali, perdita di informazioni riservate. I clienti: risposte sbagliate, trattamento dei loro dati, decisioni che li riguardano. I collaboratori: valutazioni, informazioni personali, carichi di lavoro. I terzi: persone citate nei documenti, autori di opere usate, destinatari di contenuti ingannevoli. Una domanda pratica prima di un uso delicato: chi potrebbe essere toccato da questo, e se fosse al mio posto, sarebbe d'accordo con come lo sto facendo? È una domanda semplice che aiuta a vedere conseguenze che altrimenti sfuggono.");
    riskTag(s, 0);
    await iconGrid(s, [
      { icon: "FiBriefcase", head: "L'organizzazione", body: "Danni economici, reputazionali, legali; informazioni perse" },
      { icon: "FiSmile", head: "I clienti", body: "Risposte sbagliate, dati trattati, decisioni" },
      { icon: "FiUsers", head: "I collaboratori", body: "Valutazioni, informazioni personali, carichi" },
      { icon: "FiGlobe", head: "I terzi", body: "Persone citate, autori, destinatari di contenuti" },
    ], 2, { y: 1.15, H: 2.55, headSize: 14, bodySize: 12 });
    banner(s, 3.9, "Chi potrebbe essere toccato da questo? Se fosse al mio posto, sarebbe d'accordo con come lo sto facendo?", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Errore, danno, rischio", "Il sottotema chiede di distinguere tra errore, danno potenziale e rischio, e di ragionare, a livello concettuale, in termini di probabilità e gravità. Tre concetti che nel linguaggio comune si confondono. L'errore è un risultato sbagliato: una cifra errata in una sintesi, un nome sbagliato, una valutazione infondata. Il danno è una conseguenza negativa per qualcuno: un cliente che riceve un prezzo sbagliato, una persona discriminata, un'informazione riservata diffusa. Non ogni errore produce un danno: un errore in una bozza che viene corretta non ne produce. Il rischio è la possibilità che si verifichi un danno, e si valuta considerando due dimensioni: quanto è probabile, e quanto sarebbe grave. Un errore frequente con conseguenze lievi può avere un rischio basso; un errore raro con conseguenze gravi, irreversibili o che riguardano persone, può avere un rischio alto. La matrice in slide, puramente illustrativa, colloca alcune situazioni fittizie. Il documento chiede di restare a livello concettuale: le metodologie formali di gestione del rischio sono solo da introdurre. Il punto è abituarsi a chiedersi non solo 'può sbagliare?', ma 'se sbaglia, che cosa succede, e a chi?'.");
    riskTag(s, 0);
    const X = 0.9, Y = 1.1, W = 4.6, H = 3.3;
    const cols = [[C.background2, C.accent6], ["D9ECEA", HEX.a1]];
    [[0, 0], [1, 0], [0, 1], [1, 1]].forEach(q => {
      const gi = q[0], pi = q[1];
      shapeBox(s, X + pi * W / 2, Y + (1 - gi) * H / 2, W / 2, H / 2, gi && pi ? "A86F1C" : (gi || pi ? C.accent6 : C.background2), "quadrante " + gi + pi);
    });
    txt(s, "Gravità", { x: 0.3, y: Y + H / 2 - 0.15, w: 0.6, h: 0.3, fontSize: 11, bold: true, color: C.text1, rotate: 270, align: "center" });
    txt(s, "Probabilità", { x: X, y: Y + H + 0.02, w: W, h: 0.28, fontSize: 11, bold: true, color: C.text1, align: "center" });
    const pts = [["Refuso in una bozza interna", 0.75, 0.15], ["Dati di un collega in un servizio esterno", 0.27, 0.75], ["Prezzo errato inviato a un cliente", 0.62, 0.58], ["Valutazione di candidati non verificata", 0.8, 0.9]];
    pts.forEach(p => {
      const cx = X + p[1] * W, cy = Y + (1 - p[2]) * H;
      s.addShape(pres.shapes.OVAL, { x: cx - 0.09, y: cy - 0.09, w: 0.18, h: 0.18, fill: { color: HEX.dk1 }, line: { color: "FFFFFF", width: 1 }, objectName: "punto" });
      txt(s, p[0], { x: cx - 0.85, y: cy + 0.08, w: 1.7, h: 0.4, fontSize: 9, bold: true, color: C.text1, align: "center" });
    });
    rowsLabel(s, [["Errore", "Un risultato sbagliato"], ["Danno", "Una conseguenza negativa per qualcuno"], ["Rischio", "Possibilità di danno: probabilità e gravità"]], { y: 1.15, h: 0.75, lw: 1.0, x: 5.75, w: 3.75, fontSize: 11 });
    txt(s, "Matrice illustrativa, esempi fittizi. Se sbaglia, che cosa succede, e a chi?", { x: 5.75, y: 3.6, w: 3.75, h: 0.8, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Livelli di criticità", "Il sottotema chiede di riconoscere livelli diversi di criticità delle attività, e la rilevanza del contesto e dello scopo. Non tutte le attività richiedono la stessa cautela. Una scala semplice, con tre livelli, aiuta a orientarsi; non è una classificazione ufficiale, ma uno strumento di ragionamento. Bassa criticità: attività interne, reversibili, senza dati personali o riservati, con risultati facili da controllare. Per esempio riformulare un testo, generare idee, preparare una bozza per uso personale. Media criticità: attività che producono effetti verso altri, o che trattano informazioni interne, o i cui errori sono meno visibili. Per esempio una comunicazione a un cliente, una sintesi per un responsabile, un'analisi su cui altri si baseranno. Alta criticità: attività che riguardano persone e decisioni su di loro, che trattano dati personali o molto riservati, che producono effetti difficili da annullare, o in ambiti regolati. Per esempio la valutazione di candidati o dipendenti, comunicazioni con effetti legali, informazioni sanitarie, azioni automatiche su sistemi. Lo stesso strumento può servire attività di criticità molto diversa: è lo scopo, e il contesto, che determina il livello.");
    riskTag(s, 0);
    const l = [["Bassa", "Interne, reversibili, senza dati sensibili, facili da controllare", "Riformulare, generare idee, bozze personali", C.background2, C.text1], ["Media", "Effetti verso altri, informazioni interne, errori meno visibili", "Comunicazione a un cliente, sintesi per un responsabile", C.accent6, C.text1], ["Alta", "Persone e decisioni su di loro, dati personali o riservati, effetti irreversibili, ambiti regolati", "Valutare candidati, effetti legali, dati sanitari, azioni automatiche", HEX.a1, C.background1]];
    l.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.85, e[3], "livello " + e[0]);
      txt(s, e[0], { x: 0.7, y, w: 1.2, h: 0.85, fontSize: 16, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 1.9, y: y + 0.05, w: 7.4, h: 0.38, fontSize: 12, bold: true, color: e[4] });
      txt(s, e[2], { x: 1.9, y: y + 0.43, w: 7.4, h: 0.38, fontSize: 11, italic: true, color: e[4] });
    });
    banner(s, 4.1, "Non una classificazione ufficiale, ma uno strumento di ragionamento: è lo scopo, e il contesto, che determina il livello.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Giudizio e responsabilità", "Due punti del sottotema legati tra loro. La responsabilità dell'utilizzatore nel rispettare le indicazioni applicabili: chi usa l'AI nel proprio lavoro risponde del proprio comportamento, e in particolare del rispetto delle regole aziendali sugli strumenti, sulle informazioni, sugli usi consentiti. Non si tratta di conoscere le norme nel dettaglio, che sono del Tema 18, ma di conoscere e seguire le indicazioni che riguardano il proprio lavoro, e di chiedere quando non sono chiare. Il ruolo del giudizio professionale, e la capacità di riconoscere quando non usare l'AI: il giudizio professionale è ciò che permette di valutare l'appropriatezza, e nessuno strumento lo sostituisce. Saper riconoscere quando non usare l'AI è una competenza, non una debolezza. Alcuni segnali: quando l'attività richiede empatia e presenza personale, come una conversazione difficile; quando le informazioni sono troppo sensibili per lo strumento disponibile; quando non si è in grado di verificare il risultato; quando le conseguenze di un errore sarebbero gravi e il beneficio piccolo; quando le regole non lo consentono. In questi casi, fare a meno dell'AI è la scelta responsabile.");
    riskTag(s, 0);
    await card(s, 0.5, 1.15, 4.35, 2.5, { icon: "FiBookmark", head: "La responsabilità dell'utilizzatore", headSize: 14, bodySize: 12, body: "Conoscere e seguire le indicazioni che riguardano il proprio lavoro: strumenti, informazioni, usi consentiti.\n\nChiedere quando non sono chiare." });
    await card(s, 5.15, 1.15, 4.35, 2.5, { icon: "FiStopCircle", head: "Quando non usare l'AI", headSize: 14, bodySize: 12, fill: C.accent6, body: bullets(["Serve empatia e presenza personale", "Informazioni troppo sensibili per lo strumento", "Non si può verificare il risultato", "Errore grave, beneficio piccolo", "Le regole non lo consentono"], { space: 2 }) });
    banner(s, 3.85, "Saper riconoscere quando non usare l'AI è una competenza, non una debolezza.", { h: 0.85, fontSize: 15 });
  }
  {
    const s = content("Proporzione, non rinuncia", "L'ultimo punto del sottotema, e il tono di tutto il modulo: la differenza tra precauzione proporzionata e rinuncia indiscriminata alla tecnologia. Parlare di rischi può produrre due reazioni sbagliate. La prima è ignorarli, per comodità o per entusiasmo: usare qualsiasi strumento, con qualsiasi informazione, per qualsiasi scopo, fidandosi dei risultati. La seconda è la rinuncia indiscriminata: concludere che l'AI è troppo rischiosa e non usarla affatto, o usarla di nascosto. Anche la rinuncia ha costi: perdere benefici reali, come visto nei Temi 12-16, e spesso spingere le persone verso strumenti non controllati, come visto con lo Shadow AI nel Tema 16. La precauzione proporzionata sta in mezzo: cautele leggere per le attività a bassa criticità, più attente per quelle a media criticità, rigorose, o la rinuncia, per quelle ad alta criticità. È lo stesso principio di proporzionalità della verifica visto nel Tema 7, esteso a tutti i rischi. La consapevolezza del sottotema: valutare l'appropriatezza dell'uso e le sue conseguenze, non soltanto la comodità e le prestazioni dello strumento.");
    riskTag(s, 0);
    const z = [["Ignorare i rischi", "Qualsiasi strumento, informazione, scopo; fiducia nei risultati", C.background2, C.accent5], ["Precauzione proporzionata", "Cautele leggere, attente o rigorose secondo la criticità", HEX.a1, C.background1], ["Rinuncia indiscriminata", "Nessun uso, o uso nascosto: benefici persi, Shadow AI", C.background2, C.accent5]];
    z.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.4, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.3, w: 2.56, h: 0.65, fontSize: 16, bold: true, color: i === 1 ? C.background1 : e[3], align: "center", valign: "middle" });
      txt(s, e[1], { x: x + 0.15, y: 2.05, w: 2.56, h: 1.35, fontSize: 12, color: i === 1 ? C.background1 : C.text1, align: "center" });
    });
    banner(s, 3.8, "Valutare appropriatezza e conseguenze, non solo comodità e prestazioni dello strumento.", { h: 0.85, fontSize: 15 });
  }
  keySlide("Usare l'AI responsabilmente significa chiedersi non solo che cosa può fare, ma che cosa è opportuno farle fare, qui, con queste informazioni e queste conseguenze.", "Sottotema 17.1  ·  Che cosa significa uso responsabile", "Concetto chiave del primo sottotema. Ciò che l'AI può fare non coincide con ciò che è opportuno. Benefici e rischi si valutano insieme, pensando a tutti i coinvolti. Errore, danno e rischio sono diversi; il rischio combina probabilità e gravità. Le attività hanno criticità diverse, determinate da scopo e contesto. Il giudizio professionale include saper riconoscere quando non usare l'AI. La precauzione è proporzionata, non una rinuncia. Esercizio suggerito: elencare cinque usi dell'AI nel proprio lavoro e classificarli per criticità bassa, media o alta, indicando che cosa determina il livello.");
