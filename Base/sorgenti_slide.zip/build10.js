const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 10: AI multimodale e creazione di contenuti";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 10  ·  AI multimodale e creazione di contenuti";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function opTag(s, active) {
    const st = ["Interpretare", "Generare", "Trasformare"];
    const act = Array.isArray(active) ? active : [active];
    st.forEach((t, i) => {
      const x = 6.62 + i * 0.97, on = act.indexOf(i) >= 0;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.92, h: 0.26, rectRadius: 0.13, fill: { color: on ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "operazione " + t });
      txt(s, t, { x, y: 0.42, w: 0.92, h: 0.26, fontSize: 9, bold: true, color: on ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1, italic: !!o.italic });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, 0.5, y, 9.0, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: 0.7 + lw, y, w: 8.6 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 10", { placeholder: "kicker" });
    s.addText("AI multimodale e creazione di contenuti", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI", { placeholder: "sub" });
    s.addNotes("Benvenuti al decimo tema, il terzo dell'area 'Esplorare le possibilità dell'AI'. Nel Tema 8 abbiamo lavorato su testi e documenti, nel Tema 9 sui dati. Qui allarghiamo lo sguardo alle altre modalità attraverso cui le informazioni si presentano: immagini, audio, video, e i materiali di comunicazione che le combinano, come le presentazioni. I sistemi AI attuali non lavorano più solo con il testo: possono descrivere una fotografia, leggere una schermata, trascrivere una riunione, generare un'immagine o un breve video, trasformare un documento in slide. Sono possibilità che cambiano molte attività quotidiane, dalla comunicazione alla formazione, dal supporto tecnico all'accessibilità. E portano con sé una questione nuova e importante: un contenuto può essere molto realistico senza essere autentico. Il punto di vista resta quello dell'utilizzatore: non entriamo nelle architetture dei modelli multimodali né nella produzione audiovisiva professionale. Suggerimento per l'apertura: mostrare due immagini, una fotografia reale e una generata, e chiedere ai partecipanti di indovinare quale sia quale. La difficoltà del compito introduce bene il tema. Usare immagini prive di persone reali riconoscibili o di marchi.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la comprensione delle principali possibilità offerte dall'AI multimodale nella percezione, interpretazione, generazione e trasformazione di contenuti visivi, sonori e audiovisivi, riconoscendo opportunità applicative, condizioni di efficacia e limiti. La consapevolezza da sviluppare ha due parti. La prima: l'AI può comprendere, produrre e trasformare informazioni attraverso modalità diverse, e questo apre possibilità concrete in molti ambiti di lavoro. La seconda: un contenuto realistico non è necessariamente autentico, e una trasformazione da una modalità all'altra può introdurre errori, omissioni o alterazioni del significato. Il concetto centrale del tema: l'AI multimodale amplia le possibilità di comprendere, creare e trasformare contenuti attraverso testo, immagini, audio e video; il realismo non garantisce autenticità e ogni trasformazione richiede attenzione alla fedeltà, alla correttezza e all'adeguatezza delle informazioni. Un principio di metodo indicato dal documento: le capacità effettive vanno sempre ricondotte allo specifico sistema, e non dedotte genericamente dall'etichetta 'multimodale'.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Conoscere le possibilità dell'AI su immagini, audio e video", "Distinguere interpretare, generare e trasformare", "Riconoscere opportunità, condizioni di efficacia e limiti"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Un contenuto realistico non è necessariamente autentico.\n\nOgni passaggio tra modalità può introdurre errori, omissioni o alterazioni del significato.\n\nLe capacità dipendono dal sistema, non dall'etichetta 'multimodale'." });
  }
  {
    const s = content("Dieci domande guida", "Le dieci domande guida accompagnano il modulo. Le prime due sono concettuali: che cosa significa multimodale, e in che cosa differiscono interpretazione, generazione e trasformazione dei contenuti. Le successive quattro percorrono le modalità: immagini da comprendere, immagini da generare e modificare, audio e parlato, video. La settima riguarda presentazioni e materiali di comunicazione. Le ultime tre riguardano i temi trasversali: che cosa può andare perduto passando da una modalità all'altra, come distinguere realismo, autenticità e accuratezza, e quali opportunità offre la multimodalità per l'accessibilità delle informazioni. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Che cosa significa AI multimodale?", "Interpretare, generare, trasformare: che differenza c'è?", "Come comprende immagini, diagrammi e schermate?", "Possibilità e limiti della generazione di immagini?", "Come elabora parlato e registrazioni?", "Quali capacità applicate ai video?", "Come supporta presentazioni e materiali?", "Che cosa si perde passando da una modalità all'altra?", "Come distinguere realismo, autenticità, accuratezza?", "Quali opportunità per l'accessibilità?"], 5, 1.2, 1.6, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in quattro dimensioni complementari. Comprendere le modalità: che cosa significa multimodalità e come sono rappresentate le informazioni, nel sottotema 10.1. Interpretare e generare contenuti nelle diverse modalità: immagini, audio, video e materiali comunicativi, nei sottotemi dal 10.2 al 10.6. Trasformare e combinare, cioè passare tra più modalità preservando significato e utilità, nel 10.7. Valutare i risultati: autenticità, accuratezza, provenienza, fedeltà e limiti, nel 10.8. Trasversale a tutto il tema c'è la distinzione, chiesta dalla seconda domanda guida, tra tre operazioni: interpretare un contenuto, cioè comprenderlo e descriverlo; generarne uno nuovo; trasformarlo da una forma all'altra. Sono operazioni con rischi diversi: interpretare può portare a errori di riconoscimento; generare può produrre contenuti realistici ma non autentici; trasformare può far perdere o alterare informazioni. Nelle slide, un indicatore in alto a destra ricorda di quale operazione si sta parlando.");
    const d = [["FiLayers", "Comprendere le modalità", "10.1"], ["FiImage", "Interpretare e generare", "10.2  10.3  10.4  10.5  10.6"], ["FiRepeat", "Trasformare e combinare", "10.7"], ["FiShield", "Valutare i risultati", "10.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.1, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.03, w: 1.9, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.7, w: 1.9, h: 0.4, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Trasversali: tre operazioni con rischi diversi", { x: 0.5, y: 3.4, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    const o = [["Interpretare", "Errori di riconoscimento"], ["Generare", "Realistico ma non autentico"], ["Trasformare", "Informazioni perse o alterate"]];
    o.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 3.8, 2.86, 1.1, C.accent6, e[0]);
      txt(s, e[0], { x: x + 0.15, y: 3.88, w: 2.56, h: 0.38, fontSize: 15, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 4.3, w: 2.56, h: 0.5, fontSize: 12, color: C.text1 });
    });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, il video, con priorità media. Vanno compresi e sperimentati: interpretazione di immagini, generazione e modifica visiva, trascrizione, interazione vocale e trasformazioni tra modalità. Vanno conosciuti: generazione video, presentazioni, accessibilità, autenticità, provenienza e controlli di coerenza. Vanno solo accennati: architetture multimodali, modelli di diffusione, editing professionale, produzione audiovisiva specialistica e verifica forense tecnica. Confini: non ripetiamo i meccanismi del Tema 2, la teoria degli errori del Tema 3, i confronti commerciali tra strumenti del Tema 4, le tecniche di prompting del Tema 6, la metodologia di verifica del Tema 7. Il confine più importante è con il Tema 8: lì si trattava la conoscenza contenuta nei documenti, qui le modalità visive, sonore e audiovisive. Non progettiamo workflow automatizzati, che appartengono al Tema 11, e introduciamo autenticità e diritti senza analizzare gli obblighi giuridici, che appartengono all'area della responsabilità. Un'avvertenza pratica: immagini, registrazioni e video aziendali possono contenere dati personali o riservati, e vanno caricati solo negli strumenti autorizzati.");
    pathSlide(s, [["10.1", "Fondamenti dell'AI multimodale", "Alta"], ["10.2", "Comprensione delle immagini", "Alta"], ["10.3", "Generazione e modifica delle immagini", "Alta"], ["10.4", "Audio, voce e parlato", "Alta"], ["10.5", "Comprensione e generazione video", "Media"], ["10.6", "Presentazioni e comunicazione", "Alta"], ["10.7", "Trasformazioni tra modalità", "Alta"], ["10.8", "Limiti, autenticità, affidabilità", "Alta"]],
      [["Comprendere e sperimentare", "Interpretare immagini, generare e modificare, trascrivere, voce, trasformazioni", C.accent1, C.background1], ["Conoscere", "Video, presentazioni, accessibilità, autenticità, provenienza, coerenza", C.accent6, C.text1], ["Solo accennare", "Architetture, modelli di diffusione, editing professionale, verifica forense", C.background2, C.text1]]);
  }

  // =====================================================================
  section("10.1 Fondamenti");
  divider("10.1", "Fondamenti dell'AI multimodale", "Capacità effettive e modalità supportate dipendono dal sistema impiegato", "Partiamo dai concetti. Che cosa significa che un sistema AI è multimodale? Quali sono le modalità, che cosa vuol dire comprenderle o generarle, e come si realizza in pratica un sistema multimodale? In questo sottotema, da comprendere, costruiamo il vocabolario per tutto il modulo. Senza entrare nelle architetture, che il documento chiede solo di accennare, vedremo una distinzione importante: quella tra un modello che elabora più modalità e un'applicazione che combina più modelli specializzati. È una distinzione che spiega perché due strumenti entrambi 'multimodali' possono avere capacità molto diverse.");
  {
    const s = content("Che cosa significa multimodale", "Una modalità è una forma in cui l'informazione si presenta: testo, immagini, audio, video. Gli esseri umani sono naturalmente multimodali: in una riunione ascoltiamo le parole, guardiamo le slide, osserviamo le espressioni, leggiamo gli appunti, e integriamo tutto in una comprensione unica. I primi sistemi di AI generativa erano essenzialmente testuali: ricevevano testo e producevano testo. Un sistema multimodale può ricevere e, in alcuni casi, produrre informazioni in più modalità: può ricevere una fotografia e una domanda scritta, una registrazione audio, una schermata, e rispondere con un testo, un'immagine, una voce. Le quattro modalità principali sono quelle in slide. Il testo, che resta la modalità centrale e spesso il ponte tra le altre. Le immagini: fotografie, illustrazioni, diagrammi, schermate, documenti scansionati. L'audio: parlato, musica, suoni. Il video: sequenze di immagini nel tempo, spesso con audio. Ciascuna modalità ha caratteristiche proprie, e un sistema può gestirne bene alcune e meno bene altre.");
    opTag(s, -1);
    const m = [["FiType", "Testo", "La modalità centrale, spesso il ponte tra le altre"], ["FiImage", "Immagini", "Fotografie, illustrazioni, diagrammi, schermate, scansioni"], ["FiMic", "Audio", "Parlato, musica, suoni"], ["FiFilm", "Video", "Immagini nel tempo, spesso con audio"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.4, i === 0 ? C.accent6 : C.background2, m[i][1]);
      await iconCircle(s, x + 0.68, 1.3, 0.8, m[i][0]);
      txt(s, m[i][1], { x: x + 0.1, y: 2.2, w: 1.95, h: 0.42, fontSize: 17, bold: true, color: C.text1, align: "center" });
      txt(s, m[i][2], { x: x + 0.15, y: 2.65, w: 1.85, h: 0.8, fontSize: 11, color: C.text2, align: "center" });
    }
    banner(s, 3.8, "Gli esseri umani sono naturalmente multimodali: in una riunione integriamo parole, slide, espressioni e appunti.", { h: 0.65, fontSize: 13 });
    txt(s, "Un sistema può gestire bene alcune modalità e meno bene altre.", { x: 0.5, y: 4.58, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Testuali e multimodali", "Confrontiamo un sistema solo testuale con uno multimodale, dal punto di vista di chi lo usa. Con un sistema testuale, per chiedere aiuto su un errore che compare a schermo bisogna descriverlo a parole; per analizzare un grafico bisogna trascriverne i valori; per riassumere una riunione bisogna prima averla trascritta. Con un sistema multimodale si può mostrare direttamente la schermata, caricare l'immagine del grafico, fornire la registrazione. L'interazione diventa più naturale e più rapida, e si possono affrontare compiti prima impossibili. Ma ci sono due conseguenze meno evidenti. La prima: si aggiunge un passaggio di interpretazione. Quando descriviamo noi la schermata, siamo noi a scegliere che cosa è rilevante; quando la carichiamo, è il sistema a interpretarla, e può sbagliare, per esempio leggendo male un numero o non notando un dettaglio. La seconda: si condividono più informazioni di quante se ne intendano condividere. Una schermata può contenere nomi, email, dati di clienti visibili in un'altra finestra; una fotografia può contenere documenti sulla scrivania; una registrazione contiene le voci di tutti i presenti.");
    opTag(s, 0);
    table(s, [["Compito", "Sistema testuale", "Sistema multimodale"],
      ["Un errore a schermo", "Descriverlo a parole", "Mostrare la schermata"],
      ["Un grafico da analizzare", "Trascriverne i valori", "Caricare l'immagine"],
      ["Una riunione da riassumere", "Trascriverla prima", "Fornire la registrazione"]],
      { y: 1.15, colW: [3.0, 3.0, 3.0], rowH: 0.45, fontSize: 13, accentCol: 2, blankCorner: false });
    await card(s, 0.5, 3.1, 4.35, 1.85, { icon: "FiEye", inline: true, head: "Un passaggio di interpretazione in più", headSize: 13, bodySize: 12, body: "Non scegliamo più noi che cosa è rilevante: lo interpreta il sistema, e può sbagliare." });
    await card(s, 5.15, 3.1, 4.35, 1.85, { icon: "FiLock", inline: true, head: "Più informazioni del previsto", headSize: 13, bodySize: 12, fill: C.accent6, body: "Nomi in un'altra finestra, documenti sulla scrivania, le voci di tutti i presenti." });
  }
  {
    const s = content("Comprendere e generare", "Una distinzione fondamentale del sottotema: comprendere e generare. Comprendere una modalità significa ricevere un contenuto in quella forma ed estrarne informazioni: descrivere un'immagine, trascrivere un audio, riassumere un video. Generare significa produrre un contenuto in quella forma: creare un'immagine, sintetizzare una voce, produrre un video. Le due capacità sono indipendenti: un sistema può comprendere bene le immagini senza saperle generare, o generare audio senza comprenderlo. La tabella in slide incrocia modalità e capacità con esempi concreti. Si aggiunge una terza operazione, la trasformazione, che combina le prime due: si comprende un contenuto in una modalità e se ne genera uno in un'altra, come da un audio a una trascrizione, da un testo a un'immagine, da un documento a una presentazione. Sono le tre operazioni del filo conduttore. Ricordiamo che i rischi sono diversi: comprendere può portare a errori di riconoscimento e di interpretazione; generare a contenuti plausibili ma inventati o non autentici; trasformare a perdite e alterazioni di significato.");
    opTag(s, [0, 1]);
    table(s, [["Modalità", "Comprendere", "Generare"],
      ["Immagini", "Descrivere una foto, leggere una schermata", "Creare un'illustrazione, modificare una foto"],
      ["Audio", "Trascrivere una riunione, riconoscere il parlato", "Sintetizzare una voce, leggere un testo"],
      ["Video", "Riassumere un filmato, individuare eventi", "Produrre una breve animazione"]],
      { y: 1.15, colW: [1.8, 3.6, 3.6], rowH: 0.5, fontSize: 12, blankCorner: false });
    shapeBox(s, 0.5, 3.35, 9.0, 0.85, C.accent6, "trasformare");
    txt(s, [{ text: "Trasformare ", options: { bold: true, color: C.accent1 } }, { text: "combina le due: comprendere in una modalità e generare in un'altra. Audio in testo, testo in immagine, documento in slide.", options: { color: C.text1 } }], { x: 0.7, y: 3.35, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
    txt(s, "Le capacità sono indipendenti: si può comprendere una modalità senza saperla generare, e viceversa.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Interazioni che combinano modalità", "Il valore più interessante della multimodalità non sta nel trattare ogni modalità separatamente, ma nel combinarle in una stessa interazione. Alcuni esempi tipici del lavoro quotidiano. Una fotografia di una lavagna con gli appunti di una riunione, accompagnata dalla richiesta di trasformarli in un elenco di azioni. Una schermata di un messaggio di errore, con la domanda 'che cosa devo fare?'. La foto di un componente guasto, con la richiesta di identificarlo e di trovare la procedura di sostituzione nel manuale caricato. Una registrazione di una riunione insieme alle slide presentate, per produrre un verbale che colleghi ciò che è stato detto a ciò che è stato mostrato. Una conversazione vocale con un assistente mentre si guida o si lavora con le mani occupate. In tutti questi casi, il sistema deve integrare informazioni di natura diversa, ed è proprio nell'integrazione che nascono sia il valore sia i rischi: il sistema può collegare in modo errato elementi di modalità diverse, per esempio attribuire a una slide un commento detto su un'altra.");
    opTag(s, [0, 2]);
    await iconGrid(s, [
      { icon: "FiClipboard", head: "Foto della lavagna + richiesta", body: "Gli appunti diventano un elenco di azioni" },
      { icon: "FiMonitor", head: "Schermata di errore + domanda", body: "'Che cosa devo fare?'" },
      { icon: "FiTool", head: "Foto di un componente + manuale", body: "Identificarlo e trovare la procedura" },
      { icon: "FiMic", head: "Registrazione + slide", body: "Un verbale che collega detto e mostrato" },
    ], 2, { y: 1.15, H: 2.6, headSize: 13, bodySize: 12 });
    banner(s, 3.95, "Il valore e i rischi nascono nell'integrazione: elementi di modalità diverse possono essere collegati in modo errato.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Un modello o più modelli?", "Una distinzione che il documento chiede di introdurre, senza entrare nelle architetture: la differenza tra un modello multimodale e un'applicazione che combina modelli specializzati. Un modello multimodale nativo è addestrato per elaborare più modalità insieme: riceve, per esempio, immagini e testo come input dello stesso modello. Un'applicazione che combina modelli specializzati collega più sistemi diversi: un modello di riconoscimento vocale trascrive l'audio, un modello linguistico elabora la trascrizione, un modello di sintesi vocale legge la risposta. Per l'utente le due soluzioni possono sembrare identiche: in entrambi i casi si parla e si riceve una risposta vocale. Ma il comportamento può essere diverso. In una catena di modelli, ogni passaggio può introdurre errori che si propagano, e alcune informazioni si perdono: se l'audio viene prima trascritto, il tono, le pause e l'enfasi della voce non arrivano al modello linguistico. In un modello nativo, alcune di queste informazioni possono essere conservate. Nella pratica, molti strumenti combinano entrambe le soluzioni. La conseguenza per l'utente è il principio del documento: le capacità effettive dipendono dal sistema impiegato.");
    opTag(s, -1);
    txt(s, "Applicazione che combina modelli specializzati", { x: 0.5, y: 1.12, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const ch = ["Voce", "Riconoscimento vocale", "Modello linguistico", "Sintesi vocale", "Risposta"];
    ch.forEach((t, i) => {
      chip(s, 0.5 + i * 1.84, 1.5, 1.6, 0.65, t, { fill: i === 0 || i === 4 ? C.background2 : C.accent6, fontSize: 11 });
      if (i < 4) arrow(s, 2.12 + i * 1.84, 1.66, 0.2);
    });
    txt(s, "Ogni passaggio può introdurre errori; tono, pause ed enfasi si perdono nella trascrizione", { x: 0.5, y: 2.2, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent5 });
    txt(s, "Modello multimodale nativo", { x: 0.5, y: 2.65, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.03, 1.6, 0.65, "Voce", { fill: C.background2, fontSize: 11 });
    arrow(s, 2.12, 3.19, 0.2);
    chip(s, 2.34, 3.03, 5.28, 0.65, "Un solo modello per più modalità", { fill: C.accent1, color: C.background1, fontSize: 12 });
    arrow(s, 7.64, 3.19, 0.2);
    chip(s, 7.86, 3.03, 1.6, 0.65, "Risposta", { fill: C.background2, fontSize: 11 });
    banner(s, 3.95, "Per l'utente possono sembrare identici, ma si comportano diversamente. Le capacità dipendono dal sistema.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Capacità che dipendono dal sistema", "La consapevolezza del sottotema, e uno dei principi metodologici di tutto il tema: la multimodalità può essere realizzata con architetture diverse, e le capacità effettive e le modalità supportate dipendono dal sistema impiegato. In pratica, l'etichetta 'multimodale' dice poco. Due strumenti entrambi definiti multimodali possono differire su molti aspetti: quali modalità accettano in ingresso e quali producono in uscita; quanto bene interpretano dettagli piccoli, testi nelle immagini, grafici complessi; quali lingue e accenti riconoscono nel parlato; quanto lunghi possono essere gli audio e i video elaborati; se un video viene analizzato in tutti i fotogrammi o solo in alcuni campionati; se elaborano i contenuti sul dispositivo o li inviano a un servizio esterno; quali regole d'uso e quali limiti applicano, per esempio sulla generazione di immagini di persone reali. Per questo il documento chiede di mantenere la distinzione tra concetti durevoli e funzionalità dei prodotti soggette a cambiamento. In questo modulo ci concentriamo sui primi; per le funzionalità specifiche, conviene verificare quelle degli strumenti autorizzati in azienda, che cambiano rapidamente.");
    opTag(s, -1);
    const q = ["Quali modalità in ingresso e in uscita?", "Quanto bene legge dettagli, testi, grafici?", "Quali lingue e accenti nel parlato?", "Quale durata massima di audio e video?", "Video analizzati in tutti i fotogrammi o solo in alcuni?", "Elaborazione sul dispositivo o su un servizio esterno?", "Quali regole d'uso, per esempio sulle persone reali?"];
    q.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.62;
      shapeBox(s, x, y, 4.4, 0.54, C.background2, "domanda " + (i + 1));
      txt(s, t, { x: x + 0.2, y, w: 4.0, h: 0.54, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 3.75, "L'etichetta 'multimodale' dice poco. Verificare le capacità degli strumenti autorizzati, che cambiano rapidamente.", { h: 0.75, fontSize: 13 });
    txt(s, "In questo modulo: concetti durevoli, non funzionalità dei prodotti.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("La multimodalità può essere realizzata con architetture differenti: capacità effettive e modalità supportate dipendono dal sistema impiegato.", "Sottotema 10.1  ·  Fondamenti dell'AI multimodale", "Concetto chiave del primo sottotema. Un sistema multimodale lavora con più modalità: testo, immagini, audio, video. Può comprenderle, generarle, trasformarle da una all'altra, e combinarle in un'unica interazione. Questo rende l'interazione più naturale e apre compiti nuovi, ma aggiunge un passaggio di interpretazione e può far condividere più informazioni del previsto. Un modello multimodale nativo e una catena di modelli specializzati possono sembrare uguali all'utente e comportarsi in modo diverso. Per questo le capacità vanno sempre verificate sullo strumento specifico. Esercizio suggerito: con lo strumento autorizzato in azienda, provare a fornire la stessa informazione in tre modalità diverse, per esempio una tabella scritta, una sua fotografia e una lettura ad alta voce, e confrontare le risposte.");

  // =====================================================================
  section("10.2 Immagini: comprendere");
  divider("10.2", "Comprensione e analisi delle immagini", "Descrivere ciò che appare in un'immagine non equivale a comprenderne significato, provenienza o contesto", "Entriamo nelle modalità, partendo dalla comprensione delle immagini. È una delle capacità multimodali più mature e più utili nel lavoro quotidiano: descrivere una fotografia, leggere una schermata, interpretare un diagramma, estrarre il testo da un'immagine. In questo sottotema, da conoscere e sperimentare, vediamo che cosa i sistemi sanno fare con le immagini, dove sbagliano più facilmente, e una distinzione importante: quella tra descrivere ciò che si vede e comprenderne il significato. Il confine con il Tema 8: lì abbiamo parlato di documenti scansionati per il loro contenuto testuale; qui parliamo di immagini come modalità visiva.");
  {
    const s = content("Le possibilità su un'immagine", "Le possibilità di comprensione delle immagini sono ampie. Interpretare fotografie: descrivere che cosa rappresentano, le persone, gli oggetti, l'ambiente, la situazione. Analizzare schermate e interfacce: capire che cosa mostra un programma, leggere un messaggio di errore, individuare dove cliccare. Interpretare diagrammi e contenuti visivi: schemi di processo, organigrammi, mappe, grafici. Leggere il testo presente nelle immagini: cartelli, etichette, lavagne, documenti fotografati, scritte a mano. Estrarre informazioni visive: quanti elementi, quali colori, quali condizioni, per esempio lo stato di un macchinario o di un magazzino. Identificare elementi e relazioni spaziali: che cosa sta sopra, accanto, dentro che cosa. Le applicazioni aziendali sono molte: supporto tecnico a partire da schermate, catalogazione di prodotti, controllo visivo di documenti o ambienti, accessibilità per persone con disabilità visive, digitalizzazione di appunti. In molti di questi casi il sistema fornisce in pochi secondi una descrizione utile. Ma, come vedremo, la sua affidabilità varia molto a seconda del tipo di compito.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiCamera", head: "Fotografie", body: "Persone, oggetti, ambienti, situazioni" },
      { icon: "FiMonitor", head: "Schermate e interfacce", body: "Errori, menu, dove cliccare" },
      { icon: "FiShare2", head: "Diagrammi e schemi", body: "Processi, organigrammi, mappe, grafici" },
      { icon: "FiType", head: "Testo nelle immagini", body: "Cartelli, etichette, lavagne, scritte a mano" },
      { icon: "FiSearch", head: "Informazioni visive", body: "Quantità, colori, condizioni, stato" },
      { icon: "FiMove", head: "Relazioni spaziali", body: "Sopra, accanto, dentro" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Una descrizione utile in pochi secondi. Ma l'affidabilità varia molto a seconda del compito.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Schermate e interfacce", "Le schermate meritano un approfondimento, perché sono probabilmente l'uso più frequente della comprensione visiva nel lavoro d'ufficio. Si fotografa o si cattura lo schermo e si chiede: che cosa significa questo errore? Come faccio a esportare questi dati? Dove si trova questa impostazione? Il sistema legge il testo dell'interfaccia, riconosce menu, pulsanti, campi, e può guidare passo per passo. È un supporto prezioso, che riduce le richieste ripetitive all'assistenza tecnica e aiuta con programmi poco familiari. Tre attenzioni. Prima: il sistema può riconoscere l'interfaccia ma non conoscere la versione specifica del programma o la configurazione aziendale, e suggerire passaggi che nel nostro caso non esistono. Seconda: le istruzioni operative su sistemi aziendali, specialmente quando comportano modifiche di configurazione o di dati, vanno seguite con prudenza, e in caso di dubbio con l'assistenza interna. Terza, la più importante: una schermata contiene spesso molto più di quanto si intende mostrare. Prima di condividerla, conviene ritagliarla sulla parte rilevante e verificare che non contenga dati personali, dati di clienti, credenziali, informazioni riservate in altre finestre o nelle notifiche.");
    opTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.6, "Domande tipiche", "Che cosa significa questo errore?\nCome esporto questi dati?\nDove si trova questa impostazione?", { fontSize: 13, fill: C.accent6 });
    await card(s, 5.15, 1.15, 4.35, 1.6, { icon: "FiThumbsUp", inline: true, head: "Il valore", headSize: 14, bodySize: 12, body: "Guida passo per passo, meno richieste ripetitive all'assistenza, aiuto con programmi poco familiari." });
    rowsLabel(s, [["Versione e configurazione", "Il sistema può suggerire passaggi che nel nostro caso non esistono"], ["Modifiche a sistemi aziendali", "Prudenza; in caso di dubbio, l'assistenza interna"], ["Prima di condividere", "Ritagliare; niente dati personali, credenziali, notifiche, altre finestre"]], { y: 2.95, h: 0.56, lw: 2.9 });
  }
  {
    const s = content("Diagrammi e testo nelle immagini", "Due compiti molto utili, con affidabilità diversa. Leggere il testo nelle immagini, compito che un tempo richiedeva software specifici di riconoscimento ottico, è oggi molto affidabile per testi stampati, chiari, in lingue diffuse. Diventa meno affidabile con scritture a mano, caratteri piccoli o sfocati, inclinazioni, riflessi, testi in lingue o alfabeti meno comuni. Gli errori più insidiosi riguardano numeri e codici: un 8 letto come 3, uno 0 come una O, una cifra saltata. A differenza delle parole, dove un errore produce spesso una parola senza senso facile da notare, un numero sbagliato resta un numero plausibile. Interpretare diagrammi, schemi di processo, organigrammi, mappe concettuali, è un compito più complesso, perché richiede di capire le relazioni tra gli elementi: le frecce, la gerarchia, la sequenza. I sistemi attuali lo fanno spesso bene con diagrammi semplici e ordinati, peggio con diagrammi densi, frecce che si incrociano, legende separate. L'analisi quantitativa dei grafici appartiene al Tema 9: qui ricordiamo solo che leggere valori da un grafico in un'immagine è un'operazione approssimativa, e i valori letti vanno trattati come stime.");
    opTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiType", head: "Testo nelle immagini", headSize: 15, bodySize: 12,
      body: bullets(["Molto affidabile: stampato, chiaro, lingue diffuse", "Meno: a mano, piccolo, sfocato, inclinato", "Insidiosi: numeri e codici, 8 e 3, 0 e O"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiShare2", head: "Diagrammi e schemi", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Richiedono di capire relazioni e sequenze", "Bene: semplici e ordinati", "Peggio: densi, frecce incrociate, legende separate"], { space: 5 }) });
    banner(s, 3.95, "Una parola sbagliata spesso si nota; un numero sbagliato resta un numero plausibile. I valori letti da un grafico sono stime.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Dettagli e relazioni spaziali", "Il sottotema chiede di conoscere i limiti nel riconoscimento dei dettagli. Pur essendo molto capaci, i sistemi di comprensione visiva hanno alcune debolezze ricorrenti, che è utile conoscere per sapere quando fidarsi meno. Contare: il numero di oggetti in un'immagine affollata è spesso approssimativo. Dettagli piccoli: un piccolo difetto, una cifra in un angolo, un'etichetta lontana possono non essere notati o essere letti male, anche perché le immagini vengono spesso ridotte di risoluzione prima dell'elaborazione. Relazioni spaziali: destra e sinistra, sopra e sotto, davanti e dietro, distanze e proporzioni sono fonte di errori frequenti. Orientamento e prospettiva: immagini ruotate, riflesse o con prospettive insolite. Elementi parzialmente nascosti o ambigui. In tutti questi casi, il problema è lo stesso visto per il testo nel Tema 3: il sistema risponde con la stessa sicurezza sia quando ha visto bene sia quando ha ricostruito in modo plausibile. Una tecnica pratica: per i dettagli importanti, chiedere al sistema dove si trova esattamente l'elemento descritto, e controllare; per i conteggi e le misure, considerare la risposta come una stima.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiHash", head: "Contare", body: "In immagini affollate, spesso approssimativo" },
      { icon: "FiZoomIn", head: "Dettagli piccoli", body: "Difetti, cifre, etichette lontane" },
      { icon: "FiMove", head: "Relazioni spaziali", body: "Destra e sinistra, distanze, proporzioni" },
      { icon: "FiRotateCw", head: "Orientamento", body: "Immagini ruotate, riflesse, prospettive insolite" },
    ], 4, { y: 1.2, h: 1.85, headSize: 13, bodySize: 12 });
    banner(s, 3.3, "Stessa sicurezza quando ha visto bene e quando ha ricostruito in modo plausibile.", { h: 0.7, fontSize: 14 });
    txt(s, "Per i dettagli importanti: chiedere dove si trova esattamente l'elemento, e controllare. Conteggi e misure: stime.", { x: 0.5, y: 4.2, w: 9, h: 0.6, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Descrivere o comprendere", "La distinzione più importante del sottotema. Descrivere ciò che appare in un'immagine non equivale a comprenderne il significato, la provenienza o il contesto. L'esempio in slide lo mostra. Davanti alla fotografia di un magazzino con alcuni scaffali vuoti, un sistema può dare una descrizione accurata: scaffali metallici, alcuni pieni, alcuni vuoti, un carrello elevatore, luce artificiale. Fin qui, descrizione. Ma che cosa significa? Gli scaffali vuoti indicano una carenza di scorte, un'area appena svuotata per un inventario, un reparto in riorganizzazione, o un magazzino nuovo non ancora riempito? La foto è di oggi o di due anni fa? È davvero il nostro magazzino? Queste domande riguardano il significato, la provenienza e il contesto, e non trovano risposta nell'immagine. Il sistema, se gli si chiede un'interpretazione, ne fornirà una plausibile, spesso con la stessa sicurezza della descrizione. È lo stesso passaggio visto nel Tema 9 dalla descrizione all'interpretazione dei dati, e nel Tema 7 dalla descrizione al giudizio. Nelle immagini è particolarmente insidioso, perché ciò che si vede sembra parlare da sé.");
    opTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.6, "Descrizione (ciò che appare)", "Scaffali metallici, alcuni pieni e alcuni vuoti, un carrello elevatore, luce artificiale.", { fontSize: 13, fill: C.accent6 });
    shapeBox(s, 5.15, 1.15, 4.35, 1.6, C.background2, "interpretazioni");
    txt(s, "Interpretazioni possibili", { x: 5.35, y: 1.22, w: 4.0, h: 0.3, fontSize: 11, bold: true, color: C.accent5 });
    txt(s, bullets(["Carenza di scorte", "Area svuotata per un inventario", "Reparto in riorganizzazione", "Magazzino nuovo"], { space: 2 }), { x: 5.35, y: 1.55, w: 4.0, h: 1.15, fontSize: 12, color: C.text1 });
    txt(s, "Domande a cui l'immagine non risponde", { x: 0.5, y: 2.95, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.33, 2.9, 0.55, "Che cosa significa?", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.33, 2.9, 0.55, "Quando è stata scattata?", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.33, 2.9, 0.55, "Da dove viene?", { fill: C.background2, fontSize: 12 });
    banner(s, 4.1, "Ciò che si vede sembra parlare da sé. Ma significato, provenienza e contesto non sono nell'immagine.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Immagini e persone", "Un aspetto delle immagini che merita attenzione specifica: la presenza di persone. Le fotografie e i video di lavoro contengono spesso persone: colleghi, clienti, visitatori, passanti. Tre considerazioni. La prima riguarda i dati personali: il volto e l'immagine di una persona sono dati personali, e caricarli in uno strumento AI è un trattamento di dati, che va fatto negli strumenti autorizzati e per finalità legittime. Le regole specifiche appartengono all'area della responsabilità e della normativa; qui basta ricordare che non si tratta di un'operazione neutra. La seconda riguarda il riconoscimento delle persone: molti strumenti di uso generale sono configurati per non identificare le persone dal volto, e l'identificazione biometrica è soggetta a limiti normativi specifici. Non è un compito per cui usare questi strumenti. La terza riguarda le inferenze: chiedere a un sistema di dedurre da una fotografia caratteristiche delle persone, come età, stato d'animo, intenzioni o condizioni personali, produce risposte che sembrano oggettive ma sono stime incerte, spesso influenzate da stereotipi, e possono essere usate in modo discriminatorio. Descrivere una scena è una cosa; giudicare le persone che vi compaiono è un'altra.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiUser", head: "Dati personali", body: "Volti e immagini sono dati personali: solo strumenti autorizzati, finalità legittime" },
      { icon: "FiUserX", head: "Identificazione", body: "Molti strumenti non identificano dal volto; limiti normativi specifici" },
      { icon: "FiAlertTriangle", head: "Inferenze sulle persone", body: "Età, stato d'animo, intenzioni: stime incerte, rischio di stereotipi" },
    ], 3, { y: 1.2, h: 2.1, headSize: 14, bodySize: 12 });
    banner(s, 3.55, "Descrivere una scena è una cosa; giudicare le persone che vi compaiono è un'altra.", { h: 0.75, fontSize: 15 });
    txt(s, "Regole specifiche: area responsabilità e normativa.", { x: 0.5, y: 4.45, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Descrivere ciò che appare in un'immagine non equivale a comprenderne necessariamente il significato, la provenienza o il contesto.", "Sottotema 10.2  ·  Comprensione e analisi delle immagini", "Concetto chiave del sottotema 10.2. I sistemi multimodali sanno interpretare fotografie, schermate, diagrammi e testo nelle immagini, con applicazioni concrete nel supporto tecnico, nella digitalizzazione, nell'accessibilità. Ma hanno limiti ricorrenti nei dettagli, nei conteggi, nelle relazioni spaziali e nei numeri, e rispondono con la stessa sicurezza quando vedono bene e quando ricostruiscono. Soprattutto, descrivere non è comprendere: significato, provenienza e contesto non sono nell'immagine. Le immagini con persone richiedono attenzioni specifiche. Esercizio suggerito: dare ai partecipanti una schermata o una foto fittizia con alcuni dettagli importanti piccoli, chiedere una descrizione all'AI e verificare quali dettagli sono stati letti correttamente, quali mancati e quali inventati.");

  // =====================================================================
  section("10.3 Immagini: generare");
  divider("10.3", "Generazione e trasformazione delle immagini", "La generazione visiva accelera l'esplorazione creativa, ma non garantisce controllo completo e conformità", "Dalla comprensione alla generazione. I sistemi di generazione di immagini sono tra gli strumenti di AI più noti al grande pubblico: da una descrizione testuale producono in pochi secondi illustrazioni, immagini fotorealistiche, concept, varianti. Possono anche modificare immagini esistenti: aggiungere o rimuovere elementi, cambiare lo stile, adattare il formato. In questo sottotema, da conoscere e sperimentare, vediamo le possibilità e le applicazioni nella comunicazione aziendale, ma anche i limiti di precisione e di riproducibilità, e i requisiti professionali che la generazione non garantisce automaticamente. I modelli di diffusione, la tecnologia su cui si basano molti di questi sistemi, sono solo da accennare.");
  {
    const s = content("Dalla descrizione all'immagine", "La generazione di immagini da descrizioni testuali funziona così, dal punto di vista dell'utente: si descrive ciò che si vuole, e il sistema produce una o più immagini. La descrizione può indicare il soggetto, la composizione, lo stile, i colori, l'atmosfera, il formato. Il risultato può essere un'illustrazione, un'immagine dall'aspetto fotografico, uno schizzo, un'icona, un'immagine astratta. Le tecniche di formulazione delle richieste per le immagini sono specialistiche, e il documento chiede di non svilupparle; i principi generali del Tema 6 restano validi: chiarezza, contesto, esempi, iterazione. Il punto concettuale da cogliere è un altro: la descrizione non determina l'immagine in modo univoco. La stessa richiesta produce immagini diverse a ogni generazione, e molti dettagli non descritti vengono decisi dal sistema: il volto di una persona, la disposizione degli oggetti, la luce, lo sfondo. Questo è un vantaggio per l'esplorazione creativa, perché propone soluzioni a cui non si era pensato. Ed è un limite per il controllo: è difficile ottenere esattamente ciò che si ha in mente, e ancora più difficile ottenere di nuovo la stessa immagine. Per molti sistemi è possibile ripartire da un'immagine generata e chiederne modifiche, procedendo per affinamenti successivi.");
    opTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 1.65, "Una descrizione può indicare", "Soggetto, composizione, stile, colori, atmosfera, formato.", { fontSize: 13 });
    await card(s, 5.15, 1.15, 4.35, 1.65, { icon: "FiShuffle", inline: true, head: "Non determina l'immagine", headSize: 14, bodySize: 12, fill: C.accent6, body: "Molti dettagli non descritti li decide il sistema: volti, disposizione, luce, sfondo." });
    await card(s, 0.5, 3.0, 4.35, 1.4, { head: "Un vantaggio per esplorare", headSize: 14, bodySize: 12, body: "Propone soluzioni a cui non si era pensato." });
    await card(s, 5.15, 3.0, 4.35, 1.4, { head: "Un limite per controllare", headSize: 14, bodySize: 12, body: "Difficile ottenere esattamente ciò che si ha in mente, e ottenerlo di nuovo." });
    txt(s, "Tecniche di richiesta specialistiche: non sviluppate. Valgono i principi del Tema 6.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Che cosa si può produrre", "Le tipologie di immagini che si possono generare sono molte, e il sottotema le elenca. Illustrazioni: immagini disegnate, in stili diversi, per accompagnare testi, presentazioni, materiali formativi. Immagini sintetiche dall'aspetto fotografico: ambienti, oggetti, scene, che sembrano fotografie ma non lo sono. Concept: bozze visive per esplorare un'idea, come l'allestimento di uno stand, il design di un packaging, l'atmosfera di una campagna, prima di affidarne la realizzazione a professionisti. Varianti visive: più versioni della stessa idea, con colori, composizioni o stili diversi, per confrontarle e scegliere. Elementi grafici: icone, sfondi, pattern, decorazioni. Il valore principale, nel contesto aziendale, è l'esplorazione rapida: vedere un'idea prima di investire nella sua realizzazione, provare dieci varianti in pochi minuti, dare forma visiva a un concetto astratto. Come accenna il documento, in contesti professionali la generazione è spesso un punto di partenza, non un prodotto finito: la produzione professionale richiede controllo creativo, revisione e, spesso, il lavoro di professionisti della comunicazione visiva.");
    opTag(s, 1);
    await iconGrid(s, [
      { icon: "FiFeather", head: "Illustrazioni", body: "Per testi, presentazioni, materiali formativi" },
      { icon: "FiCamera", head: "Immagini sintetiche", body: "Sembrano fotografie, ma non lo sono" },
      { icon: "FiPenTool", head: "Concept", body: "Uno stand, un packaging, un'atmosfera" },
      { icon: "FiCopy", head: "Varianti", body: "Colori, composizioni, stili da confrontare" },
      { icon: "FiGrid", head: "Elementi grafici", body: "Icone, sfondi, pattern" },
      { icon: "FiZap", head: "Esplorazione rapida", body: "Vedere un'idea prima di investire", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "In contesti professionali, spesso un punto di partenza, non un prodotto finito.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Modificare immagini esistenti", "Oltre a generare immagini nuove, i sistemi possono trasformare immagini esistenti. Il sottotema elenca le principali operazioni. Aggiungere elementi: inserire un oggetto, una persona, una scritta in una fotografia. Rimuovere elementi: cancellare un oggetto, un passante, un difetto, ricostruendo lo sfondo. Sostituire elementi: cambiare il colore di un prodotto, lo sfondo di una foto, un oggetto con un altro. Trasformare lo stile: rendere una fotografia un disegno, un acquerello, uno schizzo. Modificare la composizione: estendere un'immagine oltre i suoi bordi, cambiarne l'inquadratura. Adattare il formato: da orizzontale a verticale per i social, da alta a bassa risoluzione. Sono operazioni che un tempo richiedevano competenze di fotoritocco e ore di lavoro, e oggi si ottengono con una richiesta. Il loro valore pratico è evidente. Ma è proprio qui che nasce una delle questioni più importanti del tema, che svilupperemo nel 10.8: un'immagine modificata in modo realistico può non essere più distinguibile dall'originale. Rimuovere un elemento da una fotografia che documenta un fatto, come lo stato di un cantiere o un danno, cambia ciò che la fotografia documenta. Le modifiche alle immagini usate come documentazione richiedono quindi particolare cautela e trasparenza.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiPlusCircle", head: "Aggiungere", body: "Un oggetto, una scritta" },
      { icon: "FiMinusCircle", head: "Rimuovere", body: "Un oggetto, un difetto, un passante" },
      { icon: "FiRefreshCw", head: "Sostituire", body: "Colore, sfondo, oggetto" },
      { icon: "FiFeather", head: "Cambiare stile", body: "Da foto a disegno o acquerello" },
      { icon: "FiMaximize", head: "Composizione", body: "Estendere, reinquadrare" },
      { icon: "FiSmartphone", head: "Formato", body: "Orizzontale, verticale, risoluzione" },
    ], 3, { y: 1.15, H: 2.6, headSize: 13, bodySize: 12 });
    shapeBox(s, 0.5, 3.95, 9.0, 1.0, C.text1, "attenzione documentazione");
    txt(s, [{ text: "Attenzione: ", options: { bold: true, color: C.accent6 } }, { text: "rimuovere un elemento da una foto che documenta un fatto, come un cantiere o un danno, cambia ciò che la foto documenta. Cautela e trasparenza (10.8).", options: { color: C.background1 } }], { x: 0.7, y: 3.95, w: 8.6, h: 1.0, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Applicazioni alla comunicazione", "Vediamo alcune applicazioni concrete nella comunicazione aziendale, con il loro valore e la loro principale attenzione. Materiali interni, come presentazioni, newsletter, intranet, materiali formativi: illustrazioni per rendere più chiari e gradevoli i contenuti. È l'uso a minor rischio, a condizione di rispettare lo stile aziendale. Concept e prototipi visivi, per esplorare idee prima di affidarle a professionisti: grande risparmio di tempo nelle fasi iniziali; attenzione a non confondere il concept con il prodotto finale. Adattamento di materiali esistenti a formati diversi, per canali e destinatari differenti: rapido ed efficace; attenzione a mantenere la coerenza con l'originale e con l'identità visiva. Comunicazione esterna, come social, pubblicità, sito: possibile, ma è l'uso che richiede più attenzione, per i requisiti di marchio, i diritti, la rappresentazione delle persone e la trasparenza verso il pubblico sull'uso di immagini generate. In tutti i casi, le linee guida aziendali sull'uso delle immagini generate, quando esistono, vanno seguite. Se non esistono, è un buon segnale per chiederle.");
    opTag(s, [1, 2]);
    table(s, [["Applicazione", "Valore", "Attenzione principale"],
      ["Materiali interni", "Contenuti più chiari e gradevoli", "Coerenza con lo stile aziendale"],
      ["Concept e prototipi", "Esplorare prima di investire", "Non confonderli con il prodotto finale"],
      ["Adattamento di formati", "Rapido, per più canali", "Coerenza con originale e identità visiva"],
      ["Comunicazione esterna", "Contenuti in quantità", "Marchio, diritti, persone, trasparenza"]],
      { y: 1.15, colW: [2.5, 3.0, 3.5], rowH: 0.5, fontSize: 12, blankCorner: false, accentCol: 2 });
    banner(s, 3.85, "Seguire le linee guida aziendali sulle immagini generate. Se non esistono, è il momento di chiederle.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Limiti di precisione e riproducibilità", "Il sottotema chiede di conoscere i limiti nella precisione dei dettagli e nella riproducibilità. I principali, dal punto di vista dell'uso professionale. Il testo nelle immagini: i sistemi sono migliorati molto, ma scritte, etichette e numeri possono ancora risultare errati, deformati o inventati, specialmente se lunghi o in lingue meno comuni. I dettagli anatomici e strutturali: mani, dita, oggetti complessi, meccanismi, architetture possono contenere incoerenze che un occhio attento nota. La fedeltà ai riferimenti: chiedere di riprodurre un prodotto specifico, un luogo reale, un macchinario aziendale porta spesso a immagini simili ma non fedeli, con dettagli sbagliati che chi conosce l'oggetto riconosce subito. La riproducibilità: la stessa richiesta produce immagini diverse, e ottenere una serie di immagini coerenti tra loro, per esempio lo stesso personaggio in più scene o lo stesso prodotto da più angolazioni, è difficile, anche se alcuni strumenti offrono funzioni dedicate. Il controllo fine: spostare un elemento di pochi centimetri, cambiare un solo dettaglio senza alterare il resto, è spesso più difficile di quanto ci si aspetti. Per questi motivi, la generazione visiva è ottima per esplorare e meno adatta quando servono precisione e coerenza rigorose.");
    opTag(s, 1);
    rowsLabel(s, [["Testo nell'immagine", "Scritte, etichette e numeri errati, deformati o inventati"], ["Dettagli", "Mani, oggetti complessi, meccanismi con incoerenze"], ["Fedeltà ai riferimenti", "Un prodotto o un luogo reale: simile, ma non fedele"], ["Riproducibilità", "Stessa richiesta, immagini diverse; serie coerenti difficili"], ["Controllo fine", "Cambiare un solo dettaglio senza alterare il resto"]], { y: 1.15, h: 0.52, lw: 2.6 });
    banner(s, 4.25, "Ottima per esplorare; meno adatta quando servono precisione e coerenza rigorose.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Requisiti professionali", "La consapevolezza del sottotema dice che la generazione visiva non garantisce conformità automatica a requisiti professionali. Quali sono questi requisiti? Quattro famiglie. L'identità visiva: colori, caratteri, stile fotografico e regole d'uso del marchio aziendale. Un'immagine generata non li rispetta automaticamente, e i loghi in particolare vanno inseriti come elementi originali, non generati. I diritti: il documento chiede di introdurre il tema senza analisi normativa. Basti sapere che esistono questioni aperte sui diritti relativi alle immagini generate e ai dati usati per addestrare i sistemi, che le condizioni d'uso degli strumenti variano, e che generare immagini che imitano lo stile riconoscibile di un artista vivente, o riproducono personaggi, opere e marchi altrui, può creare problemi. Le persone: generare immagini di persone reali riconoscibili, colleghi, clienti, personaggi pubblici, solleva questioni di consenso, di immagine e di possibile inganno; molti strumenti lo limitano. La trasparenza: in alcuni contesti è opportuno, o richiesto, dichiarare che un'immagine è generata, specialmente quando potrebbe essere scambiata per una fotografia reale. Le regole specifiche appartengono all'area della responsabilità e della normativa.");
    opTag(s, 1);
    await iconGrid(s, [
      { icon: "FiDroplet", head: "Identità visiva", body: "Colori, caratteri, stile; loghi originali, non generati" },
      { icon: "FiFileText", head: "Diritti", body: "Questioni aperte; stili di artisti, personaggi e marchi altrui" },
      { icon: "FiUsers", head: "Persone reali", body: "Consenso, immagine, possibile inganno" },
      { icon: "FiEye", head: "Trasparenza", body: "Dichiarare che è generata, se può sembrare una foto" },
    ], 2, { y: 1.15, H: 2.65, headSize: 14, bodySize: 12 });
    banner(s, 4.0, "La generazione non garantisce conformità automatica a requisiti professionali. Regole specifiche: area responsabilità e normativa.", { h: 0.85, fontSize: 13 });
  }
  keySlide("La generazione visiva accelera l'esplorazione creativa ma non garantisce controllo completo, fedeltà ai riferimenti o conformità automatica a requisiti professionali.", "Sottotema 10.3  ·  Generazione e trasformazione delle immagini", "Concetto chiave del sottotema 10.3. I sistemi generano illustrazioni, immagini sintetiche, concept e varianti, e modificano immagini esistenti aggiungendo, rimuovendo o sostituendo elementi, cambiando stile e formato. Il valore principale è l'esplorazione rapida. Ma la descrizione non determina l'immagine, i dettagli e i testi possono essere errati, la fedeltà ai riferimenti e la riproducibilità sono limitate, e requisiti di marchio, diritti, persone e trasparenza non sono garantiti automaticamente. Le modifiche a immagini usate come documentazione richiedono particolare cautela. Esercizio suggerito: chiedere ai partecipanti di generare un'immagine per una slide interna su un tema fittizio, poi valutarla con una breve lista di controllo: dettagli corretti, testo corretto, coerenza con lo stile aziendale, assenza di persone reali o marchi altrui.");

  // =====================================================================
  section("10.4 Audio e voce");
  divider("10.4", "AI per audio, voce e linguaggio parlato", "L'accessibilità può migliorare grazie alle tecnologie vocali, ma trascrizioni e traduzioni richiedono controlli", "Passiamo all'audio. Le tecnologie vocali sono forse quelle con l'impatto più immediato sul lavoro quotidiano: trascrivere riunioni, interviste e telefonate, produrne sintesi, interagire con un assistente a voce, tradurre il parlato, generare una voce che legge un testo. In questo sottotema, da conoscere e sperimentare, vediamo queste capacità, i loro limiti tipici, in particolare nel riconoscimento della terminologia e nell'attribuzione delle affermazioni agli interlocutori, e la prima delle integrazioni del tema: l'AI multimodale come strumento di accessibilità.");
  {
    const s = content("Le capacità vocali", "Una panoramica delle capacità che il sottotema elenca. Il riconoscimento del parlato: il sistema capisce che cosa viene detto. È alla base di tutte le altre. La trascrizione da audio a testo: una registrazione diventa un testo, eventualmente con l'indicazione di chi parla e dei tempi. La sintesi vocale: un testo viene letto da una voce artificiale, oggi molto naturale. L'interazione vocale: si conversa a voce con un assistente, con tempi di risposta sempre più simili a una conversazione umana. La traduzione del parlato: ciò che viene detto in una lingua viene restituito in un'altra, come testo o come voce, anche quasi in tempo reale. L'analisi e la sintesi di registrazioni: dal contenuto di una riunione o di un'intervista si ricavano un riassunto, le decisioni, le azioni, i temi principali. Le applicazioni più diffuse riguardano le riunioni, le interviste, le telefonate con i clienti, la formazione, la comunicazione multilingue, e l'accessibilità, che vedremo tra poco. La qualità di tutte queste capacità è molto migliorata negli ultimi anni, ma dipende fortemente dalla qualità dell'audio, dalla lingua, dagli accenti e dalla terminologia.");
    opTag(s, [0, 1, 2]);
    await iconGrid(s, [
      { icon: "FiMic", head: "Riconoscimento", body: "Capire che cosa viene detto" },
      { icon: "FiFileText", head: "Trascrizione", body: "Da audio a testo, con chi parla e quando" },
      { icon: "FiVolume2", head: "Sintesi vocale", body: "Un testo letto da una voce naturale" },
      { icon: "FiMessageCircle", head: "Interazione vocale", body: "Conversare a voce con un assistente" },
      { icon: "FiGlobe", head: "Traduzione del parlato", body: "In un'altra lingua, anche quasi in tempo reale" },
      { icon: "FiList", head: "Analisi e sintesi", body: "Riassunto, decisioni, azioni, temi" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Qualità molto migliorata, ma dipende da audio, lingua, accenti e terminologia.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Riunioni, interviste, comunicazioni", "L'applicazione più diffusa delle tecnologie vocali in azienda è la trascrizione e la sintesi di riunioni. Molti strumenti di videoconferenza la offrono direttamente: al termine della riunione si ottengono la trascrizione completa, un riassunto, le decisioni e le azioni con i responsabili. Il valore è evidente: nessuno deve prendere appunti, chi era assente può recuperare, le azioni concordate non si perdono. Lo stesso vale per interviste, focus group, telefonate di assistenza, colloqui di formazione. Ma il passaggio dalla registrazione al verbale è una catena di trasformazioni, come vedremo nel 10.7, e ogni passaggio può introdurre errori: il riconoscimento può fraintendere parole, la trascrizione può attribuire frasi alla persona sbagliata, la sintesi può omettere obiezioni, trasformare un'ipotesi in una decisione, o un 'ci penso' in un 'sì', come abbiamo visto nel Tema 8 per i verbali. Due buone pratiche. Far rivedere il riassunto e le azioni a chi ha partecipato, prima di diffonderli. E conservare la trascrizione completa, o la registrazione quando consentito, come riferimento per verificare i punti controversi.");
    opTag(s, [0, 2]);
    const ch = [["Registrazione", C.background2], ["Trascrizione", C.accent6], ["Riassunto", C.accent6], ["Decisioni e azioni", C.accent1]];
    ch.forEach((e, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, e[0], { fill: e[1], color: i === 3 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    const r = [["Parole fraintese", "Nel riconoscimento"], ["Frasi attribuite male", "Nella trascrizione"], ["Obiezioni omesse", "Nel riassunto"], ["'Ci penso' diventa 'sì'", "Nelle decisioni"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 2.0, 2.05, 0.95, C.background2, e[0]);
      txt(s, e[0], { x: x + 0.12, y: 2.06, w: 1.85, h: 0.48, fontSize: 12, bold: true, color: C.accent5 });
      txt(s, e[1], { x: x + 0.12, y: 2.55, w: 1.85, h: 0.32, fontSize: 11, color: C.text2 });
    });
    await card(s, 0.5, 3.15, 4.35, 1.8, { icon: "FiUsers", inline: true, head: "Far rivedere ai partecipanti", headSize: 14, bodySize: 12, fill: C.accent6, body: "Riassunto e azioni, prima di diffonderli." });
    await card(s, 5.15, 3.15, 4.35, 1.8, { icon: "FiArchive", inline: true, head: "Conservare la trascrizione", headSize: 14, bodySize: 12, body: "O la registrazione, quando consentito, come riferimento per i punti controversi." });
  }
  {
    const s = content("Errori di riconoscimento", "Il sottotema chiede di conoscere i limiti nel riconoscimento di voci e terminologia. Gli errori tipici delle trascrizioni sono prevedibili, e conoscerli aiuta a controllarle in modo mirato. Nomi propri: persone, aziende, prodotti, luoghi, specialmente se stranieri o poco comuni. Terminologia tecnica e sigle aziendali: parole che il sistema non conosce vengono sostituite con parole simili nel suono ma diverse nel significato. Numeri: cifre, importi, date, percentuali, dove un errore è grave e poco visibile, come 'quindici' e 'cinquanta', o 'diciotto per cento' e 'otto per cento'. Accenti, dialetti, voci poco chiare, persone che parlano velocemente. Sovrapposizioni: quando più persone parlano insieme, parti del discorso si perdono o si mescolano. Rumore di fondo e qualità della registrazione. Lingue miste: riunioni in cui si alternano italiano e inglese. Un fenomeno da conoscere, osservato in alcuni sistemi di trascrizione, è l'aggiunta di frasi mai pronunciate, specialmente durante pause o rumori: un caso di 'allucinazione' applicato all'audio. Alcuni strumenti permettono di fornire un vocabolario di termini specifici, che riduce gli errori su nomi e terminologia.");
    opTag(s, 0);
    table(s, [["Detto", "Trascritto", "Tipo di errore"],
      ["Il fornitore Kessler", "Il fornitore Kessel", "Nome proprio"],
      ["Il modulo SDI", "Il modulo esse di", "Sigla aziendale"],
      ["Sconto del diciotto per cento", "Sconto dell'otto per cento", "Numero"],
      ["(pausa di silenzio)", "Grazie per l'attenzione.", "Frase aggiunta"]],
      { y: 1.15, colW: [3.2, 3.2, 2.6], rowH: 0.45, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Esempi fittizi", { x: 0.5, y: 3.43, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    const o = ["Accenti e dialetti", "Sovrapposizioni", "Rumore di fondo", "Lingue miste"];
    o.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.75, 2.15, 0.5, t, { fill: C.background2, fontSize: 12 }));
    txt(s, "Alcuni strumenti accettano un vocabolario di termini specifici: riduce gli errori su nomi e terminologia.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Chi ha detto che cosa", "Un rischio specifico che il sottotema mette in evidenza: l'errore nell'attribuzione delle affermazioni agli interlocutori. Molti strumenti di trascrizione distinguono le voci e indicano chi sta parlando, una funzione chiamata diarizzazione. Quando le persone sono collegate con account separati in una videoconferenza, l'attribuzione è di solito affidabile. Quando invece più persone parlano nella stessa stanza con un solo microfono, o hanno voci simili, o si interrompono, l'attribuzione può essere sbagliata. L'esempio fittizio in slide mostra due versioni di uno stesso scambio: nella trascrizione, l'impegno a consegnare entro venerdì è attribuito alla persona sbagliata. In un verbale, questo errore cambia chi ha preso un impegno; in un'intervista, chi ha espresso un'opinione; in una telefonata con un cliente, chi ha promesso che cosa. Ed è un errore difficile da notare per chi non era presente, perché la trascrizione è coerente e ben formattata. Le conseguenze possono essere serie, specialmente per impegni, responsabilità e posizioni espresse in contesti delicati. Per questo, nei verbali e nei riassunti, le attribuzioni importanti vanno controllate da chi era presente.");
    opTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.75, "Che cosa è stato detto (esempio fittizio)", "Bianchi: \"Riesci a consegnare entro venerdì?\"\nVerdi: \"Sì, me ne occupo io.\"", { fontSize: 13, fill: C.accent6 });
    docBox(s, 5.15, 1.15, 4.35, 1.75, "Trascrizione con attribuzione errata", "Bianchi: \"Riesci a consegnare entro venerdì? Sì, me ne occupo io.\"", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Un errore di attribuzione cambia", { x: 0.5, y: 3.05, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.43, 2.9, 0.55, "Chi ha preso un impegno", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.43, 2.9, 0.55, "Chi ha espresso un'opinione", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.43, 2.9, 0.55, "Chi ha promesso che cosa", { fill: C.background2, fontSize: 12 });
    banner(s, 4.15, "Difficile da notare per chi non c'era. Le attribuzioni importanti le controlla chi era presente.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Sintesi vocale e interazione", "Due capacità di generazione vocale. La sintesi vocale trasforma un testo in parlato. Le voci attuali sono molto naturali, con intonazione, pause ed espressività, in molte lingue. Applicazioni: narrazione di video formativi, lettura di documenti per chi preferisce ascoltare o non può leggere, messaggi vocali, assistenti telefonici, versioni audio di contenuti. Alcuni sistemi possono anche riprodurre la voce di una persona specifica a partire da pochi secondi di registrazione. È una capacità con usi legittimi, come dare voce a chi l'ha persa, ma anche con rischi seri di inganno, che vedremo nel 10.8: la voce di una persona non va riprodotta senza il suo consenso esplicito. L'interazione vocale permette di conversare a voce con un assistente: porre domande, dettare, ricevere risposte parlate. È utile quando le mani o gli occhi sono occupati, per chi ha difficoltà con la tastiera, o semplicemente perché parlare è più rapido che scrivere. Un'attenzione: nell'interazione vocale la risposta si ascolta una volta e non si rilegge, quindi è più difficile notarne gli errori. Per informazioni importanti, conviene chiedere anche la versione scritta.");
    opTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiVolume2", head: "Sintesi vocale", headSize: 15, bodySize: 12,
      body: bullets(["Voci naturali, in molte lingue", "Video formativi, documenti in audio, assistenti", "Riprodurre una voce specifica: solo con consenso esplicito"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiMessageCircle", head: "Interazione vocale", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Domande, dettatura, risposte parlate", "Mani o occhi occupati, difficoltà con la tastiera", "Si ascolta una volta: errori meno visibili"], { space: 5 }) });
    banner(s, 3.9, "Per informazioni importanti ricevute a voce, chiedere anche la versione scritta.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Tradurre il parlato", "La traduzione del parlato combina riconoscimento, traduzione e, a volte, sintesi vocale. Può avvenire in modi diversi: sottotitoli tradotti in una videoconferenza, traduzione di una registrazione, conversazione bilingue quasi in tempo reale con un dispositivo che ascolta e traduce. Le opportunità sono grandi: riunioni con colleghi o clienti di altri paesi senza una lingua comune, formazione per personale di lingue diverse, assistenza a clienti stranieri. La qualità per le lingue più diffuse e per conversazioni ordinarie è oggi buona. Ma la traduzione del parlato somma i rischi di due passaggi: gli errori di riconoscimento visti prima, e quelli di traduzione visti nel Tema 8, come terminologia, sfumature, gradi di obbligo, registro. In più, la traduzione quasi in tempo reale ha meno contesto: traduce frase per frase, senza sapere come proseguirà il discorso. E chi ascolta la traduzione spesso non può verificarla, perché non conosce la lingua di partenza. Per questo, nelle conversazioni con conseguenze, come trattative, accordi, istruzioni di sicurezza, comunicazioni mediche o legali, la traduzione automatica del parlato può supportare ma non sostituire un interprete o una conferma scritta.");
    opTag(s, [0, 2]);
    const ch = [["Parlato", C.background2], ["Riconoscimento", C.accent6], ["Traduzione", C.accent6], ["Testo o voce", C.background2]];
    ch.forEach((e, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, e[0], { fill: e[1], fontSize: 13 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    await card(s, 0.5, 2.05, 4.35, 1.75, { icon: "FiThumbsUp", inline: true, head: "Opportunità", headSize: 14, bodySize: 12, fill: C.accent6, body: "Riunioni senza lingua comune, formazione multilingue, assistenza a clienti stranieri." });
    await card(s, 5.15, 2.05, 4.35, 1.75, { icon: "FiAlertTriangle", inline: true, head: "Rischi sommati", headSize: 14, bodySize: 12, iconBg: C.accent5, body: "Errori di riconoscimento e di traduzione, meno contesto, ascoltatore che non può verificare." });
    banner(s, 4.0, "Trattative, accordi, sicurezza, ambiti medici o legali: supporto sì, sostituto di un interprete o di una conferma scritta no.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Uno strumento di accessibilità", "Integrazione B del tema: l'AI multimodale come strumento di accessibilità. Trascrizioni, sottotitoli, descrizioni, sintesi vocale e traduzioni possono rendere le informazioni accessibili a persone con esigenze diverse. Le persone sorde o con difficoltà uditive possono seguire riunioni e video grazie ai sottotitoli automatici. Le persone cieche o ipovedenti possono ascoltare documenti con la sintesi vocale, e ricevere descrizioni di immagini e grafici, come visto nel 10.2. Le persone con dislessia o difficoltà di lettura possono ascoltare invece di leggere. Le persone con difficoltà motorie possono interagire con la voce invece che con la tastiera. Le persone che non conoscono bene la lingua possono ricevere traduzioni e versioni semplificate. E chiunque, in situazioni temporanee, come in viaggio, in un ambiente rumoroso, con le mani occupate, può beneficiare di modalità alternative. È uno dei contributi più concreti e meno discussi dell'AI multimodale, e un'opportunità per rendere più inclusiva la comunicazione aziendale. La consapevolezza del sottotema aggiunge però una condizione: trascrizioni e traduzioni richiedono controlli adeguati di accuratezza e contesto. Un sottotitolo sbagliato, per chi non può ascoltare l'audio, è un'informazione sbagliata che non ha modo di correggere.");
    opTag(s, [0, 1, 2]);
    await iconGrid(s, [
      { icon: "FiType", head: "Sottotitoli", body: "Per chi non sente o è in un luogo rumoroso" },
      { icon: "FiVolume2", head: "Sintesi vocale", body: "Per chi non vede o fatica a leggere" },
      { icon: "FiImage", head: "Descrizioni di immagini", body: "Grafici e foto per chi non vede" },
      { icon: "FiMic", head: "Comandi vocali", body: "Per chi non usa la tastiera" },
      { icon: "FiGlobe", head: "Traduzioni", body: "Per chi non conosce bene la lingua" },
      { icon: "FiAlignLeft", head: "Versioni semplificate", body: "Per chi ha bisogno di testi più chiari" },
    ], 3, { y: 1.15, H: 2.7, headSize: 13, bodySize: 12 });
    banner(s, 4.05, "Un sottotitolo sbagliato, per chi non può ascoltare, è un errore che non ha modo di correggere. Servono controlli.", { h: 0.75, fontSize: 13 });
    txt(s, "Integrazione B: AI multimodale come strumento di accessibilità", { x: 0.5, y: 4.85, w: 9, h: 0.25, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Registrare con consenso", "Una considerazione pratica che riguarda tutte le applicazioni vocali sulle riunioni e sulle conversazioni: la registrazione e la trascrizione coinvolgono le voci e le parole di altre persone. Anche senza entrare nell'analisi normativa, che appartiene all'area della responsabilità, alcuni principi di buona pratica sono semplici. Informare i partecipanti che la conversazione viene registrata o trascritta, prima di iniziare, e rispettare chi preferisce di no. Usare solo strumenti autorizzati dall'azienda, perché una registrazione di una riunione contiene spesso informazioni riservate, e caricarla in uno strumento non autorizzato significa trasferirle fuori dal controllo aziendale. Fare attenzione alle conversazioni con esterni, come clienti, fornitori, candidati, per cui possono valere regole più stringenti. Non registrare di nascosto. Definire per quanto tempo conservare registrazioni e trascrizioni, e chi può accedervi. Molti strumenti di videoconferenza mostrano un avviso quando la trascrizione è attiva: è un buon punto di partenza, ma non sostituisce l'informazione esplicita ai partecipanti, specialmente quando la trascrizione viene poi elaborata da sistemi AI.");
    opTag(s, 0);
    numList(s, ["Informare i partecipanti prima di iniziare, e rispettare chi preferisce di no", "Solo strumenti autorizzati: le registrazioni contengono informazioni riservate", "Più attenzione con esterni: clienti, fornitori, candidati", "Non registrare di nascosto", "Definire conservazione e accesso a registrazioni e trascrizioni"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "L'avviso automatico dello strumento è un punto di partenza, non sostituisce l'informazione esplicita.", { h: 0.65, fontSize: 13 });
  }
  keySlide("L'accessibilità può migliorare grazie alle tecnologie vocali, ma trascrizioni e traduzioni richiedono controlli adeguati di accuratezza e contesto.", "Sottotema 10.4  ·  AI per audio, voce e linguaggio parlato", "Concetto chiave del sottotema 10.4. Le tecnologie vocali trascrivono, sintetizzano, traducono e permettono di interagire a voce, con applicazioni immediate a riunioni, interviste, comunicazioni e formazione, e un contributo importante all'accessibilità. Ma gli errori di riconoscimento su nomi, terminologia e numeri, e gli errori di attribuzione tra interlocutori, sono frequenti e poco visibili; la traduzione del parlato somma i rischi; le risposte vocali sono più difficili da controllare. Registrazioni e trascrizioni richiedono consenso e strumenti autorizzati. Esercizio suggerito: registrare, con il consenso dei partecipanti e uno strumento autorizzato, una breve discussione simulata con nomi, numeri e impegni, e confrontare la trascrizione e il riassunto automatici con quanto effettivamente detto.");

  // =====================================================================
  section("10.5 Video");
  divider("10.5", "AI per comprensione e generazione video", "Coerenza visiva e plausibilità di una sequenza non dimostrano che gli eventi siano realmente accaduti", "Il video combina immagini, tempo e spesso audio, ed è la modalità più complessa. Il documento gli assegna priorità media e un livello di conoscenza: vogliamo che i partecipanti sappiano che cosa i sistemi possono fare oggi con i video, sia nell'analizzarli sia nel generarli, e quali sono i limiti principali. La produzione audiovisiva specialistica e l'editing professionale sono solo da accennare. Il punto concettuale del sottotema anticipa il 10.8: un video plausibile non è la prova che qualcosa sia accaduto.");
  {
    const s = content("Comprendere i video", "I sistemi multimodali possono analizzare filmati e sequenze audiovisive. Le capacità principali. Descrivere il contenuto: che cosa succede, chi compare, in quale ambiente. Identificare eventi e momenti: quando avviene un certo fatto, in quale punto del video si parla di un argomento. Riassumere: ricavare una sintesi di un video lungo, come una registrazione di un webinar, una lezione, una presentazione, combinando ciò che si vede e ciò che si sente. Estrarre informazioni: il testo che compare a schermo, le slide mostrate, i passaggi di una procedura dimostrata. Le applicazioni: rendere ricercabili archivi di video formativi, ricavare istruzioni scritte da un video dimostrativo, riassumere webinar, creare capitoli e indici. Un limite tecnico da conoscere: molti sistemi non analizzano ogni fotogramma, ma ne campionano alcuni a intervalli, per esempio uno al secondo o meno. Un evento rapido tra due fotogrammi campionati può sfuggire completamente. Inoltre, le relazioni temporali, come che cosa è successo prima e dopo, quanto è durato un evento, sono una fonte di errori frequente. Per i video usati come documentazione, la sintesi automatica è un indice utile, non un sostituto della visione dei passaggi rilevanti.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiEye", head: "Descrivere", body: "Che cosa succede, chi compare, dove" },
      { icon: "FiClock", head: "Individuare eventi", body: "Quando succede, dove si parla di un tema" },
      { icon: "FiAlignLeft", head: "Riassumere", body: "Webinar, lezioni, presentazioni" },
      { icon: "FiList", head: "Estrarre", body: "Testi a schermo, slide, passaggi di una procedura" },
    ], 2, { y: 1.15, H: 2.4, headSize: 14, bodySize: 12 });
    await card(s, 0.5, 3.75, 4.35, 1.2, { head: "Fotogrammi campionati", headSize: 13, bodySize: 12, body: "Un evento rapido tra due campioni può sfuggire." });
    await card(s, 5.15, 3.75, 4.35, 1.2, { head: "Relazioni temporali", headSize: 13, bodySize: 12, fill: C.accent6, body: "Prima, dopo, durata: errori frequenti." });
  }
  {
    const s = content("Generare e modificare video", "La generazione di video è la capacità multimodale che è progredita più rapidamente negli ultimi anni. Oggi i sistemi possono generare brevi video da una descrizione testuale, animare un'immagine fissa, generare video a partire da altri video cambiandone lo stile, creare animazioni, produrre presentatori virtuali che leggono un testo con una voce sintetica. Possono anche modificare filmati esistenti: rimuovere elementi, cambiare lo sfondo, allungare una scena, tradurre il parlato sincronizzando il movimento delle labbra. Per la comunicazione e la formazione le opportunità sono concrete: video formativi prodotti e aggiornati rapidamente, versioni in più lingue di uno stesso video, animazioni per spiegare processi, brevi contenuti per la comunicazione interna. I limiti principali sono quelli del sottotema: la coerenza temporale e la continuità delle scene, perché oggetti e persone possono cambiare aspetto da un fotogramma all'altro, apparire o scomparire, muoversi in modo fisicamente impossibile; e il controllo degli eventi rappresentati, perché è difficile ottenere esattamente l'azione voluta, nella sequenza voluta. I video generati sono in genere brevi, e la produzione di video lunghi e coerenti richiede ancora un lavoro di montaggio e competenze specialistiche, da accennare.");
    opTag(s, [1, 2]);
    await card(s, 0.5, 1.2, 4.35, 2.45, { icon: "FiFilm", head: "Che cosa si può fare", headSize: 15, bodySize: 12,
      body: bullets(["Brevi video da testo o da immagini", "Animazioni e presentatori virtuali", "Modifiche: sfondi, elementi, doppiaggio con labiale"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.45, { icon: "FiBookOpen", head: "Opportunità", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Video formativi rapidi da aggiornare", "Versioni in più lingue", "Animazioni per spiegare processi"], { space: 5 }) });
    const l = [["Coerenza temporale", "Oggetti e persone che cambiano, appaiono, scompaiono"], ["Controllo degli eventi", "Difficile ottenere l'azione voluta nella sequenza voluta"]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 3.85, 4.35, 1.1, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 3.93, w: 3.95, h: 0.38, fontSize: 14, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.32, w: 3.95, h: 0.55, fontSize: 12, color: C.background1 });
    });
  }
  {
    const s = content("Documentale o sintetico", "La distinzione più importante del sottotema: tra contenuto documentale e contenuto sintetico. Un video documentale è la registrazione di qualcosa che è accaduto davanti a una telecamera: una riunione, un evento, un'ispezione, una testimonianza. Il suo valore sta nel legame con la realtà. Un video sintetico è generato o profondamente modificato da un sistema: rappresenta qualcosa che può non essere mai accaduto. Il suo valore sta nella comunicazione, nella spiegazione, nella creatività. Entrambi sono legittimi, ma non vanno confusi. Il problema è che i video sintetici di alta qualità possono essere indistinguibili, a occhio, da quelli documentali. La consapevolezza del sottotema lo dice chiaramente: la coerenza visiva e la plausibilità di una sequenza video non dimostrano che gli eventi rappresentati siano realmente accaduti. Per molto tempo un video è stato considerato una prova particolarmente forte, più di una fotografia e molto più di un testo. Questa presunzione non è più fondata. Nella comunicazione aziendale ne derivano due regole. Quando si usa un video sintetico, dichiararlo, specialmente se rappresenta persone o situazioni realistiche. Quando si riceve un video come prova di qualcosa, chiedersi da dove viene, come vedremo nel 10.8.");
    opTag(s, [1, 2]);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiVideo", head: "Contenuto documentale", headSize: 15, bodySize: 12,
      body: bullets(["Registra qualcosa che è accaduto", "Valore: il legame con la realtà", "Riunioni, eventi, ispezioni, testimonianze"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiCpu", head: "Contenuto sintetico", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Generato o profondamente modificato", "Valore: comunicazione, spiegazione, creatività", "Può non essere mai accaduto"], { space: 4 }) });
    banner(s, 3.6, "Un video è stato a lungo considerato una prova forte. Questa presunzione non è più fondata.", { h: 0.65, fontSize: 14 });
    chip(s, 0.5, 4.4, 4.4, 0.55, "Se si usa un video sintetico: dichiararlo", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 4.4, 4.4, 0.55, "Se si riceve un video come prova: da dove viene?", { fill: C.background2, fontSize: 12 });
  }
  keySlide("Coerenza visiva e plausibilità di una sequenza video non dimostrano che gli eventi rappresentati siano realmente accaduti.", "Sottotema 10.5  ·  AI per comprensione e generazione video", "Concetto chiave del sottotema 10.5. I sistemi possono descrivere, riassumere e indicizzare video, e generare o modificare brevi filmati, con opportunità concrete per la comunicazione e la formazione. Ma l'analisi può perdere eventi rapidi e sbagliare le relazioni temporali, e la generazione ha limiti di coerenza e di controllo. Soprattutto, contenuto documentale e contenuto sintetico vanno distinti: un video realistico non è più, di per sé, una prova. Esercizio suggerito: mostrare un breve video generato, privo di persone reali e marchi, insieme a un video reale di soggetto simile, e discutere quali elementi aiutano o non aiutano a distinguerli.");

  // =====================================================================
  section("10.6 Presentazioni");
  divider("10.6", "Presentazioni e materiali di comunicazione", "L'efficacia estetica di un materiale non garantisce accuratezza, completezza né coerenza narrativa", "Un'applicazione specifica che combina testo e immagini: le presentazioni e i materiali di comunicazione. È un ambito in cui l'AI è entrata rapidamente nel lavoro quotidiano: dalla descrizione di un argomento, o da un documento, si ottengono in pochi minuti slide impaginate, schemi, infografiche. In questo sottotema, da conoscere e sperimentare, vediamo che cosa si può fare, come valutare la qualità comunicativa, e la distinzione che il sottotema mette al centro: qualità estetica e accuratezza informativa sono cose diverse. Il confine con il 10.7: qui descriviamo l'applicazione, lì il principio generale delle conversioni tra modalità.");
  {
    const s = content("Dal testo alle slide", "Le possibilità che il sottotema elenca. Generare presentazioni da contenuti testuali: da una scaletta, da appunti, da una descrizione dell'argomento, il sistema produce un insieme di slide con titoli, punti, immagini e impaginazione. Trasformare documenti in materiali visivi: una relazione diventa una presentazione per la direzione, un manuale diventa una serie di schede, una procedura diventa un diagramma di flusso. Creare slide e schemi: diagrammi di processo, organigrammi, mappe concettuali, linee del tempo. Produrre infografiche: rappresentazioni visive sintetiche di informazioni e numeri. Organizzare visivamente le informazioni: scegliere che cosa mettere in evidenza, come raggrupparlo, in quale ordine presentarlo. Il valore principale è il tempo risparmiato nella parte più meccanica del lavoro, l'impaginazione, e la possibilità di partire da una struttura invece che da una pagina bianca. Questi strumenti possono essere integrati nei programmi di presentazione o essere servizi separati, e producono risultati di qualità molto variabile. In ogni caso, una presentazione generata è una bozza: struttura, contenuti e immagini vanno rivisti con la stessa attenzione di qualsiasi altro output.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiLayout", head: "Presentazioni da testo", body: "Da scaletta, appunti o descrizione" },
      { icon: "FiRepeat", head: "Documenti in materiali visivi", body: "Relazione in slide, procedura in diagramma" },
      { icon: "FiShare2", head: "Schemi e diagrammi", body: "Processi, organigrammi, linee del tempo" },
      { icon: "FiPieChart", head: "Infografiche", body: "Informazioni e numeri in sintesi visiva" },
      { icon: "FiGrid", head: "Organizzazione visiva", body: "Che cosa evidenziare, come raggruppare" },
      { icon: "FiEdit", head: "Una bozza", body: "Struttura, contenuti e immagini da rivedere", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Il valore: meno tempo sull'impaginazione, una struttura da cui partire invece di una pagina bianca.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Adattare ai destinatari", "Una delle possibilità più utili è l'adattamento di uno stesso contenuto a destinatari diversi, come visto nel Tema 8 per i testi. Da un unico documento di progetto si possono ottenere una presentazione sintetica per la direzione, con obiettivi, costi e rischi; una presentazione operativa per il gruppo di lavoro, con attività, tempi e responsabilità; un materiale formativo per chi dovrà usare il risultato, con istruzioni ed esempi; una scheda per la comunicazione interna, breve e visiva. L'AI è molto efficace in questo lavoro di adattamento, che a mano richiederebbe di ripartire più volte da capo. Il supporto alla comunicazione e alla formazione è uno degli usi più apprezzati: materiali formativi aggiornati rapidamente, versioni per livelli di esperienza diversi, schede riassuntive. Ma, come per i testi, ogni versione eredita gli errori della base, e ogni adattamento seleziona: la versione per la direzione può omettere un rischio importante, quella formativa può semplificare una regola fino a renderla scorretta. Ogni versione va controllata per il proprio destinatario.");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 2.6, 2.6, "Un documento di progetto", "Obiettivi, attività, tempi, costi, rischi, responsabilità, istruzioni.", { fontSize: 12, fill: C.accent6 });
    arrow(s, 3.2, 2.3, 0.35);
    const v = [["Direzione", "Obiettivi, costi, rischi"], ["Gruppo di lavoro", "Attività, tempi, responsabilità"], ["Formazione", "Istruzioni ed esempi"], ["Comunicazione interna", "Breve e visiva"]];
    v.forEach((e, i) => {
      const y = 1.15 + i * 0.66;
      shapeBox(s, 3.7, y, 5.8, 0.58, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 3.9, y, w: 2.3, h: 0.58, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 6.2, y, w: 3.2, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 3.95, "Ogni versione eredita gli errori della base e seleziona: va controllata per il proprio destinatario.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Coerenza tra testo e visivo", "Il sottotema chiede attenzione alla coerenza tra contenuti testuali e rappresentazioni visive. Quando un documento viene trasformato in un materiale visivo, possono nascere incoerenze tra ciò che dice il testo e ciò che mostra la grafica. L'esempio fittizio in slide mostra un'infografica generata da un rapporto: il testo del rapporto dice che le vendite online sono il 35 per cento del totale, ma il grafico a torta mostra una fetta che a occhio sembra metà; l'icona scelta per 'clienti business' rappresenta un consumatore con un carrello; la freccia del processo collega due fasi nell'ordine sbagliato. Sono errori tipici. Le proporzioni dei grafici decorativi non sempre corrispondono ai numeri, perché il sistema le disegna invece di calcolarle. Le icone e le immagini scelte possono suggerire significati diversi da quelli del testo. Gli schemi possono semplificare relazioni fino a renderle sbagliate. I numeri riportati nelle slide possono differire da quelli del documento di partenza, per arrotondamento o per errore. E il risultato è sempre visivamente gradevole, il che rende questi errori meno evidenti. Il controllo consiste nel confrontare ogni elemento visivo con il contenuto di partenza: numeri, proporzioni, sequenze, icone.");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 3.6, 1.5, "Rapporto (esempio fittizio)", "Le vendite online sono il 35% del totale.", { fontSize: 14, fill: C.accent6 });
    s.addChart(pres.charts.PIE, [{ name: "Canali", labels: ["Online", "Negozi"], values: [50, 50] }], { x: 4.3, y: 1.1, w: 2.0, h: 1.6, chartColors: [HEX.a5, HEX.a3], showLegend: false, showValue: false, showTitle: false, dataBorder: { pt: 1, color: "FFFFFF" } });
    txt(s, "Infografica: la fetta 'online' sembra metà", { x: 6.4, y: 1.2, w: 3.1, h: 1.4, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    const e = ["Proporzioni disegnate, non calcolate", "Icone che suggeriscono altro", "Schemi semplificati fino all'errore", "Numeri diversi dal documento"];
    e.forEach((t, i) => chip(s, 0.5 + i * 2.3, 2.9, 2.15, 0.7, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 3.85, "Il risultato è sempre gradevole, e questo rende gli errori meno evidenti. Confrontare ogni elemento visivo con il contenuto di partenza.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Estetica e accuratezza", "La distinzione centrale del sottotema, e la sua consapevolezza: l'efficacia estetica di un materiale non garantisce accuratezza, completezza né coerenza narrativa. È un principio che abbiamo incontrato più volte: nel Tema 7 la fluidità del testo che produce fiducia, nel Tema 9 la comunicazione efficace che non garantisce un'interpretazione corretta. Nelle presentazioni il fenomeno è particolarmente forte, per due motivi. Primo, una presentazione curata visivamente comunica professionalità e affidabilità, e chi la guarda tende a fidarsi dei contenuti. Secondo, le presentazioni sono spesso viste velocemente, in riunione, senza il tempo di verificare. Il sottotema indica tre dimensioni da valutare oltre all'estetica. L'accuratezza: le informazioni sono corrette e corrispondono alla fonte? La completezza: manca qualcosa di importante, come un rischio, una condizione, un dato sfavorevole? La coerenza narrativa: la sequenza delle slide costruisce un ragionamento solido, o salta passaggi, presenta conclusioni non sostenute dalle slide precedenti? Con l'AI, l'estetica è quasi gratuita, come visto nel Tema 9 per i report: per questo l'attenzione va spostata sulle altre tre dimensioni.");
    opTag(s, 2);
    shapeBox(s, 0.5, 1.15, 2.6, 2.6, C.background2, "estetica");
    await iconCircle(s, 1.45, 1.35, 0.7, "FiStar", C.accent2);
    txt(s, "Estetica", { x: 0.6, y: 2.15, w: 2.4, h: 0.42, fontSize: 17, bold: true, color: C.text1, align: "center" });
    txt(s, "Con l'AI, quasi gratuita", { x: 0.6, y: 2.6, w: 2.4, h: 0.6, fontSize: 12, italic: true, color: C.text2, align: "center" });
    txt(s, "≠", { x: 3.1, y: 1.9, w: 0.5, h: 0.8, fontSize: 36, bold: true, color: C.accent5, align: "center", valign: "middle" });
    const d = [["Accuratezza", "Corretto e corrispondente alla fonte?"], ["Completezza", "Manca un rischio, una condizione, un dato sfavorevole?"], ["Coerenza narrativa", "La sequenza costruisce un ragionamento solido?"]];
    d.forEach((e, i) => {
      const y = 1.15 + i * 0.89;
      shapeBox(s, 3.65, y, 5.85, 0.8, C.accent6, e[0]);
      txt(s, e[0], { x: 3.85, y, w: 2.2, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 6.05, y, w: 3.35, h: 0.8, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 4.0, "Le presentazioni si guardano in fretta, in riunione: la cura visiva genera fiducia senza tempo per verificare.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Valutare la qualità comunicativa", "Come si valuta, in pratica, un materiale di comunicazione prodotto con l'AI? Il sottotema parla di valutazione della qualità comunicativa. Proponiamo una breve lista di controllo, da applicare prima di usare o diffondere il materiale. Il messaggio: è chiaro qual è il messaggio principale, e lo si capisce in pochi secondi? Il destinatario: linguaggio, livello di dettaglio e tono sono adatti a chi lo riceverà? L'accuratezza: numeri, nomi, date, citazioni corrispondono alla fonte? La completezza: ci sono tutti gli elementi necessari, compresi rischi e limiti? La coerenza: testo, grafici, icone e immagini dicono la stessa cosa? La sequenza: l'ordine delle slide costruisce un ragionamento? La sobrietà: ci sono elementi decorativi superflui, testo eccessivo, immagini generiche che non aggiungono nulla? Le immagini: sono appropriate, rispettano l'identità visiva, non contengono persone reali o marchi altrui senza autorizzazione, e se sono generate è opportuno dichiararlo? Una lista così richiede pochi minuti, e intercetta la maggior parte dei problemi tipici. È anche un buon criterio per decidere quanto intervenire su una bozza generata.");
    opTag(s, 2);
    const c = [["Messaggio", "Chiaro in pochi secondi?"], ["Destinatario", "Linguaggio, dettaglio, tono adatti?"], ["Accuratezza", "Numeri, nomi, date come nella fonte?"], ["Completezza", "Rischi e limiti compresi?"], ["Coerenza", "Testo, grafici, icone dicono lo stesso?"], ["Sequenza", "L'ordine costruisce un ragionamento?"], ["Sobrietà", "Niente decorazioni e testo superflui?"], ["Immagini", "Appropriate, dichiarate se generate?"]];
    c.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.75;
      shapeBox(s, x, y, 4.4, 0.66, row % 2 ? C.accent6 : C.background2, e[0]);
      s.addShape(pres.shapes.RECTANGLE, { x: x + 0.15, y: y + 0.2, w: 0.26, h: 0.26, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 }, objectName: "casella " + e[0] });
      txt(s, e[0], { x: x + 0.55, y, w: 1.5, h: 0.66, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: x + 2.0, y, w: 2.3, h: 0.66, fontSize: 11, color: C.text1, valign: "middle" });
    });
    txt(s, "Pochi minuti per intercettare la maggior parte dei problemi, e decidere quanto intervenire sulla bozza.", { x: 0.5, y: 4.3, w: 9, h: 0.5, fontSize: 13, italic: true, bold: true, color: C.accent1 });
  }
  keySlide("L'efficacia estetica di un materiale non garantisce accuratezza, completezza né coerenza narrativa.", "Sottotema 10.6  ·  AI per presentazioni e materiali di comunicazione", "Concetto chiave del sottotema 10.6. L'AI genera presentazioni, schemi e infografiche da testi e documenti, e adatta i materiali a destinatari diversi, con un grande risparmio di tempo nella parte meccanica del lavoro. Ma la coerenza tra testo e visivo non è garantita, gli adattamenti selezionano, e soprattutto l'estetica, ormai quasi gratuita, genera una fiducia che va spostata su accuratezza, completezza e coerenza narrativa. Una breve lista di controllo aiuta a valutare la qualità comunicativa. Esercizio suggerito: generare con l'AI una breve presentazione a partire da un documento fittizio di due pagine, e far applicare ai partecipanti la lista di controllo, contando gli interventi necessari.");

  // =====================================================================
  section("10.7 Trasformazioni");
  divider("10.7", "Integrazione e trasformazione tra modalità", "Il valore delle conversioni dipende dalla loro utilità e dalla fedeltà, non solo dalla comodità", "Nei sottotemi precedenti abbiamo incontrato molte trasformazioni: dall'audio alla trascrizione, dal testo all'immagine, dal documento alla presentazione. In questo sottotema, da comprendere e sperimentare, le guardiamo insieme, come principio generale. Che cosa significa trasformare un contenuto da una modalità all'altra? Che cosa si guadagna e che cosa si può perdere? Due integrazioni sono centrali: l'accessibilità, perché le conversioni permettono modalità alternative di fruizione, e la coerenza delle informazioni tra modalità, perché ogni passaggio può introdurre omissioni, errori o variazioni di significato. Il confine con il 10.4: lì le capacità vocali, qui le catene tra modalità.");
  {
    const s = content("La mappa delle conversioni", "La tabella in slide mostra le principali conversioni tra modalità, con un esempio per ciascuna. Dal testo all'immagine: un'illustrazione generata da una descrizione. Dal testo all'audio: un documento letto da una voce sintetica. Dal testo al video: un breve video generato da una sceneggiatura. Dall'immagine al testo: la descrizione di una fotografia o l'estrazione del testo da una schermata. Dall'audio al testo: la trascrizione di una riunione. Dal video al testo: la sintesi di un webinar. Dal documento alla presentazione: una relazione trasformata in slide. E le combinazioni: testo, voce e immagini insieme in un video formativo, o la creazione di un contenuto a partire da più fonti di natura diversa, come una registrazione, delle slide e un documento. Ogni conversione ha un valore pratico: rendere un contenuto più accessibile, più rapido da consumare, adatto a un altro canale o a un altro destinatario. E ogni conversione comporta una scelta su che cosa portare nella nuova forma e che cosa lasciare indietro, perché le modalità non sono equivalenti: un'immagine contiene informazioni che un testo non riesce a descrivere del tutto, e un testo contiene precisazioni che un'immagine non riesce a mostrare.");
    opTag(s, 2);
    table(s, [["Da", "A", "Esempio"],
      ["Testo", "Immagine, audio, video", "Illustrazione, lettura vocale, video da sceneggiatura"],
      ["Immagine", "Testo", "Descrizione di una foto, testo da una schermata"],
      ["Audio", "Testo", "Trascrizione di una riunione"],
      ["Video", "Testo", "Sintesi di un webinar"],
      ["Documento", "Presentazione", "Relazione trasformata in slide"],
      ["Più fonti", "Un nuovo contenuto", "Registrazione, slide e documento in un verbale"]],
      { y: 1.15, colW: [2.0, 2.6, 4.4], rowH: 0.4, fontSize: 12, blankCorner: false });
    banner(s, 4.1, "Le modalità non sono equivalenti: ogni conversione sceglie che cosa portare nella nuova forma e che cosa lasciare indietro.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Le catene di trasformazione", "Spesso le trasformazioni non sono singole, ma formano catene. L'esempio in slide è tipico: una riunione viene registrata; la registrazione viene trascritta; la trascrizione viene riassunta; il riassunto viene trasformato in slide per la direzione; le slide vengono lette da una voce sintetica in un video di aggiornamento. Ogni passaggio è utile e, preso da solo, abbastanza affidabile. Ma gli errori si accumulano: una parola fraintesa nella trascrizione diventa un concetto sbagliato nel riassunto, che diventa un punto elenco nelle slide, che diventa un'affermazione nel video. E ogni passaggio seleziona: la trascrizione perde il tono e le esitazioni, il riassunto perde le obiezioni minori, le slide perdono le condizioni, il video perde la possibilità di rileggere. Alla fine della catena, il contenuto può essere molto lontano dall'originale, pur sembrando a ogni passaggio una trasformazione ragionevole del precedente. È il fenomeno del passaparola, applicato alle modalità. Due buone pratiche: limitare la lunghezza delle catene, partendo quando possibile dalla fonte originale invece che da una trasformazione intermedia; e, per i contenuti importanti, confrontare il risultato finale con la fonte originale, non solo con il passaggio precedente.");
    opTag(s, 2);
    const ch = ["Riunione", "Trascrizione", "Riassunto", "Slide", "Video"];
    const lost = ["", "Tono, esitazioni", "Obiezioni minori", "Condizioni", "Rileggibilità"];
    ch.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      chip(s, x, 1.25, 1.6, 0.7, t, { fill: i === 0 ? C.accent1 : C.accent6, color: i === 0 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 4) arrow(s, x + 1.62, 1.44, 0.2);
      if (i > 0) {
        txt(s, "Si perde:", { x, y: 2.05, w: 1.6, h: 0.25, fontSize: 9, color: C.text2, align: "center" });
        txt(s, lost[i], { x, y: 2.28, w: 1.6, h: 0.45, fontSize: 11, bold: true, color: C.accent5, align: "center" });
      }
    });
    shapeBox(s, 0.5, 2.95, 9.0, 0.8, C.background2, "passaparola");
    txt(s, [{ text: "Il passaparola delle modalità: ", options: { bold: true, color: C.accent1 } }, { text: "ogni passaggio sembra ragionevole, ma gli errori si accumulano e il risultato si allontana dall'originale.", options: { color: C.text1 } }], { x: 0.7, y: 2.95, w: 8.6, h: 0.8, fontSize: 13, valign: "middle" });
    chip(s, 0.5, 3.95, 4.4, 0.7, "Catene brevi: partire dalla fonte originale", { fill: C.accent6, fontSize: 12 });
    chip(s, 5.1, 3.95, 4.4, 0.7, "Confrontare il risultato finale con l'originale", { fill: C.accent6, fontSize: 12 });
  }
  {
    const s = content("Combinare più fonti", "Una forma particolare di trasformazione è la creazione di contenuti a partire da più fonti di natura diversa. Per esempio, un verbale che combina la registrazione di una riunione, le slide proiettate e il documento discusso; un materiale formativo che integra un video dimostrativo, un manuale e le domande frequenti; un rapporto di sopralluogo che combina fotografie, note vocali e una lista di controllo. La combinazione ha un grande valore, perché ogni fonte compensa i limiti delle altre: le slide chiariscono a che cosa si riferiva una frase della registrazione, le fotografie documentano ciò che le note descrivono. Ma introduce un rischio specifico: il collegamento errato tra elementi di fonti diverse. Il sistema può attribuire un commento alla slide sbagliata, associare una fotografia alla nota di un'altra stanza, combinare un dato del documento con un'affermazione della registrazione che si riferiva ad altro. E il risultato combinato, ben integrato e scorrevole, non mostra le giunture tra le fonti, rendendo difficile capire da quale fonte venga ciascuna informazione. Per i contenuti importanti, conviene chiedere che ogni affermazione indichi la fonte da cui proviene, applicando alle modalità il principio di tracciabilità visto nel Tema 8.");
    opTag(s, 2);
    const f = [["FiMic", "Registrazione"], ["FiLayout", "Slide"], ["FiFileText", "Documento"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.15 + i * 0.85;
      shapeBox(s, 0.5, y, 2.6, 0.72, C.background2, f[i][1]);
      await iconCircle(s, 0.62, y + 0.12, 0.48, f[i][0]);
      txt(s, f[i][1], { x: 1.2, y, w: 1.8, h: 0.72, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
    }
    arrow(s, 3.2, 2.0, 0.4);
    shapeBox(s, 3.75, 1.15, 2.2, 2.4, C.accent1, "verbale");
    txt(s, "Un verbale integrato", { x: 3.85, y: 1.15, w: 2.0, h: 2.4, fontSize: 15, bold: true, color: C.background1, align: "center", valign: "middle" });
    await card(s, 6.2, 1.15, 3.3, 2.4, { icon: "FiAlertTriangle", head: "Collegamenti errati", headSize: 14, bodySize: 12, iconBg: C.accent5, body: "Un commento sulla slide sbagliata, una foto con la nota di un'altra stanza. E le giunture non si vedono." });
    banner(s, 3.8, "Ogni fonte compensa i limiti delle altre. Per i contenuti importanti: ogni affermazione indichi la sua fonte.", { h: 0.75, fontSize: 13 });
    txt(s, "La tracciabilità del Tema 8, applicata alle modalità.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Conversioni per l'accessibilità", "L'integrazione B torna in questo sottotema in forma generale: le conversioni tra modalità permettono modalità alternative di fruizione dei contenuti. Nel 10.4 l'abbiamo vista per l'audio; qui la estendiamo a tutte le modalità. Un contenuto disponibile in una sola modalità esclude chi non può o non riesce a usarla. Un contenuto disponibile in più modalità include. Le conversioni più utili per l'accessibilità: testi alternativi per le immagini, che descrivono a chi non vede ciò che l'immagine mostra; sottotitoli e trascrizioni per audio e video; versioni audio di documenti; descrizioni testuali di grafici e diagrammi; versioni semplificate di testi complessi; traduzioni. L'AI rende queste conversioni molto più rapide ed economiche, e quindi possibili su scala, per esempio su tutti i video formativi o su tutte le immagini della intranet. È un'opportunità concreta per rendere più inclusiva la comunicazione aziendale. Valgono però le stesse condizioni viste per tutte le trasformazioni: un testo alternativo generico, come 'immagine di un grafico', non aiuta; uno sbagliato, come una descrizione che inverte una tendenza, danneggia proprio chi non può verificare. Per i contenuti importanti, le conversioni per l'accessibilità vanno controllate come qualsiasi altro contenuto.");
    opTag(s, 2);
    table(s, [["Contenuto originale", "Conversione accessibile", "Per chi"],
      ["Immagine", "Testo alternativo, descrizione", "Chi non vede"],
      ["Audio e video", "Sottotitoli, trascrizione", "Chi non sente, luoghi rumorosi"],
      ["Documento", "Versione audio, versione semplificata", "Chi fatica a leggere"],
      ["Grafico o diagramma", "Descrizione testuale", "Chi non vede"],
      ["Qualsiasi contenuto", "Traduzione", "Chi non conosce la lingua"]],
      { y: 1.15, colW: [2.6, 3.4, 3.0], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 3.85, "'Immagine di un grafico' non aiuta; una descrizione che inverte una tendenza danneggia chi non può verificare.", { h: 0.75, fontSize: 13 });
    txt(s, "Integrazione B: le conversioni permettono modalità alternative di fruizione", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Coerenza tra modalità", "L'integrazione C del tema: la coerenza delle informazioni tra modalità diverse. Ogni passaggio tra formati può introdurre omissioni, errori o variazioni di significato, per cui occorre confrontare il contenuto risultante con quello di origine. Il sottotema la chiama coerenza semantica: il significato deve restare lo stesso, anche se la forma cambia. Le alterazioni tipiche sono tre, come abbiamo visto nel Tema 8 per i documenti, e qui si presentano in forme specifiche. Le omissioni: ciò che una modalità non riesce a esprimere si perde, come il tono ironico di una frase nella trascrizione, o una condizione scritta in piccolo che non entra nell'infografica. Le reinterpretazioni: la conversione impone un'interpretazione, come un'immagine generata da una descrizione ambigua, che sceglie una delle possibili letture, o una sintesi vocale che, con l'intonazione, trasforma una domanda in un'affermazione. Le alterazioni: un contenuto cambia, come un numero letto male in una schermata, o un'immagine generata che aggiunge dettagli non presenti nel testo. L'esempio fittizio in slide mostra una frase detta in riunione con tono dubitativo e la sua trascrizione, che la trasforma in un'affermazione. Nessun errore di parola, ma il significato è cambiato.");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 4.35, 1.3, "Detto in riunione (esempio fittizio)", "\"Sì... il budget dovrebbe bastare...\" (tono dubitativo, lunga pausa)", { fontSize: 13, fill: C.accent6 });
    docBox(s, 5.15, 1.15, 4.35, 1.3, "Trascrizione e sintesi", "\"Il budget è sufficiente.\"", { fontSize: 14, bar: C.accent5, labelColor: C.accent5 });
    const t = [["Omissioni", "Ciò che la nuova modalità non esprime si perde: il tono, una condizione in piccolo"], ["Reinterpretazioni", "La conversione sceglie una lettura: un'immagine da una descrizione ambigua"], ["Alterazioni", "Il contenuto cambia: un numero letto male, un dettaglio aggiunto"]];
    rowsLabel(s, t, { y: 2.65, h: 0.55, lw: 2.2 });
    txt(s, "Integrazione C: ogni passaggio tra formati può alterare il significato; confrontare con l'origine.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Confrontare con l'origine", "Come si controlla, in pratica, la fedeltà di una trasformazione tra modalità? Il principio è semplice: confrontare il contenuto risultante con quello di origine. La difficoltà è che le due modalità sono diverse, e il confronto richiede di passare dall'una all'altra. Alcune tecniche pratiche. Identificare prima gli elementi critici che devono sopravvivere alla trasformazione: numeri, nomi, impegni, condizioni, avvertenze, il messaggio principale. Controllare quegli elementi nel risultato, uno per uno. Per le trascrizioni, ascoltare i passaggi in cui compaiono numeri, nomi e decisioni. Per le immagini generate da testi, verificare che non aggiungano elementi non previsti e che rappresentino correttamente ciò che il testo dice. Per le presentazioni ricavate da documenti, confrontare numeri e conclusioni con il documento. Per le descrizioni di immagini, guardare l'immagine. Coinvolgere, quando serve, chi conosce l'originale: chi era presente alla riunione, chi ha scritto il documento. La consapevolezza del sottotema riassume il criterio: il valore delle conversioni è legato alla loro utilità e alla fedeltà delle informazioni, non soltanto alla comodità o alla rapidità del processo. Una conversione rapida ma infedele non fa risparmiare tempo: lo sposta su chi dovrà correggerne le conseguenze.");
    opTag(s, 2);
    numList(s, ["Identificare gli elementi critici: numeri, nomi, impegni, condizioni, messaggio", "Controllarli nel risultato, uno per uno", "Tornare all'originale: ascoltare, guardare, rileggere i passaggi critici", "Coinvolgere chi conosce l'originale, quando serve"], { y: 1.15, h: 0.55, fontSize: 13 });
    banner(s, 3.65, "Una conversione rapida ma infedele non fa risparmiare tempo: lo sposta su chi dovrà correggerne le conseguenze.", { h: 0.85, fontSize: 13 });
    txt(s, "Il valore delle conversioni: utilità e fedeltà, non solo comodità e rapidità.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 13, italic: true, bold: true, color: C.accent1 });
  }
  keySlide("Il valore delle conversioni è legato alla loro utilità e alla fedeltà delle informazioni, non soltanto alla comodità o alla rapidità del processo.", "Sottotema 10.7  ·  Integrazione e trasformazione tra modalità differenti", "Concetto chiave del sottotema 10.7. Le conversioni tra modalità sono molte e utili: testo in immagine, audio in testo, documento in slide, più fonti in un unico contenuto. Rendono i contenuti più accessibili, rapidi da consumare, adatti a canali diversi. Ma le modalità non sono equivalenti, le catene accumulano errori, la combinazione di fonti può creare collegamenti errati, e ogni passaggio può omettere, reinterpretare o alterare. Il controllo consiste nel confrontare il risultato con l'origine sugli elementi critici. Esercizio suggerito: far percorrere ai partecipanti una catena di tre trasformazioni, per esempio da un breve audio fittizio a una trascrizione, a un riassunto, a una slide, e confrontare il risultato finale con l'audio originale, elencando che cosa si è perso o alterato.");

  // =====================================================================
  section("10.8 Autenticità e affidabilità");
  divider("10.8", "Limiti, autenticità e affidabilità", "Distinguere realismo, provenienza e accuratezza è essenziale per usare in modo critico i contenuti multimodali", "Ultimo sottotema, di consapevolezza critica. Raccogliamo i limiti incontrati nel modulo e affrontiamo la questione più importante del tema: l'autenticità. Con la generazione di immagini, voci e video realistici, il legame tra ciò che sembra reale e ciò che è reale si è indebolito. In questo sottotema vediamo gli errori tipici dei contenuti multimodali, i contenuti sintetici realistici e i deepfake, la distinzione tra realismo, autenticità e accuratezza, il tema della provenienza, e introduciamo, senza analisi normativa, i diritti su contenuti, immagini e voci delle persone. La verifica forense tecnica è solo da accennare.");
  {
    const s = content("Gli errori tipici", "Riassumiamo gli errori tipici dei contenuti multimodali incontrati nel modulo, che il sottotema elenca. Errori di riconoscimento visivo: dettagli non visti, numeri letti male, conteggi sbagliati, relazioni spaziali invertite. Errori di riconoscimento sonoro: nomi, terminologia e numeri fraintesi, frasi aggiunte, affermazioni attribuite alla persona sbagliata. Incoerenze nei contenuti generati: dettagli anatomici o strutturali impossibili, testi deformati, oggetti che cambiano da un fotogramma all'altro. Alterazioni di immagini e materiali originali: modifiche che cambiano ciò che un'immagine documenta. Perdita di informazioni nei passaggi tra modalità: tono, condizioni, obiezioni, contesto. Accuratezza delle trascrizioni e fedeltà semantica delle trasformazioni. Non ripetiamo la teoria generale degli errori del Tema 3: il punto qui è che nei contenuti multimodali questi errori hanno una caratteristica comune. Sono difficili da vedere, perché il risultato è visivamente o acusticamente convincente, e perché controllare richiede di tornare a una modalità diversa: riascoltare, riguardare, confrontare. Come dice l'integrazione C: trasformazioni apparentemente corrette possono modificare informazioni rilevanti senza errori immediatamente evidenti.");
    opTag(s, [0, 1, 2]);
    const m = [["Riconoscimento visivo", ["Dettagli non visti", "Numeri letti male", "Conteggi e spazi"]], ["Riconoscimento sonoro", ["Nomi e termini", "Frasi aggiunte", "Attribuzioni errate"]], ["Contenuti generati", ["Dettagli impossibili", "Testi deformati", "Incoerenze nel tempo"]], ["Trasformazioni", ["Tono e contesto persi", "Condizioni omesse", "Significato alterato"]]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.25, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 1.9, h: 0.5, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, bullets(e[1], { space: 5 }), { x: x + 0.15, y: 1.78, w: 1.92, h: 1.5, fontSize: 12, color: C.text1 });
    });
    banner(s, 3.6, "Il tratto comune: il risultato è convincente, e controllare richiede di tornare a un'altra modalità.", { h: 0.75, fontSize: 13 });
    txt(s, "Integrazione C: trasformazioni apparentemente corrette possono modificare informazioni rilevanti senza errori evidenti.", { x: 0.5, y: 4.5, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Contenuti sintetici e deepfake", "I contenuti sintetici realistici sono immagini, audio e video generati o modificati dall'AI in modo da sembrare registrazioni della realtà. Si parla di deepfake quando rappresentano persone reali che dicono o fanno cose che non hanno mai detto o fatto: un video in cui un dirigente annuncia una decisione, una telefonata con la voce di un collega, una fotografia di un evento mai accaduto. La tecnologia ha usi legittimi: doppiaggio, effetti speciali, formazione, accessibilità, satira dichiarata. Ma è anche usata per frodi, disinformazione, danni alla reputazione. In ambito aziendale il rischio più concreto è la frode basata sull'imitazione della voce o del volto di persone conosciute. Sono stati documentati casi di questo tipo: nel 2019 la stampa ha riportato il caso di un'azienda energetica britannica il cui amministratore trasferì circa 220.000 euro dopo una telefonata in cui la voce del suo superiore era stata imitata; nel 2024 è stato riportato il caso di una multinazionale in cui un dipendente della sede di Hong Kong trasferì l'equivalente di circa 25 milioni di dollari dopo una videochiamata in cui i colleghi, compreso il direttore finanziario, erano stati ricreati artificialmente. Lo schema è sempre simile: una richiesta urgente, da una persona di cui ci si fida, attraverso un canale che sembra sicuro.");
    opTag(s, 1);
    await card(s, 0.5, 1.15, 4.35, 2.0, { icon: "FiCheckCircle", head: "Usi legittimi", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Doppiaggio, effetti, formazione", "Accessibilità, satira dichiarata"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.0, { icon: "FiAlertTriangle", head: "Usi dannosi", headSize: 15, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Frodi con voce o volto imitati", "Disinformazione, danni alla reputazione"], { space: 4 }) });
    shapeBox(s, 0.5, 3.35, 9.0, 1.6, C.text1, "casi");
    txt(s, "Casi riportati dalla stampa", { x: 0.75, y: 3.42, w: 8.5, h: 0.32, fontSize: 13, bold: true, color: C.accent6 });
    txt(s, bullets(["2019: voce di un superiore imitata al telefono, circa 220.000 euro trasferiti", "2024: videochiamata con colleghi ricreati artificialmente, circa 25 milioni di dollari trasferiti"], { space: 4 }), { x: 0.75, y: 3.78, w: 8.5, h: 0.75, fontSize: 12, color: C.background1 });
    txt(s, "Lo schema: richiesta urgente, persona di fiducia, canale che sembra sicuro.", { x: 0.75, y: 4.55, w: 8.5, h: 0.32, fontSize: 12, italic: true, bold: true, color: C.accent3 });
  }
  {
    const s = content("Realismo, autenticità, accuratezza", "Il cuore del sottotema e l'integrazione A del tema: contenuto realistico e contenuto autentico. Il documento propone di distinguere tre caratteristiche che nel linguaggio comune si confondono. Il realismo: il contenuto appare plausibile, sembra reale. Un'immagine sintetica può somigliare in tutto a una fotografia. L'autenticità: l'origine del contenuto è effettivamente accertabile. Un video ha una provenienza documentata: chi l'ha girato, quando, dove, con quale dispositivo. L'accuratezza: le informazioni rappresentate corrispondono ai fatti o alla fonte. Una descrizione riporta fedelmente quanto documentato. Le tre caratteristiche sono indipendenti, e il documento offre tre esempi. Un'immagine sintetica può essere realistica senza essere autentica come testimonianza di un evento. Una registrazione autentica può contenere affermazioni false: è vero che quella persona ha detto quelle cose, ma ciò che ha detto può essere sbagliato. Una presentazione dall'aspetto professionale può riportare dati inesatti. Il messaggio dell'integrazione: la somiglianza con la realtà non dimostra l'origine, l'autenticità o la verità di quanto rappresentato. Davanti a un contenuto multimodale, le tre domande vanno poste separatamente: sembra reale? Da dove viene? Ciò che mostra è vero?");
    opTag(s, -1);
    table(s, [["Caratteristica", "Significato", "Esempio"],
      ["Realismo", "Il contenuto appare plausibile", "Un'immagine sintetica somiglia a una fotografia"],
      ["Autenticità", "L'origine è effettivamente accertabile", "Un video ha una provenienza documentata"],
      ["Accuratezza", "Corrisponde ai fatti o alla fonte", "Una descrizione riporta fedelmente quanto documentato"]],
      { y: 1.15, colW: [2.0, 3.2, 3.8], rowH: 0.5, fontSize: 12, blankCorner: false });
    const e = ["Realistica ma non autentica: un'immagine sintetica", "Autentica ma non accurata: una registrazione con affermazioni false", "Professionale ma non accurata: una presentazione con dati inesatti"];
    e.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.25, 2.86, 0.75, t, { fill: C.accent6, fontSize: 11 }));
    banner(s, 4.2, "Tre domande separate: sembra reale? Da dove viene? Ciò che mostra è vero?", { h: 0.7, fontSize: 15 });
  }
  {
    const s = content("Provenienza e verifica", "Se il realismo non basta, come si accerta l'autenticità? La risposta sta nella provenienza: la storia documentata di un contenuto, da chi l'ha creato a come è arrivato a noi. Esistono strumenti tecnici che aiutano. I metadati, cioè informazioni incorporate nei file, come data, dispositivo, posizione; ma si possono modificare o rimuovere facilmente. Le filigrane digitali, inserite da alcuni sistemi di generazione nei contenuti che producono, a volte invisibili; ma non tutti i sistemi le usano, e possono essere alterate. Gli standard di provenienza, come le credenziali di contenuto promosse dalla coalizione C2PA, che registrano in modo verificabile l'origine e le modifiche di un contenuto; utili, ma ancora non universalmente adottati. Le etichette applicate dalle piattaforme ai contenuti generati. Il documento ricorda un punto importante: anche etichette, metadati e informazioni sulla provenienza richiedono interpretazione, e non sempre costituiscono una prova definitiva della veridicità dei fatti rappresentati. L'assenza di un'etichetta non prova che un contenuto sia autentico. La verifica forense tecnica è solo da accennare. Per l'utente, la verifica più efficace è spesso di tipo organizzativo: risalire alla fonte, chiedere conferma attraverso un canale indipendente, confrontare con altre fonti.");
    opTag(s, -1);
    const t = [["Metadati", "Data, dispositivo, posizione", "Facili da modificare o rimuovere"], ["Filigrane digitali", "Inserite da alcuni generatori", "Non universali, alterabili"], ["Credenziali di contenuto (C2PA)", "Origine e modifiche verificabili", "Non ancora adottate ovunque"], ["Etichette delle piattaforme", "Segnalano contenuti generati", "L'assenza non prova l'autenticità"]];
    table(s, [["Strumento", "Che cosa offre", "Limite"]].concat(t), { y: 1.15, colW: [3.0, 3.0, 3.0], rowH: 0.42, fontSize: 12, blankCorner: false });
    banner(s, 3.4, "Anche etichette e metadati richiedono interpretazione: non sono una prova definitiva della veridicità dei fatti.", { h: 0.75, fontSize: 13 });
    txt(s, "Verifica più efficace per l'utente", { x: 0.5, y: 4.25, w: 3.0, h: 0.6, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
    chip(s, 3.5, 4.25, 1.9, 0.6, "Risalire alla fonte", { fill: C.accent6, fontSize: 11 });
    chip(s, 5.5, 4.25, 2.0, 0.6, "Canale indipendente", { fill: C.accent6, fontSize: 11 });
    chip(s, 7.6, 4.25, 1.9, 0.6, "Altre fonti", { fill: C.accent6, fontSize: 11 });
  }
  {
    const s = content("Difendersi dalle frodi", "Dal punto di vista pratico, la difesa più efficace contro le frodi basate su contenuti sintetici non è tecnica, ma organizzativa e comportamentale. Il motivo è che riconoscere un deepfake di buona qualità a occhio o a orecchio è sempre più difficile, e gli strumenti di rilevamento automatico non sono infallibili. Conviene quindi non basare decisioni importanti sul solo riconoscimento di una voce o di un volto. Le contromisure più efficaci. Verifica su un canale indipendente: davanti a una richiesta insolita, specialmente di pagamenti, credenziali o dati riservati, richiamare la persona a un numero noto, non a quello fornito nel messaggio, o confermare di persona. Procedure che non dipendono dalla voce: autorizzazioni a più firme, controlli incrociati, regole che non si possono saltare nemmeno per una richiesta del vertice. Diffidenza verso l'urgenza e la segretezza: sono i due ingredienti tipici delle frodi, perché impediscono la verifica. Parole o domande di controllo concordate per le situazioni delicate. Segnalazione: in caso di dubbio, segnalare alla sicurezza aziendale, anche se poi la richiesta si rivela autentica. Nessuno dovrebbe sentirsi in imbarazzo nel verificare una richiesta del proprio superiore: è una procedura, non una mancanza di fiducia.");
    opTag(s, -1);
    await iconGrid(s, [
      { icon: "FiPhone", head: "Canale indipendente", body: "Richiamare a un numero noto, confermare di persona" },
      { icon: "FiUsers", head: "Procedure robuste", body: "Più firme, controlli incrociati, nessuna eccezione" },
      { icon: "FiClock", head: "Urgenza e segretezza", body: "Gli ingredienti tipici delle frodi" },
      { icon: "FiKey", head: "Domande di controllo", body: "Concordate per le situazioni delicate" },
      { icon: "FiFlag", head: "Segnalare", body: "In caso di dubbio, alla sicurezza aziendale" },
      { icon: "FiShield", head: "Non solo riconoscere", body: "Voce e volto non bastano più", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Verificare una richiesta del proprio superiore è una procedura, non una mancanza di fiducia.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Comunicazione fuorviante", "Il sottotema include i rischi di comunicazione fuorviante, che riguardano non solo i contenuti ricevuti, ma anche quelli che produciamo. Un'azienda può comunicare in modo fuorviante con contenuti multimodali anche senza alcuna intenzione di ingannare. Alcuni esempi. Usare immagini generate che sembrano fotografie reali di prodotti, sedi, persone, eventi, senza dichiararlo: chi le vede può credere che documentino la realtà. Usare immagini generate di 'clienti' o 'dipendenti' che non esistono, in materiali che suggeriscono testimonianze reali. Modificare fotografie in modo da migliorare l'aspetto di un prodotto o di un luogo oltre il ritocco accettabile. Usare voci sintetiche che imitano persone reali, o presentatori virtuali senza chiarire che non sono persone. Presentare come documentazione un video o un'immagine ricostruiti. In ciascun caso, il problema non è l'uso dell'AI in sé, ma la differenza tra ciò che il contenuto sembra e ciò che è. Il principio guida è la trasparenza: quando un contenuto sintetico potrebbe essere scambiato per una rappresentazione della realtà, conviene dichiararlo. Alcune norme e piattaforme lo richiedono già esplicitamente; le regole specifiche appartengono all'area della responsabilità e della normativa.");
    opTag(s, [1, 2]);
    rowsLabel(s, [["Immagini come foto", "Prodotti, sedi, eventi generati che sembrano reali"], ["Persone inesistenti", "'Clienti' o 'dipendenti' in finte testimonianze"], ["Ritocchi eccessivi", "Un prodotto o un luogo migliore di quanto sia"], ["Voci e presentatori", "Sintetici, senza chiarire che non sono persone"], ["Ricostruzioni", "Presentate come documentazione"]], { y: 1.15, h: 0.5, lw: 2.6 });
    banner(s, 4.1, "Il problema non è l'AI, ma la differenza tra ciò che il contenuto sembra e ciò che è. Principio guida: trasparenza.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Diritti su contenuti, immagini, voci", "Il documento chiede di introdurre il tema dei diritti sui contenuti, sulle immagini e sulle voci delle persone, senza un'analisi normativa, che appartiene all'area della responsabilità. Ci limitiamo quindi a segnalare le questioni principali, perché i partecipanti sappiano riconoscere quando serve un approfondimento. I diritti sui contenuti di partenza: usare come base per una trasformazione un'immagine, un video, una musica, un testo di cui non si hanno i diritti non diventa lecito perché passa attraverso un sistema AI. I diritti sui contenuti generati: la titolarità dei contenuti prodotti con l'AI è una questione ancora in evoluzione, e le condizioni d'uso degli strumenti variano. L'immagine delle persone: usare il volto di una persona, anche modificato o in un contenuto generato, richiede di regola il suo consenso. La voce delle persone: anche la voce è un elemento dell'identità personale, e riprodurla o imitarla senza consenso è problematico, oltre che rischioso. Gli stili e le opere riconoscibili: imitare lo stile di un artista vivente, riprodurre personaggi, marchi, opere protette. Il comportamento pratico è semplice: nei casi dubbi, specialmente per contenuti destinati all'esterno, chiedere prima a chi in azienda si occupa di questi aspetti.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiFile", head: "Contenuti di partenza", body: "Senza diritti non diventano leciti passando per l'AI" },
      { icon: "FiFileText", head: "Contenuti generati", body: "Titolarità in evoluzione, condizioni d'uso variabili" },
      { icon: "FiUser", head: "Immagine delle persone", body: "Di regola serve il consenso" },
      { icon: "FiMic", head: "Voce delle persone", body: "Parte dell'identità: non imitarla senza consenso" },
      { icon: "FiStar", head: "Stili e opere riconoscibili", body: "Artisti viventi, personaggi, marchi" },
      { icon: "FiHelpCircle", head: "Nei casi dubbi", body: "Chiedere prima a chi se ne occupa in azienda", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    txt(s, "Introduzione, senza analisi normativa: approfondimento nell'area responsabilità e normativa.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Verifica e supervisione", "L'ultimo punto del sottotema: la necessità di verifica e supervisione, proporzionata all'uso, come in tutto il percorso. Proponiamo tre livelli, coerenti con quelli dei temi precedenti. Per uso personale o esplorativo, come capire una schermata, farsi un'idea di un video, generare un concept, basta un controllo di plausibilità e la consapevolezza dei limiti. Per uso interno, come verbali, materiali formativi, presentazioni interne, conviene controllare gli elementi critici sull'originale: numeri, nomi, impegni, attribuzioni, e far rivedere a chi conosce il contenuto. Per uso esterno o decisionale, come comunicazione al pubblico, materiali per clienti, contenuti usati come prova o documentazione, decisioni basate su immagini o registrazioni, serve una verifica completa: provenienza accertata, confronto sistematico con l'originale, diritti verificati, trasparenza sull'uso di contenuti sintetici, e il coinvolgimento delle funzioni competenti. Due fattori alzano il livello: la presenza di persone reali e la possibilità che il contenuto venga scambiato per una rappresentazione della realtà. La consapevolezza del sottotema chiude il tema: distinguere realismo, provenienza e accuratezza è essenziale per utilizzare in modo critico i contenuti multimodali.");
    opTag(s, -1);
    const lv = [["Personale o esplorativo", "Schermate, concept, farsi un'idea", "Plausibilità e consapevolezza dei limiti", C.background2, C.text1], ["Interno", "Verbali, formazione, presentazioni interne", "Elementi critici sull'originale, revisione di chi conosce", C.accent6, C.text1], ["Esterno o decisionale", "Pubblico, clienti, prove, decisioni", "Provenienza, confronto sistematico, diritti, trasparenza", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.9;
      shapeBox(s, 0.5, y, 9.0, 0.8, l[3], l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.3, h: 0.8, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 3.0, y, w: 2.9, h: 0.8, fontSize: 12, color: l[4], valign: "middle" });
      txt(s, l[2], { x: 6.0, y, w: 3.35, h: 0.8, fontSize: 12, bold: true, color: l[4], valign: "middle" });
    });
    txt(s, "Alzano il livello", { x: 0.5, y: 3.95, w: 2.3, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.8, 3.95, 3.25, 0.55, "Persone reali", { fill: C.background2, fontSize: 12 });
    chip(s, 6.2, 3.95, 3.3, 0.55, "Può sembrare la realtà", { fill: C.background2, fontSize: 12 });
    txt(s, "Il principio dei controlli proporzionati è sviluppato nel Tema 7.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Distinguere realismo, provenienza e accuratezza è essenziale per utilizzare in modo critico i contenuti multimodali.", "Sottotema 10.8  ·  Limiti, autenticità e affidabilità dei contenuti multimodali", "Concetto chiave dell'ultimo sottotema. Gli errori dei contenuti multimodali sono difficili da vedere, perché il risultato è convincente e il controllo richiede di tornare a un'altra modalità. I contenuti sintetici realistici e i deepfake rendono necessario distinguere realismo, autenticità e accuratezza, e porre separatamente le tre domande. La provenienza si accerta con strumenti tecnici che vanno interpretati e, soprattutto, con verifiche organizzative. La comunicazione aziendale richiede trasparenza sull'uso di contenuti sintetici, e i diritti su contenuti, immagini e voci vanno considerati. Esercizio suggerito: presentare uno scenario fittizio di richiesta urgente via messaggio vocale da parte di un dirigente e discutere in gruppo quali verifiche fare e quali procedure aziendali le rendono possibili.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle dieci domande guida. Che cosa significa multimodale: lavorare con più modalità, testo, immagini, audio e video, con capacità che dipendono dal sistema. Interpretare, generare, trasformare: comprendere un contenuto, produrne uno nuovo, passarlo da una forma all'altra, con rischi diversi. Immagini, diagrammi e schermate: descrizione utile e rapida, con limiti nei dettagli, e descrivere non è comprendere. Generazione di immagini: esplorazione rapida, controllo e conformità non garantiti. Parlato e registrazioni: trascrizione, sintesi, traduzione, voce; attenzione a terminologia, numeri e attribuzioni. Video: analisi, sintesi, generazione di brevi filmati; documentale e sintetico vanno distinti. Presentazioni: bozze rapide; l'estetica non garantisce l'accuratezza. Che cosa si perde: tono, condizioni, contesto, e le catene accumulano errori. Realismo, autenticità, accuratezza: tre domande separate. Accessibilità: le conversioni tra modalità includono, purché controllate. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Che cosa significa multimodale?", "Più modalità; capacità che dipendono dal sistema"], ["Interpretare, generare, trasformare?", "Tre operazioni, tre rischi diversi"], ["Immagini e schermate?", "Utile, limiti nei dettagli; descrivere non è comprendere"], ["Generare immagini?", "Esplorazione rapida; controllo non garantito"], ["Parlato e registrazioni?", "Attenzione a termini, numeri, attribuzioni"], ["Video?", "Documentale e sintetico vanno distinti"], ["Presentazioni?", "Bozze rapide; estetica non è accuratezza"], ["Che cosa si perde?", "Tono, condizioni, contesto; catene di errori"], ["Realismo, autenticità, accuratezza?", "Tre domande separate"], ["Accessibilità?", "Conversioni che includono, se controllate"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.74;
      shapeBox(s, x, y, 4.4, 0.66, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.66, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.04, w: 3.8, h: 0.3, fontSize: 11, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.33, w: 3.8, h: 0.3, fontSize: 10, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: spiegare il significato di AI multimodale; distinguere comprensione, generazione e trasformazione di contenuti; riconoscere applicazioni di interpretazione visiva; comprendere possibilità e limiti della generazione e modifica di immagini; conoscere le principali capacità relative ad audio e parlato; riconoscere opportunità e limiti relativi ai video; comprendere il supporto alla creazione di presentazioni e materiali comunicativi; individuare le possibilità di trasformazione tra modalità; riconoscere il contributo all'accessibilità; distinguere realismo, autenticità e accuratezza; identificare rischi di perdita del significato nelle trasformazioni; comprendere l'importanza di verificare provenienza, fedeltà e adeguatezza dei contenuti.");
    const r = ["Spiegare che cos'è l'AI multimodale", "Comprendere, generare, trasformare", "Applicazioni di interpretazione visiva", "Generare e modificare immagini: possibilità e limiti", "Capacità su audio e parlato", "Opportunità e limiti dei video", "Presentazioni e materiali comunicativi", "Trasformazioni tra modalità", "Il contributo all'accessibilità", "Realismo, autenticità, accuratezza", "Perdita di significato nelle trasformazioni", "Verificare provenienza, fedeltà, adeguatezza"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Una scheda pratica", "Traduciamo il modulo in una scheda pratica, organizzata per operazione. Interpretare: controllare i dettagli importanti, numeri e testi, guardando o ascoltando l'originale; ricordare che descrivere non è comprendere, e che significato, provenienza e contesto non sono nel contenuto. Generare: usare la generazione per esplorare; controllare dettagli, testi e coerenza; rispettare identità visiva, diritti e persone; dichiarare i contenuti sintetici che potrebbero sembrare reali. Trasformare: identificare gli elementi critici, limitare le catene, confrontare con l'originale, chiedere la fonte di ogni affermazione quando si combinano più contenuti. Valutare: porre separatamente le tre domande su realismo, autenticità e accuratezza; verificare le richieste insolite su canali indipendenti; proporzionare i controlli all'uso. E sempre: immagini, registrazioni e video aziendali solo negli strumenti autorizzati, con il consenso delle persone coinvolte. Il messaggio centrale del tema: il realismo non garantisce autenticità, e ogni trasformazione richiede attenzione alla fedeltà, alla correttezza e all'adeguatezza delle informazioni.");
    const f = [["Interpretare", ["Dettagli e numeri sull'originale", "Descrivere non è comprendere", "Contesto e provenienza fuori dal contenuto"], C.background2], ["Generare", ["Per esplorare", "Dettagli, testi, coerenza", "Marchio, diritti, persone; dichiarare"], C.accent6], ["Trasformare", ["Elementi critici", "Catene brevi", "Confronto con l'originale"], C.background2], ["Valutare", ["Reale? Da dove? Vero?", "Canali indipendenti", "Controlli proporzionati"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: strumenti autorizzati e consenso delle persone coinvolte in immagini, registrazioni e video.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 10 completiamo l'esplorazione delle modalità: testi e documenti nel Tema 8, dati nel Tema 9, immagini, audio e video in questo tema. Il tema successivo, il Tema 11, è dedicato ad assistenti, agenti e automazioni: come l'AI possa evolvere da strumento conversazionale a componente operativa di attività e processi. Vedremo che cosa sono gli assistenti con strumenti e integrazioni, che cosa sono gli agenti AI, la differenza tra automazione tradizionale e intelligente, i livelli di autonomia e di supervisione umana, e le condizioni per un uso affidabile. Molte capacità viste finora, come la trascrizione di riunioni, la lettura di schermate, l'estrazione di dati dai documenti, diventeranno lì componenti di flussi di lavoro più ampi, e i principi di verifica e di fedeltà acquisteranno un peso ancora maggiore, perché gli errori potranno propagarsi in azioni e non solo in contenuti. I documenti di perimetro richiamano poi il Tema 12, sulla creazione di valore in azienda, e il Tema 14, su dati e conoscenza aziendale. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi e documenti\nTema 9: dati e analisi\nTema 10: multimodalità (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.9, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 11: Assistenti, agenti e automazioni", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Dallo strumento conversazionale alla componente operativa", { x: 5.4, y: 2.38, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.0, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 12: AI e creazione di valore in azienda", "Tema 14: dati e conoscenza aziendale"], { space: 5 }), { x: 5.4, y: 3.35, w: 3.9, h: 1.2, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo, oltre ai rimandi ai temi precedenti. I due casi di frode sono stati riportati dalla stampa internazionale: conviene verificare le fonti e i dettagli aggiornati prima di citarli in aula. Le capacità degli strumenti multimodali, in particolare la generazione di video e di voci, evolvono molto rapidamente: prima di ogni edizione è consigliabile aggiornare esempi e dimostrazioni con gli strumenti autorizzati in azienda. Tutti gli esempi del modulo sono fittizi.");
    const src = [
      "Caso di frode vocale ai danni di un'azienda energetica britannica, riportato da The Wall Street Journal, agosto 2019.",
      "Caso di frode in videochiamata presso la sede di Hong Kong di una multinazionale (Arup), riportato da CNN e Financial Times, 2024.",
      "C2PA, Coalition for Content Provenance and Authenticity: standard per le credenziali di contenuto (c2pa.org).",
      "Gli esempi di schermate, trascrizioni, immagini e materiali presenti nelle slide sono fittizi.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema10_AI_multimodale_contenuti.pptx" });
  await applyTheme("Tema10_AI_multimodale_contenuti.pptx", THEME);
  console.log("done");
})();
