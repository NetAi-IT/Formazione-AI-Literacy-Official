const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 15: Individuazione e valutazione delle opportunità AI";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 15  ·  Opportunità e valutazione AI";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5, X = o.x || 0.5, W = o.w || 9.0;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, X, y, W, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: X + 0.15, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: X + 0.15 + lw, y, w: W - 0.3 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }
  function stepTag(s, active) {
    const st = ["Individuare", "Descrivere", "Valutare", "Confrontare", "Verificare"];
    st.forEach((t, i) => {
      const x = 6.1 + i * 0.68;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.66, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "fase " + t });
      txt(s, t, { x, y: 0.42, w: 0.66, h: 0.26, fontSize: 6.5, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 15", { placeholder: "kicker" });
    s.addText("Individuazione e valutazione delle opportunità AI", { placeholder: "title" });
    s.addText("Area: Comprendere il valore per l'azienda", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al quindicesimo tema, il quarto dell'area 'Comprendere il valore per l'azienda'. Nei tre temi precedenti abbiamo visto come l'AI può creare valore, come trasforma il lavoro e i processi, e quali condizioni informative servono perché funzioni. Ora mettiamo insieme questi elementi per rispondere a una domanda molto pratica: dove potrebbe avere senso usare l'AI nella nostra organizzazione, e quali evidenze servono per scegliere? È una domanda che molte aziende si pongono oggi, spesso sotto pressione: i fornitori propongono soluzioni, i concorrenti annunciano progetti, i vertici chiedono 'che cosa stiamo facendo con l'AI?'. Il rischio è partire dalla tecnologia e cercare dove applicarla. Il modulo propone il percorso inverso: partire dai problemi, descrivere i casi d'uso, valutarli con criteri distinti, confrontarli con prudenza, e verificarli con esperimenti che possano anche dare esito negativo. Il confine cardine è con il Tema 16: qui ci chiediamo dove e perché, là come introdurre e accompagnare l'adozione. Non costruiamo business case dettagliati né piani di progetto: diamo un metodo di ragionamento, utile a chiunque proponga, valuti o riceva un'idea di uso dell'AI. Suggerimento per l'apertura: chiedere ai partecipanti di scrivere, in una riga, un'idea di uso dell'AI che hanno sentito proporre in azienda. Le useremo durante il modulo. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; il modulo è di metodo e cambia poco nel tempo, ma esempi e strumenti citati vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere come individuare, descrivere e valutare preliminarmente opportunità di uso dell'AI nelle attività e nei processi aziendali, considerando benefici potenziali, fattibilità, sostenibilità, rischi, condizioni organizzative e possibilità di verifica. La parola 'preliminarmente' è importante: non si tratta di prendere decisioni di investimento, ma di ragionare bene prima di prenderle. La consapevolezza da sviluppare: un caso d'uso AI non è valido semplicemente perché la tecnologia è capace di realizzarlo. Deve rispondere a un bisogno concreto, promettere un miglioramento rilevante, essere realizzabile e sostenibile, e presentare rischi adeguatamente controllabili. Quattro condizioni, tutte necessarie. Il messaggio chiave del documento di perimetro: un caso d'uso AI merita attenzione quando risponde a un bisogno reale, offre un miglioramento potenzialmente significativo, è sufficientemente fattibile e sostenibile e presenta rischi controllabili; queste condizioni vanno poi verificate attraverso evidenze.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Individuare, descrivere e valutare in modo preliminare le opportunità AI", "Considerare benefici, fattibilità, sostenibilità, rischi, condizioni e verifica"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Un caso d'uso non è valido perché la tecnologia sa realizzarlo.\n\nDeve rispondere a un bisogno concreto, promettere un miglioramento rilevante, essere realizzabile e sostenibile, con rischi controllabili." });
  }
  {
    const s = content("Dal bisogno, non dallo strumento", "Il documento di perimetro articola il ragionamento in quattro momenti, più uno di confronto: individuare il problema, descrivere il caso d'uso, valutare valore, fattibilità, sostenibilità e rischi, confrontare le opportunità, verificare le ipotesi con evidenze. Il principio che lo regge: la scelta deve partire dal bisogno aziendale, non dallo strumento. Lo schema in slide confronta i due percorsi. Il percorso dallo strumento: 'abbiamo questo strumento, o questa tecnologia è di moda: dove possiamo usarla?'. È un percorso molto comune, e non sempre sbagliato, perché conoscere le capacità di uno strumento aiuta a vedere opportunità. Ma porta spesso a soluzioni in cerca di un problema, a progetti dimostrativi senza seguito, a investimenti su attività che non erano un problema. Il percorso dal bisogno: 'abbiamo questo problema, o questo obiettivo: qual è la soluzione migliore? E l'AI è parte di essa?'. Porta a valutare anche alternative non AI, e a misurare i risultati rispetto al problema di partenza. Nel modulo useremo un indicatore in alto a destra per ricordare in quale fase del percorso ci troviamo.");
    shapeBox(s, 0.5, 1.15, 4.35, 2.0, C.background2, "dallo strumento");
    txt(s, "Dallo strumento", { x: 0.7, y: 1.22, w: 3.95, h: 0.4, fontSize: 15, bold: true, color: C.accent5 });
    txt(s, "'Abbiamo questa tecnologia: dove possiamo usarla?'", { x: 0.7, y: 1.62, w: 3.95, h: 0.5, fontSize: 12, italic: true, color: C.text1 });
    txt(s, "Rischio: soluzioni in cerca di un problema, dimostrazioni senza seguito", { x: 0.7, y: 2.2, w: 3.95, h: 0.85, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.15, 4.35, 2.0, C.accent6, "dal bisogno");
    txt(s, "Dal bisogno", { x: 5.35, y: 1.22, w: 3.95, h: 0.4, fontSize: 15, bold: true, color: C.accent1 });
    txt(s, "'Abbiamo questo problema: qual è la soluzione migliore? L'AI ne fa parte?'", { x: 5.35, y: 1.62, w: 3.95, h: 0.5, fontSize: 12, italic: true, color: C.text1 });
    txt(s, "Porta a valutare anche alternative non AI e a misurare i risultati sul problema", { x: 5.35, y: 2.2, w: 3.95, h: 0.85, fontSize: 12, color: C.text2 });
    const ph = ["Individuare", "Descrivere", "Valutare", "Confrontare", "Verificare"];
    ph.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      chip(s, x, 3.4, 1.62, 0.6, t, { fill: i === 4 ? C.accent1 : C.background2, color: i === 4 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 4) arrow(s, x + 1.63, 3.54, 0.19);
    });
    txt(s, "Il percorso del modulo: individuare il problema, descrivere il caso, valutarlo, confrontarlo, verificarlo con evidenze", { x: 0.5, y: 4.15, w: 9, h: 0.5, fontSize: 12, italic: true, color: C.text2, align: "center" });
  }
  {
    const s = content("Otto domande guida", "Le otto domande guida accompagnano il modulo, e seguono il percorso. Quale problema o obiettivo aziendale vogliamo affrontare. Come descrivere chiaramente un caso d'uso. Quali caratteristiche rendono un'opportunità promettente. Come distinguere i benefici ipotizzati da quelli realisticamente ottenibili. Quali dati, competenze, strumenti e integrazioni servono. Quali rischi possono rendere un caso d'uso inappropriato, anche se promettente. Come confrontare opportunità diverse senza attribuire eccessiva certezza ai punteggi. E infine, una domanda che il documento sottolinea: quali esperimenti potrebbero confermare, o smentire, le ipotesi iniziali. L'enfasi su 'smentire' è voluta, e la ritroveremo nell'ultimo sottotema. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Quale problema o obiettivo vogliamo affrontare?", "Come descrivere chiaramente un caso d'uso?", "Che cosa rende promettente un'opportunità?", "Benefici ipotizzati o realisticamente ottenibili?", "Quali dati, competenze, strumenti, integrazioni?", "Quali rischi lo rendono inappropriato?", "Come confrontare senza troppa fiducia nei punteggi?", "Quali esperimenti per confermare, o smentire?"], 4, 1.12, 1.5, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema lungo il percorso individuare, descrivere, valutare, confrontare, verificare. Individuare: i problemi aziendali e le caratteristiche delle opportunità, nei sottotemi 15.1 e 15.3. Descrivere: attività, informazioni, ruoli e risultato atteso, nel 15.2. Valutare: benefici, fattibilità, sostenibilità e rischi, dal 15.4 al 15.6. Confrontare: selezionare che cosa merita ulteriori verifiche, nel 15.7. Verificare: raccogliere evidenze, anche contrarie alle ipotesi, nel 15.8. Quattro integrazioni attraversano il modulo. A: prima chiedersi se serve davvero l'AI. B: il caso d'uso promettente non è necessariamente il più spettacolare. C: distinguere desiderabilità, fattibilità e sostenibilità, insieme all'accettabilità dei rischi. D: la sperimentazione deve poter smentire l'idea iniziale. Sulle slide compaiono senza lettere; nelle note le richiamiamo come integrazioni A, B, C e D. E tre precisazioni: confrontare con alternative realistiche, comprese quelle non AI e la situazione attuale; le condizioni di esclusione, legali, di sicurezza e di controllo, non sono compensate da punteggi elevati; una matrice di opportunità è un ausilio alla discussione, non una prova oggettiva di convenienza.");
    const d = [["FiSearch", "Individuare", "15.1  15.3"], ["FiEdit3", "Descrivere", "15.2"], ["FiSliders", "Valutare", "15.4  15.5  15.6"], ["FiBarChart2", "Confrontare", "15.7"], ["FiCheckCircle", "Verificare", "15.8"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84, dark = i === 4;
      shapeBox(s, x, 1.15, 1.68, 1.65, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.54, 1.25, 0.6, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.08, y: 1.9, w: 1.52, h: 0.4, fontSize: 13, bold: true, color: dark ? C.background1 : C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.08, y: 2.32, w: 1.52, h: 0.35, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
    }
    txt(s, "Quattro messaggi trasversali", { x: 0.5, y: 2.92, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const p = ["Prima chiedersi se serve davvero l'AI", "Il più promettente non è il più spettacolare", "Desiderabilità, fattibilità, sostenibilità", "La sperimentazione deve poter smentire"];
    p.forEach((t, i) => chip(s, 0.5 + (i % 2) * 4.6, 3.27 + Math.floor(i / 2) * 0.55, 4.4, 0.47, t, { fill: C.accent6, fontSize: 12 }));
    txt(s, "Precisazioni: alternative realistiche, anche non AI  ·  condizioni di esclusione non compensabili  ·  la matrice è un ausilio, non una prova", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti con priorità alta. Da approfondire: la definizione del problema, la descrizione del caso d'uso, la valutazione preliminare del valore e il confronto tra alternative. Da conoscere e sperimentare: le alternative non AI, la fattibilità, i rischi, la desiderabilità e la sostenibilità, l'impostazione delle ipotesi di test. Da solo accennare: business case dettagliati, ROI avanzato, gestione di portafogli progetti, progettazione tecnica dei prototipi, sperimentazione statistica specialistica, project management. Confini: usiamo le capacità di assistenti e agenti come possibili soluzioni senza ripetere il Tema 11; applichiamo a casi specifici le dimensioni del valore del Tema 12 senza riprenderne la teoria; usiamo la comprensione di compiti e processi del Tema 13 e i criteri informativi del Tema 14 come criteri di fattibilità. Non elaboriamo piani di implementazione, formazione o comunicazione, che sono del Tema 16, e identifichiamo rischi e vincoli senza approfondimenti normativi, che sono dei Temi 17 e 18.");
    pathSlide(s, [["15.1", "Partire dai problemi", "Alta"], ["15.2", "Descrivere un caso d'uso", "Alta"], ["15.3", "Opportunità promettenti", "Alta"], ["15.4", "Il valore potenziale", "Alta"], ["15.5", "Fattibilità tecnica e organizzativa", "Alta"], ["15.6", "Rischi e condizioni di controllo", "Alta"], ["15.7", "Confronto e priorità", "Alta"], ["15.8", "Dall'idea alla verifica", "Alta"]],
      [["Approfondire", "Problema, descrizione del caso d'uso, valore, confronto tra alternative", C.accent1, C.background1], ["Conoscere e sperimentare", "Alternative non AI, fattibilità, rischi, sostenibilità, ipotesi di test", C.accent6, C.text1], ["Solo accennare", "Business case, ROI avanzato, portafogli, prototipi tecnici, statistica", C.background2, C.text1]]);
  }
  {
    const s = content("Lo scenario del modulo", "Il documento di perimetro propone uno scenario che useremo come filo rosso: un'azienda che riceve molte richieste commerciali, via email e dal sito. Le persone dell'ufficio commerciale passano molto tempo a leggerle, a capire che cosa chiede il cliente, a preparare le risposte e a seguire le trattative. Tre opportunità ipotetiche emergono spesso in discussioni di questo tipo. La sintesi delle richieste: l'AI legge la richiesta e ne estrae i punti essenziali. Il valore possibile è la riduzione dei tempi di lettura; la condizione principale da verificare è la completezza e la correttezza delle sintesi. Le bozze di risposta: l'AI prepara una bozza che il commerciale rivede. Il valore possibile è rapidità e uniformità; la condizione da verificare è l'accuratezza delle condizioni commerciali e la disponibilità delle informazioni, come visto nel Tema 14. La gestione autonoma delle trattative: un agente che risponde, negozia, propone condizioni. Il valore possibile è una trasformazione del processo; le condizioni da verificare riguardano il controllo delle azioni, le eccezioni, le autorizzazioni e il rischio. I giudizi sono illustrativi, non valutazioni di un'azienda reale. Torneremo su queste tre opportunità in molti sottotemi.");
    table(s, [["Opportunità ipotetica", "Possibile valore", "Condizione principale da verificare"],
      ["Sintesi delle richieste", "Meno tempo di lettura", "Completezza e correttezza delle sintesi"],
      ["Bozze di risposta", "Rapidità e uniformità", "Accuratezza delle condizioni, informazioni disponibili"],
      ["Gestione autonoma delle trattative", "Trasformazione del processo", "Controllo delle azioni, eccezioni, autorizzazioni, rischio"]],
      { y: 1.15, colW: [2.8, 2.4, 3.8], rowH: 0.62, accentCol: 2, fontSize: 12, blankCorner: false });
    banner(s, 3.85, "Un'azienda che riceve molte richieste commerciali. Giudizi illustrativi, non valutazioni di un'azienda reale.", { h: 0.85, fontSize: 14 });
  }

  // =====================================================================
  section("15.1 Partire dai problemi");
  divider("15.1", "Partire dai problemi", "Prima di scegliere l'AI occorre comprendere il problema, e chiedersi se serve davvero", "Primo sottotema, da comprendere e applicare, e uno di quelli da approfondire. Il punto di partenza di ogni opportunità è un problema o un obiettivo, non uno strumento. Vediamo la differenza tra problema, bisogno, obiettivo e soluzione; dove cercare i problemi: inefficienze, attività che assorbono tempo, errori e rilavorazioni, informazioni mancanti, servizio da migliorare; come definire il risultato desiderato; come distinguere cause e sintomi; e come confrontare l'AI con soluzioni non AI. Integrazione A: prima chiedersi se serve davvero l'AI.");
  {
    const s = content("Dal problema alla soluzione", "La prima distinzione del sottotema, e la prima domanda guida. Quattro parole spesso usate come sinonimi, che conviene separare. Il problema è una situazione insoddisfacente osservabile: le risposte ai clienti arrivano in tre giorni, mentre i concorrenti rispondono in uno. Il bisogno è ciò che manca per superarla, dal punto di vista di chi la vive: i clienti hanno bisogno di una risposta rapida per decidere; i commerciali hanno bisogno di più tempo per le trattative importanti. L'obiettivo è il risultato desiderato, possibilmente misurabile: rispondere entro un giorno lavorativo al 90 per cento delle richieste. La soluzione è il modo scelto per raggiungerlo: più persone, una diversa organizzazione del lavoro, modelli di risposta, un assistente AI. Il problema più comune nelle discussioni sull'AI è partire dalla quarta: 'vogliamo un chatbot per i clienti'. Una soluzione presentata come obiettivo nasconde il problema, e impedisce di valutare alternative. Un esercizio semplice: quando qualcuno propone una soluzione, chiedere 'quale problema risolve?' e 'come sapremo se l'ha risolto?'. Esempio fittizio, legato allo scenario del modulo.");
    stepTag(s, 0);
    const l = [["Problema", "Situazione insoddisfacente osservabile", "Le risposte arrivano in tre giorni, i concorrenti in uno"], ["Bisogno", "Che cosa manca, per chi la vive", "I clienti vogliono decidere in fretta; i commerciali, tempo per le trattative"], ["Obiettivo", "Il risultato desiderato, misurabile", "Rispondere entro un giorno al 90% delle richieste"], ["Soluzione", "Il modo scelto per raggiungerlo", "Persone, organizzazione, modelli di risposta, un assistente AI"]];
    l.forEach((e, i) => {
      const y = 1.12 + i * 0.78, dark = i === 3;
      shapeBox(s, 0.5, y, 9.0, 0.7, dark ? C.accent6 : (i % 2 ? C.background1 : C.background2), e[0]);
      txt(s, e[0], { x: 0.65, y, w: 1.5, h: 0.7, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.15, y: y + 0.04, w: 7.2, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[2], { x: 2.15, y: y + 0.36, w: 7.2, h: 0.32, fontSize: 11, italic: true, color: C.text2 });
    });
    banner(s, 4.3, "Davanti a una soluzione: quale problema risolve? Come sapremo se l'ha risolto?", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Dove cercare i problemi", "Il sottotema indica cinque aree in cui cercare problemi e opportunità, utili come traccia per un'esplorazione in azienda. Le inefficienze e difficoltà operative: passaggi inutili, attese, lavoro duplicato, procedure macchinose. Le attività che assorbono tempo e risorse: quelle in cui le persone passano molte ore, spesso senza che sia il cuore del loro lavoro, come cercare informazioni, compilare, riformattare. I problemi di qualità, errori e rilavorazioni: dove si sbaglia spesso, dove si deve rifare il lavoro, dove arrivano reclami. I limiti nella disponibilità delle informazioni: dove le persone non trovano ciò che serve, o lo trovano tardi, o non sanno a chi chiedere. Le opportunità di miglioramento del servizio: che cosa i clienti, interni o esterni, vorrebbero e oggi non ricevono, come risposte più rapide o più personalizzate. Il modo migliore per individuarli è chiedere a chi fa il lavoro, osservare il lavoro reale, come visto nel Tema 13, e guardare i dati disponibili: tempi, volumi, errori, reclami. Notate che nessuna di queste aree menziona l'AI: i problemi vengono prima.");
    stepTag(s, 0);
    await iconGrid(s, [
      { icon: "FiAlertTriangle", head: "Inefficienze", body: "Passaggi inutili, attese, lavoro duplicato" },
      { icon: "FiClock", head: "Tempo e risorse", body: "Ore spese a cercare, compilare, riformattare" },
      { icon: "FiRotateCcw", head: "Errori e rilavorazioni", body: "Dove si sbaglia, si rifà, arrivano reclami" },
      { icon: "FiHelpCircle", head: "Informazioni mancanti", body: "Non si trova, si trova tardi, non si sa a chi chiedere" },
      { icon: "FiSmile", head: "Servizio da migliorare", body: "Che cosa i clienti vorrebbero e non ricevono" },
      { icon: "FiEye", head: "Come trovarli", body: "Chiedere a chi lavora, osservare, guardare i dati" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Nessuna di queste aree menziona l'AI: i problemi vengono prima.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Il risultato desiderato", "Il sottotema chiede di definire il risultato desiderato. Sembra ovvio, ma è spesso il passaggio più trascurato. Senza un risultato definito non si può valutare se una soluzione funziona, né confrontarla con altre. Un buon risultato desiderato ha alcune caratteristiche. È riferito al problema, non alla soluzione: 'risposte entro un giorno', non 'usare l'AI per le risposte'. È osservabile: si può capire se è stato raggiunto, possibilmente con un indicatore. Ha un livello di partenza: oggi le risposte arrivano in media in tre giorni. Ha un livello obiettivo realistico. E considera anche ciò che non deve peggiorare: la qualità delle risposte, la correttezza delle condizioni, la soddisfazione dei commerciali. Quest'ultimo punto è importante e spesso dimenticato: molti miglioramenti in una dimensione ne peggiorano un'altra, come visto nel Tema 12. Definire in anticipo i limiti da non superare evita di dichiarare un successo che in realtà ha spostato il problema. L'esempio in slide, fittizio, mostra la differenza tra una formulazione vaga e una formulazione utile.");
    stepTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.1, "Formulazione vaga", "Migliorare la gestione delle richieste commerciali con l'AI.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    shapeBox(s, 5.15, 1.15, 4.35, 2.9, C.accent6, "formulazione utile");
    txt(s, "Formulazione utile (esempio fittizio)", { x: 5.35, y: 1.22, w: 3.95, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
    const r = [["Problema", "Risposte lente ai clienti"], ["Oggi", "In media 3 giorni"], ["Obiettivo", "Entro 1 giorno per il 90%"], ["Non peggiorare", "Correttezza delle condizioni, qualità"], ["Come osservarlo", "Tempi registrati nel CRM"]];
    r.forEach((e, i) => {
      txt(s, e[0], { x: 5.35, y: 1.6 + i * 0.47, w: 1.5, h: 0.42, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[1], { x: 6.85, y: 1.6 + i * 0.47, w: 2.5, h: 0.42, fontSize: 12, color: C.text1, valign: "middle" });
    });
    txt(s, bullets(["Riferito al problema, non alla soluzione", "Osservabile, con un livello di partenza", "Un obiettivo realistico", "Che cosa non deve peggiorare"], { space: 4 }), { x: 0.6, y: 2.45, w: 4.2, h: 1.6, fontSize: 12, color: C.text1 });
    banner(s, 4.25, "Definire prima che cosa non deve peggiorare evita successi che spostano il problema.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Cause e sintomi", "Il sottotema chiede di identificare le cause del problema e distinguerle dai sintomi. È un principio classico del miglioramento dei processi: intervenire sui sintomi dà sollievo temporaneo, intervenire sulle cause risolve. Riprendiamo l'esempio: le risposte ai clienti sono lente. È un sintomo. Le cause possono essere molto diverse. Le richieste arrivano a una casella generica e nessuno le smista per giorni. I commerciali devono chiedere i prezzi all'ufficio tecnico, che risponde lentamente. Le richieste sono incomplete e servono scambi per chiarirle. I commerciali sono pochi rispetto ai volumi. Scrivere le risposte richiede molto tempo. Solo l'ultima causa è direttamente affrontabile con un assistente che prepara bozze. Se la causa principale è l'attesa dell'ufficio tecnico, un assistente che scrive più in fretta non cambierà molto il tempo totale: è il collo di bottiglia del Tema 12 e del Tema 13. Una tecnica semplice e nota è quella dei 'cinque perché', associata alla tradizione del miglioramento continuo giapponese: chiedersi più volte 'perché?' fino ad arrivare a una causa su cui si può intervenire. Esempio fittizio.");
    stepTag(s, 0);
    shapeBox(s, 0.5, 1.15, 2.6, 3.0, C.accent1, "sintomo");
    txt(s, "Sintomo", { x: 0.65, y: 1.3, w: 2.3, h: 0.35, fontSize: 12, bold: true, color: C.accent6 });
    txt(s, "Le risposte ai clienti sono lente", { x: 0.65, y: 1.75, w: 2.3, h: 1.2, fontSize: 16, bold: true, color: C.background1 });
    txt(s, "Esempio fittizio", { x: 0.65, y: 3.6, w: 2.3, h: 0.35, fontSize: 11, italic: true, color: C.accent6 });
    const c = [["Nessuno smista la casella generica", false], ["Si attendono i prezzi dall'ufficio tecnico", false], ["Richieste incomplete, servono chiarimenti", false], ["Pochi commerciali rispetto ai volumi", false], ["Scrivere le risposte richiede tempo", true]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.62;
      arrow(s, 3.2, y + 0.13, 0.35);
      chip(s, 3.65, y, 5.85, 0.52, e[0], { fill: e[1] ? C.accent6 : C.background2, fontSize: 12, bold: e[1] });
    });
    banner(s, 4.3, "Solo l'ultima causa è affrontata da bozze automatiche. I 'cinque perché' aiutano a risalire alle cause.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Le alternative non AI", "Il cuore del sottotema, e l'integrazione A: prima chiedersi se serve davvero l'AI. La prima precisazione trasversale del tema chiede di confrontare il caso d'uso non solo con altre applicazioni AI, ma con alternative realistiche. Il documento ne indica quattro. La situazione attuale, cioè non fare nulla: a volte il problema è tollerabile, o costerebbe di più risolverlo. Una modifica organizzativa: cambiare chi fa che cosa, l'ordine dei passaggi, le regole. Nell'esempio: assegnare a una persona lo smistamento quotidiano delle richieste. Una procedura tradizionale: un modulo strutturato sul sito, che raccolga le informazioni necessarie e riduca le richieste incomplete; un modello di risposta standard. Un'automazione semplice, basata su regole: instradare le richieste in base al prodotto, inviare una conferma automatica di ricezione. Queste alternative sono spesso più economiche, più affidabili, più facili da mantenere. Non sempre bastano: ci sono problemi in cui l'AI offre qualcosa che le alternative non possono dare, come la comprensione di testi liberi e variabili. Ma il confronto va fatto, e va fatto prima. Esempi fittizi.");
    stepTag(s, 0);
    const a = [["FiPauseCircle", "Situazione attuale", "Non intervenire: il problema è tollerabile?"], ["FiUsers", "Modifica organizzativa", "Una persona smista ogni mattina"], ["FiFileText", "Procedura tradizionale", "Un modulo strutturato, risposte standard"], ["FiGitBranch", "Automazione semplice", "Regole di instradamento, conferma automatica"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.3, C.background2, a[i][1]);
      await iconCircle(s, x + 0.75, 1.25, 0.62, a[i][0]);
      txt(s, a[i][1], { x: x + 0.1, y: 1.95, w: 1.95, h: 0.5, fontSize: 13, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, a[i][2], { x: x + 0.12, y: 2.5, w: 1.91, h: 0.85, fontSize: 11, italic: true, color: C.text2, align: "center" });
    }
    shapeBox(s, 0.5, 3.6, 9.0, 0.6, C.accent6, "quando l'AI");
    txt(s, [{ text: "Quando l'AI aggiunge qualcosa: ", options: { bold: true, color: C.accent1 } }, { text: "per esempio la comprensione di testi liberi e variabili, che le regole non gestiscono.", options: { color: C.text1 } }], { x: 0.7, y: 3.6, w: 8.6, h: 0.6, fontSize: 12, valign: "middle" });
    banner(s, 4.35, "Prima chiedersi se serve davvero l'AI. Il confronto va fatto, e va fatto prima.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Partire dalla tecnologia", "L'ultimo punto del sottotema: i rischi di partire dalla tecnologia anziché dal bisogno. Vale la pena elencarli, perché è un errore molto diffuso e comprensibile, alimentato dall'entusiasmo e dalla pressione esterna. Soluzioni in cerca di un problema: progetti che funzionano tecnicamente ma che nessuno usa, perché non rispondevano a un bisogno sentito. Investimenti sproporzionati: soluzioni sofisticate per problemi che un'alternativa semplice avrebbe risolto. Obiettivi non definiti: senza un problema di partenza, non si sa che cosa misurare, e il progetto non può né riuscire né fallire in modo chiaro. Dimostrazioni senza seguito: un prototipo impressionante, presentato con successo, che non diventa mai uno strumento di lavoro. Problemi spostati: l'AI accelera un passaggio, ma il problema vero era altrove. E una conseguenza meno visibile: delusione e scetticismo, che rendono più difficili anche i progetti successivi, anche quelli validi. Questo non significa che conoscere la tecnologia sia inutile: sapere che cosa l'AI può fare, come nei Temi 8-11, aiuta a riconoscere opportunità. Significa che, una volta vista un'opportunità, bisogna risalire al problema e verificare che sia reale.");
    stepTag(s, 0);
    rowsLabel(s, [["Soluzioni senza problema", "Funzionano, ma nessuno le usa"], ["Investimenti sproporzionati", "Sofisticate dove bastava poco"], ["Obiettivi non definiti", "Il progetto non può né riuscire né fallire in modo chiaro"], ["Dimostrazioni senza seguito", "Il prototipo impressiona, lo strumento non arriva"], ["Delusione e scetticismo", "Anche i progetti validi diventano più difficili"]], { y: 1.15, h: 0.5, lw: 2.8 });
    banner(s, 4.3, "Conoscere la tecnologia aiuta a vedere opportunità. Poi bisogna risalire al problema, e verificare che sia reale.", { h: 0.65, fontSize: 13 });
  }
  keySlide("Prima di scegliere l'AI occorre comprendere il problema, e chiedersi se una soluzione tradizionale, organizzativa o semplice non sia più adatta.", "Sottotema 15.1  ·  Partire dai problemi", "Concetto chiave del primo sottotema. Problema, bisogno, obiettivo e soluzione sono cose diverse, e partire dalla soluzione nasconde il problema. I problemi si cercano in inefficienze, tempo assorbito, errori, informazioni mancanti, servizio. Il risultato desiderato va definito in modo osservabile, con ciò che non deve peggiorare. Le cause vanno distinte dai sintomi. Le alternative non AI vanno confrontate prima. Esercizio suggerito: riprendere l'idea di uso dell'AI scritta all'inizio e riformularla partendo dal problema: quale situazione insoddisfacente, per chi, con quale risultato desiderato, e quali alternative non AI esistono.");

  // =====================================================================
  section("15.2 Descrivere un caso d'uso");
  divider("15.2", "Descrivere un caso d'uso", "Chi svolge quale attività, su quali informazioni, con quale contributo dell'AI e per quale risultato", "Secondo sottotema, da comprendere e applicare, e uno di quelli da approfondire. Dopo aver definito il problema, si descrive il caso d'uso: l'applicazione concreta dell'AI a quel problema. Il documento distingue: il 15.1 definisce il bisogno, il 15.2 descrive l'applicazione. Vediamo che cosa significa caso d'uso, gli elementi di una buona descrizione, la differenza tra un'idea generica e un caso d'uso definito, e l'identificazione delle ipotesi da verificare.");
  {
    const s = content("Che cos'è un caso d'uso", "Il significato di caso d'uso. Il termine viene dall'ingegneria del software, dove indica la descrizione di come un utente interagisce con un sistema per raggiungere un obiettivo. Nel linguaggio aziendale sull'AI ha preso un significato più ampio: un'applicazione specifica dell'AI a un'attività o a un processo, per un certo scopo. La consapevolezza del sottotema lo dice in una frase che conviene ricordare: un caso d'uso deve specificare chi svolge quale attività, su quali informazioni, con quale contributo dell'AI, e per quale risultato. Cinque elementi: il chi, il che cosa, le informazioni, il ruolo dell'AI, il risultato. Se manca uno di questi, non abbiamo ancora un caso d'uso, ma un'idea. 'Usare l'AI nel commerciale' è un ambito. 'Un chatbot per i clienti' è una soluzione. 'I commerciali dell'area nord ricevono, per ogni richiesta arrivata via email, una sintesi preparata dall'AI con prodotto, quantità, tempi e domande aperte, per ridurre il tempo di lettura e non perdere informazioni' è un caso d'uso. Esempio fittizio.");
    stepTag(s, 1);
    const e = [["Chi", "svolge"], ["Quale attività", "o processo"], ["Su quali informazioni", "input"], ["Con quale contributo", "dell'AI"], ["Per quale risultato", "osservabile"]];
    e.forEach((x, i) => {
      const xx = 0.5 + i * 1.84;
      shapeBox(s, xx, 1.15, 1.68, 1.05, i === 3 ? C.accent1 : C.background2, x[0]);
      txt(s, x[0], { x: xx + 0.08, y: 1.18, w: 1.52, h: 0.58, fontSize: 12, bold: true, color: i === 3 ? C.background1 : C.accent1, align: "center", valign: "middle" });
      txt(s, x[1], { x: xx + 0.08, y: 1.8, w: 1.52, h: 0.3, fontSize: 11, color: i === 3 ? C.accent6 : C.text2, align: "center" });
    });
    rowsLabel(s, [["Un ambito", "'Usare l'AI nel commerciale'"], ["Una soluzione", "'Un chatbot per i clienti'"]], { y: 2.4, h: 0.45, lw: 1.8 });
    docBox(s, 0.5, 3.5, 9.0, 1.35, "Un caso d'uso (esempio fittizio)", "I commerciali dell'area nord ricevono, per ogni richiesta via email, una sintesi preparata dall'AI con prodotto, quantità, tempi e domande aperte, per ridurre il tempo di lettura e non perdere informazioni.", { fontSize: 13, fill: C.accent6 });
  }
  {
    const s = content("Gli elementi della descrizione", "Il sottotema elenca gli elementi di una descrizione completa, che possiamo organizzare in una scheda. Contesto e persone coinvolte: in quale reparto, quali ruoli, chi usa e chi riceve il risultato. Attività o processo interessato: quale passaggio cambia. Problema e obiettivo concreto, dal 15.1. Input e informazioni necessarie: che cosa riceve il sistema, da dove, in quale forma; qui entrano le condizioni del Tema 14. Risultato atteso e modo per osservarlo. Ruolo previsto dell'AI: supporta, automatizza in parte, trasforma, come visto nel Tema 13. Intervento e supervisione umana: chi controlla, quando, come corregge. Frequenza e volume: quante volte al giorno, al mese; è un dato decisivo per il valore. Confini e condizioni d'uso: che cosa il sistema non deve fare, in quali casi non si usa, come si gestiscono le eccezioni. La scheda in slide riassume gli elementi: è uno strumento semplice, che chiunque può compilare, e che rende confrontabili idee diverse. Nella pratica, compilarla fa emergere rapidamente che cosa non si sa ancora.");
    stepTag(s, 1);
    const f = [["Contesto e persone", "Reparto, ruoli, chi usa e chi riceve"], ["Attività o processo", "Quale passaggio cambia"], ["Problema e obiettivo", "Dal 15.1"], ["Input e informazioni", "Che cosa, da dove, in quale forma"], ["Risultato atteso", "E come osservarlo"], ["Ruolo dell'AI", "Supporta, automatizza in parte, trasforma"], ["Supervisione umana", "Chi controlla, quando, come corregge"], ["Frequenza e volume", "Quante volte, quanti casi"], ["Confini e condizioni", "Che cosa non fa, eccezioni, quando non si usa"]];
    f.forEach((e, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.15 + row * 1.0;
      shapeBox(s, x, y, 2.9, 0.88, row % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.15, y: y + 0.06, w: 2.6, h: 0.34, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: y + 0.42, w: 2.6, h: 0.4, fontSize: 11, color: C.text1 });
    });
    banner(s, 4.25, "Compilare la scheda fa emergere rapidamente che cosa non si sa ancora.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Un esempio compilato", "Proviamo a compilare la scheda per una delle tre opportunità dello scenario: le bozze di risposta alle richieste commerciali. Esempio interamente fittizio. Contesto: ufficio commerciale, otto commerciali, area Italia. Attività: risposta alle richieste di informazioni e preventivo arrivate via email. Problema e obiettivo: risposte in media in tre giorni, obiettivo un giorno per il 90 per cento, senza errori sulle condizioni. Input: testo della richiesta, listino in vigore, condizioni standard, storico del cliente dal CRM. Risultato: una bozza di risposta pronta da rivedere. Ruolo dell'AI: prepara la bozza, non invia. Supervisione: il commerciale rivede, corregge e invia; le condizioni fuori standard richiedono approvazione del responsabile, come oggi. Volume: circa 60 richieste al giorno. Confini: nessuna bozza per richieste su prodotti personalizzati o clienti con contratti quadro; nessun prezzo non presente nel listino. Notate che la compilazione ha già fatto emergere domande: il listino è aggiornato e accessibile? Lo storico del CRM è affidabile? Le richieste su prodotti personalizzati quante sono? Queste domande diventano le ipotesi da verificare.");
    stepTag(s, 1);
    rowsLabel(s, [["Contesto", "Ufficio commerciale, 8 persone, area Italia"], ["Attività", "Risposta a richieste di informazioni e preventivo via email"], ["Input", "Richiesta, listino in vigore, condizioni standard, storico CRM"], ["Ruolo dell'AI", "Prepara una bozza, non invia"], ["Supervisione", "Il commerciale rivede e invia; fuori standard, approva il responsabile"], ["Volume", "Circa 60 richieste al giorno"], ["Confini", "No prodotti personalizzati, no contratti quadro, no prezzi fuori listino"]], { y: 1.12, h: 0.42, lw: 1.8, fontSize: 11, headSize: 12 });
    txt(s, "Esempio fittizio: bozze di risposta alle richieste commerciali.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.accent5 });
  }
  {
    const s = content("Idea generica o caso definito", "Il sottotema chiede di riconoscere la differenza tra un'idea generica e un caso d'uso definito. Le idee generiche sono il punto di partenza naturale, e non vanno scoraggiate: 'potremmo usare l'AI per le richieste dei clienti'. Ma non sono ancora valutabili. Un'idea generica non permette di stimare il valore, perché non si sa quante attività riguarda e quanto tempo fa risparmiare. Non permette di valutare la fattibilità, perché non si sa quali informazioni servono. Non permette di valutare i rischi, perché non si sa che cosa fa il sistema e chi controlla. Non permette di confrontarla con altre, perché non si sa che cosa si sta confrontando. Il passaggio dall'idea al caso definito è spesso il lavoro più utile di tutta la valutazione, e richiede il contributo di chi conosce il lavoro: le persone che svolgono l'attività sanno quali sono le eccezioni, i volumi, le informazioni davvero necessarie. Un segnale utile: se due persone, leggendo la stessa descrizione, immaginano due sistemi molto diversi, il caso d'uso non è ancora definito.");
    stepTag(s, 1);
    await twoPanel(s, "Idea generica", "'Potremmo usare l'AI per le richieste dei clienti.'\n\nUn buon punto di partenza, ma non valutabile: valore, fattibilità, rischi, confronto restano indefiniti.", "Caso d'uso definito", "Chi, quale attività, quali informazioni, quale ruolo dell'AI, quale supervisione, quale risultato, quale volume, quali confini.\n\nValutabile e confrontabile.", { y: 1.15, h: 2.65, li: "FiCloud", ri: "FiClipboard" });
    banner(s, 4.0, "Segnale: se due persone, leggendo la stessa descrizione, immaginano due sistemi diversi, il caso non è ancora definito.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Le ipotesi da verificare", "L'ultimo punto del sottotema, che prepara il 15.8: l'identificazione delle principali ipotesi da verificare. Ogni caso d'uso, anche ben descritto, si basa su ipotesi: affermazioni che crediamo vere ma che non abbiamo ancora verificato. Conviene renderle esplicite subito, perché sono ciò che il caso d'uso deve dimostrare. Nell'esempio delle bozze di risposta, le ipotesi principali potrebbero essere: che la scrittura delle risposte sia una parte rilevante del tempo totale; che le bozze siano abbastanza buone da richiedere solo una revisione rapida; che il listino e le condizioni siano disponibili e aggiornati; che i commerciali usino le bozze invece di riscrivere da capo; che le richieste escluse, come i prodotti personalizzati, siano una minoranza. Alcune ipotesi sono critiche: se sono false, il caso d'uso non ha senso. Per esempio, se la scrittura occupa solo il 10 per cento del tempo totale, il beneficio massimo è limitato, comunque vadano le bozze. Identificare le ipotesi critiche è il primo passo per decidere che cosa verificare prima di investire. Esempio fittizio.");
    stepTag(s, 1);
    numList(s, ["La scrittura delle risposte è una parte rilevante del tempo totale", "Le bozze richiedono solo una revisione rapida", "Listino e condizioni sono disponibili e aggiornati", "I commerciali useranno le bozze invece di riscrivere", "Le richieste escluse sono una minoranza"], { y: 1.12, h: 0.5, fontSize: 13 });
    shapeBox(s, 0.5, 4.1, 9.0, 0.78, C.accent6, "critica");
    txt(s, [{ text: "Ipotesi critica: ", options: { bold: true, color: C.accent5 } }, { text: "se la scrittura occupa solo il 10% del tempo, il beneficio massimo è limitato, comunque vadano le bozze. Esempio fittizio.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.78, fontSize: 12, valign: "middle" });
  }
  keySlide("Un caso d'uso specifica chi svolge quale attività, su quali informazioni, con quale contributo dell'AI e per quale risultato. Il resto è ancora un'idea.", "Sottotema 15.2  ·  Descrivere un caso d'uso", "Concetto chiave del secondo sottotema. Un caso d'uso è un'applicazione specifica dell'AI a un'attività, per uno scopo. La scheda di descrizione comprende contesto, attività, problema, input, risultato, ruolo dell'AI, supervisione, volume e confini. Compilarla fa emergere ciò che non si sa, e le ipotesi da verificare, alcune delle quali critiche. Esercizio suggerito: in piccoli gruppi, compilare la scheda per l'idea scritta all'inizio, e sottolineare le ipotesi critiche, cioè quelle che, se false, renderebbero il caso d'uso privo di senso.");

  // =====================================================================
  section("15.3 Opportunità promettenti");
  divider("15.3", "Opportunità promettenti", "L'opportunità più promettente non è necessariamente la più complessa o impressionante", "Terzo sottotema, da comprendere. Quali caratteristiche di un'attività segnalano un'opportunità promettente? Riprendiamo, applicandoli alla scelta, alcuni criteri visti nel Tema 13 sulla trasformabilità: frequenza, impegno informativo, standardizzazione, variabilità, informazioni, verificabilità, conseguenze degli errori, giudizio specialistico. Il documento distingue: il 15.3 riconosce i segnali di potenziale, il 15.5 verifica la disponibilità effettiva dei prerequisiti. Integrazioni A e B: prima chiedersi se serve davvero l'AI, e il caso più promettente non è il più spettacolare.");
  {
    const s = content("Segnali di potenziale", "Il sottotema elenca le caratteristiche che possono rendere promettente un'opportunità. Le raggruppiamo in due famiglie. I segnali di valore, che dicono quanto potrebbe valere intervenire: attività frequenti e ripetitive, perché il beneficio si moltiplica; attività con elevato impegno informativo, cioè molto tempo speso a leggere, cercare, scrivere, sintetizzare, l'ambito in cui l'AI generativa interviene di più; volumi e tempi di esecuzione rilevanti. I segnali di adattabilità, che dicono quanto l'AI potrebbe funzionare bene: un certo grado di standardizzazione; variabilità ed eccezioni gestibili; disponibilità delle informazioni necessarie; possibilità di verificare i risultati; conseguenze degli errori limitate o intercettabili; necessità di giudizio specialistico contenuta, o comunque preservata nella supervisione. Nessun segnale da solo è decisivo, e alcuni vanno in direzioni opposte: un'attività molto standardizzata e ripetitiva è promettente, ma potrebbe essere gestita meglio da un'automazione tradizionale, come vediamo tra poco. Il documento sottolinea che questi sono segnali, non prove: un'attività astrattamente adatta può non essere realizzabile nel contesto specifico.");
    stepTag(s, 0);
    await twoPanel(s, "Segnali di valore", bullets(["Attività frequenti e ripetitive", "Elevato impegno informativo", "Volumi e tempi rilevanti"], { space: 6 }), "Segnali di adattabilità", bullets(["Standardizzazione, eccezioni gestibili", "Informazioni disponibili", "Risultati verificabili", "Errori con conseguenze limitate", "Giudizio specialistico contenuto o preservato"], { space: 4 }), { y: 1.15, h: 2.75, li: "FiTrendingUp", ri: "FiCheckSquare" });
    banner(s, 4.1, "Segnali, non prove: un'attività astrattamente adatta può non essere realizzabile nel contesto specifico.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Profilo di un'opportunità", "Uno strumento semplice per applicare i segnali: un profilo, che descrive un'attività su ciascuna caratteristica. Il grafico, con valutazioni illustrative e fittizie, confronta due delle opportunità dello scenario: la sintesi delle richieste e la gestione autonoma delle trattative. Su una scala da 1 a 5, dove 5 è il valore più favorevole. La sintesi delle richieste ha frequenza alta, impegno informativo alto, buona verificabilità, conseguenze degli errori limitate, perché la persona legge comunque la richiesta originale se serve, e poco bisogno di giudizio specialistico. La gestione autonoma delle trattative ha frequenza e impegno informativo simili, ma verificabilità bassa, conseguenze degli errori elevate, perché impegna l'azienda verso il cliente, e molto bisogno di giudizio. Il profilo non produce una decisione, ma rende visibili le differenze, e fa discutere sulle valutazioni: è il suo scopo principale. Le valutazioni sono giudizi, e persone diverse possono darne di diversi: è utile chiedere a più persone e confrontare. Valutazioni illustrative.");
    stepTag(s, 0);
    const labels = ["Frequenza", "Impegno informativo", "Standardizzazione", "Verificabilità", "Errori contenuti", "Poco giudizio specialistico"];
    s.addChart(pres.charts.BAR, [
      { name: "Sintesi delle richieste", labels, values: [5, 5, 3, 4, 4, 4] },
      { name: "Trattative autonome", labels, values: [4, 5, 2, 2, 1, 1] },
    ], { x: 0.5, y: 1.05, w: 6.0, h: 3.75, barDir: "bar", barGrouping: "clustered", chartColors: [HEX.a1, HEX.a5],
      showValue: true, dataLabelColor: HEX.dk1, dataLabelFontSize: 10, dataLabelFontFace: "+mn-lt", dataLabelPosition: "outEnd",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
      valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 5.5, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Profilo, da 1 a 5 (valutazioni illustrative)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 40 });
    await card(s, 6.75, 1.15, 2.75, 1.75, { icon: "FiMessageCircle", inline: true, head: "Fa discutere", headSize: 13, bodySize: 12, body: "Non decide: rende visibili le differenze." });
    await card(s, 6.75, 3.05, 2.75, 1.75, { icon: "FiUsers", inline: true, head: "Sono giudizi", headSize: 13, bodySize: 12, fill: C.accent6, body: "Chiedere a più persone e confrontare." });
  }
  {
    const s = content("Supporto o automazione parziale", "Il sottotema chiede di considerare la possibilità di supporto o automazione parziale. Davanti a un'attività, la scelta non è tra 'l'AI fa tutto' e 'l'AI non fa nulla'. Ci sono molte possibilità intermedie, come visto nei Temi 11 e 13. L'AI può preparare e la persona decidere: la bozza di risposta. Può occuparsi dei casi semplici e passare quelli complessi alla persona: le richieste standard ricevono una bozza, quelle con condizioni particolari no. Può fare un primo passaggio, come la classificazione o l'estrazione delle informazioni, lasciando il resto invariato. Può controllare il lavoro della persona invece di sostituirlo, segnalando possibili errori. Le soluzioni parziali hanno spesso vantaggi importanti: catturano gran parte del valore con una frazione del rischio, sono più facili da verificare, lasciano alla persona il controllo e il giudizio, e permettono di imparare prima di estendere. È una delle ragioni per cui l'opportunità più promettente è spesso più modesta di quella immaginata all'inizio. Esempi fittizi.");
    stepTag(s, 0);
    await iconGrid(s, [
      { icon: "FiEdit3", head: "Prepara, la persona decide", body: "La bozza di risposta" },
      { icon: "FiFilter", head: "I casi semplici", body: "Bozza per le richieste standard, non per le particolari" },
      { icon: "FiTag", head: "Un primo passaggio", body: "Classificare, estrarre informazioni" },
      { icon: "FiShield", head: "Controlla", body: "Segnala possibili errori nel lavoro della persona" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Gran parte del valore con una frazione del rischio, più facile da verificare, e si impara prima di estendere.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Complessità o utilità", "L'integrazione B del tema: il caso d'uso promettente non è necessariamente il più spettacolare. Il sottotema la formula come differenza tra complessità tecnologica e utilità effettiva. C'è una tendenza naturale a considerare più interessanti i progetti più ambiziosi: un agente che gestisce da solo le trattative attira più attenzione di uno strumento che riassume le email. Ma l'utilità non cresce con la complessità. Spesso è il contrario: più un sistema è complesso, più è costoso da costruire e mantenere, più è difficile da verificare, più rischi comporta, più tempo serve prima che produca valore, più facilmente si ferma allo stadio di prototipo. Uno strumento semplice, usato ogni giorno da molte persone, con risultati facili da controllare, può generare più valore complessivo di un sistema sofisticato usato raramente o con riserva. Il grafico illustra questa idea con un andamento ipotetico: oltre un certo punto, la complessità aggiunta porta più costi e rischi che utilità. La consapevolezza del sottotema: una soluzione limitata e controllabile può generare maggiore valore.");
    stepTag(s, 0);
    s.addChart(pres.charts.LINE, [
      { name: "Utilità effettiva", labels: ["Molto semplice", "Semplice", "Media", "Complessa", "Molto complessa"], values: [3, 6, 7, 6.5, 5] },
      { name: "Costi e rischi", labels: ["Molto semplice", "Semplice", "Media", "Complessa", "Molto complessa"], values: [1, 2, 3.5, 6, 9] },
    ], { x: 0.5, y: 1.05, w: 5.4, h: 3.4, chartColors: [HEX.a1, HEX.a5], lineSize: 3, lineDataSymbol: "circle", lineDataSymbolSize: 7,
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 10, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Andamento ipotetico, per complessità della soluzione", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt" });
    await card(s, 6.15, 1.15, 3.35, 1.6, { icon: "FiStar", inline: true, head: "Spettacolare", headSize: 13, bodySize: 12, body: "Più costoso, difficile da verificare, rischioso, lento." });
    await card(s, 6.15, 2.9, 3.35, 1.6, { icon: "FiCheckCircle", inline: true, head: "Utile", headSize: 13, bodySize: 12, fill: C.accent6, body: "Semplice, quotidiano, controllabile." });
  }
  {
    const s = content("Alternative più semplici", "L'ultimo punto del sottotema, e l'integrazione A applicata alle caratteristiche: il riconoscimento di alternative più semplici. Alcuni segnali, che sembrano indicare un'opportunità AI, indicano in realtà un'opportunità per altro. Se l'attività è completamente standardizzata, con regole chiare e senza eccezioni, un'automazione tradizionale basata su regole è probabilmente più affidabile, più economica e più verificabile dell'AI generativa, come visto nel Tema 11. Se il problema è che le informazioni sono disordinate, il primo intervento è mettere ordine, come visto nel Tema 14; l'AI potrà venire dopo. Se il problema è un passaggio organizzativo, come un'approvazione che attende giorni, la soluzione è organizzativa. Se l'attività è rara, il beneficio di automatizzarla è minimo. L'AI generativa aggiunge valore soprattutto dove c'è linguaggio naturale, variabilità dei contenuti, necessità di interpretare testi o produrre testi nuovi. Una domanda semplice da porsi: che cosa fa l'AI qui che una regola, un modulo o una migliore organizzazione non potrebbero fare?");
    stepTag(s, 0);
    table(s, [["Se...", "Probabilmente conviene..."],
      ["L'attività ha regole chiare e nessuna eccezione", "Un'automazione tradizionale"],
      ["Le informazioni sono disordinate", "Mettere prima ordine"],
      ["Il problema è un passaggio organizzativo", "Una soluzione organizzativa"],
      ["L'attività è rara", "Lasciare com'è"],
      ["Ci sono testi liberi, variabili, da interpretare o produrre", "Valutare l'AI generativa"]],
      { y: 1.15, colW: [4.8, 4.2], rowH: 0.47, accentCol: 1, fontSize: 12, blankCorner: false });
    banner(s, 4.2, "Che cosa fa l'AI qui che una regola, un modulo o una migliore organizzazione non potrebbero fare?", { h: 0.7, fontSize: 14 });
  }
  keySlide("L'opportunità più promettente non è necessariamente la più complessa o impressionante: una soluzione limitata e controllabile può generare più valore.", "Sottotema 15.3  ·  Opportunità promettenti", "Concetto chiave del terzo sottotema. I segnali di valore riguardano frequenza, impegno informativo e volumi; quelli di adattabilità riguardano standardizzazione, informazioni, verificabilità, conseguenze degli errori, giudizio. Il profilo fa discutere, non decide. Il supporto o l'automazione parziale catturano molto valore con meno rischio. La complessità non è utilità. E alcuni segnali indicano alternative più semplici. Esercizio suggerito: tracciare il profilo delle tre opportunità dello scenario, ciascuno da solo, poi confrontare in gruppo le valutazioni e discutere quelle più diverse.");
  // =====================================================================
  section("15.4 Il valore potenziale");
  divider("15.4", "Il valore potenziale", "Un beneficio potenziale deve essere rilevante per il bisogno reale, non soltanto tecnicamente interessante", "Quarto sottotema, da comprendere e applicare, e uno di quelli da approfondire. Entriamo nella valutazione. Il documento chiede di applicare a casi specifici le dimensioni del valore del Tema 12, senza riprenderne la trattazione teorica. Vediamo i benefici attesi, il ruolo di frequenza, volumi e diffusione, i costi, la differenza tra beneficio teorico e realisticamente ottenibile, la desiderabilità, e un'introduzione al rapporto tra benefici e costi. Integrazione C, per la parte di desiderabilità e valore. Business case dettagliati e ROI avanzato vanno solo accennati.");
  {
    const s = content("I benefici attesi", "Il primo passo: identificare i benefici attesi del caso d'uso. Il sottotema ne elenca diversi tipi, che riprendono le dimensioni del valore del Tema 12. Risparmio di tempo. Miglioramento della qualità. Riduzione degli errori. Incremento della capacità operativa: gestire più richieste con le stesse persone. Benefici per i clienti, come risposte più rapide, e per i collaboratori, come meno lavoro ripetitivo. Possibilità di svolgere nuove attività, che prima non si facevano. Per ciascun caso d'uso conviene chiedersi quali di questi benefici sono plausibili, e per chi. Nell'esempio delle bozze di risposta: risparmio di tempo per i commerciali; risposte più rapide per i clienti; maggiore uniformità delle risposte; forse meno errori sulle condizioni, se il sistema usa il listino aggiornato, o forse di più, se lo usa male. Notate quest'ultimo punto: un beneficio atteso può trasformarsi nel suo contrario, e va trattato come un'ipotesi. Un'avvertenza: i benefici vanno collegati al problema del 15.1. Un beneficio reale ma non rilevante per il problema, come uno stile più elegante delle risposte, ha poco peso nella valutazione.");
    stepTag(s, 2);
    await iconGrid(s, [
      { icon: "FiClock", head: "Tempo risparmiato", body: "Per i commerciali" },
      { icon: "FiAward", head: "Qualità", body: "Risposte più uniformi" },
      { icon: "FiCheckCircle", head: "Meno errori", body: "Se usa il listino aggiornato, o di più se lo usa male" },
      { icon: "FiTrendingUp", head: "Capacità operativa", body: "Più richieste con le stesse persone" },
      { icon: "FiSmile", head: "Clienti e collaboratori", body: "Risposte più rapide, meno lavoro ripetitivo" },
      { icon: "FiPlusCircle", head: "Nuove attività", body: "Che prima non si facevano" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Benefici collegati al problema del 15.1, e trattati come ipotesi. Esempi fittizi.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Frequenza, volumi, diffusione", "Il valore di un beneficio dipende dalla sua dimensione unitaria e da quante volte si ripete. È uno dei punti più concreti del sottotema: frequenza, volumi e diffusione del beneficio. Un risparmio di dieci minuti su un'attività che si fa una volta al mese vale poco; un risparmio di due minuti su un'attività che si fa sessanta volte al giorno vale molto. La diffusione conta allo stesso modo: un beneficio per una persona o per cento persone. Un calcolo di massima è spesso illuminante. Nell'esempio fittizio delle bozze: 60 richieste al giorno, un risparmio stimato di 5 minuti per richiesta, 220 giorni lavorativi: circa 1.100 ore all'anno. Ma quante delle 60 richieste sono escluse, come i prodotti personalizzati? Se sono il 30 per cento, le ore scendono a circa 770. E i 5 minuti sono un'ipotesi: se il risparmio reale fosse di 2 minuti, sarebbero circa 310. Lo stesso calcolo, con ipotesi diverse, dà valori molto diversi. È per questo che conviene sempre fare il calcolo con ipotesi esplicite, e verificare le ipotesi più incerte. Il grafico mostra i tre scenari. Numeri inventati.");
    stepTag(s, 2);
    s.addChart(pres.charts.BAR, [{ name: "Ore all'anno", labels: ["Ottimistico: 60 richieste, 5 min", "Escluse il 30%: 42 richieste, 5 min", "Prudente: 42 richieste, 2 min"], values: [1100, 770, 310] }], {
      x: 0.5, y: 1.05, w: 5.6, h: 3.35, barDir: "bar", chartColors: [HEX.a1], showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "#,##0",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 10, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
      valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 1350, valGridLine: { style: "none" }, showLegend: false,
      showTitle: true, title: "Ore risparmiate all'anno, 220 giorni (numeri inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50 });
    await card(s, 6.35, 1.15, 3.15, 1.55, { icon: "FiRepeat", inline: true, head: "Unità per volte", headSize: 13, bodySize: 12, body: "Dieci minuti al mese contro due minuti sessanta volte al giorno." });
    await card(s, 6.35, 2.85, 3.15, 1.55, { icon: "FiSliders", inline: true, head: "Ipotesi esplicite", headSize: 13, bodySize: 12, fill: C.accent6, body: "Lo stesso calcolo dà valori molto diversi." });
    banner(s, 4.5, "Fare il calcolo con ipotesi esplicite, e verificare le più incerte.", { h: 0.45, fontSize: 13 });
  }
  {
    const s = content("Teorico o ottenibile?", "La quarta domanda guida: come distinguere i benefici ipotizzati da quelli realisticamente ottenibili. Il sottotema chiede di distinguere il beneficio teorico da quello realisticamente ottenibile, e le stime dai benefici già dimostrati. Il beneficio teorico è quello che si otterrebbe se tutto funzionasse come previsto. Il beneficio ottenibile tiene conto di ciò che, nella realtà, lo riduce, e che abbiamo visto nei Temi 12 e 13. Le attività escluse e le eccezioni. Il tempo di verifica e correzione degli output. L'adozione parziale: non tutti useranno lo strumento, o non sempre. Il periodo di apprendimento iniziale. Il tempo liberato che non si traduce in valore, se non viene reinvestito. I colli di bottiglia a valle. Il waterfall in slide, con numeri inventati, mostra come un beneficio teorico di 1.100 ore possa ridursi a un beneficio ottenibile molto più modesto. Non è pessimismo: è realismo, e serve a non prendere decisioni su numeri che non si realizzeranno. Distinguere poi le stime dai benefici dimostrati: una stima, anche fatta bene, è un'ipotesi; un beneficio dimostrato è stato osservato, in un test o in un uso reale. Nelle presentazioni le due cose vengono spesso confuse.");
    stepTag(s, 2);
    const labels = ["Teorico", "Escluse", "Verifica", "Adozione", "Ottenibile"];
    const base = [0, 770, 520, 380, 0];
    const vals = [1100, 330, 250, 140, 380];
    s.addChart(pres.charts.BAR, [{ name: "base", labels, values: base }, { name: "Ore", labels, values: vals }], {
      x: 0.5, y: 1.05, w: 5.6, h: 3.4, barDir: "col", barGrouping: "stacked", chartColors: ["FFFFFF", HEX.a1],
      showValue: true, dataLabelColor: "FFFFFF", dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "#,##0;-#,##0;;",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt",
      valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 1250, valGridLine: { style: "none" }, showLegend: false,
      showTitle: true, title: "Da teorico a ottenibile, ore all'anno (numeri inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 40 });
    rowsLabel(s, [["Stima", "Un'ipotesi, anche se fatta bene"], ["Dimostrato", "Osservato in un test o in un uso reale"]], { y: 1.15, h: 0.75, lw: 1.3, x: 6.35, w: 3.15, fontSize: 11 });
    txt(s, "Anche: apprendimento iniziale, tempo non reinvestito, colli di bottiglia", { x: 6.35, y: 2.95, w: 3.15, h: 0.9, fontSize: 11, italic: true, color: C.text2 });
    banner(s, 4.55, "Non pessimismo, realismo: non decidere su numeri che non si realizzeranno.", { h: 0.42, fontSize: 13 });
  }
  {
    const s = content("I costi da considerare", "Il valore non è solo beneficio: il sottotema chiede di considerare costi e risorse necessari. Senza entrare in un business case, che il documento chiede solo di accennare, è utile avere presenti le principali categorie di costo, perché alcune vengono sistematicamente dimenticate. Le licenze e l'uso degli strumenti: abbonamenti, costi per utilizzo, che possono crescere con i volumi. La preparazione: configurazione, integrazione con i sistemi, preparazione delle informazioni, che come visto nel Tema 14 è spesso il lavoro principale. Il tempo delle persone: chi partecipa alla definizione, alla prova, alla verifica, e il tempo per imparare a usare lo strumento. La gestione nel tempo: manutenzione, aggiornamento delle fonti, monitoraggio della qualità, gestione dei problemi. Il lavoro nuovo creato: verifica degli output, gestione delle eccezioni, come visto nel Tema 13. E i costi dei rischi: gli errori che sfuggono, con le loro conseguenze. Molte valutazioni considerano solo la prima categoria, la licenza, e sottostimano tutte le altre. Il risultato è un rapporto tra benefici e costi apparentemente ottimo, che non regge alla prova.");
    stepTag(s, 2);
    rowsLabel(s, [["Licenze e uso", "Abbonamenti, costi per utilizzo che crescono con i volumi"], ["Preparazione", "Configurazione, integrazioni, informazioni"], ["Tempo delle persone", "Definizione, prova, verifica, apprendimento"], ["Gestione nel tempo", "Manutenzione, fonti, monitoraggio, problemi"], ["Lavoro nuovo", "Verifica degli output, eccezioni"], ["Costo dei rischi", "Errori che sfuggono, e le loro conseguenze"]], { y: 1.12, h: 0.45, lw: 2.3 });
    banner(s, 4.4, "Spesso si conta solo la licenza: un rapporto apparentemente ottimo che non regge.", { h: 0.55, fontSize: 14 });
  }
  {
    const s = content("Desiderabilità", "Il sottotema introduce la desiderabilità del risultato per utenti e organizzazione, e con essa l'integrazione C: distinguere desiderabilità, fattibilità e sostenibilità. Le tre parole vengono dal design thinking, un approccio alla progettazione reso noto da IDEO e da altri a partire dagli anni Duemila, che considera promettenti le soluzioni all'incrocio di tre condizioni: desiderabili per le persone, fattibili tecnicamente, sostenibili economicamente. Il documento di perimetro aggiunge una quarta dimensione, l'accettabilità dei rischi, che vedremo nel 15.6. La desiderabilità chiede: le persone vogliono davvero questo risultato? I commerciali vogliono bozze automatiche, o preferiscono scrivere a modo loro? I clienti preferiscono una risposta rapida e standard o una più lenta ma personalizzata? La direzione considera prioritario questo problema? Un caso d'uso tecnicamente valido ma non desiderato viene ignorato, aggirato, o usato male. La desiderabilità non si deduce: si chiede, si osserva, si verifica. E va chiesta a chi userà lo strumento e a chi ne riceverà i risultati, non solo a chi lo propone. Le tre dimensioni sono distinte: ciascuna può essere alta mentre le altre sono basse.");
    stepTag(s, 2);
    const d = [["Desiderabilità", "Le persone vogliono davvero questo risultato?", "15.4", C.accent1, C.background1], ["Fattibilità", "Si può realizzare, qui, con ciò che abbiamo?", "15.5", C.background2, C.text1], ["Sostenibilità", "Regge economicamente e nel tempo?", "15.5", C.background2, C.text1], ["Rischi accettabili", "Sono controllabili?", "15.6", C.accent6, C.text1]];
    d.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 1.75, e[3], e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.22, w: 1.91, h: 0.4, fontSize: 14, bold: true, color: e[4] });
      txt(s, e[1], { x: x + 0.12, y: 1.65, w: 1.91, h: 0.85, fontSize: 12, color: e[4] });
      txt(s, e[2], { x: x + 0.12, y: 2.5, w: 1.91, h: 0.3, fontSize: 11, bold: true, color: i === 0 ? C.accent6 : C.accent1 });
    });
    rowsLabel(s, [["Ai commerciali", "Vogliono bozze automatiche, o scrivere a modo loro?"], ["Ai clienti", "Risposta rapida e standard, o lenta ma personalizzata?"], ["Alla direzione", "È un problema prioritario?"]], { y: 3.05, h: 0.42, lw: 1.9 });
    txt(s, "Da design thinking (IDEO), più l'accettabilità dei rischi. La desiderabilità non si deduce: si chiede e si osserva.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 11, italic: true, color: C.accent5 });
  }
  {
    const s = content("Benefici e costi, in sintesi", "L'ultimo punto del sottotema: un'introduzione al rapporto tra benefici e costi. Il documento chiede di accennarvi, senza entrare nel ROI e nei business case dettagliati, che richiedono competenze specifiche. Il ragionamento di base è semplice: un caso d'uso vale la pena se i benefici ottenibili superano i costi complessivi, in un orizzonte di tempo ragionevole, e con un margine che tenga conto dell'incertezza. Tre avvertenze pratiche. Confrontare grandezze omogenee: benefici e costi annuali, o sull'intero periodo; benefici realistici, non teorici; costi completi, non solo la licenza. Considerare l'incertezza: se il caso d'uso conviene solo con le ipotesi più ottimistiche, è fragile; se conviene anche con quelle prudenti, è robusto. Ricordare i benefici non monetizzabili, come la soddisfazione dei clienti o la riduzione del carico di lavoro, senza però usarli per giustificare qualsiasi cosa. E infine, la consapevolezza del sottotema: un beneficio potenziale deve essere rilevante per il bisogno reale, non soltanto tecnicamente interessante. Il rapporto tra benefici e costi va calcolato sul problema di partenza.");
    stepTag(s, 2);
    numList(s, ["Grandezze omogenee: benefici realistici e costi completi, sullo stesso periodo", "Incertezza: conviene anche con le ipotesi prudenti? Allora è robusto", "Benefici non monetizzabili: contano, ma non giustificano tutto", "Rilevanza: sul problema di partenza, non sull'interesse tecnico"], { y: 1.15, h: 0.62, fontSize: 13 });
    banner(s, 3.95, "Business case dettagliati e ROI avanzato richiedono competenze specifiche: qui basta il ragionamento di base.", { h: 0.85, fontSize: 14 });
  }
  keySlide("Un beneficio potenziale conta se è rilevante per il bisogno reale, realisticamente ottenibile, e superiore ai costi completi, anche con ipotesi prudenti.", "Sottotema 15.4  ·  Il valore potenziale", "Concetto chiave del quarto sottotema. I benefici attesi vanno collegati al problema e trattati come ipotesi. Frequenza, volumi e diffusione moltiplicano il beneficio unitario. Il beneficio teorico si riduce per esclusioni, verifica, adozione parziale. Le stime non sono benefici dimostrati. I costi sono più della licenza. La desiderabilità si chiede, non si deduce, ed è distinta da fattibilità e sostenibilità. Esercizio suggerito: per l'idea scritta all'inizio, fare un calcolo di massima del beneficio con tre scenari, ottimistico, intermedio e prudente, rendendo esplicita ogni ipotesi.");

  // =====================================================================
  section("15.5 Fattibilità");
  divider("15.5", "Fattibilità tecnica e organizzativa", "Fattibilità tecnica, adozione organizzativa e sostenibilità economica non coincidono", "Quinto sottotema, da comprendere. Il caso d'uso è promettente e potenzialmente utile: si può realizzare, qui, con ciò che abbiamo? Il documento sottolinea il confine con il 15.3: un'attività astrattamente adatta all'AI può non essere realizzabile nel contesto specifico. Vediamo strumenti e capacità, dati e integrazioni, compatibilità con i processi, competenze, dipendenza dai fornitori, complessità di realizzazione e manutenzione, fattibilità tecnica e organizzativa, prototipo e uso operativo, sostenibilità nel tempo. Integrazioni A e C. Usiamo i criteri del Tema 14 senza ripetere l'analisi del patrimonio informativo.");
  {
    const s = content("Le domande della fattibilità", "La quinta domanda guida: quali dati, competenze, strumenti e integrazioni sono necessari? Il sottotema la articola in una serie di domande, che raggruppiamo in sei aree. Strumenti e capacità: esistono strumenti AI adatti, e le loro capacità sono adeguate al compito, con un livello di qualità sufficiente? Dati e informazioni: le informazioni necessarie sono disponibili, accessibili, di qualità sufficiente? Sono le quattro condizioni del Tema 14. Integrazioni: serve collegare il sistema ad applicazioni esistenti, e quanto è complesso? Processi: il caso d'uso è compatibile con il modo in cui si lavora, o richiede di cambiarlo? Competenze e risorse: ci sono le persone e il tempo per realizzarlo e gestirlo? Dipendenze: da quali fornitori e piattaforme dipenderà? Per ogni area, la risposta può essere: sì, no, o non lo sappiamo. Le risposte 'non lo sappiamo' sono le più importanti: sono ipotesi da verificare, e vanno ad aggiungersi a quelle identificate nel 15.2.");
    stepTag(s, 2);
    await iconGrid(s, [
      { icon: "FiCpu", head: "Strumenti e capacità", body: "Esistono strumenti adatti, con qualità sufficiente?" },
      { icon: "FiDatabase", head: "Dati e informazioni", body: "Disponibili, accessibili, utilizzabili, affidabili?" },
      { icon: "FiLink", head: "Integrazioni", body: "Con quali applicazioni, con quale complessità?" },
      { icon: "FiGitBranch", head: "Processi", body: "Compatibile con il modo di lavorare?" },
      { icon: "FiUsers", head: "Competenze e risorse", body: "Persone e tempo per realizzare e gestire?" },
      { icon: "FiPackage", head: "Dipendenze", body: "Da quali fornitori e piattaforme?" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Sì, no, o non lo sappiamo. I 'non lo sappiamo' sono ipotesi da verificare.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Dati e integrazioni", "Due aree della fattibilità meritano un approfondimento, perché sono spesso decisive e sottostimate: l'accessibilità e la qualità dei dati, e le integrazioni con i sistemi esistenti. Il documento chiede di usare qui i criteri del Tema 14 senza ripeterne l'analisi. Per i dati: le informazioni necessarie esistono? Sono accessibili al sistema, con i permessi corretti? Sono organizzate e utilizzabili? Sono affidabili e aggiornate? Nell'esempio delle bozze: il listino in vigore è in un unico posto, aggiornato, o ce ne sono più versioni? Lo storico del cliente nel CRM è completo? Per le integrazioni: il caso d'uso si può realizzare con strumenti che lavorano su informazioni fornite dall'utente, o richiede un collegamento con le applicazioni? Se lo richiede, le applicazioni lo permettono, e chi lo realizza? Un'indicazione pratica che deriva da questo: a parità di valore, un caso d'uso che funziona con le informazioni già disponibili e senza integrazioni complesse è molto più fattibile. E se la fattibilità dipende da un intervento sui dati, quell'intervento va considerato parte del progetto, con i suoi costi e tempi.");
    stepTag(s, 2);
    await twoPanel(s, "Dati", bullets(["Esistono, sono accessibili con i permessi giusti?", "Organizzati, affidabili, aggiornati?", "Il listino è uno solo, aggiornato?"], { space: 5 }), "Integrazioni", bullets(["Bastano informazioni fornite dall'utente?", "Serve collegare applicazioni? Lo permettono?", "Chi lo realizza, e lo mantiene?"], { space: 5 }), { y: 1.15, h: 2.5, li: "FiDatabase", ri: "FiLink" });
    banner(s, 3.85, "A parità di valore, conta molto funzionare con ciò che c'è. E l'intervento sui dati fa parte del progetto, con costi e tempi.", { h: 1.0, fontSize: 14 });
  }
  {
    const s = content("Tecnica, organizzativa, economica", "La consapevolezza del sottotema, e l'integrazione C nella sua parte sulla fattibilità: fattibilità tecnica, adozione organizzativa e sostenibilità economica non coincidono. Tre domande diverse. La fattibilità tecnica: il sistema può funzionare? Le capacità dell'AI sono sufficienti, le informazioni ci sono, le integrazioni si possono fare. La fattibilità organizzativa: il sistema verrà usato, e bene? Le persone lo accettano, i processi si adattano, le responsabilità sono chiare, la supervisione è possibile, ci sono le competenze. La sostenibilità economica e operativa: il sistema regge nel tempo? I costi di uso e di gestione sono sostenibili, la manutenzione è assicurata, la dipendenza dai fornitori è accettabile. Un caso d'uso può essere fattibile tecnicamente e non organizzativamente: lo strumento funziona, ma nessuno lo usa. Può essere fattibile tecnicamente e organizzativamente ma non sostenibile: funziona e viene usato, ma i costi crescono più dei benefici, o nessuno lo mantiene. Distinguere le tre domande aiuta a non dichiarare fattibile un caso d'uso solo perché una dimostrazione tecnica ha funzionato.");
    stepTag(s, 2);
    const t = [["FiCpu", "Tecnica", "Può funzionare?", "Capacità, informazioni, integrazioni"], ["FiUsers", "Organizzativa", "Verrà usato, e bene?", "Accettazione, processi, responsabilità, supervisione, competenze"], ["FiDollarSign", "Economica e operativa", "Regge nel tempo?", "Costi di uso e gestione, manutenzione, dipendenze"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.5, i === 1 ? C.accent6 : C.background2, t[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.66, t[i][0]);
      txt(s, t[i][1], { x: x + 0.15, y: 1.98, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, t[i][2], { x: x + 0.15, y: 2.38, w: 2.56, h: 0.35, fontSize: 13, bold: true, color: C.accent1, align: "center" });
      txt(s, t[i][3], { x: x + 0.15, y: 2.78, w: 2.56, h: 0.8, fontSize: 11, color: C.text2, align: "center" });
    }
    banner(s, 3.85, "Funziona ma nessuno lo usa; funziona e lo usano ma non regge. Una dimostrazione tecnica non basta.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Fornitori e manutenzione", "Due aspetti della fattibilità che si vedono soprattutto nel tempo: la dipendenza da fornitori e piattaforme, e la complessità di realizzazione e manutenzione. La dipendenza: un caso d'uso costruito su una piattaforma specifica dipende dalle sue scelte. Il fornitore può cambiare i prezzi, modificare il comportamento del modello con un aggiornamento, ritirare una funzione, cambiare le condizioni d'uso dei dati. Nel Tema 4 abbiamo visto quanto l'ecosistema sia in rapido movimento. Non si tratta di evitare ogni dipendenza, che è impossibile, ma di conoscerla e di chiedersi: che cosa succederebbe se dovessimo cambiare strumento? Quanto lavoro andrebbe rifatto? La complessità di realizzazione e manutenzione: un caso d'uso semplice, che usa uno strumento standard con istruzioni e fonti, si realizza in poco tempo e si mantiene facilmente. Un caso d'uso che richiede sviluppo, integrazioni e configurazioni complesse richiede competenze specifiche, tempi lunghi, e una manutenzione continua, perché ogni cambiamento, nei sistemi collegati, nei dati, nel modello, può richiedere interventi. La complessità è un costo, e va pesata contro il valore.");
    stepTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 2.65, { icon: "FiPackage", head: "Dipendenza da fornitori", headSize: 14, bodySize: 12, body: bullets(["Prezzi, aggiornamenti del modello, funzioni ritirate, condizioni sui dati", "Un ecosistema in rapido movimento", "Che cosa succederebbe se dovessimo cambiare?"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.65, { icon: "FiTool", head: "Realizzazione e manutenzione", headSize: 14, bodySize: 12, fill: C.accent6, body: bullets(["Semplice: strumento standard, istruzioni, fonti", "Complessa: sviluppo, integrazioni, configurazioni", "Ogni cambiamento può richiedere interventi"], { space: 4 }) });
    banner(s, 4.0, "Non evitare ogni dipendenza, ma conoscerla. La complessità è un costo da pesare contro il valore.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Prototipo e uso operativo", "Il sottotema chiede di distinguere il prototipo dall'uso operativo, e di considerare la sostenibilità nel tempo. È la stessa distinzione vista nel Tema 14 per i sistemi documentali, applicata a qualsiasi caso d'uso. Un prototipo dimostra che qualcosa può funzionare, in condizioni favorevoli: pochi casi scelti, utenti motivati, dati preparati, nessuna integrazione reale, attenzione costante. L'uso operativo richiede che funzioni ogni giorno, in condizioni normali: tutti i casi, comprese le eccezioni; tutti gli utenti, anche i meno interessati; i dati come sono davvero; le integrazioni reali; nessuna attenzione speciale. Il passaggio dall'uno all'altro è spesso dove i progetti si fermano, e dove i costi crescono. La sostenibilità nel tempo aggiunge una domanda: chi se ne occuperà tra un anno? Chi aggiorna le fonti, chi controlla la qualità, chi gestisce i problemi, chi decide i cambiamenti? Un caso d'uso senza una risposta a queste domande non è fattibile, anche se il prototipo funziona. Il documento ricorda il confine con il Tema 16: qui il prototipo serve a verificare un'ipotesi, non a gestire l'intero progetto di adozione.");
    stepTag(s, 2);
    table(s, [["", "Prototipo", "Uso operativo"],
      ["Casi", "Pochi, scelti", "Tutti, comprese le eccezioni"],
      ["Utenti", "Motivati", "Tutti, anche i meno interessati"],
      ["Dati", "Preparati", "Come sono davvero"],
      ["Integrazioni", "Simulate o assenti", "Reali"],
      ["Attenzione", "Costante", "Nessuna attenzione speciale"]],
      { y: 1.15, colW: [1.8, 3.4, 3.8], rowH: 0.45, accentCol: 2, fontSize: 12 });
    banner(s, 4.0, "Chi se ne occuperà tra un anno? Senza risposta, non è fattibile, anche se il prototipo funziona.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Alternative tecnologiche", "L'ultimo punto del sottotema, e l'integrazione A applicata alla fattibilità: il confronto con alternative tecnologiche più semplici. Nel 15.1 abbiamo confrontato l'AI con alternative non tecnologiche, come cambiare l'organizzazione. Qui il confronto è tra soluzioni tecnologiche di complessità diversa, per lo stesso caso d'uso. Nell'esempio delle bozze di risposta, si possono immaginare almeno quattro soluzioni, in ordine di complessità crescente. Modelli di risposta predefiniti, che il commerciale personalizza: nessuna AI. Uno strumento AI generico, a cui il commerciale incolla la richiesta e il listino: nessuna integrazione. Un assistente configurato con istruzioni e fonti, come il listino e le condizioni standard: integrazione leggera. Un sistema integrato con il CRM e la posta, che prepara automaticamente la bozza nel flusso di lavoro: integrazione completa. Ogni livello aggiunge valore potenziale, ma anche costi, tempi e rischi. Spesso conviene partire da un livello basso, verificare le ipotesi, e salire solo se il valore lo giustifica. Esempi fittizi.");
    stepTag(s, 2);
    const lv = [["Modelli di risposta", "Il commerciale personalizza", "Nessuna AI"], ["Strumento AI generico", "Si incollano richiesta e listino", "Nessuna integrazione"], ["Assistente configurato", "Istruzioni e fonti: listino, condizioni", "Integrazione leggera"], ["Sistema integrato", "Bozza automatica nel CRM e nella posta", "Integrazione completa"]];
    lv.forEach((e, i) => {
      const x = 0.5 + i * 2.3, y = 1.15 + (3 - i) * 0.4;
      shapeBox(s, x, y, 2.15, 2.75 - (3 - i) * 0.4, i === 3 ? C.accent1 : (i ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: x + 0.12, y: y + 0.08, w: 1.91, h: 0.55, fontSize: 13, bold: true, color: i === 3 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: y + 0.65, w: 1.91, h: 0.6, fontSize: 11, color: i === 3 ? C.background1 : C.text1 });
      txt(s, e[2], { x: x + 0.12, y: y + 1.25, w: 1.91, h: 0.35, fontSize: 11, bold: true, color: i === 3 ? C.accent6 : C.text2 });
    });
    txt(s, "Complessità, costi, tempi e rischi crescenti  ›", { x: 0.5, y: 3.95, w: 9, h: 0.3, fontSize: 11, bold: true, color: C.accent5, align: "right" });
    banner(s, 4.35, "Partire basso, verificare le ipotesi, salire solo se il valore lo giustifica. Esempi fittizi.", { h: 0.6, fontSize: 14 });
  }
  keySlide("Fattibilità tecnica, adozione organizzativa e sostenibilità economica non coincidono: una dimostrazione che funziona non basta.", "Sottotema 15.5  ·  Fattibilità tecnica e organizzativa", "Concetto chiave del quinto sottotema. La fattibilità riguarda strumenti, dati, integrazioni, processi, competenze e dipendenze; i 'non lo sappiamo' sono ipotesi da verificare. Dati e integrazioni sono spesso decisivi. Tecnica, organizzativa ed economica sono tre domande diverse. Dipendenze e manutenzione si vedono nel tempo. Prototipo e uso operativo sono distanti. E per lo stesso caso d'uso esistono soluzioni di complessità diversa, da cui conviene partire dal basso. Esercizio suggerito: per l'idea scritta all'inizio, rispondere sì, no o non lo sappiamo alle domande delle sei aree, e descrivere la soluzione più semplice che potrebbe funzionare.");

  // =====================================================================
  section("15.6 Rischi e controlli");
  divider("15.6", "Rischi e condizioni di controllo", "Alcuni rischi o vincoli sono condizioni di esclusione: un alto beneficio stimato non li rende accettabili", "Sesto sottotema, a livello di consapevolezza critica. Il documento distingue: il 15.5 riguarda la possibilità di realizzazione, il 15.6 la controllabilità e l'accettabilità. Vediamo gli errori dell'AI e le loro conseguenze, i dati, le informazioni riservate, gli impatti su clienti e persone, la verifica, la supervisione e la correzione, la reversibilità, il rischio intrinseco e residuo, e le condizioni di esclusione. Riprendiamo dai temi precedenti ciò che serve per valutare un caso d'uso, senza trasformare il tema in un approfondimento normativo, che è dei Temi 17 e 18.");
  {
    const s = content("Che cosa può andare storto", "La sesta domanda guida: quali rischi possono rendere un caso d'uso inappropriato, anche se promettente? Il sottotema elenca le principali categorie di rischio da considerare, che riprendono quanto visto nei temi precedenti, applicato a un caso d'uso. I possibili errori dell'AI e le loro conseguenze operative: allucinazioni, omissioni, interpretazioni sbagliate, come nei Temi 3 e 7. Le criticità dei dati usati: informazioni errate, superate, incomplete, come nel Tema 14. L'esposizione di informazioni riservate: verso persone non autorizzate o verso l'esterno, per esempio verso un fornitore. Gli impatti sui clienti e sulle persone: una risposta sbagliata a un cliente, una decisione che riguarda un dipendente presa su basi errate, un trattamento non equo. La difficoltà di verificare i risultati: quando non si riesce a capire se l'output è corretto, il rischio cresce. Per ciascun caso d'uso conviene chiedersi, per ogni categoria: che cosa potrebbe succedere? Con quale probabilità? Con quali conseguenze? Chi ne sarebbe colpito?");
    stepTag(s, 2);
    await iconGrid(s, [
      { icon: "FiAlertTriangle", head: "Errori dell'AI", body: "Allucinazioni, omissioni, interpretazioni" },
      { icon: "FiDatabase", head: "Criticità dei dati", body: "Errati, superati, incompleti" },
      { icon: "FiLock", head: "Informazioni riservate", body: "Esposte a non autorizzati o all'esterno" },
      { icon: "FiUsers", head: "Impatti su clienti e persone", body: "Risposte sbagliate, decisioni errate, trattamenti non equi" },
      { icon: "FiEyeOff", head: "Verifica difficile", body: "Se non si capisce se è corretto, il rischio cresce" },
      { icon: "FiHelpCircle", head: "Le domande", body: "Che cosa? Quanto probabile? Quali conseguenze? Per chi?" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Per ogni categoria: che cosa, con quale probabilità, con quali conseguenze, per chi.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Supervisione e reversibilità", "Il sottotema chiede di considerare la necessità di supervisione, la possibilità di intervento e correzione, e la distinzione tra azioni reversibili e irreversibili. Sono i fattori che determinano quanto un rischio è controllabile, e li abbiamo visti nel Tema 11 per gli agenti. Applicati alla valutazione di un caso d'uso, diventano domande. Chi controlla l'output, e quando? Prima che produca effetti, o dopo? Il controllo è realistico, rispetto ai volumi e al tempo disponibile? Se c'è un errore, ci si accorge? Si può correggere, e quanto costa farlo? L'azione è reversibile: una bozza non inviata si corregge senza conseguenze; un'email inviata a un cliente, un ordine registrato, un'offerta con un prezzo sbagliato no, o solo in parte. Riprendiamo le tre opportunità dello scenario. La sintesi delle richieste: supervisione naturale, perché il commerciale lavora sulla richiesta; errori correggibili; nessuna azione verso l'esterno. Le bozze di risposta: supervisione prima dell'invio, errori correggibili se la revisione è attenta. La gestione autonoma delle trattative: azioni verso il cliente, in parte irreversibili, supervisione difficile. Valutazioni illustrative.");
    stepTag(s, 2);
    table(s, [["Opportunità (illustrativa)", "Supervisione", "Correzione", "Reversibilità"],
      ["Sintesi delle richieste", "Naturale: si lavora sulla richiesta", "Facile", "Nessuna azione esterna"],
      ["Bozze di risposta", "Prima dell'invio", "Facile, se la revisione è attenta", "Reversibile fino all'invio"],
      ["Trattative autonome", "Difficile, a posteriori", "Costosa", "Azioni verso il cliente, in parte irreversibili"]],
      { y: 1.15, colW: [2.4, 2.3, 2.1, 2.2], rowH: 0.62, accentCol: 3, fontSize: 12, blankCorner: false });
    banner(s, 3.85, "Chi controlla, prima o dopo gli effetti? Il controllo è realistico rispetto ai volumi? Se c'è un errore, ci si accorge?", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Intrinseco e residuo", "Una distinzione del sottotema utile per ragionare con precisione: rischio intrinseco e rischio residuo dopo i controlli. Il rischio intrinseco è quello del caso d'uso in sé, senza misure di controllo: che cosa può succedere se l'AI sbaglia e nessuno se ne accorge. Il rischio residuo è quello che rimane dopo aver introdotto i controlli: la revisione umana, i limiti all'uso, le regole sui permessi, le verifiche periodiche. Nell'esempio delle bozze, il rischio intrinseco di inviare condizioni sbagliate a un cliente è significativo; con la revisione obbligatoria prima dell'invio, l'esclusione dei casi particolari e l'uso del solo listino ufficiale, il rischio residuo si riduce. Due avvertenze. I controlli funzionano solo se sono realistici: una revisione obbligatoria che, sotto pressione, diventa un clic di approvazione senza lettura non riduce il rischio, come visto nel Tema 7 per la fiducia eccessiva. E i controlli hanno un costo, che va considerato nel valore: se per rendere accettabile il rischio serve rivedere ogni bozza con la stessa attenzione che servirebbe a scriverla, il beneficio si riduce molto. Il grafico illustra, con valori ipotetici, la riduzione da intrinseco a residuo.");
    stepTag(s, 2);
    s.addChart(pres.charts.BAR, [{ name: "Rischio", labels: ["Intrinseco", "Con revisione prima dell'invio", "Più esclusione dei casi particolari", "Più solo listino ufficiale", "Revisione solo formale"], values: [9, 5, 3.5, 2.5, 7] }], {
      x: 0.5, y: 1.05, w: 5.6, h: 3.4, barDir: "bar", chartColors: [HEX.a1], showValue: false,
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 10, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
      valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 10, valGridLine: { style: "none" }, showLegend: false,
      showTitle: true, title: "Rischio di condizioni errate al cliente (valori ipotetici)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 45 });
    await card(s, 6.35, 1.15, 3.15, 1.55, { icon: "FiCheckSquare", inline: true, head: "Controlli realistici", headSize: 13, bodySize: 12, body: "Una revisione ridotta a un clic non riduce il rischio." });
    await card(s, 6.35, 2.85, 3.15, 1.6, { icon: "FiDollarSign", inline: true, head: "Controlli con un costo", headSize: 13, bodySize: 12, fill: C.accent6, body: "Rivedere quanto riscrivere annulla il beneficio." });
    banner(s, 4.55, "Valutare il rischio residuo, con controlli che funzionano davvero, e il loro costo.", { h: 0.42, fontSize: 13 });
  }
  {
    const s = content("Condizioni di esclusione", "Il punto più importante del sottotema, e la seconda precisazione del tema: alcuni rischi o vincoli costituiscono condizioni di esclusione. Requisiti legali, di sicurezza e di controllo non possono essere compensati automaticamente da punteggi elevati sul valore potenziale. Che cosa significa? Che nella valutazione ci sono due tipi di criteri. Quelli compensabili: un valore più basso può essere compensato da una fattibilità più alta, un costo più alto da un beneficio maggiore. E quelli non compensabili, o di soglia: se non sono soddisfatti, il caso d'uso non è accettabile, qualunque sia il beneficio. Esempi di condizioni di esclusione: il caso d'uso richiede di trattare dati in modo non consentito dalle regole o dalla normativa; espone informazioni riservate senza possibilità di controllo; produce decisioni con effetti significativi sulle persone senza possibilità di supervisione e contestazione; compie azioni irreversibili ad alto impatto senza controllo umano; non permette di verificare i risultati in un ambito in cui l'errore è grave. Gli aspetti giuridici sono dei Temi 17 e 18: qui basta sapere che queste condizioni esistono e vanno verificate prima, non dopo, aver calcolato il valore.");
    stepTag(s, 2);
    docBox(s, 0.5, 1.15, 4.35, 1.25, "Criteri compensabili", "Un valore più basso compensato da una fattibilità più alta; un costo più alto da un beneficio maggiore.", { fontSize: 12 });
    docBox(s, 5.15, 1.15, 4.35, 1.25, "Criteri di soglia", "Se non soddisfatti, il caso non è accettabile, qualunque sia il beneficio.", { fontSize: 12, fill: C.accent6, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Esempi di condizioni di esclusione", { x: 0.5, y: 2.5, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    rowList(s, ["Trattamento di dati non consentito da regole o normativa", "Informazioni riservate esposte senza controllo", "Decisioni con effetti significativi sulle persone, senza supervisione né contestazione", "Azioni irreversibili ad alto impatto senza controllo umano"], { y: 2.88, h: 0.38, gap: 0.05, fontSize: 12 });
    txt(s, "Da verificare prima, non dopo, aver calcolato il valore.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Escludere o riprogettare", "L'ultimo punto del sottotema: le situazioni in cui un'opportunità deve essere esclusa o riprogettata. Davanti a un rischio non accettabile, le strade sono due. Escludere: il caso d'uso, così com'è e nel contesto attuale, non va perseguito. È una decisione legittima e spesso saggia, anche se il valore potenziale era alto. Riprogettare: modificare il caso d'uso per riportare il rischio sotto la soglia. Ridurre l'autonomia dell'AI, passando dall'azione alla proposta. Restringere il perimetro, escludendo i casi più rischiosi. Aggiungere controlli realistici. Limitare le informazioni a cui il sistema accede. Spesso la riprogettazione porta a un caso d'uso più modesto, ma accettabile e ancora utile. È quello che accade, nello scenario del modulo, con la gestione autonoma delle trattative: riprogettata, potrebbe diventare un assistente che prepara proposte di risposta per le trattative, che il commerciale valuta e decide se inviare. Cioè qualcosa di molto simile alle bozze di risposta. Molti casi d'uso spettacolari, riprogettati per essere controllabili, diventano casi d'uso più semplici: è l'integrazione B vista dal lato dei rischi.");
    stepTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 2.6, { icon: "FiXCircle", head: "Escludere", headSize: 15, bodySize: 12, body: "Così com'è e nel contesto attuale, non va perseguito.\n\nUna decisione legittima e spesso saggia, anche con valore potenziale alto." });
    await card(s, 5.15, 1.15, 4.35, 2.6, { icon: "FiRefreshCw", head: "Riprogettare", headSize: 15, bodySize: 12, fill: C.accent6, body: bullets(["Meno autonomia: dall'azione alla proposta", "Perimetro più ristretto", "Controlli realistici", "Meno informazioni accessibili"], { space: 4 }) });
    shapeBox(s, 0.5, 3.95, 9.0, 0.9, C.background2, "esempio riprogettazione");
    txt(s, [{ text: "Trattative autonome, riprogettate: ", options: { bold: true, color: C.accent1 } }, { text: "proposte di risposta che il commerciale valuta e decide se inviare. Cioè quasi le bozze di risposta. Il caso spettacolare, reso controllabile, diventa semplice.", options: { color: C.text1 } }], { x: 0.7, y: 3.95, w: 8.6, h: 0.9, fontSize: 12, valign: "middle" });
  }
  keySlide("Alcuni rischi e vincoli sono condizioni di esclusione: un alto beneficio stimato non li rende automaticamente accettabili.", "Sottotema 15.6  ·  Rischi e condizioni di controllo", "Concetto chiave del sesto sottotema. I rischi riguardano errori, dati, informazioni riservate, impatti sulle persone, verificabilità. Supervisione, correzione e reversibilità determinano la controllabilità. Conta il rischio residuo, con controlli realistici e il loro costo. Alcune condizioni sono di soglia, non compensabili, e vanno verificate prima del valore. Davanti a un rischio non accettabile si esclude o si riprogetta, spesso verso un caso più semplice. Esercizio suggerito: per la gestione autonoma delle trattative dello scenario, individuare le condizioni di esclusione possibili e proporre una riprogettazione che le superi, valutando quanto valore rimane.");
  // =====================================================================
  section("15.7 Confronto e priorità");
  divider("15.7", "Confronto e priorità", "Prioritizzare aiuta a decidere che cosa approfondire; non dimostra la convenienza di un investimento", "Settimo sottotema, da comprendere e sperimentare. Abbiamo più opportunità, ciascuna descritta e valutata: come confrontarle? Vediamo la differenza tra individuazione e selezione, i criteri espliciti di confronto, la matrice valore-fattibilità, quick win e opportunità strategiche, i limiti dei punteggi, e la differenza tra priorità di approfondimento e decisione di investimento. Integrazioni B e C. La gestione di portafogli progetti va solo accennata.");
  {
    const s = content("Individuare non è selezionare", "La prima distinzione del sottotema: individuazione e selezione sono attività diverse, con regole diverse. L'individuazione cerca di raccogliere molte opportunità, senza giudicarle troppo presto: è una fase aperta, in cui conviene coinvolgere molte persone, perché chi fa il lavoro vede problemi che altri non vedono. Un errore comune è scartare subito le idee che sembrano poco ambiziose, o, al contrario, inseguire solo quelle più visibili. La selezione, invece, sceglie tra le opportunità individuate quelle che meritano di essere approfondite, con criteri espliciti. È una fase chiusa, che richiede di rinunciare a qualcosa: non si possono approfondire tutte le idee, perché le risorse sono limitate. Mescolare le due fasi produce problemi in entrambe le direzioni: se si seleziona mentre si individua, si perdono idee; se non si seleziona mai, si disperdono le risorse su troppe iniziative, nessuna delle quali viene portata a termine. La settima domanda guida chiede come confrontare opportunità diverse senza attribuire eccessiva certezza ai punteggi: vediamo prima i criteri, poi gli strumenti, poi i loro limiti.");
    stepTag(s, 3);
    await twoPanel(s, "Individuare", bullets(["Fase aperta: raccogliere molte opportunità", "Coinvolgere chi fa il lavoro", "Non scartare troppo presto le idee modeste"], { space: 5 }), "Selezionare", bullets(["Fase chiusa: scegliere che cosa approfondire", "Criteri espliciti", "Rinunciare a qualcosa: le risorse sono limitate"], { space: 5 }), { y: 1.15, h: 2.5, li: "FiSearch", ri: "FiFilter" });
    banner(s, 3.85, "Selezionare mentre si individua fa perdere idee; non selezionare mai disperde le risorse.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Criteri espliciti", "Il sottotema chiede criteri di confronto espliciti, e ne elenca diversi, che riprendono il percorso del modulo. Valore potenziale, dal 15.4. Fattibilità e complessità, dal 15.5. Desiderabilità per utenti e organizzazione. Sostenibilità economica e operativa. Rischi e criticità, dal 15.6. Prontezza organizzativa: l'area interessata è pronta, ha le persone, l'interesse, il tempo? Dipendenze e prerequisiti: il caso d'uso richiede che prima sia fatto qualcos'altro, come mettere ordine nei dati o completare un'integrazione? Rendere espliciti i criteri ha un valore in sé, anche prima di usarli: costringe a dichiarare che cosa conta, permette a persone diverse di discutere sulle stesse basi, rende la scelta comprensibile a chi non ha partecipato. Il contrario, la scelta basata su impressioni o sull'entusiasmo di chi presenta meglio, è più rapido ma meno affidabile. E ricordiamo la seconda precisazione del tema: le condizioni non negoziabili, cioè le condizioni di esclusione del 15.6, vanno considerate separatamente dal punteggio. Prima si escludono i casi che non le rispettano, poi si confrontano gli altri.");
    stepTag(s, 3);
    const c = ["Valore potenziale", "Fattibilità e complessità", "Desiderabilità", "Sostenibilità", "Rischi e criticità", "Prontezza organizzativa", "Dipendenze e prerequisiti"];
    c.forEach((t, i) => chip(s, 0.5 + (i % 4) * 2.3, 1.15 + Math.floor(i / 4) * 0.75, 2.15, 0.62, t, { fill: i < 5 ? C.accent6 : C.background2, fontSize: 12 }));
    shapeBox(s, 0.5, 2.75, 9.0, 0.9, C.accent1, "prima le soglie");
    txt(s, [{ text: "Prima le soglie, poi il punteggio. ", options: { bold: true, color: C.background1 } }, { text: "Le condizioni di esclusione del 15.6 si verificano separatamente: chi non le rispetta non entra nel confronto.", options: { color: C.background1 } }], { x: 0.7, y: 2.75, w: 8.6, h: 0.9, fontSize: 13, valign: "middle" });
    banner(s, 3.85, "Criteri espliciti: dichiarare che cosa conta, discutere sulle stesse basi, rendere la scelta comprensibile.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("La matrice valore-fattibilità", "Uno strumento molto diffuso, che il sottotema chiede di introdurre: la matrice valore-fattibilità. Si collocano le opportunità su due assi: il valore potenziale, in verticale, e la fattibilità, in orizzontale. Si ottengono quattro quadranti. In alto a destra, valore alto e fattibilità alta: le opportunità da approfondire per prime, spesso chiamate quick win, vittorie rapide. In alto a sinistra, valore alto e fattibilità bassa: le opportunità strategiche, che richiedono investimenti e preparazione, come mettere ordine nei dati, ma possono valere molto. In basso a destra, valore basso e fattibilità alta: miglioramenti facili ma modesti, da considerare se costano poco. In basso a sinistra, valore basso e fattibilità bassa: da accantonare. Le tre opportunità dello scenario, con valutazioni illustrative: la sintesi delle richieste ha fattibilità alta e valore medio; le bozze di risposta valore e fattibilità medio-alti; la gestione autonoma delle trattative valore potenziale alto ma fattibilità bassa, e, ricordiamolo, problemi di rischio che andrebbero risolti prima ancora di collocarla. La dimensione dei cerchi può rappresentare un terzo criterio, come il rischio. Valutazioni illustrative.");
    stepTag(s, 3);
    const X = 0.9, Y = 1.1, W = 4.8, H = 3.4;
    shapeBox(s, X, Y, W / 2, H / 2, C.accent6, "strategiche");
    shapeBox(s, X + W / 2, Y, W / 2, H / 2, "D9ECEA", "quick win");
    shapeBox(s, X, Y + H / 2, W / 2, H / 2, C.background2, "accantonare");
    shapeBox(s, X + W / 2, Y + H / 2, W / 2, H / 2, C.background2, "facili e modeste");
    txt(s, "Strategiche", { x: X + 0.08, y: Y + 0.05, w: 2.2, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
    txt(s, "Quick win", { x: X + W / 2 + 0.08, y: Y + 0.05, w: 2.2, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
    txt(s, "Da accantonare", { x: X + 0.08, y: Y + H - 0.35, w: 2.2, h: 0.3, fontSize: 11, bold: true, color: C.text2 });
    txt(s, "Facili ma modeste", { x: X + W / 2 + 0.08, y: Y + H - 0.35, w: 2.2, h: 0.3, fontSize: 11, bold: true, color: C.text2 });
    txt(s, "Valore", { x: 0.3, y: Y + H / 2 - 0.15, w: 0.6, h: 0.3, fontSize: 11, bold: true, color: C.text1, rotate: 270, align: "center" });
    txt(s, "Fattibilità", { x: X, y: Y + H + 0.02, w: W, h: 0.28, fontSize: 11, bold: true, color: C.text1, align: "center" });
    const pts = [["Sintesi", 0.82, 0.55, 0.42], ["Bozze", 0.66, 0.7, 0.55], ["Trattative", 0.28, 0.78, 0.6]];
    pts.forEach(p => {
      const cx = X + p[1] * W, cy = Y + (1 - p[2]) * H, d = p[3];
      s.addShape(pres.shapes.OVAL, { x: cx - d / 2, y: cy - d / 2, w: d, h: d, fill: { color: p[0] === "Trattative" ? HEX.a5 : HEX.a1 }, line: { color: "FFFFFF", width: 1.5 }, objectName: "punto " + p[0] });
      txt(s, p[0], { x: cx - 0.7, y: cy + d / 2, w: 1.4, h: 0.26, fontSize: 10, bold: true, color: C.text1, align: "center" });
    });
    await card(s, 6.0, 1.15, 3.5, 1.65, { icon: "FiCircle", inline: true, head: "Un terzo criterio", headSize: 13, bodySize: 12, body: "La dimensione dei cerchi: qui, il rischio." });
    await card(s, 6.0, 2.95, 3.5, 1.55, { icon: "FiAlertTriangle", inline: true, head: "Le soglie prima", headSize: 13, bodySize: 12, fill: C.accent6, body: "Le trattative autonome hanno rischi da risolvere prima di collocarle." });
    txt(s, "Valutazioni illustrative", { x: 6.0, y: 4.6, w: 3.5, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Quick win e strategiche", "Il sottotema introduce la distinzione tra quick win e opportunità strategiche, e conviene vederne pregi e trappole. Le quick win, ad alto valore e alta fattibilità, sono attraenti per buone ragioni: producono risultati in poco tempo, costano poco, permettono di imparare, creano fiducia e competenze. Molte organizzazioni fanno bene a partire da lì. Ma hanno trappole. Possono essere troppo piccole per contare, se il valore è stato sovrastimato. Possono esaurirsi: dopo le prime, le altre opportunità sono più difficili. E possono distrarre dai problemi più importanti, che raramente sono facili. Le opportunità strategiche, ad alto valore ma bassa fattibilità, richiedono investimenti e tempo, spesso in prerequisiti come i dati, le integrazioni o le competenze. Sono più rischiose, ma possono essere quelle che cambiano davvero il modo di lavorare. Una strategia equilibrata combina le due: alcune quick win per imparare e produrre risultati, e un piccolo numero di opportunità strategiche su cui preparare le condizioni. Le decisioni su portafogli di progetti vanno oltre questo modulo: qui basta riconoscere che le due categorie hanno funzioni diverse.");
    stepTag(s, 3);
    await card(s, 0.5, 1.15, 4.35, 2.75, { icon: "FiZap", head: "Quick win", headSize: 15, bodySize: 12, body: "Pregi: risultati rapidi, costi bassi, apprendimento, fiducia.\n\nTrappole: troppo piccole, si esauriscono, distraggono dai problemi importanti." });
    await card(s, 5.15, 1.15, 4.35, 2.75, { icon: "FiFlag", head: "Strategiche", headSize: 15, bodySize: 12, fill: C.accent6, body: "Pregi: possono cambiare davvero il modo di lavorare.\n\nAttenzioni: investimenti e tempo, prerequisiti (dati, integrazioni, competenze), più rischio." });
    banner(s, 4.1, "Combinare: alcune quick win per imparare, poche strategiche su cui preparare le condizioni.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("I limiti dei punteggi", "Il punto più delicato del sottotema, e la terza precisazione del tema: una matrice di opportunità è un ausilio alla discussione, non una prova oggettiva di convenienza. Molte organizzazioni usano punteggi: ogni criterio riceve un voto da 1 a 5, i voti vengono pesati e sommati, e le opportunità vengono ordinate. Lo strumento è utile, ma ha limiti seri, che conviene conoscere. I voti sono giudizi, spesso di poche persone, con le loro preferenze. Le differenze tra un 3 e un 4 sono spesso arbitrarie. I pesi sono scelte, e cambiarli cambia la classifica. La somma tratta come compensabili criteri che forse non lo sono. E soprattutto, il risultato numerico appare preciso e oggettivo, molto più di quanto sia: un 3,7 contro un 3,5 sembra una differenza, ma è dentro il margine di incertezza dei giudizi. Il grafico mostra, con dati inventati, tre opportunità valutate con due sistemi di pesi diversi, entrambi ragionevoli: la classifica si inverte. È l'integrazione B in versione quantitativa: un sistema di pesi che premia l'ambizione tecnica favorirà le opportunità spettacolari. L'uso corretto del punteggio è come base per la discussione: dove i voti divergono, dove la classifica è sensibile ai pesi, lì serve più informazione.");
    stepTag(s, 3);
    s.addChart(pres.charts.BAR, [
      { name: "Pesi A: valore al 50%", labels: ["Sintesi", "Bozze", "Trattative"], values: [3.5, 3.7, 3.6] },
      { name: "Pesi B: rischio e fattibilità al 60%", labels: ["Sintesi", "Bozze", "Trattative"], values: [3.9, 3.6, 2.4] },
    ], { x: 0.5, y: 1.05, w: 5.4, h: 2.8, barDir: "col", barGrouping: "clustered", chartColors: [HEX.a4, HEX.a1],
      showValue: true, dataLabelColor: HEX.dk1, dataLabelFontSize: 11, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0.0", dataLabelPosition: "outEnd",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 4.5, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Punteggio pesato, due sistemi di pesi (dati inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50 });
    txt(s, bullets(["Voti: giudizi di poche persone", "3 o 4: spesso arbitrario", "Pesi: scelte che cambiano la classifica", "Somma: rende compensabile ciò che forse non lo è", "Precisione apparente: 3,7 contro 3,5"], { space: 5 }), { x: 6.15, y: 1.15, w: 3.35, h: 2.6, fontSize: 12, color: C.text1 });
    banner(s, 3.9, "Un ausilio alla discussione, non una prova. Dove i voti divergono, serve più informazione.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Approfondire o investire?", "L'ultima distinzione del sottotema, e la sua consapevolezza: la differenza tra priorità di approfondimento e decisione di investimento. Prioritizzare aiuta a decidere che cosa approfondire; non equivale a dimostrare la convenienza di un investimento. In pratica: il fatto che un'opportunità sia in cima alla lista significa che merita di essere esaminata meglio, con più informazioni e, quando serve, con una verifica, come vedremo nel 15.8. Non significa che sia stato dimostrato che conviene, né che sia pronta per essere realizzata su larga scala. Questa distinzione protegge da un errore frequente: trasformare una valutazione preliminare, fatta con stime e giudizi, in una decisione di investimento importante. La scala in slide mostra tre livelli di decisione, ciascuno con il tipo di evidenza che richiede. Decidere che cosa esplorare richiede una valutazione preliminare, come quella di questo modulo. Decidere che cosa sperimentare richiede ipotesi chiare e criteri di valutazione. Decidere che cosa realizzare su larga scala richiede evidenze dalla sperimentazione, e un business case, che va oltre questo modulo. Più la decisione è impegnativa, più forti devono essere le evidenze.");
    stepTag(s, 3);
    const lv = [["Che cosa esplorare", "Valutazione preliminare: descrizione, profilo, matrice", C.background2], ["Che cosa sperimentare", "Ipotesi chiare, criteri di successo e insuccesso (15.8)", C.accent6], ["Che cosa realizzare su larga scala", "Evidenze dalla sperimentazione, business case (oltre il modulo)", "D9ECEA"]];
    lv.forEach((e, i) => {
      const y = 1.15 + (2 - i) * 0.95, w = 5.0 + i * 2.0;
      shapeBox(s, 0.5, y, w, 0.85, e[2], e[0]);
      txt(s, e[0], { x: 0.7, y: y + 0.04, w: w - 0.4, h: 0.38, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 0.7, y: y + 0.42, w: w - 0.4, h: 0.38, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.1, "Più la decisione è impegnativa, più forti devono essere le evidenze. In cima alla lista non significa conveniente.", { h: 0.8, fontSize: 14 });
  }
  keySlide("Prioritizzare aiuta a decidere che cosa approfondire; non dimostra la convenienza di un investimento. E le condizioni non negoziabili stanno fuori dal punteggio.", "Sottotema 15.7  ·  Confronto e priorità", "Concetto chiave del settimo sottotema. Individuare e selezionare sono fasi diverse. I criteri vanno resi espliciti, e le soglie verificate prima del punteggio. La matrice valore-fattibilità distingue quick win, strategiche, facili ma modeste e da accantonare. Quick win e strategiche hanno funzioni diverse. I punteggi hanno limiti seri: sono un ausilio alla discussione. Esercizio suggerito: in piccoli gruppi, collocare le idee raccolte all'inizio sulla matrice, ciascuno da solo, poi confrontare le posizioni e discutere quelle più distanti, individuando quale informazione servirebbe per decidere.");

  // =====================================================================
  section("15.8 Dall'idea alla verifica");
  divider("15.8", "Dall'idea alla verifica", "Lo scopo di un test è imparare, non dimostrare a ogni costo che l'idea iniziale è valida", "L'ultimo sottotema, da comprendere, chiude il percorso: verificare. L'opportunità selezionata si basa su ipotesi: come trasformarle in evidenze? Vediamo la differenza tra ipotesi e risultato dimostrato, le assunzioni critiche, le ipotesi verificabili, le verifiche preliminari, i prototipi e le sperimentazioni circoscritte, i criteri di successo e di insuccesso, il confronto con la situazione iniziale, la ricerca di evidenze contrarie e la decisione finale. Integrazione D: la sperimentazione deve poter smentire l'idea iniziale. Il confine con il Tema 16: qui i prototipi servono a verificare un'ipotesi, non a gestire l'adozione.");
  {
    const s = content("Ipotesi o risultato", "La prima distinzione del sottotema: un'ipotesi non è un risultato dimostrato. Tutto ciò che abbiamo prodotto finora, descrizione, profilo, stima del valore, valutazione di fattibilità e rischi, collocazione nella matrice, è fatto di ipotesi, più o meno fondate. Sono ipotesi ragionate, ed è giusto usarle per decidere che cosa approfondire. Ma non sono evidenze. La differenza diventa importante quando le ipotesi vengono presentate come fatti: 'il sistema ridurrà i tempi del 40 per cento' invece di 'stimiamo che potrebbe ridurre i tempi, in un intervallo tra il 10 e il 40 per cento, se le bozze richiedono solo una revisione rapida'. La prima frase è più convincente, la seconda è più onesta e più utile, perché dice che cosa va verificato. Il sottotema distingue anche tre livelli: l'ipotesi, cioè ciò che crediamo; la dimostrazione tecnica, cioè che il sistema può produrre un output adeguato in alcune condizioni; e il risultato verificato, cioè che il caso d'uso produce il beneficio atteso nel lavoro reale. Li riprendiamo alla fine del sottotema. Esempi fittizi.");
    stepTag(s, 4);
    docBox(s, 0.5, 1.15, 4.35, 1.5, "Ipotesi presentata come fatto", "'Il sistema ridurrà i tempi del 40%.'", { fontSize: 14, bar: C.accent5, labelColor: C.accent5 });
    docBox(s, 5.15, 1.15, 4.35, 1.5, "Ipotesi presentata come ipotesi", "'Stimiamo tra il 10 e il 40%, se le bozze richiedono solo una revisione rapida.'", { fontSize: 14, fill: C.accent6 });
    const l = ["Ipotesi: ciò che crediamo", "Dimostrazione tecnica: l'output è adeguato, in alcune condizioni", "Risultato verificato: il beneficio c'è, nel lavoro reale"];
    l.forEach((t, i) => {
      chip(s, 0.5 + i * 3.07, 2.9, 2.86, 0.85, t, { fill: i === 2 ? C.accent1 : C.background2, color: i === 2 ? C.background1 : C.text1, fontSize: 12 });
      if (i < 2) arrow(s, 0.5 + i * 3.07 + 2.88, 3.17, 0.17);
    });
    banner(s, 3.95, "La seconda frase è meno convincente, ma più onesta e più utile: dice che cosa va verificato.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Assunzioni critiche", "Il sottotema chiede di identificare le assunzioni critiche e formulare ipotesi verificabili. Riprendiamo le ipotesi individuate nel 15.2 e nel 15.5, e chiediamoci quali sono critiche. Un modo semplice per farlo è valutare ciascuna ipotesi su due dimensioni: quanto è importante, cioè quanto cambierebbe la valutazione se fosse falsa; e quanto è incerta, cioè quanto poco ne sappiamo. Le assunzioni da verificare per prime sono quelle importanti e incerte. Un'ipotesi importante ma già nota non richiede una verifica; un'ipotesi incerta ma poco importante può aspettare. Poi bisogna rendere le ipotesi verificabili, cioè formularle in modo che un'osservazione possa confermarle o smentirle. 'Le bozze saranno utili' non è verificabile. 'Su 100 richieste reali, almeno 70 bozze richiedono meno di 3 minuti di revisione per essere inviate' è verificabile. Questo richiede di decidere in anticipo che cosa osservare e quale soglia considerare sufficiente. Nell'esempio fittizio, la tabella mostra alcune ipotesi delle bozze di risposta, con la loro importanza e incertezza.");
    stepTag(s, 4);
    table(s, [["Ipotesi (esempio fittizio)", "Importanza", "Incertezza", "Verificare?"],
      ["La scrittura è una parte rilevante del tempo", "Alta", "Media", "Sì, per prima"],
      ["Le bozze richiedono solo una revisione rapida", "Alta", "Alta", "Sì, per prima"],
      ["Il listino è aggiornato e accessibile", "Alta", "Bassa", "Controllo rapido"],
      ["I commerciali useranno le bozze", "Alta", "Alta", "Sì"],
      ["Lo stile delle bozze piacerà", "Bassa", "Alta", "Può aspettare"]],
      { y: 1.15, colW: [4.2, 1.5, 1.5, 1.8], rowH: 0.44, accentCol: 3, fontSize: 12, blankCorner: false });
    docBox(s, 0.5, 3.95, 9.0, 0.95, "Ipotesi verificabile", "Su 100 richieste reali, almeno 70 bozze richiedono meno di 3 minuti di revisione prima dell'invio.", { fontSize: 13, fill: C.accent6 });
  }
  {
    const s = content("Verifiche e sperimentazioni", "Il sottotema elenca diversi modi di verificare, dal più leggero al più impegnativo. Le verifiche preliminari di fattibilità: controlli rapidi, che spesso non richiedono nessuno strumento. Il listino è davvero in un unico posto? Quanto tempo richiede oggi scrivere una risposta, misurato su qualche giorno di lavoro? Quante richieste riguardano prodotti personalizzati? Molte ipotesi si possono verificare, o smentire, in questo modo, con pochissimo costo. I prototipi: una versione semplificata del sistema, per verificare se l'output è adeguato. Per esempio, prendere 50 richieste reali dell'ultimo mese, generare le bozze con uno strumento generico configurato con il listino, e farle valutare a due commerciali. Le sperimentazioni circoscritte: l'uso del sistema nel lavoro reale, ma in un perimetro limitato, per un periodo limitato, con alcuni utenti. Per esempio, tre commerciali per quattro settimane. È il solo modo per verificare le ipotesi sull'uso effettivo e sul beneficio nel lavoro reale. Il principio: usare la verifica più leggera che può rispondere alla domanda. La progettazione tecnica dei prototipi e la sperimentazione statistica specialistica vanno solo accennate. Esempi fittizi.");
    stepTag(s, 4);
    const v = [["FiSearch", "Verifiche preliminari", "Controlli rapidi, spesso senza strumenti", "Dov'è il listino? Quanto tempo richiede oggi una risposta?"], ["FiBox", "Prototipo", "Una versione semplificata, per l'output", "50 richieste reali dell'ultimo mese, bozze valutate da due commerciali"], ["FiUsers", "Sperimentazione circoscritta", "Nel lavoro reale, perimetro e tempi limitati", "Tre commerciali per quattro settimane"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.75, i === 2 ? C.accent6 : C.background2, v[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.62, v[i][0]);
      txt(s, v[i][1], { x: x + 0.15, y: 1.95, w: 2.56, h: 0.4, fontSize: 14, bold: true, color: C.text1, align: "center" });
      txt(s, v[i][2], { x: x + 0.15, y: 2.35, w: 2.56, h: 0.55, fontSize: 12, bold: true, color: C.accent1, align: "center" });
      txt(s, v[i][3], { x: x + 0.15, y: 2.92, w: 2.56, h: 0.9, fontSize: 11, italic: true, color: C.text2, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.35, 0.17);
    }
    banner(s, 4.1, "Usare la verifica più leggera che può rispondere alla domanda. Esempi fittizi.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Successo e insuccesso, prima", "Il cuore del sottotema, e l'integrazione D: la definizione preventiva di criteri di successo e di insuccesso. Il documento sottolinea 'e insuccesso', e la ragione è precisa. Prima di iniziare una verifica, bisogna decidere che cosa la renderà un successo, e che cosa un insuccesso. Prima, non dopo. Se i criteri vengono decisi dopo aver visto i risultati, è quasi sempre possibile trovare un modo di presentarli come positivi: 'i tempi non sono scesi, ma i commerciali sono soddisfatti'; 'la qualità non è sufficiente, ma con qualche miglioramento lo sarà'. È un meccanismo umano ben noto, che la psicologia descrive come bias di conferma: tendiamo a cercare e a valorizzare le informazioni che confermano ciò che già crediamo. Definire in anticipo i criteri, e scriverli, protegge da questo meccanismo. Un buon insieme di criteri comprende: una soglia di successo, oltre la quale si prosegue; una soglia di insuccesso, sotto la quale ci si ferma; una zona intermedia, in cui si modifica e si riprova; e i limiti da non superare, come gli errori sulle condizioni. L'esempio in slide, fittizio, mostra criteri per la sperimentazione delle bozze.");
    stepTag(s, 4);
    rowsLabel(s, [["Successo: si prosegue", "Almeno 70% delle bozze inviate con meno di 3 minuti di revisione; tempo di risposta medio sotto 1,5 giorni"], ["Zona intermedia: si modifica", "Tra 40% e 70%; tempo tra 1,5 e 2,5 giorni"], ["Insuccesso: ci si ferma", "Meno del 40%, o nessun miglioramento dei tempi"], ["Limite da non superare", "Anche un solo errore sulle condizioni inviato a un cliente"]], { y: 1.15, h: 0.62, lw: 2.6, fontSize: 12 });
    banner(s, 3.85, "Decisi prima, e scritti. Dopo, si trova quasi sempre un modo di presentare i risultati come positivi (bias di conferma). Esempio fittizio.", { h: 1.0, fontSize: 13 });
  }
  {
    const s = content("Il confronto giusto", "Il sottotema chiede di confrontare i risultati con la situazione iniziale e, quando utile, con alternative non AI. Sembra ovvio, ma è spesso trascurato. Un risultato da solo non dice molto: 'con le bozze, una risposta richiede in media 12 minuti'. È tanto o poco? Dipende da quanto richiedeva prima. Per questo serve una misura della situazione iniziale, raccolta prima della sperimentazione e con lo stesso metodo: è la baseline. Senza di essa, qualsiasi risultato può sembrare buono. Il confronto con alternative non AI è il ritorno dell'integrazione A: se la sperimentazione mostra un miglioramento, conviene chiedersi se un'alternativa più semplice, come i modelli di risposta predefiniti, avrebbe ottenuto lo stesso risultato. A volte una parte del miglioramento viene semplicemente dall'attenzione al problema: il fatto stesso di sperimentare porta le persone a lavorare meglio, un fenomeno noto in letteratura come effetto Hawthorne, anche se le interpretazioni degli studi originali sono discusse. Il grafico mostra, con dati inventati, un confronto con tre condizioni: prima, con i modelli predefiniti, con le bozze AI.");
    stepTag(s, 4);
    s.addChart(pres.charts.BAR, [{ name: "Minuti", labels: ["Prima (baseline)", "Modelli predefiniti", "Bozze AI"], values: [18, 14, 11] }], {
      x: 0.5, y: 1.05, w: 5.2, h: 3.35, barDir: "col", chartColors: [HEX.a1], showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 21, valGridLine: { style: "none" }, showLegend: false,
      showTitle: true, title: "Minuti per risposta, media (dati inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 60 });
    await card(s, 5.95, 1.15, 3.55, 1.6, { icon: "FiBarChart", inline: true, head: "La baseline", headSize: 13, bodySize: 12, body: "Misurata prima, con lo stesso metodo." });
    await card(s, 5.95, 2.9, 3.55, 1.6, { icon: "FiGitPullRequest", inline: true, head: "L'alternativa semplice", headSize: 13, bodySize: 12, fill: C.accent6, body: "Parte del miglioramento c'era anche senza AI." });
    banner(s, 4.55, "Il valore dell'AI è la differenza con l'alternativa, non con il nulla. Attenzione all'effetto dell'attenzione stessa.", { h: 0.42, fontSize: 12 });
  }
  {
    const s = content("Cercare le evidenze contrarie", "Il sottotema chiede di raccogliere evidenze, valutare risultati e limiti, e cercare evidenze contrarie alle ipotesi. Quest'ultimo punto è l'integrazione D nella sua forma più esigente. È naturale, durante una sperimentazione, guardare soprattutto ai segnali positivi: i casi in cui le bozze erano ottime, i commenti entusiasti. Il sottotema chiede di fare il contrario: cercare attivamente ciò che potrebbe smentire l'idea. In quali casi le bozze erano sbagliate, e quanto? Chi non le ha usate, e perché? Che cosa è peggiorato, anche se non era nei criteri? Quali errori sono sfuggiti alla revisione? I risultati valgono anche per i commerciali che non hanno partecipato, o per i periodi di maggior carico? È un atteggiamento scientifico, che il filosofo Karl Popper ha formulato in termini generali: una teoria è scientifica se può essere smentita dai fatti, e la si mette alla prova cercando di smentirla, non di confermarla. Applicato a un caso d'uso significa: progettare la verifica in modo che possa dare esito negativo, e prestare attenzione ai segnali contrari quanto a quelli favorevoli. È anche una questione di cultura: le persone devono potersi sentire libere di dire che qualcosa non funziona.");
    stepTag(s, 4);
    qGrid(s, ["In quali casi le bozze erano sbagliate, e quanto?", "Chi non le ha usate, e perché?", "Che cosa è peggiorato, anche fuori dai criteri?", "Quali errori sono sfuggiti alla revisione?", "Vale anche per chi non ha partecipato?", "Vale anche nei periodi di maggior carico?"], 3, 1.12, 1.05, 12);
    banner(s, 3.65, "Progettare la verifica in modo che possa dare esito negativo (Popper). E poter dire che qualcosa non funziona.", { h: 0.9, fontSize: 14 });
    txt(s, "Domande da porsi durante e dopo la sperimentazione delle bozze. Esempio fittizio.", { x: 0.5, y: 4.6, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Tre decisioni possibili", "L'esito di una verifica è una decisione, e il sottotema ne indica tre possibili: approfondire, modificare o abbandonare l'opportunità. Approfondire: i criteri di successo sono raggiunti, e si passa a un livello di verifica o di investimento successivo; per esempio dalla sperimentazione circoscritta a una più ampia, o alla decisione di realizzazione, che richiede il lavoro del Tema 16. Modificare: i risultati sono nella zona intermedia, o hanno rivelato qualcosa di inatteso; si cambia il caso d'uso, per esempio restringendo il perimetro, cambiando le fonti, rafforzando i controlli, e si verifica di nuovo. Abbandonare: i criteri di insuccesso sono raggiunti, o è emerso un rischio non accettabile; si interrompe. Abbandonare non è un fallimento della verifica: è il suo successo. La verifica è servita esattamente a ciò per cui era stata progettata: evitare un investimento che non avrebbe funzionato, a un costo limitato. La consapevolezza del sottotema lo dice chiaramente: lo scopo di un test è imparare se l'opportunità sia utile, realizzabile e controllabile, non dimostrare a ogni costo che l'idea iniziale è valida. Un'organizzazione in cui nessuna sperimentazione viene mai abbandonata probabilmente non sta sperimentando davvero.");
    stepTag(s, 4);
    const d = [["FiArrowUpRight", "Approfondire", "Criteri di successo raggiunti: livello successivo", C.accent6], ["FiRefreshCw", "Modificare", "Zona intermedia o sorprese: cambiare e riverificare", C.background2], ["FiXCircle", "Abbandonare", "Insuccesso o rischio non accettabile: fermarsi", C.background2]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.1, d[i][3], d[i][1]);
      await iconCircle(s, x + 0.15, 1.27, 0.55, d[i][0]);
      txt(s, d[i][1], { x: x + 0.8, y: 1.27, w: 1.95, h: 0.55, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, d[i][2], { x: x + 0.15, y: 1.95, w: 2.56, h: 1.2, fontSize: 12, color: C.text1 });
    }
    shapeBox(s, 0.5, 3.45, 9.0, 0.7, C.accent1, "abbandonare");
    txt(s, "Abbandonare non è il fallimento della verifica: è il suo successo, a un costo limitato.", { x: 0.7, y: 3.45, w: 8.6, h: 0.7, fontSize: 14, bold: true, color: C.background1, valign: "middle" });
    txt(s, "Un'organizzazione in cui nessuna sperimentazione viene mai abbandonata probabilmente non sta sperimentando davvero.", { x: 0.5, y: 4.3, w: 9, h: 0.55, fontSize: 13, italic: true, color: C.accent5 });
  }
  {
    const s = content("Dimostrazione o validazione", "L'ultimo punto del sottotema e del percorso: la differenza tra dimostrazione tecnica e validazione del caso d'uso. Una dimostrazione tecnica mostra che il sistema può produrre un output adeguato: le bozze generate su 50 richieste scelte sono buone. È un passo importante, ed è spesso ciò che viene presentato nelle riunioni, con grande effetto. Ma risponde solo a una delle domande. La validazione del caso d'uso mostra che il caso d'uso produce il beneficio atteso, nel lavoro reale, con rischi controllabili: i commerciali usano le bozze, i tempi di risposta scendono, gli errori non aumentano, il costo è sostenibile. Risponde alle domande di valore, fattibilità organizzativa, sostenibilità e rischio. Molti progetti di AI si fermano alla dimostrazione tecnica, e la scambiano per la validazione: il prototipo funziona, quindi il caso d'uso è valido. È lo stesso errore visto nel Tema 14 e nel 15.5 tra prototipo e servizio, guardato dal punto di vista delle evidenze. Il confronto in slide riassume le differenze.");
    stepTag(s, 4);
    table(s, [["", "Dimostrazione tecnica", "Validazione del caso d'uso"],
      ["Domanda", "Il sistema può produrre un output adeguato?", "Il caso d'uso produce il beneficio, nel lavoro reale?"],
      ["Condizioni", "Casi scelti, attenzione speciale", "Casi reali, uso normale"],
      ["Che cosa mostra", "Qualità dell'output", "Valore, uso, sostenibilità, rischio"],
      ["Esempio fittizio", "Bozze buone su 50 richieste scelte", "Bozze usate, tempi più brevi, errori non aumentati"]],
      { y: 1.15, colW: [1.9, 3.4, 3.7], rowH: 0.55, accentCol: 2, fontSize: 12 });
    banner(s, 4.0, "Il prototipo funziona, quindi il caso d'uso è valido: l'errore più comune.", { h: 0.8, fontSize: 15 });
  }
  keySlide("La sperimentazione deve poter smentire l'idea iniziale: lo scopo di un test è imparare, non dimostrare a ogni costo che l'idea era valida.", "Sottotema 15.8  ·  Dall'idea alla verifica", "Concetto chiave dell'ultimo sottotema. Ipotesi, dimostrazione tecnica e risultato verificato sono livelli diversi. Le assunzioni critiche sono quelle importanti e incerte, da rendere verificabili. Si usa la verifica più leggera che risponde alla domanda. I criteri di successo e di insuccesso si decidono prima. Si confronta con la baseline e con le alternative semplici. Si cercano le evidenze contrarie. L'esito è approfondire, modificare o abbandonare, e abbandonare può essere il successo della verifica. Esercizio suggerito: per l'idea su cui si è lavorato nel modulo, scrivere un'ipotesi critica verificabile, la verifica più leggera che potrebbe rispondere, e i criteri di successo, di insuccesso e la zona intermedia.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quale problema affrontare: partire dal problema e dal risultato desiderato, distinguere cause e sintomi, e chiedersi prima se serve l'AI. Come descrivere un caso d'uso: chi, quale attività, quali informazioni, quale ruolo dell'AI, quale risultato, con supervisione, volumi e confini. Che cosa rende promettente un'opportunità: segnali di valore e di adattabilità, ma il più promettente non è il più spettacolare. Benefici ipotizzati o ottenibili: calcoli con ipotesi esplicite, beneficio teorico ridotto da esclusioni, verifica e adozione, stime distinte da risultati. Dati, competenze, strumenti, integrazioni: fattibilità tecnica, organizzativa ed economica sono distinte. Rischi: alcuni sono condizioni di esclusione, non compensabili. Confrontare senza troppa certezza: criteri espliciti, soglie prima del punteggio, la matrice come ausilio alla discussione. Esperimenti: con criteri di successo e insuccesso definiti prima, capaci di smentire l'idea. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Quale problema?", "Il problema e il risultato, prima dello strumento"], ["Come descrivere un caso d'uso?", "Chi, attività, informazioni, ruolo dell'AI, risultato"], ["Che cosa lo rende promettente?", "Valore e adattabilità; non la spettacolarità"], ["Ipotizzati o ottenibili?", "Ipotesi esplicite, scenari, stime non dimostrate"], ["Dati, competenze, strumenti?", "Fattibilità tecnica, organizzativa, economica"], ["Quali rischi lo escludono?", "Le condizioni di soglia, non compensabili"], ["Come confrontare?", "Criteri espliciti; la matrice è un ausilio"], ["Quali esperimenti?", "Criteri decisi prima, capaci di smentire"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.9;
      shapeBox(s, x, y, 4.4, 0.8, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.06, w: 3.8, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.34, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere un problema aziendale da una soluzione tecnologica; comprendere perché non tutti i problemi richiedono l'AI; descrivere un caso d'uso attraverso attività, informazioni, risultati e contributo dell'AI; riconoscere le caratteristiche che possono rendere promettente un'opportunità; individuare i principali benefici potenziali; distinguere desiderabilità, fattibilità e sostenibilità; comprendere l'importanza di dati, strumenti e competenze disponibili; identificare rischi e condizioni che possono limitare o impedire un uso; confrontare opportunità diverse con criteri espliciti; comprendere i limiti delle matrici e dei punteggi; distinguere ipotesi, dimostrazioni tecniche e risultati verificati; comprendere perché una sperimentazione deve poter portare anche all'abbandono dell'idea iniziale.");
    const r = ["Problema o soluzione tecnologica", "Non tutti i problemi richiedono l'AI", "Descrivere un caso d'uso", "Caratteristiche promettenti", "Benefici potenziali", "Desiderabilità, fattibilità, sostenibilità", "Dati, strumenti, competenze", "Rischi e condizioni di esclusione", "Confronto con criteri espliciti", "Limiti di matrici e punteggi", "Ipotesi, dimostrazioni, risultati verificati", "Una sperimentazione può far abbandonare l'idea"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("La scheda dell'opportunità", "Traduciamo il modulo in una scheda pratica, da usare per valutare in modo preliminare un'idea di uso dell'AI. Cinque colonne, come le fasi del percorso. Individuare: qual è il problema, per chi, con quale risultato desiderato? Quali alternative non AI esistono? Descrivere: chi, quale attività, quali informazioni, quale ruolo dell'AI, quale supervisione, quale volume, quali confini? Quali ipotesi? Valutare: quale beneficio realistico, con scenari? Quali costi completi? È desiderabile, fattibile, sostenibile? Ci sono condizioni di esclusione? Confrontare: dove si colloca rispetto alle altre opportunità? Quanto è robusta la valutazione ai cambiamenti di pesi e giudizi? Verificare: qual è l'ipotesi critica? Qual è la verifica più leggera? Quali criteri di successo e insuccesso, decisi prima? La scheda non sostituisce il giudizio, ma lo rende esplicito, condivisibile e discutibile. Ed è uno strumento accessibile a chiunque, non solo agli specialisti.");
    const f = [["Individuare", ["Problema, per chi?", "Risultato desiderato?", "Alternative non AI?"], C.background2], ["Descrivere", ["Chi, attività, informazioni?", "Ruolo dell'AI, supervisione?", "Volume, confini, ipotesi?"], C.accent6], ["Valutare", ["Beneficio realistico?", "Costi completi?", "Desiderabile, fattibile, sostenibile?", "Esclusioni?"], C.background2], ["Confrontare", ["Posizione nella matrice?", "Robusta ai pesi?"], C.accent6], ["Verificare", ["Ipotesi critica?", "Verifica più leggera?", "Criteri decisi prima?"], C.background2]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.72, 3.0, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.1, y: 1.22, w: 1.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.1, y: 1.68, w: 1.58, h: 2.4, fontSize: 11, color: C.text1 });
    }
    banner(s, 4.3, "Non sostituisce il giudizio: lo rende esplicito, condivisibile, discutibile.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei semplificazioni frequenti quando si cercano e si valutano opportunità AI, una per ciascuno dei passaggi del modulo. Primo: 'abbiamo l'AI, dove la usiamo?'. È partire dallo strumento invece che dal problema, e scambiare una soluzione per un obiettivo. Secondo: 'facciamo il caso più spettacolare'. L'opportunità più promettente è spesso semplice, quotidiana e controllabile, e prima vanno considerate le alternative più semplici, anche non AI. Terzo: 'risparmieremo il 40 per cento del tempo'. È una stima presentata come un risultato; e spesso si conta solo il costo della licenza. Quarto: 'la demo funziona, quindi è fattibile'. La fattibilità tecnica non coincide con l'adozione organizzativa né con la sostenibilità economica. Quinto: 'ha il punteggio più alto'. Il punteggio è un ausilio alla discussione, non una prova, e non compensa le condizioni di esclusione. Sesto: 'il test è andato bene, come previsto'. I criteri di successo e di insuccesso vanno decisi prima di vedere i risultati, e una sperimentazione deve poter portare anche ad abbandonare l'idea. Sono errori comprensibili, perché la pressione a 'fare qualcosa con l'AI' è forte, e le dimostrazioni sono convincenti. Suggerimento: chiedere ai partecipanti quale di queste frasi hanno sentito più spesso in azienda.");
    const a = [["FiCpu", "\"Abbiamo l'AI: dove la usiamo?\"", "Prima il problema, poi lo strumento", "15.1"], ["FiStar", "\"Facciamo il caso più spettacolare\"", "Prima le alternative più semplici", "15.3"], ["FiTrendingUp", "\"Risparmieremo il 40% del tempo\"", "Una stima non è un risultato", "15.4"], ["FiCheckCircle", "\"La demo funziona: è fattibile\"", "Fattibile non vuol dire adottato", "15.5"], ["FiBarChart2", "\"Ha il punteggio più alto\"", "Le esclusioni non si compensano", "15.7"], ["FiFlag", "\"Il test è andato bene, come previsto\"", "Criteri di successo decisi prima", "15.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 2.95, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.7, y: y + 0.1, w: 0.55, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 15 abbiamo visto come individuare, descrivere, valutare, confrontare e verificare le opportunità di uso dell'AI, partendo dal bisogno e non dallo strumento. Il tema successivo, il Tema 16, è dedicato all'adozione dell'AI e al cambiamento organizzativo: come introdurre e accompagnare l'adozione nell'organizzazione. È il confine cardine di questo modulo: qui ci siamo chiesti dove potrebbe avere senso usare l'AI e quali evidenze servono per scegliere; nel Tema 16 ci chiederemo come portare un'opportunità verificata nel lavoro quotidiano delle persone, con quali passaggi, quale coinvolgimento, quale formazione e comunicazione. Molte questioni che abbiamo lasciato aperte, come la fattibilità organizzativa, la desiderabilità per gli utenti, l'adozione effettiva degli strumenti, troveranno lì una risposta operativa. Il Tema 16 chiude l'area 'Comprendere il valore per l'azienda'; seguiranno i Temi 17 e 18, sull'utilizzo responsabile, dove i rischi e le condizioni di esclusione di questo modulo verranno approfonditi. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Temi 12-14; Tema 15: opportunità e valutazione (completato)", { x: 0.75, y: 4.07, w: 3.9, h: 0.55, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 16: Adozione dell'AI e cambiamento organizzativo", { x: 5.4, y: 1.72, w: 3.9, h: 0.85, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Come introdurre e accompagnare l'adozione nell'organizzazione", { x: 5.4, y: 2.6, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.2, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Temi 17 e 18: utilizzo responsabile"], { space: 5 }), { x: 5.4, y: 3.55, w: 3.9, h: 1.0, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Il modulo è soprattutto di metodo, e si appoggia su concetti consolidati della gestione dei progetti, del design e del metodo scientifico più che su studi specifici sull'AI. La terna desiderabilità, fattibilità, sostenibilità è associata al design thinking e in particolare a IDEO, con formulazioni diverse a seconda delle fonti. La tecnica dei cinque perché è tradizionalmente attribuita a Sakichi Toyoda e al sistema di produzione Toyota. L'effetto Hawthorne è citato con la cautela dovuta, perché le interpretazioni degli studi originali sono discusse. Gli esempi aziendali, le valutazioni e i numeri del modulo sono fittizi; lo scenario delle richieste commerciali è tratto dal documento di perimetro, con giudizi dichiaratamente illustrativi. Riferimenti verificati a ottobre 2026; le pagine di Nickerson e gli editori di Popper, Brown e Ohno sono da ricontrollare sulle pubblicazioni originali.");
    const src = [
      "Popper, K. R. (1959). The Logic of Scientific Discovery. Hutchinson (ed. orig. 1934).",
      "Brown, T. (2009). Change by Design. HarperBusiness. Per la terna desiderabilità, fattibilità, sostenibilità.",
      "Ohno, T. (1988). Toyota Production System: Beyond Large-Scale Production. Productivity Press. Per i cinque perché.",
      "Nickerson, R. S. (1998). Confirmation Bias: A Ubiquitous Phenomenon in Many Guises. Review of General Psychology, 2(2), 175-220.",
      "Gli esempi aziendali, le valutazioni e i numeri delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 9 }), { x: 1.3, y: 1.15, w: 8.2, h: 3.45, fontSize: 12, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema15_Opportunita_valutazione_AI.pptx" });
  await applyTheme("Tema15_Opportunita_valutazione_AI.pptx", THEME);
  console.log("done");
})();
