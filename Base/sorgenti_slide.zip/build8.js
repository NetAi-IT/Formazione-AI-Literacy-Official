const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 8: AI per testi, documenti e conoscenza";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 8  ·  AI per testi, documenti e conoscenza";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function modeTag(s, active) {
    const st = ["Produrre", "Trasformare", "Analizzare", "Recuperare"];
    st.forEach((t, i) => {
      const x = 6.46 + i * 0.77;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.74, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "modalità " + t });
      txt(s, t, { x, y: 0.42, w: 0.74, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "documento " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 8", { placeholder: "kicker" });
    s.addText("AI per testi, documenti e conoscenza", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti all'ottavo tema, che apre una nuova area del percorso: 'Esplorare le possibilità dell'AI'. Nelle aree precedenti abbiamo costruito le basi: che cos'è l'AI e come funziona, quali sono i suoi limiti, come dialogare con essa, come formulare richieste e come verificare i risultati. Ora guardiamo a che cosa si può fare concretamente, partendo dall'ambito in cui l'AI generativa è più matura e più usata: i testi, i documenti e la conoscenza. È un tema che riguarda praticamente ogni ruolo aziendale, perché quasi ogni lavoro produce, legge, trasforma e cerca informazioni scritte. Il punto di vista è quello dell'utilizzatore: capacità applicative e condizioni di efficacia, non configurazione tecnica di sistemi documentali. E il tema va oltre la semplice scrittura: il suo nucleo distintivo è la capacità di sintetizzare, estrarre, confrontare e consultare documenti. Suggerimento per l'apertura: chiedere ai partecipanti quante ore a settimana dedicano a leggere, scrivere, riassumere o cercare informazioni nei documenti. La risposta, di solito sorprendente, mostra perché il tema è rilevante. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; le capacità degli strumenti su documenti lunghi, tabelle e scansioni migliorano di continuo, quindi esempi e limiti vanno ricontrollati sugli strumenti autorizzati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la comprensione delle principali possibilità dell'AI nella produzione, trasformazione, analisi, estrazione e organizzazione di contenuti testuali e documentali, con le relative opportunità, condizioni di efficacia e limiti. La consapevolezza da sviluppare ha due facce. Da un lato, l'AI può supportare molte attività basate sulle informazioni, dalla redazione di un'email alla consultazione di un archivio di procedure. Dall'altro, il valore del risultato dipende da quattro fattori: la qualità delle fonti, la fedeltà dell'elaborazione, la tracciabilità delle informazioni e la capacità di verificarne l'adeguatezza. Un punto chiave che svilupperemo: generare, trasformare, analizzare ed estrarre informazioni sono attività distinte, con esigenze di controllo diverse. Il messaggio centrale del tema: l'AI può generare testi e trasformare documenti in informazioni organizzate, confrontabili e consultabili, ma il valore effettivo richiede di preservare correttezza, significato e tracciabilità, senza confondere un'elaborazione convincente con un'elaborazione completa e verificata.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Conoscere le possibilità dell'AI su testi e documenti", "Distinguere produrre, trasformare, analizzare, estrarre", "Riconoscere opportunità, condizioni di efficacia e limiti"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Da che cosa dipende il valore", headSize: 16, fill: C.accent6, bodySize: 14,
      body: bullets(["Qualità delle fonti", "Fedeltà dell'elaborazione", "Tracciabilità delle informazioni", "Capacità di verificarne l'adeguatezza"], { space: 6 }) });
  }
  {
    const s = content("Undici domande guida", "Le undici domande guida accompagnano il modulo. Le prime due riguardano la produzione di testi: che cosa può fare l'AI oltre alla scrittura, e quando conviene generare un testo nuovo invece di trasformarne uno esistente. Le successive riguardano l'analisi dei documenti: come sintetizzare senza perdere condizioni ed eccezioni, che differenza c'è tra sintetizzare ed estrarre dati, come confrontare documenti mantenendo il collegamento ai passaggi originali. Poi la conoscenza: la differenza tra ricerca su fonti esterne e interrogazione di una raccolta documentale, e che cosa rende una raccolta davvero interrogabile. L'ottava riguarda il passaggio da informazioni non strutturate a dati utilizzabili. Le ultime tre riguardano i limiti: formati, scansioni, tabelle e documenti lunghi; come distinguere una sintesi apparentemente corretta da una fedele; quando risalire alle fonti. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Quali attività sui testi oltre alla scrittura?", "Quando generare e quando trasformare un testo esistente?", "Come sintetizzare senza perdere condizioni ed eccezioni?", "Che differenza tra sintetizzare ed estrarre dati strutturati?", "Come confrontare documenti restando legati ai passaggi originali?", "Ricerca su fonti esterne o interrogazione di una raccolta?", "Che cosa rende una raccolta davvero interrogabile?", "Come passare da testo non strutturato a dati utilizzabili?", "Perché formati, scansioni, tabelle e lunghezza complicano?", "Sintesi apparentemente corretta o fedele e completa?", "Quando risalire alle fonti e verificare l'elaborazione?"], 4, 1.15, 1.08, 11);
  }
  {
    const s = content("Il filo conduttore: quattro modalità", "Il documento di perimetro propone un filo conduttore: quattro modalità applicative, che corrispondono a quattro tipi diversi di lavoro informativo. Produrre: creare contenuti nuovi a partire da istruzioni, come un'email, una relazione, una descrizione. Corrisponde al sottotema 8.1. Trasformare: lavorare su un testo esistente, correggendolo, semplificandolo, traducendolo, cambiandone il formato. Corrisponde all'8.2. Analizzare e strutturare: ricavare da uno o più documenti sintesi, dati strutturati, confronti. Corrispondono l'8.3, l'8.4 e l'8.5, che sono il nucleo distintivo del tema. Recuperare conoscenza: cercare, approfondire e consultare informazioni, sia all'esterno sia in raccolte documentali organizzate. Corrispondono l'8.6 e l'8.7. L'8.8, sui limiti e le condizioni di efficacia, attraversa tutte le modalità. Una precisazione: non è una sequenza obbligatoria. Sono modalità diverse, che spesso si combinano: per preparare un dossier si può cercare, sintetizzare, estrarre e infine produrre un testo. Nelle slide, un indicatore in alto a destra ricorda la modalità di cui stiamo parlando.");
    const st = [["FiEdit3", "Produrre", "Creare contenuti nuovi da istruzioni", "8.1"], ["FiRefreshCw", "Trasformare", "Lavorare su un testo esistente", "8.2"], ["FiLayers", "Analizzare e strutturare", "Sintesi, estrazione, confronto", "8.3  8.4  8.5"], ["FiDatabase", "Recuperare conoscenza", "Ricerca e raccolte documentali", "8.6  8.7"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 2;
      shapeBox(s, x, 1.2, 2.1, 2.75, dark ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.7, 1.35, 0.7, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.1, y: 2.15, w: 1.9, h: 0.6, fontSize: 15, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.8, w: 1.8, h: 0.6, fontSize: 12, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.1, y: 3.5, w: 1.9, h: 0.35, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.4, 0.17);
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.accent6, "limiti trasversali");
    txt(s, [{ text: "8.8 Limiti e condizioni di efficacia: ", options: { bold: true, color: C.accent1 } }, { text: "attraversano tutte le modalità. Non è una sequenza obbligatoria: le modalità spesso si combinano.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Attività diverse, controlli diversi", "Il punto concettuale più importante del tema è che generare, trasformare, analizzare ed estrarre sono attività diverse, con rischi e controlli diversi. Quando si genera, il rischio principale è che il sistema inventi o aggiunga contenuti non corretti o non adatti: il controllo riguarda l'accuratezza e l'adeguatezza al destinatario. Quando si trasforma, il rischio è che la nuova versione alteri il significato del testo di partenza: il controllo è un confronto con l'originale. Quando si sintetizza o si analizza, il rischio è perdere elementi decisivi, come condizioni ed eccezioni: il controllo riguarda la fedeltà e la completezza rispetto al documento. Quando si estrae, il rischio è un dato sbagliato, mancante o inventato, che poi viene usato in attività successive: il controllo riguarda l'accuratezza campo per campo. Quando si recupera conoscenza, il rischio è un'informazione superata, non pertinente o senza fonte: il controllo riguarda attualità, attendibilità e collegamento al documento originale. Non ripetiamo qui i metodi generali di verifica del Tema 7: li applichiamo, in ciascun sottotema, ai contenuti documentali.");
    table(s, [["Attività", "Rischio principale", "Controllo principale"],
      ["Generare", "Contenuti inventati o inadatti", "Accuratezza, adeguatezza al destinatario"],
      ["Trasformare", "Significato alterato", "Confronto con l'originale"],
      ["Sintetizzare, analizzare", "Elementi decisivi persi", "Fedeltà e completezza rispetto al documento"],
      ["Estrarre", "Dato errato, mancante o inventato", "Accuratezza campo per campo"],
      ["Recuperare conoscenza", "Informazione superata o senza fonte", "Attualità, attendibilità, collegamento alla fonte"]],
      { y: 1.15, colW: [2.2, 3.2, 3.6], rowH: 0.5, fontSize: 12, blankCorner: false });
    banner(s, 4.35, "Non è sempre lo stesso controllo: dipende dal tipo di lavoro che l'AI ha svolto.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti con priorità alta e tutti mantenuti distinti. Vanno compresi e sperimentati: generazione, trasformazione e sintesi di testi, estrazione di informazioni, confronto documentale e tracciabilità delle fonti. Vanno conosciuti e compresi: ricerca informativa, gestione della conoscenza, interrogazione documentale, limiti di formati e qualità dei documenti. Vanno solo accennati: architetture RAG, pipeline documentali, sistemi di indicizzazione, database vettoriali, configurazioni di ricerca semantica e integrazioni tecniche. L'enfasi va su 8.3, 8.4, 8.5 e 8.7, il nucleo distintivo del tema, perché mostrano il potenziale dell'AI oltre la generazione di testo. Confini: non ripetiamo i meccanismi tecnici del Tema 2, la teoria delle allucinazioni del Tema 3, le tecniche di prompting del Tema 6, i metodi di verifica del Tema 7. Non approfondiamo l'analisi quantitativa, che è del Tema 9, la multimodalità, del Tema 10, gli agenti e i workflow, del Tema 11, né la progettazione dei sistemi di conoscenza aziendale, del Tema 14. Un'avvertenza pratica valida per tutto il modulo: i documenti di lavoro vanno caricati solo negli strumenti autorizzati dall'azienda, secondo le regole sulla riservatezza dei dati.");
    pathSlide(s, [["8.1", "Generazione di contenuti testuali", "Alta"], ["8.2", "Revisione e trasformazione dei testi", "Alta"], ["8.3", "Sintesi e analisi documentale", "Alta"], ["8.4", "Estrazione e strutturazione", "Alta"], ["8.5", "Confronto documentale", "Alta"], ["8.6", "Ricerca e organizzazione", "Alta"], ["8.7", "Gestione della conoscenza", "Alta"], ["8.8", "Limiti e condizioni di efficacia", "Alta"]],
      [["Comprendere e sperimentare", "Generazione, trasformazione, sintesi, estrazione, confronto, tracciabilità", C.accent1, C.background1], ["Conoscere e comprendere", "Ricerca, gestione della conoscenza, interrogazione documentale, limiti dei formati", C.accent6, C.text1], ["Solo accennare", "RAG, pipeline documentali, indicizzazione, database vettoriali, ricerca semantica", C.background2, C.text1]]);
  }

  // =====================================================================
  section("8.1 Generazione");
  divider("8.1", "Generazione di contenuti testuali", "L'AI può accelerare la produzione di contenuti, ma qualità e adeguatezza vanno presidiate dalla revisione", "Partiamo dalla modalità più nota: produrre testi nuovi. È quella che quasi tutti hanno già provato, ed è anche quella in cui è più facile sopravvalutare il risultato, perché un testo generato è quasi sempre scorrevole e ben impaginato. In questo sottotema, da comprendere e sperimentare, vediamo che cosa si può produrre, come adattare i testi a destinatari e registri diversi, come usare bozze e versioni alternative e, soprattutto, la differenza tra generazione automatica e redazione supervisionata. Come si formulano le richieste l'abbiamo visto nel Tema 6: qui ci concentriamo sulle possibilità e sulle condizioni di efficacia.");
  {
    const s = content("Che cosa si può produrre", "La generazione di testi a partire da istruzioni copre una gamma ampia di contenuti professionali. Comunicazioni: email, risposte a richieste, messaggi, avvisi, comunicazioni interne. Documenti di lavoro: relazioni, report, verbali a partire da appunti, proposte, presentazioni testuali. Contenuti informativi: descrizioni di prodotti o servizi, schede, FAQ, testi per il sito o per la intranet, istruzioni. Bozze e strutture: scalette, indici, prime versioni da completare, modelli riutilizzabili. Il valore principale non è tanto scrivere al posto della persona, quanto superare la pagina bianca e ridurre il tempo delle parti più ripetitive, lasciando più tempo per contenuto, verifica e cura. Un punto da sottolineare: la qualità del testo generato dipende in gran parte dalle informazioni fornite. Se il sistema non conosce i fatti specifici, tende a riempire i vuoti con contenuti generici o inventati. Più il testo riguarda fatti, dati e decisioni specifici dell'azienda, più è importante fornire il materiale di partenza invece di chiedere al sistema di produrlo da zero.");
    modeTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMail", head: "Comunicazioni", body: "Email, risposte, avvisi, comunicazioni interne" },
      { icon: "FiFileText", head: "Documenti di lavoro", body: "Relazioni, report, verbali da appunti, proposte" },
      { icon: "FiInfo", head: "Contenuti informativi", body: "Descrizioni, schede, FAQ, istruzioni, testi per la intranet" },
      { icon: "FiList", head: "Bozze e strutture", body: "Scalette, indici, prime versioni, modelli riutilizzabili" },
    ], 2, { y: 1.2, H: 2.9, headSize: 15, bodySize: 13 });
    banner(s, 4.3, "Più il testo riguarda fatti specifici, più conta fornire il materiale di partenza: altrimenti il sistema riempie i vuoti.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Dalle istruzioni al testo", "Un testo generato è il risultato di tre ingredienti, e la sua qualità dipende da tutti e tre. Il primo sono le istruzioni: scopo, destinatario, tono, lunghezza, struttura. Le tecniche per formularle le abbiamo viste nel Tema 6. Il secondo è il materiale di partenza: fatti, dati, appunti, documenti, decisioni già prese. È l'ingrediente più trascurato e il più importante per i testi professionali. Senza materiale, il sistema produce un testo plausibile ma generico, o peggio inventa dettagli verosimili, come date, nomi, numeri, impegni. Il terzo sono gli esempi e i riferimenti di stile: un testo simile già approvato, le linee guida di comunicazione, il modo in cui l'azienda si rivolge ai clienti. Lo schema in slide mostra il rapporto: le istruzioni dicono come scrivere, il materiale dice che cosa scrivere, gli esempi dicono in che stile. Quando un testo generato delude, conviene chiedersi quale dei tre ingredienti mancava. Spesso il problema non è il sistema, ma il fatto che gli abbiamo chiesto di scrivere qualcosa che non poteva sapere.");
    modeTag(s, 0);
    const ing = [["FiSliders", "Istruzioni", "Come scrivere", "Scopo, destinatario, tono, lunghezza, struttura"], ["FiFolder", "Materiale di partenza", "Che cosa scrivere", "Fatti, dati, appunti, decisioni già prese"], ["FiBookmark", "Esempi e stile", "In che stile", "Testi approvati, linee guida, modo di rivolgersi"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.15 + i * 1.0;
      shapeBox(s, 0.5, y, 5.3, 0.88, i === 1 ? C.accent6 : C.background2, ing[i][1]);
      await iconCircle(s, 0.68, y + 0.17, 0.54, ing[i][0]);
      txt(s, ing[i][1], { x: 1.4, y: y + 0.08, w: 2.3, h: 0.36, fontSize: 14, bold: true, color: C.text1 });
      txt(s, ing[i][2], { x: 3.7, y: y + 0.08, w: 2.0, h: 0.36, fontSize: 12, bold: true, color: C.accent1, align: "right" });
      txt(s, ing[i][3], { x: 1.4, y: y + 0.45, w: 4.3, h: 0.38, fontSize: 12, color: C.text2 });
    }
    arrow(s, 5.95, 2.3, 0.4);
    shapeBox(s, 6.5, 1.15, 3.0, 2.88, C.text1, "testo");
    await iconCircle(s, 7.65, 1.35, 0.7, "FiFileText", C.accent1);
    txt(s, "Testo generato", { x: 6.65, y: 2.15, w: 2.7, h: 0.4, fontSize: 16, bold: true, color: C.background1, align: "center" });
    txt(s, "La qualità dipende da tutti e tre gli ingredienti", { x: 6.7, y: 2.6, w: 2.6, h: 0.9, fontSize: 12, color: C.accent3, align: "center" });
    txt(s, "Senza materiale, il testo è generico, o inventa dettagli verosimili: date, nomi, numeri, impegni.", { x: 0.5, y: 4.3, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.accent5, bold: true });
  }
  {
    const s = content("Adattare il testo ai destinatari", "Uno degli usi più utili della generazione è adattare uno stesso contenuto a destinatari diversi. Lo stesso fatto, per esempio una modifica dell'orario del servizio clienti, va comunicato in modo diverso alla direzione, ai colleghi del servizio clienti e ai clienti. Per la direzione conta il perché e l'impatto: motivazione, costi, effetti attesi. Per i colleghi conta che cosa cambia operativamente: da quando, che cosa devono fare, a chi rivolgersi. Per i clienti conta che cosa cambia per loro, con un tono cortese e senza dettagli interni. L'AI è molto efficace nel produrre rapidamente queste versioni, partendo da un unico contenuto di base. Due attenzioni. Primo, il contenuto di base deve essere corretto e completo: ogni versione eredita gli errori della base. Secondo, ogni versione va controllata per il proprio destinatario: è facile che nella versione per i clienti finisca un dettaglio interno che non dovrebbe esserci, o che nella versione sintetica per la direzione sparisca un'informazione importante. Esempio fittizio in slide.");
    modeTag(s, 0);
    docBox(s, 0.5, 1.15, 9.0, 0.75, "Contenuto di base (esempio fittizio)", "Dal 1° marzo il servizio clienti telefonico sarà attivo dalle 8 alle 18, invece che dalle 9 alle 17.", { fontSize: 12 });
    table(s, [["Destinatario", "Che cosa conta", "Registro"],
      ["Direzione", "Motivazione, costi, effetti attesi", "Sintetico, orientato alle decisioni"],
      ["Colleghi del servizio", "Da quando, nuovi turni, a chi rivolgersi", "Operativo, diretto"],
      ["Clienti", "Che cosa cambia per loro, come contattarci", "Cortese, senza dettagli interni"]],
      { y: 2.05, colW: [2.2, 3.7, 3.1], rowH: 0.45, fontSize: 12, blankCorner: false });
    banner(s, 4.1, "Ogni versione eredita gli errori della base, e va controllata per il proprio destinatario.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Tono, stile e registro", "Tre concetti vicini ma distinti, utili per dare istruzioni precise e valutare il risultato. Il tono è l'atteggiamento verso il destinatario: cordiale, formale, rassicurante, deciso, empatico. Lo stile riguarda le scelte di scrittura: frasi brevi o articolate, lessico tecnico o comune, struttura con elenchi o testo continuo. Il registro è il livello di formalità adatto al contesto: una comunicazione a un ente pubblico, un'email a un collega, un post sulla intranet. L'AI è molto flessibile su tutti e tre: può riscrivere lo stesso contenuto in molte varianti. Alcune attenzioni pratiche. Il tono di default dei sistemi tende a essere entusiasta, cerimonioso e ricco di formule generiche, che in un contesto professionale possono suonare artificiali o poco credibili: conviene indicare esplicitamente il tono desiderato o fornire un esempio. La coerenza con la comunicazione aziendale non è automatica: se l'azienda ha linee guida di stile, vanno fornite. Infine, il tono può cambiare il significato percepito: un messaggio troppo rassicurante su un problema serio, o troppo deciso in una trattativa, può creare aspettative o tensioni non volute.");
    modeTag(s, 0);
    await iconGrid(s, [
      { icon: "FiSmile", head: "Tono", body: "L'atteggiamento verso il destinatario: cordiale, formale, rassicurante, deciso" },
      { icon: "FiFeather", head: "Stile", body: "Le scelte di scrittura: frasi, lessico, struttura" },
      { icon: "FiLayers", head: "Registro", body: "Il livello di formalità adatto al contesto" },
    ], 3, { y: 1.2, h: 1.6, headSize: 15, bodySize: 12 });
    const a = [["Tono di default", "Spesso entusiasta e cerimonioso: indicare il tono o dare un esempio"], ["Coerenza aziendale", "Non automatica: fornire le linee guida di stile"], ["Significato percepito", "Il tono può creare aspettative o tensioni non volute"]];
    a.forEach((e, i) => {
      const y = 3.0 + i * 0.62;
      shapeBox(s, 0.5, y, 9.0, 0.54, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.4, h: 0.54, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.1, y, w: 6.2, h: 0.54, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Bozze e versioni alternative", "Due usi della generazione meritano attenzione perché cambiano il modo di lavorare. Le bozze: l'AI è molto efficace nel produrre una prima versione su cui lavorare. Il valore sta nel ridurre il tempo per arrivare a qualcosa di concreto da migliorare. Ma una bozza è appunto una bozza: va letta, corretta e completata, non solo ritoccata. Le versioni alternative: si possono chiedere più versioni dello stesso testo, con impostazioni diverse, per esempio una più sintetica e una più dettagliata, una più formale e una più diretta, tre possibili oggetti per un'email, due aperture per una relazione. Confrontare alternative aiuta a capire che cosa si vuole davvero e spesso porta a combinare elementi di versioni diverse. Due rischi da conoscere. Il primo è l'ancoraggio, visto nel Tema 5: la prima bozza tende a definire struttura e contenuti anche quando sarebbe meglio un'impostazione diversa. Chiedere alternative fin dall'inizio aiuta a contrastarlo. Il secondo è l'omologazione: testi generati da molte persone con gli stessi strumenti tendono ad assomigliarsi, con le stesse formule e le stesse strutture. Il contributo personale resta ciò che rende un testo riconoscibile.");
    modeTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.45, { icon: "FiEdit", head: "Bozze", headSize: 16, bodySize: 13,
      body: bullets(["Arrivare rapidamente a qualcosa di concreto", "Da leggere, correggere, completare", "Non solo da ritoccare"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.45, { icon: "FiCopy", head: "Versioni alternative", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Sintetica o dettagliata, formale o diretta", "Più oggetti, più aperture", "Confrontare e combinare"], { space: 5 }) });
    const r = [["Ancoraggio", "La prima bozza definisce l'impostazione: chiedere alternative fin dall'inizio"], ["Omologazione", "Testi tutti simili: il contributo personale li rende riconoscibili"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 3.85, 4.35, 1.1, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 3.95, w: 3.95, h: 0.35, fontSize: 14, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.3, w: 3.95, h: 0.6, fontSize: 12, color: C.background1 });
    });
  }
  {
    const s = content("Automatica o supervisionata", "Questa è la distinzione più importante del sottotema. Nella generazione automatica, il testo prodotto dal sistema viene usato così com'è, senza una revisione sostanziale: è il caso di risposte automatiche, descrizioni generate in serie, testi pubblicati direttamente. Nella redazione supervisionata, il sistema produce una proposta e una persona la rivede, la corregge, la completa e ne risponde. Tra i due estremi ci sono gradi intermedi, come una revisione a campione su testi generati in serie. Il livello di supervisione adeguato dipende da tre fattori, coerenti con quanto visto nel Tema 7: le conseguenze di un errore, la visibilità del testo, cioè chi lo leggerà, e la presenza di fatti specifici, dati o impegni. Una bozza di email interna può richiedere una rilettura; una comunicazione a tutti i clienti, un testo contrattuale o una risposta su temi legali o sanitari richiedono una redazione pienamente supervisionata, eventualmente con esperti. La generazione automatica senza revisione è adatta solo a contenuti a basso rischio, con controlli organizzativi definiti. In ogni caso, chi usa e firma il testo ne risponde, come detto nel Tema 7.");
    modeTag(s, 0);
    const lv = [["Generazione automatica", "Il testo è usato così com'è", C.background2, C.text1], ["Supervisione a campione", "Testi in serie, controlli periodici", C.accent6, C.text1], ["Redazione supervisionata", "Una persona rivede, completa e ne risponde", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 1.35, l[2], l[0]);
      txt(s, l[0], { x: x + 0.15, y: 1.3, w: 2.56, h: 0.5, fontSize: 15, bold: true, color: l[3], align: "center", valign: "middle" });
      txt(s, l[1], { x: x + 0.15, y: 1.85, w: 2.56, h: 0.6, fontSize: 12, color: l[3], align: "center" });
      if (i < 2) arrow(s, x + 2.88, 1.72, 0.17);
    });
    txt(s, "Più supervisione quando aumentano", { x: 0.5, y: 2.75, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.15, 2.9, 0.5, "Conseguenze di un errore", { fill: C.background2 });
    chip(s, 3.55, 3.15, 2.9, 0.5, "Visibilità del testo", { fill: C.background2 });
    chip(s, 6.6, 3.15, 2.9, 0.5, "Fatti, dati, impegni", { fill: C.background2 });
    banner(s, 3.95, "Generazione automatica solo per contenuti a basso rischio, con controlli definiti. Chi usa il testo ne risponde.", { h: 0.9, fontSize: 13 });
  }
  keySlide("L'AI può accelerare la produzione di contenuti, ma qualità, accuratezza e adeguatezza devono essere presidiate dal processo di revisione umano e organizzativo.", "Sottotema 8.1  ·  Generazione di contenuti testuali", "Concetto chiave del primo sottotema. Generare testi è la modalità più nota e immediata: email, relazioni, descrizioni, bozze, versioni per destinatari diversi. Ma la qualità dipende da istruzioni, materiale di partenza ed esempi; il tono di default e l'omologazione vanno gestiti; e soprattutto, il livello di supervisione deve essere proporzionato alle conseguenze di un errore e alla visibilità del testo. Si noti che il concetto chiave parla di revisione umana e organizzativa: non basta la buona volontà del singolo, servono anche regole su quali testi richiedono quale revisione. Esercizio suggerito: partire da un contenuto di base fittizio e chiedere ai partecipanti di generare tre versioni per destinatari diversi, poi confrontarle per individuare informazioni perse o aggiunte.");

  // =====================================================================
  section("8.2 Trasformazione");
  divider("8.2", "Revisione, riscrittura e trasformazione", "Trasformare un testo richiede di controllare che la nuova formulazione non alteri significati e informazioni", "Seconda modalità: trasformare. Qui il punto di partenza non sono istruzioni, ma un testo che esiste già, nostro o di altri. L'AI può correggerlo, renderlo più chiaro, semplificarlo, riformularlo, tradurlo, cambiarne il formato o la struttura. È una modalità molto potente e spesso sottovalutata, perché il controllo è più semplice che nella generazione: c'è un originale con cui confrontare il risultato. Ma ha un rischio specifico, che è il filo rosso del sottotema: la trasformazione può alterare il significato senza che ce ne accorgiamo. In questo sottotema, da comprendere e sperimentare, vediamo le principali trasformazioni e come distinguere modifiche formali da modifiche sostanziali.");
  {
    const s = content("Generare o trasformare?", "Una delle domande guida chiede quando conviene generare un testo nuovo e quando è più opportuno trasformarne uno esistente. Generare conviene quando non esiste un punto di partenza adatto e il contenuto è relativamente generico, oppure quando si vuole esplorare impostazioni diverse. Trasformare conviene quando esiste già un testo che contiene i contenuti corretti: una procedura approvata da semplificare, una relazione tecnica da rendere comprensibile alla direzione, appunti di una riunione da trasformare in verbale, un testo da tradurre. In questi casi la trasformazione ha due vantaggi importanti. Il primo è l'affidabilità: il sistema lavora su contenuti forniti, invece di produrli, e quindi il rischio di invenzioni si riduce, anche se non si azzera. Il secondo è la verificabilità: c'è un originale con cui confrontare il risultato, e quindi il controllo è più semplice e più mirato. Per questo, per i testi professionali che riguardano fatti specifici, una buona regola è partire dal materiale esistente quando c'è, e usare l'AI per trasformarlo, invece di chiederle di generare da zero.");
    modeTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiEdit3", head: "Generare conviene se", headSize: 16, bodySize: 13,
      body: bullets(["Non c'è un punto di partenza adatto", "Il contenuto è relativamente generico", "Si vogliono esplorare impostazioni diverse"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiRefreshCw", head: "Trasformare conviene se", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Esiste un testo con i contenuti corretti", "Procedure, relazioni, appunti, testi da tradurre", "Meno invenzioni, controllo più semplice"], { space: 5 }) });
    banner(s, 4.0, "Per i testi su fatti specifici: partire dal materiale esistente, quando c'è, e trasformarlo.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Le principali trasformazioni", "Una panoramica delle trasformazioni più utili. Correzione grammaticale e stilistica: refusi, concordanze, punteggiatura, ripetizioni. Miglioramento di chiarezza e leggibilità: frasi più brevi, ordine logico, eliminazione di ambiguità. Semplificazione: rendere comprensibile un testo complesso a chi non è esperto. Riformulazione e adattamento del linguaggio: cambiare registro, tono o lessico per un destinatario diverso. Traduzione e localizzazione: non solo tradurre, ma adattare a un contesto culturale e locale, con formati di date, unità, riferimenti. Trasformazione tra formati: da appunti a verbale, da relazione a slide, da procedura a FAQ, da email lunga a messaggio breve. Revisione della struttura: riorganizzare un testo, aggiungere titoli, spostare le informazioni importanti all'inizio. Le prime trasformazioni dell'elenco tendono a intervenire più sulla forma, le ultime più profondamente sul contenuto e sulla sua organizzazione. Più la trasformazione è profonda, più è alto il rischio di alterare il significato, e più è importante il controllo.");
    modeTag(s, 1);
    await iconGrid(s, [
      { icon: "FiCheckSquare", head: "Correzione", body: "Refusi, concordanze, punteggiatura" },
      { icon: "FiEye", head: "Chiarezza e leggibilità", body: "Frasi brevi, ordine logico, meno ambiguità" },
      { icon: "FiMinimize2", head: "Semplificazione", body: "Comprensibile anche ai non esperti" },
      { icon: "FiRepeat", head: "Riformulazione", body: "Registro, tono, lessico per un altro destinatario" },
      { icon: "FiGlobe", head: "Traduzione e localizzazione", body: "Lingua, contesto culturale, formati locali" },
      { icon: "FiShuffle", head: "Cambio di formato", body: "Appunti in verbale, procedura in FAQ" },
    ], 3, { y: 1.15, H: 2.85, headSize: 13, bodySize: 12 });
    txt(s, "Più profonda la trasformazione", { x: 0.5, y: 4.2, w: 2.6, h: 0.5, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 3.1, y: 4.29, w: 2.6, h: 0.32, fill: { color: C.accent5 }, line: { type: "none" }, objectName: "freccia rischio" });
    txt(s, "più alto il rischio di alterare il significato", { x: 5.85, y: 4.2, w: 3.65, h: 0.5, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
  }
  {
    const s = content("Semplificare senza tradire", "La semplificazione è una delle trasformazioni più utili e più delicate. Utile, perché molti testi aziendali, come procedure, regolamenti, documentazione tecnica e comunicazioni normative, sono difficili da leggere per chi deve applicarli. Delicata, perché semplificare significa scegliere che cosa togliere e come riformulare, e in queste scelte si nascondono i rischi. L'esempio fittizio in slide mostra una clausola di una procedura interna e una semplificazione apparentemente ben fatta. La versione semplificata è chiara e scorrevole, ma ha perso due elementi: il limite di importo oltre il quale serve l'autorizzazione, e l'eccezione per gli acquisti urgenti, che ha un iter diverso. Chi la legge applicherà la regola in modo sbagliato in due casi su tre. Il problema non è la semplificazione, ma la mancanza di controllo. Per semplificare in modo fedele conviene indicare esplicitamente che cosa deve restare, per esempio importi, scadenze, condizioni ed eccezioni, e poi confrontare punto per punto la versione semplificata con l'originale. Nei testi con valore normativo o contrattuale, la versione semplificata dovrebbe rimandare all'originale come riferimento valido.");
    modeTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 2.65, "Originale (esempio fittizio)", "Gli acquisti di importo superiore a 5.000 euro richiedono l'autorizzazione preventiva del responsabile di funzione e dell'ufficio acquisti. Per gli acquisti urgenti, documentati come tali, l'autorizzazione dell'ufficio acquisti può essere richiesta entro tre giorni lavorativi successivi.", { fontSize: 12 });
    docBox(s, 5.15, 1.15, 4.35, 2.65, "Versione semplificata", "Prima di fare un acquisto serve l'autorizzazione del proprio responsabile e dell'ufficio acquisti.", { fontSize: 13, fill: C.accent6 });
    chip(s, 5.35, 2.45, 1.95, 0.42, "Manca la soglia", { fill: C.accent5, color: C.background1, fontSize: 11 });
    chip(s, 7.4, 2.45, 1.9, 0.42, "Manca l'eccezione", { fill: C.accent5, color: C.background1, fontSize: 11 });
    banner(s, 4.0, "Chiara, scorrevole e sbagliata. Indicare che cosa deve restare e confrontare punto per punto con l'originale.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Tradurre e localizzare", "La traduzione è uno degli ambiti in cui i sistemi linguistici danno risultati migliori, soprattutto tra lingue molto diffuse. Ma tradurre un testo professionale non è solo cambiare lingua. La localizzazione adatta il testo al contesto del destinatario: formati di date, numeri e valute, unità di misura, riferimenti normativi o istituzionali che possono non avere un equivalente, convenzioni di cortesia, esempi culturalmente appropriati. Alcune attenzioni specifiche. La terminologia tecnica e aziendale: un termine di settore può avere più traduzioni possibili, e il sistema può sceglierne una diversa da quella usata in azienda o nel settore; conviene fornire un glossario. I falsi amici e le sfumature: termini simili con significato diverso, gradi di obbligo come 'deve' e 'dovrebbe', che in un contratto fanno una grande differenza. Le lingue meno diffuse, per cui la qualità può essere inferiore. I testi con valore legale o contrattuale, per cui una traduzione automatica non sostituisce la traduzione professionale certificata quando richiesta. Un controllo utile, quando non si conosce bene la lingua di arrivo, è far ritradurre il testo nella lingua originale da uno strumento diverso: non è una prova, ma fa emergere molti scostamenti di significato.");
    modeTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiGlobe", head: "Localizzare significa adattare", headSize: 15, bodySize: 13,
      body: bullets(["Date, numeri, valute, unità di misura", "Riferimenti normativi e istituzionali", "Convenzioni di cortesia, esempi culturali"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiAlertTriangle", head: "Attenzioni", headSize: 15, bodySize: 13, fill: C.accent6, iconBg: C.accent5,
      body: bullets(["Terminologia: fornire un glossario", "Sfumature: 'deve' e 'dovrebbe' non sono uguali", "Lingue meno diffuse, testi con valore legale"], { space: 4 }) });
    shapeBox(s, 0.5, 3.6, 9.0, 1.3, C.background2, "ritraduzione");
    await iconCircle(s, 0.7, 3.85, 0.6, "FiRepeat", C.accent1);
    txt(s, "Controllo utile se non si conosce la lingua di arrivo", { x: 1.5, y: 3.7, w: 7.8, h: 0.4, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Ritradurre nella lingua originale con uno strumento diverso: non è una prova, ma fa emergere molti scostamenti di significato.", { x: 1.5, y: 4.1, w: 7.8, h: 0.7, fontSize: 13, color: C.text2 });
  }
  {
    const s = content("Cambiare formato e struttura", "Due trasformazioni che cambiano l'organizzazione del contenuto più che le singole frasi. La trasformazione tra formati testuali porta lo stesso contenuto in una forma diversa, adatta a un altro uso: appunti di riunione in un verbale con decisioni e azioni; una relazione lunga in una sintesi per la direzione o in punti per una presentazione; una procedura in una lista di controllo o in FAQ; una email lunga in un messaggio breve; un testo in una tabella. La revisione della struttura riorganizza un testo esistente: mettere all'inizio le informazioni più importanti, aggiungere titoli e sezioni, raggruppare argomenti dispersi, eliminare ripetizioni, separare ciò che è obbligatorio da ciò che è consigliato. Sono trasformazioni molto utili, ma con un rischio specifico: nel cambiare forma, alcune informazioni possono andare perse o cambiare peso. Nel passaggio da appunti a verbale, per esempio, il sistema può trasformare un'ipotesi discussa in una decisione presa, o attribuire un'azione alla persona sbagliata. Nel passaggio da testo a elenco puntato, i legami logici, come 'solo se' o 'a meno che', possono sparire. Il controllo consiste nel verificare che ogni elemento importante dell'originale sia presente, con lo stesso peso e lo stesso significato.");
    modeTag(s, 1);
    const tr = [["Appunti", "Verbale con decisioni e azioni"], ["Relazione lunga", "Sintesi per la direzione"], ["Procedura", "Lista di controllo o FAQ"], ["Testo continuo", "Tabella o elenco"]];
    tr.forEach((e, i) => {
      const y = 1.15 + i * 0.6;
      chip(s, 0.5, y, 1.9, 0.5, e[0], { fill: C.background2, fontSize: 12 });
      arrow(s, 2.5, y + 0.09, 0.35);
      chip(s, 2.95, y, 2.35, 0.5, e[1], { fill: C.accent6, fontSize: 12 });
    });
    await card(s, 5.55, 1.15, 3.95, 2.3, { icon: "FiAlertTriangle", inline: true, head: "Che cosa può succedere", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Un'ipotesi discussa diventa una decisione", "Un'azione attribuita alla persona sbagliata", "Spariscono 'solo se' e 'a meno che'", "Un dettaglio secondario diventa centrale"], { space: 4 }) });
    banner(s, 3.75, "Controllo: ogni elemento importante dell'originale è presente, con lo stesso peso e lo stesso significato?", { h: 0.75, fontSize: 13 });
    txt(s, "Revisione della struttura: informazioni importanti all'inizio, titoli, raggruppamenti, obbligatorio separato da consigliato.", { x: 0.5, y: 4.6, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Modifiche formali e sostanziali", "La distinzione chiave del sottotema. Una modifica formale cambia il modo in cui una cosa è detta, senza cambiare che cosa è detto: correggere un refuso, spezzare una frase lunga, sostituire un termine con un sinonimo davvero equivalente, riordinare elementi senza legami logici. Una modifica sostanziale cambia il contenuto: un'informazione aggiunta o tolta, un grado di obbligo modificato, una condizione eliminata, un'attribuzione cambiata, un numero alterato. Il problema è che molte modifiche che sembrano formali sono in realtà sostanziali. La tabella mostra alcuni esempi. Passare da 'entro il 15' a 'verso metà mese' sembra una semplificazione, ma cambia una scadenza in un'indicazione vaga. Passare da 'si raccomanda' a 'è obbligatorio' sembra una riformulazione, ma cambia il grado di obbligo. Passare da 'in alcuni casi' a 'spesso' cambia la frequenza. Eliminare 'salvo diversa indicazione' cancella un'eccezione. Quando si chiede una trasformazione, conviene esplicitare il tipo di modifiche ammesse, per esempio 'correggi solo grammatica e punteggiatura, non cambiare contenuti'. E chiedere al sistema di segnalare le modifiche sostanziali che ritiene necessarie, invece di applicarle.");
    modeTag(s, 1);
    table(s, [["Originale", "Trasformato", "Che cosa è cambiato"],
      ["Entro il 15 del mese", "Verso metà mese", "Una scadenza diventa vaga"],
      ["Si raccomanda di...", "È obbligatorio...", "Il grado di obbligo"],
      ["In alcuni casi", "Spesso", "La frequenza"],
      ["Salvo diversa indicazione, ...", "(eliminato)", "Un'eccezione cancellata"],
      ["Il fornitore propone", "Il fornitore garantisce", "Un impegno attribuito"]],
      { y: 1.15, colW: [3.0, 2.7, 3.3], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 2 });
    banner(s, 3.85, "Esplicitare le modifiche ammesse e chiedere di segnalare, non applicare, quelle sostanziali.", { h: 0.6, fontSize: 13 });
    txt(s, "Molte modifiche che sembrano formali sono sostanziali.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Preservare il significato originale", "Come si controlla, in pratica, che una trasformazione abbia preservato il significato? Alcune tecniche, dalla più semplice alla più strutturata. Primo, definire in anticipo che cosa deve restare invariato: importi, date, scadenze, nomi, condizioni, eccezioni, gradi di obbligo, impegni. Sono gli elementi più a rischio e quelli con le conseguenze più serie. Secondo, chiedere al sistema di elencare le modifiche apportate, distinguendo quelle formali da quelle che potrebbero toccare il contenuto. Non è una garanzia, come visto nel Tema 7, ma aiuta a dirigere l'attenzione. Terzo, usare il confronto tra versioni, con gli strumenti di revisione dei programmi di scrittura, per vedere esattamente che cosa è cambiato. Quarto, per i testi importanti, rileggere l'originale e il trasformato affiancati, punto per punto, controllando gli elementi critici. Quinto, per i testi con valore normativo, contrattuale o tecnico, far validare la versione trasformata da chi conosce la materia, e mantenere l'originale come riferimento. Il principio è semplice: più il testo ha conseguenze, più il confronto con l'originale deve essere sistematico.");
    modeTag(s, 1);
    numList(s, ["Definire in anticipo che cosa non deve cambiare: importi, date, condizioni, eccezioni, obblighi", "Chiedere l'elenco delle modifiche, formali e potenzialmente sostanziali", "Usare il confronto tra versioni per vedere che cosa è cambiato", "Rileggere originale e trasformato affiancati, sui punti critici", "Per testi normativi, contrattuali o tecnici: validazione esperta, originale come riferimento"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "Più il testo ha conseguenze, più il confronto con l'originale deve essere sistematico.", { h: 0.65, fontSize: 13 });
  }
  keySlide("Trasformare un testo richiede di controllare che la nuova formulazione non alteri significati, intenzioni o informazioni rilevanti.", "Sottotema 8.2  ·  Revisione, riscrittura e trasformazione", "Concetto chiave del secondo sottotema. Trasformare un testo esistente è spesso preferibile a generarlo da zero, perché riduce le invenzioni e offre un originale con cui confrontare il risultato. Le trasformazioni possibili sono molte: correzione, chiarezza, semplificazione, riformulazione, traduzione, cambio di formato e di struttura. Il rischio comune è l'alterazione del significato, spesso nascosta in modifiche che sembrano formali. Il concetto chiave cita anche le intenzioni: un testo riformulato può dire le stesse cose con un'intenzione diversa, per esempio più perentoria o più accomodante. Esercizio suggerito: dare ai partecipanti un paragrafo fittizio di procedura, farlo semplificare con l'AI e chiedere di trovare tutte le differenze di contenuto tra originale e semplificato.");

  // =====================================================================
  section("8.3 Sintesi e analisi");
  divider("8.3", "Sintesi e analisi documentale", "Una sintesi utile rappresenta fedelmente gli elementi essenziali e consente controlli sui contenuti originali", "Entriamo nel nucleo distintivo del tema. Con i sottotemi 8.3, 8.4 e 8.5 l'AI non produce testi nuovi né riscrive testi esistenti: lavora sui documenti per ricavarne qualcosa. In questo sottotema, da comprendere e sperimentare, vediamo la sintesi e l'analisi dei documenti: riassunti, sintesi esecutive, individuazione dei concetti e dei passaggi rilevanti, analisi di documentazione tecnica e organizzativa. E due integrazioni importanti: la tracciabilità, cioè la possibilità di risalire ai passaggi originali, e il rischio di perdita di significato, cioè sintesi che sembrano fedeli ma hanno eliminato elementi decisivi.");
  {
    const s = content("Le possibilità su un documento", "Le possibilità dell'AI nella sintesi e nell'analisi di documenti sono molte e, per chi lavora con grandi quantità di materiale, di grande valore. Riassumere: ridurre un documento ai suoi contenuti principali, con lunghezza e livello di dettaglio scelti. Sintetizzare contenuti lunghi e articolati: rapporti, verbali di più riunioni, documentazione di progetto. Identificare i concetti principali: i temi, le tesi, le decisioni, le richieste. Individuare informazioni e passaggi rilevanti: dove il documento parla di un certo argomento, che cosa dice su penali, scadenze, responsabilità. Produrre sintesi esecutive: una pagina per chi deve decidere, con ciò che serve sapere. Analizzare documentazione tecnica e organizzativa: capire che cosa prevede una procedura, che cosa richiede un capitolato, quali sono i punti aperti di un progetto. I sistemi attuali possono lavorare con i formati più comuni, come PDF, Word e testo, e molti accettano più documenti insieme. Il valore principale è il tempo: un primo orientamento su un documento di cento pagine in pochi minuti. Ma, come vedremo, un primo orientamento non è una lettura completa.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiAlignLeft", head: "Riassumere", body: "Contenuti principali, lunghezza e dettaglio scelti" },
      { icon: "FiTarget", head: "Concetti principali", body: "Temi, tesi, decisioni, richieste" },
      { icon: "FiSearch", head: "Passaggi rilevanti", body: "Dove e che cosa dice su penali, scadenze, responsabilità" },
      { icon: "FiBriefcase", head: "Sintesi esecutive", body: "Una pagina per chi deve decidere" },
      { icon: "FiTool", head: "Documentazione tecnica", body: "Procedure, capitolati, specifiche" },
      { icon: "FiFile", head: "Formati diversi", body: "PDF, Word, testo; spesso più documenti insieme" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Un primo orientamento su cento pagine in pochi minuti. Ma un orientamento non è una lettura completa.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Sintesi diverse per scopi diversi", "Non esiste la sintesi giusta in assoluto: esiste la sintesi adatta a uno scopo. Lo stesso documento, per esempio un contratto di fornitura, può essere sintetizzato in modi molto diversi. Una sintesi informativa generale riassume di che cosa parla e quali sono i contenuti principali: utile per orientarsi. Una sintesi esecutiva evidenzia ciò che serve a chi deve decidere: condizioni economiche, durata, rischi, punti da negoziare. Una sintesi operativa estrae ciò che serve a chi deve applicare il documento: scadenze, adempimenti, responsabilità, contatti. Una sintesi mirata risponde a una domanda specifica: che cosa prevede il contratto in caso di ritardo nelle consegne? Dichiarare lo scopo della sintesi, come visto nel Tema 6, migliora molto il risultato, perché guida il sistema nella scelta di che cosa tenere. Senza indicazioni, il sistema tende a produrre una sintesi generica, equilibrata in apparenza, che dà lo stesso spazio a elementi importanti e secondari, e può trascurare proprio ciò che serviva. Lo scopo determina anche il controllo: una sintesi per orientarsi richiede meno verifica di una sintesi su cui si basa una decisione.");
    modeTag(s, 2);
    table(s, [["Tipo di sintesi", "A chi serve", "Che cosa evidenzia"],
      ["Informativa", "A chi deve orientarsi", "Di che cosa parla, contenuti principali"],
      ["Esecutiva", "A chi deve decidere", "Condizioni, rischi, punti da negoziare"],
      ["Operativa", "A chi deve applicare", "Scadenze, adempimenti, responsabilità"],
      ["Mirata", "A chi ha una domanda", "Solo ciò che risponde alla domanda"]],
      { y: 1.15, colW: [2.2, 2.8, 4.0], rowH: 0.48, fontSize: 13, blankCorner: false });
    banner(s, 3.8, "Dichiarare lo scopo guida la scelta di che cosa tenere. Senza scopo, la sintesi è generica e può trascurare proprio ciò che serviva.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Tracciabilità: risalire alle fonti", "Prima integrazione del sottotema: la tracciabilità delle informazioni e il collegamento alle fonti. Una sintesi è tanto più utile quanto più permette, quando serve, di risalire ai passaggi del documento originale. Se una sintesi dice che il contratto prevede una penale del 2 per cento per ogni settimana di ritardo, poter andare subito all'articolo e al paragrafo in cui lo dice trasforma un'affermazione da prendere sulla fiducia in un'affermazione controllabile in pochi secondi. Per questo, quando l'uso lo richiede, conviene chiedere esplicitamente che ogni punto della sintesi indichi la sezione, l'articolo, la pagina o il passaggio da cui deriva, e, per i punti critici, anche una breve citazione testuale. L'esempio fittizio in slide mostra una sintesi con riferimenti. Il vantaggio è doppio: rende la verifica rapida e mirata, e rende visibili i punti della sintesi che non hanno un riferimento, che sono quelli da trattare con più cautela, perché potrebbero essere interpretazioni del sistema o informazioni non presenti nel documento. La tracciabilità è richiesta anche da molti strumenti aziendali di consultazione documentale, come vedremo nell'8.7.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 5.6, 2.9, "Sintesi con riferimenti (esempio fittizio)", "", { fill: C.background2 });
    const pts = [["Durata: tre anni, rinnovo tacito annuale", "art. 4.1"], ["Penale: 2% per settimana di ritardo, massimo 10%", "art. 9.2"], ["Recesso: preavviso di 90 giorni", "art. 12.1"], ["Esclusiva territoriale per il Nord Italia", "nessun riferimento"]];
    pts.forEach((p, i) => {
      const y = 1.62 + i * 0.58;
      const none = i === 3;
      txt(s, p[0], { x: 0.75, y, w: 3.75, h: 0.48, fontSize: 12, color: C.text1, valign: "middle" });
      chip(s, 4.55, y + 0.06, 1.4, 0.36, p[1], { fill: none ? C.accent5 : C.accent1, color: C.background1, fontSize: 10 });
    });
    await card(s, 6.35, 1.15, 3.15, 2.9, { icon: "FiLink", head: "Perché conta", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Verifica in pochi secondi", "Si vede subito ciò che non ha riferimento", "Per i punti critici: anche la citazione testuale"], { space: 5 }) });
    banner(s, 4.25, "Un punto senza riferimento va trattato con più cautela: può essere un'interpretazione o non essere nel documento.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Riferimenti davvero controllabili", "La seconda parte dell'integrazione sulla tracciabilità è un'avvertenza: un riferimento presentato dall'AI deve essere realmente controllabile. Non basta che la sintesi contenga dei riferimenti: occorre che siano corretti. I sistemi possono indicare un articolo sbagliato, un numero di pagina approssimativo, una sezione che non esiste, o una citazione testuale che in realtà è una parafrasi, magari con piccole differenze di significato. È lo stesso fenomeno visto nel Tema 3 per le fonti inventate, applicato ai riferimenti interni a un documento. Per i numeri di pagina, in particolare, l'affidabilità dipende dal formato del documento e dal modo in cui lo strumento lo elabora. Il controllo, per i punti importanti, è semplice: aprire il documento nel punto indicato e leggere il passaggio. Tre verifiche, coerenti con quelle viste nel Tema 7 per le fonti: il passaggio esiste nel punto indicato; dice ciò che la sintesi afferma, con le stesse condizioni; la citazione, se presentata come testuale, corrisponde parola per parola. Un buon segnale pratico: gli strumenti che mostrano direttamente il passaggio citato, con un collegamento cliccabile al documento, rendono questo controllo molto più rapido.");
    modeTag(s, 2);
    const ck = [["FiMapPin", "Esiste", "Il passaggio è nel punto indicato?"], ["FiCheckCircle", "Sostiene", "Dice ciò che la sintesi afferma, con le stesse condizioni?"], ["FiType", "Corrisponde", "La citazione testuale è davvero parola per parola?"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 1.9, C.background2, ck[i][1]);
      await iconCircle(s, x + 1.08, 1.32, 0.7, ck[i][0]);
      txt(s, (i + 1) + ". " + ck[i][1], { x: x + 0.15, y: 2.08, w: 2.56, h: 0.38, fontSize: 16, bold: true, color: C.text1, align: "center" });
      txt(s, ck[i][2], { x: x + 0.2, y: 2.46, w: 2.46, h: 0.6, fontSize: 12, color: C.text2, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.0, 0.17);
    }
    await card(s, 0.5, 3.3, 9.0, 1.65, { icon: "FiAlertTriangle", inline: true, head: "Che cosa può andare storto", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: "Articolo sbagliato, pagina approssimativa, sezione inesistente, parafrasi presentata come citazione. Lo stesso fenomeno delle fonti inventate, dentro un singolo documento." });
  }
  {
    const s = content("Il rischio di perdita di significato", "Seconda integrazione, forse la più importante del tema: il rischio di perdita di significato nella sintesi. Una sintesi può apparire fedele pur avendo eliminato eccezioni, vincoli, sfumature o elementi decisivi. Il motivo è intrinseco: sintetizzare significa togliere, e il sistema sceglie che cosa togliere secondo criteri che non conosciamo e che non coincidono necessariamente con ciò che per noi è importante. Gli elementi più a rischio sono proprio quelli che, in un testo, occupano poco spazio ma hanno grande peso: una condizione introdotta da 'solo se', un'eccezione introdotta da 'salvo', una negazione, un limite numerico, una scadenza, un'attribuzione di responsabilità, un'espressione di incertezza come 'in via preliminare' o 'da confermare'. L'esempio fittizio in slide mostra un estratto di verbale e una sintesi che sembra corretta: ogni frase è vera, ma la decisione appare definitiva, mentre era condizionata all'approvazione del budget, e l'incertezza sui tempi è sparita. Chi legge la sintesi crede che il progetto sia approvato. Il punto chiave è che queste perdite non si vedono leggendo la sintesi: la sintesi è scorrevole, coerente, ben organizzata. Si vedono solo confrontandola con l'originale, o sapendo che cosa cercare.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 4.35, 2.6, "Verbale originale (esempio fittizio)", "Il comitato approva in via preliminare l'avvio del progetto, subordinatamente all'approvazione del budget nella riunione di aprile. I tempi di consegna indicati dal fornitore sono da confermare.", { fontSize: 12 });
    docBox(s, 5.15, 1.15, 4.35, 2.6, "Sintesi", "Il comitato ha approvato l'avvio del progetto. Sono stati discussi budget e tempi di consegna.", { fontSize: 13, fill: C.accent6 });
    chip(s, 5.35, 2.5, 1.95, 0.42, "Condizione persa", { fill: C.accent5, color: C.background1, fontSize: 11 });
    chip(s, 7.4, 2.5, 1.9, 0.42, "Incertezza persa", { fill: C.accent5, color: C.background1, fontSize: 11 });
    banner(s, 3.95, "Ogni frase è vera, ma chi legge crede che il progetto sia approvato. La perdita non si vede leggendo la sintesi.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Dove si perde il significato", "Per controllare una sintesi in modo efficiente, conviene sapere dove cercare. Gli elementi più a rischio sono quelli che occupano poco spazio nel testo ma cambiano le conseguenze. Condizioni: 'solo se', 'a condizione che', 'subordinatamente a'. Eccezioni: 'salvo', 'tranne', 'ad eccezione di'. Limiti e soglie: importi massimi, percentuali, quantità. Scadenze e tempi: date, termini, durate, preavvisi. Responsabilità: chi deve fare che cosa, chi risponde di che cosa. Gradi di certezza e di obbligo: 'in via preliminare', 'da confermare', 'si raccomanda', 'è obbligatorio'. Negazioni e limitazioni: 'non si applica', 'esclusivamente', 'non oltre'. Posizioni minoritarie o dissenzienti: in un verbale, un'obiezione registrata; in un rapporto, un rischio segnalato in una nota. Una tecnica pratica è chiedere al sistema, insieme alla sintesi, un elenco separato di tutte le condizioni, eccezioni, scadenze e limiti presenti nel documento, con il riferimento. È più facile controllare un elenco mirato che cercare le perdite in una sintesi scorrevole.");
    modeTag(s, 2);
    const it = [["Condizioni", "solo se, a condizione che"], ["Eccezioni", "salvo, tranne"], ["Limiti e soglie", "importi, percentuali"], ["Scadenze", "date, termini, preavvisi"], ["Responsabilità", "chi fa che cosa"], ["Certezza e obbligo", "da confermare, è obbligatorio"], ["Negazioni", "non si applica, esclusivamente"], ["Voci minoritarie", "obiezioni, rischi in nota"]];
    it.forEach((e, i) => {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.15 + row * 1.1;
      shapeBox(s, x, y, 2.15, 0.98, row === 0 ? C.background2 : C.accent6, e[0]);
      txt(s, e[0], { x: x + 0.15, y: y + 0.1, w: 1.9, h: 0.36, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: y + 0.48, w: 1.9, h: 0.42, fontSize: 11, italic: true, color: C.text2 });
    });
    banner(s, 3.5, "Tecnica pratica: chiedere, insieme alla sintesi, un elenco di tutte le condizioni, eccezioni, scadenze e limiti, con il riferimento.", { h: 0.8, fontSize: 13 });
    txt(s, "È più facile controllare un elenco mirato che cercare le perdite in una sintesi scorrevole.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text2 });
  }
  {
    const s = content("Controllare una sintesi", "Mettiamo insieme le tecniche viste in una procedura di controllo, da applicare con intensità proporzionata all'uso della sintesi. Prima di chiedere la sintesi: dichiarare lo scopo e indicare gli elementi che devono essere presenti, come condizioni, scadenze, importi, responsabilità. Durante: chiedere i riferimenti ai passaggi originali e un elenco separato di condizioni ed eccezioni. Dopo, per una sintesi usata per orientarsi, basta una lettura critica: è plausibile? Manca qualcosa che ci si aspetterebbe? Per una sintesi su cui si basa una decisione o un'azione, conviene controllare sul documento i punti critici, usando i riferimenti, e verificare che condizioni ed eccezioni importanti siano state riportate. Per una sintesi destinata ad altri, specie all'esterno o a chi non leggerà l'originale, conviene un controllo sistematico, e indicare nella sintesi stessa che si tratta di una sintesi e dove trovare l'originale. Un principio di fondo: chi legge una sintesi tende a considerarla equivalente al documento. Più la sintesi sostituisce la lettura dell'originale, più deve essere controllata.");
    modeTag(s, 2);
    const ph = [["Prima", ["Dichiarare lo scopo", "Indicare gli elementi da includere"]], ["Durante", ["Chiedere i riferimenti", "Elenco separato di condizioni ed eccezioni"]], ["Dopo", ["Controllo proporzionato all'uso", "Punti critici verificati sul documento"]]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.0, i === 2 ? C.accent6 : C.background2, ph[i][0]);
      txt(s, ph[i][0], { x: x + 0.2, y: 1.25, w: 2.46, h: 0.42, fontSize: 18, bold: true, color: C.accent1 });
      txt(s, bullets(ph[i][1], { space: 6 }), { x: x + 0.2, y: 1.75, w: 2.5, h: 1.3, fontSize: 13, color: C.text1 });
      if (i < 2) arrow(s, x + 2.88, 1.95, 0.17);
    }
    chip(s, 0.5, 3.35, 2.9, 0.55, "Per orientarsi: lettura critica", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.35, 2.9, 0.55, "Per decidere: punti critici", { fill: C.accent6, fontSize: 12 });
    chip(s, 6.6, 3.35, 2.9, 0.55, "Per altri: controllo sistematico", { fill: C.accent1, color: C.background1, fontSize: 12 });
    banner(s, 4.1, "Più la sintesi sostituisce la lettura dell'originale, più deve essere controllata.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Limiti con documenti complessi", "Il sottotema chiede anche di conoscere i limiti dell'analisi di documentazione complessa, che approfondiremo nell'8.8. Ne anticipiamo i principali, per come incidono sulla sintesi. Documenti molto lunghi: anche quando il sistema accetta il documento intero, non è detto che ne consideri tutte le parti con la stessa attenzione. Studi sui modelli linguistici hanno mostrato che le informazioni al centro di testi lunghi tendono a essere usate meno di quelle all'inizio e alla fine. Rimandi interni e allegati: un contratto in cui l'articolo 9 rimanda all'allegato C, che a sua volta modifica l'articolo 4, richiede di collegare parti lontane, e qui gli errori sono più frequenti. Tabelle, grafici e impaginazioni complesse: possono essere lette in modo incompleto o scorretto. Linguaggio tecnico e specialistico: il sistema può riassumere in modo scorrevole un contenuto che non interpreta correttamente. Più documenti insieme: aumentano il rischio di confondere a quale documento appartiene un'informazione. In tutti questi casi, la sintesi resta utile come primo orientamento, ma la lettura dei passaggi critici diventa indispensabile.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiBookOpen", head: "Documenti molto lunghi", body: "Le parti centrali tendono a essere usate meno" },
      { icon: "FiCornerDownRight", head: "Rimandi e allegati", body: "Collegare parti lontane aumenta gli errori" },
      { icon: "FiGrid", head: "Tabelle e impaginazioni", body: "Lette in modo incompleto o scorretto" },
      { icon: "FiCpu", head: "Linguaggio specialistico", body: "Riassunto scorrevole, interpretazione errata" },
      { icon: "FiFolder", head: "Più documenti insieme", body: "Informazioni attribuite al documento sbagliato" },
      { icon: "FiArrowRight", head: "Approfondimento", body: "Nel sottotema 8.8" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "La sintesi resta un primo orientamento: la lettura dei passaggi critici diventa indispensabile.", { h: 0.6, fontSize: 13 });
  }
  keySlide("Una sintesi utile deve rappresentare fedelmente gli elementi essenziali e consentire controlli sui contenuti originali quando richiesto dall'utilizzo previsto.", "Sottotema 8.3  ·  Sintesi e analisi documentale", "Concetto chiave del sottotema 8.3. L'AI offre grandi possibilità nella sintesi e nell'analisi dei documenti: riassunti, sintesi esecutive e operative, individuazione di concetti e passaggi rilevanti. Ma una sintesi va pensata per uno scopo, deve permettere di risalire ai passaggi originali con riferimenti realmente controllabili, e può perdere proprio gli elementi che contano di più: condizioni, eccezioni, limiti, scadenze, gradi di certezza. Il controllo va proporzionato all'uso: più la sintesi sostituisce la lettura dell'originale, più va verificata. Esercizio suggerito: dare ai partecipanti un documento fittizio di due o tre pagine con alcune condizioni ed eccezioni, farlo sintetizzare con l'AI, e chiedere di verificare quali elementi decisivi sono stati conservati e quali persi.");

  // =====================================================================
  section("8.4 Estrazione");
  divider("8.4", "Estrazione e strutturazione delle informazioni", "Un dato estratto non è automaticamente un dato validato", "Passiamo dalla sintesi all'estrazione. Qui l'obiettivo non è ridurre un documento, ma ricavarne informazioni puntuali e organizzarle in una struttura: una tabella, un elenco di campi, una classificazione. È una delle possibilità più concrete e meno conosciute dell'AI generativa, perché permette di trasformare testi non strutturati, come email, contratti, moduli, verbali, in dati utilizzabili da attività successive. In questo sottotema, da comprendere e sperimentare, vediamo che cosa si può estrarre, come si passa dal testo al dato, come gestire campi mancanti o ambigui e, soprattutto, come controllare la qualità dell'estrazione prima di usarla.");
  {
    const s = content("Sintetizzare o estrarre?", "Una domanda guida chiede la differenza tra sintetizzare un documento ed estrarne dati strutturati. La distinzione, indicata anche dal documento di perimetro, è netta. La sintesi produce un testo più breve, che interpreta e seleziona i contenuti: il risultato si legge. L'estrazione produce dati puntuali, organizzati in campi definiti in anticipo, come nome del fornitore, data di scadenza, importo, numero d'ordine: il risultato si usa, per esempio in una tabella, in un confronto, in un sistema gestionale, in un'analisi. Le due attività hanno esigenze diverse. La sintesi richiede di non perdere significato; l'estrazione richiede precisione su ogni singolo valore e completezza su tutti i documenti. In una sintesi, un piccolo errore può passare inosservato senza grandi conseguenze; in un'estrazione, un importo sbagliato o una data invertita entra in un foglio di calcolo e da lì in decisioni e processi, spesso senza che nessuno torni più a guardare il documento originale. Per questo il controllo dell'estrazione è diverso: non si valuta la fedeltà complessiva, ma l'accuratezza campo per campo.");
    modeTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiAlignLeft", head: "Sintesi", headSize: 17, bodySize: 13,
      body: bullets(["Un testo più breve che interpreta e seleziona", "Il risultato si legge", "Rischio: perdita di significato", "Controllo: fedeltà complessiva"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiGrid", head: "Estrazione", headSize: 17, bodySize: 13, fill: C.accent6,
      body: bullets(["Dati puntuali in campi definiti", "Il risultato si usa in attività successive", "Rischio: valore errato, mancante, inventato", "Controllo: accuratezza campo per campo"], { space: 4 }) });
    banner(s, 3.95, "Un importo sbagliato entra in un foglio di calcolo, e da lì in decisioni e processi, spesso senza che nessuno torni al documento.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Che cosa si può estrarre", "Le possibilità di estrazione sono molte. Informazioni anagrafiche e identificative: nomi di persone e aziende, ruoli, indirizzi, codici, numeri di documento. Date e scadenze: data del documento, decorrenza, termini, rinnovi. Importi e quantità: prezzi, totali, sconti, penali, quantità ordinate. Riferimenti: numeri d'ordine, di contratto, di pratica, rimandi normativi. Classificazioni: il tipo di richiesta in un'email, l'argomento di un reclamo, il livello di urgenza, il reparto competente. Elementi ricorrenti: i motivi più frequenti di reclamo in cento email, le clausole presenti o assenti in un gruppo di contratti, i temi che ricorrono in una serie di verbali. Le prime quattro categorie riguardano informazioni esplicitamente scritte nel testo, e l'estrazione è relativamente affidabile, pur con errori possibili. Le ultime due richiedono un'interpretazione: classificare significa giudicare, e due persone potrebbero classificare diversamente la stessa email. In questi casi, la qualità dipende molto dalla chiarezza delle categorie e dei criteri forniti.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiUser", head: "Nomi e identificativi", body: "Persone, aziende, ruoli, codici" },
      { icon: "FiCalendar", head: "Date e scadenze", body: "Decorrenze, termini, rinnovi" },
      { icon: "FiDollarSign", head: "Importi e quantità", body: "Prezzi, totali, sconti, penali" },
      { icon: "FiHash", head: "Riferimenti", body: "Ordini, contratti, pratiche, norme" },
      { icon: "FiTag", head: "Classificazioni", body: "Tipo di richiesta, argomento, urgenza", fill: C.accent6 },
      { icon: "FiBarChart2", head: "Elementi ricorrenti", body: "Motivi frequenti, clausole presenti o assenti", fill: C.accent6 },
    ], 3, { y: 1.15, H: 2.95, headSize: 13, bodySize: 12 });
    chip(s, 0.5, 4.3, 5.95, 0.6, "Informazioni esplicite nel testo: estrazione più affidabile", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 4.3, 2.9, 0.6, "Richiedono interpretazione", { fill: C.accent6, fontSize: 12 });
  }
  {
    const s = content("Dal non strutturato al dato utilizzabile", "Prima integrazione del sottotema: dall'informazione non strutturata al dato utilizzabile. Gran parte delle informazioni aziendali vive in testi: email, contratti, moduli compilati a mano o in formato libero, verbali, segnalazioni, curricula, offerte. Sono informazioni preziose, ma difficili da usare in modo sistematico: per sapere quanti contratti scadono nel prossimo trimestre, bisogna aprirli uno per uno. L'AI può trasformare questi testi in campi e categorie riutilizzabili. L'esempio fittizio in slide mostra un'email di un cliente trasformata in un record strutturato: cliente, numero d'ordine, tipo di richiesta, prodotto, data richiesta, urgenza. Su cento email, questo produce una tabella che si può ordinare, filtrare, contare, collegare ad altri dati. È il passaggio che rende utilizzabile da attività successive un'informazione che prima era solo leggibile. La condizione, indicata esplicitamente dal documento di perimetro, è che la qualità dell'estrazione sia controllata prima dell'impiego operativo. L'analisi quantitativa dei dati così ottenuti appartiene al Tema 9; i flussi automatici che fanno questo in modo continuo, al Tema 11.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 4.1, 2.85, "Email del cliente (esempio fittizio)", "Buongiorno, vi scrivo per l'ordine 4471 del 12 marzo. Le sedie modello Alfa sono arrivate, ma due su dieci hanno la seduta danneggiata. Avremmo bisogno della sostituzione entro fine mese, perché abbiamo un evento. Grazie, M. Rossi, Studio Bianchi", { fontSize: 12 });
    arrow(s, 4.7, 2.4, 0.4);
    table(s, [["Campo", "Valore"], ["Cliente", "Studio Bianchi"], ["Ordine", "4471"], ["Tipo richiesta", "Sostituzione"], ["Prodotto", "Sedia Alfa, 2 pezzi"], ["Scadenza", "Fine mese"], ["Urgenza", "Alta"]],
      { x: 5.2, y: 1.15, w: 4.3, colW: [1.6, 2.7], rowH: 0.4, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 4.2, "Da informazione leggibile a dato utilizzabile: ordinare, filtrare, contare, collegare. Purché l'estrazione sia controllata prima dell'uso.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Classificare e trovare ricorrenze", "Due forme di strutturazione che vanno oltre l'estrazione di singoli valori. La classificazione assegna ogni contenuto a una categoria: il tipo di richiesta, il reparto competente, il tema di un reclamo, il livello di priorità. Le ricorrenze emergono confrontando molti contenuti: quali problemi si ripetono nelle segnalazioni, quali clausole compaiono in tutti i contratti tranne uno, quali argomenti tornano nelle riunioni. Sono utilizzi di grande valore perché permettono di vedere schemi che in una lettura documento per documento sfuggono. Ma richiedono attenzione a tre aspetti. Le categorie devono essere definite bene: se non sono chiare e mutuamente esclusive, il sistema le applicherà in modo incoerente, e anche due persone farebbero lo stesso. Conviene fornire per ogni categoria una definizione e qualche esempio, e prevedere una categoria 'altro' o 'non classificabile', per evitare forzature. La coerenza va controllata: lo stesso tipo di contenuto deve finire sempre nella stessa categoria, anche in documenti elaborati in momenti diversi. I conteggi vanno verificati: se il sistema dice che il 40 per cento dei reclami riguarda le consegne, conviene controllare su un campione, perché i numeri su grandi insiemi sono tra gli errori più difficili da notare.");
    modeTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 1.75, { icon: "FiTag", inline: true, head: "Classificare", headSize: 15, bodySize: 13, body: "Assegnare ogni contenuto a una categoria: tipo, reparto, tema, priorità." });
    await card(s, 5.15, 1.2, 4.35, 1.75, { icon: "FiRepeat", inline: true, head: "Trovare ricorrenze", headSize: 15, bodySize: 13, fill: C.accent6, body: "Schemi che si ripetono in molti contenuti e sfuggono alla lettura singola." });
    const at = [["Categorie ben definite", "Definizione ed esempi per ognuna, più 'altro' o 'non classificabile'"], ["Coerenza", "Lo stesso contenuto sempre nella stessa categoria"], ["Conteggi verificati", "Controllare le percentuali su un campione"]];
    at.forEach((e, i) => {
      const y = 3.15 + i * 0.6;
      shapeBox(s, 0.5, y, 9.0, 0.52, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.6, h: 0.52, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.3, y, w: 6.0, h: 0.52, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Campi mancanti o ambigui", "Uno degli aspetti più importanti dell'estrazione, e uno dei più trascurati, è che cosa succede quando l'informazione cercata non c'è o non è chiara. Il rischio principale è che il sistema, invece di lasciare il campo vuoto, lo riempia con un valore plausibile: una data dedotta, un importo calcolato, un nome preso da un'altra parte del documento. È il comportamento visto nel Tema 3: il sistema tende a produrre una risposta piuttosto che dichiarare che non c'è. In un'estrazione, questo è particolarmente pericoloso, perché un valore inventato in una tabella ha lo stesso aspetto di un valore estratto. La soluzione è definire in anticipo regole esplicite. Se l'informazione non è presente, il campo resta vuoto o riporta 'non presente', mai un valore stimato. Se l'informazione è ambigua, per esempio due date diverse o un importo con e senza IVA, il campo riporta 'ambiguo' con una nota che spiega perché. Se il valore è stato dedotto e non letto, per esempio una scadenza calcolata dalla data di inizio e dalla durata, va segnalato come dedotto. Queste tre etichette rendono visibili i casi da controllare e impediscono che un'incertezza diventi un dato apparentemente certo.");
    modeTag(s, 2);
    const rl = [["Non presente", "Il campo resta vuoto o riporta 'non presente', mai un valore stimato", C.background2], ["Ambiguo", "Più valori possibili: si riporta 'ambiguo' con una nota", C.accent6], ["Dedotto", "Valore calcolato, non letto: va segnalato come tale", C.background2]];
    rl.forEach((r, i) => {
      const y = 1.15 + i * 0.8;
      shapeBox(s, 0.5, y, 5.5, 0.7, r[2], r[0]);
      chip(s, 0.65, y + 0.14, 1.6, 0.42, r[0], { fill: C.accent1, color: C.background1, fontSize: 12 });
      txt(s, r[1], { x: 2.4, y, w: 3.5, h: 0.7, fontSize: 12, color: C.text1, valign: "middle" });
    });
    shapeBox(s, 6.25, 1.15, 3.25, 2.3, C.text1, "rischio");
    txt(s, "Il rischio", { x: 6.45, y: 1.25, w: 2.9, h: 0.38, fontSize: 15, bold: true, color: C.accent6 });
    txt(s, "Un valore inventato in una tabella ha lo stesso aspetto di un valore estratto.", { x: 6.45, y: 1.7, w: 2.9, h: 1.6, fontSize: 13, color: C.background1 });
    banner(s, 3.75, "Regole definite in anticipo rendono visibili i casi da controllare: un'incertezza non deve diventare un dato apparentemente certo.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Accuratezza e completezza", "Come si verifica un'estrazione? Due dimensioni distinte. L'accuratezza: i valori estratti corrispondono a quelli del documento? Errori tipici: cifre invertite, importi con o senza IVA confusi, date in formato diverso interpretate male, come 03/04 letto come 3 aprile o 4 marzo, valori presi dal punto sbagliato del documento, nomi storpiati. La completezza: sono stati estratti tutti i documenti, tutte le righe, tutti i campi? Errori tipici: documenti saltati, righe di una tabella omesse, campi lasciati vuoti anche se l'informazione c'era. Tecniche di controllo pratiche. Controllo a campione: confrontare con gli originali una parte dei record, scelti a caso e tra quelli con valori anomali; se il campione rivela errori, allargare il controllo. Controllo dei conteggi: il numero di record corrisponde al numero di documenti? Le somme tornano con un totale noto? Controllo di plausibilità, come visto nel Tema 7: date future dove non dovrebbero esserci, importi fuori scala, categorie inattese. Controllo dei campi segnalati: tutti i 'non presente', 'ambiguo' e 'dedotto' vanno guardati. Per le estrazioni ripetute nel tempo, una verifica iniziale approfondita può giustificare controlli più leggeri e periodici.");
    modeTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 1.9, { icon: "FiCrosshair", inline: true, head: "Accuratezza", headSize: 15, bodySize: 12,
      body: "Cifre invertite, IVA sì o no, 03/04 marzo o aprile, valore dal punto sbagliato, nomi storpiati." });
    await card(s, 5.15, 1.15, 4.35, 1.9, { icon: "FiLayers", inline: true, head: "Completezza", headSize: 15, bodySize: 12, fill: C.accent6,
      body: "Documenti saltati, righe omesse, campi vuoti anche se l'informazione c'era." });
    const tc = [["A campione", "Casuali e anomali"], ["Conteggi", "Record, somme, totali"], ["Plausibilità", "Date, scale, categorie"], ["Campi segnalati", "Assenti, ambigui, dedotti"]];
    tc.forEach((t, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 3.25, 2.15, 0.95, C.background2, t[0]);
      txt(s, t[0], { x: x + 0.12, y: 3.32, w: 1.95, h: 0.38, fontSize: 13, bold: true, color: C.accent1, align: "center" });
      txt(s, t[1], { x: x + 0.12, y: 3.7, w: 1.95, h: 0.4, fontSize: 11, color: C.text2, align: "center" });
    });
    txt(s, "Estrazioni ripetute: verifica iniziale approfondita, poi controlli più leggeri e periodici.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 13, italic: true, color: C.text2 });
  }
  {
    const s = content("Dato estratto, dato validato", "Il concetto chiave del sottotema merita una slide dedicata: un dato estratto non è automaticamente un dato validato. Tra il momento in cui l'AI produce una tabella e il momento in cui quei dati vengono usati in un processo, in un sistema gestionale o in una decisione, deve esserci un passaggio di controllo. Lo schema in slide mostra il percorso: il documento originale, il dato estratto dall'AI, il dato controllato secondo le tecniche viste, il dato validato per un uso specifico, e infine l'impiego operativo. Il rischio tipico è saltare il passaggio centrale: la tabella sembra ordinata, completa e precisa, e viene usata direttamente. Gli errori, a quel punto, si propagano: un importo sbagliato entra in un report, una scadenza mancata non genera l'avviso, un fornitore classificato male finisce nell'analisi sbagliata. E più ci si allontana dal documento originale, più è difficile accorgersene. Un accorgimento utile è conservare per ogni dato estratto il collegamento al documento e al passaggio da cui proviene: la tracciabilità rende possibile controllare anche a distanza di tempo.");
    modeTag(s, 2);
    const st = ["Documento", "Dato estratto", "Dato controllato", "Dato validato", "Impiego"];
    st.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      chip(s, x, 1.4, 1.6, 0.8, t, { fill: i === 2 ? C.accent5 : (i === 4 ? C.accent1 : C.background2), color: i === 2 || i === 4 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 4) arrow(s, x + 1.62, 1.64, 0.2);
    });
    txt(s, "Il passaggio che si rischia di saltare", { x: 3.68, y: 2.3, w: 1.6, h: 0.6, fontSize: 11, italic: true, bold: true, color: C.accent5, align: "center" });
    await card(s, 0.5, 3.05, 4.35, 1.9, { icon: "FiAlertTriangle", inline: true, head: "Gli errori si propagano", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: "Importo sbagliato nel report, scadenza senza avviso, fornitore nell'analisi sbagliata. Più ci si allontana dal documento, più è difficile accorgersene." });
    await card(s, 5.15, 3.05, 4.35, 1.9, { icon: "FiLink", inline: true, head: "Conservare il collegamento", headSize: 14, bodySize: 12, fill: C.accent6,
      body: "Per ogni dato, il documento e il passaggio da cui proviene: si può controllare anche a distanza di tempo." });
  }
  keySlide("L'AI può rendere più utilizzabile il contenuto informativo dei documenti, ma un dato estratto non è automaticamente un dato validato.", "Sottotema 8.4  ·  Estrazione e strutturazione delle informazioni", "Concetto chiave del sottotema 8.4. L'estrazione trasforma testi non strutturati in dati utilizzabili: nomi, date, importi, riferimenti, classificazioni, ricorrenze. È una delle possibilità più concrete dell'AI, perché rende sistematicamente usabili informazioni che prima erano solo leggibili. Ma richiede regole per i campi mancanti, ambigui o dedotti, categorie ben definite, controlli di accuratezza e completezza, e soprattutto un passaggio di validazione prima dell'impiego operativo. Esercizio suggerito: preparare cinque o sei email fittizie di clienti, chiedere all'AI di estrarne una tabella con campi definiti, e far controllare ai partecipanti ogni valore, contando errori, campi inventati e campi correttamente segnalati come mancanti.");

  // =====================================================================
  section("8.5 Confronto");
  divider("8.5", "Confronto e analisi di più documenti", "Un confronto utile individua differenze rilevanti, ne distingue la natura e permette di verificarle nelle fonti", "Terzo sottotema del nucleo distintivo: il confronto tra documenti. Mentre l'8.3 lavora su un documento per volta, qui il valore sta nelle relazioni tra documenti diversi: due versioni dello stesso contratto, tre offerte di fornitori, una procedura e il regolamento a cui dovrebbe conformarsi. Confrontare documenti è un'attività lunga, faticosa e soggetta a errori di attenzione quando la si fa a mano, e l'AI può renderla molto più rapida. In questo sottotema, da comprendere e sperimentare, vediamo i principali tipi di confronto, le matrici comparative, l'analisi di contraddizioni e lacune, la distinzione tra differenze formali e sostanziali e la tracciabilità delle differenze.");
  {
    const s = content("Tre tipi di confronto", "Il sottotema comprende tre famiglie di confronto, con obiettivi diversi. Il confronto tra versioni di uno stesso documento: che cosa è cambiato tra la bozza di contratto inviata e quella ricevuta dalla controparte? Tra la procedura dell'anno scorso e quella aggiornata? L'obiettivo è identificare le modifiche, e in particolare quelle non dichiarate. Il confronto tra documenti alternativi: tre offerte di fornitori, più proposte progettuali, condizioni di diversi contratti. L'obiettivo è individuare elementi comuni e differenze, per valutare e scegliere. Il confronto tra documenti collegati: una procedura e il regolamento che dovrebbe applicare, un capitolato e l'offerta che dovrebbe rispondervi, un verbale e il piano di progetto. L'obiettivo è trovare contraddizioni, incoerenze e informazioni mancanti. In tutti e tre i casi, l'AI può produrre rapidamente un primo quadro delle differenze. Si noti che per il confronto tra versioni esistono anche strumenti tradizionali, come la funzione di confronto dei programmi di scrittura, che sono esatti sulle modifiche testuali: l'AI aggiunge la capacità di interpretarle, distinguendo quelle rilevanti, e di confrontare documenti con struttura diversa.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiGitCommit", head: "Versioni di un documento", body: "Che cosa è cambiato? Soprattutto: che cosa non è stato dichiarato?" },
      { icon: "FiColumns", head: "Documenti alternativi", body: "Offerte, proposte, contratti: elementi comuni e differenze per scegliere" },
      { icon: "FiGitMerge", head: "Documenti collegati", body: "Procedura e regolamento, capitolato e offerta: contraddizioni e lacune" },
    ], 3, { y: 1.2, h: 2.2, headSize: 14, bodySize: 13 });
    banner(s, 3.65, "Gli strumenti di confronto tradizionali sono esatti sulle modifiche testuali. L'AI aggiunge l'interpretazione e il confronto tra strutture diverse.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Identificare le modifiche", "Il confronto tra versioni è un caso d'uso molto concreto: quando una controparte restituisce un contratto o un accordo, non sempre segnala tutte le modifiche, e controllare a mano un documento di trenta pagine è lungo e soggetto a distrazioni. Gli strumenti tradizionali di confronto mostrano ogni differenza testuale, ma non distinguono un refuso corretto da una clausola modificata, e funzionano male quando il documento è stato riorganizzato o riformattato. L'AI può aiutare in tre modi: elencare le modifiche raggruppandole per importanza, spiegare in linguaggio semplice che cosa cambia in pratica, e segnalare le modifiche che potrebbero avere conseguenze. L'esempio fittizio in slide mostra tre modifiche tra due versioni di un accordo: una formale e due sostanziali, di cui una, il passaggio da 30 a 60 giorni per il pagamento, cambia le condizioni economiche. Due avvertenze. La prima: un elenco di modifiche prodotto dall'AI può non essere completo; per i documenti importanti, conviene usare anche il confronto tradizionale, che è esaustivo sulle differenze testuali. La seconda: la valutazione dell'importanza di una modifica dipende dal contesto, che il sistema conosce solo in parte.");
    modeTag(s, 2);
    table(s, [["Versione 1", "Versione 2", "Natura"],
      ["Il fornitre si impegna", "Il fornitore si impegna", "Formale: refuso"],
      ["Pagamento a 30 giorni", "Pagamento a 60 giorni", "Sostanziale: condizioni economiche"],
      ["Il fornitore garantisce la consegna", "Il fornitore si adopera per la consegna", "Sostanziale: obbligo attenuato"]],
      { y: 1.15, colW: [3.0, 3.2, 2.8], rowH: 0.5, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.2, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    await card(s, 0.5, 3.55, 4.35, 1.4, { head: "L'elenco può non essere completo", headSize: 14, bodySize: 12, body: "Per i documenti importanti, usare anche il confronto tradizionale, esaustivo sulle differenze testuali." });
    await card(s, 5.15, 3.55, 4.35, 1.4, { head: "L'importanza dipende dal contesto", headSize: 14, bodySize: 12, fill: C.accent6, body: "Che il sistema conosce solo in parte: la valutazione finale resta a chi conosce la trattativa." });
  }
  {
    const s = content("La matrice comparativa", "Per i documenti alternativi, lo strumento più utile è la matrice comparativa: una tabella con i documenti in colonna e i criteri di confronto in riga. L'esempio fittizio in slide confronta tre offerte di fornitori su prezzo, tempi di consegna, garanzia e assistenza. L'AI è molto efficace nel costruire queste matrici, a condizione di definire bene i criteri: se li scegliamo noi, in base a ciò che conta per la decisione, il confronto è mirato; se li lasciamo scegliere al sistema, rischiamo un confronto sui criteri più facili da estrarre, non su quelli più importanti. Tre elementi rendono una matrice affidabile. I riferimenti: ogni cella dovrebbe indicare da quale passaggio del documento deriva il valore. La gestione dei vuoti: se un'offerta non specifica un elemento, la cella deve dirlo, come nell'esempio per l'assistenza del fornitore C, invece di riportare un valore dedotto. La comparabilità: i valori devono essere confrontabili, per esempio prezzi tutti con o tutti senza IVA, tempi tutti in giorni lavorativi o tutti in giorni di calendario. Una matrice che mette accanto valori non omogenei produce un confronto sbagliato con l'aspetto di un confronto preciso.");
    modeTag(s, 2);
    table(s, [["Criterio", "Fornitore A", "Fornitore B", "Fornitore C"],
      ["Prezzo (IVA esclusa)", "12.400 € (§3)", "11.900 € (§2.1)", "12.100 € (p. 4)"],
      ["Consegna", "30 giorni (§5)", "45 giorni (§4)", "20 giorni lavorativi (p. 6)"],
      ["Garanzia", "24 mesi (§7)", "36 mesi (§6.2)", "24 mesi (p. 7)"],
      ["Assistenza", "Inclusa 1 anno (§8)", "A pagamento (§6.4)", "Non specificata"]],
      { y: 1.15, colW: [2.1, 2.3, 2.3, 2.3], rowH: 0.45, fontSize: 12, blankCorner: false });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.45, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    chip(s, 0.5, 3.8, 2.9, 0.6, "Riferimento per ogni cella", { fill: C.accent6, fontSize: 12 });
    chip(s, 3.55, 3.8, 2.9, 0.6, "Vuoti dichiarati, non dedotti", { fill: C.accent6, fontSize: 12 });
    chip(s, 6.6, 3.8, 2.9, 0.6, "Valori comparabili", { fill: C.accent6, fontSize: 12 });
    txt(s, "Attenzione: 20 giorni lavorativi non sono confrontabili con 30 giorni di calendario senza conversione.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Contraddizioni e lacune", "Il confronto tra documenti collegati serve soprattutto a trovare due tipi di problemi. Le contraddizioni: due documenti, o due parti dello stesso documento, che dicono cose incompatibili. Una procedura che prevede un'approvazione in due giorni, mentre il regolamento ne prevede cinque. Un'offerta che indica una garanzia di 24 mesi nella premessa e di 12 nelle condizioni generali. Un verbale che attribuisce un'attività a un reparto diverso da quello del piano di progetto. Le informazioni mancanti: elementi richiesti da un documento e assenti nell'altro. Un capitolato che chiede certificazioni, piano di manutenzione e referenze, e un'offerta che risponde solo sulle prime due. Una procedura che non disciplina un caso previsto dal regolamento. L'AI può essere molto utile qui, perché questi problemi richiedono di tenere a mente molti dettagli e incrociarli, attività in cui l'attenzione umana cala rapidamente. Ma due cautele. Le lacune sono più difficili da trovare delle contraddizioni, come visto nel Tema 7 per le omissioni: conviene fornire esplicitamente l'elenco dei requisiti da controllare. E il sistema può segnalare false contraddizioni, dovute a una lettura imprecisa: ogni contraddizione segnalata va verificata sui due passaggi.");
    modeTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.7, { icon: "FiXCircle", head: "Contraddizioni", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Procedura: approvazione in 2 giorni; regolamento: 5", "Offerta: garanzia 24 mesi in premessa, 12 nelle condizioni", "Attività attribuita a reparti diversi"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.7, { icon: "FiMinusCircle", head: "Informazioni mancanti", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Capitolato: certificazioni, manutenzione, referenze; offerta: solo le prime due", "Caso previsto dal regolamento, non disciplinato dalla procedura"], { space: 5 }) });
    const c = [["Lacune più difficili da trovare", "Fornire l'elenco dei requisiti da controllare"], ["Possibili false contraddizioni", "Verificare ogni segnalazione sui due passaggi"]];
    c.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 4.05, 4.35, 0.9, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 4.1, w: 3.95, h: 0.38, fontSize: 13, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.47, w: 3.95, h: 0.4, fontSize: 12, color: C.background1 });
    });
  }
  {
    const s = content("Differenze formali e sostanziali", "Come per le trasformazioni nell'8.2, anche nel confronto è essenziale distinguere differenze formali e sostanziali. Le differenze formali riguardano il modo di esprimersi: un sinonimo, un ordine diverso, una formattazione, una numerazione cambiata, un refuso. Le differenze sostanziali riguardano il contenuto: obblighi, importi, scadenze, responsabilità, condizioni, esclusioni. Un buon confronto non elenca tutte le differenze con lo stesso peso: le seleziona, le classifica, e porta in evidenza quelle sostanziali. Altrimenti si ottiene un elenco lunghissimo in cui la modifica decisiva si perde tra decine di cambiamenti irrilevanti, o, al contrario, un elenco breve che ha scartato come formale una modifica sostanziale. Il caso più insidioso è proprio questo: differenze che sembrano formali ma non lo sono. 'Si impegna a' contro 'si adopera per', 'entro' contro 'indicativamente entro', 'il cliente' contro 'il cliente o i suoi incaricati'. Per i confronti importanti, conviene chiedere al sistema di classificare ogni differenza e di motivare la classificazione, e poi controllare in particolare quelle classificate come formali in clausole rilevanti, come obblighi, importi e scadenze.");
    modeTag(s, 2);
    await twoPanel(s, "Differenze formali", bullets(["Sinonimi equivalenti, ordine, formattazione", "Numerazione, refusi", "Non cambiano il contenuto"], { space: 4 }), "Differenze sostanziali", bullets(["Obblighi, importi, scadenze", "Responsabilità, condizioni, esclusioni", "Cambiano le conseguenze"], { space: 4 }), { li: "FiType", ri: "FiAlertCircle", h: 2.1 });
    txt(s, "Sembrano formali, ma non lo sono", { x: 0.5, y: 3.45, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    chip(s, 0.5, 3.85, 2.9, 0.5, "si impegna / si adopera", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.85, 2.9, 0.5, "entro / indicativamente entro", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.85, 2.9, 0.5, "il cliente / o i suoi incaricati", { fill: C.background2, fontSize: 12 });
    txt(s, "Chiedere di classificare e motivare; controllare le differenze 'formali' nelle clausole rilevanti.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Tracciare le differenze", "Il sottotema riprende l'integrazione sulla tracciabilità: le differenze e le conclusioni di un confronto devono poter essere ricondotte ai passaggi dei documenti confrontati. In un confronto la tracciabilità è ancora più importante che in una sintesi, per due ragioni. Primo, i documenti sono più di uno, e il rischio di attribuire un'informazione al documento sbagliato è reale: il sistema può riportare nella colonna del fornitore A una condizione che compare nell'offerta del fornitore B. Secondo, i confronti sono spesso usati per decisioni con conseguenze, come la scelta di un fornitore o l'accettazione di un contratto, e per comunicazioni a terzi, come la richiesta di chiarimenti a un fornitore. Indicare che 'l'offerta B non prevede assistenza' a un fornitore che invece la prevede a pagina 12 è un errore che si paga. Per ogni differenza rilevante, quindi, il confronto dovrebbe indicare i due passaggi a confronto, con il riferimento nel rispettivo documento, così che la differenza si possa verificare affiancandoli. Le conclusioni, come 'l'offerta A è la più completa', dovrebbero indicare su quali differenze si basano.");
    modeTag(s, 2);
    shapeBox(s, 0.5, 1.15, 9.0, 1.8, C.background2, "differenza tracciata");
    txt(s, "Differenza tracciata (esempio fittizio)", { x: 0.7, y: 1.22, w: 6, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
    docBox(s, 0.7, 1.6, 3.7, 1.2, "Offerta A, §8", "Assistenza tecnica inclusa per 12 mesi dalla consegna.", { fill: C.background1, fontSize: 12 });
    chip(s, 4.55, 1.95, 0.9, 0.5, "≠", { fill: C.accent5, color: C.background1, fontSize: 18 });
    docBox(s, 5.6, 1.6, 3.7, 1.2, "Offerta B, §6.4", "Assistenza tecnica disponibile a pagamento, secondo listino.", { fill: C.background1, fontSize: 12 });
    await card(s, 0.5, 3.15, 4.35, 1.8, { icon: "FiFolder", inline: true, head: "Più documenti, più confusione", headSize: 14, bodySize: 12, body: "Il rischio di attribuire un'informazione al documento sbagliato è reale." });
    await card(s, 5.15, 3.15, 4.35, 1.8, { icon: "FiSend", inline: true, head: "Decisioni e comunicazioni a terzi", headSize: 14, bodySize: 12, fill: C.accent6, body: "Contestare a un fornitore una mancanza che non c'è è un errore che si paga." });
  }
  keySlide("Un confronto documentale è utile se individua differenze rilevanti, ne distingue la natura e permette di verificarle nelle fonti.", "Sottotema 8.5  ·  Confronto e analisi di più documenti", "Concetto chiave del sottotema 8.5. L'AI rende molto più rapido il confronto tra versioni, tra documenti alternativi e tra documenti collegati: identifica modifiche, costruisce matrici comparative, trova contraddizioni e lacune. Il valore del confronto dipende da tre condizioni, che il concetto chiave riassume: individuare le differenze rilevanti, non tutte con lo stesso peso; distinguerne la natura, formale o sostanziale, con attenzione a quelle che sembrano formali; permettere di verificarle nelle fonti, con riferimenti ai passaggi di ciascun documento. Esercizio suggerito: preparare due versioni fittizie di un breve accordo, con alcune modifiche formali e due o tre sostanziali, di cui una mascherata da modifica formale, e chiedere ai partecipanti di confrontarle con l'AI e con il confronto tradizionale, valutando che cosa trova ciascun metodo.");

  // =====================================================================
  section("8.6 Ricerca");
  divider("8.6", "Ricerca, approfondimento e organizzazione", "L'AI può sostenere ricerca e organizzazione della conoscenza, senza rendere automaticamente attendibili le informazioni", "Passiamo alla quarta modalità: recuperare conoscenza. In questo sottotema, da comprendere, guardiamo all'AI come supporto alla ricerca informativa e all'approfondimento di argomenti: trovare fonti, esplorare un tema, organizzare ciò che si è raccolto, preparare dossier. È un uso molto diffuso, che cambia il modo di cercare informazioni rispetto ai motori di ricerca tradizionali. La distinzione centrale del sottotema è tra la conoscenza incorporata nel modello e le informazioni recuperate da fonti esterne, e tra ricerca assistita e verifica delle fonti. Il metodo di verifica l'abbiamo visto nel Tema 7: qui ci concentriamo su come l'AI può sostenere la ricerca, e su che cosa non può garantire.");
  {
    const s = content("L'AI nel lavoro di ricerca", "L'AI può intervenire in diverse fasi del lavoro di ricerca e approfondimento. Nell'orientamento: capire rapidamente i concetti di base di un argomento nuovo, il lessico, le questioni principali, le domande giuste da porsi. Nell'identificazione di fonti e materiali: suggerire tipi di fonti, enti di riferimento, documenti normativi, parole chiave per la ricerca; con gli strumenti dotati di ricerca web, trovare e citare pagine specifiche. Nell'approfondimento: esplorare un aspetto specifico, chiedere spiegazioni, esempi, collegamenti. Nell'organizzazione: raggruppare le informazioni raccolte per tema, individuare sovrapposizioni e lacune, costruire uno schema. Nella produzione: preparare un dossier, una sintesi tematica, una nota di aggiornamento. Il valore principale è la velocità di orientamento: in pochi minuti si passa da 'non so nulla di questo argomento' a 'so che cosa cercare e dove'. Il limite principale, che svilupperemo, è che velocità di orientamento non significa attendibilità delle informazioni. Alcune funzioni di ricerca approfondita svolgono molte ricerche in sequenza e producono rapporti estesi con molte fonti: utili, ma con le stesse esigenze di verifica.");
    modeTag(s, 3);
    const ph = [["FiCompass", "Orientarsi", "Concetti, lessico, domande giuste"], ["FiSearch", "Trovare fonti", "Tipi di fonti, enti, parole chiave, pagine"], ["FiZoomIn", "Approfondire", "Spiegazioni, esempi, collegamenti"], ["FiFolder", "Organizzare", "Temi, sovrapposizioni, lacune"], ["FiFileText", "Produrre", "Dossier, sintesi tematiche, note"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.2, 1.66, 2.4, i % 2 ? C.accent6 : C.background2, ph[i][1]);
      await iconCircle(s, x + 0.53, 1.35, 0.6, ph[i][0]);
      txt(s, ph[i][1], { x: x + 0.08, y: 2.05, w: 1.5, h: 0.4, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, ph[i][2], { x: x + 0.1, y: 2.5, w: 1.46, h: 1.0, fontSize: 11, color: C.text2, align: "center" });
      if (i < 4) arrow(s, x + 1.665, 2.2, 0.17);
    }
    banner(s, 3.85, "Il valore: dalla domanda 'che cosa so?' a 'che cosa cercare e dove' in pochi minuti. Velocità di orientamento non significa attendibilità.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Incorporata o recuperata?", "Una distinzione fondamentale, introdotta nel Tema 2 e qui ripresa per le sue conseguenze pratiche. La conoscenza incorporata nel modello è ciò che il modello ha appreso durante l'addestramento: è vasta, ma ha una data limite, può contenere errori, non ha fonti precise da citare, e quando manca il sistema tende a ricostruire risposte plausibili. Le informazioni recuperate esternamente sono quelle che il sistema ottiene durante la conversazione: da una ricerca web, da documenti caricati, da una base documentale aziendale. Sono più aggiornate, possono essere citate e verificate, ma dipendono dalla qualità delle fonti trovate e dalla correttezza con cui il sistema le legge e le riporta. In pratica, la domanda da porsi davanti a una risposta è: da dove viene questa informazione? Se lo strumento indica le fonti consultate, la risposta si basa almeno in parte su informazioni recuperate, e si può controllare. Se non le indica, la risposta probabilmente viene dalla conoscenza incorporata, e va trattata con più cautela, soprattutto per fatti recenti, dati specifici, norme, prezzi, persone. Molti strumenti combinano le due cose nella stessa risposta, e non sempre distinguono chiaramente quale parte viene da dove.");
    modeTag(s, 3);
    table(s, [["", "Conoscenza incorporata", "Informazioni recuperate"],
      ["Origine", "Addestramento del modello", "Web, documenti caricati, basi documentali"],
      ["Aggiornamento", "Fino a una data limite", "Al momento della ricerca"],
      ["Fonti", "Non citabili con precisione", "Citabili e verificabili"],
      ["Rischio tipico", "Ricostruzioni plausibili ma errate", "Fonti scadenti, lettura imprecisa"]],
      { y: 1.15, colW: [2.0, 3.5, 3.5], rowH: 0.48, fontSize: 12, accentCol: 2 });
    banner(s, 3.75, "La domanda da porsi: da dove viene questa informazione? Senza fonti indicate, più cautela su fatti recenti, dati, norme, prezzi.", { h: 0.8, fontSize: 13 });
    txt(s, "Molti strumenti combinano le due cose, e non sempre distinguono quale parte viene da dove.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Attualità e attendibilità", "Due requisiti delle informazioni trovate, che l'AI non garantisce automaticamente. L'attualità: un'informazione corretta un anno fa può non esserlo oggi. Riguarda in particolare norme e scadenze, prezzi e tariffe, organigrammi e ruoli, prodotti e versioni, dati di mercato, eventi recenti. Se l'informazione viene dalla conoscenza incorporata, può essere superata senza alcun segnale. Se viene da una ricerca, può essere stata trovata in una pagina vecchia. Conviene verificare la data della fonte e, per le informazioni sensibili al tempo, cercare esplicitamente la versione più recente. L'attendibilità: chi ha prodotto l'informazione, con quali competenze e quali interessi? I criteri sono quelli visti nel Tema 7. Qui aggiungiamo un rischio specifico della ricerca assistita: il sistema seleziona e sintetizza le fonti secondo criteri non trasparenti, e può dare lo stesso peso a una fonte istituzionale e a un blog, o presentare come consolidata una posizione che compare in poche fonti. Inoltre la sintesi delle fonti può introdurre le stesse perdite di significato viste nell'8.3. Il risultato è che una risposta con molte fonti citate può sembrare più solida di quanto sia.");
    modeTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.45, { icon: "FiClock", head: "Attualità", headSize: 16, bodySize: 12,
      body: bullets(["Norme, scadenze, prezzi, ruoli, versioni", "Conoscenza incorporata: superata senza segnali", "Ricerca: pagina vecchia; controllare la data"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.45, { icon: "FiShield", head: "Attendibilità", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Chi, con quali competenze e interessi", "Fonti selezionate con criteri non trasparenti", "Stesso peso a fonti istituzionali e blog"], { space: 4 }) });
    banner(s, 3.85, "Una risposta con molte fonti citate può sembrare più solida di quanto sia.", { h: 0.65, fontSize: 14 });
    txt(s, "Le fonti trovate si valutano con gli stessi criteri di qualsiasi altra fonte.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Organizzare: dossier e sintesi", "Una volta raccolte le informazioni, l'AI è molto utile per organizzarle. Raggruppare per tema: da trenta appunti e documenti sparsi a una struttura per argomenti. Individuare sovrapposizioni, contraddizioni e lacune tra il materiale raccolto, applicando quanto visto nell'8.5. Costruire uno schema o un indice per un documento da produrre. Preparare un dossier: un documento che raccoglie e organizza le informazioni su un tema, per esempio un fornitore, un mercato, una normativa, in vista di una riunione o di una decisione. Preparare sintesi tematiche: note di aggiornamento periodiche su un argomento. Il modo più affidabile di farlo, coerente con quanto detto finora, è separare le fasi: prima raccogliere le fonti e verificarne attendibilità e attualità; poi fornire al sistema il materiale raccolto e chiedergli di organizzarlo, citando le fonti per ogni punto; infine rivedere il risultato. In questo modo il dossier si basa su fonti scelte e controllate, e non sulla conoscenza incorporata del modello. Un buon dossier dichiara le sue fonti, la data a cui è aggiornato e i punti che restano incerti o da approfondire.");
    modeTag(s, 3);
    const st = [["1", "Raccogliere", "Fonti scelte, verificate per attendibilità e attualità"], ["2", "Organizzare", "Il sistema struttura il materiale fornito, citando le fonti"], ["3", "Rivedere", "Coerenza, lacune, punti incerti"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 1.8, i === 1 ? C.accent6 : C.background2, e[1]);
      txt(s, e[0], { x: x + 0.2, y: 1.28, w: 0.5, h: 0.5, fontSize: 24, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.7, y: 1.33, w: 2.0, h: 0.42, fontSize: 16, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[2], { x: x + 0.2, y: 1.9, w: 2.5, h: 0.95, fontSize: 12, color: C.text2 });
      if (i < 2) arrow(s, x + 2.88, 1.95, 0.17);
    });
    shapeBox(s, 0.5, 3.2, 9.0, 1.75, C.text1, "buon dossier");
    txt(s, "Un buon dossier dichiara", { x: 0.75, y: 3.32, w: 8.5, h: 0.38, fontSize: 15, bold: true, color: C.accent6 });
    chip(s, 0.75, 3.85, 2.7, 0.55, "Le sue fonti", { fill: C.accent1, color: C.background1, fontSize: 13 });
    chip(s, 3.65, 3.85, 2.7, 0.55, "La data di aggiornamento", { fill: C.accent1, color: C.background1, fontSize: 13 });
    chip(s, 6.55, 3.85, 2.7, 0.55, "I punti incerti", { fill: C.accent1, color: C.background1, fontSize: 13 });
    txt(s, "Così si basa su fonti scelte e controllate, non sulla conoscenza incorporata.", { x: 0.75, y: 4.5, w: 8.5, h: 0.35, fontSize: 12, italic: true, color: C.accent3 });
  }
  {
    const s = content("Confrontare fonti e prospettive", "Un uso prezioso dell'AI nella ricerca è il confronto tra fonti e prospettive. Su molti argomenti, specialmente quelli complessi o dibattuti, esistono posizioni diverse: interpretazioni diverse di una norma, valutazioni diverse di una tecnologia, previsioni diverse su un mercato. Il sistema può aiutare a mappare queste posizioni, a individuare su che cosa concordano e su che cosa divergono, e a capire su quali assunzioni si basano. È un modo efficace per evitare di fermarsi alla prima fonte trovata, che è una forma del bias di conferma visto nel Tema 7. Ma ci sono tre cautele. Primo, il sistema tende a produrre un quadro equilibrato in apparenza, che può dare lo stesso peso a una posizione largamente condivisa e a una minoritaria, o al contrario ignorare posizioni minoritarie ma rilevanti. Secondo, la presentazione delle posizioni può semplificarle o deformarle: conviene risalire alle fonti delle posizioni più rilevanti per la decisione. Terzo, come per la generazione, il modo in cui poniamo la domanda può orientare la risposta: chiedere 'quali sono i vantaggi di' produce un quadro diverso da 'quali sono le valutazioni su'.");
    modeTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiGitBranch", head: "Che cosa può fare", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Mappare posizioni diverse", "Concordanze, divergenze, assunzioni", "Non fermarsi alla prima fonte"], { space: 5 }) });
    const c = [["Equilibrio apparente", "Stesso peso a posizioni maggioritarie e minoritarie"], ["Semplificazione", "Risalire alle fonti delle posizioni rilevanti"], ["Domanda orientata", "'Vantaggi di' e 'valutazioni su' danno quadri diversi"]];
    c.forEach((e, i) => {
      const y = 1.2 + i * 0.75;
      shapeBox(s, 5.15, y, 4.35, 0.65, C.background2, e[0]);
      txt(s, e[0], { x: 5.3, y: y + 0.04, w: 4.1, h: 0.3, fontSize: 13, bold: true, color: C.accent5 });
      txt(s, e[1], { x: 5.3, y: y + 0.33, w: 4.1, h: 0.3, fontSize: 11, color: C.text2 });
    });
    banner(s, 3.65, "Il confronto tra prospettive contrasta il bias di conferma. Ma il quadro prodotto va letto con le stesse cautele di una sintesi.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Ricerca assistita e verifica", "L'ultimo punto del sottotema è una distinzione che riprende il Tema 7: la ricerca assistita non è una verifica delle fonti. Quando il sistema trova e cita fonti, ha svolto una ricerca: ha individuato pagine o documenti che ritiene pertinenti e ne ha riportato il contenuto. Ma non ha verificato che le fonti siano attendibili, aggiornate, e che sostengano davvero ciò che la risposta afferma. Queste verifiche restano a chi usa il risultato, con l'intensità proporzionata all'uso. In particolare, i problemi visti nel Tema 7 si presentano anche qui: fonti citate che non contengono l'affermazione attribuita, fonti che la contengono con condizioni diverse, fonti esistenti ma poco attendibili. La ricerca assistita sposta il lavoro, non lo elimina: riduce molto il tempo per trovare il materiale, e lascia il tempo per valutarlo. Il rischio è che la comodità di una risposta già accompagnata da fonti faccia saltare proprio quel passaggio. Il concetto chiave del sottotema lo dice chiaramente: l'AI sostiene la ricerca, senza rendere automaticamente attendibili le informazioni trovate o generate.");
    modeTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiSearch", head: "Ricerca assistita", headSize: 16, bodySize: 13,
      body: bullets(["Trova fonti ritenute pertinenti", "Ne riporta il contenuto", "Riduce il tempo per trovare il materiale"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCheckCircle", head: "Verifica delle fonti", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Attendibili e aggiornate?", "Sostengono davvero l'affermazione?", "Resta a chi usa il risultato"], { space: 5 }) });
    banner(s, 3.7, "La ricerca assistita sposta il lavoro, non lo elimina. Il rischio è che una risposta già con le fonti faccia saltare la verifica.", { h: 0.85, fontSize: 13 });
    txt(s, "Verificare una fonte: esiste, è pertinente, sostiene davvero l'affermazione.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("L'AI può sostenere ricerca e organizzazione della conoscenza, senza rendere automaticamente attendibili le informazioni trovate o generate.", "Sottotema 8.6  ·  Ricerca, approfondimento e organizzazione", "Concetto chiave del sottotema 8.6. L'AI accelera molto l'orientamento su un argomento, la ricerca di fonti, l'approfondimento, l'organizzazione del materiale e la preparazione di dossier. Ma bisogna distinguere la conoscenza incorporata nel modello dalle informazioni recuperate esternamente, controllare attualità e attendibilità, leggere con cautela i quadri di sintesi su posizioni diverse, e ricordare che la ricerca assistita non è una verifica delle fonti. Esercizio suggerito: scegliere un argomento professionale con aspetti recenti, porre la stessa domanda a uno strumento senza ricerca web e a uno con ricerca web, e confrontare le risposte per attualità, fonti indicate e affermazioni verificabili.");

  // =====================================================================
  section("8.7 Conoscenza");
  divider("8.7", "AI e gestione della conoscenza", "L'AI può agevolare l'accesso alle informazioni documentali, ma non risolve da sola i problemi di organizzazione e qualità", "Ultimo sottotema del nucleo distintivo: la gestione della conoscenza. Mentre l'8.6 riguardava la ricerca su fonti esterne, qui guardiamo al patrimonio documentale dell'organizzazione: procedure, manuali, contratti, documentazione tecnica, verbali, FAQ. Le aziende producono enormi quantità di documenti, ma spesso trovare la risposta giusta al momento giusto resta difficile. L'AI apre una possibilità nuova: interrogare una raccolta documentale in linguaggio naturale, come si farebbe con un collega esperto. In questo sottotema, da comprendere nelle sue opportunità, vediamo che cosa significa, quali condizioni servono perché funzioni, e perché un archivio non è automaticamente conoscenza interrogabile. Gli aspetti tecnici, come l'architettura RAG vista nel Tema 2, restano solo accennati; la progettazione di questi sistemi in azienda appartiene al Tema 14.");
  {
    const s = content("Dati, informazioni, documenti", "Partiamo da quattro concetti che nel linguaggio comune si confondono, ma che è utile distinguere. I dati sono elementi elementari, come un numero, una data, un codice: '45', '12/03', 'ORD-4471'. Le informazioni sono dati con un significato e un contesto: 'l'ordine 4471 è stato consegnato il 12 marzo con 45 giorni di ritardo'. I documenti sono contenitori organizzati di informazioni, prodotti per uno scopo: un contratto, una procedura, un verbale, un manuale. La conoscenza è la capacità di usare le informazioni per capire, decidere e agire: sapere che cosa fare quando un ordine arriva in ritardo, quale clausola applicare, chi contattare, quali eccezioni esistono. In azienda, gran parte della conoscenza è distribuita: in parte nei documenti, in parte nelle persone, nella loro esperienza e nelle pratiche consolidate. La gestione della conoscenza si occupa di renderla accessibile a chi ne ha bisogno. L'AI interviene in questo passaggio: può aiutare a trovare e collegare le informazioni contenute nei documenti, e a presentarle in risposta a una domanda. Ma la conoscenza non scritta, o scritta male, resta fuori dalla sua portata.");
    modeTag(s, 3);
    const lv = [["Dati", "Elementi elementari", "45  ·  12/03  ·  ORD-4471"], ["Informazioni", "Dati con significato e contesto", "Ordine 4471 consegnato il 12/03 con 45 giorni di ritardo"], ["Documenti", "Contenitori organizzati per uno scopo", "Contratto, procedura, verbale, manuale"], ["Conoscenza", "Capacità di usare le informazioni per agire", "Che cosa fare, quale clausola, chi contattare"]];
    lv.forEach((l, i) => {
      const y = 1.12 + i * 0.78, w = 5.5 + i * 0.5;
      shapeBox(s, 0.5, y, w, 0.68, i === 3 ? C.accent1 : (i % 2 ? C.accent6 : C.background2), l[0]);
      txt(s, l[0], { x: 0.65, y, w: 1.6, h: 0.68, fontSize: 14, bold: true, color: i === 3 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 2.25, y: y + 0.05, w: w - 1.9, h: 0.3, fontSize: 12, bold: true, color: i === 3 ? C.background1 : C.text1 });
      txt(s, l[2], { x: 2.25, y: y + 0.34, w: w - 1.9, h: 0.3, fontSize: 11, italic: true, color: i === 3 ? C.accent6 : C.text2 });
    });
    txt(s, "La conoscenza non scritta, o scritta male, resta fuori dalla portata dell'AI.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Archivio o conoscenza interrogabile", "Questa è l'integrazione D del tema, ed è forse il messaggio più importante per chi pensa di introdurre in azienda un assistente basato sulla documentazione: possedere un archivio di documenti non equivale a poterlo interrogare in modo affidabile. Un archivio documentale è una raccolta di file, organizzata per cartelle o in un sistema di gestione: si cerca un documento, lo si apre, lo si legge. La conoscenza interrogabile è una raccolta su cui si può porre una domanda e ottenere una risposta corretta, basata sui documenti pertinenti e collegata ad essi. Il passaggio dall'uno all'altro non avviene semplicemente collegando un sistema AI all'archivio. Contano cinque condizioni. La reperibilità: i documenti giusti devono poter essere trovati dal sistema. La struttura: documenti chiari, con titoli, sezioni e informazioni esplicite, funzionano meglio di documenti confusi. L'aggiornamento: se l'archivio contiene versioni superate, il sistema può rispondere in base a quelle. La qualità: documenti contraddittori, incompleti o scritti male producono risposte contraddittorie, incomplete o sbagliate. La possibilità di verifica: le risposte devono rimandare ai documenti originali. In sintesi: l'AI rende interrogabile un archivio nella misura in cui l'archivio è già ben tenuto.");
    modeTag(s, 3);
    shapeBox(s, 0.5, 1.15, 2.6, 1.45, C.background2, "archivio");
    await iconCircle(s, 0.7, 1.3, 0.55, "FiArchive", C.accent2);
    txt(s, "Archivio", { x: 1.35, y: 1.32, w: 1.7, h: 0.5, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
    txt(s, "Si cerca un file, lo si apre, lo si legge", { x: 0.7, y: 1.95, w: 2.3, h: 0.6, fontSize: 11, color: C.text2 });
    arrow(s, 3.2, 1.7, 0.35);
    shapeBox(s, 3.65, 1.15, 2.6, 1.45, C.accent1, "interrogabile");
    await iconCircle(s, 3.85, 1.3, 0.55, "FiMessageCircle", C.background1, HEX.a1);
    txt(s, "Conoscenza interrogabile", { x: 4.5, y: 1.25, w: 1.7, h: 0.65, fontSize: 13, bold: true, color: C.background1, valign: "middle" });
    txt(s, "Una domanda, una risposta corretta e collegata ai documenti", { x: 3.85, y: 1.95, w: 2.3, h: 0.6, fontSize: 11, color: C.background1 });
    txt(s, "Non basta collegare un sistema AI all'archivio", { x: 6.45, y: 1.15, w: 3.05, h: 1.45, fontSize: 14, bold: true, italic: true, color: C.accent5, valign: "middle" });
    const cd = ["Reperibilità", "Struttura", "Aggiornamento", "Qualità", "Verificabilità"];
    cd.forEach((t, i) => chip(s, 0.5 + i * 1.82, 2.85, 1.7, 0.55, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 3.65, "L'AI rende interrogabile un archivio nella misura in cui l'archivio è già ben tenuto.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Come funziona per chi la usa", "Senza entrare nell'architettura tecnica, che il documento di perimetro chiede solo di accennare, è utile capire dal punto di vista dell'utilizzatore che cosa succede quando si interroga una raccolta documentale. Il funzionamento tipico, che nel Tema 2 abbiamo chiamato RAG, avviene in due passaggi. Primo, il recupero: a partire dalla domanda, il sistema cerca nella raccolta i passaggi più pertinenti. Secondo, la generazione: il modello produce una risposta basandosi su quei passaggi, e idealmente li cita. Questa semplice descrizione spiega molti comportamenti che l'utente osserva. Se il recupero non trova il passaggio giusto, perché la domanda usa parole diverse dal documento o perché il documento è mal strutturato, la risposta sarà incompleta o sbagliata, anche se l'informazione è nella raccolta. Se il recupero trova passaggi di documenti superati, la risposta sarà superata. Se il recupero non trova nulla di pertinente, un buon sistema dovrebbe dirlo, ma alcuni rispondono comunque con la conoscenza generale del modello. E se la generazione riporta male i passaggi trovati, la risposta sarà sbagliata nonostante il recupero corretto. Per l'utente, la conseguenza pratica è una: controllare i passaggi citati, non solo la risposta.");
    modeTag(s, 3);
    chip(s, 0.5, 1.3, 1.7, 0.8, "Domanda", { fill: C.background2, fontSize: 14 });
    arrow(s, 2.3, 1.54, 0.35);
    shapeBox(s, 2.75, 1.15, 2.6, 1.1, C.accent6, "recupero");
    txt(s, "1. Recupero", { x: 2.9, y: 1.22, w: 2.3, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Cerca i passaggi più pertinenti nella raccolta", { x: 2.9, y: 1.58, w: 2.3, h: 0.6, fontSize: 11, color: C.text1 });
    arrow(s, 5.45, 1.54, 0.35);
    shapeBox(s, 5.9, 1.15, 2.6, 1.1, C.accent1, "generazione");
    txt(s, "2. Generazione", { x: 6.05, y: 1.22, w: 2.3, h: 0.35, fontSize: 14, bold: true, color: C.background1 });
    txt(s, "Risponde sulla base dei passaggi, e li cita", { x: 6.05, y: 1.58, w: 2.3, h: 0.6, fontSize: 11, color: C.background1 });
    table(s, [["Che cosa va storto", "Che cosa vede l'utente"],
      ["Recupero manca il passaggio giusto", "Risposta incompleta, anche se l'informazione c'è"],
      ["Recupero trova documenti superati", "Risposta superata"],
      ["Nessun passaggio pertinente", "Risposta dalla conoscenza generale, o 'non so'"],
      ["Generazione riporta male", "Risposta errata con fonti corrette"]],
      { y: 2.45, colW: [4.2, 4.8], rowH: 0.42, fontSize: 12, blankCorner: false });
    txt(s, "Conseguenza pratica: controllare i passaggi citati, non solo la risposta.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Assistenti sulla documentazione", "Gli assistenti basati sulla documentazione sono strumenti che permettono di interrogare in linguaggio naturale una raccolta definita di documenti. Le opportunità sono concrete. Un assistente sulle procedure interne risponde a domande come 'come si richiede un rimborso spese per una trasferta all'estero?'. Un assistente sulla documentazione tecnica aiuta il servizio di assistenza a trovare la soluzione a un problema descritto dal cliente. Un assistente sulle condizioni contrattuali aiuta il commerciale a rispondere a domande su garanzie e tempi. Un assistente per l'inserimento dei nuovi colleghi raccoglie regole, contatti e prassi. Il valore è di ridurre il tempo per trovare le informazioni, rendere accessibile la conoscenza anche a chi non sa dove cercare, e alleggerire le persone esperte dalle domande ripetitive. Molti strumenti di uso comune permettono già oggi di creare piccoli assistenti su un insieme di documenti, mentre le soluzioni aziendali su larga scala richiedono progettazione, integrazione e gestione dei permessi, temi che appartengono al Tema 14. La progettazione di assistenti e agenti che svolgono azioni appartiene invece al Tema 11. Qui ci interessa che cosa possono offrire, e a quali condizioni.");
    modeTag(s, 3);
    await iconGrid(s, [
      { icon: "FiClipboard", head: "Procedure interne", body: "Come si richiede un rimborso per una trasferta all'estero?" },
      { icon: "FiTool", head: "Documentazione tecnica", body: "Soluzioni ai problemi descritti dai clienti" },
      { icon: "FiFileText", head: "Condizioni contrattuali", body: "Garanzie, tempi, condizioni per i commerciali" },
      { icon: "FiUserPlus", head: "Inserimento di nuovi colleghi", body: "Regole, contatti, prassi in un unico punto" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Meno tempo per trovare le informazioni, conoscenza accessibile a chi non sa dove cercare, esperti alleggeriti dalle domande ripetitive.", { h: 0.6, fontSize: 12 });
    txt(s, "Qui gli assistenti che rispondono; soluzioni su larga scala e agenti che svolgono azioni sono argomenti a sé.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Risposte collegate ai documenti", "Il sottotema riprende l'integrazione sulla tracciabilità: l'accesso alla conoscenza è più controllabile quando la risposta rimanda ai documenti e ai passaggi rilevanti. L'esempio fittizio in slide mostra una risposta di un assistente sulle procedure interne. La risposta indica il documento, la versione, la sezione, e riporta il passaggio. Questo permette all'utente tre cose. Verificare rapidamente che la risposta corrisponda a ciò che dice il documento. Controllare che il documento sia quello giusto e aggiornato: in questo caso la versione e la data. Approfondire, leggendo il contesto del passaggio, che spesso contiene condizioni ed eccezioni che la risposta ha omesso. Una risposta senza riferimenti, invece, non permette di distinguere un'informazione tratta dalla documentazione aziendale da un'informazione generica prodotta dal modello. Per chi valuta o sceglie uno strumento di questo tipo, la presenza di riferimenti precisi e cliccabili è un requisito importante. Per chi lo usa, la buona pratica è aprire il riferimento ogni volta che la risposta servirà per una decisione o un'azione con conseguenze.");
    modeTag(s, 3);
    shapeBox(s, 0.5, 1.15, 5.6, 3.0, C.background2, "risposta assistente");
    txt(s, "Domanda: entro quando va presentata la nota spese?", { x: 0.7, y: 1.25, w: 5.2, h: 0.35, fontSize: 12, bold: true, color: C.text1 });
    txt(s, "La nota spese va presentata entro 30 giorni dalla fine della trasferta, allegando i giustificativi in originale.", { x: 0.7, y: 1.65, w: 5.2, h: 0.7, fontSize: 12, color: C.text1 });
    docBox(s, 0.7, 2.45, 5.2, 1.55, "Fonte: Procedura rimborsi spese, v. 3.2 (gennaio), §4.1", "\"Le note spese devono essere presentate entro 30 giorni dalla conclusione della trasferta. Per le trasferte superiori a 15 giorni è ammessa la presentazione di note intermedie.\"", { fill: C.background1, fontSize: 11 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 4.2, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    await card(s, 6.35, 1.15, 3.15, 3.0, { icon: "FiLink", head: "Il riferimento permette di", headSize: 14, bodySize: 12, fill: C.accent6,
      body: bullets(["Verificare la risposta", "Controllare documento e versione", "Leggere il contesto: qui c'è un'eccezione omessa"], { space: 5 }) });
    txt(s, "Senza riferimenti non si distingue la documentazione aziendale dalla conoscenza generica del modello.", { x: 0.5, y: 4.5, w: 9, h: 0.45, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Aggiornamento e versionamento", "Un aspetto spesso sottovalutato della conoscenza interrogabile è il tempo. Le procedure cambiano, i listini si aggiornano, i contratti vengono rinnovati, le persone cambiano ruolo. Un archivio che contiene più versioni dello stesso documento, senza indicare quale è valida, è un problema già per una persona; per un sistema AI lo è di più, perché il recupero può trovare il passaggio della versione vecchia, magari perché è scritto in modo più simile alla domanda, e la risposta viene presentata con la stessa sicurezza. Il risultato è un'informazione superata, con l'aspetto di un'informazione aggiornata e documentata. Alcune condizioni rendono la raccolta più affidabile nel tempo. Chiarezza sulla versione valida: documenti superati rimossi o chiaramente marcati come tali. Date e numeri di versione visibili nei documenti. Responsabilità definite per l'aggiornamento di ciascun documento. Riesami periodici della raccolta. Per l'utente, il comportamento pratico è controllare la versione e la data del documento citato, specialmente per regole, prezzi e scadenze. Le modalità con cui l'azienda gestisce questi processi appartengono al Tema 14.");
    modeTag(s, 3);
    docBox(s, 0.5, 1.15, 2.8, 1.3, "Procedura rimborsi v. 2.0", "Presentazione entro 60 giorni", { fill: C.background2, bar: C.accent2, labelColor: C.accent2 });
    docBox(s, 0.5, 2.6, 2.8, 1.3, "Procedura rimborsi v. 3.2", "Presentazione entro 30 giorni", { fill: C.accent6 });
    chip(s, 3.45, 1.55, 1.5, 0.5, "Superata", { fill: C.accent5, color: C.background1, fontSize: 12 });
    chip(s, 3.45, 3.0, 1.5, 0.5, "Valida", { fill: C.accent1, color: C.background1, fontSize: 12 });
    await card(s, 5.2, 1.15, 4.3, 2.75, { icon: "FiAlertTriangle", inline: true, head: "Se convivono senza indicazioni", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: "Il recupero può trovare la versione vecchia, e la risposta arriva con la stessa sicurezza: un'informazione superata con l'aspetto di un'informazione aggiornata e documentata." });
    const cd = ["Versione valida chiara", "Date e versioni visibili", "Responsabili dell'aggiornamento", "Riesami periodici"];
    cd.forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.1, 2.15, 0.55, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Per l'utente: controllare versione e data del documento citato.", { x: 0.5, y: 4.72, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Condizioni per risposte utili", "Riassumiamo le condizioni necessarie per ottenere risposte utili da una raccolta documentale, che il sottotema chiede di comprendere. Sul lato dei documenti: contenuti corretti, aggiornati e non contraddittori; una struttura chiara, con titoli e sezioni che rendano facile trovare le informazioni; informazioni esplicite, perché ciò che è dato per scontato o è solo nella testa delle persone non può essere recuperato; formati leggibili, tema dell'8.8. Sul lato della raccolta: un perimetro chiaro, cioè sapere quali documenti contiene e quali no; versioni gestite; permessi coerenti, perché ciascuno dovrebbe poter interrogare solo ciò che è autorizzato a vedere. Sul lato dell'uso: domande chiare e specifiche, che usino quando possibile il lessico dei documenti; consapevolezza del perimetro, perché se la risposta non è nella raccolta il sistema potrebbe comunque rispondere; controllo dei riferimenti per le risposte con conseguenze. Il concetto chiave lo riassume: l'AI agevola l'accesso, ma non risolve da sola i problemi di organizzazione e qualità della conoscenza. Anzi, spesso li rende più visibili.");
    modeTag(s, 3);
    const col = [["FiFileText", "Documenti", ["Corretti, aggiornati, coerenti", "Struttura chiara", "Informazioni esplicite", "Formati leggibili"]], ["FiDatabase", "Raccolta", ["Perimetro chiaro", "Versioni gestite", "Permessi coerenti"]], ["FiUser", "Uso", ["Domande chiare, lessico dei documenti", "Consapevolezza del perimetro", "Controllo dei riferimenti"]]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.15, 2.86, 2.95, { icon: col[i][0], inline: true, head: col[i][1], headSize: 16, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: bullets(col[i][2], { space: 5 }) });
    }
    banner(s, 4.3, "L'AI agevola l'accesso, ma non risolve da sola i problemi di organizzazione e qualità. Spesso li rende più visibili.", { h: 0.65, fontSize: 13 });
  }
  keySlide("L'AI può agevolare l'accesso alle informazioni documentali, ma non risolve da sola i problemi di organizzazione e qualità della conoscenza.", "Sottotema 8.7  ·  AI e gestione della conoscenza", "Concetto chiave del sottotema 8.7. L'AI permette di interrogare raccolte documentali in linguaggio naturale, con assistenti sulle procedure, sulla documentazione tecnica, sulle condizioni contrattuali. È una possibilità di grande valore. Ma un archivio non è automaticamente conoscenza interrogabile: servono reperibilità, struttura, aggiornamento, qualità e possibilità di verifica. Il funzionamento in due passaggi, recupero e generazione, spiega perché le risposte possono essere incomplete, superate o sbagliate anche quando l'informazione è nella raccolta. Le risposte collegate ai documenti, con versione e passaggio, rendono l'accesso controllabile. Esercizio suggerito: se in azienda è disponibile uno strumento autorizzato per creare un piccolo assistente su documenti, caricare alcune procedure fittizie, di cui una in due versioni contraddittorie, e osservare come risponde alle domande, verificando i riferimenti.");

  // =====================================================================
  section("8.8 Limiti");
  divider("8.8", "Limiti e condizioni di efficacia", "Caricare un documento non garantisce che il sistema ne abbia elaborato tutte le parti e preservato il significato", "Ultimo sottotema, di consapevolezza critica, che attraversa tutte le modalità. Nei sottotemi precedenti abbiamo incontrato più volte limiti specifici: perdite di significato, riferimenti imprecisi, campi inventati, versioni superate. Qui li mettiamo insieme e li guardiamo dal punto di vista delle condizioni di efficacia: da che cosa dipende il fatto che un'elaborazione documentale funzioni bene o male. Non ripetiamo la teoria generale delle allucinazioni e dell'affidabilità del Tema 3: ne consideriamo gli effetti specifici sui documenti. E concludiamo con il principio dei controlli proporzionati all'uso, applicato al lavoro documentale.");
  {
    const s = content("Caricare non significa elaborare", "Il concetto chiave del sottotema contiene un'osservazione che vale la pena mettere all'inizio: poter caricare un documento non garantisce che il sistema ne abbia elaborato tutte le parti, interpretato correttamente il contenuto e preservato il significato. Quando carichiamo un file e otteniamo una risposta sicura e ben organizzata, tendiamo a pensare che il sistema abbia letto il documento come lo leggeremmo noi, tutto e con attenzione. Non è necessariamente così, per diversi motivi che vedremo. Il file può essere stato convertito in testo in modo incompleto: le tabelle possono essere state appiattite, le immagini ignorate, le scansioni lette male. Il documento può essere troppo lungo per essere elaborato interamente, oppure alcune parti possono ricevere meno attenzione di altre. Alcuni strumenti, con documenti molto grandi, ne usano solo i passaggi ritenuti pertinenti alla domanda. E anche quando il testo è tutto disponibile, l'interpretazione può essere sbagliata. Il problema è che nulla di tutto questo è visibile nella risposta. La risposta ha sempre lo stesso aspetto, sicuro e completo, sia quando il sistema ha elaborato tutto, sia quando ne ha elaborato una parte.");
    modeTag(s, -1);
    const st = [["FiUpload", "Caricato", "Il file è stato accettato"], ["FiFileText", "Convertito", "Tabelle, immagini, scansioni: tutto letto?"], ["FiLayers", "Elaborato", "Tutte le parti, con la stessa attenzione?"], ["FiCheckCircle", "Compreso", "Interpretato correttamente?"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.1, 2.1, i === 0 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.32, 0.65, st[i][0], i === 0 ? C.accent1 : C.accent2);
      txt(s, st[i][1], { x: x + 0.1, y: 2.05, w: 1.9, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.12, y: 2.45, w: 1.86, h: 0.8, fontSize: 11, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Ogni passaggio può fallire in modo invisibile", { x: 0.5, y: 3.45, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent5, align: "center" });
    banner(s, 3.95, "La risposta ha sempre lo stesso aspetto, sicuro e completo, sia che il sistema abbia elaborato tutto, sia che ne abbia elaborato una parte.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Qualità e struttura dei documenti", "La prima condizione di efficacia riguarda i documenti di partenza. Un principio noto nell'informatica dice: se entra spazzatura, esce spazzatura. Vale anche qui, con una differenza importante: con l'AI, da documenti di scarsa qualità esce un risultato che non sembra spazzatura, perché è ben scritto e ben organizzato. Che cosa rende un documento adatto all'elaborazione? Un contenuto corretto, completo e coerente: se il documento contiene errori o contraddizioni, il sistema li riporterà, o sceglierà una delle versioni contraddittorie senza segnalarlo. Una struttura chiara: titoli, sezioni, numerazione, paragrafi con un tema ciascuno. Il linguaggio esplicito: abbreviazioni non spiegate, riferimenti impliciti come 'come concordato' o 'la solita procedura' non sono interpretabili. Un formato digitale nativo, cioè un file prodotto da un programma di scrittura, piuttosto che una scansione. Documenti con queste caratteristiche producono risultati migliori, sono più facili da controllare, e sono gli stessi che funzionano meglio anche per i lettori umani. Migliorare la qualità dei documenti è quindi un investimento che vale doppio.");
    modeTag(s, -1);
    await iconGrid(s, [
      { icon: "FiCheckSquare", head: "Contenuto corretto e coerente", body: "Errori e contraddizioni vengono riportati, o risolti in silenzio" },
      { icon: "FiList", head: "Struttura chiara", body: "Titoli, sezioni, numerazione, un tema per paragrafo" },
      { icon: "FiMessageSquare", head: "Linguaggio esplicito", body: "'Come concordato', 'la solita procedura': non interpretabili" },
      { icon: "FiFile", head: "Formato digitale nativo", body: "Meglio un file nativo che una scansione" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Se entra spazzatura, esce spazzatura. Con l'AI, però, il risultato non sembra spazzatura: è ben scritto e ben organizzato.", { h: 0.65, fontSize: 13 });
    txt(s, "I documenti che funzionano meglio per l'AI sono gli stessi che funzionano meglio per le persone.", { x: 0.5, y: 4.67, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Digitali, scansionati, impaginati", "Il formato del documento incide molto sulla qualità dell'elaborazione. Un documento digitale nativo, come un file Word o un PDF prodotto da un programma, contiene il testo in forma leggibile dal computer. Un documento scansionato è invece un'immagine: per elaborarlo, il testo deve essere riconosciuto, con tecniche di riconoscimento ottico o con le capacità visive dei modelli multimodali. Il riconoscimento può sbagliare, specialmente con scansioni di bassa qualità, scritture a mano, timbri, firme, caratteri piccoli, documenti storti o macchiati. E un errore di riconoscimento su una cifra cambia un importo. Anche nei documenti digitali, alcune parti sono più difficili del testo continuo. Le tabelle: possono essere lette riga per riga in modo corretto, oppure appiattite, con le celle mescolate e i valori associati alle intestazioni sbagliate. Le immagini e i grafici: a seconda dello strumento possono essere ignorati, descritti in modo generico o interpretati in modo impreciso. Le impaginazioni complesse: testo su più colonne, note a piè di pagina, riquadri, intestazioni ripetute, possono essere lette nell'ordine sbagliato. La multimodalità in sé appartiene al Tema 10: qui ci interessa il suo impatto sulla lettura dei documenti.");
    modeTag(s, -1);
    table(s, [["Elemento", "Che cosa può succedere", "Che cosa controllare"],
      ["Scansioni", "Riconoscimento errato di cifre e parole", "Importi, date, nomi nei punti critici"],
      ["Scritture a mano, timbri", "Letti male o ignorati", "Se contengono informazioni rilevanti"],
      ["Tabelle", "Celle mescolate, valori sotto l'intestazione sbagliata", "Alcuni valori riga per riga"],
      ["Immagini e grafici", "Ignorati o interpretati in modo impreciso", "Se l'informazione è solo lì"],
      ["Colonne, note, riquadri", "Ordine di lettura sbagliato", "Il senso dei passaggi collegati"]],
      { y: 1.15, colW: [2.2, 3.6, 3.2], rowH: 0.5, fontSize: 12, blankCorner: false });
    banner(s, 4.35, "Un errore di riconoscimento su una cifra cambia un importo.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Documenti lunghi e copertura", "Un limite specifico riguarda i contenuti molto lunghi. Anche se i sistemi attuali accettano documenti di centinaia di pagine, la lunghezza crea tre problemi. Il primo è il limite di contesto, visto nel Tema 2: oltre una certa dimensione, il documento non può essere considerato tutto insieme, e lo strumento ne usa solo una parte, o lo elabora a pezzi, spesso senza avvisare. Il secondo è l'attenzione non uniforme: studi sui modelli linguistici, come quello di Liu e colleghi sul fenomeno chiamato 'lost in the middle', hanno mostrato che le informazioni nella parte centrale di testi lunghi tendono a essere usate meno di quelle all'inizio e alla fine. I modelli più recenti hanno migliorato questo aspetto, ma non lo hanno eliminato. Il terzo è la copertura: in una sintesi o in un'analisi di un documento lungo, alcune sezioni possono essere trattate in dettaglio e altre ignorate, senza che la risposta lo dica. Per valutare la copertura, alcune tecniche pratiche: chiedere una sintesi per sezioni, che rende visibile se una sezione manca; porre domande mirate su parti specifiche, specialmente centrali; per i documenti lunghi e importanti, elaborarli per parti, con richieste distinte, e poi ricomporre.");
    modeTag(s, -1);
    await iconGrid(s, [
      { icon: "FiMaximize", head: "Limite di contesto", body: "Oltre una certa dimensione, solo una parte o a pezzi, spesso senza avviso" },
      { icon: "FiTarget", head: "Attenzione non uniforme", body: "Le parti centrali tendono a essere usate meno (Liu et al.)" },
      { icon: "FiPieChart", head: "Copertura", body: "Alcune sezioni in dettaglio, altre ignorate, senza dirlo" },
    ], 3, { y: 1.15, h: 1.75, headSize: 13, bodySize: 12 });
    txt(s, "Come valutare la copertura", { x: 0.5, y: 3.1, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    chip(s, 0.5, 3.5, 2.9, 0.65, "Sintesi per sezioni: si vede se una manca", { fill: C.accent6, fontSize: 11 });
    chip(s, 3.55, 3.5, 2.9, 0.65, "Domande mirate sulle parti centrali", { fill: C.accent6, fontSize: 11 });
    chip(s, 6.6, 3.5, 2.9, 0.65, "Elaborare per parti, poi ricomporre", { fill: C.accent6, fontSize: 11 });
    txt(s, "I modelli più recenti hanno migliorato questi aspetti, ma non li hanno eliminati.", { x: 0.5, y: 4.4, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Linguaggio tecnico e riferimenti", "Altri due limiti, frequenti nella documentazione aziendale. Il linguaggio tecnico e specialistico: documenti giuridici, tecnici, medici, finanziari usano termini con significati precisi, spesso diversi dal significato comune. 'Risoluzione' in un contratto, 'tolleranza' in una specifica tecnica, 'competenza' in contabilità. Il sistema conosce molti linguaggi specialistici, ma può interpretare un termine nel senso comune, confondere termini vicini, o non conoscere il gergo specifico di un settore o di un'azienda, con le sue sigle e i suoi codici. Il risultato può essere una sintesi scorrevole e sbagliata, difficile da riconoscere per chi non è esperto. Per questo, sui documenti specialistici, la revisione di chi conosce la materia resta indispensabile, come visto nel Tema 7. I riferimenti puntuali: come visto nell'8.3, i sistemi possono indicare articoli, pagine o sezioni in modo impreciso. La precisione dipende dallo strumento e dal formato: alcuni strumenti mostrano il passaggio esatto, altri ricostruiscono il riferimento in modo approssimativo. I numeri di pagina sono particolarmente fragili, perché la numerazione del documento può non coincidere con quella del file. Per i riferimenti importanti, aprire il documento nel punto indicato resta l'unico controllo affidabile.");
    modeTag(s, -1);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiCpu", head: "Linguaggio specialistico", headSize: 16, bodySize: 12,
      body: bullets(["Termini con significato tecnico preciso", "'Risoluzione', 'tolleranza', 'competenza'", "Sigle, codici e gergo aziendale", "Sintesi scorrevole e sbagliata"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiBookmark", head: "Riferimenti puntuali", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Articoli, pagine, sezioni imprecisi", "Dipende da strumento e formato", "Pagine del documento e del file diverse"], { space: 4 }) });
    banner(s, 3.8, "Sui documenti specialistici, la revisione esperta resta indispensabile. Per i riferimenti importanti, aprire il documento nel punto indicato.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Omissioni e alterazioni", "Torniamo, in chiusura, ai rischi che attraversano tutto il tema: omissioni e alterazioni. L'integrazione C, già vista nell'8.3, viene ripresa qui in forma generale: la riduzione o trasformazione di un documento può nascondere elementi decisivi anche quando il risultato appare scorrevole e ben organizzato. Le omissioni sono elementi presenti nel documento e assenti nel risultato: una condizione, un'eccezione, un rischio, una sezione intera. Le alterazioni sono elementi presenti in entrambi, ma con un significato diverso: un obbligo attenuato, un'incertezza trasformata in certezza, un importo cambiato, un'attribuzione spostata. Si aggiungono le aggiunte: elementi presenti nel risultato e assenti nel documento, dedotti o inventati dal sistema. In tutte le modalità del tema ritroviamo questi tre rischi in forme diverse: nella trasformazione dei testi, nella sintesi, nell'estrazione, nel confronto, nella consultazione documentale. Il denominatore comune è che sono difficili da vedere guardando solo il risultato. Si vedono confrontandolo con l'originale, sapendo che cosa cercare. Per questo la tracciabilità, che abbiamo incontrato in quasi tutti i sottotemi, non è un dettaglio tecnico: è la condizione che rende possibile il controllo.");
    modeTag(s, -1);
    const r = [["FiMinusCircle", "Omissioni", "Nel documento, non nel risultato", "Condizioni, eccezioni, rischi, sezioni"], ["FiShuffle", "Alterazioni", "In entrambi, con significato diverso", "Obblighi attenuati, incertezze diventate certezze"], ["FiPlusCircle", "Aggiunte", "Nel risultato, non nel documento", "Elementi dedotti o inventati"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.4, C.background2, r[i][1]);
      await iconCircle(s, x + 0.2, 1.3, 0.6, r[i][0], C.accent5);
      txt(s, r[i][1], { x: x + 0.95, y: 1.35, w: 1.8, h: 0.5, fontSize: 17, bold: true, color: C.text1, valign: "middle" });
      txt(s, r[i][2], { x: x + 0.2, y: 2.05, w: 2.46, h: 0.55, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, r[i][3], { x: x + 0.2, y: 2.62, w: 2.46, h: 0.85, fontSize: 12, color: C.text2 });
    }
    banner(s, 3.75, "Difficili da vedere guardando solo il risultato. La tracciabilità non è un dettaglio tecnico: è la condizione che rende possibile il controllo.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Controlli proporzionati all'uso", "L'ultimo punto del sottotema è la necessità di controlli proporzionati all'utilizzo previsto, il principio che abbiamo sviluppato nel Tema 7 e che qui applichiamo al lavoro documentale. Non ogni elaborazione richiede lo stesso controllo. La matrice in slide propone tre livelli. Per orientarsi, cioè per capire di che cosa parla un documento, decidere se leggerlo, prepararsi a una riunione, basta una lettura critica del risultato: è plausibile, manca qualcosa di ovvio? Per lavorare, cioè quando il risultato serve per un'attività interna, come una bozza, un'analisi preliminare, una tabella di lavoro, conviene controllare a campione e sui punti critici, usando i riferimenti. Per decidere o comunicare all'esterno, cioè quando il risultato sostituisce la lettura dell'originale per una decisione con conseguenze, o arriva a clienti, fornitori, enti, serve un controllo sistematico sugli elementi critici, con il confronto con l'originale e, se necessario, la revisione di un esperto. Due fattori alzano il livello: documenti di qualità incerta, come scansioni o documenti lunghi e complessi, e contenuti specialistici o con valore legale.");
    modeTag(s, -1);
    const lv = [["Per orientarsi", "Capire di che cosa parla, decidere se leggerlo", "Lettura critica del risultato", C.background2, C.text1], ["Per lavorare", "Bozze, analisi preliminari, tabelle di lavoro", "Controllo a campione e sui punti critici, con i riferimenti", C.accent6, C.text1], ["Per decidere o comunicare", "Sostituisce l'originale, arriva all'esterno", "Controllo sistematico, confronto con l'originale, esperto se serve", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.9;
      shapeBox(s, 0.5, y, 9.0, 0.8, l[3], l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.3, h: 0.8, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 3.0, y, w: 2.9, h: 0.8, fontSize: 12, color: l[4], valign: "middle" });
      txt(s, l[2], { x: 6.0, y, w: 3.35, h: 0.8, fontSize: 12, bold: true, color: l[4], valign: "middle" });
    });
    txt(s, "Alzano il livello", { x: 0.5, y: 3.95, w: 2.3, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.8, 3.95, 3.25, 0.55, "Scansioni, documenti lunghi o complessi", { fill: C.background2, fontSize: 11 });
    chip(s, 6.2, 3.95, 3.3, 0.55, "Contenuti specialistici o con valore legale", { fill: C.background2, fontSize: 11 });
    txt(s, "Più il risultato sostituisce la lettura dell'originale, più deve essere controllato.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Poter caricare un documento non garantisce che il sistema ne abbia elaborato tutte le parti, interpretato correttamente il contenuto e preservato il significato.", "Sottotema 8.8  ·  Limiti e condizioni di efficacia", "Concetto chiave dell'ultimo sottotema. L'efficacia dell'elaborazione documentale dipende dalla qualità e dalla struttura dei documenti, dal formato, dalla presenza di tabelle, immagini e impaginazioni complesse, dalla lunghezza, dal linguaggio specialistico. Omissioni, alterazioni e aggiunte attraversano tutte le modalità e sono difficili da vedere guardando solo il risultato. Per questo servono tracciabilità e controlli proporzionati all'uso. Esercizio suggerito: caricare in uno strumento autorizzato un documento fittizio con una tabella, una nota a piè di pagina e una sezione centrale contenente un'informazione chiave, e verificare con domande mirate che cosa il sistema ha effettivamente elaborato.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle undici domande guida. Attività oltre la scrittura: trasformare, sintetizzare, estrarre, confrontare, ricercare, consultare raccolte documentali. Generare o trasformare: trasformare quando esiste materiale corretto, perché riduce le invenzioni e offre un originale per il controllo. Sintetizzare senza perdere condizioni: dichiarare lo scopo, chiedere riferimenti e un elenco separato di condizioni ed eccezioni. Sintesi o estrazione: la prima produce un testo da leggere, la seconda dati da usare, con controllo campo per campo. Confrontare documenti: riferimenti a entrambi i passaggi, differenze classificate per natura. Ricerca o raccolta: fonti esterne da verificare, oppure documenti dell'organizzazione con risposte collegate. Raccolta interrogabile: reperibilità, struttura, aggiornamento, qualità, verificabilità. Dal non strutturato ai dati: campi definiti, regole per i mancanti, validazione prima dell'uso. Formati e lunghezza: conversione, attenzione non uniforme, copertura. Sintesi fedele: confronto con l'originale sugli elementi decisivi. Quando risalire alle fonti: in proporzione all'uso, sempre quando il risultato sostituisce l'originale. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Oltre la scrittura?", "Trasformare, sintetizzare, estrarre, confrontare, consultare"], ["Generare o trasformare?", "Trasformare il materiale corretto, quando c'è"], ["Sintesi senza perdite?", "Scopo, riferimenti, elenco di condizioni ed eccezioni"], ["Sintesi o estrazione?", "Testo da leggere o dati da usare"], ["Confrontare con i passaggi?", "Riferimenti a entrambi, differenze classificate"], ["Ricerca o raccolta?", "Fonti esterne o documenti dell'organizzazione"], ["Raccolta interrogabile?", "Reperibile, strutturata, aggiornata, verificabile"], ["Dal testo ai dati?", "Campi definiti, regole, validazione"], ["Formati e lunghezza?", "Conversione, attenzione, copertura"], ["Sintesi fedele?", "Confronto con l'originale sugli elementi decisivi"], ["Quando risalire alle fonti?", "In proporzione all'uso, sempre se sostituisce l'originale"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.6, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.6, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.03, w: 3.8, h: 0.28, fontSize: 11, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.3, w: 3.8, h: 0.28, fontSize: 10, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: riconoscere le possibilità dell'AI per testi e documenti; distinguere generazione, trasformazione, analisi ed estrazione; comprendere opportunità e limiti nella redazione e revisione; identificare utilizzi nella sintesi e nell'analisi documentale; comprendere come ottenere dati strutturati da informazioni non strutturate; riconoscere modalità di confronto tra documenti e versioni; distinguere ricerca informativa e interrogazione di una raccolta documentale; comprendere il potenziale della conoscenza documentale interrogabile; riconoscere l'importanza della tracciabilità verso le fonti originali; individuare rischi di omissione, perdita di significato e interpretazione errata; comprendere come qualità dei file, formati e complessità incidano sull'elaborazione; riconoscere quando serve una verifica più approfondita.");
    const r = ["Riconoscere le possibilità su testi e documenti", "Distinguere generare, trasformare, analizzare, estrarre", "Opportunità e limiti in redazione e revisione", "Utilizzi nella sintesi e nell'analisi documentale", "Dati strutturati da informazioni non strutturate", "Confronto tra documenti e versioni", "Ricerca informativa o raccolta documentale", "Il potenziale della conoscenza interrogabile", "L'importanza della tracciabilità", "Omissioni, perdita di significato, errori", "Effetto di file, formati e complessità", "Quando serve una verifica più approfondita"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Quattro modalità: una scheda pratica", "Traduciamo il modulo in una scheda pratica, organizzata per modalità. Produrre: fornire il materiale di partenza, indicare destinatario e tono, scegliere il livello di supervisione in base alle conseguenze e alla visibilità del testo. Trasformare: partire da materiale corretto, dichiarare le modifiche ammesse, confrontare con l'originale gli elementi che non devono cambiare. Analizzare e strutturare: dichiarare lo scopo della sintesi, chiedere riferimenti ai passaggi, definire campi e regole per i mancanti nelle estrazioni, classificare le differenze nei confronti, validare prima dell'uso. Recuperare conoscenza: chiedersi da dove viene l'informazione, controllare attualità e attendibilità, aprire i riferimenti, controllare versione e data dei documenti. E per tutte le modalità: caricare i documenti solo negli strumenti autorizzati; tenere presenti i limiti di formato, lunghezza e linguaggio; proporzionare i controlli all'uso. Non confondere un'elaborazione convincente con un'elaborazione completa e verificata: è il messaggio centrale del tema.");
    const f = [["Produrre", ["Materiale di partenza", "Destinatario e tono", "Supervisione proporzionata"], C.background2], ["Trasformare", ["Partire da materiale corretto", "Modifiche ammesse dichiarate", "Confronto con l'originale"], C.accent6], ["Analizzare", ["Scopo e riferimenti", "Campi e regole per i mancanti", "Differenze classificate, validazione"], C.background2], ["Recuperare", ["Da dove viene?", "Attualità e attendibilità", "Riferimenti, versione e data"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: strumenti autorizzati, limiti di formato e lunghezza, controlli proporzionati all'uso.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei errori tipici nel lavoro su testi e documenti, uno per ciascuno dei principali messaggi del modulo. Primo: generare da zero quando esiste già un testo con i contenuti corretti. Trasformare il materiale esistente riduce le invenzioni e rende il controllo più semplice. Secondo: pensare che una sintesi sia fedele perché ogni frase è vera. Le perdite di significato stanno in ciò che manca: condizioni, eccezioni, incertezze. Terzo: usare un dato estratto come se fosse già validato. Gli errori di estrazione si propagano nei fogli di calcolo, nei report, nelle decisioni. Quarto: credere che l'AI abbia trovato tutte le differenze tra due versioni. L'elenco può essere incompleto, e per i documenti importanti serve anche il confronto tradizionale. Quinto: pensare che basti collegare l'AI all'archivio. Senza documenti aggiornati, strutturati e con le versioni gestite, le risposte ereditano il disordine. Sesto: dare per scontato che un documento caricato sia stato letto tutto. Conversione, attenzione e copertura possono fallire senza segnali. Suggerimento: chiedere ai partecipanti quale di questi errori vedono più spesso nel proprio lavoro.");
    const a = [["FiEdit3", "\"Lo genero da zero\"", "Se c'è il testo giusto, trasformarlo", "8.2"], ["FiFileText", "\"Ogni frase è vera, quindi è fedele\"", "Le perdite stanno in ciò che manca", "8.3"], ["FiDatabase", "\"Il dato estratto è pronto all'uso\"", "Estratto non vuol dire validato", "8.4"], ["FiColumns", "\"Ha trovato tutte le differenze\"", "L'elenco può essere incompleto", "8.5"], ["FiArchive", "\"Basta collegare l'AI all'archivio\"", "Le risposte ereditano il disordine", "8.7"], ["FiUpload", "\"L'ho caricato, quindi l'ha letto\"", "Caricare non è elaborare", "8.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 8 si apre l'area 'Esplorare le possibilità dell'AI', che guarda a che cosa si può fare concretamente con l'AI nei diversi ambiti di lavoro. Abbiamo iniziato dai testi, dai documenti e dalla conoscenza, perché è l'ambito più maturo e più trasversale. Il tema successivo, il Tema 9, è dedicato all'AI per dati e analisi: preparazione, elaborazione, analisi, interpretazione e rappresentazione dei dati. È il naturale proseguimento dell'8.4: abbiamo visto come trasformare testi in dati strutturati, ora vedremo come analizzarli. I documenti di perimetro richiamano poi altri temi dell'area e del percorso: l'AI multimodale, nel Tema 10; assistenti, agenti e automazioni, nel Tema 11, dove torneranno gli assistenti documentali e i flussi di estrazione automatica; AI, dati e conoscenza aziendale, nel Tema 14, dove si affronta la progettazione dei sistemi di conoscenza in azienda. In tutti questi temi resteranno validi i principi di questo modulo: fedeltà del significato, completezza, tracciabilità verso le fonti. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi, documenti e conoscenza (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.5, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 9: AI per dati e analisi", { x: 5.4, y: 1.72, w: 3.9, h: 0.4, fontSize: 16, bold: true, color: C.background1 });
    txt(s, "Dal testo strutturato all'analisi dei dati", { x: 5.4, y: 2.1, w: 3.9, h: 0.3, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 2.6, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 10: AI multimodale", "Tema 11: assistenti, agenti e automazioni", "Tema 14: dati e conoscenza aziendale"], { space: 5 }), { x: 5.4, y: 2.95, w: 3.9, h: 1.6, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Lo studio di Liu e colleghi è già presentato nel Tema 2; il lavoro di Lewis e colleghi introduce l'architettura RAG, qui solo accennata e approfondita nel Tema 14. Il modulo si basa soprattutto sull'esperienza pratica dell'uso dell'AI su testi e documenti, che evolve rapidamente: le capacità degli strumenti nella gestione di documenti lunghi, tabelle e scansioni migliorano di continuo. Prima di ogni edizione è consigliabile verificare le funzionalità degli strumenti autorizzati in azienda, e aggiornare gli esempi di conseguenza. Gli esempi usati nelle slide sono tutti fittizi.");
    const src = [
      "Liu, N. F. et al. (2024). Lost in the Middle: How Language Models Use Long Contexts. Transactions of the ACL, 12, 157-173.",
      "Lewis, P. et al. (2020). Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS 2020.",
      "Gli esempi di documenti, email, offerte e procedure presenti nelle slide sono fittizi.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema8_AI_testi_documenti_conoscenza.pptx" });
  await applyTheme("Tema8_AI_testi_documenti_conoscenza.pptx", THEME);
  console.log("done");
})();
