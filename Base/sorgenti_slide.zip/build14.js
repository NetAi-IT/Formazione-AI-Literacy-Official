const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 14: AI, dati e conoscenza aziendale";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 14  ·  AI, dati e conoscenza aziendale";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5, X = o.x || 0.5, W = o.w || 9.0;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, X, y, W, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: X + 0.15, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: X + 0.15 + lw, y, w: W - 0.3 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }
  function infoTag(s, active) {
    const st = ["Patrimonio", "Qualità", "Utilizzo", "Controllo", "Condizioni"];
    st.forEach((t, i) => {
      const x = 6.2 + i * 0.66;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.63, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "dimensione " + t });
      txt(s, t, { x, y: 0.42, w: 0.63, h: 0.26, fontSize: 7, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 14", { placeholder: "kicker" });
    s.addText("AI, dati e conoscenza aziendale", { placeholder: "title" });
    s.addText("Area: Comprendere il valore per l'azienda", { placeholder: "sub" });
    s.addNotes("Benvenuti al quattordicesimo tema, il terzo dell'area 'Comprendere il valore per l'azienda'. Nei Temi 12 e 13 abbiamo visto che il valore dell'AI e la trasformazione del lavoro dipendono da condizioni organizzative. Più volte è emersa una condizione in particolare: le informazioni. La trasformabilità di un'attività dipende dalla disponibilità delle informazioni necessarie; le conoscenze organizzative rischiano di perdersi; un assistente vale quanto le fonti su cui si basa. In questo tema guardiamo proprio al patrimonio informativo dell'azienda: che cosa contiene, quanto è affidabile, come è organizzato, come l'AI può usarlo, con quali permessi e con quale affidabilità delle risposte. Il confine cardine, indicato dal documento di perimetro, è con il Tema 8. Lì abbiamo visto che cosa l'AI può fare con i documenti: sintetizzare, estrarre, confrontare, rispondere. Qui guardiamo a come l'organizzazione rende il proprio patrimonio informativo utilizzabile, pertinente e accessibile in modo controllato. Non è un tema tecnico: le architetture, i database, le integrazioni sono solo accennati. È un tema di consapevolezza, utile a chiunque usi, chieda o valuti un assistente AI collegato ai dati aziendali. Suggerimento per l'apertura: chiedere ai partecipanti quanto tempo hanno impiegato l'ultima volta per trovare un documento aziendale aggiornato, e se erano sicuri che fosse la versione giusta.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere il ruolo del patrimonio informativo aziendale nell'utilizzo dell'AI, riconoscendo l'importanza della qualità, dell'organizzazione, dell'accessibilità, dell'aggiornamento e dell'integrazione dei dati e delle conoscenze. La consapevolezza da sviluppare parte da un fatto che molti trascurano: un modello AI, anche molto avanzato, non conosce automaticamente le informazioni interne di un'organizzazione. Non sa quali sono i listini in vigore, le procedure approvate, i contratti con i clienti, le decisioni prese nell'ultima riunione. Ha imparato da testi pubblici, come visto nel Tema 2, e le informazioni aziendali, salvo eccezioni, non ne facevano parte. Per usarle efficacemente, il sistema deve poter accedere a fonti pertinenti e affidabili, attraverso modalità tecniche appropriate, e con autorizzazioni coerenti con le finalità dell'uso. Ognuna di queste condizioni è necessaria: fonti affidabili, modalità tecniche adatte, autorizzazioni corrette. Il messaggio di sintesi del tema: l'informazione aziendale diventa un fattore abilitante dell'AI quando è sufficientemente corretta, aggiornata, organizzata, reperibile e accessibile in modo controllato.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Capire il ruolo del patrimonio informativo nell'uso dell'AI", "Riconoscere l'importanza di qualità, organizzazione, accessibilità, aggiornamento, integrazione"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Un modello AI non conosce automaticamente le informazioni interne di un'azienda.\n\nPer usarle servono fonti pertinenti e affidabili, modalità tecniche appropriate, autorizzazioni coerenti con lo scopo." });
  }
  {
    const s = content("Quattro condizioni distinte", "Il documento di perimetro chiede di distinguere quattro condizioni, che useremo per tutto il modulo come una lista di controllo. Disponibilità: le informazioni esistono, da qualche parte. Accessibilità: il sistema può accedervi quando serve, ed è autorizzato a farlo. Utilizzabilità: le informazioni sono organizzate, pertinenti e interpretabili, cioè si possono trovare e capire. Affidabilità: le informazioni sono sufficientemente corrette e aggiornate per lo scopo. Le quattro condizioni sono indipendenti. Un'informazione può esistere ma non essere accessibile, perché sta nella casella di posta di una persona o in un sistema non collegato. Può essere accessibile ma non utilizzabile, perché è dispersa in cento file con nomi poco chiari. Può essere utilizzabile ma non affidabile, perché è la versione dell'anno scorso. Quando un assistente AI aziendale dà una risposta sbagliata o incompleta, una delle prime domande da porsi è: quale di queste quattro condizioni è mancata? È una domanda che aiuta a non attribuire tutto al modello, e a capire dove intervenire.");
    const d = [["FiDatabase", "Disponibilità", "Le informazioni esistono"], ["FiKey", "Accessibilità", "Il sistema può accedervi ed è autorizzato"], ["FiLayers", "Utilizzabilità", "Organizzate, pertinenti, interpretabili"], ["FiShield", "Affidabilità", "Corrette e aggiornate per lo scopo"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.1, 2.45, i === 3 ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], i === 3 ? C.background1 : C.accent1, i === 3 ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.05, w: 1.9, h: 0.4, fontSize: 15, bold: true, color: i === 3 ? C.background1 : C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.12, y: 2.5, w: 1.86, h: 0.9, fontSize: 12, color: i === 3 ? C.background1 : C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.25, 0.17);
    }
    banner(s, 3.85, "Quattro condizioni indipendenti. Quando una risposta è sbagliata: quale è mancata?", { h: 0.85, fontSize: 15 });
  }
  {
    const s = content("Otto domande guida", "Le otto domande guida accompagnano il modulo. La prima riguarda il patrimonio: quali informazioni e conoscenze possiede un'azienda e dove risiedono. La seconda e la terza riguardano qualità e organizzazione: la differenza tra avere molti dati e poterli usare, e come qualità, organizzazione e aggiornamento influiscono sull'efficacia dell'AI. La quarta e la quinta riguardano l'uso da parte dell'AI: come un sistema può usare informazioni che non ha imparato durante l'addestramento, e che cosa cambia quando lo si collega ad archivi o applicazioni gestionali. La sesta e la settima riguardano il controllo: perché servono permessi selettivi, e perché fonti corrette non garantiscono risposte corrette. L'ottava riguarda le condizioni: che cosa favorisce un uso aziendale affidabile. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Quali informazioni possiede un'azienda, e dove?", "Molti dati o dati utilizzabili?", "Come incidono qualità, organizzazione, aggiornamento?", "Come usa l'AI informazioni non apprese?", "Che cosa cambia collegando archivi e gestionali?", "Perché permessi e accessi selettivi?", "Perché una fonte corretta non basta?", "Quali condizioni per un uso affidabile?"], 4, 1.12, 1.5, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in cinque dimensioni. Il patrimonio informativo: quali informazioni e conoscenze esistono, nel 14.1. Qualità e organizzazione: correttezza, aggiornamento, struttura e reperibilità, nel 14.2 e 14.3. Utilizzo tramite AI: come il sistema accede a informazioni specifiche e si integra con le applicazioni, nel 14.4 e 14.5. Controllo e affidabilità: permessi, recupero corretto e interpretazione, nel 14.6 e 14.7. Condizioni aziendali: i prerequisiti per un funzionamento affidabile nel tempo, nel 14.8. Quattro integrazioni attraversano il modulo e sono i suoi messaggi principali. A: avere molti dati non significa avere dati utilizzabili. B: una fonte corretta non garantisce una risposta corretta. C: la conoscenza aziendale non è tutta documentata. D: l'AI non deve sapere tutto ciò che l'azienda sa. Nelle slide, un indicatore in alto a destra ricorda la dimensione di cui stiamo parlando.");
    const d = [["FiArchive", "Patrimonio", "14.1"], ["FiCheckCircle", "Qualità e organizzazione", "14.2  14.3"], ["FiCpu", "Utilizzo tramite AI", "14.4  14.5"], ["FiLock", "Controllo e affidabilità", "14.6  14.7"], ["FiSettings", "Condizioni aziendali", "14.8"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84, dark = i === 4;
      shapeBox(s, x, 1.15, 1.68, 1.9, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.54, 1.25, 0.6, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.08, y: 1.9, w: 1.52, h: 0.6, fontSize: 12, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.08, y: 2.55, w: 1.52, h: 0.35, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
    }
    txt(s, "Quattro integrazioni trasversali", { x: 0.5, y: 3.2, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const p = ["A  Molti dati non sono dati utilizzabili", "B  Una fonte corretta non garantisce una risposta corretta", "C  La conoscenza non è tutta documentata", "D  L'AI non deve sapere tutto ciò che l'azienda sa"];
    p.forEach((t, i) => chip(s, 0.5 + (i % 2) * 4.6, 3.6 + Math.floor(i / 2) * 0.68, 4.4, 0.58, t, { fill: C.accent6, fontSize: 12 }));
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti con priorità alta. Il documento indica quattro aree da approfondire: la qualità e l'aggiornamento delle informazioni, il recupero di informazioni specifiche da parte dell'AI, i permessi, l'affidabilità delle risposte. Vanno solo accennati: le architetture RAG avanzate, i database vettoriali, l'indicizzazione, le API, il data engineering, le integrazioni enterprise e l'implementazione tecnica dei controlli di accesso. Confini: non ripetiamo le applicazioni di sintesi, estrazione e confronto del Tema 8, ma guardiamo alle condizioni che le rendono possibili in azienda. Non ripetiamo il metodo generale di verifica del Tema 7, ma i rischi specifici delle fonti aziendali. Non torniamo sul funzionamento degli agenti, Tema 11, né sulla ridefinizione di ruoli e processi, Tema 13. Introduciamo permessi e protezione senza approfondire la disciplina giuridica e la governance, che sono dei Temi 17 e 18. E non sviluppiamo criteri di selezione dei progetti, che sono del Tema 15.");
    pathSlide(s, [["14.1", "Il patrimonio informativo", "Alta"], ["14.2", "Qualità e aggiornamento", "Alta"], ["14.3", "Organizzazione e accessibilità", "Alta"], ["14.4", "L'AI e le informazioni specifiche", "Alta"], ["14.5", "Integrazione con i sistemi", "Alta"], ["14.6", "Accessi e permessi", "Alta"], ["14.7", "Affidabilità delle risposte", "Alta"], ["14.8", "Condizioni aziendali", "Alta"]],
      [["Approfondire", "Qualità e aggiornamento, recupero di informazioni, permessi, affidabilità delle risposte", C.accent1, C.background1], ["Conoscere", "Patrimonio, organizzazione, integrazione con i sistemi, condizioni", C.accent6, C.text1], ["Solo accennare", "RAG avanzato, database vettoriali, API, data engineering, controlli tecnici", C.background2, C.text1]]);
  }

  // =====================================================================
  section("14.1 Il patrimonio informativo");
  divider("14.1", "Il patrimonio informativo", "Quali informazioni e conoscenze possiede un'azienda, dove risiedono, e che cosa serve per usarle", "Partiamo da che cosa esiste. In questo sottotema costruiamo un vocabolario: dati, informazioni, documenti, conoscenza. Vediamo le informazioni strutturate e non strutturate, le principali categorie di contenuti e dati di un'azienda, la differenza tra conoscenza formalizzata e tacita, e il fatto che le informazioni sono distribuite tra persone, reparti e applicazioni. Due integrazioni: la A, molti dati non equivalgono a dati utilizzabili, e la C, parte della conoscenza risiede nelle persone e non nei documenti.");
  {
    const s = content("Dai dati alla conoscenza", "La prima distinzione del sottotema, utile per tutto il modulo. I dati sono registrazioni elementari: un numero, una data, un codice, il valore di un campo. Per esempio, '1.250' o '15/03'. Da soli dicono poco. Le informazioni sono dati dotati di contesto e significato: 'il cliente Alfa ha ordinato 1.250 pezzi il 15 marzo'. I documenti sono contenitori organizzati di informazioni, pensati per un uso: una procedura, un contratto, un manuale, un verbale, un'offerta. La conoscenza è la capacità di usare le informazioni per agire e decidere: sapere che quell'ordine è insolito per quel cliente, che probabilmente anticipa una campagna, e che conviene verificare la disponibilità di magazzino. La conoscenza è in parte scritta, nei documenti e nelle procedure, e in parte è nelle persone. La distinzione è utile perché i sistemi AI lavorano in modo diverso su ciascun livello: possono elaborare dati, recuperare informazioni, leggere documenti; la conoscenza che serve per interpretarli nel contesto dell'azienda è spesso la parte più difficile da rendere disponibile. Esempio fittizio, come tutti quelli del modulo.");
    infoTag(s, 0);
    const l = [["Dati", "Registrazioni elementari", "1.250  ·  15/03  ·  CL-0042"], ["Informazioni", "Dati con contesto e significato", "Il cliente Alfa ha ordinato 1.250 pezzi il 15 marzo"], ["Documenti", "Contenitori organizzati per un uso", "Procedura, contratto, manuale, verbale, offerta"], ["Conoscenza", "Capacità di usare le informazioni per agire", "L'ordine è insolito: forse anticipa una campagna, verificare il magazzino"]];
    l.forEach((e, i) => {
      const y = 1.12 + i * 0.8, w = 5.6 + i * 0.6, dark = i === 3;
      shapeBox(s, 0.5, y, w + 0.6, 0.72, dark ? C.accent1 : (i % 2 ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: 0.65, y, w: 1.75, h: 0.72, fontSize: 15, bold: true, color: dark ? C.background1 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.4, y: y + 0.05, w: w - 1.7, h: 0.32, fontSize: 12, bold: true, color: dark ? C.background1 : C.text1 });
      txt(s, e[2], { x: 2.4, y: y + 0.37, w: w - 1.7, h: 0.32, fontSize: 11, italic: true, color: dark ? C.accent6 : C.text2 });
    });
    txt(s, "Esempio fittizio. L'AI elabora dati, recupera informazioni, legge documenti: la conoscenza per interpretarli è la parte più difficile.", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 12, italic: true, color: C.accent5 });
  }
  {
    const s = content("Strutturate e non strutturate", "Seconda distinzione: informazioni strutturate e non strutturate. Le informazioni strutturate sono organizzate in campi e tabelle con un formato definito: l'anagrafica clienti, gli ordini, le fatture, le giacenze, le presenze. Si trovano nei gestionali, nei database, nei fogli di calcolo. Sono facili da interrogare con precisione: quanti ordini ha fatto questo cliente quest'anno? Le informazioni non strutturate sono in forma libera: testi, email, documenti, presentazioni, verbali, chat, registrazioni, immagini. Sono la grande maggioranza delle informazioni di un'azienda, secondo stime spesso citate nel settore, anche se le percentuali precise variano molto tra le fonti. Fino a pochi anni fa erano difficili da usare in modo automatico; l'AI generativa ha cambiato proprio questo, rendendo possibile leggere, sintetizzare e interrogare grandi quantità di testo, come visto nel Tema 8. Esiste anche una via di mezzo, le informazioni semistrutturate: un modulo con campi fissi e note libere, un'email con oggetto e allegati, un ticket con categoria e descrizione. Per l'AI aziendale la distinzione conta perché il modo di accedere alle informazioni è diverso: per i dati strutturati serve interrogare il sistema che li contiene; per quelli non strutturati serve trovare i documenti pertinenti e leggerli.");
    infoTag(s, 0);
    await twoPanel(s, "Strutturate", bullets(["Campi e tabelle con formato definito", "Anagrafiche, ordini, fatture, giacenze", "Nei gestionali, database, fogli di calcolo", "Interrogabili con precisione"], { space: 4 }), "Non strutturate", bullets(["Forma libera", "Testi, email, documenti, verbali, chat, registrazioni", "La maggior parte delle informazioni aziendali", "Rese più usabili dall'AI generativa (Tema 8)"], { space: 4 }), { y: 1.15, h: 2.65, li: "FiGrid", ri: "FiFileText" });
    banner(s, 4.0, "In mezzo, le semistrutturate: un ticket con categoria e descrizione. Si accede alle une interrogando, alle altre trovando e leggendo.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Che cosa contiene il patrimonio", "Una panoramica delle principali categorie di contenuti, utile per far emergere quanto il patrimonio informativo di un'azienda sia vasto e vario. Documenti di riferimento: procedure, manuali, istruzioni operative, policy, regolamenti interni, schede prodotto. Comunicazioni: email, chat, verbali di riunione, comunicazioni interne, presentazioni. Dati commerciali: clienti, offerte, ordini, contratti, listini, storico delle relazioni, reclami. Dati amministrativi: fatture, pagamenti, contabilità, fornitori, personale. Dati produttivi e operativi: produzione, qualità, manutenzione, magazzino, logistica, ticket di assistenza. Il punto non è fare un inventario completo, che sarebbe impossibile in aula, ma riconoscere che ciascuna categoria ha caratteristiche diverse: alcune sono strutturate e controllate, altre disordinate; alcune sono aggiornate ogni giorno, altre raramente; alcune sono accessibili a tutti, altre riservate. Queste differenze contano molto quando si pensa di renderle disponibili a un sistema AI. Suggerimento: chiedere ai partecipanti quali di queste categorie usano ogni giorno, e dove le trovano.");
    infoTag(s, 0);
    await iconGrid(s, [
      { icon: "FiBook", head: "Documenti di riferimento", body: "Procedure, manuali, istruzioni, policy, schede prodotto" },
      { icon: "FiMail", head: "Comunicazioni", body: "Email, chat, verbali, comunicazioni interne, presentazioni" },
      { icon: "FiBriefcase", head: "Dati commerciali", body: "Clienti, offerte, ordini, contratti, listini, reclami" },
      { icon: "FiFileText", head: "Dati amministrativi", body: "Fatture, pagamenti, contabilità, fornitori, personale" },
      { icon: "FiTool", head: "Dati produttivi e operativi", body: "Produzione, qualità, manutenzione, magazzino, ticket" },
      { icon: "FiUsers", head: "Conoscenza nelle persone", body: "Esperienza, relazioni, soluzioni, contesto" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Ogni categoria ha struttura, aggiornamento e riservatezza diversi.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Formalizzata e tacita", "Una distinzione centrale del sottotema, e l'integrazione C del tema: la conoscenza aziendale non è tutta documentata. La conoscenza formalizzata, o esplicita, è quella scritta: procedure, manuali, documenti, basi dati. Può essere archiviata, cercata, letta, e quindi anche resa disponibile a un sistema AI. La conoscenza tacita è quella che le persone hanno ma che non è scritta, e spesso è difficile da scrivere: come si gestisce un cliente difficile, perché una macchina fa un certo rumore prima di guastarsi, a chi rivolgersi per sbloccare una pratica, quali eccezioni si fanno di solito e perché, la storia di una decisione. Il filosofo Michael Polanyi la riassumeva con una frase diventata celebre: sappiamo più di quanto sappiamo dire. Ikujiro Nonaka e Hirotaka Takeuchi, negli anni Novanta, hanno costruito su questa distinzione un modello di come le organizzazioni creano conoscenza, trasformando continuamente conoscenza tacita in esplicita e viceversa. L'immagine dell'iceberg è utile: la parte visibile, documentata, è solo una parte. Un assistente AI collegato ai documenti aziendali vede solo la parte emersa. Questo non significa che sia inutile, ma che le sue risposte possono mancare di ciò che un collega esperto saprebbe aggiungere.");
    infoTag(s, 0);
    s.addShape(pres.shapes.RECTANGLE, { x: 0.5, y: 2.25, w: 5.0, h: 0.02, fill: { color: HEX.a1 }, line: { type: "none" }, objectName: "linea acqua" });
    s.addShape(pres.shapes.ISOSCELES_TRIANGLE, { x: 1.85, y: 1.15, w: 2.3, h: 1.1, fill: { color: HEX.lt2 }, line: { color: HEX.a1, width: 1 }, objectName: "iceberg emerso" });
    s.addShape(pres.shapes.TRAPEZOID, { x: 0.7, y: 2.27, w: 4.6, h: 2.4, fill: { color: HEX.a1 }, line: { type: "none" }, objectName: "iceberg sommerso" });
    txt(s, "Formalizzata", { x: 2.2, y: 1.75, w: 1.6, h: 0.35, fontSize: 12, bold: true, color: C.text1, align: "center" });
    txt(s, "Tacita", { x: 1.2, y: 2.45, w: 3.6, h: 0.4, fontSize: 16, bold: true, color: C.background1, align: "center" });
    txt(s, "Come si gestisce un cliente difficile\nA chi rivolgersi per sbloccare una pratica\nQuali eccezioni si fanno, e perché\nLa storia delle decisioni", { x: 1.3, y: 2.9, w: 3.4, h: 1.4, fontSize: 11, color: C.background1, align: "center" });
    await card(s, 5.8, 1.15, 3.7, 1.75, { icon: "FiMessageCircle", inline: true, head: "Sappiamo più di quanto sappiamo dire", headSize: 13, bodySize: 12, body: "Polanyi. Nonaka e Takeuchi: le organizzazioni creano conoscenza convertendo tacito ed esplicito." });
    await card(s, 5.8, 3.05, 3.7, 1.6, { icon: "FiEye", inline: true, head: "Che cosa vede l'AI", headSize: 13, bodySize: 12, fill: C.accent6, body: "Un assistente collegato ai documenti vede solo la parte emersa (C)." });
  }
  {
    const s = content("Informazioni distribuite", "Il sottotema chiede di riconoscere che le informazioni sono distribuite tra persone, reparti e applicazioni. In una tipica azienda le informazioni su un singolo cliente possono trovarsi: nel CRM, con l'anagrafica e le opportunità; nel gestionale, con ordini e fatture; nel sistema di assistenza, con i ticket; nelle caselle email dei commerciali, con le trattative; in una cartella condivisa, con i contratti; in un foglio di calcolo personale, con le note sulle condizioni particolari; e nella memoria del commerciale che lo segue da dieci anni. Nessuno di questi luoghi contiene il quadro completo. Le cause sono comprensibili: ogni reparto adotta gli strumenti adatti al proprio lavoro, i sistemi vengono introdotti in momenti diversi, le persone tengono le informazioni dove le trovano comode. Per l'AI ne derivano due conseguenze. Un assistente collegato a una sola fonte vede una parte del quadro, e può rispondere in modo convincente ma incompleto. Collegarlo a tutte le fonti è tecnicamente complesso e, come vedremo nel 14.6, non sempre opportuno. Esempio fittizio.");
    infoTag(s, 0);
    shapeBox(s, 3.75, 2.25, 2.5, 0.8, C.accent1, "cliente");
    txt(s, "Il cliente Alfa", { x: 3.75, y: 2.25, w: 2.5, h: 0.8, fontSize: 15, bold: true, color: C.background1, align: "center", valign: "middle" });
    const pl = [["CRM", "anagrafica, opportunità", 0.5, 1.15], ["Gestionale", "ordini, fatture", 3.75, 1.15], ["Assistenza", "ticket", 7.0, 1.15], ["Email", "trattative", 0.5, 2.3], ["Cartella condivisa", "contratti", 7.0, 2.3], ["Foglio personale", "condizioni particolari", 0.5, 3.45], ["Persone", "la memoria di chi lo segue", 3.75, 3.45], ["Verbali", "decisioni prese", 7.0, 3.45]];
    pl.forEach(p => {
      shapeBox(s, p[2], p[3], 2.5, 0.7, C.background2, p[0]);
      txt(s, p[0], { x: p[2] + 0.12, y: p[3] + 0.03, w: 2.3, h: 0.32, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, p[1], { x: p[2] + 0.12, y: p[3] + 0.34, w: 2.3, h: 0.32, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.35, "Nessun luogo contiene il quadro completo. Un assistente collegato a una fonte ne vede una parte.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Possedere non è poter usare", "L'integrazione A del tema: avere molti dati non significa avere dati utilizzabili. Il sottotema la formula come differenza tra possedere informazioni e poterle utilizzare, e tra quantità delle informazioni e valore informativo. Molte aziende hanno accumulato in anni enormi quantità di documenti, email, registrazioni, dati di sistema. È facile pensare che basti 'dare tutto all'AI' per ottenere un assistente che sa tutto. Ma la quantità non compensa i problemi: documenti duplicati in dieci versioni, procedure superate mai archiviate, dati incoerenti tra sistemi, cartelle con nomi incomprensibili, informazioni rilevanti sepolte tra migliaia di irrilevanti. Più materiale non pertinente si aggiunge, più aumenta il rischio che il sistema recuperi il documento sbagliato. Il valore informativo dipende invece dalla pertinenza rispetto allo scopo, dalla correttezza, dall'aggiornamento, dalla reperibilità. Cento procedure aggiornate e ben organizzate valgono più di diecimila file non curati. La domanda giusta non è 'quante informazioni abbiamo?', ma 'quali informazioni servono per questo uso, e in che stato sono?'.");
    infoTag(s, 0);
    shapeBox(s, 0.5, 1.15, 4.35, 2.7, C.background2, "quantità");
    txt(s, "Diecimila file non curati", { x: 0.7, y: 1.25, w: 3.95, h: 0.4, fontSize: 15, bold: true, color: C.accent5 });
    txt(s, bullets(["Dieci versioni dello stesso documento", "Procedure superate mai archiviate", "Dati incoerenti tra sistemi", "Il rilevante sepolto tra l'irrilevante"], { space: 4 }), { x: 0.7, y: 1.7, w: 3.95, h: 2.0, fontSize: 12, color: C.text1 });
    shapeBox(s, 5.15, 1.15, 4.35, 2.7, C.accent6, "valore");
    txt(s, "Cento procedure curate", { x: 5.35, y: 1.25, w: 3.95, h: 0.4, fontSize: 15, bold: true, color: C.accent1 });
    txt(s, bullets(["Pertinenti allo scopo", "Corrette e aggiornate", "Una versione valida, riconoscibile", "Facili da trovare"], { space: 4 }), { x: 5.35, y: 1.7, w: 3.95, h: 2.0, fontSize: 12, color: C.text1 });
    banner(s, 4.05, "Non 'quante informazioni abbiamo?', ma 'quali servono per questo uso, e in che stato sono?' (A)", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Il ruolo del patrimonio nell'AI", "Per chiudere il sottotema, il ruolo del patrimonio informativo nell'uso aziendale dell'AI. Con un assistente generico, il valore viene dalla conoscenza generale del modello e dalla capacità di elaborare ciò che gli diamo. Con un assistente aziendale, il valore viene in larga parte dalle informazioni dell'azienda: la differenza tra una risposta generica su come gestire un reso e la risposta che applica la procedura di reso della nostra azienda, con le nostre condizioni e i nostri moduli. È per questo che molte delle applicazioni più utili dell'AI in azienda dipendono dal patrimonio informativo: l'assistente che risponde sulle procedure interne, quello che aiuta l'assistenza clienti con la documentazione tecnica, quello che prepara offerte usando listini e condizioni aggiornati. E per lo stesso motivo il patrimonio informativo diventa un fattore abilitante, o un limite: un'azienda con informazioni curate può ottenere molto, una con informazioni disordinate otterrà risposte disordinate, anche con il miglior modello disponibile. La conclusione del sottotema: prima di chiedersi quale AI usare, conviene chiedersi quali informazioni ha l'azienda e in che stato sono.");
    infoTag(s, 0);
    await twoPanel(s, "Assistente generico", "Conoscenza generale del modello.\n\n'Come si gestisce di solito un reso?'\nRisposta plausibile, ma generica.", "Assistente aziendale", "Conoscenza generale più informazioni dell'azienda.\n\n'Come gestiamo questo reso?'\nLa nostra procedura, le nostre condizioni, i nostri moduli.", { y: 1.15, h: 2.5, li: "FiGlobe", ri: "FiHome" });
    banner(s, 3.85, "Informazioni curate abilitano, informazioni disordinate limitano, anche con il miglior modello. Prima di 'quale AI?', 'quali informazioni, in che stato?'", { h: 1.0, fontSize: 13 });
  }
  keySlide("Avere molti dati non significa avere dati utilizzabili. E una parte della conoscenza aziendale non è scritta da nessuna parte.", "Sottotema 14.1  ·  Il patrimonio informativo dell'azienda  ·  Integrazioni A e C", "Concetto chiave del primo sottotema. Dati, informazioni, documenti e conoscenza sono livelli diversi. Le informazioni sono strutturate e non strutturate, distribuite tra persone, reparti e applicazioni. Una parte importante della conoscenza è tacita, e un assistente collegato ai documenti non la vede. La quantità non equivale al valore: conta la pertinenza, lo stato delle informazioni rispetto allo scopo. Esercizio suggerito: scegliere una domanda frequente del proprio lavoro, per esempio le condizioni applicate a un cliente, e mappare dove si trovano tutte le informazioni necessarie per rispondere, distinguendo ciò che è scritto da ciò che sanno solo alcune persone.");

  // =====================================================================
  section("14.2 Qualità e aggiornamento");
  divider("14.2", "Qualità e aggiornamento", "La quantità delle informazioni non compensa errori, incoerenze, lacune o obsolescenza", "Uno dei sottotemi da approfondire. Se l'AI usa le informazioni dell'azienda, la qualità di quelle informazioni diventa la qualità delle sue risposte. Vediamo le dimensioni della qualità: accuratezza, completezza, pertinenza, coerenza, aggiornamento. I problemi tipici: duplicati, contraddizioni, documenti obsoleti, definizioni non uniformi. La provenienza e l'autorevolezza delle fonti, la responsabilità dell'aggiornamento, le conseguenze delle informazioni errate e i limiti dell'AI nel compensarle. Integrazione A.");
  {
    const s = content("Le dimensioni della qualità", "La qualità delle informazioni non è una cosa sola. Il sottotema indica diverse dimensioni, che conviene distinguere perché i problemi e i rimedi sono diversi. Accuratezza: l'informazione corrisponde alla realtà? Il prezzo indicato è quello giusto, l'indirizzo del cliente è corretto? Completezza: ci sono tutte le informazioni necessarie? La procedura descrive anche i casi particolari, la scheda prodotto ha tutte le specifiche? Pertinenza: l'informazione serve allo scopo? Un documento accurato ma riferito a un altro prodotto o a un altro paese non è pertinente. Coerenza: fonti diverse dicono la stessa cosa? Il listino nel gestionale e quello nella presentazione commerciale coincidono? Aggiornamento: l'informazione è ancora valida? La procedura del 2021 è stata superata? Le dimensioni sono indipendenti: un documento può essere accurato quando è stato scritto ma non più aggiornato; completo ma non pertinente per la domanda. La qualità, infine, è sempre relativa allo scopo: un dato approssimativo può bastare per una stima interna, non per una comunicazione al cliente.");
    infoTag(s, 1);
    rowsLabel(s, [["Accuratezza", "Corrisponde alla realtà? Il prezzo è quello giusto?"], ["Completezza", "Ci sono anche i casi particolari, tutte le specifiche?"], ["Pertinenza", "Serve allo scopo? O è di un altro prodotto, di un altro paese?"], ["Coerenza", "Il listino nel gestionale e nella presentazione coincidono?"], ["Aggiornamento", "È ancora valida? La procedura del 2021 è stata superata?"]], { y: 1.15, h: 0.52, lw: 2.2 });
    banner(s, 4.2, "Dimensioni indipendenti. E la qualità è sempre relativa allo scopo.", { h: 0.7, fontSize: 15 });
  }
  {
    const s = content("Duplicati e contraddizioni", "Il primo gruppo di problemi tipici: informazioni duplicate o contraddittorie, e la coerenza tra fonti diverse. Sono problemi molto diffusi, per ragioni comprensibili. Un documento viene copiato per essere modificato, e la copia vive di vita propria. Un file viene inviato per email e salvato in più cartelle. Lo stesso dato viene inserito in due sistemi diversi e aggiornato solo in uno. Una procedura viene riscritta da un reparto senza che l'altro aggiorni la propria. Il risultato sono più versioni dello stesso contenuto, spesso con differenze piccole ma importanti. Per una persona esperta il problema si gestisce: sa quale versione è quella buona, o sa a chi chiedere. Per un sistema AI è molto più difficile: due documenti che dicono cose diverse sono, per il sistema, due fonti ugualmente valide, a meno che qualcosa non indichi quale prevale. Il sistema può scegliere quella sbagliata, mescolarle, o, nel caso migliore, segnalare la contraddizione. L'esempio in slide, fittizio: tre versioni delle condizioni di reso, con tre termini diversi. Quale applicherà l'assistente?");
    infoTag(s, 1);
    docBox(s, 0.5, 1.15, 2.86, 1.45, "Condizioni_reso.docx", "Reso entro 14 giorni dalla consegna.", { fontSize: 12 });
    docBox(s, 3.57, 1.15, 2.86, 1.45, "Condizioni_reso_v2_def.docx", "Reso entro 30 giorni dalla consegna.", { fontSize: 12, fill: C.accent6 });
    docBox(s, 6.64, 1.15, 2.86, 1.45, "FAQ sito (copia 2022)", "Reso entro 15 giorni dall'acquisto.", { fontSize: 12 });
    txt(s, "Esempio fittizio. Quale applicherà l'assistente?", { x: 0.5, y: 2.7, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2, align: "center" });
    const o = ["Sceglie quella sbagliata", "Mescola le versioni", "Segnala la contraddizione"];
    o.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.15, 2.86, 0.6, t, { fill: i === 2 ? C.accent6 : C.background2, fontSize: 13 }));
    banner(s, 4.0, "Per una persona esperta, una versione è 'quella buona'. Per il sistema, sono fonti ugualmente valide, salvo indicazioni.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Il problema dell'obsolescenza", "Il secondo problema: dati e documenti obsoleti. È forse il più insidioso, perché un documento obsoleto non sembra sbagliato: era corretto quando è stato scritto, è ben formattato, magari è firmato e approvato. Semplicemente, non è più valido. Le procedure cambiano, i listini si aggiornano, i prodotti escono di produzione, le normative vengono modificate, le persone di riferimento cambiano ruolo. Negli archivi aziendali raramente i documenti superati vengono eliminati o marcati come tali: restano accanto a quelli nuovi. Per un sistema AI che recupera documenti in base alla pertinenza del contenuto, un documento del 2019 e uno del 2025 sullo stesso argomento possono sembrare ugualmente adatti, e il vecchio può essere scelto perché il suo testo corrisponde meglio alla domanda. Il grafico illustra, con dati inventati, una situazione tipica: in un archivio di procedure, la quota di documenti non più validi cresce nel tempo se nessuno se ne occupa. Il messaggio: l'aggiornamento non è un evento, è un'attività continua, e senza di essa la qualità del patrimonio informativo si degrada da sola.");
    infoTag(s, 1);
    s.addChart(pres.charts.BAR, [
      { name: "Valide", labels: ["Anno 1", "Anno 2", "Anno 3", "Anno 4", "Anno 5"], values: [95, 84, 72, 63, 55] },
      { name: "Superate, non archiviate", labels: ["Anno 1", "Anno 2", "Anno 3", "Anno 4", "Anno 5"], values: [5, 16, 28, 37, 45] },
    ], { x: 0.5, y: 1.1, w: 5.4, h: 3.3, barDir: "col", barGrouping: "percentStacked", chartColors: [HEX.a1, HEX.a5],
      showValue: true, dataLabelColor: "FFFFFF", dataLabelFontSize: 11, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 11, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Procedure in archivio, % (dati inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 60 });
    await card(s, 6.15, 1.15, 3.35, 1.6, { icon: "FiClock", inline: true, head: "Non sembra sbagliato", headSize: 13, bodySize: 12, body: "Era corretto, è ben fatto, magari approvato. Non è più valido." });
    await card(s, 6.15, 2.9, 3.35, 1.55, { icon: "FiRefreshCw", inline: true, head: "Un'attività continua", headSize: 13, bodySize: 12, fill: C.accent6, body: "Senza aggiornamento, la qualità si degrada da sola." });
  }
  {
    const s = content("Parole diverse, stesse cose", "Il terzo problema: definizioni e terminologie non uniformi. Reparti diversi usano spesso parole diverse per la stessa cosa, o la stessa parola per cose diverse. Per esempio, 'cliente attivo' può significare per il commerciale chi ha un contratto in essere, per l'amministrazione chi ha fatturato negli ultimi dodici mesi, per l'assistenza chi ha aperto un ticket nell'ultimo anno. 'Ordine' può indicare la richiesta del cliente, la conferma interna o la spedizione. 'Commessa', 'progetto', 'lavoro', 'pratica' possono indicare la stessa cosa in reparti diversi. Le sigle interne, i codici, i nomi di prodotto cambiati nel tempo complicano ulteriormente il quadro. Per le persone, il contesto di solito chiarisce. Per un sistema AI, che non conosce le convenzioni dell'azienda, è facile confondere: rispondere sul numero di clienti attivi con la definizione sbagliata, o non trovare un documento perché usa un termine diverso da quello della domanda. È un problema noto da tempo nella gestione dei dati, e i rimedi sono organizzativi prima che tecnici: un glossario condiviso, definizioni esplicite degli indicatori, un responsabile della terminologia per gli ambiti chiave. Esempi fittizi.");
    infoTag(s, 1);
    txt(s, "'Cliente attivo' (esempio fittizio)", { x: 0.5, y: 1.12, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const d = [["Commerciale", "Ha un contratto in essere"], ["Amministrazione", "Ha fatturato negli ultimi 12 mesi"], ["Assistenza", "Ha aperto un ticket nell'ultimo anno"]];
    d.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.55, 2.86, 1.05, i === 1 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.6, w: 2.56, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.97, w: 2.56, h: 0.55, fontSize: 12, color: C.text1 });
    });
    txt(s, "Anche: ordine, commessa, progetto, pratica; sigle, codici, nomi di prodotto cambiati", { x: 0.5, y: 2.72, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
    txt(s, "Rimedi organizzativi prima che tecnici", { x: 0.5, y: 3.15, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    ["Glossario condiviso", "Indicatori con definizioni esplicite", "Responsabili della terminologia"].forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.55, 2.86, 0.6, t, { fill: C.accent6, fontSize: 13 }));
    txt(s, "Il sistema non conosce le convenzioni dell'azienda: confonde le definizioni, o non trova il documento.", { x: 0.5, y: 4.35, w: 9, h: 0.5, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Provenienza e autorevolezza", "Il sottotema chiede di considerare la provenienza e l'autorevolezza delle fonti interne. Non tutti i documenti di un'azienda hanno lo stesso peso. Una procedura approvata dalla direzione qualità vale più di una nota scritta da un collega per uso personale. Un listino ufficiale vale più del prezzo citato in una vecchia email. Un contratto firmato vale più della bozza. Una comunicazione formale vale più di un messaggio in chat. Le persone fanno queste distinzioni quasi automaticamente, guardando chi ha scritto il documento, dove si trova, se ha un numero di versione, se è firmato. Per un sistema AI queste informazioni sono disponibili solo se sono registrate in modo esplicito, nei metadati o nella collocazione del documento, e se il sistema è configurato per tenerne conto. Altrimenti una nota informale e una procedura ufficiale possono essere trattate come fonti equivalenti. Ne deriva un'indicazione pratica: quando si decide quali fonti rendere disponibili a un assistente, conviene partire da quelle ufficiali e curate, e dichiarare esplicitamente la gerarchia delle fonti, cioè quale prevale in caso di contraddizione.");
    infoTag(s, 1);
    const p = [["Procedura approvata", "Nota personale di un collega"], ["Listino ufficiale", "Prezzo in una vecchia email"], ["Contratto firmato", "Bozza del contratto"], ["Comunicazione formale", "Messaggio in chat"]];
    txt(s, "Più autorevole", { x: 0.5, y: 1.1, w: 4.0, h: 0.32, fontSize: 12, bold: true, color: C.accent1 });
    txt(s, "Meno autorevole", { x: 5.5, y: 1.1, w: 4.0, h: 0.32, fontSize: 12, bold: true, color: C.text2 });
    p.forEach((e, i) => {
      const y = 1.45 + i * 0.55;
      chip(s, 0.5, y, 4.0, 0.46, e[0], { fill: C.accent6, fontSize: 12 });
      txt(s, "›", { x: 4.55, y, w: 0.9, h: 0.46, fontSize: 18, bold: true, color: C.accent1, align: "center", valign: "middle" });
      chip(s, 5.5, y, 4.0, 0.46, e[1], { fill: C.background2, fontSize: 12, bold: false });
    });
    banner(s, 3.75, "Le persone lo vedono da sole. Il sistema solo se è registrato e configurato. Partire dalle fonti ufficiali, e dichiarare quale prevale.", { h: 1.05, fontSize: 13 });
  }
  {
    const s = content("Chi aggiorna che cosa", "Un punto organizzativo, spesso il più trascurato: la responsabilità sull'aggiornamento. Molti problemi di qualità visti finora hanno la stessa radice: nessuno è esplicitamente responsabile di mantenere aggiornata una certa informazione. Il documento viene creato per un progetto, chi l'ha scritto cambia ruolo, nessuno lo rivede più. Per le informazioni che contano, e in particolare per quelle rese disponibili a un sistema AI, conviene che per ciascuna fonte sia chiaro: chi ne è responsabile, cioè chi la mantiene e risponde della sua correttezza; con quale frequenza va riesaminata; che cosa succede quando cambia, cioè come si sostituisce la versione vecchia e come si informa chi la usa; che cosa succede quando non è più valida, cioè come si archivia o si elimina. Nella letteratura sulla gestione dei dati si parla spesso di data owner o di responsabili del contenuto. Non è necessario un apparato complesso: per un assistente sulle procedure interne, può bastare un elenco delle fonti, ciascuna con un responsabile e una data di revisione. Il punto è che, senza una responsabilità chiara, la qualità si degrada, e l'AI renderà il degrado più visibile, e più rapido nei suoi effetti.");
    infoTag(s, 1);
    numList(s, ["Chi ne è responsabile: chi la mantiene e risponde della correttezza", "Ogni quanto va riesaminata", "Che cosa succede quando cambia: sostituire la versione, informare chi la usa", "Che cosa succede quando non è più valida: archiviare o eliminare"], { y: 1.15, h: 0.58, fontSize: 13 });
    banner(s, 3.75, "Basta poco: un elenco delle fonti, ciascuna con un responsabile e una data di revisione. Senza, la qualità si degrada, e l'AI lo rende visibile.", { h: 1.05, fontSize: 13 });
  }
  {
    const s = content("Che cosa l'AI non compensa", "Le conseguenze dell'uso di informazioni errate, e i limiti dell'AI nel compensare i problemi di qualità, che sono l'ultimo punto del sottotema e l'integrazione A nella sua forma più netta. Una convinzione diffusa è che l'AI, essendo 'intelligente', saprà riconoscere da sola le informazioni sbagliate o superate. In parte può aiutare: può segnalare contraddizioni evidenti tra documenti, notare date vecchie, accorgersi che due valori non tornano. Ma non può sapere che una procedura corretta in apparenza è stata superata da una decisione presa in riunione e non ancora scritta; che un prezzo plausibile è sbagliato; che un documento ben scritto riguarda un caso diverso. Non ha accesso alla realtà, ha accesso alle fonti. Le conseguenze dell'informazione errata, inoltre, vengono amplificate: un documento sbagliato letto da una persona produce un errore; lo stesso documento usato da un assistente consultato da cento persone produce cento risposte sbagliate, tutte con l'aspetto di risposte affidabili. Ecco perché la qualità delle fonti è una condizione, non un dettaglio. E perché la quantità non compensa: più documenti non correggono quelli sbagliati, li accompagnano.");
    infoTag(s, 1);
    await twoPanel(s, "Che cosa l'AI può aiutare a vedere", bullets(["Contraddizioni evidenti tra documenti", "Date vecchie, valori che non tornano"], { space: 5 }), "Che cosa non può sapere", bullets(["Una procedura superata da una decisione non scritta", "Un prezzo plausibile ma sbagliato", "Un documento che riguarda un caso diverso"], { space: 5 }), { y: 1.15, h: 2.3, li: "FiSearch", ri: "FiEyeOff" });
    shapeBox(s, 0.5, 3.55, 9.0, 0.6, C.background2, "amplificazione");
    txt(s, [{ text: "Amplificazione: ", options: { bold: true, color: C.accent5 } }, { text: "un documento sbagliato letto da una persona, un errore; usato da un assistente consultato da cento persone, cento risposte sbagliate.", options: { color: C.text1 } }], { x: 0.7, y: 3.55, w: 8.6, h: 0.6, fontSize: 12, valign: "middle" });
    banner(s, 4.3, "L'AI non ha accesso alla realtà, ha accesso alle fonti (A).", { h: 0.6, fontSize: 15 });
  }
  keySlide("La quantità delle informazioni non compensa errori, incoerenze, lacune o obsolescenza. L'AI ha accesso alle fonti, non alla realtà.", "Sottotema 14.2  ·  Qualità, affidabilità e aggiornamento delle informazioni  ·  Integrazione A", "Concetto chiave del secondo sottotema. La qualità ha più dimensioni: accuratezza, completezza, pertinenza, coerenza, aggiornamento, sempre relative allo scopo. I problemi tipici sono duplicati e contraddizioni, obsolescenza, terminologie non uniformi, fonti di autorevolezza diversa. La radice comune è spesso l'assenza di una responsabilità sull'aggiornamento. L'AI può aiutare a vedere alcuni problemi, ma non li compensa, e ne amplifica le conseguenze. Esercizio suggerito: scegliere un argomento del proprio lavoro, cercare nell'archivio aziendale tutti i documenti che ne parlano e verificare quante versioni esistono, quale è valida e come lo si capisce.");

  // =====================================================================
  section("14.3 Organizzazione e accessibilità");
  divider("14.3", "Organizzazione e accessibilità", "La reperibilità conta quanto la presenza delle informazioni. La documentazione non esaurisce la conoscenza aziendale", "Dopo che cosa esiste e in che stato è, guardiamo a come è organizzato e come si trova. Il documento di perimetro distingue: il 14.1 riguarda che cosa esiste, il 14.3 come è organizzato e reperito; il 14.3 riguarda l'organizzazione delle informazioni, il 14.4 il loro uso da parte dell'AI. Vediamo archivi e repository, classificazione e metadati, ricerca, versionamento, frammentazione e silos, la differenza tra archivio e base di conoscenza, e i limiti della documentazione. Integrazioni A e C.");
  {
    const s = content("Archivi e repository", "Le informazioni non strutturate di un'azienda vivono in archivi di vario tipo. Le cartelle condivise su un server o nel cloud, spesso organizzate per reparto o per progetto. I sistemi di gestione documentale, che aggiungono versioni, approvazioni, permessi e ricerca. Le intranet e i wiki aziendali, pensati per la consultazione. Gli spazi degli strumenti collaborativi, come i canali e i file dei team. E, inevitabilmente, le caselle di posta e i dischi personali, dove finisce molto materiale importante. L'organizzazione può seguire logiche diverse: per argomento, per funzione aziendale, per cliente, per progetto, per data. Ognuna ha senso per qualcuno, nessuna è perfetta per tutti. Il problema più comune non è la scelta della logica, ma la sua mancanza o la sua incoerenza: ogni reparto organizza a modo suo, le regole cambiano nel tempo, le eccezioni si accumulano. Per un sistema AI questo conta due volte: perché deve sapere dove cercare, e perché la collocazione di un documento è spesso l'unico indizio di che cosa sia e quanto valga.");
    infoTag(s, 1);
    await iconGrid(s, [
      { icon: "FiFolder", head: "Cartelle condivise", body: "Per reparto o per progetto" },
      { icon: "FiArchive", head: "Gestione documentale", body: "Versioni, approvazioni, permessi, ricerca" },
      { icon: "FiGlobe", head: "Intranet e wiki", body: "Pensati per la consultazione" },
      { icon: "FiUsers", head: "Spazi collaborativi", body: "Canali e file dei team" },
      { icon: "FiInbox", head: "Email e dischi personali", body: "Dove finisce molto materiale importante" },
      { icon: "FiShuffle", head: "Logiche diverse", body: "Per argomento, funzione, cliente, progetto, data" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Il problema più comune non è quale logica, ma la sua mancanza o incoerenza.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Classificazione e metadati", "Il sottotema introduce la classificazione e i metadati. I metadati sono informazioni sulle informazioni: titolo, autore, data di creazione e di ultima modifica, versione, stato, cioè bozza, approvato, superato, reparto di riferimento, argomento, destinatari, livello di riservatezza, responsabile, data di revisione. Possono sembrare un dettaglio burocratico, ma sono ciò che permette a una persona, e ancora più a un sistema, di capire che cosa è un documento senza doverlo leggere tutto. Molti dei problemi visti nel 14.2 si possono ridurre con metadati ben tenuti: lo stato 'superato' risolve parte dell'obsolescenza; il campo 'reparto' evita di applicare una procedura di un altro ufficio; la data di revisione segnala le fonti da controllare; il livello di riservatezza, come vedremo nel 14.6, è la base per i permessi. L'esempio in slide confronta lo stesso documento senza e con metadati. Un'avvertenza pratica: i metadati sono utili solo se vengono compilati e mantenuti, e la compilazione manuale tende a essere trascurata. Qui l'AI può aiutare, proponendo classificazioni e metadati, purché qualcuno li verifichi.");
    infoTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 2.4, "Senza metadati", "procedura_finale_nuova(2).docx\n\nChe cos'è? Chi l'ha scritta? È valida? Per chi?", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    shapeBox(s, 5.15, 1.15, 4.35, 2.4, C.accent6, "con metadati");
    txt(s, "Con metadati (esempio fittizio)", { x: 5.35, y: 1.2, w: 3.95, h: 0.32, fontSize: 12, bold: true, color: C.accent1 });
    const md = [["Titolo", "Gestione resi clienti"], ["Stato", "Approvata, versione 3"], ["Reparto", "Assistenza clienti"], ["Responsabile", "Ufficio qualità"], ["Revisione", "Entro marzo"], ["Riservatezza", "Interna"]];
    md.forEach((m, i) => {
      txt(s, m[0], { x: 5.35, y: 1.55 + i * 0.32, w: 1.4, h: 0.3, fontSize: 11, bold: true, color: C.text1 });
      txt(s, m[1], { x: 6.75, y: 1.55 + i * 0.32, w: 2.6, h: 0.3, fontSize: 11, color: C.text1 });
    });
    banner(s, 3.75, "Permettono di capire che cos'è un documento senza leggerlo. Utili solo se compilati e mantenuti: l'AI può proporli, qualcuno li verifica.", { h: 1.05, fontSize: 13 });
  }
  {
    const s = content("Trovare e riconoscere la versione", "Due punti del sottotema legati tra loro: la ricerca e il recupero delle informazioni, e il versionamento dei documenti. La ricerca tradizionale, per parole chiave, trova i documenti che contengono le parole cercate: funziona se si conosce il termine esatto, fallisce se il documento usa un sinonimo o un termine interno diverso. Gli strumenti AI hanno introdotto la ricerca per significato, che trova documenti pertinenti anche senza le stesse parole: un passo avanti importante, che vedremo nel 14.4. Ma nessuna ricerca, per quanto avanzata, risolve il problema se il documento giusto non è distinguibile da quelli sbagliati. Qui entra il versionamento: sapere quale versione di un documento è quella valida, quali sono state sostituite, che cosa è cambiato. I sistemi di gestione documentale lo fanno in modo strutturato; nelle cartelle condivise si affida ai nomi dei file, con risultati noti a tutti: 'definitivo', 'definitivo_2', 'definitivo_corretto'. La reperibilità è l'integrazione A applicata all'organizzazione: un'informazione che non si trova, o che non si distingue dalle versioni superate, è come se non ci fosse, o peggio.");
    infoTag(s, 1);
    await twoPanel(s, "Ricerca", bullets(["Per parole chiave: serve il termine esatto", "Per significato: trova anche con parole diverse (14.4)", "Nessuna ricerca distingue il giusto dal superato, se non è marcato"], { space: 4 }), "Versionamento", bullets(["Quale versione è valida?", "Quali sono state sostituite, che cosa è cambiato?", "Nelle cartelle: 'definitivo', 'definitivo_2', 'definitivo_corretto'"], { space: 4 }), { y: 1.15, h: 2.65, li: "FiSearch", ri: "FiGitCommit" });
    banner(s, 4.0, "Un'informazione che non si trova, o non si distingue dalle versioni superate, è come se non ci fosse. O peggio (A).", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Frammentazione e silos", "La frammentazione delle informazioni e i silos informativi tra reparti. La frammentazione è la dispersione delle informazioni su uno stesso argomento in molti luoghi e formati: una parte nel gestionale, una in un documento, una in un'email, una in una presentazione. I silos sono un caso specifico: ogni reparto ha le proprie informazioni, nei propri sistemi, con le proprie regole, e la condivisione tra reparti è difficile o assente. I silos hanno spesso buone ragioni: specializzazione, riservatezza, strumenti adatti a ciascun lavoro. Ma producono effetti noti: lo stesso dato inserito più volte, versioni diverse della stessa informazione, decisioni prese senza informazioni che esistevano altrove. Per l'AI, i silos pongono due questioni diverse, che non vanno confuse. La prima è tecnica: un assistente può vedere solo i silos a cui è collegato. La seconda è di opportunità: abbattere i silos dando all'AI accesso a tutto può sembrare la soluzione, ma alcuni silos esistono proprio per proteggere informazioni riservate. Lo vedremo nel 14.6, con l'integrazione D. Il punto qui è riconoscere i silos e capire quali separazioni sono un ostacolo e quali una protezione.");
    infoTag(s, 1);
    const r = ["Commerciale", "Produzione", "Amministrazione", "Risorse umane"];
    r.forEach((t, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.1, 1.5, C.background2, "silo " + t);
      txt(s, t, { x: x + 0.1, y: 1.2, w: 1.9, h: 0.38, fontSize: 13, bold: true, color: C.accent1, align: "center" });
      txt(s, "Propri sistemi, proprie regole, propri documenti", { x: x + 0.12, y: 1.6, w: 1.86, h: 0.95, fontSize: 11, color: C.text2, align: "center" });
    });
    docBox(s, 0.5, 2.85, 4.35, 1.4, "Ostacolo", "Dati inseriti più volte, versioni diverse, decisioni prese senza informazioni che esistevano altrove.", { fontSize: 12 });
    docBox(s, 5.15, 2.85, 4.35, 1.4, "Protezione", "Alcune separazioni esistono per proteggere informazioni riservate: non vanno abbattute per comodità (D).", { fontSize: 12, fill: C.accent6 });
    txt(s, "Un assistente vede solo i silos a cui è collegato.", { x: 0.5, y: 4.5, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Archivio o base di conoscenza", "Il sottotema chiede di distinguere un archivio documentale da una base di conoscenza. Un archivio conserva documenti: il suo scopo principale è che non vadano persi e che si possano ritrovare. Contiene di tutto, in ordine cronologico o per pratica, comprese bozze, versioni superate, documenti di contesto. Una base di conoscenza è costruita per rispondere a domande: contiene informazioni selezionate, verificate, aggiornate, organizzate per argomento e pensate per essere consultate. Un esempio classico è la base di conoscenza di un servizio di assistenza clienti: articoli brevi, uno per problema, con la soluzione validata, aggiornati quando cambia qualcosa. La differenza conta molto per l'AI. Collegare un assistente a un archivio significa esporlo a tutto, anche al superato e al contraddittorio. Collegarlo a una base di conoscenza curata significa dargli fonti pensate per rispondere. Molti progetti di assistenti aziendali scoprono, strada facendo, che il lavoro principale non è configurare l'AI, ma trasformare un archivio in qualcosa di più simile a una base di conoscenza: selezionare, eliminare i duplicati, aggiornare, organizzare. È lavoro, spesso sottostimato, e lo ritroveremo nel 14.8.");
    infoTag(s, 1);
    table(s, [["", "Archivio documentale", "Base di conoscenza"],
      ["Scopo", "Conservare e ritrovare", "Rispondere a domande"],
      ["Contenuto", "Tutto, comprese bozze e versioni superate", "Selezionato, verificato, aggiornato"],
      ["Organizzazione", "Per data, pratica, progetto", "Per argomento, pensata per la consultazione"],
      ["Con l'AI", "Espone anche il superato e il contraddittorio", "Offre fonti pensate per rispondere"]],
      { y: 1.15, colW: [1.8, 3.6, 3.6], rowH: 0.5, accentCol: 2, fontSize: 12 });
    banner(s, 3.85, "Spesso il lavoro principale non è configurare l'AI, ma trasformare un archivio in una base di conoscenza.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("I limiti della documentazione", "Torniamo alla conoscenza tacita, per vederne i limiti in termini di organizzazione: è l'integrazione C applicata al 14.3. La conoscenza distribuita nelle persone è una parte essenziale del funzionamento di un'azienda: chi sa come si fa, chi conosce i clienti, chi ricorda perché si è deciso così. Si può documentare una parte di questa conoscenza: le procedure, le soluzioni ai problemi ricorrenti, le domande frequenti, le lezioni apprese. Ed è utile farlo, anche per renderla disponibile a un assistente AI. Ma documentare ha dei limiti. Alcune conoscenze sono difficili da esprimere in parole: il giudizio su una situazione, la sensibilità nella relazione. Alcune cambiano troppo rapidamente per essere scritte. Alcune dipendono dal contesto di ogni singolo caso. E la documentazione richiede tempo, che le persone esperte, le più preziose, hanno di meno. Ne derivano due indicazioni. Primo: un assistente collegato ai documenti non sostituisce l'accesso alle persone; conviene che le sue risposte indichino anche a chi rivolgersi. Secondo, legato al Tema 13: se il lavoro degli esperti viene in parte affidato all'AI, la conoscenza tacita rischia di non essere più esercitata né trasmessa.");
    infoTag(s, 1);
    await card(s, 0.5, 1.15, 4.35, 2.15, { icon: "FiEdit3", head: "Si può documentare", headSize: 14, bodySize: 12, body: bullets(["Procedure e soluzioni ricorrenti", "Domande frequenti", "Lezioni apprese"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.15, { icon: "FiAlertCircle", head: "Difficile da documentare", headSize: 14, bodySize: 12, fill: C.accent6, body: bullets(["Giudizio e sensibilità nella relazione", "Ciò che cambia troppo in fretta", "Ciò che dipende da ogni caso"], { space: 4 }) });
    rowsLabel(s, [["Indicazione 1", "L'assistente non sostituisce le persone: indichi anche a chi rivolgersi"], ["Indicazione 2", "Se il lavoro degli esperti va all'AI, la conoscenza tacita va trasmessa (Tema 13)"]], { y: 3.5, h: 0.55, lw: 1.8 });
  }
  keySlide("Un'informazione che non si trova, o che non si distingue da quelle superate, è come se non ci fosse. E i documenti non contengono tutto ciò che l'azienda sa.", "Sottotema 14.3  ·  Organizzazione e accessibilità della conoscenza aziendale  ·  Integrazioni A e C", "Concetto chiave del terzo sottotema. Archivi e repository hanno logiche diverse, spesso incoerenti. Classificazione e metadati permettono di capire che cosa è un documento; ricerca e versionamento di trovare quello giusto. Frammentazione e silos disperdono le informazioni, ma alcune separazioni sono protezioni. Un archivio non è una base di conoscenza, e trasformare l'uno nell'altra è spesso il lavoro principale. La documentazione ha limiti: la conoscenza tacita resta nelle persone. Esercizio suggerito: confrontare in piccoli gruppi come sono organizzate le cartelle condivise di due reparti, e individuare tre metadati che renderebbero più facile trovare il documento giusto.");
  // =====================================================================
  section("14.4 L'AI e le informazioni specifiche");
  divider("14.4", "L'AI e le informazioni aziendali", "Come un sistema può usare informazioni che non ha appreso durante l'addestramento, e dove può sbagliare", "Uno dei sottotemi da approfondire, e il cuore tecnico del modulo, trattato a livello concettuale. Il modello non conosce le informazioni dell'azienda: come gliele si rende disponibili? Vediamo le modalità principali: nella conversazione, con file allegati, con il collegamento a raccolte documentali. Introduciamo in modo concettuale la Retrieval-Augmented Generation, o RAG, e la differenza tra recuperare informazioni e modificare il modello. Poi i possibili errori del recupero, e la differenza tra informazioni accessibili e informazioni realmente usate. Integrazione B: una fonte corretta non garantisce una risposta corretta. Il documento di perimetro chiede di evitare i dettagli tecnici, già accennati nel Tema 2.");
  {
    const s = content("Modello e azienda", "Il punto di partenza del sottotema: la differenza tra la conoscenza generale del modello e le informazioni specifiche dell'azienda. Come visto nel Tema 2, un modello linguistico apprende durante l'addestramento da grandi quantità di testi, in gran parte pubblici. Da lì viene la sua conoscenza generale: la lingua, i concetti, molti fatti sul mondo, i modi tipici di scrivere un'email o di strutturare un documento. Questa conoscenza ha tre limiti per l'uso aziendale. Non contiene le informazioni interne dell'azienda, che non erano tra i testi di addestramento. È ferma a una certa data, quella del termine dell'addestramento. E non è consultabile come un archivio: il modello non 'ricorda' documenti specifici in modo affidabile, ha appreso regolarità. Per questo, quando chiediamo a un assistente generico la procedura di reso della nostra azienda, nel migliore dei casi risponde che non la conosce; nel peggiore, produce una procedura plausibile ma inventata, il fenomeno delle allucinazioni visto nel Tema 3. Le informazioni aziendali vanno quindi fornite al modello al momento dell'uso. Le modalità sono diverse, e le vediamo nella prossima slide.");
    infoTag(s, 2);
    await twoPanel(s, "Conoscenza del modello", bullets(["Appresa nell'addestramento, da testi in gran parte pubblici", "Lingua, concetti, fatti, modi di scrivere", "Ferma a una data", "Non consultabile come un archivio"], { space: 4 }), "Informazioni dell'azienda", bullets(["Procedure, listini, contratti, decisioni", "Non erano nei testi di addestramento", "Cambiano continuamente", "Vanno fornite al momento dell'uso"], { space: 4 }), { y: 1.15, h: 2.65, li: "FiGlobe", ri: "FiHome" });
    banner(s, 4.0, "Senza informazioni aziendali, nel migliore dei casi 'non lo so'. Nel peggiore, una procedura plausibile ma inventata (Tema 3).", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Tre modi di fornire informazioni", "Le modalità principali con cui un sistema AI può usare informazioni aziendali, in ordine di complessità crescente. La prima: le informazioni fornite direttamente nella conversazione. L'utente scrive o incolla il contesto necessario: 'il cliente ha questo contratto, queste condizioni, questo problema'. È semplice e controllabile: l'utente sceglie esattamente che cosa fornire. Ma dipende interamente da lui, ed è limitata dalla quantità di testo che si può inserire. La seconda: file e documenti allegati. L'utente carica uno o più documenti, e il sistema li usa per rispondere. Come visto nel Tema 8, è il modo più diffuso per lavorare su documenti specifici. Anche qui è l'utente a scegliere le fonti, e il limite è il numero e la dimensione dei documenti. La terza: il collegamento a raccolte documentali. Il sistema è collegato a un archivio, una base di conoscenza, un insieme di cartelle, e cerca da solo i documenti pertinenti per ogni domanda. È la modalità degli assistenti aziendali sulle procedure, sui manuali tecnici, sulle policy interne. È molto più potente, perché copre migliaia di documenti, ma l'utente non sceglie più le fonti: le sceglie il sistema. E qui nascono i problemi che vediamo nel resto del sottotema.");
    infoTag(s, 2);
    const m = [["FiMessageSquare", "Nella conversazione", "L'utente scrive il contesto", "Semplice e controllabile; dipende dall'utente"], ["FiPaperclip", "File allegati", "L'utente carica i documenti", "Fonti scelte dall'utente; limiti di quantità (Tema 8)"], ["FiDatabase", "Raccolte collegate", "Il sistema cerca i documenti pertinenti", "Migliaia di documenti; le fonti le sceglie il sistema"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.65, i === 2 ? C.accent6 : C.background2, m[i][1]);
      await iconCircle(s, x + 1.08, 1.25, 0.7, m[i][0]);
      txt(s, m[i][1], { x: x + 0.15, y: 2.02, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, m[i][2], { x: x + 0.15, y: 2.45, w: 2.56, h: 0.5, fontSize: 12, bold: true, color: C.accent1, align: "center" });
      txt(s, m[i][3], { x: x + 0.15, y: 2.98, w: 2.56, h: 0.75, fontSize: 11, color: C.text2, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.4, 0.17);
    }
    banner(s, 4.0, "Più potenza, meno controllo diretto: nella terza modalità le fonti non le sceglie più l'utente.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Il recupero, in sintesi", "Introduciamo in modo concettuale la Retrieval-Augmented Generation, o RAG, cioè generazione aumentata dal recupero. Il termine è stato reso popolare da un articolo di ricercatori di Facebook AI, Lewis e colleghi, nel 2020; oggi indica in generale lo schema usato dalla maggior parte degli assistenti collegati a raccolte documentali. Lo schema ha quattro passaggi. Primo: l'utente fa una domanda. Secondo, il recupero: il sistema cerca nella raccolta i brani più pertinenti alla domanda; di solito non interi documenti, ma porzioni. Terzo, l'aumento: i brani recuperati vengono inseriti, insieme alla domanda, nelle istruzioni passate al modello, con un'indicazione del tipo 'rispondi usando queste fonti'. Quarto, la generazione: il modello produce la risposta, idealmente basandosi su quei brani e citandoli. L'idea è semplice e potente: il modello non deve conoscere le informazioni aziendali, deve solo leggerle al momento giusto, come uno studente bravo a cui si passano gli appunti pertinenti prima della risposta. Il documento chiede di solo accennare a come avviene la ricerca, con indici e database vettoriali che trovano i brani per somiglianza di significato. Il punto da capire è che ci sono due fasi distinte, recupero e generazione, e ciascuna può sbagliare.");
    infoTag(s, 2);
    const st = [["FiHelpCircle", "1  Domanda", "L'utente chiede"], ["FiSearch", "2  Recupero", "Il sistema cerca i brani pertinenti nella raccolta"], ["FiPlusSquare", "3  Aumento", "Brani e domanda insieme, nelle istruzioni al modello"], ["FiEdit3", "4  Generazione", "Il modello risponde, idealmente citando le fonti"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.1, 2.2, i === 1 || i === 3 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.25, 0.66, st[i][0]);
      txt(s, st[i][1], { x: x + 0.1, y: 2.0, w: 1.9, h: 0.38, fontSize: 14, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.12, y: 2.4, w: 1.86, h: 0.85, fontSize: 11, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.15, 0.17);
    }
    shapeBox(s, 0.5, 3.5, 9.0, 0.6, C.background2, "nota tecnica");
    txt(s, [{ text: "Solo un accenno: ", options: { bold: true, color: C.accent1 } }, { text: "indici e database vettoriali trovano i brani per somiglianza di significato (Lewis et al., 2020).", options: { color: C.text1 } }], { x: 0.7, y: 3.5, w: 8.6, h: 0.6, fontSize: 12, valign: "middle" });
    banner(s, 4.25, "Due fasi distinte, recupero e generazione. Ciascuna può sbagliare.", { h: 0.65, fontSize: 15 });
  }
  {
    const s = content("Recuperare o modificare il modello", "Una distinzione che il sottotema chiede di chiarire, perché è fonte di molti equivoci: recuperare informazioni non è la stessa cosa che modificare il modello. Quando si dice 'addestriamo l'AI sui nostri documenti', spesso si intende in realtà collegarla ai documenti con il recupero: il modello resta lo stesso, e legge le fonti al momento della domanda. Modificare il modello, invece, significa proseguirne l'addestramento su dati aziendali, il cosiddetto fine-tuning, visto nel Tema 2, in modo che apprenda uno stile, un formato, un vocabolario o un comportamento. Le due strade hanno usi diversi. Il recupero è adatto a informazioni che cambiano, che devono essere citate, che hanno permessi diversi: le informazioni restano nelle fonti, si aggiornano aggiornando i documenti, e si possono verificare. La modifica del modello è adatta a insegnare un modo di fare, non a memorizzare fatti: le informazioni apprese non sono citabili, non si aggiornano facilmente, e non si possono 'togliere' a chi non è autorizzato. Per la maggior parte degli usi aziendali basati su conoscenza, il recupero è la strada più indicata. Il documento chiede di non entrare nei dettagli tecnici: basta sapere che le due cose esistono e servono a scopi diversi.");
    infoTag(s, 2);
    table(s, [["", "Recuperare informazioni", "Modificare il modello"],
      ["Che cosa avviene", "Il modello legge le fonti a ogni domanda", "Il modello prosegue l'addestramento (fine-tuning)"],
      ["Adatto a", "Informazioni che cambiano, da citare, con permessi", "Stile, formato, vocabolario, comportamento"],
      ["Aggiornamento", "Si aggiorna il documento", "Serve un nuovo addestramento"],
      ["Verifica e permessi", "Fonti citabili, accessi applicabili", "Non citabile, non si 'toglie' a chi non è autorizzato"]],
      { y: 1.15, colW: [1.9, 3.55, 3.55], rowH: 0.52, accentCol: 1, fontSize: 12 });
    banner(s, 3.95, "'Addestriamo l'AI sui nostri documenti' di solito significa collegarla. Per la conoscenza aziendale, il recupero è la strada più indicata.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Istruzioni, contesto e fonti", "Il sottotema parla di personalizzazione attraverso istruzioni, contesto e fonti. Molti assistenti aziendali, anche quelli offerti dagli strumenti più diffusi, permettono di configurare tre elementi, senza modificare il modello. Le istruzioni: indicazioni stabili su come comportarsi, per esempio rispondi solo sulla base delle procedure fornite, cita sempre il documento e la versione, se l'informazione non è presente dillo e indica a chi rivolgersi, non dare indicazioni su argomenti legali. Il contesto: informazioni sull'utente o sulla situazione, per esempio il reparto, il ruolo, il cliente su cui si sta lavorando. Le fonti: le raccolte documentali a cui l'assistente è collegato, scelte per lo scopo. È una personalizzazione potente e accessibile, che richiede competenze organizzative più che tecniche: chi conosce il processo sa quali fonti sono affidabili e quali istruzioni servono. L'esempio in slide, fittizio, mostra istruzioni per un assistente sulle procedure interne. Le istruzioni migliorano il comportamento, ma non lo garantiscono: il modello può non rispettarle sempre, come visto nel Tema 5. Ecco perché le verifiche restano necessarie.");
    infoTag(s, 2);
    promptBox(s, 0.5, 1.15, 5.4, 2.85, "Rispondi solo sulla base delle procedure fornite.\nCita sempre documento e versione.\nSe l'informazione non è presente, dillo e indica a chi rivolgersi.\nSe trovi indicazioni contraddittorie, segnalalo.\nNon dare indicazioni su questioni legali.", { label: "Istruzioni per un assistente sulle procedure (esempio fittizio)", fontSize: 11 });
    rowsLabel(s, [["Istruzioni", "Come comportarsi"], ["Contesto", "Chi chiede, in quale situazione"], ["Fonti", "Le raccolte scelte per lo scopo"]], { y: 1.15, h: 0.6, lw: 1.3, x: 6.15, w: 3.35 });
    banner(s, 4.2, "Personalizzare senza modificare il modello. Le istruzioni migliorano il comportamento, non lo garantiscono.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Quando il recupero sbaglia", "I possibili errori nel recupero delle informazioni, uno dei punti da approfondire. Il recupero è una ricerca, e come ogni ricerca può sbagliare in modi diversi. Può recuperare il brano sbagliato: un documento che parla dello stesso argomento ma per un altro prodotto, un altro reparto, un altro paese. Può recuperare una versione superata, se non è marcata come tale. Può recuperare un brano incompleto: la regola generale senza l'eccezione che si trova nel paragrafo successivo, perché i documenti vengono spezzati in porzioni e la porzione recuperata non contiene tutto. Può non recuperare nulla di pertinente, perché la domanda usa termini diversi da quelli dei documenti, o perché l'informazione non c'è. E può recuperare troppo: molti brani parzialmente pertinenti, tra cui il modello deve scegliere. In tutti questi casi il modello genera comunque una risposta, spesso convincente, basata su ciò che ha ricevuto. Ricerche sul tema hanno anche mostrato che i modelli tendono a usare meglio le informazioni all'inizio e alla fine di un lungo contesto, e peggio quelle nel mezzo: è il fenomeno descritto come 'lost in the middle', da Liu e colleghi nel 2024. Il risultato è che il recupero non è un passaggio neutro: determina che cosa il modello vede, e quindi che cosa può rispondere.");
    infoTag(s, 2);
    await iconGrid(s, [
      { icon: "FiShuffle", head: "Il brano sbagliato", body: "Stesso argomento, altro prodotto, reparto, paese" },
      { icon: "FiClock", head: "La versione superata", body: "Se non è marcata come tale" },
      { icon: "FiScissors", head: "Il brano incompleto", body: "La regola senza l'eccezione del paragrafo dopo" },
      { icon: "FiXCircle", head: "Niente di pertinente", body: "Termini diversi, o informazione assente" },
      { icon: "FiLayers", head: "Troppo", body: "Molti brani parziali tra cui scegliere" },
      { icon: "FiMinimize2", head: "Perso nel mezzo", body: "Le informazioni centrali usate peggio (Liu et al., 2024)" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "In tutti i casi il modello risponde comunque, spesso in modo convincente.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Accessibili, recuperate, usate", "L'ultimo punto del sottotema, e uno dei più importanti: la differenza tra informazioni accessibili e informazioni realmente utilizzate nella risposta. Si possono distinguere tre insiemi, uno dentro l'altro. Le informazioni accessibili: tutto ciò a cui il sistema è collegato, magari migliaia di documenti. Le informazioni recuperate: i pochi brani che il sistema ha trovato per quella domanda. Le informazioni usate: ciò che il modello ha effettivamente considerato nel generare la risposta. Ogni passaggio riduce l'insieme, e ciascuno può perdere qualcosa di importante. Quando un assistente aziendale viene presentato come 'collegato a tutte le procedure', è vero per il primo insieme, non per gli altri due. A ciò si aggiungono i limiti della conoscenza effettivamente disponibile: se un'informazione non è in nessun documento, perché è tacita, perché è stata decisa ieri, perché sta in un sistema non collegato, nessun recupero la troverà. Ecco l'integrazione B: una fonte corretta, anche presente nella raccolta, non garantisce una risposta corretta, perché può non essere recuperata, essere recuperata solo in parte, o essere interpretata male.");
    infoTag(s, 2);
    s.addShape(pres.shapes.OVAL, { x: 0.5, y: 1.1, w: 5.2, h: 3.3, fill: { color: HEX.lt2 }, line: { color: HEX.a1, width: 1 }, objectName: "accessibili" });
    s.addShape(pres.shapes.OVAL, { x: 1.5, y: 1.9, w: 3.4, h: 2.3, fill: { color: "CFE6E4" }, line: { color: HEX.a1, width: 1 }, objectName: "recuperate" });
    s.addShape(pres.shapes.OVAL, { x: 2.3, y: 2.75, w: 1.9, h: 1.3, fill: { color: HEX.a1 }, line: { type: "none" }, objectName: "usate" });
    txt(s, "Accessibili", { x: 2.0, y: 1.25, w: 2.2, h: 0.35, fontSize: 13, bold: true, color: C.accent1, align: "center" });
    txt(s, "Recuperate", { x: 2.1, y: 2.1, w: 2.2, h: 0.35, fontSize: 13, bold: true, color: C.accent1, align: "center" });
    txt(s, "Usate", { x: 2.3, y: 3.2, w: 1.9, h: 0.4, fontSize: 14, bold: true, color: C.background1, align: "center" });
    rowsLabel(s, [["Accessibili", "Tutto ciò a cui il sistema è collegato"], ["Recuperate", "I brani trovati per questa domanda"], ["Usate", "Ciò che il modello ha considerato"], ["Fuori", "Tacito, deciso ieri, sistemi non collegati"]], { y: 1.15, h: 0.6, lw: 1.25, x: 5.95, w: 3.55, fontSize: 11 });
    banner(s, 4.55, "'Collegato a tutte le procedure' vale per il primo insieme, non per gli altri due (B).", { h: 0.5, fontSize: 13 });
  }
  keySlide("Il modello non conosce l'azienda: legge le fonti che gli vengono recuperate. E ciò che è accessibile non è ciò che viene davvero usato nella risposta.", "Sottotema 14.4  ·  Come l'AI può utilizzare informazioni aziendali specifiche  ·  Integrazione B", "Concetto chiave del quarto sottotema. La conoscenza del modello è generale e ferma a una data; le informazioni aziendali vanno fornite al momento dell'uso: nella conversazione, con file allegati, con il collegamento a raccolte. Lo schema del recupero, o RAG, ha due fasi, recupero e generazione, ciascuna con i propri errori. Recuperare non è modificare il modello. Istruzioni, contesto e fonti permettono di personalizzare senza addestrare. Tra informazioni accessibili, recuperate e usate, ogni passaggio può perdere qualcosa. Esercizio suggerito: con un assistente a cui si allega un documento fittizio lungo, porre domande la cui risposta si trova all'inizio, a metà e alla fine, e confrontare la qualità delle risposte e delle citazioni.");

  // =====================================================================
  section("14.5 Integrazione con i sistemi");
  divider("14.5", "Integrazione con i sistemi", "Collegare applicazioni non implica accordare all'AI un accesso indiscriminato ai loro contenuti", "Dal recupero di documenti passiamo alle applicazioni aziendali. Il documento di perimetro chiede di preservare con cura il confine con il 14.4: lì il recupero di conoscenza specifica, qui l'integrazione con applicazioni operative e dati gestionali. Il livello è 'conoscere': vediamo le categorie di applicazioni, la differenza tra consultare documenti e accedere a dati operativi, sola lettura e modifica, dipendenza dalle integrazioni, interoperabilità, coerenza tra sistemi e accesso selettivo. Integrazione D. Le API e le integrazioni enterprise vanno solo accennate; il funzionamento degli agenti è del Tema 11.");
  {
    const s = content("Le applicazioni aziendali", "Una panoramica delle principali categorie di applicazioni aziendali, senza entrare nei prodotti, come chiede il documento di perimetro, che rimanda al Tema 4 per l'ecosistema. Il CRM, Customer Relationship Management, gestisce i rapporti con i clienti: anagrafiche, contatti, opportunità, offerte, storico delle interazioni. L'ERP, Enterprise Resource Planning, integra i processi gestionali: ordini, acquisti, magazzino, produzione, contabilità, fatturazione. I gestionali verticali coprono ambiti specifici: la gestione del personale, la manutenzione, la qualità, l'assistenza clienti con i sistemi di ticket. Gli strumenti collaborativi supportano la comunicazione e il lavoro comune: posta, chat, calendari, documenti condivisi, gestione dei progetti. A questi si aggiungono i sistemi di analisi e reportistica. Ciascuna applicazione contiene informazioni preziose e diverse, ed è pensata per un certo tipo di utenti e di operazioni. Molti fornitori di queste applicazioni stanno integrando funzioni AI direttamente nei propri prodotti; in altri casi è un assistente esterno a collegarsi a più applicazioni. Il funzionamento delle integrazioni, tramite le cosiddette API, interfacce di programmazione, va solo accennato.");
    infoTag(s, 2);
    await iconGrid(s, [
      { icon: "FiUsers", head: "CRM", body: "Clienti, contatti, opportunità, offerte, interazioni" },
      { icon: "FiBox", head: "ERP", body: "Ordini, acquisti, magazzino, produzione, contabilità" },
      { icon: "FiTool", head: "Gestionali verticali", body: "Personale, manutenzione, qualità, ticket" },
      { icon: "FiMessageCircle", head: "Strumenti collaborativi", body: "Posta, chat, calendari, documenti, progetti" },
      { icon: "FiBarChart2", head: "Analisi e reportistica", body: "Indicatori, cruscotti, report" },
      { icon: "FiLink", head: "Integrazioni (API)", body: "Le interfacce che collegano i sistemi: solo un accenno" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "AI integrata nelle applicazioni, o un assistente esterno collegato a più applicazioni.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Documenti o dati operativi", "La distinzione centrale del sottotema: consultare documenti non è la stessa cosa che accedere a dati operativi. I documenti, visti nel 14.4, descrivono regole, procedure, conoscenze: come si gestisce un reso, quali sono le condizioni standard. Cambiano relativamente di rado. I dati operativi descrivono la situazione attuale: lo stato di questo ordine, la giacenza di questo articolo, il saldo di questo cliente, i ticket aperti oggi. Cambiano di continuo, e si trovano nelle applicazioni gestionali. Molte domande utili richiedono entrambi. 'Posso accettare il reso del cliente Alfa?' richiede la procedura di reso, un documento, e i dati dell'ordine del cliente, data di consegna e prodotto, che sono dati operativi. Un assistente collegato solo ai documenti risponderà in modo generico; uno collegato anche al gestionale potrà applicare la regola al caso. Le integrazioni con le applicazioni permettono, quando disponibili, di accedere a dati aggiornati e in tempo reale. Il prezzo è una maggiore complessità: più sistemi coinvolti, più permessi da gestire, più punti in cui qualcosa può non funzionare. Esempio fittizio.");
    infoTag(s, 2);
    await twoPanel(s, "Documenti (14.4)", bullets(["Regole, procedure, conoscenze", "Come si gestisce un reso", "Cambiano di rado"], { space: 4 }), "Dati operativi (14.5)", bullets(["La situazione attuale", "Questo ordine, questa giacenza, questo saldo", "Cambiano di continuo, nei gestionali"], { space: 4 }), { y: 1.15, h: 2.1, li: "FiBook", ri: "FiActivity" });
    shapeBox(s, 0.5, 3.45, 9.0, 0.75, C.background2, "esempio");
    txt(s, [{ text: "'Posso accettare il reso del cliente Alfa?' ", options: { bold: true, color: C.accent1 } }, { text: "Serve la procedura (documento) e la data di consegna dell'ordine (dato operativo). Esempio fittizio.", options: { color: C.text1 } }], { x: 0.7, y: 3.45, w: 8.6, h: 0.75, fontSize: 12, valign: "middle" });
    banner(s, 4.35, "Più sistemi coinvolti: più permessi da gestire, più punti in cui qualcosa può non funzionare.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Leggere o anche modificare", "Una distinzione decisiva: sistemi con capacità di sola lettura e sistemi che consentono modifiche e operazioni. Con la sola lettura, l'AI consulta i dati: legge lo stato dell'ordine, la giacenza, lo storico del cliente. Il rischio principale è informativo: una risposta sbagliata, o l'esposizione di dati a chi non dovrebbe vederli, come vedremo nel 14.6. Con la possibilità di modifica, l'AI può anche agire: aggiornare un'anagrafica, creare un ticket, registrare un ordine, inviare un'email, modificare uno stato. Il rischio cambia natura: un errore non produce solo una risposta sbagliata, ma un'operazione sbagliata, con effetti reali, a volte difficili da annullare. È il passaggio, visto nel Tema 11, dall'assistente che risponde all'agente che agisce. Il documento di perimetro chiede di non ripetere qui il funzionamento degli agenti, ma di segnalare la distinzione in termini di accesso ai dati. Un'indicazione pratica, coerente con il principio del minimo privilegio che vedremo nel 14.6: partire dalla sola lettura, e concedere la possibilità di modifica solo quando serve davvero, per operazioni specifiche, con controlli e approvazioni proporzionati al rischio.");
    infoTag(s, 2);
    const c = [["FiEye", "Sola lettura", "Consulta: stato dell'ordine, giacenza, storico", "Rischio informativo: risposta sbagliata, esposizione di dati", C.background2], ["FiEdit", "Lettura e modifica", "Agisce: aggiorna, crea, registra, invia", "Rischio operativo: operazioni sbagliate, effetti reali (Tema 11)", C.accent6]];
    for (let i = 0; i < 2; i++) {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 1.15, 4.35, 2.4, c[i][4], c[i][1]);
      await iconCircle(s, x + 0.2, 1.3, 0.6, c[i][0]);
      txt(s, c[i][1], { x: x + 0.95, y: 1.3, w: 3.2, h: 0.6, fontSize: 17, bold: true, color: C.text1, valign: "middle" });
      txt(s, c[i][2], { x: x + 0.2, y: 2.05, w: 3.95, h: 0.6, fontSize: 13, color: C.text1 });
      txt(s, c[i][3], { x: x + 0.2, y: 2.7, w: 3.95, h: 0.75, fontSize: 12, bold: true, color: i ? C.accent5 : C.accent1 });
    }
    banner(s, 3.8, "Partire dalla sola lettura. Concedere la modifica solo quando serve, per operazioni specifiche, con controlli proporzionati.", { h: 1.0, fontSize: 14 });
  }
  {
    const s = content("Integrazioni e interoperabilità", "Tre punti del sottotema legati alla qualità delle integrazioni. La dipendenza dalla qualità delle integrazioni: un assistente collegato a un gestionale funziona bene quanto il collegamento. Se l'integrazione non trasmette alcuni campi, se è lenta, se si interrompe quando il fornitore aggiorna il sistema, l'assistente risponderà in modo incompleto o non risponderà. E spesso l'utente non se ne accorge: vede una risposta, non vede il collegamento che non ha funzionato. I limiti dell'interoperabilità: i sistemi aziendali sono stati costruiti in momenti diversi, da fornitori diversi, con formati e logiche diversi. Non tutti si lasciano collegare facilmente, e alcuni sistemi più datati non offrono collegamenti adatti. La coerenza tra informazioni presenti in sistemi differenti: il codice cliente nel CRM non coincide con quello nel gestionale; il prezzo nel listino differisce da quello in fattura; lo stato dell'ordine è aggiornato in un sistema e non nell'altro. Collegare l'AI a più sistemi rende visibili queste incoerenze, e talvolta le mescola in una risposta. Come per la qualità dei documenti, l'AI non risolve questi problemi: li eredita.");
    infoTag(s, 2);
    rowsLabel(s, [["Qualità delle integrazioni", "Campi mancanti, lentezze, interruzioni dopo un aggiornamento: l'utente vede la risposta, non il collegamento"], ["Interoperabilità", "Sistemi di epoche, fornitori e formati diversi; alcuni difficili da collegare"], ["Coerenza tra sistemi", "Codici cliente diversi, prezzi diversi, stati non allineati"]], { y: 1.15, h: 0.85, lw: 2.5 });
    banner(s, 4.0, "Come per i documenti, l'AI non risolve questi problemi: li eredita, e talvolta li mescola in una risposta.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Collegare non è aprire tutto", "L'ultimo punto del sottotema e l'integrazione D: l'accessibilità selettiva in funzione degli utenti e delle finalità. Collegare un'applicazione a un sistema AI non implica accordare all'AI un accesso indiscriminato ai suoi contenuti. Un CRM contiene informazioni di tutti i clienti, compresi quelli seguiti da altri commerciali, le trattative riservate, le note personali. Un ERP contiene dati contabili, retribuzioni, condizioni di acquisto. Un sistema delle risorse umane contiene dati personali e sensibili. Se l'assistente è collegato a questi sistemi con permessi ampi, chiunque lo usi potrebbe, con la domanda giusta, ottenere informazioni che non dovrebbe vedere. L'integrazione va quindi progettata pensando a che cosa serve per ciascun caso d'uso, e per ciascun utente. Un assistente per l'assistenza clienti ha bisogno dello stato degli ordini e dei ticket, non delle marginalità. Un assistente per i commerciali ha bisogno dei loro clienti, non necessariamente di tutti. Questa è la logica che approfondiamo nel prossimo sottotema, dedicato agli accessi e ai permessi. Esempi fittizi.");
    infoTag(s, 2);
    table(s, [["Caso d'uso (fittizio)", "Che cosa serve", "Che cosa non serve"],
      ["Assistente per l'assistenza clienti", "Stato degli ordini, ticket, procedure", "Marginalità, condizioni di acquisto"],
      ["Assistente per i commerciali", "I propri clienti, listini, offerte", "Trattative di altri, retribuzioni"],
      ["Assistente per l'amministrazione", "Fatture, pagamenti, fornitori", "Note sui colloqui del personale"]],
      { y: 1.15, colW: [3.0, 3.0, 3.0], rowH: 0.6, accentCol: 1, fontSize: 12, blankCorner: false });
    banner(s, 3.8, "Con permessi ampi, con la domanda giusta, chiunque potrebbe ottenere ciò che non dovrebbe vedere (D).", { h: 0.9, fontSize: 14 });
  }
  keySlide("Collegare un'applicazione all'AI non significa aprirle tutto ciò che contiene.", "Sottotema 14.5  ·  Integrazione dell'AI con applicazioni e sistemi aziendali  ·  Integrazione D", "Concetto chiave del quinto sottotema. Le applicazioni aziendali, CRM, ERP, gestionali e strumenti collaborativi, contengono dati operativi, diversi dai documenti: descrivono la situazione attuale e cambiano di continuo. Sola lettura e modifica comportano rischi di natura diversa, informativa e operativa. Le integrazioni hanno una qualità, dei limiti di interoperabilità, e rendono visibili le incoerenze tra sistemi. E vanno progettate in modo selettivo, per caso d'uso e per utente. Esercizio suggerito: scegliere un'applicazione gestionale usata nel proprio lavoro e, per un caso d'uso fittizio di assistente, elencare quali informazioni dovrebbe poter leggere, quali no, e se servirebbe mai la possibilità di modifica.");

  // =====================================================================
  section("14.6 Accessi e permessi");
  divider("14.6", "Accessi, permessi e disponibilità", "L'AI deve poter consultare soltanto ciò che è pertinente e autorizzato per il caso d'uso", "Uno dei sottotemi da approfondire. Se l'AI accede alle informazioni aziendali, chi decide che cosa può vedere, e per conto di chi? Vediamo la differenza tra disponibilità e autorizzazione, la classificazione delle informazioni, i controlli basati sui ruoli, il principio del minimo privilegio, i permessi degli utenti e dei sistemi AI, il rischio di esposizione, la separazione tra contesti, la tracciabilità e l'equilibrio tra accessibilità e protezione. Integrazione D. Il documento chiede di introdurre permessi e protezione senza approfondire la disciplina giuridica e la governance, che sono dei Temi 17 e 18, né l'implementazione tecnica dei controlli.");
  {
    const s = content("Esistere non è essere autorizzati", "Il primo punto del sottotema: la differenza tra disponibilità dei dati e autorizzazione ad accedervi. Riprende le quattro condizioni dell'introduzione: un'informazione disponibile, cioè esistente, non è per questo accessibile a chiunque. In ogni azienda le informazioni sono soggette a regole di accesso, scritte o implicite: le retribuzioni le vede l'ufficio del personale, le trattative riservate chi le segue, i dati di un progetto il team del progetto. Queste regole esistono per ragioni diverse: proteggere dati personali, rispettare obblighi contrattuali di riservatezza, tutelare informazioni strategiche, evitare conflitti di interesse, ridurre il rischio di errori. Quando si introduce un sistema AI, le regole devono continuare a valere. La domanda da porsi non è solo 'l'informazione c'è?', ma 'questo utente, per questo scopo, è autorizzato a vederla?'. E, come vedremo, anche 'il sistema AI è autorizzato a vederla per conto di questo utente?'. Per tutti gli aspetti giuridici, come la protezione dei dati personali, rimandiamo ai Temi 17 e 18: qui ci interessa la logica degli accessi.");
    infoTag(s, 3);
    await twoPanel(s, "La domanda incompleta", "L'informazione c'è?", "Le domande giuste", "Questo utente, per questo scopo, è autorizzato a vederla?\n\nIl sistema AI è autorizzato a vederla per conto suo?", { y: 1.15, h: 2.1, li: "FiDatabase", ri: "FiKey" });
    txt(s, "Perché esistono le regole di accesso", { x: 0.5, y: 3.35, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    ["Dati personali", "Riservatezza contrattuale", "Informazioni strategiche", "Conflitti di interesse", "Rischio di errori"].forEach((t, i) => chip(s, 0.5 + i * 1.835, 3.72, 1.66, 0.62, t, { fill: C.accent6, fontSize: 11 }));
    txt(s, "Gli aspetti giuridici sono dei Temi 17 e 18: qui la logica degli accessi.", { x: 0.5, y: 4.48, w: 9, h: 0.38, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Livelli di classificazione", "Il sottotema introduce una classificazione delle informazioni in quattro livelli, comune in molte organizzazioni anche se i nomi e i dettagli variano. Pubbliche: informazioni destinate o già note all'esterno, come il catalogo, il sito, i comunicati. La loro diffusione non crea danni. Interne: informazioni per l'uso all'interno dell'azienda, come le procedure operative, l'organigramma, le comunicazioni interne. La diffusione all'esterno sarebbe inopportuna, ma non grave. Riservate: informazioni accessibili solo a persone o gruppi specifici, come contratti con i clienti, offerte, dati economici, piani strategici, progetti non annunciati. La diffusione potrebbe causare danni economici o reputazionali. Sensibili: le informazioni più protette, come i dati personali dei dipendenti e dei clienti, in particolare quelli che la normativa considera categorie particolari, come i dati sanitari, i dati sulle retribuzioni e sulle valutazioni, i segreti industriali. La diffusione può causare danni gravi alle persone o all'azienda, e violare obblighi di legge. La classificazione è il presupposto di ogni regola di accesso: se non è chiaro a quale livello appartiene un documento, non si può decidere chi lo può vedere, né se un sistema AI lo può usare.");
    infoTag(s, 3);
    const lv = [["Pubbliche", "Catalogo, sito, comunicati", "Nessun danno", HEX.lt2, C.text1], ["Interne", "Procedure, organigramma, comunicazioni", "Inopportuno, non grave", "D9ECEA", C.text1], ["Riservate", "Contratti, offerte, dati economici, piani", "Danni economici o reputazionali", HEX.a1, C.background1], ["Sensibili", "Dati personali, sanitari, retribuzioni, segreti industriali", "Danni gravi, obblighi di legge", HEX.dk2, C.background1]];
    lv.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      s.addShape(pres.shapes.RECTANGLE, { x, y: 1.15, w: 2.15, h: 2.6, fill: { color: e[3] }, line: { type: "none" }, objectName: "livello " + e[0] });
      txt(s, String(i + 1), { x: x + 0.15, y: 1.22, w: 0.6, h: 0.5, fontSize: 24, bold: true, color: e[4] });
      txt(s, e[0], { x: x + 0.15, y: 1.75, w: 1.9, h: 0.4, fontSize: 16, bold: true, color: e[4] });
      txt(s, e[1], { x: x + 0.15, y: 2.2, w: 1.88, h: 0.8, fontSize: 11, color: e[4] });
      txt(s, "Se diffuse: " + e[2], { x: x + 0.15, y: 3.0, w: 1.88, h: 0.7, fontSize: 11, bold: true, color: e[4] });
    });
    txt(s, "Protezione crescente", { x: 0.5, y: 3.85, w: 2.0, h: 0.32, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
    arrow(s, 2.5, 3.85, 7.0, C.accent5);
    banner(s, 4.35, "Se non è chiaro il livello, non si può decidere chi vede, né se l'AI può usarlo.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Ruoli e minimo privilegio", "Due principi classici della sicurezza delle informazioni, che il sottotema chiede di conoscere. I controlli di accesso basati sui ruoli, spesso indicati con la sigla inglese RBAC, Role-Based Access Control: invece di decidere persona per persona che cosa può vedere, si definiscono ruoli, come commerciale, addetto amministrativo, responsabile di reparto, e a ciascun ruolo si assegnano i permessi. Le persone ricevono i permessi del loro ruolo. È più semplice da gestire e più coerente. Il principio del minimo privilegio: ogni utente, e ogni sistema, dovrebbe avere solo i permessi strettamente necessari per svolgere il proprio compito, e non di più. Non 'tutto tranne ciò che è vietato', ma 'solo ciò che serve'. Il principio è formulato da decenni nella letteratura sulla sicurezza informatica; una formulazione classica è quella di Saltzer e Schroeder, del 1975. Applicato all'AI, il principio ha un significato preciso: un assistente dovrebbe accedere solo alle fonti e ai dati necessari per il suo caso d'uso, e, quando agisce per un utente, solo a ciò che quell'utente può vedere. È l'integrazione D nella sua forma operativa: l'efficacia non richiede accesso illimitato, ma disponibilità mirata.");
    infoTag(s, 3);
    await twoPanel(s, "Accesso basato sui ruoli", "Si definiscono ruoli (commerciale, amministrativo, responsabile) e permessi per ruolo.\n\nPiù semplice da gestire, più coerente.", "Minimo privilegio", "Solo i permessi strettamente necessari per il compito.\n\nNon 'tutto tranne il vietato', ma 'solo ciò che serve' (Saltzer e Schroeder, 1975).", { y: 1.15, h: 2.4, li: "FiUsers", ri: "FiMinimize" });
    banner(s, 3.8, "Per l'AI: solo le fonti necessarie al caso d'uso, e per ogni utente solo ciò che quell'utente può vedere (D).", { h: 1.0, fontSize: 14 });
  }
  {
    const s = content("I permessi di chi?", "Un punto del sottotema che merita attenzione, perché è nuovo rispetto alla gestione tradizionale degli accessi: i permessi degli utenti e i permessi dei sistemi AI. Quando un assistente AI accede a un archivio o a un'applicazione, con quali permessi lo fa? Ci sono due modelli, semplificando. Nel primo, l'assistente agisce con i permessi dell'utente che lo usa: vede solo ciò che quell'utente potrebbe vedere da solo. Se Mario non può aprire la cartella delle retribuzioni, nemmeno l'assistente usato da Mario può leggerla. È il modello più coerente con le regole esistenti, e quello che la maggior parte degli strumenti aziendali cerca di applicare. Nel secondo, l'assistente ha permessi propri, spesso ampi, definiti al momento del collegamento, per esempio un'utenza tecnica che può leggere l'intero archivio. In questo caso, se non ci sono altri filtri, qualunque utente dell'assistente può ottenere, attraverso le sue risposte, informazioni a cui non avrebbe accesso diretto. Il sottotema chiede proprio questo: la necessità di verificare come le autorizzazioni vengono applicate nei sistemi AI. Non è un dettaglio tecnico da lasciare ai fornitori: è una domanda che chi introduce un assistente deve porsi, e a cui deve ottenere una risposta chiara. Esempio fittizio.");
    infoTag(s, 3);
    const m = [["Con i permessi dell'utente", "L'assistente vede solo ciò che l'utente vedrebbe da solo", "Mario non apre le retribuzioni: nemmeno il suo assistente", C.accent6, C.accent1], ["Con permessi propri, ampi", "Un'utenza tecnica legge l'intero archivio", "Senza altri filtri, chiunque può ottenere ciò a cui non ha accesso", C.background2, C.accent5]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 1.15, 4.35, 2.4, e[3], e[0]);
      txt(s, e[0], { x: x + 0.2, y: 1.25, w: 3.95, h: 0.45, fontSize: 16, bold: true, color: e[4] });
      txt(s, e[1], { x: x + 0.2, y: 1.75, w: 3.95, h: 0.7, fontSize: 13, color: C.text1 });
      txt(s, e[2], { x: x + 0.2, y: 2.5, w: 3.95, h: 0.9, fontSize: 12, italic: true, color: C.text2 });
    });
    banner(s, 3.8, "Verificare come le autorizzazioni vengono applicate nei sistemi AI: una domanda da porre, e a cui ottenere una risposta chiara.", { h: 1.0, fontSize: 14 });
  }
  {
    const s = content("Il rischio di esposizione", "Il rischio di esposizione di informazioni non necessarie, uno dei punti più concreti del sottotema. C'è un fenomeno ben noto a chi introduce assistenti aziendali, che a volte viene chiamato 'oversharing', condivisione eccessiva. In molte aziende esistono documenti condivisi in modo più ampio del dovuto: una cartella con i dati del personale accessibile a tutto il reparto per un errore di configurazione di anni prima; un file con le retribuzioni condiviso con un link 'chiunque nell'organizzazione'; un verbale riservato salvato in uno spazio comune. Finché nessuno li cerca, il problema resta invisibile: i documenti sono tecnicamente accessibili, ma nessuno sa che ci sono. Un assistente AI che lavora con i permessi dell'utente e cerca in tutto ciò che l'utente può vedere li trova, e li usa nelle risposte. La domanda 'quali sono gli stipendi nel mio reparto?' può ottenere una risposta. L'AI non ha violato nessun permesso: ha reso visibile un problema che c'era già. Per questo, prima di collegare un assistente agli archivi, conviene verificare i permessi esistenti e correggere le condivisioni eccessive. È un caso esemplare di come l'AI renda urgenti problemi di organizzazione delle informazioni che erano rimasti latenti. Esempi fittizi.");
    infoTag(s, 3);
    const st = [["Una condivisione eccessiva", "Cartella del personale aperta a tutto il reparto, per un errore di anni fa", C.background2], ["Invisibile", "Tecnicamente accessibile, ma nessuno sa che c'è", C.background2], ["L'assistente la trova", "Cerca in tutto ciò che l'utente può vedere, e la usa", C.accent6]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.75, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.42, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.68, w: 2.56, h: 1.1, fontSize: 12, color: C.text1 });
      if (i < 2) arrow(s, x + 2.88, 1.92, 0.17);
    });
    docBox(s, 0.5, 3.1, 9.0, 0.75, "Domanda (esempio fittizio)", "Quali sono gli stipendi nel mio reparto?  L'assistente risponde.", { fontSize: 13 });
    banner(s, 4.05, "L'AI non ha violato permessi: ha reso visibile un problema che c'era già. Verificare le condivisioni prima di collegare.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Separare i contesti", "Due punti del sottotema legati tra loro: la separazione tra funzioni e contesti aziendali, e gli accessi coerenti con il contesto operativo. La separazione: alcune informazioni non devono passare da un contesto all'altro, anche all'interno della stessa azienda. Le informazioni su un cliente gestite dalla consulenza non dovrebbero essere visibili a chi ne gestisce un concorrente; le informazioni di una gara non dovrebbero essere visibili a chi valuta le offerte dei fornitori in un'altra; i dati di una società del gruppo non sempre possono essere condivisi con un'altra. In alcuni settori sono obblighi precisi; in altri sono buone pratiche. Un assistente che attinge da tutte le fonti senza distinzione può mescolare questi contesti, anche senza volerlo, per esempio usando un documento di un cliente per rispondere su un altro. Gli accessi coerenti con il contesto operativo: lo stesso utente può avere bisogno di informazioni diverse a seconda di ciò che sta facendo. Un responsabile commerciale che prepara un'offerta ha bisogno del listino e dello storico del cliente; non ha bisogno, per quella attività, delle valutazioni del personale, anche se in altri momenti può vederle. Configurare un assistente per caso d'uso, e non per persona, aiuta a mantenere questa coerenza. Esempi fittizi.");
    infoTag(s, 3);
    await card(s, 0.5, 1.15, 4.35, 2.55, { icon: "FiColumns", head: "Separazione tra contesti", headSize: 14, bodySize: 12, body: bullets(["Clienti concorrenti seguiti da team diversi", "Gare e valutazioni di fornitori", "Società diverse di un gruppo", "Rischio: un documento di un cliente usato per un altro"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.55, { icon: "FiCrosshair", head: "Coerenza con il contesto", headSize: 14, bodySize: 12, fill: C.accent6, body: bullets(["Per preparare un'offerta: listino e storico del cliente", "Non, per quell'attività, le valutazioni del personale", "Configurare per caso d'uso, non solo per persona"], { space: 4 }) });
    banner(s, 3.95, "Un assistente che attinge da tutto senza distinzione può mescolare contesti, anche senza volerlo.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Tracciabilità ed equilibrio", "Gli ultimi punti del sottotema. L'importanza della tracciabilità degli accessi: sapere chi ha chiesto che cosa, quali fonti sono state recuperate, quali informazioni sono state mostrate. Serve per scoprire usi impropri, per ricostruire l'origine di una risposta sbagliata, per dimostrare che le regole sono state rispettate, per migliorare il sistema. La tracciabilità ha anche un costo, perché le registrazioni contengono a loro volta informazioni da proteggere: le domande degli utenti possono rivelare molto. Gli accessi agli archivi e ai sistemi integrati devono essere governati con la stessa attenzione dei sistemi stessi. E l'equilibrio tra accessibilità e protezione: troppa protezione rende l'assistente inutile, perché non trova le informazioni che servono e le persone tornano a cercare a mano, o peggio usano strumenti non autorizzati; troppa apertura espone informazioni e crea rischi. Non esiste una soluzione unica: l'equilibrio va trovato caso d'uso per caso d'uso, partendo da che cosa serve davvero. Il documento di perimetro chiede di introdurre questi aspetti senza approfondire la governance, che sarà trattata nei Temi 17 e 18.");
    infoTag(s, 3);
    rowsLabel(s, [["Chi ha chiesto", "Quale utente, quando, per quale scopo"], ["Che cosa è stato recuperato", "Quali fonti, quali brani"], ["Che cosa è stato mostrato", "Quali informazioni nella risposta"], ["Attenzione", "Anche le registrazioni contengono informazioni da proteggere"]], { y: 1.15, h: 0.48, lw: 2.6 });
    shapeBox(s, 0.5, 3.35, 4.35, 0.85, C.background2, "troppa protezione");
    txt(s, [{ text: "Troppa protezione: ", options: { bold: true, color: C.accent1 } }, { text: "l'assistente è inutile, si torna a cercare a mano o a strumenti non autorizzati.", options: { color: C.text1 } }], { x: 0.65, y: 3.35, w: 4.05, h: 0.85, fontSize: 12, valign: "middle" });
    shapeBox(s, 5.15, 3.35, 4.35, 0.85, C.accent6, "troppa apertura");
    txt(s, [{ text: "Troppa apertura: ", options: { bold: true, color: C.accent5 } }, { text: "informazioni esposte, rischi per persone e azienda.", options: { color: C.text1 } }], { x: 5.3, y: 3.35, w: 4.05, h: 0.85, fontSize: 12, valign: "middle" });
    txt(s, "L'equilibrio si trova caso d'uso per caso d'uso, partendo da che cosa serve davvero.", { x: 0.5, y: 4.35, w: 9, h: 0.5, fontSize: 13, bold: true, italic: true, color: C.accent1, align: "center" });
  }
  keySlide("L'AI non deve sapere tutto ciò che l'azienda sa. Deve poter consultare soltanto ciò che è pertinente e autorizzato per il caso d'uso.", "Sottotema 14.6  ·  Accessi, permessi e disponibilità delle informazioni  ·  Integrazione D", "Concetto chiave del sesto sottotema. Esistere non è essere autorizzati. Le informazioni hanno livelli di classificazione, pubbliche, interne, riservate, sensibili, che sono il presupposto delle regole di accesso. Ruoli e minimo privilegio valgono anche per l'AI. Conta con quali permessi l'assistente accede, quelli dell'utente o permessi propri, e va verificato. L'AI rende visibili le condivisioni eccessive; i contesti vanno separati; gli accessi vanno tracciati; l'equilibrio tra accessibilità e protezione si trova caso per caso. Esercizio suggerito: in piccoli gruppi, per un assistente fittizio sulle procedure del reparto, definire quali livelli di informazione può usare, con quali permessi accede, e quali domande di prova porre per verificare che non esponga informazioni riservate.");
  // =====================================================================
  section("14.7 Affidabilità delle risposte");
  divider("14.7", "Affidabilità delle risposte", "Le risposte possono essere errate anche quando i documenti di partenza sono accurati", "Uno dei sottotemi da approfondire, e il punto di arrivo della parte su utilizzo e controllo. Il documento di perimetro distingue con cura: il 14.2 riguarda la qualità delle fonti, il 14.7 la qualità della risposta generata. Vediamo la pertinenza di ciò che viene recuperato, le risposte basate su documenti insufficienti, le contraddizioni, la differenza tra informazione recuperata e interpretazione generata, i riferimenti alle fonti, le informazioni non recuperate, le risposte apparentemente fondate, e la verifica rispetto allo scopo. Lo scenario centrale del tema si colloca qui. Integrazione B. Il metodo generale di verifica è del Tema 7: qui ci concentriamo sui rischi specifici delle fonti aziendali.");
  {
    const s = content("Lo scenario: cinque modi di sbagliare", "Lo scenario indicato dal documento di perimetro come esempio didattico centrale del tema. Un assistente AI è collegato a un archivio di procedure aziendali approvate. Le fonti sono corrette e aggiornate: il problema della qualità visto nel 14.2 è risolto. Eppure l'assistente può sbagliare in almeno cinque modi. Uno: recuperare una procedura senza la relativa eccezione, che si trova in un altro paragrafo o in un documento collegato. Due: selezionare un documento destinato a un reparto diverso, con regole simili ma non uguali. Tre: interpretare impropriamente le informazioni recuperate, per esempio applicando una regola a un caso che non vi rientra. Quattro: non disporre di una condizione operativa decisiva, come la situazione specifica del cliente o una decisione non ancora scritta. Cinque: esporre informazioni non appropriate, se i permessi sono configurati male. Il messaggio chiave del tema: qualità delle fonti, efficacia del recupero, interpretazione e controllo degli accessi sono condizioni distinte. Collegare l'AI ai documenti aziendali non garantisce automaticamente risposte affidabili. Suggerimento: presentare lo scenario chiedendo ai partecipanti di immaginare, prima di mostrare l'elenco, che cosa potrebbe andare storto.");
    infoTag(s, 3);
    docBox(s, 0.5, 1.12, 9.0, 0.7, "Scenario", "Un assistente AI collegato a un archivio di procedure aziendali approvate, corrette e aggiornate.", { fontSize: 13, fill: C.accent6 });
    const f = [["Recupero", "La procedura senza l'eccezione"], ["Recupero", "Il documento di un altro reparto"], ["Interpretazione", "Una regola applicata al caso sbagliato"], ["Disponibilità", "Manca una condizione operativa decisiva"], ["Accessi", "Informazioni esposte per permessi errati"]];
    f.forEach((e, i) => {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.97, 1.7, 1.85, C.background2, "errore " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y: 2.02, w: 0.5, h: 0.45, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, e[0], { x: x + 0.12, y: 2.47, w: 1.5, h: 0.3, fontSize: 10, bold: true, color: C.accent5 });
      txt(s, e[1], { x: x + 0.12, y: 2.8, w: 1.5, h: 0.95, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.0, "Qualità delle fonti, recupero, interpretazione e accessi sono condizioni distinte. Collegare non garantisce risposte affidabili.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Pertinenza e completezza", "I primi punti del sottotema: la pertinenza delle informazioni recuperate e la qualità e completezza delle fonti rispetto alla domanda. Una risposta può basarsi su brani che parlano dell'argomento ma non rispondono alla domanda: si chiede il termine per i resi di prodotti personalizzati, e il sistema recupera la procedura generale sui resi, che non ne parla. Il modello, spinto a rispondere, applica la regola generale. Oppure le fonti sono pertinenti ma insufficienti: la procedura esiste, ma non copre il caso specifico, e la risposta colma il vuoto con un'ipotesi plausibile, senza segnalarlo. È il caso delle risposte basate su documenti insufficienti, uno dei rischi principali. Un assistente ben configurato dovrebbe dire 'le procedure disponibili non coprono questo caso', e le istruzioni viste nel 14.4 vanno in questa direzione; ma non sempre lo fa, perché i modelli tendono a produrre comunque una risposta. Per l'utente il segnale d'allarme è una risposta generica a una domanda specifica, o una risposta specifica senza un riferimento preciso alla fonte. Esempio fittizio.");
    infoTag(s, 3);
    docBox(s, 0.5, 1.15, 4.35, 1.3, "Domanda (esempio fittizio)", "Qual è il termine per il reso di un prodotto personalizzato?", { fontSize: 13 });
    docBox(s, 5.15, 1.15, 4.35, 1.3, "Brano recuperato", "Procedura generale resi: il cliente può restituire il prodotto entro 30 giorni.", { fontSize: 13, fill: C.accent6 });
    docBox(s, 0.5, 2.6, 9.0, 0.85, "Risposta", "Il termine è di 30 giorni.  Plausibile, ma la procedura non parla dei prodotti personalizzati.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Segnali d'allarme", { x: 0.5, y: 3.6, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    ["Risposta generica a una domanda specifica", "Risposta specifica senza riferimento preciso"].forEach((t, i) => chip(s, 0.5 + i * 4.6, 4.0, 4.4, 0.7, t, { fill: C.accent6, fontSize: 13 }));
  }
  {
    const s = content("Recuperato o interpretato?", "Una distinzione centrale del sottotema: la differenza tra informazione recuperata e interpretazione generata. Quando un assistente risponde basandosi sulle fonti, la risposta contiene due cose diverse, che all'utente appaiono fuse. Ciò che le fonti dicono, recuperato e riportato. E ciò che il modello ne deduce, sintetizza, applica al caso, collega: l'interpretazione. Per esempio: la procedura dice che i resi oltre i 500 euro richiedono l'approvazione del responsabile. Il cliente chiede di rendere tre articoli da 200 euro. L'assistente risponde che non serve approvazione, perché ogni articolo è sotto la soglia. È un'interpretazione: la procedura parla del valore del reso o del singolo articolo? La fonte non lo dice, il modello ha scelto. Può aver ragione o torto, ma ha presentato la sua interpretazione come se fosse scritta nella procedura. Il rischio è sottile: l'utente vede una risposta con un riferimento alla fonte corretta, e la ritiene fondata. Ma la fonte supporta solo una parte della risposta. Una buona pratica, quando la decisione conta, è distinguere: che cosa dice esattamente la fonte, e che cosa ne sto deducendo? Esempio fittizio.");
    infoTag(s, 3);
    docBox(s, 0.5, 1.15, 4.35, 1.35, "La procedura dice (fittizio)", "I resi oltre 500 € richiedono l'approvazione del responsabile.", { fontSize: 13, fill: C.accent6 });
    docBox(s, 5.15, 1.15, 4.35, 1.35, "Il caso", "Il cliente rende tre articoli da 200 € ciascuno.", { fontSize: 13 });
    docBox(s, 0.5, 2.65, 9.0, 0.95, "L'assistente risponde", "Non serve approvazione: ogni articolo è sotto la soglia.  Interpretazione: la soglia è per articolo o per reso? La fonte non lo dice.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    banner(s, 3.8, "La fonte citata supporta solo una parte della risposta. Che cosa dice esattamente, e che cosa ne viene dedotto?", { h: 0.95, fontSize: 14 });
  }
  {
    const s = content("Contraddizioni e assenze", "Altri due rischi specifici del sottotema. Le contraddizioni tra fonti: anche in un archivio curato possono esistere documenti che dicono cose diverse, per esempio una procedura generale e un'istruzione operativa di reparto, o un documento aggiornato e una FAQ non ancora allineata. Il modello può comportarsi in tre modi: scegliere una delle fonti senza dirlo, mescolarle in una risposta che non corrisponde a nessuna delle due, o segnalare la contraddizione. Solo il terzo è utile, e va chiesto esplicitamente nelle istruzioni. Le informazioni non disponibili o non recuperate: il caso più insidioso, perché non lascia traccia. Se l'informazione decisiva non è nella raccolta, o non viene recuperata, la risposta non mostra il vuoto: semplicemente non ne tiene conto. L'utente vede una risposta completa in apparenza, e non sa che cosa manca. È il quarto errore dello scenario: la condizione operativa decisiva che il sistema non ha. Per questo un assistente affidabile dovrebbe saper dire 'non ho trovato informazioni su questo', e l'utente dovrebbe chiedersi, per le questioni importanti: c'è qualcosa che la risposta potrebbe non sapere?");
    infoTag(s, 3);
    await card(s, 0.5, 1.15, 4.35, 2.6, { icon: "FiGitMerge", head: "Contraddizioni tra fonti", headSize: 14, bodySize: 12, body: bullets(["Sceglie una fonte senza dirlo", "Mescola, in una risposta che non corrisponde a nessuna", "Segnala la contraddizione: l'unico utile, da chiedere nelle istruzioni"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.6, { icon: "FiEyeOff", head: "Informazioni assenti", headSize: 14, bodySize: 12, fill: C.accent6, body: bullets(["Non nella raccolta, o non recuperate", "Il vuoto non si vede: la risposta sembra completa", "È il quarto errore dello scenario"], { space: 4 }) });
    banner(s, 3.95, "Per le questioni importanti: c'è qualcosa che la risposta potrebbe non sapere?", { h: 0.85, fontSize: 15 });
  }
  {
    const s = content("Citare le fonti", "Un elemento che il sottotema indica come decisivo: i riferimenti ai documenti e ai passaggi utilizzati. Molti assistenti aziendali indicano le fonti delle risposte, con il titolo del documento e spesso il brano usato. È uno strumento molto utile, per tre ragioni. Permette di verificare: l'utente può aprire il documento e controllare che dica davvero ciò che la risposta afferma. Permette di valutare la fonte: è la procedura ufficiale o una nota? È la versione attuale? È del reparto giusto? Rende visibile la differenza tra ciò che è scritto e ciò che è dedotto. Ma le citazioni hanno limiti che conviene conoscere. Una citazione non garantisce che la risposta corrisponda alla fonte: il modello può citare un documento e affermare qualcosa che il documento non dice, o dice in modo diverso. Le citazioni indicano che cosa è stato usato, non che cosa è stato trascurato. E una risposta con citazioni appare più autorevole, e questo può ridurre la propensione a verificare. Il suggerimento pratico: per le risposte che hanno conseguenze, aprire almeno la fonte citata e controllare il passaggio. Bastano pochi secondi.");
    infoTag(s, 3);
    await twoPanel(s, "A che cosa servono", bullets(["Verificare: la fonte dice davvero questo?", "Valutare: ufficiale, attuale, del reparto giusto?", "Distinguere lo scritto dal dedotto"], { space: 5 }), "I loro limiti", bullets(["Una citazione non garantisce la corrispondenza", "Mostrano ciò che è stato usato, non il trascurato", "Rendono la risposta più autorevole in apparenza"], { space: 5 }), { y: 1.15, h: 2.5, li: "FiBookmark", ri: "FiAlertTriangle" });
    banner(s, 3.9, "Per le risposte che hanno conseguenze: aprire la fonte citata e controllare il passaggio. Bastano pochi secondi.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Apparentemente fondate", "Il rischio che riassume il sottotema: le risposte apparentemente fondate. Una risposta generata da un assistente collegato alle fonti aziendali ha tutte le caratteristiche dell'affidabilità: usa il linguaggio dell'azienda, cita documenti interni, è precisa, ben scritta, sicura. Proprio per questo può essere più pericolosa di una risposta palesemente generica: è più difficile metterla in dubbio. Abbiamo visto i modi in cui può essere errata pur basandosi su fonti corrette: recupero non pertinente o incompleto, fonti insufficienti, interpretazione impropria, contraddizioni risolte in silenzio, informazioni mancanti, omissioni. È l'integrazione B: le risposte possono essere errate anche quando i documenti di partenza sono accurati. Il collegamento con il Tema 7 è diretto: là abbiamo visto che la fluidità non è affidabilità; qui aggiungiamo che anche il riferimento a fonti interne non lo è, da solo. Il grafico, con dati inventati a scopo illustrativo, mostra come si potrebbe scomporre la quota di risposte inadeguate in un'ipotetica verifica di un assistente: la maggior parte degli errori non dipende dalla qualità delle fonti, ma da ciò che accade dopo.");
    infoTag(s, 3);
    s.addChart(pres.charts.PIE, [{ name: "Cause", labels: ["Recupero non pertinente o incompleto", "Interpretazione impropria", "Informazione assente", "Fonte errata o superata", "Permessi"], values: [38, 24, 20, 12, 6] }], {
      x: 0.4, y: 1.05, w: 5.2, h: 3.5, chartColors: [HEX.a1, HEX.a4, HEX.a5, HEX.a2, HEX.a3], showPercent: true, showValue: false, dataLabelColor: "FFFFFF", dataLabelFontSize: 11, dataLabelFontFace: "+mn-lt",
      showLegend: true, legendPos: "r", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Cause di risposte inadeguate (dati inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt" });
    await card(s, 5.85, 1.15, 3.65, 1.65, { icon: "FiCheckCircle", inline: true, head: "Sembra affidabile", headSize: 13, bodySize: 12, body: "Linguaggio dell'azienda, fonti interne, precisione, sicurezza." });
    await card(s, 5.85, 2.95, 3.65, 1.6, { icon: "FiAlertCircle", inline: true, head: "Ma non basta (B)", headSize: 13, bodySize: 12, fill: C.accent6, body: "Il riferimento a fonti interne non è, da solo, affidabilità (Tema 7)." });
  }
  {
    const s = content("Adeguata allo scopo", "Gli ultimi punti del sottotema: la necessità di aggiornamento delle fonti, e la verifica dell'adeguatezza rispetto allo scopo. L'aggiornamento: un assistente affidabile oggi non lo sarà domani se le fonti invecchiano. Va previsto un controllo periodico, che sarà parte delle condizioni del 14.8. La verifica rispetto allo scopo è il criterio che tiene insieme tutto: non tutte le risposte richiedono lo stesso livello di controllo. Il principio di proporzionalità visto nel Tema 7 vale anche qui. Per orientarsi, per trovare un documento, per avere una prima idea, una risposta approssimativa può bastare, e la citazione permette di approfondire. Per applicare una regola a un cliente, per comunicare un'informazione all'esterno, per prendere una decisione con conseguenze economiche, la risposta va verificata sulla fonte, e nei casi dubbi con una persona competente. Per questioni legali, di sicurezza o che riguardano persone, l'assistente può aiutare a trovare le informazioni, ma la decisione richiede una verifica completa. La scala in slide propone tre livelli, da adattare al proprio contesto. Il messaggio di sintesi del documento di perimetro: un sistema collegato ai dati interni può recuperare o interpretare male le fonti, e richiede verifiche coerenti con l'uso previsto.");
    infoTag(s, 3);
    const lv = [["Orientarsi", "Trovare un documento, farsi una prima idea", "La citazione permette di approfondire", C.background2], ["Applicare", "Una regola a un cliente, un'informazione all'esterno, una decisione economica", "Verificare sulla fonte; nei dubbi, una persona competente", C.accent6], ["Decidere su temi critici", "Questioni legali, di sicurezza, che riguardano persone", "L'assistente aiuta a trovare; la verifica è completa", "D9ECEA"]];
    lv.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.85, e[3], e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.2, h: 0.85, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.9, y: y + 0.05, w: 6.4, h: 0.38, fontSize: 12, color: C.text1 });
      txt(s, e[2], { x: 2.9, y: y + 0.43, w: 6.4, h: 0.38, fontSize: 12, bold: true, color: C.text2 });
    });
    banner(s, 4.1, "Verifiche coerenti con l'uso previsto (Tema 7). E fonti da riesaminare nel tempo.", { h: 0.75, fontSize: 14 });
  }
  keySlide("Una fonte corretta non garantisce una risposta corretta: il recupero può fallire, l'interpretazione può sbagliare, e ciò che manca non si vede.", "Sottotema 14.7  ·  Affidabilità delle risposte basate sulla conoscenza aziendale  ·  Integrazione B", "Concetto chiave del settimo sottotema. Lo scenario centrale del tema mostra cinque modi di sbagliare con fonti corrette. Pertinenza e completezza delle fonti rispetto alla domanda, distinzione tra recuperato e interpretato, contraddizioni e assenze, citazioni utili ma non sufficienti: tutto concorre a risposte che possono essere apparentemente fondate. La verifica va proporzionata allo scopo. Esercizio suggerito: dato un documento fittizio di procedura e cinque risposte di un assistente, individuare per ciascuna che cosa è recuperato e che cosa è interpretato, e quale dei cinque errori dello scenario, se presente, si è verificato.");

  // =====================================================================
  section("14.8 Condizioni aziendali");
  divider("14.8", "Condizioni per valorizzare i dati", "L'efficacia non richiede accesso illimitato, bensì disponibilità mirata e controllata delle informazioni", "L'ultimo sottotema riassume il modulo dal punto di vista dell'organizzazione: quali condizioni informative, tecnologiche e organizzative servono perché l'AI possa usare bene le informazioni aziendali, e mantenerlo nel tempo. Il livello è la consapevolezza organizzativa. Il documento di perimetro distingue: il 14.2 riguarda la qualità dei contenuti, il 14.8 il quadro complessivo delle condizioni; il 14.6 le regole di accesso, il 14.8 il loro contributo all'utilizzabilità. Integrazione D. Non sviluppiamo criteri di selezione dei progetti, che sono del Tema 15, né piani di adozione, del Tema 16.");
  {
    const s = content("Tre famiglie di condizioni", "Il sottotema elenca molte condizioni, che conviene raggruppare in tre famiglie, come indica l'ottava domanda guida. Le condizioni informative: la disponibilità delle informazioni necessarie per il caso d'uso; la loro qualità e il loro aggiornamento; l'organizzazione della documentazione, cioè quanto è vicina a una base di conoscenza. Le condizioni tecnologiche: la compatibilità con gli strumenti esistenti; il livello di integrazione necessario, che può andare dai documenti allegati al collegamento con più applicazioni; la disponibilità selettiva delle informazioni, cioè la possibilità tecnica di applicare i permessi. Le condizioni organizzative: la responsabilità sulla gestione delle fonti; l'equilibrio tra accessibilità e protezione; la manutenzione e l'aggiornamento nel tempo; le competenze aziendali necessarie, non solo tecniche ma anche di chi conosce i contenuti e i processi. Le tre famiglie sono tutte necessarie. Un'azienda con un'ottima tecnologia e informazioni disordinate otterrà risposte disordinate; una con informazioni curate ma nessuno responsabile di mantenerle le vedrà degradare; una con tutto pronto ma permessi non governati si esporrà a rischi.");
    infoTag(s, 4);
    const f = [["FiFileText", "Informative", ["Informazioni necessarie disponibili", "Qualità e aggiornamento", "Documentazione organizzata"]], ["FiCpu", "Tecnologiche", ["Compatibilità con gli strumenti", "Livello di integrazione adatto", "Permessi applicabili"]], ["FiUsers", "Organizzative", ["Responsabili delle fonti", "Equilibrio accesso e protezione", "Manutenzione nel tempo", "Competenze su contenuti e processi"]]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.85, i === 2 ? C.accent6 : C.background2, f[i][1]);
      await iconCircle(s, x + 0.15, 1.27, 0.55, f[i][0]);
      txt(s, f[i][1], { x: x + 0.8, y: 1.27, w: 1.95, h: 0.55, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, bullets(f[i][2], { space: 5 }), { x: x + 0.15, y: 1.95, w: 2.6, h: 1.95, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.2, "Tutte necessarie: ottima tecnologia con informazioni disordinate dà risposte disordinate.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Prototipo o servizio", "Una distinzione del sottotema molto utile nella pratica: la differenza tra un prototipo documentale e un servizio operativo affidabile. Oggi costruire un prototipo di assistente sui documenti aziendali è relativamente facile: si caricano alcune decine di documenti in uno strumento, si scrivono le istruzioni, e in pochi giorni si ha qualcosa che risponde, spesso in modo impressionante. La dimostrazione funziona. Ma un servizio su cui le persone possano contare ogni giorno richiede molto di più. Fonti selezionate e curate, non un campione. Un responsabile per ogni fonte, e un processo di aggiornamento. Permessi coerenti con le regole aziendali, verificati. Integrazione con i sistemi necessari, che funzioni anche quando i sistemi cambiano. Verifiche periodiche della qualità delle risposte, con domande di prova. Un modo per gli utenti di segnalare risposte sbagliate, e qualcuno che se ne occupi. Tracciabilità. Formazione degli utenti. È la differenza, ben nota nell'informatica, tra far funzionare qualcosa una volta e farlo funzionare sempre. Molti progetti si fermano tra le due, perché il lavoro necessario per il secondo passo era stato sottostimato guardando il primo.");
    infoTag(s, 4);
    table(s, [["", "Prototipo documentale", "Servizio operativo affidabile"],
      ["Fonti", "Un campione caricato", "Selezionate, curate, con responsabili"],
      ["Aggiornamento", "Nessuno", "Un processo continuo"],
      ["Permessi", "Spesso ignorati", "Coerenti con le regole, verificati"],
      ["Qualità", "La dimostrazione funziona", "Verifiche periodiche, segnalazioni degli utenti"],
      ["Tempo", "Pochi giorni", "Lavoro continuo, spesso sottostimato"]],
      { y: 1.15, colW: [1.9, 3.3, 3.8], rowH: 0.47, accentCol: 2, fontSize: 12 });
    banner(s, 4.15, "Far funzionare qualcosa una volta non è farlo funzionare sempre.", { h: 0.7, fontSize: 15 });
  }
  {
    const s = content("Gli ostacoli principali", "Il sottotema chiede di riconoscere i principali ostacoli alla valorizzazione dei dati aziendali. Riprendendo il modulo, se ne possono indicare alcuni ricorrenti. Le informazioni disperse e frammentate, tra sistemi, reparti, caselle personali. La qualità insufficiente: duplicati, contraddizioni, obsolescenza, terminologie diverse. L'assenza di responsabilità sulle fonti. La conoscenza tacita non documentata, e il tempo limitato degli esperti per documentarla. I permessi non governati, con condivisioni eccessive mai corrette. Le integrazioni difficili con sistemi datati o poco aperti. Le competenze, sia tecniche sia di chi conosce i contenuti, spesso disponibili in poche persone. E l'aspettativa, molto diffusa, che l'AI risolva da sola problemi che sono di organizzazione delle informazioni. Un'osservazione utile: molti di questi ostacoli esistevano già prima dell'AI, e già limitavano il lavoro delle persone. L'AI non li crea, ma li rende più visibili e più costosi da ignorare. Per questo i progetti sull'AI aziendale diventano spesso, in pratica, occasioni per mettere ordine nel patrimonio informativo, con benefici che vanno oltre l'AI stessa.");
    infoTag(s, 4);
    await iconGrid(s, [
      { icon: "FiGrid", head: "Dispersione", body: "Tra sistemi, reparti, caselle personali" },
      { icon: "FiCopy", head: "Qualità", body: "Duplicati, contraddizioni, obsolescenza" },
      { icon: "FiUserX", head: "Nessun responsabile", body: "Fonti che nessuno mantiene" },
      { icon: "FiUsers", head: "Conoscenza tacita", body: "Non scritta, esperti senza tempo" },
      { icon: "FiUnlock", head: "Permessi non governati", body: "Condivisioni eccessive mai corrette" },
      { icon: "FiZap", head: "Aspettative", body: "Che l'AI risolva da sola problemi organizzativi" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Esistevano già. L'AI li rende più visibili, e più costosi da ignorare.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Partire dal caso d'uso", "L'ultimo punto del sottotema, e l'indicazione di metodo con cui si chiude il modulo: la necessità di valutare l'adeguatezza delle informazioni rispetto ai casi di utilizzo. Il patrimonio informativo non va valutato in astratto, 'abbiamo dati buoni o cattivi?', ma rispetto a un uso. Le stesse informazioni possono essere adeguate per un caso d'uso e inadeguate per un altro. Le procedure del magazzino possono essere ottime per un assistente rivolto agli addetti, insufficienti per uno rivolto ai clienti. Per ciascun caso d'uso, le domande sono quelle delle quattro condizioni dell'introduzione, più una. Disponibilità: le informazioni necessarie esistono? Accessibilità: il sistema può accedervi, con i permessi giusti? Utilizzabilità: sono organizzate e reperibili? Affidabilità: sono corrette e aggiornate per questo scopo? E infine: che cosa non è scritto, e come lo si gestisce? È anche l'integrazione D nella sua forma più costruttiva: l'efficacia non richiede accesso illimitato, ma disponibilità mirata e controllata. Partire da un caso d'uso circoscritto, con fonti curate e permessi chiari, è più efficace che collegare tutto. La valutazione dei casi d'uso, con criteri di priorità e business case, è il tema del modulo successivo.");
    infoTag(s, 4);
    numList(s, ["Disponibilità: le informazioni necessarie esistono?", "Accessibilità: il sistema può accedervi, con i permessi giusti?", "Utilizzabilità: sono organizzate e reperibili?", "Affidabilità: sono corrette e aggiornate per questo scopo?", "E che cosa non è scritto, e come lo si gestisce?"], { y: 1.15, h: 0.5, fontSize: 13 });
    banner(s, 4.15, "Non accesso illimitato, ma disponibilità mirata e controllata. Un caso d'uso circoscritto è meglio che collegare tutto (D).", { h: 0.8, fontSize: 13 });
  }
  keySlide("L'efficacia non richiede accesso illimitato, ma disponibilità mirata e controllata delle informazioni, curata nel tempo.", "Sottotema 14.8  ·  Condizioni organizzative e tecnologiche per valorizzare i dati aziendali  ·  Integrazione D", "Concetto chiave dell'ultimo sottotema. Le condizioni sono informative, tecnologiche e organizzative, tutte necessarie. Un prototipo che funziona non è un servizio affidabile: servono fonti curate, responsabili, permessi, verifiche, manutenzione. Gli ostacoli principali esistevano già prima dell'AI, che li rende visibili. Il patrimonio va valutato rispetto al caso d'uso, con le quattro condizioni e la domanda su ciò che non è scritto. Esercizio suggerito: scegliere un caso d'uso fittizio di assistente nel proprio ambito e compilare la checklist delle quattro condizioni, indicando per ciascuna lo stato attuale e che cosa servirebbe per passare da prototipo a servizio.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quali informazioni possiede un'azienda e dove: dati, informazioni, documenti e conoscenza, strutturati e non, distribuiti tra persone, reparti e applicazioni, e in parte taciti. Molti dati o dati utilizzabili: la quantità non è valore; contano pertinenza, qualità, reperibilità. Qualità, organizzazione, aggiornamento: l'AI ha accesso alle fonti, non alla realtà, e ne eredita i problemi, amplificandoli. Informazioni non apprese: vengono fornite al momento dell'uso, nella conversazione, con allegati o con il recupero da raccolte; recuperare non è modificare il modello. Archivi e gestionali: documenti e dati operativi sono diversi, sola lettura e modifica comportano rischi diversi. Permessi selettivi: perché l'AI non deve sapere tutto ciò che l'azienda sa, e perché rende visibili le condivisioni eccessive. Fonti corrette e risposte: recupero, interpretazione e ciò che manca possono far sbagliare anche con fonti accurate. Condizioni: informative, tecnologiche e organizzative, valutate rispetto al caso d'uso. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Quali informazioni, e dove?", "Dati, documenti, conoscenza; distribuiti; in parte taciti"], ["Molti dati o dati utilizzabili?", "Pertinenza, qualità, reperibilità, non quantità"], ["Qualità e aggiornamento?", "L'AI eredita i problemi delle fonti, e li amplifica"], ["Informazioni non apprese?", "Fornite al momento dell'uso; recuperare non è addestrare"], ["Archivi e gestionali?", "Documenti o dati operativi; leggere o modificare"], ["Perché permessi selettivi?", "L'AI non deve sapere tutto ciò che l'azienda sa"], ["Perché una fonte corretta non basta?", "Recupero, interpretazione, ciò che manca"], ["Quali condizioni?", "Informative, tecnologiche, organizzative, per caso d'uso"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.9;
      shapeBox(s, x, y, 4.4, 0.8, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.06, w: 3.8, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.34, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere dati, informazioni, documenti e conoscenza aziendale; comprendere l'importanza della qualità e dell'aggiornamento delle informazioni; riconoscere che possedere molti dati non equivale a poterli utilizzare; comprendere il ruolo dell'organizzazione e della reperibilità della conoscenza; distinguere la conoscenza del modello dalle informazioni aziendali rese disponibili durante l'uso; conoscere le principali modalità con cui l'AI può accedere a informazioni specifiche; comprendere la differenza tra recupero documentale e integrazione con applicazioni operative; riconoscere la necessità di permessi e controlli di accesso appropriati; comprendere perché una fonte corretta non garantisce una risposta corretta; riconoscere il valore e i limiti della conoscenza tacita; distinguere accessibilità completa e accessibilità selettiva; identificare le principali condizioni informative, tecnologiche e organizzative per usare efficacemente l'AI in azienda.");
    const r = ["Dati, informazioni, documenti, conoscenza", "Qualità e aggiornamento", "Molti dati non sono dati utilizzabili", "Organizzazione e reperibilità", "Conoscenza del modello e dell'azienda", "Modalità di accesso a informazioni specifiche", "Recupero documentale e applicazioni operative", "Permessi e controlli di accesso", "Fonte corretta, risposta non garantita", "Valore e limiti della conoscenza tacita", "Accessibilità completa o selettiva", "Condizioni informative, tecnologiche, organizzative"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Domande su un assistente aziendale", "Traduciamo il modulo in una scheda pratica: le domande da porsi quando si usa, si chiede o si valuta un assistente AI collegato alle informazioni aziendali. Fonti: quali fonti usa? Sono quelle ufficiali, curate, aggiornate? Chi ne è responsabile? Che cosa non è scritto da nessuna parte? Recupero: come trova le informazioni? Cita le fonti e i passaggi? Che cosa fa se non trova nulla, o trova fonti in contraddizione? Accessi: con quali permessi accede, quelli dell'utente o permessi propri? Solo lettura o anche modifica? Sono state verificate le condivisioni eccessive? Gli accessi sono tracciati? Risposte: la risposta distingue ciò che è scritto da ciò che è dedotto? Quanto conta questa risposta, e quanto la devo verificare? Ho aperto la fonte citata? Sono domande accessibili a chiunque, non solo ai tecnici, e chi le pone contribuisce in modo concreto alla qualità e alla sicurezza del sistema.");
    const f = [["Fonti", ["Ufficiali, curate, aggiornate?", "Chi ne è responsabile?", "Che cosa non è scritto?"], C.background2], ["Recupero", ["Cita fonti e passaggi?", "Se non trova nulla?", "Se le fonti si contraddicono?"], C.accent6], ["Accessi", ["Permessi dell'utente o propri?", "Lettura o modifica?", "Condivisioni verificate, accessi tracciati?"], C.background2], ["Risposte", ["Scritto o dedotto?", "Quanto conta, quanto verificare?", "Ho aperto la fonte?"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Domande accessibili a chiunque, non solo ai tecnici.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Che cosa evitare", "Per completezza, gli errori più comuni da evitare, che riassumono il modulo in negativo. Collegare tutto: dare all'AI accesso all'intero archivio, nella convinzione che più informazioni significhino risposte migliori. Confondere collegare con addestrare, e aspettarsi che il modello 'sappia' i documenti. Trascurare la qualità delle fonti, pensando che l'AI riconoscerà da sola il vecchio e il contraddittorio. Dimenticare chi aggiorna: costruire l'assistente senza un responsabile per le fonti. Ignorare i permessi, o non chiedere con quali permessi l'assistente accede. Fidarsi delle citazioni senza aprirle. Confondere il prototipo con il servizio. Dimenticare la conoscenza tacita, e smettere di chiedere alle persone. Sono errori comprensibili, perché la facilità con cui oggi si può collegare un assistente ai documenti fa sembrare semplice ciò che non lo è.");
    rowList(s, ["Collegare tutto, pensando che più informazioni diano risposte migliori", "Confondere collegare con addestrare", "Pensare che l'AI riconosca da sola il vecchio e il contraddittorio", "Costruire l'assistente senza responsabili delle fonti", "Ignorare con quali permessi l'assistente accede", "Fidarsi delle citazioni senza aprirle", "Confondere il prototipo con il servizio, e dimenticare la conoscenza tacita"], { y: 1.12, h: 0.47, gap: 0.07, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 14 abbiamo visto come il patrimonio informativo dell'azienda condizioni l'uso dell'AI: che cosa esiste, in che stato è, come è organizzato, come l'AI lo usa, con quali permessi e con quale affidabilità. Il tema successivo, il Tema 15, è dedicato all'individuazione e alla valutazione delle opportunità AI: come riconoscere dove l'AI può creare valore in un'organizzazione, come valutare i casi d'uso, con quali criteri scegliere e dare priorità. È il naturale sviluppo dei temi di quest'area: il valore del Tema 12, la trasformazione del lavoro del Tema 13, le condizioni informative del Tema 14 diventano criteri per valutare le opportunità. La domanda con cui abbiamo chiuso, 'le informazioni sono adeguate per questo caso d'uso?', sarà uno di quei criteri. Seguirà il Tema 16, sull'adozione e il cambiamento organizzativo. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Temi 12 e 13; Tema 14: dati e conoscenza (completato)", { x: 0.75, y: 4.07, w: 3.9, h: 0.55, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 15: Individuazione e valutazione delle opportunità AI", { x: 5.4, y: 1.72, w: 3.9, h: 0.85, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Dove l'AI crea valore, come valutare e scegliere i casi d'uso", { x: 5.4, y: 2.6, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.2, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 16: adozione e cambiamento organizzativo", "Temi 17 e 18: utilizzo responsabile"], { space: 5 }), { x: 5.4, y: 3.55, w: 3.9, h: 1.2, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Le tecnologie di recupero e di integrazione evolvono rapidamente, così come le funzioni di gestione dei permessi negli strumenti aziendali: è consigliabile verificare lo stato dell'arte prima di ogni edizione, senza però spostare il modulo sui dettagli tecnici, come chiede il documento di perimetro. La classificazione in quattro livelli delle informazioni è una convenzione diffusa, con nomi e dettagli che variano tra organizzazioni e standard; conviene adattarla a quella eventualmente in uso nell'azienda. Gli esempi aziendali e i numeri del modulo sono fittizi, tranne lo scenario dell'assistente sulle procedure, tratto dal documento di perimetro.");
    const src = [
      "Polanyi, M. (1966). The Tacit Dimension. University of Chicago Press.",
      "Nonaka, I., Takeuchi, H. (1995). The Knowledge-Creating Company. Oxford University Press.",
      "Lewis, P. et al. (2020). Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS 2020.",
      "Liu, N. F. et al. (2024). Lost in the Middle: How Language Models Use Long Contexts. Transactions of the ACL, 12.",
      "Saltzer, J. H., Schroeder, M. D. (1975). The Protection of Information in Computer Systems. Proceedings of the IEEE, 63(9).",
      "Gli esempi aziendali e i numeri delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 8 }), { x: 1.3, y: 1.15, w: 8.2, h: 3.6, fontSize: 12, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema14_AI_dati_conoscenza_aziendale.pptx" });
  await applyTheme("Tema14_AI_dati_conoscenza_aziendale.pptx", THEME);
  console.log("done");
})();
