  // =====================================================================
  section("15.7 Confronto e priorità");
  divider("15.7", "Confronto e priorità", "Prioritizzare aiuta a decidere che cosa approfondire; non dimostra la convenienza di un investimento", "Settimo sottotema, da comprendere e sperimentare. Abbiamo più opportunità, ciascuna descritta e valutata: come confrontarle? Vediamo la differenza tra individuazione e selezione, i criteri espliciti di confronto, la matrice valore-fattibilità, quick win e opportunità strategiche, i limiti dei punteggi, e la differenza tra priorità di approfondimento e decisione di investimento. Integrazioni B e C. La gestione di portafogli progetti va solo accennata.");
  {
    const s = content("Individuare non è selezionare", "La prima distinzione del sottotema: individuazione e selezione sono attività diverse, con regole diverse. L'individuazione cerca di raccogliere molte opportunità, senza giudicarle troppo presto: è una fase aperta, in cui conviene coinvolgere molte persone, perché chi fa il lavoro vede problemi che altri non vedono. Un errore comune è scartare subito le idee che sembrano poco ambiziose, o, al contrario, inseguire solo quelle più visibili. La selezione, invece, sceglie tra le opportunità individuate quelle che meritano di essere approfondite, con criteri espliciti. È una fase chiusa, che richiede di rinunciare a qualcosa: non si possono approfondire tutte le idee, perché le risorse sono limitate. Mescolare le due fasi produce problemi in entrambe le direzioni: se si seleziona mentre si individua, si perdono idee; se non si seleziona mai, si disperdono le risorse su troppe iniziative, nessuna delle quali viene portata a termine. La settima domanda guida chiede come confrontare opportunità diverse senza attribuire eccessiva certezza ai punteggi: vediamo prima i criteri, poi gli strumenti, poi i loro limiti.");
    stepTag(s, 3);
    await twoPanel(s, "Individuare", bullets(["Fase aperta: raccogliere molte opportunità", "Coinvolgere chi fa il lavoro", "Non scartare troppo presto le idee modeste"], { space: 5 }), "Selezionare", bullets(["Fase chiusa: scegliere che cosa approfondire", "Criteri espliciti", "Rinunciare a qualcosa: le risorse sono limitate"], { space: 5 }), { y: 1.15, h: 2.5, li: "FiSearch", ri: "FiFilter" });
    banner(s, 3.85, "Selezionare mentre si individua fa perdere idee; non selezionare mai disperde le risorse.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Criteri espliciti", "Il sottotema chiede criteri di confronto espliciti, e ne elenca diversi, che riprendono il percorso del modulo. Valore potenziale, dal 15.4. Fattibilità e complessità, dal 15.5. Desiderabilità per utenti e organizzazione. Sostenibilità economica e operativa. Rischi e criticità, dal 15.6. Prontezza organizzativa: l'area interessata è pronta, ha le persone, l'interesse, il tempo? Dipendenze e prerequisiti: il caso d'uso richiede che prima sia fatto qualcos'altro, come mettere ordine nei dati o completare un'integrazione? Rendere espliciti i criteri ha un valore in sé, anche prima di usarli: costringe a dichiarare che cosa conta, permette a persone diverse di discutere sulle stesse basi, rende la scelta comprensibile a chi non ha partecipato. Il contrario, la scelta basata su impressioni o sull'entusiasmo di chi presenta meglio, è più rapido ma meno affidabile. E ricordiamo la seconda precisazione del tema: le condizioni non negoziabili, cioè le condizioni di esclusione del 15.6, vanno considerate separatamente dal punteggio. Prima si escludono i casi che non le rispettano, poi si confrontano gli altri.");
    stepTag(s, 3);
    const c = ["Valore potenziale", "Fattibilità e complessità", "Desiderabilità", "Sostenibilità", "Rischi e criticità", "Prontezza organizzativa", "Dipendenze e prerequisiti"];
    c.forEach((t, i) => chip(s, 0.5 + (i % 4) * 2.3, 1.15 + Math.floor(i / 4) * 0.75, 2.15, 0.62, t, { fill: i < 5 ? C.accent6 : C.background2, fontSize: 12 }));
    shapeBox(s, 0.5, 2.75, 9.0, 0.9, C.accent1, "prima le soglie");
    txt(s, [{ text: "Prima le soglie, poi il punteggio. ", options: { bold: true, color: C.background1 } }, { text: "Le condizioni di esclusione del 15.6 si verificano separatamente: chi non le rispetta non entra nel confronto.", options: { color: C.background1 } }], { x: 0.7, y: 2.75, w: 8.6, h: 0.9, fontSize: 13, valign: "middle" });
    banner(s, 3.85, "Criteri espliciti: dichiarare che cosa conta, discutere sulle stesse basi, rendere la scelta comprensibile.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("La matrice valore-fattibilità", "Uno strumento molto diffuso, che il sottotema chiede di introdurre: la matrice valore-fattibilità. Si collocano le opportunità su due assi: il valore potenziale, in verticale, e la fattibilità, in orizzontale. Si ottengono quattro quadranti. In alto a destra, valore alto e fattibilità alta: le opportunità da approfondire per prime, spesso chiamate quick win, vittorie rapide. In alto a sinistra, valore alto e fattibilità bassa: le opportunità strategiche, che richiedono investimenti e preparazione, come mettere ordine nei dati, ma possono valere molto. In basso a destra, valore basso e fattibilità alta: miglioramenti facili ma modesti, da considerare se costano poco. In basso a sinistra, valore basso e fattibilità bassa: da accantonare. Le tre opportunità dello scenario, con valutazioni illustrative: la sintesi delle richieste ha fattibilità alta e valore medio; le bozze di risposta valore e fattibilità medio-alti; la gestione autonoma delle trattative valore potenziale alto ma fattibilità bassa, e, ricordiamolo, problemi di rischio che andrebbero risolti prima ancora di collocarla. La dimensione dei cerchi può rappresentare un terzo criterio, come il rischio. Valutazioni illustrative.");
    stepTag(s, 3);
    const X = 0.9, Y = 1.1, W = 4.8, H = 3.4;
    shapeBox(s, X, Y, W / 2, H / 2, C.accent6, "strategiche");
    shapeBox(s, X + W / 2, Y, W / 2, H / 2, "D9ECEA", "quick win");
    shapeBox(s, X, Y + H / 2, W / 2, H / 2, C.background2, "accantonare");
    shapeBox(s, X + W / 2, Y + H / 2, W / 2, H / 2, C.background2, "facili e modeste");
    txt(s, "Strategiche", { x: X + 0.08, y: Y + 0.05, w: 2.2, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
    txt(s, "Quick win", { x: X + W / 2 + 0.08, y: Y + 0.05, w: 2.2, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
    txt(s, "Da accantonare", { x: X + 0.08, y: Y + H - 0.35, w: 2.2, h: 0.3, fontSize: 11, bold: true, color: C.text2 });
    txt(s, "Facili ma modeste", { x: X + W / 2 + 0.08, y: Y + H - 0.35, w: 2.2, h: 0.3, fontSize: 11, bold: true, color: C.text2 });
    txt(s, "Valore", { x: 0.3, y: Y + H / 2 - 0.15, w: 0.6, h: 0.3, fontSize: 11, bold: true, color: C.text1, rotate: 270, align: "center" });
    txt(s, "Fattibilità", { x: X, y: Y + H + 0.02, w: W, h: 0.28, fontSize: 11, bold: true, color: C.text1, align: "center" });
    const pts = [["Sintesi", 0.82, 0.55, 0.42], ["Bozze", 0.66, 0.7, 0.55], ["Trattative", 0.28, 0.78, 0.6]];
    pts.forEach(p => {
      const cx = X + p[1] * W, cy = Y + (1 - p[2]) * H, d = p[3];
      s.addShape(pres.shapes.OVAL, { x: cx - d / 2, y: cy - d / 2, w: d, h: d, fill: { color: p[0] === "Trattative" ? HEX.a5 : HEX.a1 }, line: { color: "FFFFFF", width: 1.5 }, objectName: "punto " + p[0] });
      txt(s, p[0], { x: cx - 0.7, y: cy + d / 2, w: 1.4, h: 0.26, fontSize: 10, bold: true, color: C.text1, align: "center" });
    });
    await card(s, 6.0, 1.15, 3.5, 1.65, { icon: "FiCircle", inline: true, head: "Un terzo criterio", headSize: 13, bodySize: 12, body: "La dimensione dei cerchi: qui, il rischio." });
    await card(s, 6.0, 2.95, 3.5, 1.55, { icon: "FiAlertTriangle", inline: true, head: "Le soglie prima", headSize: 13, bodySize: 12, fill: C.accent6, body: "Le trattative autonome hanno rischi da risolvere prima di collocarle." });
    txt(s, "Valutazioni illustrative", { x: 6.0, y: 4.6, w: 3.5, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Quick win e strategiche", "Il sottotema introduce la distinzione tra quick win e opportunità strategiche, e conviene vederne pregi e trappole. Le quick win, ad alto valore e alta fattibilità, sono attraenti per buone ragioni: producono risultati in poco tempo, costano poco, permettono di imparare, creano fiducia e competenze. Molte organizzazioni fanno bene a partire da lì. Ma hanno trappole. Possono essere troppo piccole per contare, se il valore è stato sovrastimato. Possono esaurirsi: dopo le prime, le altre opportunità sono più difficili. E possono distrarre dai problemi più importanti, che raramente sono facili. Le opportunità strategiche, ad alto valore ma bassa fattibilità, richiedono investimenti e tempo, spesso in prerequisiti come i dati, le integrazioni o le competenze. Sono più rischiose, ma possono essere quelle che cambiano davvero il modo di lavorare. Una strategia equilibrata combina le due: alcune quick win per imparare e produrre risultati, e un piccolo numero di opportunità strategiche su cui preparare le condizioni. Le decisioni su portafogli di progetti vanno oltre questo modulo: qui basta riconoscere che le due categorie hanno funzioni diverse.");
    stepTag(s, 3);
    await card(s, 0.5, 1.15, 4.35, 2.75, { icon: "FiZap", head: "Quick win", headSize: 15, bodySize: 12, body: "Pregi: risultati rapidi, costi bassi, apprendimento, fiducia.\n\nTrappole: troppo piccole, si esauriscono, distraggono dai problemi importanti." });
    await card(s, 5.15, 1.15, 4.35, 2.75, { icon: "FiFlag", head: "Strategiche", headSize: 15, bodySize: 12, fill: C.accent6, body: "Pregi: possono cambiare davvero il modo di lavorare.\n\nAttenzioni: investimenti e tempo, prerequisiti (dati, integrazioni, competenze), più rischio." });
    banner(s, 4.1, "Combinare: alcune quick win per imparare, poche strategiche su cui preparare le condizioni.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("I limiti dei punteggi", "Il punto più delicato del sottotema, e la terza precisazione del tema: una matrice di opportunità è un ausilio alla discussione, non una prova oggettiva di convenienza. Molte organizzazioni usano punteggi: ogni criterio riceve un voto da 1 a 5, i voti vengono pesati e sommati, e le opportunità vengono ordinate. Lo strumento è utile, ma ha limiti seri, che conviene conoscere. I voti sono giudizi, spesso di poche persone, con le loro preferenze. Le differenze tra un 3 e un 4 sono spesso arbitrarie. I pesi sono scelte, e cambiarli cambia la classifica. La somma tratta come compensabili criteri che forse non lo sono. E soprattutto, il risultato numerico appare preciso e oggettivo, molto più di quanto sia: un 3,7 contro un 3,5 sembra una differenza, ma è dentro il margine di incertezza dei giudizi. Il grafico mostra, con dati inventati, tre opportunità valutate con due sistemi di pesi diversi, entrambi ragionevoli: la classifica si inverte. È l'integrazione B in versione quantitativa: un sistema di pesi che premia l'ambizione tecnica favorirà le opportunità spettacolari. L'uso corretto del punteggio è come base per la discussione: dove i voti divergono, dove la classifica è sensibile ai pesi, lì serve più informazione.");
    stepTag(s, 3);
    s.addChart(pres.charts.BAR, [
      { name: "Pesi A: valore al 50%", labels: ["Sintesi", "Bozze", "Trattative"], values: [3.5, 3.7, 3.6] },
      { name: "Pesi B: rischio e fattibilità al 60%", labels: ["Sintesi", "Bozze", "Trattative"], values: [3.9, 3.6, 2.4] },
    ], { x: 0.5, y: 1.05, w: 5.4, h: 2.8, barDir: "col", barGrouping: "clustered", chartColors: [HEX.a4, HEX.a1],
      showValue: true, dataLabelColor: HEX.dk1, dataLabelFontSize: 11, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0.0", dataLabelPosition: "outEnd",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 4.5, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Punteggio pesato, due sistemi di pesi (dati inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50 });
    txt(s, bullets(["Voti: giudizi di poche persone", "3 o 4: spesso arbitrario", "Pesi: scelte che cambiano la classifica", "Somma: rende compensabile ciò che forse non lo è", "Precisione apparente: 3,7 contro 3,5"], { space: 5 }), { x: 6.15, y: 1.15, w: 3.35, h: 2.6, fontSize: 12, color: C.text1 });
    banner(s, 3.9, "Un ausilio alla discussione, non una prova. Dove i voti divergono, serve più informazione.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Approfondire o investire?", "L'ultima distinzione del sottotema, e la sua consapevolezza: la differenza tra priorità di approfondimento e decisione di investimento. Prioritizzare aiuta a decidere che cosa approfondire; non equivale a dimostrare la convenienza di un investimento. In pratica: il fatto che un'opportunità sia in cima alla lista significa che merita di essere esaminata meglio, con più informazioni e, quando serve, con una verifica, come vedremo nel 15.8. Non significa che sia stato dimostrato che conviene, né che sia pronta per essere realizzata su larga scala. Questa distinzione protegge da un errore frequente: trasformare una valutazione preliminare, fatta con stime e giudizi, in una decisione di investimento importante. La scala in slide mostra tre livelli di decisione, ciascuno con il tipo di evidenza che richiede. Decidere che cosa esplorare richiede una valutazione preliminare, come quella di questo modulo. Decidere che cosa sperimentare richiede ipotesi chiare e criteri di valutazione. Decidere che cosa realizzare su larga scala richiede evidenze dalla sperimentazione, e un business case, che va oltre questo modulo. Più la decisione è impegnativa, più forti devono essere le evidenze.");
    stepTag(s, 3);
    const lv = [["Che cosa esplorare", "Valutazione preliminare: descrizione, profilo, matrice", C.background2], ["Che cosa sperimentare", "Ipotesi chiare, criteri di successo e insuccesso (15.8)", C.accent6], ["Che cosa realizzare su larga scala", "Evidenze dalla sperimentazione, business case (oltre il modulo)", "D9ECEA"]];
    lv.forEach((e, i) => {
      const y = 1.15 + (2 - i) * 0.95, w = 5.0 + i * 2.0;
      shapeBox(s, 0.5, y, w, 0.85, e[2], e[0]);
      txt(s, e[0], { x: 0.7, y: y + 0.04, w: w - 0.4, h: 0.38, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 0.7, y: y + 0.42, w: w - 0.4, h: 0.38, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.1, "Più la decisione è impegnativa, più forti devono essere le evidenze. In cima alla lista non significa conveniente.", { h: 0.8, fontSize: 14 });
  }
  keySlide("Prioritizzare aiuta a decidere che cosa approfondire; non dimostra la convenienza di un investimento. E le condizioni non negoziabili stanno fuori dal punteggio.", "Sottotema 15.7  ·  Confronto e priorità", "Concetto chiave del settimo sottotema. Individuare e selezionare sono fasi diverse. I criteri vanno resi espliciti, e le soglie verificate prima del punteggio. La matrice valore-fattibilità distingue quick win, strategiche, facili ma modeste e da accantonare. Quick win e strategiche hanno funzioni diverse. I punteggi hanno limiti seri: sono un ausilio alla discussione. Esercizio suggerito: in piccoli gruppi, collocare le idee raccolte all'inizio sulla matrice, ciascuno da solo, poi confrontare le posizioni e discutere quelle più distanti, individuando quale informazione servirebbe per decidere.");

  // =====================================================================
  section("15.8 Dall'idea alla verifica");
  divider("15.8", "Dall'idea alla verifica", "Lo scopo di un test è imparare, non dimostrare a ogni costo che l'idea iniziale è valida", "L'ultimo sottotema, da comprendere, chiude il percorso: verificare. L'opportunità selezionata si basa su ipotesi: come trasformarle in evidenze? Vediamo la differenza tra ipotesi e risultato dimostrato, le assunzioni critiche, le ipotesi verificabili, le verifiche preliminari, i prototipi e le sperimentazioni circoscritte, i criteri di successo e di insuccesso, il confronto con la situazione iniziale, la ricerca di evidenze contrarie e la decisione finale. Integrazione D: la sperimentazione deve poter smentire l'idea iniziale. Il confine con il Tema 16: qui i prototipi servono a verificare un'ipotesi, non a gestire l'adozione.");
  {
    const s = content("Ipotesi o risultato", "La prima distinzione del sottotema: un'ipotesi non è un risultato dimostrato. Tutto ciò che abbiamo prodotto finora, descrizione, profilo, stima del valore, valutazione di fattibilità e rischi, collocazione nella matrice, è fatto di ipotesi, più o meno fondate. Sono ipotesi ragionate, ed è giusto usarle per decidere che cosa approfondire. Ma non sono evidenze. La differenza diventa importante quando le ipotesi vengono presentate come fatti: 'il sistema ridurrà i tempi del 40 per cento' invece di 'stimiamo che potrebbe ridurre i tempi, in un intervallo tra il 10 e il 40 per cento, se le bozze richiedono solo una revisione rapida'. La prima frase è più convincente, la seconda è più onesta e più utile, perché dice che cosa va verificato. Il sottotema distingue anche tre livelli: l'ipotesi, cioè ciò che crediamo; la dimostrazione tecnica, cioè che il sistema può produrre un output adeguato in alcune condizioni; e il risultato verificato, cioè che il caso d'uso produce il beneficio atteso nel lavoro reale. Li riprendiamo alla fine del sottotema. Esempi fittizi.");
    stepTag(s, 4);
    docBox(s, 0.5, 1.15, 4.35, 1.5, "Ipotesi presentata come fatto", "'Il sistema ridurrà i tempi del 40%.'", { fontSize: 14, bar: C.accent5, labelColor: C.accent5 });
    docBox(s, 5.15, 1.15, 4.35, 1.5, "Ipotesi presentata come ipotesi", "'Stimiamo tra il 10 e il 40%, se le bozze richiedono solo una revisione rapida.'", { fontSize: 14, fill: C.accent6 });
    const l = ["Ipotesi: ciò che crediamo", "Dimostrazione tecnica: l'output è adeguato, in alcune condizioni", "Risultato verificato: il beneficio c'è, nel lavoro reale"];
    l.forEach((t, i) => {
      chip(s, 0.5 + i * 3.07, 2.9, 2.86, 0.85, t, { fill: i === 2 ? C.accent1 : C.background2, color: i === 2 ? C.background1 : C.text1, fontSize: 12 });
      if (i < 2) arrow(s, 0.5 + i * 3.07 + 2.88, 3.17, 0.17);
    });
    banner(s, 3.95, "La seconda frase è meno convincente, ma più onesta e più utile: dice che cosa va verificato.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Assunzioni critiche", "Il sottotema chiede di identificare le assunzioni critiche e formulare ipotesi verificabili. Riprendiamo le ipotesi individuate nel 15.2 e nel 15.5, e chiediamoci quali sono critiche. Un modo semplice per farlo è valutare ciascuna ipotesi su due dimensioni: quanto è importante, cioè quanto cambierebbe la valutazione se fosse falsa; e quanto è incerta, cioè quanto poco ne sappiamo. Le assunzioni da verificare per prime sono quelle importanti e incerte. Un'ipotesi importante ma già nota non richiede una verifica; un'ipotesi incerta ma poco importante può aspettare. Poi bisogna rendere le ipotesi verificabili, cioè formularle in modo che un'osservazione possa confermarle o smentirle. 'Le bozze saranno utili' non è verificabile. 'Su 100 richieste reali, almeno 70 bozze richiedono meno di 3 minuti di revisione per essere inviate' è verificabile. Questo richiede di decidere in anticipo che cosa osservare e quale soglia considerare sufficiente. Nell'esempio fittizio, la tabella mostra alcune ipotesi delle bozze di risposta, con la loro importanza e incertezza.");
    stepTag(s, 4);
    table(s, [["Ipotesi (esempio fittizio)", "Importanza", "Incertezza", "Verificare?"],
      ["La scrittura è una parte rilevante del tempo", "Alta", "Media", "Sì, per prima"],
      ["Le bozze richiedono solo una revisione rapida", "Alta", "Alta", "Sì, per prima"],
      ["Il listino è aggiornato e accessibile", "Alta", "Bassa", "Controllo rapido"],
      ["I commerciali useranno le bozze", "Alta", "Alta", "Sì"],
      ["Lo stile delle bozze piacerà", "Bassa", "Alta", "Può aspettare"]],
      { y: 1.15, colW: [4.2, 1.5, 1.5, 1.8], rowH: 0.44, accentCol: 3, fontSize: 12, blankCorner: false });
    docBox(s, 0.5, 3.95, 9.0, 0.95, "Ipotesi verificabile", "Su 100 richieste reali, almeno 70 bozze richiedono meno di 3 minuti di revisione prima dell'invio.", { fontSize: 13, fill: C.accent6 });
  }
  {
    const s = content("Verifiche e sperimentazioni", "Il sottotema elenca diversi modi di verificare, dal più leggero al più impegnativo. Le verifiche preliminari di fattibilità: controlli rapidi, che spesso non richiedono nessuno strumento. Il listino è davvero in un unico posto? Quanto tempo richiede oggi scrivere una risposta, misurato su qualche giorno di lavoro? Quante richieste riguardano prodotti personalizzati? Molte ipotesi si possono verificare, o smentire, in questo modo, con pochissimo costo. I prototipi: una versione semplificata del sistema, per verificare se l'output è adeguato. Per esempio, prendere 50 richieste reali dell'ultimo mese, generare le bozze con uno strumento generico configurato con il listino, e farle valutare a due commerciali. Le sperimentazioni circoscritte: l'uso del sistema nel lavoro reale, ma in un perimetro limitato, per un periodo limitato, con alcuni utenti. Per esempio, tre commerciali per quattro settimane. È il solo modo per verificare le ipotesi sull'uso effettivo e sul beneficio nel lavoro reale. Il principio: usare la verifica più leggera che può rispondere alla domanda. La progettazione tecnica dei prototipi e la sperimentazione statistica specialistica vanno solo accennate. Esempi fittizi.");
    stepTag(s, 4);
    const v = [["FiSearch", "Verifiche preliminari", "Controlli rapidi, spesso senza strumenti", "Dov'è il listino? Quanto tempo richiede oggi una risposta?"], ["FiBox", "Prototipo", "Una versione semplificata, per l'output", "50 richieste reali dell'ultimo mese, bozze valutate da due commerciali"], ["FiUsers", "Sperimentazione circoscritta", "Nel lavoro reale, perimetro e tempi limitati", "Tre commerciali per quattro settimane"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.75, i === 2 ? C.accent6 : C.background2, v[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.62, v[i][0]);
      txt(s, v[i][1], { x: x + 0.15, y: 1.95, w: 2.56, h: 0.4, fontSize: 14, bold: true, color: C.text1, align: "center" });
      txt(s, v[i][2], { x: x + 0.15, y: 2.35, w: 2.56, h: 0.55, fontSize: 12, bold: true, color: C.accent1, align: "center" });
      txt(s, v[i][3], { x: x + 0.15, y: 2.92, w: 2.56, h: 0.9, fontSize: 11, italic: true, color: C.text2, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.35, 0.17);
    }
    banner(s, 4.1, "Usare la verifica più leggera che può rispondere alla domanda. Esempi fittizi.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Successo e insuccesso, prima", "Il cuore del sottotema, e l'integrazione D: la definizione preventiva di criteri di successo e di insuccesso. Il documento sottolinea 'e insuccesso', e la ragione è precisa. Prima di iniziare una verifica, bisogna decidere che cosa la renderà un successo, e che cosa un insuccesso. Prima, non dopo. Se i criteri vengono decisi dopo aver visto i risultati, è quasi sempre possibile trovare un modo di presentarli come positivi: 'i tempi non sono scesi, ma i commerciali sono soddisfatti'; 'la qualità non è sufficiente, ma con qualche miglioramento lo sarà'. È un meccanismo umano ben noto, che la psicologia descrive come bias di conferma: tendiamo a cercare e a valorizzare le informazioni che confermano ciò che già crediamo. Definire in anticipo i criteri, e scriverli, protegge da questo meccanismo. Un buon insieme di criteri comprende: una soglia di successo, oltre la quale si prosegue; una soglia di insuccesso, sotto la quale ci si ferma; una zona intermedia, in cui si modifica e si riprova; e i limiti da non superare, come gli errori sulle condizioni. L'esempio in slide, fittizio, mostra criteri per la sperimentazione delle bozze.");
    stepTag(s, 4);
    rowsLabel(s, [["Successo: si prosegue", "Almeno 70% delle bozze inviate con meno di 3 minuti di revisione; tempo di risposta medio sotto 1,5 giorni"], ["Zona intermedia: si modifica", "Tra 40% e 70%; tempo tra 1,5 e 2,5 giorni"], ["Insuccesso: ci si ferma", "Meno del 40%, o nessun miglioramento dei tempi"], ["Limite da non superare", "Anche un solo errore sulle condizioni inviato a un cliente"]], { y: 1.15, h: 0.62, lw: 2.6, fontSize: 12 });
    banner(s, 3.85, "Decisi prima, e scritti. Dopo, si trova quasi sempre un modo di presentare i risultati come positivi (bias di conferma). Esempio fittizio.", { h: 1.0, fontSize: 13 });
  }
  {
    const s = content("Il confronto giusto", "Il sottotema chiede di confrontare i risultati con la situazione iniziale e, quando utile, con alternative non AI. Sembra ovvio, ma è spesso trascurato. Un risultato da solo non dice molto: 'con le bozze, una risposta richiede in media 12 minuti'. È tanto o poco? Dipende da quanto richiedeva prima. Per questo serve una misura della situazione iniziale, raccolta prima della sperimentazione e con lo stesso metodo: è la baseline. Senza di essa, qualsiasi risultato può sembrare buono. Il confronto con alternative non AI è il ritorno dell'integrazione A: se la sperimentazione mostra un miglioramento, conviene chiedersi se un'alternativa più semplice, come i modelli di risposta predefiniti, avrebbe ottenuto lo stesso risultato. A volte una parte del miglioramento viene semplicemente dall'attenzione al problema: il fatto stesso di sperimentare porta le persone a lavorare meglio, un fenomeno noto in letteratura come effetto Hawthorne, anche se le interpretazioni degli studi originali sono discusse. Il grafico mostra, con dati inventati, un confronto con tre condizioni: prima, con i modelli predefiniti, con le bozze AI.");
    stepTag(s, 4);
    s.addChart(pres.charts.BAR, [{ name: "Minuti", labels: ["Prima (baseline)", "Modelli predefiniti", "Bozze AI"], values: [18, 14, 11] }], {
      x: 0.5, y: 1.05, w: 5.2, h: 3.35, barDir: "col", chartColors: [HEX.a1], showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 21, valGridLine: { style: "none" }, showLegend: false,
      showTitle: true, title: "Minuti per risposta, media (dati inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 60 });
    await card(s, 5.95, 1.15, 3.55, 1.6, { icon: "FiBarChart", inline: true, head: "La baseline", headSize: 13, bodySize: 12, body: "Misurata prima, con lo stesso metodo." });
    await card(s, 5.95, 2.9, 3.55, 1.6, { icon: "FiGitPullRequest", inline: true, head: "L'alternativa semplice", headSize: 13, bodySize: 12, fill: C.accent6, body: "Parte del miglioramento c'era anche senza AI." });
    banner(s, 4.55, "Il valore dell'AI è la differenza con l'alternativa, non con il nulla. Attenzione all'effetto dell'attenzione stessa.", { h: 0.42, fontSize: 12 });
  }
  {
    const s = content("Cercare le evidenze contrarie", "Il sottotema chiede di raccogliere evidenze, valutare risultati e limiti, e cercare evidenze contrarie alle ipotesi. Quest'ultimo punto è l'integrazione D nella sua forma più esigente. È naturale, durante una sperimentazione, guardare soprattutto ai segnali positivi: i casi in cui le bozze erano ottime, i commenti entusiasti. Il sottotema chiede di fare il contrario: cercare attivamente ciò che potrebbe smentire l'idea. In quali casi le bozze erano sbagliate, e quanto? Chi non le ha usate, e perché? Che cosa è peggiorato, anche se non era nei criteri? Quali errori sono sfuggiti alla revisione? I risultati valgono anche per i commerciali che non hanno partecipato, o per i periodi di maggior carico? È un atteggiamento scientifico, che il filosofo Karl Popper ha formulato in termini generali: una teoria è scientifica se può essere smentita dai fatti, e la si mette alla prova cercando di smentirla, non di confermarla. Applicato a un caso d'uso significa: progettare la verifica in modo che possa dare esito negativo, e prestare attenzione ai segnali contrari quanto a quelli favorevoli. È anche una questione di cultura: le persone devono potersi sentire libere di dire che qualcosa non funziona.");
    stepTag(s, 4);
    qGrid(s, ["In quali casi le bozze erano sbagliate, e quanto?", "Chi non le ha usate, e perché?", "Che cosa è peggiorato, anche fuori dai criteri?", "Quali errori sono sfuggiti alla revisione?", "Vale anche per chi non ha partecipato?", "Vale anche nei periodi di maggior carico?"], 3, 1.12, 1.05, 12);
    banner(s, 3.65, "Progettare la verifica in modo che possa dare esito negativo (Popper). E poter dire che qualcosa non funziona.", { h: 0.9, fontSize: 14 });
    txt(s, "Domande da porsi durante e dopo la sperimentazione delle bozze. Esempio fittizio.", { x: 0.5, y: 4.6, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Tre decisioni possibili", "L'esito di una verifica è una decisione, e il sottotema ne indica tre possibili: approfondire, modificare o abbandonare l'opportunità. Approfondire: i criteri di successo sono raggiunti, e si passa a un livello di verifica o di investimento successivo; per esempio dalla sperimentazione circoscritta a una più ampia, o alla decisione di realizzazione, che richiede il lavoro del Tema 16. Modificare: i risultati sono nella zona intermedia, o hanno rivelato qualcosa di inatteso; si cambia il caso d'uso, per esempio restringendo il perimetro, cambiando le fonti, rafforzando i controlli, e si verifica di nuovo. Abbandonare: i criteri di insuccesso sono raggiunti, o è emerso un rischio non accettabile; si interrompe. Abbandonare non è un fallimento della verifica: è il suo successo. La verifica è servita esattamente a ciò per cui era stata progettata: evitare un investimento che non avrebbe funzionato, a un costo limitato. La consapevolezza del sottotema lo dice chiaramente: lo scopo di un test è imparare se l'opportunità sia utile, realizzabile e controllabile, non dimostrare a ogni costo che l'idea iniziale è valida. Un'organizzazione in cui nessuna sperimentazione viene mai abbandonata probabilmente non sta sperimentando davvero.");
    stepTag(s, 4);
    const d = [["FiArrowUpRight", "Approfondire", "Criteri di successo raggiunti: livello successivo", C.accent6], ["FiRefreshCw", "Modificare", "Zona intermedia o sorprese: cambiare e riverificare", C.background2], ["FiXCircle", "Abbandonare", "Insuccesso o rischio non accettabile: fermarsi", C.background2]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.1, d[i][3], d[i][1]);
      await iconCircle(s, x + 0.15, 1.27, 0.55, d[i][0]);
      txt(s, d[i][1], { x: x + 0.8, y: 1.27, w: 1.95, h: 0.55, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, d[i][2], { x: x + 0.15, y: 1.95, w: 2.56, h: 1.2, fontSize: 12, color: C.text1 });
    }
    shapeBox(s, 0.5, 3.45, 9.0, 0.7, C.accent1, "abbandonare");
    txt(s, "Abbandonare non è il fallimento della verifica: è il suo successo, a un costo limitato.", { x: 0.7, y: 3.45, w: 8.6, h: 0.7, fontSize: 14, bold: true, color: C.background1, valign: "middle" });
    txt(s, "Un'organizzazione in cui nessuna sperimentazione viene mai abbandonata probabilmente non sta sperimentando davvero.", { x: 0.5, y: 4.3, w: 9, h: 0.55, fontSize: 13, italic: true, color: C.accent5 });
  }
  {
    const s = content("Dimostrazione o validazione", "L'ultimo punto del sottotema e del percorso: la differenza tra dimostrazione tecnica e validazione del caso d'uso. Una dimostrazione tecnica mostra che il sistema può produrre un output adeguato: le bozze generate su 50 richieste scelte sono buone. È un passo importante, ed è spesso ciò che viene presentato nelle riunioni, con grande effetto. Ma risponde solo a una delle domande. La validazione del caso d'uso mostra che il caso d'uso produce il beneficio atteso, nel lavoro reale, con rischi controllabili: i commerciali usano le bozze, i tempi di risposta scendono, gli errori non aumentano, il costo è sostenibile. Risponde alle domande di valore, fattibilità organizzativa, sostenibilità e rischio. Molti progetti di AI si fermano alla dimostrazione tecnica, e la scambiano per la validazione: il prototipo funziona, quindi il caso d'uso è valido. È lo stesso errore visto nel Tema 14 e nel 15.5 tra prototipo e servizio, guardato dal punto di vista delle evidenze. Il confronto in slide riassume le differenze.");
    stepTag(s, 4);
    table(s, [["", "Dimostrazione tecnica", "Validazione del caso d'uso"],
      ["Domanda", "Il sistema può produrre un output adeguato?", "Il caso d'uso produce il beneficio, nel lavoro reale?"],
      ["Condizioni", "Casi scelti, attenzione speciale", "Casi reali, uso normale"],
      ["Che cosa mostra", "Qualità dell'output", "Valore, uso, sostenibilità, rischio"],
      ["Esempio fittizio", "Bozze buone su 50 richieste scelte", "Bozze usate, tempi più brevi, errori non aumentati"]],
      { y: 1.15, colW: [1.9, 3.4, 3.7], rowH: 0.55, accentCol: 2, fontSize: 12 });
    banner(s, 4.0, "Il prototipo funziona, quindi il caso d'uso è valido: l'errore più comune.", { h: 0.8, fontSize: 15 });
  }
  keySlide("La sperimentazione deve poter smentire l'idea iniziale: lo scopo di un test è imparare, non dimostrare a ogni costo che l'idea era valida.", "Sottotema 15.8  ·  Dall'idea alla verifica", "Concetto chiave dell'ultimo sottotema. Ipotesi, dimostrazione tecnica e risultato verificato sono livelli diversi. Le assunzioni critiche sono quelle importanti e incerte, da rendere verificabili. Si usa la verifica più leggera che risponde alla domanda. I criteri di successo e di insuccesso si decidono prima. Si confronta con la baseline e con le alternative semplici. Si cercano le evidenze contrarie. L'esito è approfondire, modificare o abbandonare, e abbandonare può essere il successo della verifica. Esercizio suggerito: per l'idea su cui si è lavorato nel modulo, scrivere un'ipotesi critica verificabile, la verifica più leggera che potrebbe rispondere, e i criteri di successo, di insuccesso e la zona intermedia.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quale problema affrontare: partire dal problema e dal risultato desiderato, distinguere cause e sintomi, e chiedersi prima se serve l'AI. Come descrivere un caso d'uso: chi, quale attività, quali informazioni, quale ruolo dell'AI, quale risultato, con supervisione, volumi e confini. Che cosa rende promettente un'opportunità: segnali di valore e di adattabilità, ma il più promettente non è il più spettacolare. Benefici ipotizzati o ottenibili: calcoli con ipotesi esplicite, beneficio teorico ridotto da esclusioni, verifica e adozione, stime distinte da risultati. Dati, competenze, strumenti, integrazioni: fattibilità tecnica, organizzativa ed economica sono distinte. Rischi: alcuni sono condizioni di esclusione, non compensabili. Confrontare senza troppa certezza: criteri espliciti, soglie prima del punteggio, la matrice come ausilio alla discussione. Esperimenti: con criteri di successo e insuccesso definiti prima, capaci di smentire l'idea. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Quale problema?", "Il problema e il risultato, prima dello strumento"], ["Come descrivere un caso d'uso?", "Chi, attività, informazioni, ruolo dell'AI, risultato"], ["Che cosa lo rende promettente?", "Valore e adattabilità; non la spettacolarità"], ["Ipotizzati o ottenibili?", "Ipotesi esplicite, scenari, stime non dimostrate"], ["Dati, competenze, strumenti?", "Fattibilità tecnica, organizzativa, economica"], ["Quali rischi lo escludono?", "Le condizioni di soglia, non compensabili"], ["Come confrontare?", "Criteri espliciti; la matrice è un ausilio"], ["Quali esperimenti?", "Criteri decisi prima, capaci di smentire"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.9;
      shapeBox(s, x, y, 4.4, 0.8, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.06, w: 3.8, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.34, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere un problema aziendale da una soluzione tecnologica; comprendere perché non tutti i problemi richiedono l'AI; descrivere un caso d'uso attraverso attività, informazioni, risultati e contributo dell'AI; riconoscere le caratteristiche che possono rendere promettente un'opportunità; individuare i principali benefici potenziali; distinguere desiderabilità, fattibilità e sostenibilità; comprendere l'importanza di dati, strumenti e competenze disponibili; identificare rischi e condizioni che possono limitare o impedire un uso; confrontare opportunità diverse con criteri espliciti; comprendere i limiti delle matrici e dei punteggi; distinguere ipotesi, dimostrazioni tecniche e risultati verificati; comprendere perché una sperimentazione deve poter portare anche all'abbandono dell'idea iniziale.");
    const r = ["Problema o soluzione tecnologica", "Non tutti i problemi richiedono l'AI", "Descrivere un caso d'uso", "Caratteristiche promettenti", "Benefici potenziali", "Desiderabilità, fattibilità, sostenibilità", "Dati, strumenti, competenze", "Rischi e condizioni di esclusione", "Confronto con criteri espliciti", "Limiti di matrici e punteggi", "Ipotesi, dimostrazioni, risultati verificati", "Una sperimentazione può far abbandonare l'idea"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("La scheda dell'opportunità", "Traduciamo il modulo in una scheda pratica, da usare per valutare in modo preliminare un'idea di uso dell'AI. Cinque colonne, come le fasi del percorso. Individuare: qual è il problema, per chi, con quale risultato desiderato? Quali alternative non AI esistono? Descrivere: chi, quale attività, quali informazioni, quale ruolo dell'AI, quale supervisione, quale volume, quali confini? Quali ipotesi? Valutare: quale beneficio realistico, con scenari? Quali costi completi? È desiderabile, fattibile, sostenibile? Ci sono condizioni di esclusione? Confrontare: dove si colloca rispetto alle altre opportunità? Quanto è robusta la valutazione ai cambiamenti di pesi e giudizi? Verificare: qual è l'ipotesi critica? Qual è la verifica più leggera? Quali criteri di successo e insuccesso, decisi prima? La scheda non sostituisce il giudizio, ma lo rende esplicito, condivisibile e discutibile. Ed è uno strumento accessibile a chiunque, non solo agli specialisti.");
    const f = [["Individuare", ["Problema, per chi?", "Risultato desiderato?", "Alternative non AI?"], C.background2], ["Descrivere", ["Chi, attività, informazioni?", "Ruolo dell'AI, supervisione?", "Volume, confini, ipotesi?"], C.accent6], ["Valutare", ["Beneficio realistico?", "Costi completi?", "Desiderabile, fattibile, sostenibile?", "Esclusioni?"], C.background2], ["Confrontare", ["Posizione nella matrice?", "Robusta ai pesi?"], C.accent6], ["Verificare", ["Ipotesi critica?", "Verifica più leggera?", "Criteri decisi prima?"], C.background2]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.72, 3.0, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.1, y: 1.22, w: 1.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.1, y: 1.68, w: 1.58, h: 2.4, fontSize: 11, color: C.text1 });
    }
    banner(s, 4.3, "Non sostituisce il giudizio: lo rende esplicito, condivisibile, discutibile.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei semplificazioni frequenti quando si cercano e si valutano opportunità AI, una per ciascuno dei passaggi del modulo. Primo: 'abbiamo l'AI, dove la usiamo?'. È partire dallo strumento invece che dal problema, e scambiare una soluzione per un obiettivo. Secondo: 'facciamo il caso più spettacolare'. L'opportunità più promettente è spesso semplice, quotidiana e controllabile, e prima vanno considerate le alternative più semplici, anche non AI. Terzo: 'risparmieremo il 40 per cento del tempo'. È una stima presentata come un risultato; e spesso si conta solo il costo della licenza. Quarto: 'la demo funziona, quindi è fattibile'. La fattibilità tecnica non coincide con l'adozione organizzativa né con la sostenibilità economica. Quinto: 'ha il punteggio più alto'. Il punteggio è un ausilio alla discussione, non una prova, e non compensa le condizioni di esclusione. Sesto: 'il test è andato bene, come previsto'. I criteri di successo e di insuccesso vanno decisi prima di vedere i risultati, e una sperimentazione deve poter portare anche ad abbandonare l'idea. Sono errori comprensibili, perché la pressione a 'fare qualcosa con l'AI' è forte, e le dimostrazioni sono convincenti. Suggerimento: chiedere ai partecipanti quale di queste frasi hanno sentito più spesso in azienda.");
    const a = [["FiCpu", "\"Abbiamo l'AI: dove la usiamo?\"", "Prima il problema, poi lo strumento", "15.1"], ["FiStar", "\"Facciamo il caso più spettacolare\"", "Prima le alternative più semplici", "15.3"], ["FiTrendingUp", "\"Risparmieremo il 40% del tempo\"", "Una stima non è un risultato", "15.4"], ["FiCheckCircle", "\"La demo funziona: è fattibile\"", "Fattibile non vuol dire adottato", "15.5"], ["FiBarChart2", "\"Ha il punteggio più alto\"", "Le esclusioni non si compensano", "15.7"], ["FiFlag", "\"Il test è andato bene, come previsto\"", "Criteri di successo decisi prima", "15.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 2.95, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.7, y: y + 0.1, w: 0.55, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 15 abbiamo visto come individuare, descrivere, valutare, confrontare e verificare le opportunità di uso dell'AI, partendo dal bisogno e non dallo strumento. Il tema successivo, il Tema 16, è dedicato all'adozione dell'AI e al cambiamento organizzativo: come introdurre e accompagnare l'adozione nell'organizzazione. È il confine cardine di questo modulo: qui ci siamo chiesti dove potrebbe avere senso usare l'AI e quali evidenze servono per scegliere; nel Tema 16 ci chiederemo come portare un'opportunità verificata nel lavoro quotidiano delle persone, con quali passaggi, quale coinvolgimento, quale formazione e comunicazione. Molte questioni che abbiamo lasciato aperte, come la fattibilità organizzativa, la desiderabilità per gli utenti, l'adozione effettiva degli strumenti, troveranno lì una risposta operativa. Il Tema 16 chiude l'area 'Comprendere il valore per l'azienda'; seguiranno i Temi 17 e 18, sull'utilizzo responsabile, dove i rischi e le condizioni di esclusione di questo modulo verranno approfonditi. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Temi 12-14; Tema 15: opportunità e valutazione (completato)", { x: 0.75, y: 4.07, w: 3.9, h: 0.55, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 16: Adozione dell'AI e cambiamento organizzativo", { x: 5.4, y: 1.72, w: 3.9, h: 0.85, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Come introdurre e accompagnare l'adozione nell'organizzazione", { x: 5.4, y: 2.6, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.2, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Temi 17 e 18: utilizzo responsabile"], { space: 5 }), { x: 5.4, y: 3.55, w: 3.9, h: 1.0, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Il modulo è soprattutto di metodo, e si appoggia su concetti consolidati della gestione dei progetti, del design e del metodo scientifico più che su studi specifici sull'AI. La terna desiderabilità, fattibilità, sostenibilità è associata al design thinking e in particolare a IDEO, con formulazioni diverse a seconda delle fonti. La tecnica dei cinque perché è tradizionalmente attribuita a Sakichi Toyoda e al sistema di produzione Toyota. L'effetto Hawthorne è citato con la cautela dovuta, perché le interpretazioni degli studi originali sono discusse. Gli esempi aziendali, le valutazioni e i numeri del modulo sono fittizi; lo scenario delle richieste commerciali è tratto dal documento di perimetro, con giudizi dichiaratamente illustrativi. Riferimenti verificati a ottobre 2026; le pagine di Nickerson e gli editori di Popper, Brown e Ohno sono da ricontrollare sulle pubblicazioni originali.");
    const src = [
      "Popper, K. R. (1959). The Logic of Scientific Discovery. Hutchinson (ed. orig. 1934).",
      "Brown, T. (2009). Change by Design. HarperBusiness. Per la terna desiderabilità, fattibilità, sostenibilità.",
      "Ohno, T. (1988). Toyota Production System: Beyond Large-Scale Production. Productivity Press. Per i cinque perché.",
      "Nickerson, R. S. (1998). Confirmation Bias: A Ubiquitous Phenomenon in Many Guises. Review of General Psychology, 2(2), 175-220.",
      "Gli esempi aziendali, le valutazioni e i numeri delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 9 }), { x: 1.3, y: 1.15, w: 8.2, h: 3.45, fontSize: 12, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema15_Opportunita_valutazione_AI.pptx" });
  await applyTheme("Tema15_Opportunita_valutazione_AI.pptx", THEME);
  console.log("done");
})();
