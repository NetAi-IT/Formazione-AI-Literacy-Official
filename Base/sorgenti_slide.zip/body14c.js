  // =====================================================================
  section("14.7 Affidabilità delle risposte");
  divider("14.7", "Affidabilità delle risposte", "Le risposte possono essere errate anche quando i documenti di partenza sono accurati", "Uno dei sottotemi da approfondire, e il punto di arrivo della parte su utilizzo e controllo. Il documento di perimetro distingue con cura: il 14.2 riguarda la qualità delle fonti, il 14.7 la qualità della risposta generata. Vediamo la pertinenza di ciò che viene recuperato, le risposte basate su documenti insufficienti, le contraddizioni, la differenza tra informazione recuperata e interpretazione generata, i riferimenti alle fonti, le informazioni non recuperate, le risposte apparentemente fondate, e la verifica rispetto allo scopo. Lo scenario centrale del tema si colloca qui. Integrazione B. Il metodo generale di verifica è del Tema 7: qui ci concentriamo sui rischi specifici delle fonti aziendali.");
  {
    const s = content("Lo scenario: cinque modi di sbagliare", "Lo scenario indicato dal documento di perimetro come esempio didattico centrale del tema. Un assistente AI è collegato a un archivio di procedure aziendali approvate. Le fonti sono corrette e aggiornate: il problema della qualità visto nel 14.2 è risolto. Eppure l'assistente può sbagliare in almeno cinque modi. Uno: recuperare una procedura senza la relativa eccezione, che si trova in un altro paragrafo o in un documento collegato. Due: selezionare un documento destinato a un reparto diverso, con regole simili ma non uguali. Tre: interpretare impropriamente le informazioni recuperate, per esempio applicando una regola a un caso che non vi rientra. Quattro: non disporre di una condizione operativa decisiva, come la situazione specifica del cliente o una decisione non ancora scritta. Cinque: esporre informazioni non appropriate, se i permessi sono configurati male. Il messaggio chiave del tema: qualità delle fonti, efficacia del recupero, interpretazione e controllo degli accessi sono condizioni distinte. Collegare l'AI ai documenti aziendali non garantisce automaticamente risposte affidabili. Suggerimento: presentare lo scenario chiedendo ai partecipanti di immaginare, prima di mostrare l'elenco, che cosa potrebbe andare storto.");
    infoTag(s, 3);
    docBox(s, 0.5, 1.12, 9.0, 0.7, "Scenario", "Un assistente AI collegato a un archivio di procedure aziendali approvate, corrette e aggiornate.", { fontSize: 13, fill: C.accent6 });
    const f = [["Recupero", "La procedura senza l'eccezione"], ["Recupero", "Il documento di un altro reparto"], ["Interpretazione", "Una regola applicata al caso sbagliato"], ["Disponibilità", "Manca una condizione operativa decisiva"], ["Accessi", "Informazioni esposte per permessi errati"]];
    f.forEach((e, i) => {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.97, 1.7, 1.85, C.background2, "errore " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y: 2.02, w: 0.5, h: 0.45, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, e[0], { x: x + 0.12, y: 2.47, w: 1.5, h: 0.3, fontSize: 10, bold: true, color: C.accent5 });
      txt(s, e[1], { x: x + 0.12, y: 2.8, w: 1.5, h: 0.95, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.0, "Qualità delle fonti, recupero, interpretazione e accessi sono condizioni distinte. Collegare non garantisce risposte affidabili.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Pertinenza e completezza", "I primi punti del sottotema: la pertinenza delle informazioni recuperate e la qualità e completezza delle fonti rispetto alla domanda. Una risposta può basarsi su brani che parlano dell'argomento ma non rispondono alla domanda: si chiede il termine per i resi di prodotti personalizzati, e il sistema recupera la procedura generale sui resi, che non ne parla. Il modello, spinto a rispondere, applica la regola generale. Oppure le fonti sono pertinenti ma insufficienti: la procedura esiste, ma non copre il caso specifico, e la risposta colma il vuoto con un'ipotesi plausibile, senza segnalarlo. È il caso delle risposte basate su documenti insufficienti, uno dei rischi principali. Un assistente ben configurato dovrebbe dire 'le procedure disponibili non coprono questo caso', e le istruzioni viste nel 14.4 vanno in questa direzione; ma non sempre lo fa, perché i modelli tendono a produrre comunque una risposta. Per l'utente il segnale d'allarme è una risposta generica a una domanda specifica, o una risposta specifica senza un riferimento preciso alla fonte. Esempio fittizio.");
    infoTag(s, 3);
    docBox(s, 0.5, 1.15, 4.35, 1.3, "Domanda (esempio fittizio)", "Qual è il termine per il reso di un prodotto personalizzato?", { fontSize: 13 });
    docBox(s, 5.15, 1.15, 4.35, 1.3, "Brano recuperato", "Procedura generale resi: il cliente può restituire il prodotto entro 30 giorni.", { fontSize: 13, fill: C.accent6 });
    docBox(s, 0.5, 2.6, 9.0, 0.85, "Risposta", "Il termine è di 30 giorni.  Plausibile, ma la procedura non parla dei prodotti personalizzati.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Segnali d'allarme", { x: 0.5, y: 3.6, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    ["Risposta generica a una domanda specifica", "Risposta specifica senza riferimento preciso"].forEach((t, i) => chip(s, 0.5 + i * 4.6, 4.0, 4.4, 0.7, t, { fill: C.accent6, fontSize: 13 }));
  }
  {
    const s = content("Recuperato o interpretato?", "Una distinzione centrale del sottotema: la differenza tra informazione recuperata e interpretazione generata. Quando un assistente risponde basandosi sulle fonti, la risposta contiene due cose diverse, che all'utente appaiono fuse. Ciò che le fonti dicono, recuperato e riportato. E ciò che il modello ne deduce, sintetizza, applica al caso, collega: l'interpretazione. Per esempio: la procedura dice che i resi oltre i 500 euro richiedono l'approvazione del responsabile. Il cliente chiede di rendere tre articoli da 200 euro. L'assistente risponde che non serve approvazione, perché ogni articolo è sotto la soglia. È un'interpretazione: la procedura parla del valore del reso o del singolo articolo? La fonte non lo dice, il modello ha scelto. Può aver ragione o torto, ma ha presentato la sua interpretazione come se fosse scritta nella procedura. Il rischio è sottile: l'utente vede una risposta con un riferimento alla fonte corretta, e la ritiene fondata. Ma la fonte supporta solo una parte della risposta. Una buona pratica, quando la decisione conta, è distinguere: che cosa dice esattamente la fonte, e che cosa ne sto deducendo? Esempio fittizio.");
    infoTag(s, 3);
    docBox(s, 0.5, 1.15, 4.35, 1.35, "La procedura dice (fittizio)", "I resi oltre 500 € richiedono l'approvazione del responsabile.", { fontSize: 13, fill: C.accent6 });
    docBox(s, 5.15, 1.15, 4.35, 1.35, "Il caso", "Il cliente rende tre articoli da 200 € ciascuno.", { fontSize: 13 });
    docBox(s, 0.5, 2.65, 9.0, 0.95, "L'assistente risponde", "Non serve approvazione: ogni articolo è sotto la soglia.  Interpretazione: la soglia è per articolo o per reso? La fonte non lo dice.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    banner(s, 3.8, "La fonte citata supporta solo una parte della risposta. Che cosa dice esattamente, e che cosa ne viene dedotto?", { h: 0.95, fontSize: 14 });
  }
  {
    const s = content("Contraddizioni e assenze", "Altri due rischi specifici del sottotema. Le contraddizioni tra fonti: anche in un archivio curato possono esistere documenti che dicono cose diverse, per esempio una procedura generale e un'istruzione operativa di reparto, o un documento aggiornato e una FAQ non ancora allineata. Il modello può comportarsi in tre modi: scegliere una delle fonti senza dirlo, mescolarle in una risposta che non corrisponde a nessuna delle due, o segnalare la contraddizione. Solo il terzo è utile, e va chiesto esplicitamente nelle istruzioni. Le informazioni non disponibili o non recuperate: il caso più insidioso, perché non lascia traccia. Se l'informazione decisiva non è nella raccolta, o non viene recuperata, la risposta non mostra il vuoto: semplicemente non ne tiene conto. L'utente vede una risposta completa in apparenza, e non sa che cosa manca. È il quarto errore dello scenario: la condizione operativa decisiva che il sistema non ha. Per questo un assistente affidabile dovrebbe saper dire 'non ho trovato informazioni su questo', e l'utente dovrebbe chiedersi, per le questioni importanti: c'è qualcosa che la risposta potrebbe non sapere?");
    infoTag(s, 3);
    await card(s, 0.5, 1.15, 4.35, 2.6, { icon: "FiGitMerge", head: "Contraddizioni tra fonti", headSize: 14, bodySize: 12, body: bullets(["Sceglie una fonte senza dirlo", "Mescola, in una risposta che non corrisponde a nessuna", "Segnala la contraddizione: l'unico utile, da chiedere nelle istruzioni"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.6, { icon: "FiEyeOff", head: "Informazioni assenti", headSize: 14, bodySize: 12, fill: C.accent6, body: bullets(["Non nella raccolta, o non recuperate", "Il vuoto non si vede: la risposta sembra completa", "È il quarto errore dello scenario"], { space: 4 }) });
    banner(s, 3.95, "Per le questioni importanti: c'è qualcosa che la risposta potrebbe non sapere?", { h: 0.85, fontSize: 15 });
  }
  {
    const s = content("Citare le fonti", "Un elemento che il sottotema indica come decisivo: i riferimenti ai documenti e ai passaggi utilizzati. Molti assistenti aziendali indicano le fonti delle risposte, con il titolo del documento e spesso il brano usato. È uno strumento molto utile, per tre ragioni. Permette di verificare: l'utente può aprire il documento e controllare che dica davvero ciò che la risposta afferma. Permette di valutare la fonte: è la procedura ufficiale o una nota? È la versione attuale? È del reparto giusto? Rende visibile la differenza tra ciò che è scritto e ciò che è dedotto. Ma le citazioni hanno limiti che conviene conoscere. Una citazione non garantisce che la risposta corrisponda alla fonte: il modello può citare un documento e affermare qualcosa che il documento non dice, o dice in modo diverso. Le citazioni indicano che cosa è stato usato, non che cosa è stato trascurato. E una risposta con citazioni appare più autorevole, e questo può ridurre la propensione a verificare. Il suggerimento pratico: per le risposte che hanno conseguenze, aprire almeno la fonte citata e controllare il passaggio. Bastano pochi secondi.");
    infoTag(s, 3);
    await twoPanel(s, "A che cosa servono", bullets(["Verificare: la fonte dice davvero questo?", "Valutare: ufficiale, attuale, del reparto giusto?", "Distinguere lo scritto dal dedotto"], { space: 5 }), "I loro limiti", bullets(["Una citazione non garantisce la corrispondenza", "Mostrano ciò che è stato usato, non il trascurato", "Rendono la risposta più autorevole in apparenza"], { space: 5 }), { y: 1.15, h: 2.5, li: "FiBookmark", ri: "FiAlertTriangle" });
    banner(s, 3.9, "Per le risposte che hanno conseguenze: aprire la fonte citata e controllare il passaggio. Bastano pochi secondi.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Apparentemente fondate", "Il rischio che riassume il sottotema: le risposte apparentemente fondate. Una risposta generata da un assistente collegato alle fonti aziendali ha tutte le caratteristiche dell'affidabilità: usa il linguaggio dell'azienda, cita documenti interni, è precisa, ben scritta, sicura. Proprio per questo può essere più pericolosa di una risposta palesemente generica: è più difficile metterla in dubbio. Abbiamo visto i modi in cui può essere errata pur basandosi su fonti corrette: recupero non pertinente o incompleto, fonti insufficienti, interpretazione impropria, contraddizioni risolte in silenzio, informazioni mancanti, omissioni. È l'integrazione B: le risposte possono essere errate anche quando i documenti di partenza sono accurati. Il collegamento con il Tema 7 è diretto: là abbiamo visto che la fluidità non è affidabilità; qui aggiungiamo che anche il riferimento a fonti interne non lo è, da solo. Il grafico, con dati inventati a scopo illustrativo, mostra come si potrebbe scomporre la quota di risposte inadeguate in un'ipotetica verifica di un assistente: la maggior parte degli errori non dipende dalla qualità delle fonti, ma da ciò che accade dopo.");
    infoTag(s, 3);
    s.addChart(pres.charts.PIE, [{ name: "Cause", labels: ["Recupero non pertinente o incompleto", "Interpretazione impropria", "Informazione assente", "Fonte errata o superata", "Permessi"], values: [38, 24, 20, 12, 6] }], {
      x: 0.4, y: 1.05, w: 5.2, h: 3.5, chartColors: [HEX.a1, HEX.a4, HEX.a5, HEX.a2, HEX.a3], showPercent: true, showValue: false, dataLabelColor: "FFFFFF", dataLabelFontSize: 11, dataLabelFontFace: "+mn-lt",
      showLegend: true, legendPos: "r", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: true, title: "Cause di risposte inadeguate (dati inventati)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt" });
    await card(s, 5.85, 1.15, 3.65, 1.65, { icon: "FiCheckCircle", inline: true, head: "Sembra affidabile", headSize: 13, bodySize: 12, body: "Linguaggio dell'azienda, fonti interne, precisione, sicurezza." });
    await card(s, 5.85, 2.95, 3.65, 1.6, { icon: "FiAlertCircle", inline: true, head: "Ma non basta (B)", headSize: 13, bodySize: 12, fill: C.accent6, body: "Il riferimento a fonti interne non è, da solo, affidabilità (Tema 7)." });
  }
  {
    const s = content("Adeguata allo scopo", "Gli ultimi punti del sottotema: la necessità di aggiornamento delle fonti, e la verifica dell'adeguatezza rispetto allo scopo. L'aggiornamento: un assistente affidabile oggi non lo sarà domani se le fonti invecchiano. Va previsto un controllo periodico, che sarà parte delle condizioni del 14.8. La verifica rispetto allo scopo è il criterio che tiene insieme tutto: non tutte le risposte richiedono lo stesso livello di controllo. Il principio di proporzionalità visto nel Tema 7 vale anche qui. Per orientarsi, per trovare un documento, per avere una prima idea, una risposta approssimativa può bastare, e la citazione permette di approfondire. Per applicare una regola a un cliente, per comunicare un'informazione all'esterno, per prendere una decisione con conseguenze economiche, la risposta va verificata sulla fonte, e nei casi dubbi con una persona competente. Per questioni legali, di sicurezza o che riguardano persone, l'assistente può aiutare a trovare le informazioni, ma la decisione richiede una verifica completa. La scala in slide propone tre livelli, da adattare al proprio contesto. Il messaggio di sintesi del documento di perimetro: un sistema collegato ai dati interni può recuperare o interpretare male le fonti, e richiede verifiche coerenti con l'uso previsto.");
    infoTag(s, 3);
    const lv = [["Orientarsi", "Trovare un documento, farsi una prima idea", "La citazione permette di approfondire", C.background2], ["Applicare", "Una regola a un cliente, un'informazione all'esterno, una decisione economica", "Verificare sulla fonte; nei dubbi, una persona competente", C.accent6], ["Decidere su temi critici", "Questioni legali, di sicurezza, che riguardano persone", "L'assistente aiuta a trovare; la verifica è completa", "D9ECEA"]];
    lv.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.85, e[3], e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.2, h: 0.85, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.9, y: y + 0.05, w: 6.4, h: 0.38, fontSize: 12, color: C.text1 });
      txt(s, e[2], { x: 2.9, y: y + 0.43, w: 6.4, h: 0.38, fontSize: 12, bold: true, color: C.text2 });
    });
    banner(s, 4.1, "Verifiche coerenti con l'uso previsto (Tema 7). E fonti da riesaminare nel tempo.", { h: 0.75, fontSize: 14 });
  }
  keySlide("Una fonte corretta non garantisce una risposta corretta: il recupero può fallire, l'interpretazione può sbagliare, e ciò che manca non si vede.", "Sottotema 14.7  ·  Affidabilità delle risposte basate sulla conoscenza aziendale  ·  Integrazione B", "Concetto chiave del settimo sottotema. Lo scenario centrale del tema mostra cinque modi di sbagliare con fonti corrette. Pertinenza e completezza delle fonti rispetto alla domanda, distinzione tra recuperato e interpretato, contraddizioni e assenze, citazioni utili ma non sufficienti: tutto concorre a risposte che possono essere apparentemente fondate. La verifica va proporzionata allo scopo. Esercizio suggerito: dato un documento fittizio di procedura e cinque risposte di un assistente, individuare per ciascuna che cosa è recuperato e che cosa è interpretato, e quale dei cinque errori dello scenario, se presente, si è verificato.");

  // =====================================================================
  section("14.8 Condizioni aziendali");
  divider("14.8", "Condizioni per valorizzare i dati", "L'efficacia non richiede accesso illimitato, bensì disponibilità mirata e controllata delle informazioni", "L'ultimo sottotema riassume il modulo dal punto di vista dell'organizzazione: quali condizioni informative, tecnologiche e organizzative servono perché l'AI possa usare bene le informazioni aziendali, e mantenerlo nel tempo. Il livello è la consapevolezza organizzativa. Il documento di perimetro distingue: il 14.2 riguarda la qualità dei contenuti, il 14.8 il quadro complessivo delle condizioni; il 14.6 le regole di accesso, il 14.8 il loro contributo all'utilizzabilità. Integrazione D. Non sviluppiamo criteri di selezione dei progetti, che sono del Tema 15, né piani di adozione, del Tema 16.");
  {
    const s = content("Tre famiglie di condizioni", "Il sottotema elenca molte condizioni, che conviene raggruppare in tre famiglie, come indica l'ottava domanda guida. Le condizioni informative: la disponibilità delle informazioni necessarie per il caso d'uso; la loro qualità e il loro aggiornamento; l'organizzazione della documentazione, cioè quanto è vicina a una base di conoscenza. Le condizioni tecnologiche: la compatibilità con gli strumenti esistenti; il livello di integrazione necessario, che può andare dai documenti allegati al collegamento con più applicazioni; la disponibilità selettiva delle informazioni, cioè la possibilità tecnica di applicare i permessi. Le condizioni organizzative: la responsabilità sulla gestione delle fonti; l'equilibrio tra accessibilità e protezione; la manutenzione e l'aggiornamento nel tempo; le competenze aziendali necessarie, non solo tecniche ma anche di chi conosce i contenuti e i processi. Le tre famiglie sono tutte necessarie. Un'azienda con un'ottima tecnologia e informazioni disordinate otterrà risposte disordinate; una con informazioni curate ma nessuno responsabile di mantenerle le vedrà degradare; una con tutto pronto ma permessi non governati si esporrà a rischi.");
    infoTag(s, 4);
    const f = [["FiFileText", "Informative", ["Informazioni necessarie disponibili", "Qualità e aggiornamento", "Documentazione organizzata"]], ["FiCpu", "Tecnologiche", ["Compatibilità con gli strumenti", "Livello di integrazione adatto", "Permessi applicabili"]], ["FiUsers", "Organizzative", ["Responsabili delle fonti", "Equilibrio accesso e protezione", "Manutenzione nel tempo", "Competenze su contenuti e processi"]]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.85, i === 2 ? C.accent6 : C.background2, f[i][1]);
      await iconCircle(s, x + 0.15, 1.27, 0.55, f[i][0]);
      txt(s, f[i][1], { x: x + 0.8, y: 1.27, w: 1.95, h: 0.55, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, bullets(f[i][2], { space: 5 }), { x: x + 0.15, y: 1.95, w: 2.6, h: 1.95, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.2, "Tutte necessarie: ottima tecnologia con informazioni disordinate dà risposte disordinate.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Prototipo o servizio", "Una distinzione del sottotema molto utile nella pratica: la differenza tra un prototipo documentale e un servizio operativo affidabile. Oggi costruire un prototipo di assistente sui documenti aziendali è relativamente facile: si caricano alcune decine di documenti in uno strumento, si scrivono le istruzioni, e in pochi giorni si ha qualcosa che risponde, spesso in modo impressionante. La dimostrazione funziona. Ma un servizio su cui le persone possano contare ogni giorno richiede molto di più. Fonti selezionate e curate, non un campione. Un responsabile per ogni fonte, e un processo di aggiornamento. Permessi coerenti con le regole aziendali, verificati. Integrazione con i sistemi necessari, che funzioni anche quando i sistemi cambiano. Verifiche periodiche della qualità delle risposte, con domande di prova. Un modo per gli utenti di segnalare risposte sbagliate, e qualcuno che se ne occupi. Tracciabilità. Formazione degli utenti. È la differenza, ben nota nell'informatica, tra far funzionare qualcosa una volta e farlo funzionare sempre. Molti progetti si fermano tra le due, perché il lavoro necessario per il secondo passo era stato sottostimato guardando il primo.");
    infoTag(s, 4);
    table(s, [["", "Prototipo documentale", "Servizio operativo affidabile"],
      ["Fonti", "Un campione caricato", "Selezionate, curate, con responsabili"],
      ["Aggiornamento", "Nessuno", "Un processo continuo"],
      ["Permessi", "Spesso ignorati", "Coerenti con le regole, verificati"],
      ["Qualità", "La dimostrazione funziona", "Verifiche periodiche, segnalazioni degli utenti"],
      ["Tempo", "Pochi giorni", "Lavoro continuo, spesso sottostimato"]],
      { y: 1.15, colW: [1.9, 3.3, 3.8], rowH: 0.47, accentCol: 2, fontSize: 12 });
    banner(s, 4.15, "Far funzionare qualcosa una volta non è farlo funzionare sempre.", { h: 0.7, fontSize: 15 });
  }
  {
    const s = content("Gli ostacoli principali", "Il sottotema chiede di riconoscere i principali ostacoli alla valorizzazione dei dati aziendali. Riprendendo il modulo, se ne possono indicare alcuni ricorrenti. Le informazioni disperse e frammentate, tra sistemi, reparti, caselle personali. La qualità insufficiente: duplicati, contraddizioni, obsolescenza, terminologie diverse. L'assenza di responsabilità sulle fonti. La conoscenza tacita non documentata, e il tempo limitato degli esperti per documentarla. I permessi non governati, con condivisioni eccessive mai corrette. Le integrazioni difficili con sistemi datati o poco aperti. Le competenze, sia tecniche sia di chi conosce i contenuti, spesso disponibili in poche persone. E l'aspettativa, molto diffusa, che l'AI risolva da sola problemi che sono di organizzazione delle informazioni. Un'osservazione utile: molti di questi ostacoli esistevano già prima dell'AI, e già limitavano il lavoro delle persone. L'AI non li crea, ma li rende più visibili e più costosi da ignorare. Per questo i progetti sull'AI aziendale diventano spesso, in pratica, occasioni per mettere ordine nel patrimonio informativo, con benefici che vanno oltre l'AI stessa.");
    infoTag(s, 4);
    await iconGrid(s, [
      { icon: "FiGrid", head: "Dispersione", body: "Tra sistemi, reparti, caselle personali" },
      { icon: "FiCopy", head: "Qualità", body: "Duplicati, contraddizioni, obsolescenza" },
      { icon: "FiUserX", head: "Nessun responsabile", body: "Fonti che nessuno mantiene" },
      { icon: "FiUsers", head: "Conoscenza tacita", body: "Non scritta, esperti senza tempo" },
      { icon: "FiUnlock", head: "Permessi non governati", body: "Condivisioni eccessive mai corrette" },
      { icon: "FiZap", head: "Aspettative", body: "Che l'AI risolva da sola problemi organizzativi" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Esistevano già. L'AI li rende più visibili, e più costosi da ignorare.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Partire dal caso d'uso", "L'ultimo punto del sottotema, e l'indicazione di metodo con cui si chiude il modulo: la necessità di valutare l'adeguatezza delle informazioni rispetto ai casi di utilizzo. Il patrimonio informativo non va valutato in astratto, 'abbiamo dati buoni o cattivi?', ma rispetto a un uso. Le stesse informazioni possono essere adeguate per un caso d'uso e inadeguate per un altro. Le procedure del magazzino possono essere ottime per un assistente rivolto agli addetti, insufficienti per uno rivolto ai clienti. Per ciascun caso d'uso, le domande sono quelle delle quattro condizioni dell'introduzione, più una. Disponibilità: le informazioni necessarie esistono? Accessibilità: il sistema può accedervi, con i permessi giusti? Utilizzabilità: sono organizzate e reperibili? Affidabilità: sono corrette e aggiornate per questo scopo? E infine: che cosa non è scritto, e come lo si gestisce? È anche l'integrazione D nella sua forma più costruttiva: l'efficacia non richiede accesso illimitato, ma disponibilità mirata e controllata. Partire da un caso d'uso circoscritto, con fonti curate e permessi chiari, è più efficace che collegare tutto. La valutazione dei casi d'uso, con criteri di priorità e business case, è il tema del modulo successivo.");
    infoTag(s, 4);
    numList(s, ["Disponibilità: le informazioni necessarie esistono?", "Accessibilità: il sistema può accedervi, con i permessi giusti?", "Utilizzabilità: sono organizzate e reperibili?", "Affidabilità: sono corrette e aggiornate per questo scopo?", "E che cosa non è scritto, e come lo si gestisce?"], { y: 1.15, h: 0.5, fontSize: 13 });
    banner(s, 4.15, "Non accesso illimitato, ma disponibilità mirata e controllata. Un caso d'uso circoscritto è meglio che collegare tutto (D).", { h: 0.8, fontSize: 13 });
  }
  keySlide("L'efficacia non richiede accesso illimitato, ma disponibilità mirata e controllata delle informazioni, curata nel tempo.", "Sottotema 14.8  ·  Condizioni organizzative e tecnologiche per valorizzare i dati aziendali  ·  Integrazione D", "Concetto chiave dell'ultimo sottotema. Le condizioni sono informative, tecnologiche e organizzative, tutte necessarie. Un prototipo che funziona non è un servizio affidabile: servono fonti curate, responsabili, permessi, verifiche, manutenzione. Gli ostacoli principali esistevano già prima dell'AI, che li rende visibili. Il patrimonio va valutato rispetto al caso d'uso, con le quattro condizioni e la domanda su ciò che non è scritto. Esercizio suggerito: scegliere un caso d'uso fittizio di assistente nel proprio ambito e compilare la checklist delle quattro condizioni, indicando per ciascuna lo stato attuale e che cosa servirebbe per passare da prototipo a servizio.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quali informazioni possiede un'azienda e dove: dati, informazioni, documenti e conoscenza, strutturati e non, distribuiti tra persone, reparti e applicazioni, e in parte taciti. Molti dati o dati utilizzabili: la quantità non è valore; contano pertinenza, qualità, reperibilità. Qualità, organizzazione, aggiornamento: l'AI ha accesso alle fonti, non alla realtà, e ne eredita i problemi, amplificandoli. Informazioni non apprese: vengono fornite al momento dell'uso, nella conversazione, con allegati o con il recupero da raccolte; recuperare non è modificare il modello. Archivi e gestionali: documenti e dati operativi sono diversi, sola lettura e modifica comportano rischi diversi. Permessi selettivi: perché l'AI non deve sapere tutto ciò che l'azienda sa, e perché rende visibili le condivisioni eccessive. Fonti corrette e risposte: recupero, interpretazione e ciò che manca possono far sbagliare anche con fonti accurate. Condizioni: informative, tecnologiche e organizzative, valutate rispetto al caso d'uso. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Quali informazioni, e dove?", "Dati, documenti, conoscenza; distribuiti; in parte taciti"], ["Molti dati o dati utilizzabili?", "Pertinenza, qualità, reperibilità, non quantità"], ["Qualità e aggiornamento?", "L'AI eredita i problemi delle fonti, e li amplifica"], ["Informazioni non apprese?", "Fornite al momento dell'uso; recuperare non è addestrare"], ["Archivi e gestionali?", "Documenti o dati operativi; leggere o modificare"], ["Perché permessi selettivi?", "L'AI non deve sapere tutto ciò che l'azienda sa"], ["Perché una fonte corretta non basta?", "Recupero, interpretazione, ciò che manca"], ["Quali condizioni?", "Informative, tecnologiche, organizzative, per caso d'uso"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.9;
      shapeBox(s, x, y, 4.4, 0.8, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.06, w: 3.8, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.34, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere dati, informazioni, documenti e conoscenza aziendale; comprendere l'importanza della qualità e dell'aggiornamento delle informazioni; riconoscere che possedere molti dati non equivale a poterli utilizzare; comprendere il ruolo dell'organizzazione e della reperibilità della conoscenza; distinguere la conoscenza del modello dalle informazioni aziendali rese disponibili durante l'uso; conoscere le principali modalità con cui l'AI può accedere a informazioni specifiche; comprendere la differenza tra recupero documentale e integrazione con applicazioni operative; riconoscere la necessità di permessi e controlli di accesso appropriati; comprendere perché una fonte corretta non garantisce una risposta corretta; riconoscere il valore e i limiti della conoscenza tacita; distinguere accessibilità completa e accessibilità selettiva; identificare le principali condizioni informative, tecnologiche e organizzative per usare efficacemente l'AI in azienda.");
    const r = ["Dati, informazioni, documenti, conoscenza", "Qualità e aggiornamento", "Molti dati non sono dati utilizzabili", "Organizzazione e reperibilità", "Conoscenza del modello e dell'azienda", "Modalità di accesso a informazioni specifiche", "Recupero documentale e applicazioni operative", "Permessi e controlli di accesso", "Fonte corretta, risposta non garantita", "Valore e limiti della conoscenza tacita", "Accessibilità completa o selettiva", "Condizioni informative, tecnologiche, organizzative"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Domande su un assistente aziendale", "Traduciamo il modulo in una scheda pratica: le domande da porsi quando si usa, si chiede o si valuta un assistente AI collegato alle informazioni aziendali. Fonti: quali fonti usa? Sono quelle ufficiali, curate, aggiornate? Chi ne è responsabile? Che cosa non è scritto da nessuna parte? Recupero: come trova le informazioni? Cita le fonti e i passaggi? Che cosa fa se non trova nulla, o trova fonti in contraddizione? Accessi: con quali permessi accede, quelli dell'utente o permessi propri? Solo lettura o anche modifica? Sono state verificate le condivisioni eccessive? Gli accessi sono tracciati? Risposte: la risposta distingue ciò che è scritto da ciò che è dedotto? Quanto conta questa risposta, e quanto la devo verificare? Ho aperto la fonte citata? Sono domande accessibili a chiunque, non solo ai tecnici, e chi le pone contribuisce in modo concreto alla qualità e alla sicurezza del sistema.");
    const f = [["Fonti", ["Ufficiali, curate, aggiornate?", "Chi ne è responsabile?", "Che cosa non è scritto?"], C.background2], ["Recupero", ["Cita fonti e passaggi?", "Se non trova nulla?", "Se le fonti si contraddicono?"], C.accent6], ["Accessi", ["Permessi dell'utente o propri?", "Lettura o modifica?", "Condivisioni verificate, accessi tracciati?"], C.background2], ["Risposte", ["Scritto o dedotto?", "Quanto conta, quanto verificare?", "Ho aperto la fonte?"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Domande accessibili a chiunque, non solo ai tecnici.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Che cosa evitare", "Per completezza, gli errori più comuni da evitare, che riassumono il modulo in negativo. Collegare tutto: dare all'AI accesso all'intero archivio, nella convinzione che più informazioni significhino risposte migliori. Confondere collegare con addestrare, e aspettarsi che il modello 'sappia' i documenti. Trascurare la qualità delle fonti, pensando che l'AI riconoscerà da sola il vecchio e il contraddittorio. Dimenticare chi aggiorna: costruire l'assistente senza un responsabile per le fonti. Ignorare i permessi, o non chiedere con quali permessi l'assistente accede. Fidarsi delle citazioni senza aprirle. Confondere il prototipo con il servizio. Dimenticare la conoscenza tacita, e smettere di chiedere alle persone. Sono errori comprensibili, perché la facilità con cui oggi si può collegare un assistente ai documenti fa sembrare semplice ciò che non lo è.");
    rowList(s, ["Collegare tutto, pensando che più informazioni diano risposte migliori", "Confondere collegare con addestrare", "Pensare che l'AI riconosca da sola il vecchio e il contraddittorio", "Costruire l'assistente senza responsabili delle fonti", "Ignorare con quali permessi l'assistente accede", "Fidarsi delle citazioni senza aprirle", "Confondere il prototipo con il servizio, e dimenticare la conoscenza tacita"], { y: 1.12, h: 0.47, gap: 0.07, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 14 abbiamo visto come il patrimonio informativo dell'azienda condizioni l'uso dell'AI: che cosa esiste, in che stato è, come è organizzato, come l'AI lo usa, con quali permessi e con quale affidabilità. Il tema successivo, il Tema 15, è dedicato all'individuazione e alla valutazione delle opportunità AI: come riconoscere dove l'AI può creare valore in un'organizzazione, come valutare i casi d'uso, con quali criteri scegliere e dare priorità. È il naturale sviluppo dei temi di quest'area: il valore del Tema 12, la trasformazione del lavoro del Tema 13, le condizioni informative del Tema 14 diventano criteri per valutare le opportunità. La domanda con cui abbiamo chiuso, 'le informazioni sono adeguate per questo caso d'uso?', sarà uno di quei criteri. Seguirà il Tema 16, sull'adozione e il cambiamento organizzativo. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Temi 12 e 13; Tema 14: dati e conoscenza (completato)", { x: 0.75, y: 4.07, w: 3.9, h: 0.55, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 15: Individuazione e valutazione delle opportunità AI", { x: 5.4, y: 1.72, w: 3.9, h: 0.85, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Dove l'AI crea valore, come valutare e scegliere i casi d'uso", { x: 5.4, y: 2.6, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.2, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 16: adozione e cambiamento organizzativo", "Temi 17 e 18: utilizzo responsabile"], { space: 5 }), { x: 5.4, y: 3.55, w: 3.9, h: 1.2, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Le tecnologie di recupero e di integrazione evolvono rapidamente, così come le funzioni di gestione dei permessi negli strumenti aziendali: è consigliabile verificare lo stato dell'arte prima di ogni edizione, senza però spostare il modulo sui dettagli tecnici, come chiede il documento di perimetro. La classificazione in quattro livelli delle informazioni è una convenzione diffusa, con nomi e dettagli che variano tra organizzazioni e standard; conviene adattarla a quella eventualmente in uso nell'azienda. Gli esempi aziendali e i numeri del modulo sono fittizi, tranne lo scenario dell'assistente sulle procedure, tratto dal documento di perimetro.");
    const src = [
      "Polanyi, M. (1966). The Tacit Dimension. University of Chicago Press.",
      "Nonaka, I., Takeuchi, H. (1995). The Knowledge-Creating Company. Oxford University Press.",
      "Lewis, P. et al. (2020). Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS 2020.",
      "Liu, N. F. et al. (2024). Lost in the Middle: How Language Models Use Long Contexts. Transactions of the ACL, 12.",
      "Saltzer, J. H., Schroeder, M. D. (1975). The Protection of Information in Computer Systems. Proceedings of the IEEE, 63(9).",
      "Gli esempi aziendali e i numeri delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 8 }), { x: 1.3, y: 1.15, w: 8.2, h: 3.6, fontSize: 12, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema14_AI_dati_conoscenza_aziendale.pptx" });
  await applyTheme("Tema14_AI_dati_conoscenza_aziendale.pptx", THEME);
  console.log("done");
})();
