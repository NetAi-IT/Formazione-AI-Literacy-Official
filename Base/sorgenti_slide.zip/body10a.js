  function opTag(s, active) {
    const st = ["Interpretare", "Generare", "Trasformare"];
    const act = Array.isArray(active) ? active : [active];
    st.forEach((t, i) => {
      const x = 6.62 + i * 0.97, on = act.indexOf(i) >= 0;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.92, h: 0.26, rectRadius: 0.13, fill: { color: on ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "operazione " + t });
      txt(s, t, { x, y: 0.42, w: 0.92, h: 0.26, fontSize: 9, bold: true, color: on ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1, italic: !!o.italic });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, 0.5, y, 9.0, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: 0.7 + lw, y, w: 8.6 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 10", { placeholder: "kicker" });
    s.addText("AI multimodale e creazione di contenuti", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al decimo tema, il terzo dell'area 'Esplorare le possibilità dell'AI'. Nel Tema 8 abbiamo lavorato su testi e documenti, nel Tema 9 sui dati. Qui allarghiamo lo sguardo alle altre modalità attraverso cui le informazioni si presentano: immagini, audio, video, e i materiali di comunicazione che le combinano, come le presentazioni. I sistemi AI attuali non lavorano più solo con il testo: possono descrivere una fotografia, leggere una schermata, trascrivere una riunione, generare un'immagine o un breve video, trasformare un documento in slide. Sono possibilità che cambiano molte attività quotidiane, dalla comunicazione alla formazione, dal supporto tecnico all'accessibilità. E portano con sé una questione nuova e importante: un contenuto può essere molto realistico senza essere autentico. Il punto di vista resta quello dell'utilizzatore: non entriamo nelle architetture dei modelli multimodali né nella produzione audiovisiva professionale. Suggerimento per l'apertura: mostrare due immagini, una fotografia reale e una generata, e chiedere ai partecipanti di indovinare quale sia quale. La difficoltà del compito introduce bene il tema. Usare immagini prive di persone reali riconoscibili o di marchi. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026, compresi gli obblighi di trasparenza dell'AI Act sui contenuti generati; le capacità di generazione di immagini, voci e video evolvono molto rapidamente, quindi esempi, dimostrazioni e riferimenti normativi vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la comprensione delle principali possibilità offerte dall'AI multimodale nella percezione, interpretazione, generazione e trasformazione di contenuti visivi, sonori e audiovisivi, riconoscendo opportunità applicative, condizioni di efficacia e limiti. La consapevolezza da sviluppare ha due parti. La prima: l'AI può comprendere, produrre e trasformare informazioni attraverso modalità diverse, e questo apre possibilità concrete in molti ambiti di lavoro. La seconda: un contenuto realistico non è necessariamente autentico, e una trasformazione da una modalità all'altra può introdurre errori, omissioni o alterazioni del significato. Il concetto centrale del tema: l'AI multimodale amplia le possibilità di comprendere, creare e trasformare contenuti attraverso testo, immagini, audio e video; il realismo non garantisce autenticità e ogni trasformazione richiede attenzione alla fedeltà, alla correttezza e all'adeguatezza delle informazioni. Un principio di metodo indicato dal documento: le capacità effettive vanno sempre ricondotte allo specifico sistema, e non dedotte genericamente dall'etichetta 'multimodale'.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Conoscere le possibilità dell'AI su immagini, audio e video", "Distinguere interpretare, generare e trasformare", "Riconoscere opportunità, condizioni di efficacia e limiti"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Un contenuto realistico non è necessariamente autentico.\n\nOgni passaggio tra modalità può introdurre errori, omissioni o alterazioni del significato.\n\nLe capacità dipendono dal sistema, non dall'etichetta 'multimodale'." });
  }
  {
    const s = content("Dieci domande guida", "Le dieci domande guida accompagnano il modulo. Le prime due sono concettuali: che cosa significa multimodale, e in che cosa differiscono interpretazione, generazione e trasformazione dei contenuti. Le successive quattro percorrono le modalità: immagini da comprendere, immagini da generare e modificare, audio e parlato, video. La settima riguarda presentazioni e materiali di comunicazione. Le ultime tre riguardano i temi trasversali: che cosa può andare perduto passando da una modalità all'altra, come distinguere realismo, autenticità e accuratezza, e quali opportunità offre la multimodalità per l'accessibilità delle informazioni. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Che cosa significa AI multimodale?", "Interpretare, generare, trasformare: che differenza c'è?", "Come comprende immagini, diagrammi e schermate?", "Possibilità e limiti della generazione di immagini?", "Come elabora parlato e registrazioni?", "Quali capacità applicate ai video?", "Come supporta presentazioni e materiali?", "Che cosa si perde passando da una modalità all'altra?", "Come distinguere realismo, autenticità, accuratezza?", "Quali opportunità per l'accessibilità?"], 5, 1.2, 1.6, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in quattro dimensioni complementari. Comprendere le modalità: che cosa significa multimodalità e come sono rappresentate le informazioni, nel sottotema 10.1. Interpretare e generare contenuti nelle diverse modalità: immagini, audio, video e materiali comunicativi, nei sottotemi dal 10.2 al 10.6. Trasformare e combinare, cioè passare tra più modalità preservando significato e utilità, nel 10.7. Valutare i risultati: autenticità, accuratezza, provenienza, fedeltà e limiti, nel 10.8. Trasversale a tutto il tema c'è la distinzione, chiesta dalla seconda domanda guida, tra tre operazioni: interpretare un contenuto, cioè comprenderlo e descriverlo; generarne uno nuovo; trasformarlo da una forma all'altra. Sono operazioni con rischi diversi: interpretare può portare a errori di riconoscimento; generare può produrre contenuti realistici ma non autentici; trasformare può far perdere o alterare informazioni. Nelle slide, un indicatore in alto a destra ricorda di quale operazione si sta parlando.");
    const d = [["FiLayers", "Comprendere le modalità", "10.1"], ["FiImage", "Interpretare e generare", "10.2  10.3  10.4  10.5  10.6"], ["FiRepeat", "Trasformare e combinare", "10.7"], ["FiShield", "Valutare i risultati", "10.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.1, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.03, w: 1.9, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.7, w: 1.9, h: 0.4, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Trasversali: tre operazioni con rischi diversi", { x: 0.5, y: 3.4, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    const o = [["Interpretare", "Errori di riconoscimento"], ["Generare", "Realistico ma non autentico"], ["Trasformare", "Informazioni perse o alterate"]];
    o.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 3.8, 2.86, 1.1, C.accent6, e[0]);
      txt(s, e[0], { x: x + 0.15, y: 3.88, w: 2.56, h: 0.38, fontSize: 15, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 4.3, w: 2.56, h: 0.5, fontSize: 12, color: C.text1 });
    });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, il video, con priorità media. Vanno compresi e sperimentati: interpretazione di immagini, generazione e modifica visiva, trascrizione, interazione vocale e trasformazioni tra modalità. Vanno conosciuti: generazione video, presentazioni, accessibilità, autenticità, provenienza e controlli di coerenza. Vanno solo accennati: architetture multimodali, modelli di diffusione, editing professionale, produzione audiovisiva specialistica e verifica forense tecnica. Confini: non ripetiamo i meccanismi del Tema 2, la teoria degli errori del Tema 3, i confronti commerciali tra strumenti del Tema 4, le tecniche di prompting del Tema 6, la metodologia di verifica del Tema 7. Il confine più importante è con il Tema 8: lì si trattava la conoscenza contenuta nei documenti, qui le modalità visive, sonore e audiovisive. Non progettiamo workflow automatizzati, che appartengono al Tema 11, e introduciamo autenticità e diritti senza analizzare gli obblighi giuridici, che appartengono ai Temi 17 e 18. Un'avvertenza pratica: immagini, registrazioni e video aziendali possono contenere dati personali o riservati, e vanno caricati solo negli strumenti autorizzati.");
    pathSlide(s, [["10.1", "Fondamenti dell'AI multimodale", "Alta"], ["10.2", "Comprensione delle immagini", "Alta"], ["10.3", "Generazione e modifica delle immagini", "Alta"], ["10.4", "Audio, voce e parlato", "Alta"], ["10.5", "Comprensione e generazione video", "Media"], ["10.6", "Presentazioni e comunicazione", "Alta"], ["10.7", "Trasformazioni tra modalità", "Alta"], ["10.8", "Limiti, autenticità, affidabilità", "Alta"]],
      [["Comprendere e sperimentare", "Interpretare immagini, generare e modificare, trascrivere, voce, trasformazioni", C.accent1, C.background1], ["Conoscere", "Video, presentazioni, accessibilità, autenticità, provenienza, coerenza", C.accent6, C.text1], ["Solo accennare", "Architetture, modelli di diffusione, editing professionale, verifica forense", C.background2, C.text1]]);
  }

  // =====================================================================
  section("10.1 Fondamenti");
  divider("10.1", "Fondamenti dell'AI multimodale", "Capacità effettive e modalità supportate dipendono dal sistema impiegato", "Partiamo dai concetti. Che cosa significa che un sistema AI è multimodale? Quali sono le modalità, che cosa vuol dire comprenderle o generarle, e come si realizza in pratica un sistema multimodale? In questo sottotema, da comprendere, costruiamo il vocabolario per tutto il modulo. Senza entrare nelle architetture, che il documento chiede solo di accennare, vedremo una distinzione importante: quella tra un modello che elabora più modalità e un'applicazione che combina più modelli specializzati. È una distinzione che spiega perché due strumenti entrambi 'multimodali' possono avere capacità molto diverse.");
  {
    const s = content("Che cosa significa multimodale", "Una modalità è una forma in cui l'informazione si presenta: testo, immagini, audio, video. Gli esseri umani sono naturalmente multimodali: in una riunione ascoltiamo le parole, guardiamo le slide, osserviamo le espressioni, leggiamo gli appunti, e integriamo tutto in una comprensione unica. I primi sistemi di AI generativa erano essenzialmente testuali: ricevevano testo e producevano testo. Un sistema multimodale può ricevere e, in alcuni casi, produrre informazioni in più modalità: può ricevere una fotografia e una domanda scritta, una registrazione audio, una schermata, e rispondere con un testo, un'immagine, una voce. Le quattro modalità principali sono quelle in slide. Il testo, che resta la modalità centrale e spesso il ponte tra le altre. Le immagini: fotografie, illustrazioni, diagrammi, schermate, documenti scansionati. L'audio: parlato, musica, suoni. Il video: sequenze di immagini nel tempo, spesso con audio. Ciascuna modalità ha caratteristiche proprie, e un sistema può gestirne bene alcune e meno bene altre.");
    opTag(s, -1);
    const m = [["FiType", "Testo", "La modalità centrale, spesso il ponte tra le altre"], ["FiImage", "Immagini", "Fotografie, illustrazioni, diagrammi, schermate, scansioni"], ["FiMic", "Audio", "Parlato, musica, suoni"], ["FiFilm", "Video", "Immagini nel tempo, spesso con audio"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.4, i === 0 ? C.accent6 : C.background2, m[i][1]);
      await iconCircle(s, x + 0.68, 1.3, 0.8, m[i][0]);
      txt(s, m[i][1], { x: x + 0.1, y: 2.2, w: 1.95, h: 0.42, fontSize: 17, bold: true, color: C.text1, align: "center" });
      txt(s, m[i][2], { x: x + 0.15, y: 2.65, w: 1.85, h: 0.8, fontSize: 11, color: C.text2, align: "center" });
    }
    banner(s, 3.8, "Gli esseri umani sono naturalmente multimodali: in una riunione integriamo parole, slide, espressioni e appunti.", { h: 0.65, fontSize: 13 });
    txt(s, "Un sistema può gestire bene alcune modalità e meno bene altre.", { x: 0.5, y: 4.58, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Testuali e multimodali", "Confrontiamo un sistema solo testuale con uno multimodale, dal punto di vista di chi lo usa. Con un sistema testuale, per chiedere aiuto su un errore che compare a schermo bisogna descriverlo a parole; per analizzare un grafico bisogna trascriverne i valori; per riassumere una riunione bisogna prima averla trascritta. Con un sistema multimodale si può mostrare direttamente la schermata, caricare l'immagine del grafico, fornire la registrazione. L'interazione diventa più naturale e più rapida, e si possono affrontare compiti prima impossibili. Ma ci sono due conseguenze meno evidenti. La prima: si aggiunge un passaggio di interpretazione. Quando descriviamo noi la schermata, siamo noi a scegliere che cosa è rilevante; quando la carichiamo, è il sistema a interpretarla, e può sbagliare, per esempio leggendo male un numero o non notando un dettaglio. La seconda: si condividono più informazioni di quante se ne intendano condividere. Una schermata può contenere nomi, email, dati di clienti visibili in un'altra finestra; una fotografia può contenere documenti sulla scrivania; una registrazione contiene le voci di tutti i presenti.");
    opTag(s, 0);
    table(s, [["Compito", "Sistema testuale", "Sistema multimodale"],
      ["Un errore a schermo", "Descriverlo a parole", "Mostrare la schermata"],
      ["Un grafico da analizzare", "Trascriverne i valori", "Caricare l'immagine"],
      ["Una riunione da riassumere", "Trascriverla prima", "Fornire la registrazione"]],
      { y: 1.15, colW: [3.0, 3.0, 3.0], rowH: 0.45, fontSize: 13, accentCol: 2, blankCorner: false });
    await card(s, 0.5, 3.1, 4.35, 1.85, { icon: "FiEye", inline: true, head: "Un passaggio di interpretazione in più", headSize: 13, bodySize: 12, body: "Non scegliamo più noi che cosa è rilevante: lo interpreta il sistema, e può sbagliare." });
    await card(s, 5.15, 3.1, 4.35, 1.85, { icon: "FiLock", inline: true, head: "Più informazioni del previsto", headSize: 13, bodySize: 12, fill: C.accent6, body: "Nomi in un'altra finestra, documenti sulla scrivania, le voci di tutti i presenti." });
  }
  {
    const s = content("Comprendere e generare", "Una distinzione fondamentale del sottotema: comprendere e generare. Comprendere una modalità significa ricevere un contenuto in quella forma ed estrarne informazioni: descrivere un'immagine, trascrivere un audio, riassumere un video. Generare significa produrre un contenuto in quella forma: creare un'immagine, sintetizzare una voce, produrre un video. Le due capacità sono indipendenti: un sistema può comprendere bene le immagini senza saperle generare, o generare audio senza comprenderlo. La tabella in slide incrocia modalità e capacità con esempi concreti. Si aggiunge una terza operazione, la trasformazione, che combina le prime due: si comprende un contenuto in una modalità e se ne genera uno in un'altra, come da un audio a una trascrizione, da un testo a un'immagine, da un documento a una presentazione. Sono le tre operazioni del filo conduttore. Ricordiamo che i rischi sono diversi: comprendere può portare a errori di riconoscimento e di interpretazione; generare a contenuti plausibili ma inventati o non autentici; trasformare a perdite e alterazioni di significato.");
    opTag(s, [0, 1]);
    table(s, [["Modalità", "Comprendere", "Generare"],
      ["Immagini", "Descrivere una foto, leggere una schermata", "Creare un'illustrazione, modificare una foto"],
      ["Audio", "Trascrivere una riunione, riconoscere il parlato", "Sintetizzare una voce, leggere un testo"],
      ["Video", "Riassumere un filmato, individuare eventi", "Produrre una breve animazione"]],
      { y: 1.15, colW: [1.8, 3.6, 3.6], rowH: 0.5, fontSize: 12, blankCorner: false });
    shapeBox(s, 0.5, 3.35, 9.0, 0.85, C.accent6, "trasformare");
    txt(s, [{ text: "Trasformare ", options: { bold: true, color: C.accent1 } }, { text: "combina le due: comprendere in una modalità e generare in un'altra. Audio in testo, testo in immagine, documento in slide.", options: { color: C.text1 } }], { x: 0.7, y: 3.35, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
    txt(s, "Le capacità sono indipendenti: si può comprendere una modalità senza saperla generare, e viceversa.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Interazioni che combinano modalità", "Il valore più interessante della multimodalità non sta nel trattare ogni modalità separatamente, ma nel combinarle in una stessa interazione. Alcuni esempi tipici del lavoro quotidiano. Una fotografia di una lavagna con gli appunti di una riunione, accompagnata dalla richiesta di trasformarli in un elenco di azioni. Una schermata di un messaggio di errore, con la domanda 'che cosa devo fare?'. La foto di un componente guasto, con la richiesta di identificarlo e di trovare la procedura di sostituzione nel manuale caricato. Una registrazione di una riunione insieme alle slide presentate, per produrre un verbale che colleghi ciò che è stato detto a ciò che è stato mostrato. Una conversazione vocale con un assistente mentre si guida o si lavora con le mani occupate. In tutti questi casi, il sistema deve integrare informazioni di natura diversa, ed è proprio nell'integrazione che nascono sia il valore sia i rischi: il sistema può collegare in modo errato elementi di modalità diverse, per esempio attribuire a una slide un commento detto su un'altra.");
    opTag(s, [0, 2]);
    await iconGrid(s, [
      { icon: "FiClipboard", head: "Foto della lavagna + richiesta", body: "Gli appunti diventano un elenco di azioni" },
      { icon: "FiMonitor", head: "Schermata di errore + domanda", body: "'Che cosa devo fare?'" },
      { icon: "FiTool", head: "Foto di un componente + manuale", body: "Identificarlo e trovare la procedura" },
      { icon: "FiMic", head: "Registrazione + slide", body: "Un verbale che collega detto e mostrato" },
    ], 2, { y: 1.15, H: 2.6, headSize: 13, bodySize: 12 });
    banner(s, 3.95, "Il valore e i rischi nascono nell'integrazione: elementi di modalità diverse possono essere collegati in modo errato.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Un modello o più modelli?", "Una distinzione che il documento chiede di introdurre, senza entrare nelle architetture: la differenza tra un modello multimodale e un'applicazione che combina modelli specializzati. Un modello multimodale nativo è addestrato per elaborare più modalità insieme: riceve, per esempio, immagini e testo come input dello stesso modello. Un'applicazione che combina modelli specializzati collega più sistemi diversi: un modello di riconoscimento vocale trascrive l'audio, un modello linguistico elabora la trascrizione, un modello di sintesi vocale legge la risposta. Per l'utente le due soluzioni possono sembrare identiche: in entrambi i casi si parla e si riceve una risposta vocale. Ma il comportamento può essere diverso. In una catena di modelli, ogni passaggio può introdurre errori che si propagano, e alcune informazioni si perdono: se l'audio viene prima trascritto, il tono, le pause e l'enfasi della voce non arrivano al modello linguistico. In un modello nativo, alcune di queste informazioni possono essere conservate. Nella pratica, molti strumenti combinano entrambe le soluzioni. La conseguenza per l'utente è il principio del documento: le capacità effettive dipendono dal sistema impiegato.");
    opTag(s, -1);
    txt(s, "Applicazione che combina modelli specializzati", { x: 0.5, y: 1.12, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const ch = ["Voce", "Riconoscimento vocale", "Modello linguistico", "Sintesi vocale", "Risposta"];
    ch.forEach((t, i) => {
      chip(s, 0.5 + i * 1.84, 1.5, 1.6, 0.65, t, { fill: i === 0 || i === 4 ? C.background2 : C.accent6, fontSize: 11 });
      if (i < 4) arrow(s, 2.12 + i * 1.84, 1.66, 0.2);
    });
    txt(s, "Ogni passaggio può introdurre errori; tono, pause ed enfasi si perdono nella trascrizione", { x: 0.5, y: 2.2, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent5 });
    txt(s, "Modello multimodale nativo", { x: 0.5, y: 2.65, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.03, 1.6, 0.65, "Voce", { fill: C.background2, fontSize: 11 });
    arrow(s, 2.12, 3.19, 0.2);
    chip(s, 2.34, 3.03, 5.28, 0.65, "Un solo modello per più modalità", { fill: C.accent1, color: C.background1, fontSize: 12 });
    arrow(s, 7.64, 3.19, 0.2);
    chip(s, 7.86, 3.03, 1.6, 0.65, "Risposta", { fill: C.background2, fontSize: 11 });
    banner(s, 3.95, "Per l'utente possono sembrare identici, ma si comportano diversamente. Le capacità dipendono dal sistema.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Capacità che dipendono dal sistema", "La consapevolezza del sottotema, e uno dei principi metodologici di tutto il tema: la multimodalità può essere realizzata con architetture diverse, e le capacità effettive e le modalità supportate dipendono dal sistema impiegato. In pratica, l'etichetta 'multimodale' dice poco. Due strumenti entrambi definiti multimodali possono differire su molti aspetti: quali modalità accettano in ingresso e quali producono in uscita; quanto bene interpretano dettagli piccoli, testi nelle immagini, grafici complessi; quali lingue e accenti riconoscono nel parlato; quanto lunghi possono essere gli audio e i video elaborati; se un video viene analizzato in tutti i fotogrammi o solo in alcuni campionati; se elaborano i contenuti sul dispositivo o li inviano a un servizio esterno; quali regole d'uso e quali limiti applicano, per esempio sulla generazione di immagini di persone reali. Per questo il documento chiede di mantenere la distinzione tra concetti durevoli e funzionalità dei prodotti soggette a cambiamento. In questo modulo ci concentriamo sui primi; per le funzionalità specifiche, conviene verificare quelle degli strumenti autorizzati in azienda, che cambiano rapidamente.");
    opTag(s, -1);
    const q = ["Quali modalità in ingresso e in uscita?", "Quanto bene legge dettagli, testi, grafici?", "Quali lingue e accenti nel parlato?", "Quale durata massima di audio e video?", "Video analizzati in tutti i fotogrammi o solo in alcuni?", "Elaborazione sul dispositivo o su un servizio esterno?", "Quali regole d'uso, per esempio sulle persone reali?"];
    q.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.62;
      shapeBox(s, x, y, 4.4, 0.54, C.background2, "domanda " + (i + 1));
      txt(s, t, { x: x + 0.2, y, w: 4.0, h: 0.54, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 3.75, "L'etichetta 'multimodale' dice poco. Verificare le capacità degli strumenti autorizzati, che cambiano rapidamente.", { h: 0.75, fontSize: 13 });
    txt(s, "In questo modulo: concetti durevoli, non funzionalità dei prodotti.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("La multimodalità può essere realizzata con architetture differenti: capacità effettive e modalità supportate dipendono dal sistema impiegato.", "Sottotema 10.1  ·  Fondamenti dell'AI multimodale", "Concetto chiave del primo sottotema. Un sistema multimodale lavora con più modalità: testo, immagini, audio, video. Può comprenderle, generarle, trasformarle da una all'altra, e combinarle in un'unica interazione. Questo rende l'interazione più naturale e apre compiti nuovi, ma aggiunge un passaggio di interpretazione e può far condividere più informazioni del previsto. Un modello multimodale nativo e una catena di modelli specializzati possono sembrare uguali all'utente e comportarsi in modo diverso. Per questo le capacità vanno sempre verificate sullo strumento specifico. Esercizio suggerito: con lo strumento autorizzato in azienda, provare a fornire la stessa informazione in tre modalità diverse, per esempio una tabella scritta, una sua fotografia e una lettura ad alta voce, e confrontare le risposte.");

  // =====================================================================
  section("10.2 Immagini: comprendere");
  divider("10.2", "Comprensione e analisi delle immagini", "Descrivere ciò che appare in un'immagine non equivale a comprenderne significato, provenienza o contesto", "Entriamo nelle modalità, partendo dalla comprensione delle immagini. È una delle capacità multimodali più mature e più utili nel lavoro quotidiano: descrivere una fotografia, leggere una schermata, interpretare un diagramma, estrarre il testo da un'immagine. In questo sottotema, da conoscere e sperimentare, vediamo che cosa i sistemi sanno fare con le immagini, dove sbagliano più facilmente, e una distinzione importante: quella tra descrivere ciò che si vede e comprenderne il significato. Il confine con il Tema 8: lì abbiamo parlato di documenti scansionati per il loro contenuto testuale; qui parliamo di immagini come modalità visiva.");
  {
    const s = content("Le possibilità su un'immagine", "Le possibilità di comprensione delle immagini sono ampie. Interpretare fotografie: descrivere che cosa rappresentano, le persone, gli oggetti, l'ambiente, la situazione. Analizzare schermate e interfacce: capire che cosa mostra un programma, leggere un messaggio di errore, individuare dove cliccare. Interpretare diagrammi e contenuti visivi: schemi di processo, organigrammi, mappe, grafici. Leggere il testo presente nelle immagini: cartelli, etichette, lavagne, documenti fotografati, scritte a mano. Estrarre informazioni visive: quanti elementi, quali colori, quali condizioni, per esempio lo stato di un macchinario o di un magazzino. Identificare elementi e relazioni spaziali: che cosa sta sopra, accanto, dentro che cosa. Le applicazioni aziendali sono molte: supporto tecnico a partire da schermate, catalogazione di prodotti, controllo visivo di documenti o ambienti, accessibilità per persone con disabilità visive, digitalizzazione di appunti. In molti di questi casi il sistema fornisce in pochi secondi una descrizione utile. Ma, come vedremo, la sua affidabilità varia molto a seconda del tipo di compito.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiCamera", head: "Fotografie", body: "Persone, oggetti, ambienti, situazioni" },
      { icon: "FiMonitor", head: "Schermate e interfacce", body: "Errori, menu, dove cliccare" },
      { icon: "FiShare2", head: "Diagrammi e schemi", body: "Processi, organigrammi, mappe, grafici" },
      { icon: "FiType", head: "Testo nelle immagini", body: "Cartelli, etichette, lavagne, scritte a mano" },
      { icon: "FiSearch", head: "Informazioni visive", body: "Quantità, colori, condizioni, stato" },
      { icon: "FiMove", head: "Relazioni spaziali", body: "Sopra, accanto, dentro" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Una descrizione utile in pochi secondi. Ma l'affidabilità varia molto a seconda del compito.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Schermate e interfacce", "Le schermate meritano un approfondimento, perché sono probabilmente l'uso più frequente della comprensione visiva nel lavoro d'ufficio. Si fotografa o si cattura lo schermo e si chiede: che cosa significa questo errore? Come faccio a esportare questi dati? Dove si trova questa impostazione? Il sistema legge il testo dell'interfaccia, riconosce menu, pulsanti, campi, e può guidare passo per passo. È un supporto prezioso, che riduce le richieste ripetitive all'assistenza tecnica e aiuta con programmi poco familiari. Tre attenzioni. Prima: il sistema può riconoscere l'interfaccia ma non conoscere la versione specifica del programma o la configurazione aziendale, e suggerire passaggi che nel nostro caso non esistono. Seconda: le istruzioni operative su sistemi aziendali, specialmente quando comportano modifiche di configurazione o di dati, vanno seguite con prudenza, e in caso di dubbio con l'assistenza interna. Terza, la più importante: una schermata contiene spesso molto più di quanto si intende mostrare. Prima di condividerla, conviene ritagliarla sulla parte rilevante e verificare che non contenga dati personali, dati di clienti, credenziali, informazioni riservate in altre finestre o nelle notifiche.");
    opTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.6, "Domande tipiche", "Che cosa significa questo errore?\nCome esporto questi dati?\nDove si trova questa impostazione?", { fontSize: 13, fill: C.accent6 });
    await card(s, 5.15, 1.15, 4.35, 1.6, { icon: "FiThumbsUp", inline: true, head: "Il valore", headSize: 14, bodySize: 12, body: "Guida passo per passo, meno richieste ripetitive all'assistenza, aiuto con programmi poco familiari." });
    rowsLabel(s, [["Versione e configurazione", "Il sistema può suggerire passaggi che nel nostro caso non esistono"], ["Modifiche a sistemi aziendali", "Prudenza; in caso di dubbio, l'assistenza interna"], ["Prima di condividere", "Ritagliare; niente dati personali, credenziali, notifiche, altre finestre"]], { y: 2.95, h: 0.56, lw: 2.9 });
  }
  {
    const s = content("Diagrammi e testo nelle immagini", "Due compiti molto utili, con affidabilità diversa. Leggere il testo nelle immagini, compito che un tempo richiedeva software specifici di riconoscimento ottico, è oggi molto affidabile per testi stampati, chiari, in lingue diffuse. Diventa meno affidabile con scritture a mano, caratteri piccoli o sfocati, inclinazioni, riflessi, testi in lingue o alfabeti meno comuni. Gli errori più insidiosi riguardano numeri e codici: un 8 letto come 3, uno 0 come una O, una cifra saltata. A differenza delle parole, dove un errore produce spesso una parola senza senso facile da notare, un numero sbagliato resta un numero plausibile. Interpretare diagrammi, schemi di processo, organigrammi, mappe concettuali, è un compito più complesso, perché richiede di capire le relazioni tra gli elementi: le frecce, la gerarchia, la sequenza. I sistemi attuali lo fanno spesso bene con diagrammi semplici e ordinati, peggio con diagrammi densi, frecce che si incrociano, legende separate. L'analisi quantitativa dei grafici appartiene al Tema 9: qui ricordiamo solo che leggere valori da un grafico in un'immagine è un'operazione approssimativa, e i valori letti vanno trattati come stime.");
    opTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiType", head: "Testo nelle immagini", headSize: 15, bodySize: 12,
      body: bullets(["Molto affidabile: stampato, chiaro, lingue diffuse", "Meno: a mano, piccolo, sfocato, inclinato", "Insidiosi: numeri e codici, 8 e 3, 0 e O"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiShare2", head: "Diagrammi e schemi", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Richiedono di capire relazioni e sequenze", "Bene: semplici e ordinati", "Peggio: densi, frecce incrociate, legende separate"], { space: 5 }) });
    banner(s, 3.95, "Una parola sbagliata spesso si nota; un numero sbagliato resta un numero plausibile. I valori letti da un grafico sono stime.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Dettagli e relazioni spaziali", "Il sottotema chiede di conoscere i limiti nel riconoscimento dei dettagli. Pur essendo molto capaci, i sistemi di comprensione visiva hanno alcune debolezze ricorrenti, che è utile conoscere per sapere quando fidarsi meno. Contare: il numero di oggetti in un'immagine affollata è spesso approssimativo. Dettagli piccoli: un piccolo difetto, una cifra in un angolo, un'etichetta lontana possono non essere notati o essere letti male, anche perché le immagini vengono spesso ridotte di risoluzione prima dell'elaborazione. Relazioni spaziali: destra e sinistra, sopra e sotto, davanti e dietro, distanze e proporzioni sono fonte di errori frequenti. Orientamento e prospettiva: immagini ruotate, riflesse o con prospettive insolite. Elementi parzialmente nascosti o ambigui. In tutti questi casi, il problema è lo stesso visto per il testo nel Tema 3: il sistema risponde con la stessa sicurezza sia quando ha visto bene sia quando ha ricostruito in modo plausibile. Una tecnica pratica: per i dettagli importanti, chiedere al sistema dove si trova esattamente l'elemento descritto, e controllare; per i conteggi e le misure, considerare la risposta come una stima.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiHash", head: "Contare", body: "In immagini affollate, spesso approssimativo" },
      { icon: "FiZoomIn", head: "Dettagli piccoli", body: "Difetti, cifre, etichette lontane" },
      { icon: "FiMove", head: "Relazioni spaziali", body: "Destra e sinistra, distanze, proporzioni" },
      { icon: "FiRotateCw", head: "Orientamento", body: "Immagini ruotate, riflesse, prospettive insolite" },
    ], 4, { y: 1.2, h: 1.85, headSize: 13, bodySize: 12 });
    banner(s, 3.3, "Stessa sicurezza quando ha visto bene e quando ha ricostruito in modo plausibile.", { h: 0.7, fontSize: 14 });
    txt(s, "Per i dettagli importanti: chiedere dove si trova esattamente l'elemento, e controllare. Conteggi e misure: stime.", { x: 0.5, y: 4.2, w: 9, h: 0.6, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Descrivere o comprendere", "La distinzione più importante del sottotema. Descrivere ciò che appare in un'immagine non equivale a comprenderne il significato, la provenienza o il contesto. L'esempio in slide lo mostra. Davanti alla fotografia di un magazzino con alcuni scaffali vuoti, un sistema può dare una descrizione accurata: scaffali metallici, alcuni pieni, alcuni vuoti, un carrello elevatore, luce artificiale. Fin qui, descrizione. Ma che cosa significa? Gli scaffali vuoti indicano una carenza di scorte, un'area appena svuotata per un inventario, un reparto in riorganizzazione, o un magazzino nuovo non ancora riempito? La foto è di oggi o di due anni fa? È davvero il nostro magazzino? Queste domande riguardano il significato, la provenienza e il contesto, e non trovano risposta nell'immagine. Il sistema, se gli si chiede un'interpretazione, ne fornirà una plausibile, spesso con la stessa sicurezza della descrizione. È lo stesso passaggio visto nel Tema 9 dalla descrizione all'interpretazione dei dati, e nel Tema 7 dalla descrizione al giudizio. Nelle immagini è particolarmente insidioso, perché ciò che si vede sembra parlare da sé.");
    opTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.6, "Descrizione (ciò che appare)", "Scaffali metallici, alcuni pieni e alcuni vuoti, un carrello elevatore, luce artificiale.", { fontSize: 13, fill: C.accent6 });
    shapeBox(s, 5.15, 1.15, 4.35, 1.6, C.background2, "interpretazioni");
    txt(s, "Interpretazioni possibili", { x: 5.35, y: 1.22, w: 4.0, h: 0.3, fontSize: 11, bold: true, color: C.accent5 });
    txt(s, bullets(["Carenza di scorte", "Area svuotata per un inventario", "Reparto in riorganizzazione", "Magazzino nuovo"], { space: 2 }), { x: 5.35, y: 1.55, w: 4.0, h: 1.15, fontSize: 12, color: C.text1 });
    txt(s, "Domande a cui l'immagine non risponde", { x: 0.5, y: 2.95, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.33, 2.9, 0.55, "Che cosa significa?", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.33, 2.9, 0.55, "Quando è stata scattata?", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.33, 2.9, 0.55, "Da dove viene?", { fill: C.background2, fontSize: 12 });
    banner(s, 4.1, "Ciò che si vede sembra parlare da sé. Ma significato, provenienza e contesto non sono nell'immagine.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Immagini e persone", "Un aspetto delle immagini che merita attenzione specifica: la presenza di persone. Le fotografie e i video di lavoro contengono spesso persone: colleghi, clienti, visitatori, passanti. Tre considerazioni. La prima riguarda i dati personali: il volto e l'immagine di una persona sono dati personali, e caricarli in uno strumento AI è un trattamento di dati, che va fatto negli strumenti autorizzati e per finalità legittime. Le regole specifiche sono trattate nei Temi 17 e 18; qui basta ricordare che non si tratta di un'operazione neutra. La seconda riguarda il riconoscimento delle persone: molti strumenti di uso generale sono configurati per non identificare le persone dal volto, e l'identificazione biometrica è soggetta a limiti normativi specifici. Non è un compito per cui usare questi strumenti. La terza riguarda le inferenze: chiedere a un sistema di dedurre da una fotografia caratteristiche delle persone, come età, stato d'animo, intenzioni o condizioni personali, produce risposte che sembrano oggettive ma sono stime incerte, spesso influenzate da stereotipi, e possono essere usate in modo discriminatorio. Descrivere una scena è una cosa; giudicare le persone che vi compaiono è un'altra.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiUser", head: "Dati personali", body: "Volti e immagini sono dati personali: solo strumenti autorizzati, finalità legittime" },
      { icon: "FiUserX", head: "Identificazione", body: "Molti strumenti non identificano dal volto; limiti normativi specifici" },
      { icon: "FiAlertTriangle", head: "Inferenze sulle persone", body: "Età, stato d'animo, intenzioni: stime incerte, rischio di stereotipi" },
    ], 3, { y: 1.2, h: 2.1, headSize: 14, bodySize: 12 });
    banner(s, 3.55, "Descrivere una scena è una cosa; giudicare le persone che vi compaiono è un'altra.", { h: 0.75, fontSize: 15 });
    txt(s, "Volti e inferenze sulle persone sono soggetti a regole specifiche: in caso di dubbio, chiedere prima.", { x: 0.5, y: 4.45, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Descrivere ciò che appare in un'immagine non equivale a comprenderne necessariamente il significato, la provenienza o il contesto.", "Sottotema 10.2  ·  Comprensione e analisi delle immagini", "Concetto chiave del sottotema 10.2. I sistemi multimodali sanno interpretare fotografie, schermate, diagrammi e testo nelle immagini, con applicazioni concrete nel supporto tecnico, nella digitalizzazione, nell'accessibilità. Ma hanno limiti ricorrenti nei dettagli, nei conteggi, nelle relazioni spaziali e nei numeri, e rispondono con la stessa sicurezza quando vedono bene e quando ricostruiscono. Soprattutto, descrivere non è comprendere: significato, provenienza e contesto non sono nell'immagine. Le immagini con persone richiedono attenzioni specifiche. Esercizio suggerito: dare ai partecipanti una schermata o una foto fittizia con alcuni dettagli importanti piccoli, chiedere una descrizione all'AI e verificare quali dettagli sono stati letti correttamente, quali mancati e quali inventati.");
