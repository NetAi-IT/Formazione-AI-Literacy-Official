
  // =====================================================================
  section("10.6 Presentazioni");
  divider("10.6", "Presentazioni e materiali di comunicazione", "L'efficacia estetica di un materiale non garantisce accuratezza, completezza né coerenza narrativa", "Un'applicazione specifica che combina testo e immagini: le presentazioni e i materiali di comunicazione. È un ambito in cui l'AI è entrata rapidamente nel lavoro quotidiano: dalla descrizione di un argomento, o da un documento, si ottengono in pochi minuti slide impaginate, schemi, infografiche. In questo sottotema, da conoscere e sperimentare, vediamo che cosa si può fare, come valutare la qualità comunicativa, e la distinzione che il sottotema mette al centro: qualità estetica e accuratezza informativa sono cose diverse. Il confine con il 10.7: qui descriviamo l'applicazione, lì il principio generale delle conversioni tra modalità.");
  {
    const s = content("Dal testo alle slide", "Le possibilità che il sottotema elenca. Generare presentazioni da contenuti testuali: da una scaletta, da appunti, da una descrizione dell'argomento, il sistema produce un insieme di slide con titoli, punti, immagini e impaginazione. Trasformare documenti in materiali visivi: una relazione diventa una presentazione per la direzione, un manuale diventa una serie di schede, una procedura diventa un diagramma di flusso. Creare slide e schemi: diagrammi di processo, organigrammi, mappe concettuali, linee del tempo. Produrre infografiche: rappresentazioni visive sintetiche di informazioni e numeri. Organizzare visivamente le informazioni: scegliere che cosa mettere in evidenza, come raggrupparlo, in quale ordine presentarlo. Il valore principale è il tempo risparmiato nella parte più meccanica del lavoro, l'impaginazione, e la possibilità di partire da una struttura invece che da una pagina bianca. Questi strumenti possono essere integrati nei programmi di presentazione o essere servizi separati, e producono risultati di qualità molto variabile. In ogni caso, una presentazione generata è una bozza: struttura, contenuti e immagini vanno rivisti con la stessa attenzione di qualsiasi altro output.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiLayout", head: "Presentazioni da testo", body: "Da scaletta, appunti o descrizione" },
      { icon: "FiRepeat", head: "Documenti in materiali visivi", body: "Relazione in slide, procedura in diagramma" },
      { icon: "FiShare2", head: "Schemi e diagrammi", body: "Processi, organigrammi, linee del tempo" },
      { icon: "FiPieChart", head: "Infografiche", body: "Informazioni e numeri in sintesi visiva" },
      { icon: "FiGrid", head: "Organizzazione visiva", body: "Che cosa evidenziare, come raggruppare" },
      { icon: "FiEdit", head: "Una bozza", body: "Struttura, contenuti e immagini da rivedere", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Il valore: meno tempo sull'impaginazione, una struttura da cui partire invece di una pagina bianca.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Adattare ai destinatari", "Una delle possibilità più utili è l'adattamento di uno stesso contenuto a destinatari diversi, come visto nel Tema 8 per i testi. Da un unico documento di progetto si possono ottenere una presentazione sintetica per la direzione, con obiettivi, costi e rischi; una presentazione operativa per il gruppo di lavoro, con attività, tempi e responsabilità; un materiale formativo per chi dovrà usare il risultato, con istruzioni ed esempi; una scheda per la comunicazione interna, breve e visiva. L'AI è molto efficace in questo lavoro di adattamento, che a mano richiederebbe di ripartire più volte da capo. Il supporto alla comunicazione e alla formazione è uno degli usi più apprezzati: materiali formativi aggiornati rapidamente, versioni per livelli di esperienza diversi, schede riassuntive. Ma, come per i testi, ogni versione eredita gli errori della base, e ogni adattamento seleziona: la versione per la direzione può omettere un rischio importante, quella formativa può semplificare una regola fino a renderla scorretta. Ogni versione va controllata per il proprio destinatario.");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 2.6, 2.6, "Un documento di progetto", "Obiettivi, attività, tempi, costi, rischi, responsabilità, istruzioni.", { fontSize: 12, fill: C.accent6 });
    arrow(s, 3.2, 2.3, 0.35);
    const v = [["Direzione", "Obiettivi, costi, rischi"], ["Gruppo di lavoro", "Attività, tempi, responsabilità"], ["Formazione", "Istruzioni ed esempi"], ["Comunicazione interna", "Breve e visiva"]];
    v.forEach((e, i) => {
      const y = 1.15 + i * 0.66;
      shapeBox(s, 3.7, y, 5.8, 0.58, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 3.9, y, w: 2.3, h: 0.58, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 6.2, y, w: 3.2, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 3.95, "Ogni versione eredita gli errori della base e seleziona: va controllata per il proprio destinatario.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Coerenza tra testo e visivo", "Il sottotema chiede attenzione alla coerenza tra contenuti testuali e rappresentazioni visive. Quando un documento viene trasformato in un materiale visivo, possono nascere incoerenze tra ciò che dice il testo e ciò che mostra la grafica. L'esempio fittizio in slide mostra un'infografica generata da un rapporto: il testo del rapporto dice che le vendite online sono il 35 per cento del totale, ma il grafico a torta mostra una fetta che a occhio sembra metà; l'icona scelta per 'clienti business' rappresenta un consumatore con un carrello; la freccia del processo collega due fasi nell'ordine sbagliato. Sono errori tipici. Le proporzioni dei grafici decorativi non sempre corrispondono ai numeri, perché il sistema le disegna invece di calcolarle. Le icone e le immagini scelte possono suggerire significati diversi da quelli del testo. Gli schemi possono semplificare relazioni fino a renderle sbagliate. I numeri riportati nelle slide possono differire da quelli del documento di partenza, per arrotondamento o per errore. E il risultato è sempre visivamente gradevole, il che rende questi errori meno evidenti. Il controllo consiste nel confrontare ogni elemento visivo con il contenuto di partenza: numeri, proporzioni, sequenze, icone.");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 3.6, 1.5, "Rapporto (esempio fittizio)", "Le vendite online sono il 35% del totale.", { fontSize: 14, fill: C.accent6 });
    s.addChart(pres.charts.PIE, [{ name: "Canali", labels: ["Online", "Negozi"], values: [50, 50] }], { x: 4.3, y: 1.1, w: 2.0, h: 1.6, chartColors: [HEX.a5, HEX.a3], showLegend: false, showValue: false, showTitle: false, dataBorder: { pt: 1, color: "FFFFFF" } });
    txt(s, "Infografica: la fetta 'online' sembra metà", { x: 6.4, y: 1.2, w: 3.1, h: 1.4, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    const e = ["Proporzioni disegnate, non calcolate", "Icone che suggeriscono altro", "Schemi semplificati fino all'errore", "Numeri diversi dal documento"];
    e.forEach((t, i) => chip(s, 0.5 + i * 2.3, 2.9, 2.15, 0.7, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 3.85, "Il risultato è sempre gradevole, e questo rende gli errori meno evidenti. Confrontare ogni elemento visivo con il contenuto di partenza.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Estetica e accuratezza", "La distinzione centrale del sottotema, e la sua consapevolezza: l'efficacia estetica di un materiale non garantisce accuratezza, completezza né coerenza narrativa. È un principio che abbiamo incontrato più volte: nel Tema 7 la fluidità del testo che produce fiducia, nel Tema 9 la comunicazione efficace che non garantisce un'interpretazione corretta. Nelle presentazioni il fenomeno è particolarmente forte, per due motivi. Primo, una presentazione curata visivamente comunica professionalità e affidabilità, e chi la guarda tende a fidarsi dei contenuti. Secondo, le presentazioni sono spesso viste velocemente, in riunione, senza il tempo di verificare. Il sottotema indica tre dimensioni da valutare oltre all'estetica. L'accuratezza: le informazioni sono corrette e corrispondono alla fonte? La completezza: manca qualcosa di importante, come un rischio, una condizione, un dato sfavorevole? La coerenza narrativa: la sequenza delle slide costruisce un ragionamento solido, o salta passaggi, presenta conclusioni non sostenute dalle slide precedenti? Con l'AI, l'estetica è quasi gratuita, come visto nel Tema 9 per i report: per questo l'attenzione va spostata sulle altre tre dimensioni.");
    opTag(s, 2);
    shapeBox(s, 0.5, 1.15, 2.6, 2.6, C.background2, "estetica");
    await iconCircle(s, 1.45, 1.35, 0.7, "FiStar", C.accent2);
    txt(s, "Estetica", { x: 0.6, y: 2.15, w: 2.4, h: 0.42, fontSize: 17, bold: true, color: C.text1, align: "center" });
    txt(s, "Con l'AI, quasi gratuita", { x: 0.6, y: 2.6, w: 2.4, h: 0.6, fontSize: 12, italic: true, color: C.text2, align: "center" });
    txt(s, "≠", { x: 3.1, y: 1.9, w: 0.5, h: 0.8, fontSize: 36, bold: true, color: C.accent5, align: "center", valign: "middle" });
    const d = [["Accuratezza", "Corretto e corrispondente alla fonte?"], ["Completezza", "Manca un rischio, una condizione, un dato sfavorevole?"], ["Coerenza narrativa", "La sequenza costruisce un ragionamento solido?"]];
    d.forEach((e, i) => {
      const y = 1.15 + i * 0.89;
      shapeBox(s, 3.65, y, 5.85, 0.8, C.accent6, e[0]);
      txt(s, e[0], { x: 3.85, y, w: 2.2, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 6.05, y, w: 3.35, h: 0.8, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 4.0, "Le presentazioni si guardano in fretta, in riunione: la cura visiva genera fiducia senza tempo per verificare.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Valutare la qualità comunicativa", "Come si valuta, in pratica, un materiale di comunicazione prodotto con l'AI? Il sottotema parla di valutazione della qualità comunicativa. Proponiamo una breve lista di controllo, da applicare prima di usare o diffondere il materiale. Il messaggio: è chiaro qual è il messaggio principale, e lo si capisce in pochi secondi? Il destinatario: linguaggio, livello di dettaglio e tono sono adatti a chi lo riceverà? L'accuratezza: numeri, nomi, date, citazioni corrispondono alla fonte? La completezza: ci sono tutti gli elementi necessari, compresi rischi e limiti? La coerenza: testo, grafici, icone e immagini dicono la stessa cosa? La sequenza: l'ordine delle slide costruisce un ragionamento? La sobrietà: ci sono elementi decorativi superflui, testo eccessivo, immagini generiche che non aggiungono nulla? Le immagini: sono appropriate, rispettano l'identità visiva, non contengono persone reali o marchi altrui senza autorizzazione, e se sono generate è opportuno dichiararlo? Una lista così richiede pochi minuti, e intercetta la maggior parte dei problemi tipici. È anche un buon criterio per decidere quanto intervenire su una bozza generata.");
    opTag(s, 2);
    const c = [["Messaggio", "Chiaro in pochi secondi?"], ["Destinatario", "Linguaggio, dettaglio, tono adatti?"], ["Accuratezza", "Numeri, nomi, date come nella fonte?"], ["Completezza", "Rischi e limiti compresi?"], ["Coerenza", "Testo, grafici, icone dicono lo stesso?"], ["Sequenza", "L'ordine costruisce un ragionamento?"], ["Sobrietà", "Niente decorazioni e testo superflui?"], ["Immagini", "Appropriate, dichiarate se generate?"]];
    c.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.75;
      shapeBox(s, x, y, 4.4, 0.66, row % 2 ? C.accent6 : C.background2, e[0]);
      s.addShape(pres.shapes.RECTANGLE, { x: x + 0.15, y: y + 0.2, w: 0.26, h: 0.26, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 }, objectName: "casella " + e[0] });
      txt(s, e[0], { x: x + 0.55, y, w: 1.5, h: 0.66, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: x + 2.0, y, w: 2.3, h: 0.66, fontSize: 11, color: C.text1, valign: "middle" });
    });
    txt(s, "Pochi minuti per intercettare la maggior parte dei problemi, e decidere quanto intervenire sulla bozza.", { x: 0.5, y: 4.3, w: 9, h: 0.5, fontSize: 13, italic: true, bold: true, color: C.accent1 });
  }
  keySlide("L'efficacia estetica di un materiale non garantisce accuratezza, completezza né coerenza narrativa.", "Sottotema 10.6  ·  Presentazioni e materiali di comunicazione", "Concetto chiave del sottotema 10.6. L'AI genera presentazioni, schemi e infografiche da testi e documenti, e adatta i materiali a destinatari diversi, con un grande risparmio di tempo nella parte meccanica del lavoro. Ma la coerenza tra testo e visivo non è garantita, gli adattamenti selezionano, e soprattutto l'estetica, ormai quasi gratuita, genera una fiducia che va spostata su accuratezza, completezza e coerenza narrativa. Una breve lista di controllo aiuta a valutare la qualità comunicativa. Esercizio suggerito: generare con l'AI una breve presentazione a partire da un documento fittizio di due pagine, e far applicare ai partecipanti la lista di controllo, contando gli interventi necessari.");

  // =====================================================================
  section("10.7 Trasformazioni");
  divider("10.7", "Integrazione e trasformazione tra modalità", "Il valore delle conversioni dipende dalla loro utilità e dalla fedeltà, non solo dalla comodità", "Nei sottotemi precedenti abbiamo incontrato molte trasformazioni: dall'audio alla trascrizione, dal testo all'immagine, dal documento alla presentazione. In questo sottotema, da comprendere e sperimentare, le guardiamo insieme, come principio generale. Che cosa significa trasformare un contenuto da una modalità all'altra? Che cosa si guadagna e che cosa si può perdere? Due integrazioni sono centrali: l'accessibilità, perché le conversioni permettono modalità alternative di fruizione, e la coerenza delle informazioni tra modalità, perché ogni passaggio può introdurre omissioni, errori o variazioni di significato. Il confine con il 10.4: lì le capacità vocali, qui le catene tra modalità.");
  {
    const s = content("La mappa delle conversioni", "La tabella in slide mostra le principali conversioni tra modalità, con un esempio per ciascuna. Dal testo all'immagine: un'illustrazione generata da una descrizione. Dal testo all'audio: un documento letto da una voce sintetica. Dal testo al video: un breve video generato da una sceneggiatura. Dall'immagine al testo: la descrizione di una fotografia o l'estrazione del testo da una schermata. Dall'audio al testo: la trascrizione di una riunione. Dal video al testo: la sintesi di un webinar. Dal documento alla presentazione: una relazione trasformata in slide. E le combinazioni: testo, voce e immagini insieme in un video formativo, o la creazione di un contenuto a partire da più fonti di natura diversa, come una registrazione, delle slide e un documento. Ogni conversione ha un valore pratico: rendere un contenuto più accessibile, più rapido da consumare, adatto a un altro canale o a un altro destinatario. E ogni conversione comporta una scelta su che cosa portare nella nuova forma e che cosa lasciare indietro, perché le modalità non sono equivalenti: un'immagine contiene informazioni che un testo non riesce a descrivere del tutto, e un testo contiene precisazioni che un'immagine non riesce a mostrare.");
    opTag(s, 2);
    table(s, [["Da", "A", "Esempio"],
      ["Testo", "Immagine, audio, video", "Illustrazione, lettura vocale, video da sceneggiatura"],
      ["Immagine", "Testo", "Descrizione di una foto, testo da una schermata"],
      ["Audio", "Testo", "Trascrizione di una riunione"],
      ["Video", "Testo", "Sintesi di un webinar"],
      ["Documento", "Presentazione", "Relazione trasformata in slide"],
      ["Più fonti", "Un nuovo contenuto", "Registrazione, slide e documento in un verbale"]],
      { y: 1.15, colW: [2.0, 2.6, 4.4], rowH: 0.4, fontSize: 12, blankCorner: false });
    banner(s, 4.1, "Le modalità non sono equivalenti: ogni conversione sceglie che cosa portare nella nuova forma e che cosa lasciare indietro.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Le catene di trasformazione", "Spesso le trasformazioni non sono singole, ma formano catene. L'esempio in slide è tipico: una riunione viene registrata; la registrazione viene trascritta; la trascrizione viene riassunta; il riassunto viene trasformato in slide per la direzione; le slide vengono lette da una voce sintetica in un video di aggiornamento. Ogni passaggio è utile e, preso da solo, abbastanza affidabile. Ma gli errori si accumulano: una parola fraintesa nella trascrizione diventa un concetto sbagliato nel riassunto, che diventa un punto elenco nelle slide, che diventa un'affermazione nel video. E ogni passaggio seleziona: la trascrizione perde il tono e le esitazioni, il riassunto perde le obiezioni minori, le slide perdono le condizioni, il video perde la possibilità di rileggere. Alla fine della catena, il contenuto può essere molto lontano dall'originale, pur sembrando a ogni passaggio una trasformazione ragionevole del precedente. È il fenomeno del passaparola, applicato alle modalità. Due buone pratiche: limitare la lunghezza delle catene, partendo quando possibile dalla fonte originale invece che da una trasformazione intermedia; e, per i contenuti importanti, confrontare il risultato finale con la fonte originale, non solo con il passaggio precedente.");
    opTag(s, 2);
    const ch = ["Riunione", "Trascrizione", "Riassunto", "Slide", "Video"];
    const lost = ["", "Tono, esitazioni", "Obiezioni minori", "Condizioni", "Rileggibilità"];
    ch.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      chip(s, x, 1.25, 1.6, 0.7, t, { fill: i === 0 ? C.accent1 : C.accent6, color: i === 0 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 4) arrow(s, x + 1.62, 1.44, 0.2);
      if (i > 0) {
        txt(s, "Si perde:", { x, y: 2.05, w: 1.6, h: 0.25, fontSize: 9, color: C.text2, align: "center" });
        txt(s, lost[i], { x, y: 2.28, w: 1.6, h: 0.45, fontSize: 11, bold: true, color: C.accent5, align: "center" });
      }
    });
    shapeBox(s, 0.5, 2.95, 9.0, 0.8, C.background2, "passaparola");
    txt(s, [{ text: "Il passaparola delle modalità: ", options: { bold: true, color: C.accent1 } }, { text: "ogni passaggio sembra ragionevole, ma gli errori si accumulano e il risultato si allontana dall'originale.", options: { color: C.text1 } }], { x: 0.7, y: 2.95, w: 8.6, h: 0.8, fontSize: 13, valign: "middle" });
    chip(s, 0.5, 3.95, 4.4, 0.7, "Catene brevi: partire dalla fonte originale", { fill: C.accent6, fontSize: 12 });
    chip(s, 5.1, 3.95, 4.4, 0.7, "Confrontare il risultato finale con l'originale", { fill: C.accent6, fontSize: 12 });
  }
  {
    const s = content("Combinare più fonti", "Una forma particolare di trasformazione è la creazione di contenuti a partire da più fonti di natura diversa. Per esempio, un verbale che combina la registrazione di una riunione, le slide proiettate e il documento discusso; un materiale formativo che integra un video dimostrativo, un manuale e le domande frequenti; un rapporto di sopralluogo che combina fotografie, note vocali e una lista di controllo. La combinazione ha un grande valore, perché ogni fonte compensa i limiti delle altre: le slide chiariscono a che cosa si riferiva una frase della registrazione, le fotografie documentano ciò che le note descrivono. Ma introduce un rischio specifico: il collegamento errato tra elementi di fonti diverse. Il sistema può attribuire un commento alla slide sbagliata, associare una fotografia alla nota di un'altra stanza, combinare un dato del documento con un'affermazione della registrazione che si riferiva ad altro. E il risultato combinato, ben integrato e scorrevole, non mostra le giunture tra le fonti, rendendo difficile capire da quale fonte venga ciascuna informazione. Per i contenuti importanti, conviene chiedere che ogni affermazione indichi la fonte da cui proviene, applicando alle modalità il principio di tracciabilità visto nel Tema 8.");
    opTag(s, 2);
    const f = [["FiMic", "Registrazione"], ["FiLayout", "Slide"], ["FiFileText", "Documento"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.15 + i * 0.85;
      shapeBox(s, 0.5, y, 2.6, 0.72, C.background2, f[i][1]);
      await iconCircle(s, 0.62, y + 0.12, 0.48, f[i][0]);
      txt(s, f[i][1], { x: 1.2, y, w: 1.8, h: 0.72, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
    }
    arrow(s, 3.2, 2.0, 0.4);
    shapeBox(s, 3.75, 1.15, 2.2, 2.4, C.accent1, "verbale");
    txt(s, "Un verbale integrato", { x: 3.85, y: 1.15, w: 2.0, h: 2.4, fontSize: 15, bold: true, color: C.background1, align: "center", valign: "middle" });
    await card(s, 6.2, 1.15, 3.3, 2.4, { icon: "FiAlertTriangle", head: "Collegamenti errati", headSize: 14, bodySize: 12, iconBg: C.accent5, body: "Un commento sulla slide sbagliata, una foto con la nota di un'altra stanza. E le giunture non si vedono." });
    banner(s, 3.8, "Ogni fonte compensa i limiti delle altre. Per i contenuti importanti: ogni affermazione indichi la sua fonte.", { h: 0.75, fontSize: 13 });
    txt(s, "Tracciabilità: ogni elemento del risultato deve poter essere ricondotto alla sua fonte.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Conversioni per l'accessibilità", "L'integrazione B torna in questo sottotema in forma generale: le conversioni tra modalità permettono modalità alternative di fruizione dei contenuti. Nel 10.4 l'abbiamo vista per l'audio; qui la estendiamo a tutte le modalità. Un contenuto disponibile in una sola modalità esclude chi non può o non riesce a usarla. Un contenuto disponibile in più modalità include. Le conversioni più utili per l'accessibilità: testi alternativi per le immagini, che descrivono a chi non vede ciò che l'immagine mostra; sottotitoli e trascrizioni per audio e video; versioni audio di documenti; descrizioni testuali di grafici e diagrammi; versioni semplificate di testi complessi; traduzioni. L'AI rende queste conversioni molto più rapide ed economiche, e quindi possibili su scala, per esempio su tutti i video formativi o su tutte le immagini della intranet. È un'opportunità concreta per rendere più inclusiva la comunicazione aziendale. Valgono però le stesse condizioni viste per tutte le trasformazioni: un testo alternativo generico, come 'immagine di un grafico', non aiuta; uno sbagliato, come una descrizione che inverte una tendenza, danneggia proprio chi non può verificare. Per i contenuti importanti, le conversioni per l'accessibilità vanno controllate come qualsiasi altro contenuto.");
    opTag(s, 2);
    table(s, [["Contenuto originale", "Conversione accessibile", "Per chi"],
      ["Immagine", "Testo alternativo, descrizione", "Chi non vede"],
      ["Audio e video", "Sottotitoli, trascrizione", "Chi non sente, luoghi rumorosi"],
      ["Documento", "Versione audio, versione semplificata", "Chi fatica a leggere"],
      ["Grafico o diagramma", "Descrizione testuale", "Chi non vede"],
      ["Qualsiasi contenuto", "Traduzione", "Chi non conosce la lingua"]],
      { y: 1.15, colW: [2.6, 3.4, 3.0], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 3.85, "'Immagine di un grafico' non aiuta; una descrizione che inverte una tendenza danneggia chi non può verificare.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Coerenza tra modalità", "L'integrazione C del tema: la coerenza delle informazioni tra modalità diverse. Ogni passaggio tra formati può introdurre omissioni, errori o variazioni di significato, per cui occorre confrontare il contenuto risultante con quello di origine. Il sottotema la chiama coerenza semantica: il significato deve restare lo stesso, anche se la forma cambia. Le alterazioni tipiche sono tre, come abbiamo visto nel Tema 8 per i documenti, e qui si presentano in forme specifiche. Le omissioni: ciò che una modalità non riesce a esprimere si perde, come il tono ironico di una frase nella trascrizione, o una condizione scritta in piccolo che non entra nell'infografica. Le reinterpretazioni: la conversione impone un'interpretazione, come un'immagine generata da una descrizione ambigua, che sceglie una delle possibili letture, o una sintesi vocale che, con l'intonazione, trasforma una domanda in un'affermazione. Le alterazioni: un contenuto cambia, come un numero letto male in una schermata, o un'immagine generata che aggiunge dettagli non presenti nel testo. L'esempio fittizio in slide mostra una frase detta in riunione con tono dubitativo e la sua trascrizione, che la trasforma in un'affermazione. Nessun errore di parola, ma il significato è cambiato.");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 4.35, 1.3, "Detto in riunione (esempio fittizio)", "\"Sì... il budget dovrebbe bastare...\" (tono dubitativo, lunga pausa)", { fontSize: 13, fill: C.accent6 });
    docBox(s, 5.15, 1.15, 4.35, 1.3, "Trascrizione e sintesi", "\"Il budget è sufficiente.\"", { fontSize: 14, bar: C.accent5, labelColor: C.accent5 });
    const t = [["Omissioni", "Ciò che la nuova modalità non esprime si perde: il tono, una condizione in piccolo"], ["Reinterpretazioni", "La conversione sceglie una lettura: un'immagine da una descrizione ambigua"], ["Alterazioni", "Il contenuto cambia: un numero letto male, un dettaglio aggiunto"]];
    rowsLabel(s, t, { y: 2.65, h: 0.55, lw: 2.2 });
  }
  {
    const s = content("Confrontare con l'origine", "Come si controlla, in pratica, la fedeltà di una trasformazione tra modalità? Il principio è semplice: confrontare il contenuto risultante con quello di origine. La difficoltà è che le due modalità sono diverse, e il confronto richiede di passare dall'una all'altra. Alcune tecniche pratiche. Identificare prima gli elementi critici che devono sopravvivere alla trasformazione: numeri, nomi, impegni, condizioni, avvertenze, il messaggio principale. Controllare quegli elementi nel risultato, uno per uno. Per le trascrizioni, ascoltare i passaggi in cui compaiono numeri, nomi e decisioni. Per le immagini generate da testi, verificare che non aggiungano elementi non previsti e che rappresentino correttamente ciò che il testo dice. Per le presentazioni ricavate da documenti, confrontare numeri e conclusioni con il documento. Per le descrizioni di immagini, guardare l'immagine. Coinvolgere, quando serve, chi conosce l'originale: chi era presente alla riunione, chi ha scritto il documento. La consapevolezza del sottotema riassume il criterio: il valore delle conversioni è legato alla loro utilità e alla fedeltà delle informazioni, non soltanto alla comodità o alla rapidità del processo. Una conversione rapida ma infedele non fa risparmiare tempo: lo sposta su chi dovrà correggerne le conseguenze.");
    opTag(s, 2);
    numList(s, ["Identificare gli elementi critici: numeri, nomi, impegni, condizioni, messaggio", "Controllarli nel risultato, uno per uno", "Tornare all'originale: ascoltare, guardare, rileggere i passaggi critici", "Coinvolgere chi conosce l'originale, quando serve"], { y: 1.15, h: 0.55, fontSize: 13 });
    banner(s, 3.65, "Una conversione rapida ma infedele non fa risparmiare tempo: lo sposta su chi dovrà correggerne le conseguenze.", { h: 0.85, fontSize: 13 });
    txt(s, "Il valore delle conversioni: utilità e fedeltà, non solo comodità e rapidità.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 13, italic: true, bold: true, color: C.accent1 });
  }
  keySlide("Il valore delle conversioni è legato alla loro utilità e alla fedeltà delle informazioni, non soltanto alla comodità o alla rapidità del processo.", "Sottotema 10.7  ·  Integrazione e trasformazione tra modalità", "Concetto chiave del sottotema 10.7. Le conversioni tra modalità sono molte e utili: testo in immagine, audio in testo, documento in slide, più fonti in un unico contenuto. Rendono i contenuti più accessibili, rapidi da consumare, adatti a canali diversi. Ma le modalità non sono equivalenti, le catene accumulano errori, la combinazione di fonti può creare collegamenti errati, e ogni passaggio può omettere, reinterpretare o alterare. Il controllo consiste nel confrontare il risultato con l'origine sugli elementi critici. Esercizio suggerito: far percorrere ai partecipanti una catena di tre trasformazioni, per esempio da un breve audio fittizio a una trascrizione, a un riassunto, a una slide, e confrontare il risultato finale con l'audio originale, elencando che cosa si è perso o alterato.");

  // =====================================================================
  section("10.8 Autenticità e affidabilità");
  divider("10.8", "Limiti, autenticità e affidabilità", "Distinguere realismo, provenienza e accuratezza è essenziale per usare in modo critico i contenuti multimodali", "Ultimo sottotema, di consapevolezza critica. Raccogliamo i limiti incontrati nel modulo e affrontiamo la questione più importante del tema: l'autenticità. Con la generazione di immagini, voci e video realistici, il legame tra ciò che sembra reale e ciò che è reale si è indebolito. In questo sottotema vediamo gli errori tipici dei contenuti multimodali, i contenuti sintetici realistici e i deepfake, la distinzione tra realismo, autenticità e accuratezza, il tema della provenienza, e introduciamo, senza analisi normativa, i diritti su contenuti, immagini e voci delle persone. La verifica forense tecnica è solo da accennare.");
  {
    const s = content("Gli errori tipici", "Riassumiamo gli errori tipici dei contenuti multimodali incontrati nel modulo, che il sottotema elenca. Errori di riconoscimento visivo: dettagli non visti, numeri letti male, conteggi sbagliati, relazioni spaziali invertite. Errori di riconoscimento sonoro: nomi, terminologia e numeri fraintesi, frasi aggiunte, affermazioni attribuite alla persona sbagliata. Incoerenze nei contenuti generati: dettagli anatomici o strutturali impossibili, testi deformati, oggetti che cambiano da un fotogramma all'altro. Alterazioni di immagini e materiali originali: modifiche che cambiano ciò che un'immagine documenta. Perdita di informazioni nei passaggi tra modalità: tono, condizioni, obiezioni, contesto. Accuratezza delle trascrizioni e fedeltà semantica delle trasformazioni. Non ripetiamo la teoria generale degli errori del Tema 3: il punto qui è che nei contenuti multimodali questi errori hanno una caratteristica comune. Sono difficili da vedere, perché il risultato è visivamente o acusticamente convincente, e perché controllare richiede di tornare a una modalità diversa: riascoltare, riguardare, confrontare. Come dice l'integrazione C: trasformazioni apparentemente corrette possono modificare informazioni rilevanti senza errori immediatamente evidenti.");
    opTag(s, [0, 1, 2]);
    const m = [["Riconoscimento visivo", ["Dettagli non visti", "Numeri letti male", "Conteggi e spazi"]], ["Riconoscimento sonoro", ["Nomi e termini", "Frasi aggiunte", "Attribuzioni errate"]], ["Contenuti generati", ["Dettagli impossibili", "Testi deformati", "Incoerenze nel tempo"]], ["Trasformazioni", ["Tono e contesto persi", "Condizioni omesse", "Significato alterato"]]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.25, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 1.9, h: 0.5, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, bullets(e[1], { space: 5 }), { x: x + 0.15, y: 1.78, w: 1.92, h: 1.5, fontSize: 12, color: C.text1 });
    });
    banner(s, 3.6, "Il tratto comune: il risultato è convincente, e controllare richiede di tornare a un'altra modalità.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Contenuti sintetici e deepfake", "I contenuti sintetici realistici sono immagini, audio e video generati o modificati dall'AI in modo da sembrare registrazioni della realtà. Si parla di deepfake quando rappresentano persone reali che dicono o fanno cose che non hanno mai detto o fatto: un video in cui un dirigente annuncia una decisione, una telefonata con la voce di un collega, una fotografia di un evento mai accaduto. La tecnologia ha usi legittimi: doppiaggio, effetti speciali, formazione, accessibilità, satira dichiarata. Ma è anche usata per frodi, disinformazione, danni alla reputazione. In ambito aziendale il rischio più concreto è la frode basata sull'imitazione della voce o del volto di persone conosciute. Sono stati documentati casi di questo tipo: nel 2019 la stampa ha riportato il caso di un'azienda energetica britannica il cui amministratore trasferì circa 220.000 euro dopo una telefonata in cui la voce del suo superiore era stata imitata; nel 2024 è stato riportato il caso di una multinazionale in cui un dipendente della sede di Hong Kong trasferì l'equivalente di circa 25 milioni di dollari dopo una videochiamata in cui i colleghi, compreso il direttore finanziario, erano stati ricreati artificialmente. Lo schema è sempre simile: una richiesta urgente, da una persona di cui ci si fida, attraverso un canale che sembra sicuro.");
    opTag(s, 1);
    await card(s, 0.5, 1.15, 4.35, 2.0, { icon: "FiCheckCircle", head: "Usi legittimi", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Doppiaggio, effetti, formazione", "Accessibilità, satira dichiarata"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.0, { icon: "FiAlertTriangle", head: "Usi dannosi", headSize: 15, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Frodi con voce o volto imitati", "Disinformazione, danni alla reputazione"], { space: 4 }) });
    shapeBox(s, 0.5, 3.35, 9.0, 1.6, C.text1, "casi");
    txt(s, "Casi riportati dalla stampa", { x: 0.75, y: 3.42, w: 8.5, h: 0.32, fontSize: 13, bold: true, color: C.accent6 });
    txt(s, bullets(["2019: voce di un superiore imitata al telefono, circa 220.000 euro trasferiti", "2024: videochiamata con colleghi ricreati artificialmente, circa 25 milioni di dollari trasferiti"], { space: 4 }), { x: 0.75, y: 3.78, w: 8.5, h: 0.75, fontSize: 12, color: C.background1 });
    txt(s, "Lo schema: richiesta urgente, persona di fiducia, canale che sembra sicuro.", { x: 0.75, y: 4.55, w: 8.5, h: 0.32, fontSize: 12, italic: true, bold: true, color: C.accent3 });
  }
  {
    const s = content("Realismo, autenticità, accuratezza", "Il cuore del sottotema e l'integrazione A del tema: contenuto realistico e contenuto autentico. Il documento propone di distinguere tre caratteristiche che nel linguaggio comune si confondono. Il realismo: il contenuto appare plausibile, sembra reale. Un'immagine sintetica può somigliare in tutto a una fotografia. L'autenticità: l'origine del contenuto è effettivamente accertabile. Un video ha una provenienza documentata: chi l'ha girato, quando, dove, con quale dispositivo. L'accuratezza: le informazioni rappresentate corrispondono ai fatti o alla fonte. Una descrizione riporta fedelmente quanto documentato. Le tre caratteristiche sono indipendenti, e il documento offre tre esempi. Un'immagine sintetica può essere realistica senza essere autentica come testimonianza di un evento. Una registrazione autentica può contenere affermazioni false: è vero che quella persona ha detto quelle cose, ma ciò che ha detto può essere sbagliato. Una presentazione dall'aspetto professionale può riportare dati inesatti. Il messaggio dell'integrazione: la somiglianza con la realtà non dimostra l'origine, l'autenticità o la verità di quanto rappresentato. Davanti a un contenuto multimodale, le tre domande vanno poste separatamente: sembra reale? Da dove viene? Ciò che mostra è vero?");
    opTag(s, -1);
    table(s, [["Caratteristica", "Significato", "Esempio"],
      ["Realismo", "Il contenuto appare plausibile", "Un'immagine sintetica somiglia a una fotografia"],
      ["Autenticità", "L'origine è effettivamente accertabile", "Un video ha una provenienza documentata"],
      ["Accuratezza", "Corrisponde ai fatti o alla fonte", "Una descrizione riporta fedelmente quanto documentato"]],
      { y: 1.15, colW: [2.0, 3.2, 3.8], rowH: 0.5, fontSize: 12, blankCorner: false });
    const e = ["Realistica ma non autentica: un'immagine sintetica", "Autentica ma non accurata: una registrazione con affermazioni false", "Professionale ma non accurata: una presentazione con dati inesatti"];
    e.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.25, 2.86, 0.75, t, { fill: C.accent6, fontSize: 11 }));
    banner(s, 4.2, "Tre domande separate: sembra reale? Da dove viene? Ciò che mostra è vero?", { h: 0.7, fontSize: 15 });
  }
  {
    const s = content("Provenienza e verifica", "Se il realismo non basta, come si accerta l'autenticità? La risposta sta nella provenienza: la storia documentata di un contenuto, da chi l'ha creato a come è arrivato a noi. Esistono strumenti tecnici che aiutano. I metadati, cioè informazioni incorporate nei file, come data, dispositivo, posizione; ma si possono modificare o rimuovere facilmente. Le filigrane digitali, inserite da alcuni sistemi di generazione nei contenuti che producono, a volte invisibili; ma non tutti i sistemi le usano, e possono essere alterate. Gli standard di provenienza, come le credenziali di contenuto promosse dalla coalizione C2PA, che registrano in modo verificabile l'origine e le modifiche di un contenuto; utili, ma ancora non universalmente adottati. Le etichette applicate dalle piattaforme ai contenuti generati. Il documento ricorda un punto importante: anche etichette, metadati e informazioni sulla provenienza richiedono interpretazione, e non sempre costituiscono una prova definitiva della veridicità dei fatti rappresentati. L'assenza di un'etichetta non prova che un contenuto sia autentico. La verifica forense tecnica è solo da accennare. Per l'utente, la verifica più efficace è spesso di tipo organizzativo: risalire alla fonte, chiedere conferma attraverso un canale indipendente, confrontare con altre fonti.");
    opTag(s, -1);
    const t = [["Metadati", "Data, dispositivo, posizione", "Facili da modificare o rimuovere"], ["Filigrane digitali", "Inserite da alcuni generatori", "Non universali, alterabili"], ["Credenziali di contenuto (C2PA)", "Origine e modifiche verificabili", "Non ancora adottate ovunque"], ["Etichette delle piattaforme", "Segnalano contenuti generati", "L'assenza non prova l'autenticità"]];
    table(s, [["Strumento", "Che cosa offre", "Limite"]].concat(t), { y: 1.15, colW: [3.0, 3.0, 3.0], rowH: 0.42, fontSize: 12, blankCorner: false });
    banner(s, 3.4, "Anche etichette e metadati richiedono interpretazione: non sono una prova definitiva della veridicità dei fatti.", { h: 0.75, fontSize: 13 });
    txt(s, "Verifica più efficace per l'utente", { x: 0.5, y: 4.25, w: 3.0, h: 0.6, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
    chip(s, 3.5, 4.25, 1.9, 0.6, "Risalire alla fonte", { fill: C.accent6, fontSize: 11 });
    chip(s, 5.5, 4.25, 2.0, 0.6, "Canale indipendente", { fill: C.accent6, fontSize: 11 });
    chip(s, 7.6, 4.25, 1.9, 0.6, "Altre fonti", { fill: C.accent6, fontSize: 11 });
  }
  {
    const s = content("Difendersi dalle frodi", "Dal punto di vista pratico, la difesa più efficace contro le frodi basate su contenuti sintetici non è tecnica, ma organizzativa e comportamentale. Il motivo è che riconoscere un deepfake di buona qualità a occhio o a orecchio è sempre più difficile, e gli strumenti di rilevamento automatico non sono infallibili. Conviene quindi non basare decisioni importanti sul solo riconoscimento di una voce o di un volto. Le contromisure più efficaci. Verifica su un canale indipendente: davanti a una richiesta insolita, specialmente di pagamenti, credenziali o dati riservati, richiamare la persona a un numero noto, non a quello fornito nel messaggio, o confermare di persona. Procedure che non dipendono dalla voce: autorizzazioni a più firme, controlli incrociati, regole che non si possono saltare nemmeno per una richiesta del vertice. Diffidenza verso l'urgenza e la segretezza: sono i due ingredienti tipici delle frodi, perché impediscono la verifica. Parole o domande di controllo concordate per le situazioni delicate. Segnalazione: in caso di dubbio, segnalare alla sicurezza aziendale, anche se poi la richiesta si rivela autentica. Nessuno dovrebbe sentirsi in imbarazzo nel verificare una richiesta del proprio superiore: è una procedura, non una mancanza di fiducia.");
    opTag(s, -1);
    await iconGrid(s, [
      { icon: "FiPhone", head: "Canale indipendente", body: "Richiamare a un numero noto, confermare di persona" },
      { icon: "FiUsers", head: "Procedure robuste", body: "Più firme, controlli incrociati, nessuna eccezione" },
      { icon: "FiClock", head: "Urgenza e segretezza", body: "Gli ingredienti tipici delle frodi" },
      { icon: "FiKey", head: "Domande di controllo", body: "Concordate per le situazioni delicate" },
      { icon: "FiFlag", head: "Segnalare", body: "In caso di dubbio, alla sicurezza aziendale" },
      { icon: "FiShield", head: "Non solo riconoscere", body: "Voce e volto non bastano più", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Verificare una richiesta del proprio superiore è una procedura, non una mancanza di fiducia.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Comunicazione fuorviante", "Il sottotema include i rischi di comunicazione fuorviante, che riguardano non solo i contenuti ricevuti, ma anche quelli che produciamo. Un'azienda può comunicare in modo fuorviante con contenuti multimodali anche senza alcuna intenzione di ingannare. Alcuni esempi. Usare immagini generate che sembrano fotografie reali di prodotti, sedi, persone, eventi, senza dichiararlo: chi le vede può credere che documentino la realtà. Usare immagini generate di 'clienti' o 'dipendenti' che non esistono, in materiali che suggeriscono testimonianze reali. Modificare fotografie in modo da migliorare l'aspetto di un prodotto o di un luogo oltre il ritocco accettabile. Usare voci sintetiche che imitano persone reali, o presentatori virtuali senza chiarire che non sono persone. Presentare come documentazione un video o un'immagine ricostruiti. In ciascun caso, il problema non è l'uso dell'AI in sé, ma la differenza tra ciò che il contenuto sembra e ciò che è. Il principio guida è la trasparenza: quando un contenuto sintetico potrebbe essere scambiato per una rappresentazione della realtà, conviene dichiararlo. Alcune norme e piattaforme lo richiedono già esplicitamente. In particolare, dal 2 agosto 2026 l'articolo 50 dell'AI Act chiede a chi usa sistemi AI di dichiarare i contenuti deepfake, cioè immagini, audio o video che ritraggono in modo realistico persone, luoghi o eventi, e ai fornitori di sistemi generativi di marcare i contenuti prodotti in modo leggibile dalle macchine; per i sistemi già sul mercato prima di agosto, la marcatura è rinviata al 2 dicembre 2026 dal Regolamento 2026/1744 (Digital Omnibus). Nel giugno 2026 è stato finalizzato anche un codice di condotta europeo sulla trasparenza dei contenuti generati. Questi dettagli provengono in parte da fonti secondarie: da verificare sul testo ufficiale prima di ogni edizione. Le regole specifiche sono trattate nei Temi 17 e 18.");
    opTag(s, [1, 2]);
    rowsLabel(s, [["Immagini come foto", "Prodotti, sedi, eventi generati che sembrano reali"], ["Persone inesistenti", "'Clienti' o 'dipendenti' in finte testimonianze"], ["Ritocchi eccessivi", "Un prodotto o un luogo migliore di quanto sia"], ["Voci e presentatori", "Sintetici, senza chiarire che non sono persone"], ["Ricostruzioni", "Presentate come documentazione"]], { y: 1.15, h: 0.5, lw: 2.6 });
    banner(s, 4.1, "Principio guida: trasparenza. Dal 2 agosto 2026 l'AI Act chiede di dichiarare i contenuti deepfake (art. 50).", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Diritti su contenuti, immagini, voci", "Il documento chiede di introdurre il tema dei diritti sui contenuti, sulle immagini e sulle voci delle persone, senza un'analisi normativa, che appartiene ai Temi 17 e 18. Ci limitiamo quindi a segnalare le questioni principali, perché i partecipanti sappiano riconoscere quando serve un approfondimento. I diritti sui contenuti di partenza: usare come base per una trasformazione un'immagine, un video, una musica, un testo di cui non si hanno i diritti non diventa lecito perché passa attraverso un sistema AI. I diritti sui contenuti generati: la titolarità dei contenuti prodotti con l'AI è una questione ancora in evoluzione, e le condizioni d'uso degli strumenti variano. L'immagine delle persone: usare il volto di una persona, anche modificato o in un contenuto generato, richiede di regola il suo consenso. La voce delle persone: anche la voce è un elemento dell'identità personale, e riprodurla o imitarla senza consenso è problematico, oltre che rischioso. Gli stili e le opere riconoscibili: imitare lo stile di un artista vivente, riprodurre personaggi, marchi, opere protette. Il comportamento pratico è semplice: nei casi dubbi, specialmente per contenuti destinati all'esterno, chiedere prima a chi in azienda si occupa di questi aspetti.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiFile", head: "Contenuti di partenza", body: "Senza diritti non diventano leciti passando per l'AI" },
      { icon: "FiFileText", head: "Contenuti generati", body: "Titolarità in evoluzione, condizioni d'uso variabili" },
      { icon: "FiUser", head: "Immagine delle persone", body: "Di regola serve il consenso" },
      { icon: "FiMic", head: "Voce delle persone", body: "Parte dell'identità: non imitarla senza consenso" },
      { icon: "FiStar", head: "Stili e opere riconoscibili", body: "Artisti viventi, personaggi, marchi" },
      { icon: "FiHelpCircle", head: "Nei casi dubbi", body: "Chiedere prima a chi se ne occupa in azienda", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    txt(s, "Un'introduzione, senza analisi normativa: nei casi dubbi, chiedere prima a chi se ne occupa in azienda.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Verifica e supervisione", "L'ultimo punto del sottotema: la necessità di verifica e supervisione, proporzionata all'uso, come in tutto il percorso. Proponiamo tre livelli, coerenti con quelli dei temi precedenti. Per uso personale o esplorativo, come capire una schermata, farsi un'idea di un video, generare un concept, basta un controllo di plausibilità e la consapevolezza dei limiti. Per uso interno, come verbali, materiali formativi, presentazioni interne, conviene controllare gli elementi critici sull'originale: numeri, nomi, impegni, attribuzioni, e far rivedere a chi conosce il contenuto. Per uso esterno o decisionale, come comunicazione al pubblico, materiali per clienti, contenuti usati come prova o documentazione, decisioni basate su immagini o registrazioni, serve una verifica completa: provenienza accertata, confronto sistematico con l'originale, diritti verificati, trasparenza sull'uso di contenuti sintetici, e il coinvolgimento delle funzioni competenti. Due fattori alzano il livello: la presenza di persone reali e la possibilità che il contenuto venga scambiato per una rappresentazione della realtà. La consapevolezza del sottotema chiude il tema: distinguere realismo, provenienza e accuratezza è essenziale per utilizzare in modo critico i contenuti multimodali.");
    opTag(s, -1);
    const lv = [["Personale o esplorativo", "Schermate, concept, farsi un'idea", "Plausibilità e consapevolezza dei limiti", C.background2, C.text1], ["Interno", "Verbali, formazione, presentazioni interne", "Elementi critici sull'originale, revisione di chi conosce", C.accent6, C.text1], ["Esterno o decisionale", "Pubblico, clienti, prove, decisioni", "Provenienza, confronto sistematico, diritti, trasparenza", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.9;
      shapeBox(s, 0.5, y, 9.0, 0.8, l[3], l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.3, h: 0.8, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 3.0, y, w: 2.9, h: 0.8, fontSize: 12, color: l[4], valign: "middle" });
      txt(s, l[2], { x: 6.0, y, w: 3.35, h: 0.8, fontSize: 12, bold: true, color: l[4], valign: "middle" });
    });
    txt(s, "Alzano il livello", { x: 0.5, y: 3.95, w: 2.3, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.8, 3.95, 3.25, 0.55, "Persone reali", { fill: C.background2, fontSize: 12 });
    chip(s, 6.2, 3.95, 3.3, 0.55, "Può sembrare la realtà", { fill: C.background2, fontSize: 12 });
    txt(s, "Più il contenuto può sembrare la realtà o arriva all'esterno, più il controllo deve essere sistematico.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Distinguere realismo, provenienza e accuratezza è essenziale per utilizzare in modo critico i contenuti multimodali.", "Sottotema 10.8  ·  Limiti, autenticità e affidabilità", "Concetto chiave dell'ultimo sottotema. Gli errori dei contenuti multimodali sono difficili da vedere, perché il risultato è convincente e il controllo richiede di tornare a un'altra modalità. I contenuti sintetici realistici e i deepfake rendono necessario distinguere realismo, autenticità e accuratezza, e porre separatamente le tre domande. La provenienza si accerta con strumenti tecnici che vanno interpretati e, soprattutto, con verifiche organizzative. La comunicazione aziendale richiede trasparenza sull'uso di contenuti sintetici, e i diritti su contenuti, immagini e voci vanno considerati. Esercizio suggerito: presentare uno scenario fittizio di richiesta urgente via messaggio vocale da parte di un dirigente e discutere in gruppo quali verifiche fare e quali procedure aziendali le rendono possibili.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle dieci domande guida. Che cosa significa multimodale: lavorare con più modalità, testo, immagini, audio e video, con capacità che dipendono dal sistema. Interpretare, generare, trasformare: comprendere un contenuto, produrne uno nuovo, passarlo da una forma all'altra, con rischi diversi. Immagini, diagrammi e schermate: descrizione utile e rapida, con limiti nei dettagli, e descrivere non è comprendere. Generazione di immagini: esplorazione rapida, controllo e conformità non garantiti. Parlato e registrazioni: trascrizione, sintesi, traduzione, voce; attenzione a terminologia, numeri e attribuzioni. Video: analisi, sintesi, generazione di brevi filmati; documentale e sintetico vanno distinti. Presentazioni: bozze rapide; l'estetica non garantisce l'accuratezza. Che cosa si perde: tono, condizioni, contesto, e le catene accumulano errori. Realismo, autenticità, accuratezza: tre domande separate. Accessibilità: le conversioni tra modalità includono, purché controllate. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Che cosa significa multimodale?", "Più modalità; capacità che dipendono dal sistema"], ["Interpretare, generare, trasformare?", "Tre operazioni, tre rischi diversi"], ["Immagini e schermate?", "Utile, limiti nei dettagli; descrivere non è comprendere"], ["Generare immagini?", "Esplorazione rapida; controllo non garantito"], ["Parlato e registrazioni?", "Attenzione a termini, numeri, attribuzioni"], ["Video?", "Documentale e sintetico vanno distinti"], ["Presentazioni?", "Bozze rapide; estetica non è accuratezza"], ["Che cosa si perde?", "Tono, condizioni, contesto; catene di errori"], ["Realismo, autenticità, accuratezza?", "Tre domande separate"], ["Accessibilità?", "Conversioni che includono, se controllate"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.74;
      shapeBox(s, x, y, 4.4, 0.66, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.66, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.04, w: 3.8, h: 0.3, fontSize: 11, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.33, w: 3.8, h: 0.3, fontSize: 10, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: spiegare il significato di AI multimodale; distinguere comprensione, generazione e trasformazione di contenuti; riconoscere applicazioni di interpretazione visiva; comprendere possibilità e limiti della generazione e modifica di immagini; conoscere le principali capacità relative ad audio e parlato; riconoscere opportunità e limiti relativi ai video; comprendere il supporto alla creazione di presentazioni e materiali comunicativi; individuare le possibilità di trasformazione tra modalità; riconoscere il contributo all'accessibilità; distinguere realismo, autenticità e accuratezza; identificare rischi di perdita del significato nelle trasformazioni; comprendere l'importanza di verificare provenienza, fedeltà e adeguatezza dei contenuti.");
    const r = ["Spiegare che cos'è l'AI multimodale", "Comprendere, generare, trasformare", "Applicazioni di interpretazione visiva", "Generare e modificare immagini: possibilità e limiti", "Capacità su audio e parlato", "Opportunità e limiti dei video", "Presentazioni e materiali comunicativi", "Trasformazioni tra modalità", "Il contributo all'accessibilità", "Realismo, autenticità, accuratezza", "Perdita di significato nelle trasformazioni", "Verificare provenienza, fedeltà, adeguatezza"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Una scheda pratica", "Traduciamo il modulo in una scheda pratica, organizzata per operazione. Interpretare: controllare i dettagli importanti, numeri e testi, guardando o ascoltando l'originale; ricordare che descrivere non è comprendere, e che significato, provenienza e contesto non sono nel contenuto. Generare: usare la generazione per esplorare; controllare dettagli, testi e coerenza; rispettare identità visiva, diritti e persone; dichiarare i contenuti sintetici che potrebbero sembrare reali. Trasformare: identificare gli elementi critici, limitare le catene, confrontare con l'originale, chiedere la fonte di ogni affermazione quando si combinano più contenuti. Valutare: porre separatamente le tre domande su realismo, autenticità e accuratezza; verificare le richieste insolite su canali indipendenti; proporzionare i controlli all'uso. E sempre: immagini, registrazioni e video aziendali solo negli strumenti autorizzati, con il consenso delle persone coinvolte. Il messaggio centrale del tema: il realismo non garantisce autenticità, e ogni trasformazione richiede attenzione alla fedeltà, alla correttezza e all'adeguatezza delle informazioni.");
    const f = [["Interpretare", ["Dettagli e numeri sull'originale", "Descrivere non è comprendere", "Contesto e provenienza fuori dal contenuto"], C.background2], ["Generare", ["Per esplorare", "Dettagli, testi, coerenza", "Marchio, diritti, persone; dichiarare"], C.accent6], ["Trasformare", ["Elementi critici", "Catene brevi", "Confronto con l'originale"], C.background2], ["Valutare", ["Reale? Da dove? Vero?", "Canali indipendenti", "Controlli proporzionati"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: strumenti autorizzati e consenso delle persone coinvolte in immagini, registrazioni e video.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei errori tipici nell'uso dell'AI multimodale, uno per ciascuno dei principali messaggi del modulo. Primo: 'l'ha letto dalla foto, quindi è giusto'. Numeri, codici e dettagli piccoli possono essere letti male o ricostruiti in modo plausibile: i punti critici si controllano sull'originale. Secondo: 'l'immagine generata è pronta per il cliente'. La generazione è ottima per esplorare, ma non garantisce fedeltà, rispetto del marchio, diritti e trasparenza. Terzo: 'la trascrizione è fedele'. Nomi, numeri, attribuzioni e frasi aggiunte sono gli errori tipici; le parti importanti le controlla chi era presente. Quarto: 'è un video, quindi è successo'. Coerenza visiva e realismo non dimostrano che gli eventi siano accaduti: conta la provenienza. Quinto: 'la slide è bella, quindi è corretta'. L'estetica è quasi gratuita, l'accuratezza no. Sesto: 'riconosco la voce del capo, quindi procedo'. Voce e volto possono essere imitati: le richieste urgenti e insolite si confermano su un canale indipendente. Suggerimento: chiedere ai partecipanti quale di questi errori ritengono più probabile nel proprio contesto.");
    const a = [["FiCamera", "\"L'ha letto dalla foto, è giusto\"", "Dettagli e numeri sull'originale", "10.2"], ["FiImage", "\"L'immagine è pronta per il cliente\"", "Fedeltà, marchio, diritti, trasparenza", "10.3"], ["FiMic", "\"La trascrizione è fedele\"", "Nomi, numeri, attribuzioni da controllare", "10.4"], ["FiFilm", "\"È un video, quindi è successo\"", "Realismo non è provenienza", "10.5"], ["FiMonitor", "\"La slide è bella, quindi è corretta\"", "Estetica non è accuratezza", "10.6"], ["FiPhoneCall", "\"È la voce del capo, procedo\"", "Conferma su un canale indipendente", "10.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 2.95, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.7, y: y + 0.1, w: 0.55, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 10 completiamo l'esplorazione delle modalità: testi e documenti nel Tema 8, dati nel Tema 9, immagini, audio e video in questo tema. Il tema successivo, il Tema 11, è dedicato ad assistenti, agenti e automazioni: come l'AI possa evolvere da strumento conversazionale a componente operativa di attività e processi. Vedremo che cosa sono gli assistenti con strumenti e integrazioni, che cosa sono gli agenti AI, la differenza tra automazione tradizionale e intelligente, i livelli di autonomia e di supervisione umana, e le condizioni per un uso affidabile. Molte capacità viste finora, come la trascrizione di riunioni, la lettura di schermate, l'estrazione di dati dai documenti, diventeranno lì componenti di flussi di lavoro più ampi, e i principi di verifica e di fedeltà acquisteranno un peso ancora maggiore, perché gli errori potranno propagarsi in azioni e non solo in contenuti. I documenti di perimetro richiamano poi il Tema 12, sulla creazione di valore in azienda, e il Tema 14, su dati e conoscenza aziendale. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi e documenti\nTema 9: dati e analisi\nTema 10: multimodalità (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.9, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 11: Assistenti, agenti e automazioni", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Dallo strumento conversazionale alla componente operativa", { x: 5.4, y: 2.38, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.0, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 12: AI e creazione di valore in azienda", "Tema 14: dati e conoscenza aziendale"], { space: 5 }), { x: 5.4, y: 3.35, w: 3.9, h: 1.2, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Per l'articolo 50 dell'AI Act: il rinvio al 2 dicembre 2026 della marcatura per i sistemi già sul mercato e il codice di condotta di giugno 2026 sono stati verificati su fonti secondarie a ottobre 2026; confermarli sul testo ufficiale e sul sito della Commissione europea. I due casi di frode sono stati riportati dalla stampa internazionale: conviene verificare le fonti e i dettagli aggiornati prima di citarli in aula. Le capacità degli strumenti multimodali, in particolare la generazione di video e di voci, evolvono molto rapidamente: prima di ogni edizione è consigliabile aggiornare esempi e dimostrazioni con gli strumenti autorizzati in azienda. Tutti gli esempi del modulo sono fittizi.");
    const src = [
      "Caso di frode vocale ai danni di un'azienda energetica britannica, riportato da The Wall Street Journal, agosto 2019.",
      "Caso di frode in videochiamata presso la sede di Hong Kong di una multinazionale (Arup), riportato da CNN e Financial Times, 2024.",
      "C2PA, Coalition for Content Provenance and Authenticity: standard per le credenziali di contenuto (c2pa.org).",
      "Regolamento (UE) 2024/1689 (AI Act), art. 50, obblighi di trasparenza dal 2 agosto 2026, come modificato dal Regolamento (UE) 2026/1744.",
      "Gli esempi di schermate, trascrizioni, immagini e materiali presenti nelle slide sono fittizi.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema10_AI_multimodale_contenuti.pptx" });
  await applyTheme("Tema10_AI_multimodale_contenuti.pptx", THEME);
  console.log("done");
})();
