
  // =====================================================================
  section("11.3 Agenti AI");
  divider("11.3", "Che cosa sono gli agenti AI", "Il successo di un singolo passaggio non garantisce l'affidabilità del processo completo", "Entriamo nel nucleo del tema. Il termine agente è tra i più usati, e abusati, nel discorso attuale sull'AI. In questo sottotema, da comprendere e sperimentare, ne diamo una definizione funzionale, vediamo come funziona un agente dal punto di vista di chi lo usa, lo distinguiamo da chatbot e workflow automatizzati, e affrontiamo un'integrazione centrale: l'effetto accumulo degli errori nei processi a più passaggi. I framework agentici e l'orchestrazione tecnica sono solo da accennare.");
  {
    const s = content("Una definizione funzionale", "Il documento chiede una definizione funzionale, basata su ciò che il sistema fa, non su come è costruito. Un agente AI è un sistema che persegue un obiettivo coordinando passaggi e strumenti. Quattro caratteristiche lo distinguono. È orientato a un obiettivo: riceve non un'istruzione puntuale, come 'scrivi questa email', ma un obiettivo, come 'organizza l'incontro con il fornitore entro la prossima settimana'. Pianifica: scompone l'obiettivo in passaggi, come verificare le disponibilità, proporre date, inviare l'invito, prenotare la sala. Usa strumenti in modo coordinato: calendario, posta, sistema di prenotazione, ciascuno nel passaggio in cui serve. Osserva e si adatta: guarda il risultato di ogni passaggio e decide il successivo di conseguenza; se nessuna data va bene, ne propone altre. La differenza rispetto a un assistente sta soprattutto in chi decide la sequenza: con un assistente, la persona chiede un passaggio alla volta; con un agente, è il sistema a scegliere i passaggi per arrivare all'obiettivo. Il grado in cui questo avviene varia molto, e molti sistemi chiamati agenti hanno capacità agentiche limitate.");
    areaTag(s, 1);
    await iconGrid(s, [
      { icon: "FiTarget", head: "Orientato a un obiettivo", body: "'Organizza l'incontro con il fornitore entro la prossima settimana'" },
      { icon: "FiList", head: "Pianifica", body: "Scompone in passaggi: disponibilità, date, invito, sala" },
      { icon: "FiTool", head: "Usa strumenti coordinati", body: "Calendario, posta, prenotazioni, ciascuno quando serve" },
      { icon: "FiRefreshCw", head: "Osserva e si adatta", body: "Se nessuna data va bene, ne propone altre" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Con un assistente la persona chiede un passaggio alla volta; con un agente è il sistema a scegliere i passaggi.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Il ciclo di un agente", "Dal punto di vista di chi lo usa, il funzionamento di un agente si può descrivere come un ciclo che si ripete. Pianificare: a partire dall'obiettivo e dalle informazioni disponibili, decidere il prossimo passaggio. Agire: eseguire il passaggio, di solito usando uno strumento, come una ricerca, la lettura di un file, l'invio di un messaggio. Osservare: esaminare il risultato del passaggio, che cosa è stato trovato, se l'operazione è riuscita, che cosa è cambiato. Adattare: decidere se l'obiettivo è raggiunto, se proseguire come previsto, se cambiare piano. E poi di nuovo pianificare il passaggio successivo. Il ciclo continua finché l'obiettivo è raggiunto, finché il sistema si blocca, o finché raggiunge un limite, come un numero massimo di passaggi o un punto in cui deve chiedere conferma. Questo ciclo spiega sia la forza sia la fragilità degli agenti. La forza: la capacità di affrontare compiti non completamente prevedibili, adattandosi a ciò che trova. La fragilità: ogni giro del ciclo è una decisione presa da un modello che può sbagliare, e le decisioni si basano sui risultati dei passaggi precedenti, compresi quelli sbagliati.");
    areaTag(s, 1);
    const st = [["FiMap", "Pianificare", "Decidere il prossimo passaggio"], ["FiPlay", "Agire", "Eseguire, di solito con uno strumento"], ["FiEye", "Osservare", "Esaminare il risultato"], ["FiRefreshCw", "Adattare", "Proseguire, cambiare piano, fermarsi"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.1, 1.95, i % 2 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.32, 0.66, st[i][0]);
      txt(s, st[i][1], { x: x + 0.1, y: 2.05, w: 1.9, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.12, y: 2.47, w: 1.86, h: 0.6, fontSize: 11, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "... e di nuovo, fino all'obiettivo, a un blocco o a un limite", { x: 0.5, y: 3.22, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.accent1, align: "center" });
    await card(s, 0.5, 3.65, 4.35, 1.3, { head: "La forza", headSize: 14, bodySize: 12, fill: C.accent6, body: "Affrontare compiti non del tutto prevedibili, adattandosi." });
    await card(s, 5.15, 3.65, 4.35, 1.3, { head: "La fragilità", headSize: 14, bodySize: 12, body: "Ogni giro è una decisione che può sbagliare, basata anche sui passaggi sbagliati." });
  }
  {
    const s = content("Un esempio passo per passo", "Un esempio fittizio rende concreto il ciclo. L'obiettivo affidato all'agente: preparare per la riunione di domani una scheda sui tre fornitori di imballaggi con cui lavoriamo, con fatturato dell'ultimo anno, reclami aperti e scadenza dei contratti. L'agente scompone l'obiettivo e procede. Primo passaggio: cerca nel gestionale i fornitori della categoria imballaggi, e ne trova quattro, non tre. Deve decidere: li include tutti, o chiede quale escludere? Secondo passaggio: per ciascuno, estrae il fatturato dell'ultimo anno. Terzo passaggio: cerca i reclami aperti nel sistema di gestione della qualità. Quarto passaggio: cerca i contratti nell'archivio documentale e ne legge la scadenza. Quinto passaggio: compone la scheda. Sesto passaggio: la salva nella cartella della riunione e avvisa il richiedente. Ogni passaggio contiene decisioni: quale categoria considerare, quale anno, che cosa conta come reclamo aperto, quale versione del contratto. E ogni passaggio può fallire: un sistema non risponde, un contratto non si trova. L'esempio mostra perché la qualità del risultato dipende dall'intera catena, e perché è utile che l'agente segnali le decisioni prese e i punti in cui non ha trovato ciò che cercava.");
    areaTag(s, 1);
    docBox(s, 0.5, 1.12, 9.0, 0.7, "Obiettivo (esempio fittizio)", "Scheda sui tre fornitori di imballaggi: fatturato ultimo anno, reclami aperti, scadenza dei contratti.", { fontSize: 12, fill: C.accent6 });
    const st = [["Cerca i fornitori", "Ne trova quattro, non tre"], ["Estrae il fatturato", "Quale anno: solare o ultimi 12 mesi?"], ["Cerca i reclami", "Che cosa conta come 'aperto'?"], ["Legge i contratti", "Quale versione? Uno non si trova"], ["Compone la scheda", ""], ["Salva e avvisa", ""]];
    st.forEach((e, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.95 + row * 1.0;
      shapeBox(s, x, y, 2.86, 0.88, C.background2, e[0]);
      txt(s, (i + 1) + ". " + e[0], { x: x + 0.15, y: y + 0.06, w: 2.56, h: 0.36, fontSize: 13, bold: true, color: C.text1 });
      if (e[1]) txt(s, e[1], { x: x + 0.15, y: y + 0.44, w: 2.56, h: 0.38, fontSize: 11, italic: true, color: C.accent5 });
    });
    banner(s, 4.1, "Ogni passaggio contiene decisioni e può fallire. Utile che l'agente segnali le scelte fatte e ciò che non ha trovato.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Agente, chatbot, workflow", "Una delle domande guida chiede che cosa distingue un agente da un workflow automatizzato. Confrontiamo tre sistemi sulla base di alcune caratteristiche. Il chatbot risponde a una domanda alla volta, non persegue obiettivi, di solito non usa strumenti, e non modifica nulla. Il workflow automatizzato esegue una sequenza di passaggi definita in anticipo da una persona: se arriva una fattura, estrai i dati, registrali nel gestionale, invia una notifica. La sequenza è sempre la stessa, prevedibile e ripetibile; se succede qualcosa di non previsto, il workflow si ferma o produce un errore. L'agente riceve un obiettivo e sceglie i passaggi in modo dinamico, in base a ciò che trova; può affrontare situazioni non previste, ma il suo comportamento è meno prevedibile, e la stessa richiesta può produrre sequenze diverse. La tabella mostra il confronto. Il documento chiede di evitare la semplificazione secondo cui un agente è soltanto un'automazione più avanzata: non è migliore o peggiore in assoluto, ma adatto a situazioni diverse. Dove il processo è stabile e ben definito, un workflow è di solito più affidabile, più economico e più controllabile. Dove il compito è variabile e richiede adattamento, un agente può fare ciò che un workflow non può.");
    areaTag(s, 1);
    table(s, [["", "Chatbot", "Workflow automatizzato", "Agente AI"],
      ["Che cosa riceve", "Una domanda", "Un evento o un'attivazione", "Un obiettivo"],
      ["Chi decide i passaggi", "Nessuno: risponde", "Una persona, in anticipo", "Il sistema, in modo dinamico"],
      ["Prevedibilità", "Media", "Alta", "Più bassa"],
      ["Casi non previsti", "Risponde comunque", "Si ferma o va in errore", "Prova ad adattarsi"],
      ["Adatto a", "Informazioni", "Processi stabili e definiti", "Compiti variabili"]],
      { y: 1.15, colW: [2.1, 2.0, 2.45, 2.45], rowH: 0.44, fontSize: 12, accentCol: 3 });
    banner(s, 3.95, "Non migliore o peggiore in assoluto: adatto a situazioni diverse. Un agente non è un'automazione più avanzata.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Limiti e incertezza", "Il sottotema chiede di conoscere i limiti e l'incertezza del comportamento agentico. Il comportamento di un agente è meno prevedibile di quello di un programma tradizionale, per diverse ragioni. Le decisioni sono prese da un modello linguistico, che può interpretare in modi diversi la stessa situazione. La stessa richiesta, ripetuta, può produrre sequenze di passaggi diverse, e quindi risultati diversi. Il comportamento dipende dalle informazioni trovate lungo il percorso, che possono cambiare da una volta all'altra. L'agente può fraintendere l'obiettivo, perseguendone una versione diversa da quella intesa: per esempio, interpretare 'riduci i costi della campagna' come 'interrompi la campagna'. Può bloccarsi in cicli, ripetendo tentativi che non funzionano. Può dichiarare di aver raggiunto l'obiettivo quando non l'ha fatto, o raggiungerlo in un modo non accettabile, come completare un modulo con dati inventati pur di arrivare in fondo. E può essere influenzato dai contenuti che legge: istruzioni nascoste in una pagina web o in un documento possono indurlo a fare cose non previste, un rischio che vedremo nell'11.8. Nessuno di questi limiti impedisce di usare gli agenti; tutti suggeriscono di farlo con obiettivi chiari, limiti espliciti e verifiche.");
    areaTag(s, 1);
    rowsLabel(s, [["Sequenze diverse", "La stessa richiesta può produrre passaggi e risultati diversi"], ["Obiettivo frainteso", "'Riduci i costi della campagna' diventa 'interrompi la campagna'"], ["Cicli e blocchi", "Ripete tentativi che non funzionano"], ["Falso completamento", "Dichiara di aver finito, o finisce in modo inaccettabile"], ["Influenza dei contenuti", "Istruzioni nascoste in ciò che legge (11.8)"]], { y: 1.15, h: 0.5, lw: 2.5 });
    banner(s, 4.15, "Nessun limite impedisce di usare gli agenti: tutti suggeriscono obiettivi chiari, limiti espliciti e verifiche.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("L'accumulo degli errori", "L'integrazione B del tema: l'effetto accumulo degli errori nei processi a più passaggi. Gli errori intermedi possono influenzare le operazioni successive, e il successo di un singolo passaggio non garantisce l'affidabilità del processo completo. Un semplice calcolo lo mostra. Supponiamo che ogni passaggio di un processo riesca correttamente nel 95 per cento dei casi: un'affidabilità che, per un singolo passaggio, sembra alta. Se i passaggi sono indipendenti e tutti devono riuscire, la probabilità che un processo di dieci passaggi riesca interamente è 0,95 elevato alla decima, cioè circa il 60 per cento. Con venti passaggi scende a circa il 36 per cento. Anche con un'affidabilità del 99 per cento per passaggio, un processo di venti passaggi riesce interamente nell'82 per cento dei casi, cioè fallisce quasi una volta su cinque. Il grafico mostra le due curve. È un modello semplificato: nella realtà alcuni errori vengono corretti dall'agente nei passaggi successivi, altri invece si amplificano. Ma il messaggio è robusto: un processo lungo richiede passaggi molto affidabili, oppure controlli intermedi che intercettino gli errori prima che si propaghino. E una dimostrazione su pochi passaggi dice poco sull'affidabilità di un processo lungo.");
    areaTag(s, 1);
    const lab = [], a = [], b = [];
    for (let n = 1; n <= 20; n++) { lab.push(String(n)); a.push(Math.round(Math.pow(0.95, n) * 1000) / 10); b.push(Math.round(Math.pow(0.99, n) * 1000) / 10); }
    lineChart(s, lab, [{ name: "99% per passaggio", values: b, color: HEX.a1 }, { name: "95% per passaggio", values: a, color: HEX.a5 }], { x: 0.5, y: 1.1, w: 5.6, h: 3.2, min: 0, max: 100, legend: true, title: "Probabilità che l'intero processo riesca (%), per numero di passaggi" });
    const k = [["10 passaggi al 95%", "≈ 60%"], ["20 passaggi al 95%", "≈ 36%"], ["20 passaggi al 99%", "≈ 82%"]];
    k.forEach((e, i) => {
      const y = 1.15 + i * 0.98;
      shapeBox(s, 6.35, y, 3.15, 0.88, i === 1 ? C.accent5 : C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.06, w: 2.9, h: 0.3, fontSize: 12, color: i === 1 ? C.background1 : C.text2 });
      txt(s, e[1], { x: 6.5, y: y + 0.36, w: 2.9, h: 0.46, fontSize: 22, bold: true, color: i === 1 ? C.background1 : C.accent1 });
    });
    banner(s, 4.45, "Un processo lungo richiede passaggi molto affidabili, o controlli intermedi. Modello semplificato: passaggi indipendenti.", { h: 0.55, fontSize: 12 });
  }
  {
    const s = content("Come si propaga un errore", "Oltre al calcolo, conviene capire come un errore si propaga concretamente. Torniamo all'esempio della scheda sui fornitori. Al primo passaggio, l'agente cerca i fornitori della categoria imballaggi, ma la categoria nel gestionale si chiama 'packaging', e trova solo due dei tre fornitori attesi. Nessun errore visibile: la ricerca è riuscita, ha restituito dei risultati. Al secondo passaggio estrae il fatturato dei due fornitori trovati: corretto. Al terzo cerca i reclami: corretto. Al quarto legge i contratti: corretto. Al quinto compone una scheda ordinata, completa nella forma, con due fornitori invece di tre. Al sesto la salva e avvisa: 'La scheda sui fornitori di imballaggi è pronta'. Cinque passaggi su sei sono corretti, e il risultato è sbagliato in modo significativo: manca un fornitore, forse proprio quello con il contratto in scadenza. L'esempio mostra tre caratteristiche tipiche della propagazione. L'errore iniziale non era un fallimento, ma un risultato plausibile e incompleto. I passaggi successivi hanno lavorato correttamente su una base sbagliata. Il risultato finale non mostra alcun segno dell'errore. Per questo i controlli più utili sono quelli intermedi sui risultati che condizionano tutto il resto, come 'ho trovato due fornitori, ne aspettavi tre?'.");
    areaTag(s, 1);
    const st = [["1", "Cerca 'imballaggi'", "Trova 2 su 3: la categoria si chiama 'packaging'", C.accent5, C.background1], ["2", "Fatturato", "Corretto, sui 2 trovati", C.background2, C.text1], ["3", "Reclami", "Corretto", C.background2, C.text1], ["4", "Contratti", "Corretto", C.background2, C.text1], ["5", "Scheda", "Ordinata e completa nella forma", C.background2, C.text1], ["6", "'La scheda è pronta'", "Manca un fornitore", C.accent1, C.background1]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 1.53;
      shapeBox(s, x, 1.2, 1.4, 1.9, e[3], "passo " + e[0]);
      txt(s, e[0], { x: x + 0.1, y: 1.25, w: 1.2, h: 0.4, fontSize: 18, bold: true, color: e[4] === C.background1 ? C.accent6 : C.accent1 });
      txt(s, e[1], { x: x + 0.1, y: 1.65, w: 1.25, h: 0.5, fontSize: 11, bold: true, color: e[4] });
      txt(s, e[2], { x: x + 0.1, y: 2.15, w: 1.25, h: 0.9, fontSize: 10, color: e[4] });
    });
    const c = ["L'errore iniziale era un risultato plausibile e incompleto", "I passaggi successivi erano corretti su una base sbagliata", "Il risultato finale non mostra segni dell'errore"];
    c.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.3, 2.86, 0.75, t, { fill: C.accent6, fontSize: 11 }));
    banner(s, 4.25, "Controlli intermedi sui risultati che condizionano il resto: 'ho trovato due fornitori, ne aspettavi tre?'", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Gradi di autonomia operativa", "L'ultimo punto del sottotema: gli agenti possono avere gradi di autonomia operativa molto diversi, e il termine agente non dice quanto. Alcuni agenti propongono un piano e lo eseguono solo dopo che la persona l'ha approvato. Altri eseguono i passaggi informativi in autonomia, come cercare e leggere, e chiedono conferma prima di ogni passaggio che modifica qualcosa. Altri ancora eseguono l'intero processo in autonomia entro un perimetro definito, con la persona che controlla il risultato finale o monitora l'esecuzione. E alcuni operano in modo continuativo, attivandosi da soli quando si verifica un evento, come l'arrivo di un'email. Per l'utente, la domanda chiave è: in quali punti del processo questo agente si ferma e chiede conferma, e in quali agisce da solo? Il documento ricorda una delle precisazioni trasversali del tema: l'autonomia non è una caratteristica assoluta. Un sistema può avere molta discrezionalità nello scegliere i passaggi e nessuna nel compiere l'azione finale. Svilupperemo questi livelli nell'11.5. Il punto qui è che un agente con capacità di pianificazione e un agente autonomo non sono la stessa cosa.");
    areaTag(s, 1);
    rowsLabel(s, [["Piano approvato", "Propone il piano, lo esegue dopo l'approvazione"], ["Conferma sulle modifiche", "Legge e cerca da solo; chiede prima di modificare"], ["Autonomo nel perimetro", "Esegue tutto entro limiti definiti, con monitoraggio"], ["Attivato da eventi", "Si attiva da solo, per esempio all'arrivo di un'email"]], { y: 1.15, h: 0.56, lw: 2.8 });
    banner(s, 3.75, "La domanda chiave: in quali punti si ferma e chiede conferma, e in quali agisce da solo?", { h: 0.7, fontSize: 14 });
    txt(s, "Pianificare in autonomia non significa agire in autonomia (11.5).", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }
  keySlide("Gli errori intermedi possono influenzare le operazioni successive: il successo di un singolo passaggio non garantisce l'affidabilità del processo completo.", "Sottotema 11.3  ·  Che cosa sono gli agenti AI", "Concetto chiave del sottotema 11.3, che coincide con l'integrazione B. Un agente persegue un obiettivo pianificando, agendo, osservando e adattandosi in un ciclo continuo. È diverso da un chatbot e da un workflow automatizzato: sceglie i passaggi in modo dinamico, ed è quindi più flessibile e meno prevedibile. Il suo comportamento ha limiti e incertezze, e gli errori si accumulano: un processo di molti passaggi, anche tutti abbastanza affidabili, fallisce più spesso di quanto sembri, e un errore iniziale plausibile può attraversare tutto il processo senza lasciare tracce. I controlli intermedi sono la contromisura principale. Esercizio suggerito: descrivere in gruppo un'attività di lavoro reale come obiettivo per un agente, scomporla nei passaggi, e individuare per ciascuno le decisioni implicite e i modi in cui potrebbe fallire senza che si veda.");

  // =====================================================================
  section("11.4 Automazione");
  divider("11.4", "Automazione tradizionale e intelligente", "Automazione, autonomia e controllo non sono la stessa cosa", "Dagli agenti all'automazione. Le aziende automatizzano processi da decenni, molto prima dell'AI generativa. In questo sottotema, da comprendere, vediamo che cosa significa automatizzare, le automazioni basate su regole e i workflow, la Robotic Process Automation, e il ruolo che l'AI può avere nei processi automatizzati, soprattutto nell'elaborare informazioni non strutturate. E affrontiamo l'integrazione C: automazione, autonomia e controllo sono dimensioni distinte. Infine, una domanda guida importante: quando l'AI non serve, e un'automazione tradizionale è preferibile.");
  {
    const s = content("Che cosa significa automatizzare", "Automatizzare significa far eseguire un'attività a un sistema senza intervento manuale. Le automazioni più comuni in azienda sono basate su regole: se si verifica una condizione, esegui un'azione. Se arriva un ordine superiore a 10.000 euro, invia una notifica al responsabile. Se una fattura è scaduta da trenta giorni, genera un sollecito. Ogni sera, copia i dati delle vendite dal sistema di cassa al gestionale. Più regole e azioni collegate formano un workflow, cioè una sequenza operativa: arriva una richiesta di ferie, viene verificato il saldo, viene inviata al responsabile, se approvata viene registrata nel calendario e nel sistema paghe. Le automazioni basate su regole hanno caratteristiche preziose: sono prevedibili, perché fanno sempre la stessa cosa nelle stesse condizioni; sono verificabili, perché si può leggere la regola; sono ripetibili ed economiche da eseguire. Il loro limite è la rigidità: funzionano solo con informazioni strutturate e casi previsti. Se l'ordine arriva per email in un formato libero invece che nel modulo, la regola non lo riconosce. Se si presenta un caso non previsto, il workflow si ferma o, peggio, prosegue in modo sbagliato.");
    areaTag(s, 1);
    txt(s, "Regole: se si verifica una condizione, esegui un'azione", { x: 0.5, y: 1.12, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const r = [["Ordine > 10.000 €", "Notifica al responsabile"], ["Fattura scaduta da 30 giorni", "Genera un sollecito"], ["Ogni sera", "Copia le vendite nel gestionale"]];
    r.forEach((e, i) => {
      const y = 1.55 + i * 0.6;
      chip(s, 0.5, y, 3.6, 0.5, "SE  " + e[0], { fill: C.background2, fontSize: 12 });
      arrow(s, 4.2, y + 0.09, 0.4);
      chip(s, 4.7, y, 4.8, 0.5, "ALLORA  " + e[1], { fill: C.accent6, fontSize: 12 });
    });
    await card(s, 0.5, 3.45, 4.35, 1.5, { icon: "FiCheckCircle", inline: true, head: "Prevedibili e verificabili", headSize: 14, bodySize: 12, fill: C.accent6, body: "Sempre la stessa cosa nelle stesse condizioni; si può leggere la regola." });
    await card(s, 5.15, 3.45, 4.35, 1.5, { icon: "FiLock", inline: true, head: "Rigide", headSize: 14, bodySize: 12, body: "Solo informazioni strutturate e casi previsti. Un'email in formato libero non viene riconosciuta." });
  }
  {
    const s = content("La Robotic Process Automation", "Il documento chiede un'introduzione alla Robotic Process Automation, o RPA. Nonostante il nome, non si tratta di robot fisici, ma di software che imitano le azioni di una persona sull'interfaccia dei programmi: aprono un'applicazione, cliccano, copiano un valore da una schermata, lo incollano in un'altra, compilano un modulo, salvano. L'RPA è nata per automatizzare attività ripetitive su sistemi che non offrono modi più diretti di integrazione: per esempio, trasferire dati tra due programmi che non comunicano tra loro, senza doverli modificare. È molto diffusa in ambiti come l'amministrazione, la contabilità, le risorse umane, i servizi finanziari. Le sue caratteristiche sono quelle delle automazioni basate su regole: prevedibile, rapida, instancabile, ma rigida. In più, è fragile rispetto ai cambiamenti delle interfacce: se un pulsante cambia posizione o un campo cambia nome, il software si blocca. Oggi l'RPA si combina spesso con componenti AI, che ne superano alcuni limiti: leggere documenti in formato libero, interpretare email, gestire variazioni. È un esempio concreto della combinazione tra regole e AI che vedremo tra poco. L'implementazione è solo da accennare.");
    areaTag(s, 1);
    const st = ["Apre l'applicazione", "Copia un valore", "Lo incolla altrove", "Compila e salva"];
    st.forEach((t, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, t, { fill: C.background2, fontSize: 12 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    txt(s, "Software che imita le azioni di una persona sull'interfaccia, non robot fisici", { x: 0.5, y: 1.95, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2, align: "center" });
    await card(s, 0.5, 2.45, 2.86, 1.6, { head: "Utile per", headSize: 14, bodySize: 12, body: "Sistemi che non comunicano tra loro; attività ripetitive in amministrazione, contabilità, HR." });
    await card(s, 3.57, 2.45, 2.86, 1.6, { head: "Limiti", headSize: 14, bodySize: 12, body: "Rigida, e fragile ai cambi di interfaccia: un pulsante spostato la blocca." });
    await card(s, 6.64, 2.45, 2.86, 1.6, { head: "Con l'AI", headSize: 14, bodySize: 12, fill: C.accent6, body: "Legge documenti in formato libero, interpreta email, gestisce variazioni." });
    txt(s, "Implementazione: solo accennata.", { x: 0.5, y: 4.3, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("L'AI nei processi automatizzati", "Qual è il ruolo specifico dell'AI nei processi automatizzati? Il contributo principale, indicato dal documento, è l'elaborazione di informazioni non strutturate. Le automazioni tradizionali lavorano con dati in formato definito; gran parte delle informazioni aziendali arriva invece in forma libera: email, documenti, moduli compilati a mano, messaggi, chiamate. L'AI può trasformare queste informazioni in dati strutturati, come visto nel Tema 8 per l'estrazione, e renderle utilizzabili da un'automazione. Esempi concreti. Leggere le email in arrivo all'indirizzo del servizio clienti, classificarle per tipo di richiesta e urgenza, e smistarle alla coda giusta. Estrarre i dati da fatture di fornitori in formati diversi e registrarli nel gestionale. Riassumere una richiesta di assistenza e proporre all'operatore una risposta. Riconoscere in un documento le clausole che richiedono una revisione legale. In questi casi l'AI non sostituisce l'automazione, ma la estende a informazioni che prima richiedevano una persona. Le altre funzioni che l'AI può svolgere in un processo sono decidere tra opzioni in casi ambigui, generare contenuti, come risposte o documenti, e gestire alcune eccezioni.");
    areaTag(s, 1);
    docBox(s, 0.5, 1.15, 2.7, 2.1, "Informazioni in forma libera", "Email, documenti, moduli a mano, messaggi, chiamate.", { fontSize: 12 });
    arrow(s, 3.3, 1.95, 0.35);
    shapeBox(s, 3.75, 1.15, 2.2, 2.1, C.accent1, "AI");
    txt(s, "AI: interpreta, classifica, estrae", { x: 3.85, y: 1.15, w: 2.0, h: 2.1, fontSize: 14, bold: true, color: C.background1, align: "center", valign: "middle" });
    arrow(s, 6.05, 1.95, 0.35);
    docBox(s, 6.5, 1.15, 3.0, 2.1, "Dati per l'automazione", "Tipo di richiesta, urgenza, importi, date, campi del gestionale.", { fontSize: 12, fill: C.accent6 });
    const e = ["Email smistate per tipo e urgenza", "Fatture in formati diversi registrate", "Richieste riassunte con risposta proposta", "Clausole da revisionare segnalate"];
    e.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.45, 2.15, 0.75, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 4.4, "L'AI non sostituisce l'automazione: la estende a informazioni che prima richiedevano una persona.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Regole e AI insieme", "Nella pratica, le automazioni più efficaci combinano regole tradizionali e componenti AI, assegnando a ciascuno ciò che sa fare meglio. Lo schema in slide mostra un esempio fittizio di gestione delle fatture passive. La fattura arriva per email: una regola la preleva dalla casella dedicata. Un componente AI estrae i dati, come fornitore, numero, importo, scadenza, anche da formati diversi. Una regola verifica che il fornitore esista in anagrafica e che esista un ordine corrispondente, confrontando importi e quantità. Se tutto corrisponde, una regola registra la fattura e la mette in pagamento alla scadenza. Se qualcosa non corrisponde, o se il componente AI segnala un'incertezza nell'estrazione, la fattura va a una persona, che decide. In questo disegno, l'AI interviene solo dove serve davvero, cioè nell'interpretazione di un documento in formato libero; i controlli e le azioni con conseguenze, come la registrazione e il pagamento, sono affidati a regole verificabili; le eccezioni vanno alle persone. Il documento chiede di comprendere la differenza tra esecuzione predefinita, dove la sequenza è fissata dalle regole, e scelta dinamica dei passaggi, dove la decide un agente. In un processo come questo, la sequenza è predefinita, e l'AI è un componente, non il regista.");
    areaTag(s, 1);
    const st = [["Regola", "Preleva la fattura dall'email", C.background2, C.text1], ["AI", "Estrae fornitore, importo, scadenza", C.accent1, C.background1], ["Regola", "Verifica anagrafica e ordine", C.background2, C.text1], ["Regola", "Registra e mette in pagamento", C.background2, C.text1]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.05, 1.35, e[2], e[0] + i);
      txt(s, e[0], { x: x + 0.12, y: 1.27, w: 1.8, h: 0.36, fontSize: 14, bold: true, color: e[3] === C.background1 ? C.accent6 : C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.65, w: 1.85, h: 0.8, fontSize: 12, color: e[3] });
      if (i < 3) arrow(s, x + 2.07, 1.72, 0.2);
    });
    shapeBox(s, 3.0, 2.75, 4.0, 0.8, C.accent6, "eccezione");
    txt(s, "Non corrisponde o estrazione incerta: decide una persona", { x: 3.15, y: 2.75, w: 3.7, h: 0.8, fontSize: 12, bold: true, color: C.accent5, align: "center", valign: "middle" });
    banner(s, 3.8, "L'AI solo dove serve, le azioni con conseguenze a regole verificabili, le eccezioni alle persone.", { h: 0.65, fontSize: 13 });
    txt(s, "Esecuzione predefinita: l'AI è un componente, non il regista. Esempio fittizio.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Tre dimensioni distinte", "L'integrazione C del tema: automazione, autonomia e controllo non sono la stessa cosa. Il documento propone tre dimensioni distinte, ciascuna con una domanda guida. L'automazione: quanto lavoro viene eseguito senza intervento manuale? L'autonomia: quanta discrezionalità ha il sistema nella scelta delle azioni? La supervisione: quali controlli e interventi umani regolano l'esecuzione? Le tre dimensioni possono combinarsi in modi diversi, come mostrano i due esempi del documento. Primo esempio: un software invia ogni lunedì un report secondo regole predefinite. Alta automazione, perché nessuno interviene; scarsa discrezionalità, perché fa sempre la stessa cosa. Secondo esempio: un agente sceglie quali informazioni raccogliere e prepara una risposta, ma chiede conferma prima di inviarla. Discrezionalità nella preparazione, autorizzazione umana sull'azione finale. Ne derivano due conclusioni, entrambe nel documento. Un processo può essere completamente automatizzato senza AI: l'automazione non richiede intelligenza. E un agente può effettuare scelte dinamiche pur richiedendo interventi umani: l'autonomia nella scelta non implica assenza di controllo. Confondere queste dimensioni porta a errori in entrambe le direzioni: temere sistemi che sono in realtà ben controllati, o fidarsi di sistemi solo perché automatizzati.");
    areaTag(s, 1);
    const d = [["Automazione", "Quanto lavoro senza intervento manuale?"], ["Autonomia", "Quanta discrezionalità nella scelta delle azioni?"], ["Supervisione", "Quali controlli e interventi umani?"]];
    d.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.1, i === 1 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.2, w: 2.56, h: 0.4, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.6, w: 2.56, h: 0.6, fontSize: 12, color: C.text1 });
    });
    table(s, [["Esempio", "Automazione", "Autonomia", "Supervisione"],
      ["Report inviato ogni lunedì secondo regole", "Alta", "Scarsa", "Sulle regole"],
      ["Agente che prepara una risposta e chiede conferma", "Parziale", "Nella preparazione", "Sull'azione finale"]],
      { y: 2.45, colW: [3.9, 1.6, 1.8, 1.7], rowH: 0.48, fontSize: 12, blankCorner: false });
    banner(s, 3.95, "Si può automatizzare tutto senza AI; un agente può scegliere i passaggi e chiedere comunque conferma.", { h: 0.65, fontSize: 13 });
    txt(s, "Integrazione C: automazione, autonomia e controllo non sono la stessa cosa", { x: 0.5, y: 4.68, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Quando l'AI non serve", "Una domanda guida e un punto del sottotema: in quali casi è preferibile un'automazione tradizionale, e quando l'AI non è necessaria. È una domanda importante, perché l'entusiasmo per l'AI porta talvolta a usarla dove una soluzione più semplice funzionerebbe meglio. Un'automazione tradizionale è di solito preferibile quando il processo è stabile e ben definito, con passaggi che non cambiano; quando le informazioni sono già strutturate, come dati in un database o moduli compilati in campi fissi; quando le regole sono chiare e si possono scrivere esplicitamente; quando serve un comportamento perfettamente prevedibile e ripetibile, per esempio per ragioni di controllo, di audit o di conformità; quando il volume è alto e il costo per operazione conta; quando un errore avrebbe conseguenze gravi e serve poterlo spiegare con precisione. In questi casi, aggiungere un componente AI introduce variabilità, costi e incertezza senza un vantaggio corrispondente. L'AI è utile dove le regole non bastano: informazioni non strutturate, casi variabili, interpretazione del linguaggio, gestione di situazioni non previste. Un buon principio pratico: usare la soluzione più semplice che risolve il problema. La valutazione economica e organizzativa delle soluzioni appartiene all'area successiva del percorso.");
    areaTag(s, 1);
    await card(s, 0.5, 1.15, 4.35, 2.75, { icon: "FiSettings", head: "Meglio un'automazione tradizionale", headSize: 14, bodySize: 12,
      body: bullets(["Processo stabile e ben definito", "Informazioni già strutturate", "Regole chiare e scrivibili", "Serve prevedibilità totale: audit, conformità", "Volumi alti, costo per operazione", "Errori gravi da spiegare con precisione"], { space: 3 }) });
    await card(s, 5.15, 1.15, 4.35, 2.75, { icon: "FiCpu", head: "Dove l'AI è utile", headSize: 14, bodySize: 12, fill: C.accent6,
      body: bullets(["Informazioni non strutturate", "Casi variabili", "Interpretazione del linguaggio", "Situazioni non previste"], { space: 4 }) });
    banner(s, 4.1, "Usare la soluzione più semplice che risolve il problema.", { h: 0.65, fontSize: 16 });
    txt(s, "Valutazione economica e organizzativa: area successiva del percorso.", { x: 0.5, y: 4.8, w: 9, h: 0.28, fontSize: 11, italic: true, color: C.text2 });
  }
  keySlide("Un processo può essere completamente automatizzato senza AI; un agente può effettuare scelte dinamiche pur richiedendo interventi umani.", "Sottotema 11.4  ·  Automazione tradizionale e automazione intelligente", "Concetto chiave del sottotema 11.4, che coincide con l'integrazione C. Le automazioni basate su regole, i workflow e l'RPA sono prevedibili, verificabili ed economiche, ma rigide. L'AI le estende soprattutto all'elaborazione di informazioni non strutturate, e le soluzioni più efficaci combinano regole e componenti AI, assegnando le azioni con conseguenze a regole verificabili e le eccezioni alle persone. Automazione, autonomia e supervisione sono dimensioni distinte. E in molti casi l'AI non serve: la soluzione più semplice è spesso la migliore. Esercizio suggerito: prendere un processo aziendale reale e semplice, scomporlo in passaggi, e decidere per ciascuno se affidarlo a una regola, a un componente AI o a una persona, motivando la scelta.");

  // =====================================================================
  section("11.5 Autonomia e supervisione");
  divider("11.5", "Livelli di autonomia e supervisione umana", "Un'azione può avere conseguenze dirette su dati, comunicazioni e processi, anche difficili da annullare", "Siamo al cuore del tema. Quando un sistema AI può agire, quanto spazio dargli? In questo sottotema, da comprendere e valutare, vediamo i livelli operativi di autonomia, i modelli di supervisione umana, i punti di approvazione, la possibilità di interrompere, correggere e annullare le operazioni, la distinzione tra azioni reversibili e difficilmente reversibili, e il principio della proporzionalità dei controlli rispetto al rischio. Due integrazioni sono centrali: dalla risposta all'azione cambia la natura del rischio, e grado di automazione, discrezionalità e supervisione sono dimensioni distinte.");
  {
    const s = content("Dalla risposta all'azione", "L'integrazione A del tema: dalla risposta all'azione cambia la natura del rischio. Finché un sistema produce risposte, tra il sistema e il mondo c'è sempre una persona: legge la risposta, la valuta, decide che cosa farne. Un errore del sistema diventa un problema solo se la persona non lo nota. È il modello su cui si basano i metodi di verifica del Tema 7. Quando il sistema esegue azioni, questo filtro può mancare: l'azione produce effetti direttamente, prima che qualcuno possa valutarla. Un'email inviata al destinatario sbagliato, un record modificato in modo errato, un ordine duplicato, un appuntamento cancellato, un file sovrascritto, un pagamento eseguito. Il documento indica tre ambiti di conseguenza: i dati, le comunicazioni e i processi. E aggiunge che le conseguenze possono essere difficili da annullare. Cambia anche la natura del controllo: per una risposta si verifica il contenuto prima di usarlo; per un'azione bisogna decidere prima che cosa il sistema può fare, quando deve chiedere, e come si rimedia se sbaglia. Il controllo si sposta dal risultato al processo: limiti, approvazioni, registrazioni, possibilità di annullare.");
    areaTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiMessageSquare", head: "Quando risponde", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Una persona legge, valuta, decide", "L'errore conta solo se non viene notato", "Si verifica il contenuto prima di usarlo"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiZap", head: "Quando agisce", headSize: 15, bodySize: 12, iconBg: C.accent5,
      body: bullets(["L'effetto è diretto, prima di ogni valutazione", "Dati, comunicazioni, processi", "Conseguenze talvolta difficili da annullare"], { space: 4 }) });
    const e = ["Email al destinatario sbagliato", "Record modificato", "Ordine duplicato", "File sovrascritto", "Pagamento eseguito"];
    e.forEach((t, i) => chip(s, 0.5 + i * 1.82, 3.55, 1.7, 0.6, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 4.3, "Il controllo si sposta dal risultato al processo: limiti, approvazioni, registrazioni, possibilità di annullare.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("I livelli operativi di autonomia", "Il documento propone una scala di quattro livelli operativi di autonomia, che riprende la distinzione dell'11.1 tra suggerire, preparare ed eseguire. Primo livello, suggerisce: il sistema propone un'azione che la persona esegue. 'Ti suggerisco di riprogrammare la riunione a giovedì'. Secondo livello, prepara: il sistema predispone un'operazione da completare con intervento umano. 'Ho preparato l'invito per giovedì: lo trovi pronto da inviare'. Terzo livello, esegue con approvazione: il sistema agisce dopo una conferma esplicita. 'Posso inviare l'invito per giovedì ai cinque partecipanti?' 'Sì.' E il sistema lo invia. Quarto livello, esegue entro limiti: il sistema opera in un perimetro definito, con monitoraggio e possibilità di intervento. Per esempio, può riprogrammare autonomamente le riunioni interne di un'ora, ma non quelle con esterni, e registra ogni modifica. Il documento sottolinea due cose. È uno schema didattico, non uno standard normativo. E più autonomia non significa automaticamente più valore: per molte attività il livello migliore è il secondo o il terzo, che combinano il risparmio di tempo con il controllo umano sull'azione finale.");
    areaTag(s, 2);
    levels(s, 1.1, 2.75);
    banner(s, 4.0, "Schema didattico, non standard normativo. Più autonomia non significa automaticamente più valore.", { h: 0.65, fontSize: 14 });
    txt(s, "Per molte attività il livello migliore è il secondo o il terzo.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Nel ciclo o sul ciclo", "Due espressioni inglesi diffuse descrivono il ruolo della persona nei sistemi che agiscono. Human-in-the-loop, la persona nel ciclo: la persona partecipa al processo, e il sistema non può proseguire senza il suo intervento in alcuni punti. Approva, corregge, sceglie. Corrisponde ai livelli secondo e terzo della scala. È il modello più prudente: nessuna azione rilevante avviene senza una decisione umana. Il suo limite è che richiede tempo e attenzione, e se le richieste di approvazione sono troppe, la persona tende ad approvare senza guardare, come vedremo tra poco. Human-on-the-loop, la persona sul ciclo: il sistema opera in autonomia, e la persona lo supervisiona, monitorando l'esecuzione e intervenendo quando qualcosa non va. Corrisponde al quarto livello. È più efficiente, ma richiede che la persona abbia gli strumenti per vedere che cosa sta succedendo, i criteri per capire quando intervenire, e la possibilità effettiva di fermare il sistema e correggere. Esiste anche una terza situazione, la persona fuori dal ciclo, in cui il sistema opera senza supervisione: per gli agenti AI è adatta solo ad attività a rischio molto basso. La scelta tra questi modelli dipende dalle conseguenze delle azioni, come vedremo.");
    areaTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiUserCheck", head: "Human-in-the-loop", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["La persona nel ciclo: approva, corregge, sceglie", "Livelli 2 e 3", "Prudente, ma richiede tempo", "Troppe approvazioni: si approva senza guardare"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiEye", head: "Human-on-the-loop", headSize: 16, bodySize: 12,
      body: bullets(["La persona sul ciclo: monitora e interviene", "Livello 4", "Efficiente, ma servono visibilità, criteri, possibilità di fermare"], { space: 4 }) });
    shapeBox(s, 0.5, 3.95, 9.0, 1.0, C.text1, "fuori dal ciclo");
    txt(s, [{ text: "Fuori dal ciclo: ", options: { bold: true, color: C.accent6 } }, { text: "nessuna supervisione. Per gli agenti AI, solo attività a rischio molto basso.", options: { color: C.background1 } }], { x: 0.7, y: 3.95, w: 8.6, h: 1.0, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Punti di approvazione", "Nei modelli con la persona nel ciclo, la scelta dei punti di approvazione è decisiva. Dove deve fermarsi il sistema per chiedere conferma? Un buon criterio è collocare le approvazioni prima delle azioni con conseguenze, e non dappertutto. Tipici punti di approvazione: prima di inviare comunicazioni all'esterno, a clienti, fornitori, enti; prima di modificare o cancellare dati in sistemi condivisi; prima di impegni economici, come ordini e pagamenti, o sopra una certa soglia; prima di azioni difficilmente reversibili; quando il sistema ha incontrato un'incertezza o un'eccezione; e, per gli agenti, prima di eseguire un piano, così che la persona possa verificare che l'obiettivo sia stato compreso. Un'approvazione è utile solo se è informata: la persona deve vedere chiaramente che cosa sta per accadere, a chi, con quale contenuto, e con quali conseguenze. 'Posso procedere?' non basta; 'Invio questa email, con questo testo, a questi tre destinatari esterni?' sì. C'è poi un rischio da conoscere: l'affaticamento da approvazione. Se il sistema chiede conferma troppo spesso, per azioni banali, la persona inizia ad approvare in automatico, e l'approvazione perde il suo valore proprio quando servirebbe. È l'automation bias visto nel Tema 7, applicato alle conferme.");
    areaTag(s, 2);
    txt(s, "Prima delle azioni con conseguenze, non dappertutto", { x: 0.5, y: 1.12, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const p = ["Comunicazioni all'esterno", "Modifiche a dati condivisi", "Impegni economici, sopra soglia", "Azioni irreversibili", "Incertezze ed eccezioni", "Prima di eseguire un piano"];
    p.forEach((t, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      chip(s, 0.5 + col * 3.07, 1.5 + row * 0.62, 2.86, 0.52, t, { fill: C.accent6, fontSize: 12 });
    });
    docBox(s, 0.5, 2.85, 4.35, 1.1, "Approvazione non informata", "\"Posso procedere?\"", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    docBox(s, 5.15, 2.85, 4.35, 1.1, "Approvazione informata", "\"Invio questa email, con questo testo, a questi tre destinatari esterni?\"", { fontSize: 12, fill: C.accent6 });
    banner(s, 4.15, "Affaticamento da approvazione: se chiede troppo spesso, si approva in automatico proprio quando servirebbe guardare.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Interrompere, correggere, annullare", "Qualunque sia il livello di autonomia, un sistema che agisce deve poter essere fermato e corretto. Il sottotema indica tre capacità. Interrompere: poter fermare il sistema mentre sta operando, in qualsiasi momento, e sapere che si fermerà davvero. È la condizione minima per qualsiasi supervisione sul ciclo. Correggere: poter intervenire su un passaggio, modificare un'azione prima che venga eseguita, cambiare l'obiettivo o i limiti durante l'esecuzione. Annullare: poter riportare la situazione allo stato precedente dopo un'azione sbagliata. Per alcune azioni è semplice, come ripristinare la versione precedente di un documento; per altre è difficile o impossibile, come richiamare un'email già letta. Insieme ai controlli sulle autorizzazioni visti nell'11.2, queste capacità definiscono quanto è recuperabile un errore. Il sottotema le collega a una distinzione fondamentale, che vediamo nella prossima slide: tra azioni reversibili e difficilmente reversibili. Una buona pratica, quando si valuta o si configura un sistema che agisce, è verificare in concreto come si interrompe, come si corregge e come si annulla, prima di averne bisogno.");
    areaTag(s, 2);
    const c = [["FiPause", "Interrompere", "Fermarlo in qualsiasi momento, e sapere che si ferma davvero"], ["FiEdit", "Correggere", "Modificare un passaggio, l'obiettivo, i limiti durante l'esecuzione"], ["FiRotateCcw", "Annullare", "Tornare allo stato precedente dopo un'azione sbagliata"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 2.2, i === 2 ? C.accent6 : C.background2, c[i][1]);
      await iconCircle(s, x + 1.08, 1.32, 0.7, c[i][0]);
      txt(s, c[i][1], { x: x + 0.15, y: 2.1, w: 2.56, h: 0.4, fontSize: 16, bold: true, color: C.text1, align: "center" });
      txt(s, c[i][2], { x: x + 0.2, y: 2.52, w: 2.46, h: 0.8, fontSize: 12, color: C.text2, align: "center" });
    }
    banner(s, 3.65, "Insieme ai controlli sulle autorizzazioni, definiscono quanto è recuperabile un errore.", { h: 0.65, fontSize: 14 });
    txt(s, "Verificare in concreto come si interrompe, si corregge e si annulla, prima di averne bisogno.", { x: 0.5, y: 4.45, w: 9, h: 0.45, fontSize: 13, italic: true, bold: true, color: C.accent1 });
  }
  {
    const s = content("Reversibili e irreversibili", "La distinzione tra azioni reversibili e difficilmente reversibili è uno dei criteri più utili per decidere quanta autonomia concedere. Le azioni reversibili si possono annullare senza conseguenze significative: salvare una bozza, creare un documento nuovo, aggiungere un'etichetta a un'email, proporre un evento in calendario, modificare un file di cui esiste una versione precedente. Le azioni difficilmente reversibili producono effetti che non si possono cancellare, o che si cancellano solo a caro prezzo: inviare un'email all'esterno, che il destinatario ha già letto; effettuare un pagamento; cancellare definitivamente dei dati; pubblicare un contenuto; firmare o accettare un accordo; comunicare una decisione a un cliente. La matrice in slide incrocia reversibilità e impatto. Le azioni reversibili e a basso impatto sono le candidate naturali all'autonomia. Quelle irreversibili e ad alto impatto richiedono approvazione esplicita e, spesso, più di una persona. Nel mezzo, le scelte dipendono dal contesto. Un accorgimento pratico consiste nel rendere reversibili azioni che non lo sono: per esempio, far salvare all'agente le email come bozze invece di inviarle, o introdurre un ritardo prima dell'invio durante il quale l'azione si può annullare.");
    areaTag(s, 2);
    txt(s, "Impatto basso", { x: 2.2, y: 1.1, w: 3.5, h: 0.3, fontSize: 11, bold: true, color: C.text2, align: "center" });
    txt(s, "Impatto alto", { x: 5.85, y: 1.1, w: 3.5, h: 0.3, fontSize: 11, bold: true, color: C.text2, align: "center" });
    txt(s, "Reversibile", { x: 0.5, y: 1.45, w: 1.6, h: 1.25, fontSize: 12, bold: true, color: C.text2, valign: "middle" });
    txt(s, "Irreversibile", { x: 0.5, y: 2.8, w: 1.6, h: 1.25, fontSize: 12, bold: true, color: C.text2, valign: "middle" });
    const m = [[2.2, 1.45, "Candidate all'autonomia", "Bozze, etichette, nuovi documenti", C.accent6, C.text1], [5.85, 1.45, "Autonomia con monitoraggio", "Modifiche a dati con versioni", C.background2, C.text1], [2.2, 2.8, "Approvazione consigliata", "Email interne, eventi confermati", C.background2, C.text1], [5.85, 2.8, "Approvazione esplicita", "Email esterne, pagamenti, pubblicazioni", C.text1, C.background1]];
    m.forEach(e => {
      shapeBox(s, e[0], e[1], 3.5, 1.25, e[4], e[2]);
      txt(s, e[2], { x: e[0] + 0.15, y: e[1] + 0.1, w: 3.2, h: 0.4, fontSize: 14, bold: true, color: e[5] === C.background1 ? C.accent6 : C.accent1 });
      txt(s, e[3], { x: e[0] + 0.15, y: e[1] + 0.55, w: 3.2, h: 0.6, fontSize: 12, color: e[5] });
    });
    banner(s, 4.25, "Rendere reversibile ciò che non lo è: bozze invece di invii, un ritardo prima dell'invio per poter annullare.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Controlli proporzionati al rischio", "L'ultima parte del sottotema riprende l'integrazione C: livello di autonomia e livello di supervisione sono dimensioni distinte, e i controlli devono essere proporzionati al rischio. Un sistema con molta autonomia può essere molto supervisionato, per esempio un agente che sceglie da solo i passaggi ma è monitorato in tempo reale e registra ogni azione; e un sistema con poca autonomia può essere poco supervisionato, come un'automazione a regole che nessuno controlla più da anni. Il rischio, quindi, non si misura solo dal livello di autonomia, ma dalla combinazione tra ciò che il sistema può fare, quanto è supervisionato e quali sarebbero le conseguenze di un errore. La proporzionalità significa adattare i controlli a queste conseguenze, con gli stessi criteri usati nel Tema 7: gravità, reversibilità, chi subisce le conseguenze, rilevabilità dell'errore. Per un agente che organizza i documenti personali in cartelle, bastano limiti di base. Per un agente che risponde ai clienti, servono approvazioni o controlli a campione. Per un agente che modifica dati contabili o esegue pagamenti, servono approvazioni esplicite, limiti stretti, registrazioni complete e verifiche indipendenti. Il documento ricorda che più autonomia non significa automaticamente più valore: spesso il valore sta nel livello di autonomia giusto per quel rischio.");
    areaTag(s, 2);
    table(s, [["Attività dell'agente", "Conseguenze di un errore", "Controlli proporzionati"],
      ["Organizzare i propri documenti", "Basse, reversibili", "Limiti di base"],
      ["Rispondere ai clienti", "Medie, visibili all'esterno", "Approvazioni o controlli a campione"],
      ["Modificare dati contabili, pagare", "Alte, difficili da annullare", "Approvazione esplicita, limiti stretti, registrazioni, verifiche"]],
      { y: 1.15, colW: [2.9, 2.7, 3.4], rowH: 0.55, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Criteri del Tema 7: gravità, reversibilità, chi subisce le conseguenze, rilevabilità.", { x: 0.5, y: 3.45, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
    banner(s, 3.9, "Autonomia e supervisione sono distinte. Il valore sta nel livello di autonomia giusto per quel rischio, non nel massimo.", { h: 0.85, fontSize: 13 });
  }
  keySlide("Dalla risposta all'azione cambia la natura del rischio: un'azione può avere conseguenze dirette su dati, comunicazioni e processi, anche difficili da annullare.", "Sottotema 11.5  ·  Livelli di autonomia e supervisione umana", "Concetto chiave del sottotema 11.5, che coincide con l'integrazione A. Quando il sistema agisce, il filtro umano tra il sistema e il mondo può mancare, e il controllo si sposta dal risultato al processo. I quattro livelli operativi, suggerire, preparare, eseguire con approvazione, eseguire entro limiti, offrono uno schema per decidere. La persona può essere nel ciclo o sul ciclo; i punti di approvazione vanno messi prima delle azioni con conseguenze, con informazioni chiare e senza eccessi; interrompere, correggere e annullare devono essere possibili. Reversibilità e impatto guidano la scelta, e i controlli vanno proporzionati al rischio. Esercizio suggerito: per tre attività di un agente fittizio, a rischio crescente, decidere in gruppo il livello di autonomia, i punti di approvazione e le misure per interrompere e annullare.");
