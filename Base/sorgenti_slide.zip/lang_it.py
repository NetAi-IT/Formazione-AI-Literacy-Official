# Imposta la lingua italiana sul testo del deck generato da build7.js (uso: python3 lang_it.py deck.pptx)
import sys, zipfile, shutil
src = sys.argv[1]; tmp = src + ".tmp"
zin = zipfile.ZipFile(src); zout = zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED)
for it in zin.infolist():
    d = zin.read(it.filename)
    if it.filename.endswith(".xml") and it.filename.startswith(("ppt/slides/", "ppt/slideLayouts/", "ppt/notesSlides/", "ppt/slideMasters/")):
        d = d.replace(b'lang="en-US"', b'lang="it-IT"')
    zout.writestr(it, d)
zout.close(); zin.close(); shutil.move(tmp, src)
