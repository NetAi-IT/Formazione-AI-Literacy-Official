  function modeTag(s, active) {
    const st = ["Produrre", "Trasformare", "Analizzare", "Recuperare"];
    st.forEach((t, i) => {
      const x = 6.46 + i * 0.77;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.74, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "modalità " + t });
      txt(s, t, { x, y: 0.42, w: 0.74, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "documento " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 8", { placeholder: "kicker" });
    s.addText("AI per testi, documenti e conoscenza", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti all'ottavo tema, che apre una nuova area del percorso: 'Esplorare le possibilità dell'AI'. Nelle aree precedenti abbiamo costruito le basi: che cos'è l'AI e come funziona, quali sono i suoi limiti, come dialogare con essa, come formulare richieste e come verificare i risultati. Ora guardiamo a che cosa si può fare concretamente, partendo dall'ambito in cui l'AI generativa è più matura e più usata: i testi, i documenti e la conoscenza. È un tema che riguarda praticamente ogni ruolo aziendale, perché quasi ogni lavoro produce, legge, trasforma e cerca informazioni scritte. Il punto di vista è quello dell'utilizzatore: capacità applicative e condizioni di efficacia, non configurazione tecnica di sistemi documentali. E il tema va oltre la semplice scrittura: il suo nucleo distintivo è la capacità di sintetizzare, estrarre, confrontare e consultare documenti. Suggerimento per l'apertura: chiedere ai partecipanti quante ore a settimana dedicano a leggere, scrivere, riassumere o cercare informazioni nei documenti. La risposta, di solito sorprendente, mostra perché il tema è rilevante. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; le capacità degli strumenti su documenti lunghi, tabelle e scansioni migliorano di continuo, quindi esempi e limiti vanno ricontrollati sugli strumenti autorizzati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la comprensione delle principali possibilità dell'AI nella produzione, trasformazione, analisi, estrazione e organizzazione di contenuti testuali e documentali, con le relative opportunità, condizioni di efficacia e limiti. La consapevolezza da sviluppare ha due facce. Da un lato, l'AI può supportare molte attività basate sulle informazioni, dalla redazione di un'email alla consultazione di un archivio di procedure. Dall'altro, il valore del risultato dipende da quattro fattori: la qualità delle fonti, la fedeltà dell'elaborazione, la tracciabilità delle informazioni e la capacità di verificarne l'adeguatezza. Un punto chiave che svilupperemo: generare, trasformare, analizzare ed estrarre informazioni sono attività distinte, con esigenze di controllo diverse. Il messaggio centrale del tema: l'AI può generare testi e trasformare documenti in informazioni organizzate, confrontabili e consultabili, ma il valore effettivo richiede di preservare correttezza, significato e tracciabilità, senza confondere un'elaborazione convincente con un'elaborazione completa e verificata.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Conoscere le possibilità dell'AI su testi e documenti", "Distinguere produrre, trasformare, analizzare, estrarre", "Riconoscere opportunità, condizioni di efficacia e limiti"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Da che cosa dipende il valore", headSize: 16, fill: C.accent6, bodySize: 14,
      body: bullets(["Qualità delle fonti", "Fedeltà dell'elaborazione", "Tracciabilità delle informazioni", "Capacità di verificarne l'adeguatezza"], { space: 6 }) });
  }
  {
    const s = content("Undici domande guida", "Le undici domande guida accompagnano il modulo. Le prime due riguardano la produzione di testi: che cosa può fare l'AI oltre alla scrittura, e quando conviene generare un testo nuovo invece di trasformarne uno esistente. Le successive riguardano l'analisi dei documenti: come sintetizzare senza perdere condizioni ed eccezioni, che differenza c'è tra sintetizzare ed estrarre dati, come confrontare documenti mantenendo il collegamento ai passaggi originali. Poi la conoscenza: la differenza tra ricerca su fonti esterne e interrogazione di una raccolta documentale, e che cosa rende una raccolta davvero interrogabile. L'ottava riguarda il passaggio da informazioni non strutturate a dati utilizzabili. Le ultime tre riguardano i limiti: formati, scansioni, tabelle e documenti lunghi; come distinguere una sintesi apparentemente corretta da una fedele; quando risalire alle fonti. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Quali attività sui testi oltre alla scrittura?", "Quando generare e quando trasformare un testo esistente?", "Come sintetizzare senza perdere condizioni ed eccezioni?", "Che differenza tra sintetizzare ed estrarre dati strutturati?", "Come confrontare documenti restando legati ai passaggi originali?", "Ricerca su fonti esterne o interrogazione di una raccolta?", "Che cosa rende una raccolta davvero interrogabile?", "Come passare da testo non strutturato a dati utilizzabili?", "Perché formati, scansioni, tabelle e lunghezza complicano?", "Sintesi apparentemente corretta o fedele e completa?", "Quando risalire alle fonti e verificare l'elaborazione?"], 4, 1.15, 1.08, 11);
  }
  {
    const s = content("Il filo conduttore: quattro modalità", "Il documento di perimetro propone un filo conduttore: quattro modalità applicative, che corrispondono a quattro tipi diversi di lavoro informativo. Produrre: creare contenuti nuovi a partire da istruzioni, come un'email, una relazione, una descrizione. Corrisponde al sottotema 8.1. Trasformare: lavorare su un testo esistente, correggendolo, semplificandolo, traducendolo, cambiandone il formato. Corrisponde all'8.2. Analizzare e strutturare: ricavare da uno o più documenti sintesi, dati strutturati, confronti. Corrispondono l'8.3, l'8.4 e l'8.5, che sono il nucleo distintivo del tema. Recuperare conoscenza: cercare, approfondire e consultare informazioni, sia all'esterno sia in raccolte documentali organizzate. Corrispondono l'8.6 e l'8.7. L'8.8, sui limiti e le condizioni di efficacia, attraversa tutte le modalità. Una precisazione: non è una sequenza obbligatoria. Sono modalità diverse, che spesso si combinano: per preparare un dossier si può cercare, sintetizzare, estrarre e infine produrre un testo. Nelle slide, un indicatore in alto a destra ricorda la modalità di cui stiamo parlando.");
    const st = [["FiEdit3", "Produrre", "Creare contenuti nuovi da istruzioni", "8.1"], ["FiRefreshCw", "Trasformare", "Lavorare su un testo esistente", "8.2"], ["FiLayers", "Analizzare e strutturare", "Sintesi, estrazione, confronto", "8.3  8.4  8.5"], ["FiDatabase", "Recuperare conoscenza", "Ricerca e raccolte documentali", "8.6  8.7"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 2;
      shapeBox(s, x, 1.2, 2.1, 2.75, dark ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.7, 1.35, 0.7, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.1, y: 2.15, w: 1.9, h: 0.6, fontSize: 15, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.8, w: 1.8, h: 0.6, fontSize: 12, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.1, y: 3.5, w: 1.9, h: 0.35, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.4, 0.17);
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.accent6, "limiti trasversali");
    txt(s, [{ text: "8.8 Limiti e condizioni di efficacia: ", options: { bold: true, color: C.accent1 } }, { text: "attraversano tutte le modalità. Non è una sequenza obbligatoria: le modalità spesso si combinano.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Attività diverse, controlli diversi", "Il punto concettuale più importante del tema è che generare, trasformare, analizzare ed estrarre sono attività diverse, con rischi e controlli diversi. Quando si genera, il rischio principale è che il sistema inventi o aggiunga contenuti non corretti o non adatti: il controllo riguarda l'accuratezza e l'adeguatezza al destinatario. Quando si trasforma, il rischio è che la nuova versione alteri il significato del testo di partenza: il controllo è un confronto con l'originale. Quando si sintetizza o si analizza, il rischio è perdere elementi decisivi, come condizioni ed eccezioni: il controllo riguarda la fedeltà e la completezza rispetto al documento. Quando si estrae, il rischio è un dato sbagliato, mancante o inventato, che poi viene usato in attività successive: il controllo riguarda l'accuratezza campo per campo. Quando si recupera conoscenza, il rischio è un'informazione superata, non pertinente o senza fonte: il controllo riguarda attualità, attendibilità e collegamento al documento originale. Non ripetiamo qui i metodi generali di verifica del Tema 7: li applichiamo, in ciascun sottotema, ai contenuti documentali.");
    table(s, [["Attività", "Rischio principale", "Controllo principale"],
      ["Generare", "Contenuti inventati o inadatti", "Accuratezza, adeguatezza al destinatario"],
      ["Trasformare", "Significato alterato", "Confronto con l'originale"],
      ["Sintetizzare, analizzare", "Elementi decisivi persi", "Fedeltà e completezza rispetto al documento"],
      ["Estrarre", "Dato errato, mancante o inventato", "Accuratezza campo per campo"],
      ["Recuperare conoscenza", "Informazione superata o senza fonte", "Attualità, attendibilità, collegamento alla fonte"]],
      { y: 1.15, colW: [2.2, 3.2, 3.6], rowH: 0.5, fontSize: 12, blankCorner: false });
    banner(s, 4.35, "Non è sempre lo stesso controllo: dipende dal tipo di lavoro che l'AI ha svolto.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, tutti con priorità alta e tutti mantenuti distinti. Vanno compresi e sperimentati: generazione, trasformazione e sintesi di testi, estrazione di informazioni, confronto documentale e tracciabilità delle fonti. Vanno conosciuti e compresi: ricerca informativa, gestione della conoscenza, interrogazione documentale, limiti di formati e qualità dei documenti. Vanno solo accennati: architetture RAG, pipeline documentali, sistemi di indicizzazione, database vettoriali, configurazioni di ricerca semantica e integrazioni tecniche. L'enfasi va su 8.3, 8.4, 8.5 e 8.7, il nucleo distintivo del tema, perché mostrano il potenziale dell'AI oltre la generazione di testo. Confini: non ripetiamo i meccanismi tecnici del Tema 2, la teoria delle allucinazioni del Tema 3, le tecniche di prompting del Tema 6, i metodi di verifica del Tema 7. Non approfondiamo l'analisi quantitativa, che è del Tema 9, la multimodalità, del Tema 10, gli agenti e i workflow, del Tema 11, né la progettazione dei sistemi di conoscenza aziendale, del Tema 14. Un'avvertenza pratica valida per tutto il modulo: i documenti di lavoro vanno caricati solo negli strumenti autorizzati dall'azienda, secondo le regole sulla riservatezza dei dati.");
    pathSlide(s, [["8.1", "Generazione di contenuti testuali", "Alta"], ["8.2", "Revisione e trasformazione dei testi", "Alta"], ["8.3", "Sintesi e analisi documentale", "Alta"], ["8.4", "Estrazione e strutturazione", "Alta"], ["8.5", "Confronto documentale", "Alta"], ["8.6", "Ricerca e organizzazione", "Alta"], ["8.7", "Gestione della conoscenza", "Alta"], ["8.8", "Limiti e condizioni di efficacia", "Alta"]],
      [["Comprendere e sperimentare", "Generazione, trasformazione, sintesi, estrazione, confronto, tracciabilità", C.accent1, C.background1], ["Conoscere e comprendere", "Ricerca, gestione della conoscenza, interrogazione documentale, limiti dei formati", C.accent6, C.text1], ["Solo accennare", "RAG, pipeline documentali, indicizzazione, database vettoriali, ricerca semantica", C.background2, C.text1]]);
  }

  // =====================================================================
  section("8.1 Generazione");
  divider("8.1", "Generazione di contenuti testuali", "L'AI può accelerare la produzione di contenuti, ma qualità e adeguatezza vanno presidiate dalla revisione", "Partiamo dalla modalità più nota: produrre testi nuovi. È quella che quasi tutti hanno già provato, ed è anche quella in cui è più facile sopravvalutare il risultato, perché un testo generato è quasi sempre scorrevole e ben impaginato. In questo sottotema, da comprendere e sperimentare, vediamo che cosa si può produrre, come adattare i testi a destinatari e registri diversi, come usare bozze e versioni alternative e, soprattutto, la differenza tra generazione automatica e redazione supervisionata. Come si formulano le richieste l'abbiamo visto nel Tema 6: qui ci concentriamo sulle possibilità e sulle condizioni di efficacia.");
  {
    const s = content("Che cosa si può produrre", "La generazione di testi a partire da istruzioni copre una gamma ampia di contenuti professionali. Comunicazioni: email, risposte a richieste, messaggi, avvisi, comunicazioni interne. Documenti di lavoro: relazioni, report, verbali a partire da appunti, proposte, presentazioni testuali. Contenuti informativi: descrizioni di prodotti o servizi, schede, FAQ, testi per il sito o per la intranet, istruzioni. Bozze e strutture: scalette, indici, prime versioni da completare, modelli riutilizzabili. Il valore principale non è tanto scrivere al posto della persona, quanto superare la pagina bianca e ridurre il tempo delle parti più ripetitive, lasciando più tempo per contenuto, verifica e cura. Un punto da sottolineare: la qualità del testo generato dipende in gran parte dalle informazioni fornite. Se il sistema non conosce i fatti specifici, tende a riempire i vuoti con contenuti generici o inventati. Più il testo riguarda fatti, dati e decisioni specifici dell'azienda, più è importante fornire il materiale di partenza invece di chiedere al sistema di produrlo da zero.");
    modeTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMail", head: "Comunicazioni", body: "Email, risposte, avvisi, comunicazioni interne" },
      { icon: "FiFileText", head: "Documenti di lavoro", body: "Relazioni, report, verbali da appunti, proposte" },
      { icon: "FiInfo", head: "Contenuti informativi", body: "Descrizioni, schede, FAQ, istruzioni, testi per la intranet" },
      { icon: "FiList", head: "Bozze e strutture", body: "Scalette, indici, prime versioni, modelli riutilizzabili" },
    ], 2, { y: 1.2, H: 2.9, headSize: 15, bodySize: 13 });
    banner(s, 4.3, "Più il testo riguarda fatti specifici, più conta fornire il materiale di partenza: altrimenti il sistema riempie i vuoti.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Dalle istruzioni al testo", "Un testo generato è il risultato di tre ingredienti, e la sua qualità dipende da tutti e tre. Il primo sono le istruzioni: scopo, destinatario, tono, lunghezza, struttura. Le tecniche per formularle le abbiamo viste nel Tema 6. Il secondo è il materiale di partenza: fatti, dati, appunti, documenti, decisioni già prese. È l'ingrediente più trascurato e il più importante per i testi professionali. Senza materiale, il sistema produce un testo plausibile ma generico, o peggio inventa dettagli verosimili, come date, nomi, numeri, impegni. Il terzo sono gli esempi e i riferimenti di stile: un testo simile già approvato, le linee guida di comunicazione, il modo in cui l'azienda si rivolge ai clienti. Lo schema in slide mostra il rapporto: le istruzioni dicono come scrivere, il materiale dice che cosa scrivere, gli esempi dicono in che stile. Quando un testo generato delude, conviene chiedersi quale dei tre ingredienti mancava. Spesso il problema non è il sistema, ma il fatto che gli abbiamo chiesto di scrivere qualcosa che non poteva sapere.");
    modeTag(s, 0);
    const ing = [["FiSliders", "Istruzioni", "Come scrivere", "Scopo, destinatario, tono, lunghezza, struttura"], ["FiFolder", "Materiale di partenza", "Che cosa scrivere", "Fatti, dati, appunti, decisioni già prese"], ["FiBookmark", "Esempi e stile", "In che stile", "Testi approvati, linee guida, modo di rivolgersi"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.15 + i * 1.0;
      shapeBox(s, 0.5, y, 5.3, 0.88, i === 1 ? C.accent6 : C.background2, ing[i][1]);
      await iconCircle(s, 0.68, y + 0.17, 0.54, ing[i][0]);
      txt(s, ing[i][1], { x: 1.4, y: y + 0.08, w: 2.3, h: 0.36, fontSize: 14, bold: true, color: C.text1 });
      txt(s, ing[i][2], { x: 3.7, y: y + 0.08, w: 2.0, h: 0.36, fontSize: 12, bold: true, color: C.accent1, align: "right" });
      txt(s, ing[i][3], { x: 1.4, y: y + 0.45, w: 4.3, h: 0.38, fontSize: 12, color: C.text2 });
    }
    arrow(s, 5.95, 2.3, 0.4);
    shapeBox(s, 6.5, 1.15, 3.0, 2.88, C.text1, "testo");
    await iconCircle(s, 7.65, 1.35, 0.7, "FiFileText", C.accent1);
    txt(s, "Testo generato", { x: 6.65, y: 2.15, w: 2.7, h: 0.4, fontSize: 16, bold: true, color: C.background1, align: "center" });
    txt(s, "La qualità dipende da tutti e tre gli ingredienti", { x: 6.7, y: 2.6, w: 2.6, h: 0.9, fontSize: 12, color: C.accent3, align: "center" });
    txt(s, "Senza materiale, il testo è generico, o inventa dettagli verosimili: date, nomi, numeri, impegni.", { x: 0.5, y: 4.3, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.accent5, bold: true });
  }
  {
    const s = content("Adattare il testo ai destinatari", "Uno degli usi più utili della generazione è adattare uno stesso contenuto a destinatari diversi. Lo stesso fatto, per esempio una modifica dell'orario del servizio clienti, va comunicato in modo diverso alla direzione, ai colleghi del servizio clienti e ai clienti. Per la direzione conta il perché e l'impatto: motivazione, costi, effetti attesi. Per i colleghi conta che cosa cambia operativamente: da quando, che cosa devono fare, a chi rivolgersi. Per i clienti conta che cosa cambia per loro, con un tono cortese e senza dettagli interni. L'AI è molto efficace nel produrre rapidamente queste versioni, partendo da un unico contenuto di base. Due attenzioni. Primo, il contenuto di base deve essere corretto e completo: ogni versione eredita gli errori della base. Secondo, ogni versione va controllata per il proprio destinatario: è facile che nella versione per i clienti finisca un dettaglio interno che non dovrebbe esserci, o che nella versione sintetica per la direzione sparisca un'informazione importante. Esempio fittizio in slide.");
    modeTag(s, 0);
    docBox(s, 0.5, 1.15, 9.0, 0.75, "Contenuto di base (esempio fittizio)", "Dal 1° marzo il servizio clienti telefonico sarà attivo dalle 8 alle 18, invece che dalle 9 alle 17.", { fontSize: 12 });
    table(s, [["Destinatario", "Che cosa conta", "Registro"],
      ["Direzione", "Motivazione, costi, effetti attesi", "Sintetico, orientato alle decisioni"],
      ["Colleghi del servizio", "Da quando, nuovi turni, a chi rivolgersi", "Operativo, diretto"],
      ["Clienti", "Che cosa cambia per loro, come contattarci", "Cortese, senza dettagli interni"]],
      { y: 2.05, colW: [2.2, 3.7, 3.1], rowH: 0.45, fontSize: 12, blankCorner: false });
    banner(s, 4.1, "Ogni versione eredita gli errori della base, e va controllata per il proprio destinatario.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Tono, stile e registro", "Tre concetti vicini ma distinti, utili per dare istruzioni precise e valutare il risultato. Il tono è l'atteggiamento verso il destinatario: cordiale, formale, rassicurante, deciso, empatico. Lo stile riguarda le scelte di scrittura: frasi brevi o articolate, lessico tecnico o comune, struttura con elenchi o testo continuo. Il registro è il livello di formalità adatto al contesto: una comunicazione a un ente pubblico, un'email a un collega, un post sulla intranet. L'AI è molto flessibile su tutti e tre: può riscrivere lo stesso contenuto in molte varianti. Alcune attenzioni pratiche. Il tono di default dei sistemi tende a essere entusiasta, cerimonioso e ricco di formule generiche, che in un contesto professionale possono suonare artificiali o poco credibili: conviene indicare esplicitamente il tono desiderato o fornire un esempio. La coerenza con la comunicazione aziendale non è automatica: se l'azienda ha linee guida di stile, vanno fornite. Infine, il tono può cambiare il significato percepito: un messaggio troppo rassicurante su un problema serio, o troppo deciso in una trattativa, può creare aspettative o tensioni non volute.");
    modeTag(s, 0);
    await iconGrid(s, [
      { icon: "FiSmile", head: "Tono", body: "L'atteggiamento verso il destinatario: cordiale, formale, rassicurante, deciso" },
      { icon: "FiFeather", head: "Stile", body: "Le scelte di scrittura: frasi, lessico, struttura" },
      { icon: "FiLayers", head: "Registro", body: "Il livello di formalità adatto al contesto" },
    ], 3, { y: 1.2, h: 1.6, headSize: 15, bodySize: 12 });
    const a = [["Tono di default", "Spesso entusiasta e cerimonioso: indicare il tono o dare un esempio"], ["Coerenza aziendale", "Non automatica: fornire le linee guida di stile"], ["Significato percepito", "Il tono può creare aspettative o tensioni non volute"]];
    a.forEach((e, i) => {
      const y = 3.0 + i * 0.62;
      shapeBox(s, 0.5, y, 9.0, 0.54, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.4, h: 0.54, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.1, y, w: 6.2, h: 0.54, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Bozze e versioni alternative", "Due usi della generazione meritano attenzione perché cambiano il modo di lavorare. Le bozze: l'AI è molto efficace nel produrre una prima versione su cui lavorare. Il valore sta nel ridurre il tempo per arrivare a qualcosa di concreto da migliorare. Ma una bozza è appunto una bozza: va letta, corretta e completata, non solo ritoccata. Le versioni alternative: si possono chiedere più versioni dello stesso testo, con impostazioni diverse, per esempio una più sintetica e una più dettagliata, una più formale e una più diretta, tre possibili oggetti per un'email, due aperture per una relazione. Confrontare alternative aiuta a capire che cosa si vuole davvero e spesso porta a combinare elementi di versioni diverse. Due rischi da conoscere. Il primo è l'ancoraggio, visto nel Tema 5: la prima bozza tende a definire struttura e contenuti anche quando sarebbe meglio un'impostazione diversa. Chiedere alternative fin dall'inizio aiuta a contrastarlo. Il secondo è l'omologazione: testi generati da molte persone con gli stessi strumenti tendono ad assomigliarsi, con le stesse formule e le stesse strutture. Il contributo personale resta ciò che rende un testo riconoscibile.");
    modeTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.45, { icon: "FiEdit", head: "Bozze", headSize: 16, bodySize: 13,
      body: bullets(["Arrivare rapidamente a qualcosa di concreto", "Da leggere, correggere, completare", "Non solo da ritoccare"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.45, { icon: "FiCopy", head: "Versioni alternative", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Sintetica o dettagliata, formale o diretta", "Più oggetti, più aperture", "Confrontare e combinare"], { space: 5 }) });
    const r = [["Ancoraggio", "La prima bozza definisce l'impostazione: chiedere alternative fin dall'inizio"], ["Omologazione", "Testi tutti simili: il contributo personale li rende riconoscibili"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 3.85, 4.35, 1.1, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 3.95, w: 3.95, h: 0.35, fontSize: 14, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.3, w: 3.95, h: 0.6, fontSize: 12, color: C.background1 });
    });
  }
  {
    const s = content("Automatica o supervisionata", "Questa è la distinzione più importante del sottotema. Nella generazione automatica, il testo prodotto dal sistema viene usato così com'è, senza una revisione sostanziale: è il caso di risposte automatiche, descrizioni generate in serie, testi pubblicati direttamente. Nella redazione supervisionata, il sistema produce una proposta e una persona la rivede, la corregge, la completa e ne risponde. Tra i due estremi ci sono gradi intermedi, come una revisione a campione su testi generati in serie. Il livello di supervisione adeguato dipende da tre fattori, coerenti con quanto visto nel Tema 7: le conseguenze di un errore, la visibilità del testo, cioè chi lo leggerà, e la presenza di fatti specifici, dati o impegni. Una bozza di email interna può richiedere una rilettura; una comunicazione a tutti i clienti, un testo contrattuale o una risposta su temi legali o sanitari richiedono una redazione pienamente supervisionata, eventualmente con esperti. La generazione automatica senza revisione è adatta solo a contenuti a basso rischio, con controlli organizzativi definiti. In ogni caso, chi usa e firma il testo ne risponde, come detto nel Tema 7.");
    modeTag(s, 0);
    const lv = [["Generazione automatica", "Il testo è usato così com'è", C.background2, C.text1], ["Supervisione a campione", "Testi in serie, controlli periodici", C.accent6, C.text1], ["Redazione supervisionata", "Una persona rivede, completa e ne risponde", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 1.35, l[2], l[0]);
      txt(s, l[0], { x: x + 0.15, y: 1.3, w: 2.56, h: 0.5, fontSize: 15, bold: true, color: l[3], align: "center", valign: "middle" });
      txt(s, l[1], { x: x + 0.15, y: 1.85, w: 2.56, h: 0.6, fontSize: 12, color: l[3], align: "center" });
      if (i < 2) arrow(s, x + 2.88, 1.72, 0.17);
    });
    txt(s, "Più supervisione quando aumentano", { x: 0.5, y: 2.75, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.15, 2.9, 0.5, "Conseguenze di un errore", { fill: C.background2 });
    chip(s, 3.55, 3.15, 2.9, 0.5, "Visibilità del testo", { fill: C.background2 });
    chip(s, 6.6, 3.15, 2.9, 0.5, "Fatti, dati, impegni", { fill: C.background2 });
    banner(s, 3.95, "Generazione automatica solo per contenuti a basso rischio, con controlli definiti. Chi usa il testo ne risponde.", { h: 0.9, fontSize: 13 });
  }
  keySlide("L'AI può accelerare la produzione di contenuti, ma qualità, accuratezza e adeguatezza devono essere presidiate dal processo di revisione umano e organizzativo.", "Sottotema 8.1  ·  Generazione di contenuti testuali", "Concetto chiave del primo sottotema. Generare testi è la modalità più nota e immediata: email, relazioni, descrizioni, bozze, versioni per destinatari diversi. Ma la qualità dipende da istruzioni, materiale di partenza ed esempi; il tono di default e l'omologazione vanno gestiti; e soprattutto, il livello di supervisione deve essere proporzionato alle conseguenze di un errore e alla visibilità del testo. Si noti che il concetto chiave parla di revisione umana e organizzativa: non basta la buona volontà del singolo, servono anche regole su quali testi richiedono quale revisione. Esercizio suggerito: partire da un contenuto di base fittizio e chiedere ai partecipanti di generare tre versioni per destinatari diversi, poi confrontarle per individuare informazioni perse o aggiunte.");

  // =====================================================================
  section("8.2 Trasformazione");
  divider("8.2", "Revisione, riscrittura e trasformazione", "Trasformare un testo richiede di controllare che la nuova formulazione non alteri significati e informazioni", "Seconda modalità: trasformare. Qui il punto di partenza non sono istruzioni, ma un testo che esiste già, nostro o di altri. L'AI può correggerlo, renderlo più chiaro, semplificarlo, riformularlo, tradurlo, cambiarne il formato o la struttura. È una modalità molto potente e spesso sottovalutata, perché il controllo è più semplice che nella generazione: c'è un originale con cui confrontare il risultato. Ma ha un rischio specifico, che è il filo rosso del sottotema: la trasformazione può alterare il significato senza che ce ne accorgiamo. In questo sottotema, da comprendere e sperimentare, vediamo le principali trasformazioni e come distinguere modifiche formali da modifiche sostanziali.");
  {
    const s = content("Generare o trasformare?", "Una delle domande guida chiede quando conviene generare un testo nuovo e quando è più opportuno trasformarne uno esistente. Generare conviene quando non esiste un punto di partenza adatto e il contenuto è relativamente generico, oppure quando si vuole esplorare impostazioni diverse. Trasformare conviene quando esiste già un testo che contiene i contenuti corretti: una procedura approvata da semplificare, una relazione tecnica da rendere comprensibile alla direzione, appunti di una riunione da trasformare in verbale, un testo da tradurre. In questi casi la trasformazione ha due vantaggi importanti. Il primo è l'affidabilità: il sistema lavora su contenuti forniti, invece di produrli, e quindi il rischio di invenzioni si riduce, anche se non si azzera. Il secondo è la verificabilità: c'è un originale con cui confrontare il risultato, e quindi il controllo è più semplice e più mirato. Per questo, per i testi professionali che riguardano fatti specifici, una buona regola è partire dal materiale esistente quando c'è, e usare l'AI per trasformarlo, invece di chiederle di generare da zero.");
    modeTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiEdit3", head: "Generare conviene se", headSize: 16, bodySize: 13,
      body: bullets(["Non c'è un punto di partenza adatto", "Il contenuto è relativamente generico", "Si vogliono esplorare impostazioni diverse"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiRefreshCw", head: "Trasformare conviene se", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Esiste un testo con i contenuti corretti", "Procedure, relazioni, appunti, testi da tradurre", "Meno invenzioni, controllo più semplice"], { space: 5 }) });
    banner(s, 4.0, "Per i testi su fatti specifici: partire dal materiale esistente, quando c'è, e trasformarlo.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Le principali trasformazioni", "Una panoramica delle trasformazioni più utili. Correzione grammaticale e stilistica: refusi, concordanze, punteggiatura, ripetizioni. Miglioramento di chiarezza e leggibilità: frasi più brevi, ordine logico, eliminazione di ambiguità. Semplificazione: rendere comprensibile un testo complesso a chi non è esperto. Riformulazione e adattamento del linguaggio: cambiare registro, tono o lessico per un destinatario diverso. Traduzione e localizzazione: non solo tradurre, ma adattare a un contesto culturale e locale, con formati di date, unità, riferimenti. Trasformazione tra formati: da appunti a verbale, da relazione a slide, da procedura a FAQ, da email lunga a messaggio breve. Revisione della struttura: riorganizzare un testo, aggiungere titoli, spostare le informazioni importanti all'inizio. Le prime trasformazioni dell'elenco tendono a intervenire più sulla forma, le ultime più profondamente sul contenuto e sulla sua organizzazione. Più la trasformazione è profonda, più è alto il rischio di alterare il significato, e più è importante il controllo.");
    modeTag(s, 1);
    await iconGrid(s, [
      { icon: "FiCheckSquare", head: "Correzione", body: "Refusi, concordanze, punteggiatura" },
      { icon: "FiEye", head: "Chiarezza e leggibilità", body: "Frasi brevi, ordine logico, meno ambiguità" },
      { icon: "FiMinimize2", head: "Semplificazione", body: "Comprensibile anche ai non esperti" },
      { icon: "FiRepeat", head: "Riformulazione", body: "Registro, tono, lessico per un altro destinatario" },
      { icon: "FiGlobe", head: "Traduzione e localizzazione", body: "Lingua, contesto culturale, formati locali" },
      { icon: "FiShuffle", head: "Cambio di formato", body: "Appunti in verbale, procedura in FAQ" },
    ], 3, { y: 1.15, H: 2.85, headSize: 13, bodySize: 12 });
    txt(s, "Più profonda la trasformazione", { x: 0.5, y: 4.2, w: 2.6, h: 0.5, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 3.1, y: 4.29, w: 2.6, h: 0.32, fill: { color: C.accent5 }, line: { type: "none" }, objectName: "freccia rischio" });
    txt(s, "più alto il rischio di alterare il significato", { x: 5.85, y: 4.2, w: 3.65, h: 0.5, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
  }
  {
    const s = content("Semplificare senza tradire", "La semplificazione è una delle trasformazioni più utili e più delicate. Utile, perché molti testi aziendali, come procedure, regolamenti, documentazione tecnica e comunicazioni normative, sono difficili da leggere per chi deve applicarli. Delicata, perché semplificare significa scegliere che cosa togliere e come riformulare, e in queste scelte si nascondono i rischi. L'esempio fittizio in slide mostra una clausola di una procedura interna e una semplificazione apparentemente ben fatta. La versione semplificata è chiara e scorrevole, ma ha perso due elementi: il limite di importo oltre il quale serve l'autorizzazione, e l'eccezione per gli acquisti urgenti, che ha un iter diverso. Chi la legge applicherà la regola in modo sbagliato in due casi su tre. Il problema non è la semplificazione, ma la mancanza di controllo. Per semplificare in modo fedele conviene indicare esplicitamente che cosa deve restare, per esempio importi, scadenze, condizioni ed eccezioni, e poi confrontare punto per punto la versione semplificata con l'originale. Nei testi con valore normativo o contrattuale, la versione semplificata dovrebbe rimandare all'originale come riferimento valido.");
    modeTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 2.65, "Originale (esempio fittizio)", "Gli acquisti di importo superiore a 5.000 euro richiedono l'autorizzazione preventiva del responsabile di funzione e dell'ufficio acquisti. Per gli acquisti urgenti, documentati come tali, l'autorizzazione dell'ufficio acquisti può essere richiesta entro tre giorni lavorativi successivi.", { fontSize: 12 });
    docBox(s, 5.15, 1.15, 4.35, 2.65, "Versione semplificata", "Prima di fare un acquisto serve l'autorizzazione del proprio responsabile e dell'ufficio acquisti.", { fontSize: 13, fill: C.accent6 });
    chip(s, 5.35, 2.45, 1.95, 0.42, "Manca la soglia", { fill: C.accent5, color: C.background1, fontSize: 11 });
    chip(s, 7.4, 2.45, 1.9, 0.42, "Manca l'eccezione", { fill: C.accent5, color: C.background1, fontSize: 11 });
    banner(s, 4.0, "Chiara, scorrevole e sbagliata. Indicare che cosa deve restare e confrontare punto per punto con l'originale.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Tradurre e localizzare", "La traduzione è uno degli ambiti in cui i sistemi linguistici danno risultati migliori, soprattutto tra lingue molto diffuse. Ma tradurre un testo professionale non è solo cambiare lingua. La localizzazione adatta il testo al contesto del destinatario: formati di date, numeri e valute, unità di misura, riferimenti normativi o istituzionali che possono non avere un equivalente, convenzioni di cortesia, esempi culturalmente appropriati. Alcune attenzioni specifiche. La terminologia tecnica e aziendale: un termine di settore può avere più traduzioni possibili, e il sistema può sceglierne una diversa da quella usata in azienda o nel settore; conviene fornire un glossario. I falsi amici e le sfumature: termini simili con significato diverso, gradi di obbligo come 'deve' e 'dovrebbe', che in un contratto fanno una grande differenza. Le lingue meno diffuse, per cui la qualità può essere inferiore. I testi con valore legale o contrattuale, per cui una traduzione automatica non sostituisce la traduzione professionale certificata quando richiesta. Un controllo utile, quando non si conosce bene la lingua di arrivo, è far ritradurre il testo nella lingua originale da uno strumento diverso: non è una prova, ma fa emergere molti scostamenti di significato.");
    modeTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiGlobe", head: "Localizzare significa adattare", headSize: 15, bodySize: 13,
      body: bullets(["Date, numeri, valute, unità di misura", "Riferimenti normativi e istituzionali", "Convenzioni di cortesia, esempi culturali"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiAlertTriangle", head: "Attenzioni", headSize: 15, bodySize: 13, fill: C.accent6, iconBg: C.accent5,
      body: bullets(["Terminologia: fornire un glossario", "Sfumature: 'deve' e 'dovrebbe' non sono uguali", "Lingue meno diffuse, testi con valore legale"], { space: 4 }) });
    shapeBox(s, 0.5, 3.6, 9.0, 1.3, C.background2, "ritraduzione");
    await iconCircle(s, 0.7, 3.85, 0.6, "FiRepeat", C.accent1);
    txt(s, "Controllo utile se non si conosce la lingua di arrivo", { x: 1.5, y: 3.7, w: 7.8, h: 0.4, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Ritradurre nella lingua originale con uno strumento diverso: non è una prova, ma fa emergere molti scostamenti di significato.", { x: 1.5, y: 4.1, w: 7.8, h: 0.7, fontSize: 13, color: C.text2 });
  }
  {
    const s = content("Cambiare formato e struttura", "Due trasformazioni che cambiano l'organizzazione del contenuto più che le singole frasi. La trasformazione tra formati testuali porta lo stesso contenuto in una forma diversa, adatta a un altro uso: appunti di riunione in un verbale con decisioni e azioni; una relazione lunga in una sintesi per la direzione o in punti per una presentazione; una procedura in una lista di controllo o in FAQ; una email lunga in un messaggio breve; un testo in una tabella. La revisione della struttura riorganizza un testo esistente: mettere all'inizio le informazioni più importanti, aggiungere titoli e sezioni, raggruppare argomenti dispersi, eliminare ripetizioni, separare ciò che è obbligatorio da ciò che è consigliato. Sono trasformazioni molto utili, ma con un rischio specifico: nel cambiare forma, alcune informazioni possono andare perse o cambiare peso. Nel passaggio da appunti a verbale, per esempio, il sistema può trasformare un'ipotesi discussa in una decisione presa, o attribuire un'azione alla persona sbagliata. Nel passaggio da testo a elenco puntato, i legami logici, come 'solo se' o 'a meno che', possono sparire. Il controllo consiste nel verificare che ogni elemento importante dell'originale sia presente, con lo stesso peso e lo stesso significato.");
    modeTag(s, 1);
    const tr = [["Appunti", "Verbale con decisioni e azioni"], ["Relazione lunga", "Sintesi per la direzione"], ["Procedura", "Lista di controllo o FAQ"], ["Testo continuo", "Tabella o elenco"]];
    tr.forEach((e, i) => {
      const y = 1.15 + i * 0.6;
      chip(s, 0.5, y, 1.9, 0.5, e[0], { fill: C.background2, fontSize: 12 });
      arrow(s, 2.5, y + 0.09, 0.35);
      chip(s, 2.95, y, 2.35, 0.5, e[1], { fill: C.accent6, fontSize: 12 });
    });
    await card(s, 5.55, 1.15, 3.95, 2.3, { icon: "FiAlertTriangle", inline: true, head: "Che cosa può succedere", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Un'ipotesi discussa diventa una decisione", "Un'azione attribuita alla persona sbagliata", "Spariscono 'solo se' e 'a meno che'", "Un dettaglio secondario diventa centrale"], { space: 4 }) });
    banner(s, 3.75, "Controllo: ogni elemento importante dell'originale è presente, con lo stesso peso e lo stesso significato?", { h: 0.75, fontSize: 13 });
    txt(s, "Revisione della struttura: informazioni importanti all'inizio, titoli, raggruppamenti, obbligatorio separato da consigliato.", { x: 0.5, y: 4.6, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Modifiche formali e sostanziali", "La distinzione chiave del sottotema. Una modifica formale cambia il modo in cui una cosa è detta, senza cambiare che cosa è detto: correggere un refuso, spezzare una frase lunga, sostituire un termine con un sinonimo davvero equivalente, riordinare elementi senza legami logici. Una modifica sostanziale cambia il contenuto: un'informazione aggiunta o tolta, un grado di obbligo modificato, una condizione eliminata, un'attribuzione cambiata, un numero alterato. Il problema è che molte modifiche che sembrano formali sono in realtà sostanziali. La tabella mostra alcuni esempi. Passare da 'entro il 15' a 'verso metà mese' sembra una semplificazione, ma cambia una scadenza in un'indicazione vaga. Passare da 'si raccomanda' a 'è obbligatorio' sembra una riformulazione, ma cambia il grado di obbligo. Passare da 'in alcuni casi' a 'spesso' cambia la frequenza. Eliminare 'salvo diversa indicazione' cancella un'eccezione. Quando si chiede una trasformazione, conviene esplicitare il tipo di modifiche ammesse, per esempio 'correggi solo grammatica e punteggiatura, non cambiare contenuti'. E chiedere al sistema di segnalare le modifiche sostanziali che ritiene necessarie, invece di applicarle.");
    modeTag(s, 1);
    table(s, [["Originale", "Trasformato", "Che cosa è cambiato"],
      ["Entro il 15 del mese", "Verso metà mese", "Una scadenza diventa vaga"],
      ["Si raccomanda di...", "È obbligatorio...", "Il grado di obbligo"],
      ["In alcuni casi", "Spesso", "La frequenza"],
      ["Salvo diversa indicazione, ...", "(eliminato)", "Un'eccezione cancellata"],
      ["Il fornitore propone", "Il fornitore garantisce", "Un impegno attribuito"]],
      { y: 1.15, colW: [3.0, 2.7, 3.3], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 2 });
    banner(s, 3.85, "Esplicitare le modifiche ammesse e chiedere di segnalare, non applicare, quelle sostanziali.", { h: 0.6, fontSize: 13 });
    txt(s, "Molte modifiche che sembrano formali sono sostanziali.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Preservare il significato originale", "Come si controlla, in pratica, che una trasformazione abbia preservato il significato? Alcune tecniche, dalla più semplice alla più strutturata. Primo, definire in anticipo che cosa deve restare invariato: importi, date, scadenze, nomi, condizioni, eccezioni, gradi di obbligo, impegni. Sono gli elementi più a rischio e quelli con le conseguenze più serie. Secondo, chiedere al sistema di elencare le modifiche apportate, distinguendo quelle formali da quelle che potrebbero toccare il contenuto. Non è una garanzia, come visto nel Tema 7, ma aiuta a dirigere l'attenzione. Terzo, usare il confronto tra versioni, con gli strumenti di revisione dei programmi di scrittura, per vedere esattamente che cosa è cambiato. Quarto, per i testi importanti, rileggere l'originale e il trasformato affiancati, punto per punto, controllando gli elementi critici. Quinto, per i testi con valore normativo, contrattuale o tecnico, far validare la versione trasformata da chi conosce la materia, e mantenere l'originale come riferimento. Il principio è semplice: più il testo ha conseguenze, più il confronto con l'originale deve essere sistematico.");
    modeTag(s, 1);
    numList(s, ["Definire in anticipo che cosa non deve cambiare: importi, date, condizioni, eccezioni, obblighi", "Chiedere l'elenco delle modifiche, formali e potenzialmente sostanziali", "Usare il confronto tra versioni per vedere che cosa è cambiato", "Rileggere originale e trasformato affiancati, sui punti critici", "Per testi normativi, contrattuali o tecnici: validazione esperta, originale come riferimento"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "Più il testo ha conseguenze, più il confronto con l'originale deve essere sistematico.", { h: 0.65, fontSize: 13 });
  }
  keySlide("Trasformare un testo richiede di controllare che la nuova formulazione non alteri significati, intenzioni o informazioni rilevanti.", "Sottotema 8.2  ·  Revisione, riscrittura e trasformazione", "Concetto chiave del secondo sottotema. Trasformare un testo esistente è spesso preferibile a generarlo da zero, perché riduce le invenzioni e offre un originale con cui confrontare il risultato. Le trasformazioni possibili sono molte: correzione, chiarezza, semplificazione, riformulazione, traduzione, cambio di formato e di struttura. Il rischio comune è l'alterazione del significato, spesso nascosta in modifiche che sembrano formali. Il concetto chiave cita anche le intenzioni: un testo riformulato può dire le stesse cose con un'intenzione diversa, per esempio più perentoria o più accomodante. Esercizio suggerito: dare ai partecipanti un paragrafo fittizio di procedura, farlo semplificare con l'AI e chiedere di trovare tutte le differenze di contenuto tra originale e semplificato.");
