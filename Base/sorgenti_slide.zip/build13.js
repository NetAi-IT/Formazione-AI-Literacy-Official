const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 13: AI e trasformazione del lavoro e dei processi";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 13  ·  AI e trasformazione del lavoro e dei processi";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5, X = o.x || 0.5, W = o.w || 9.0;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, X, y, W, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: X + 0.15, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: X + 0.15 + lw, y, w: W - 0.3 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }
  function workTag(s, active) {
    const st = ["Attività", "Processi", "Persone", "Rischi"];
    st.forEach((t, i) => {
      const x = 6.3 + i * 0.81;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.78, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "dimensione " + t });
      txt(s, t, { x, y: 0.42, w: 0.78, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 13", { placeholder: "kicker" });
    s.addText("AI e trasformazione del lavoro e dei processi", { placeholder: "title" });
    s.addText("Area: Comprendere il valore per l'azienda", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al tredicesimo tema, il secondo dell'area 'Comprendere il valore per l'azienda'. Nel Tema 12 abbiamo visto che il valore dell'AI dipende spesso da scelte organizzative: come si usa il tempo liberato, come cambiano i processi, come si mantengono le competenze. Qui guardiamo proprio a questo: come l'AI può modificare le attività professionali, i processi, la collaborazione, le competenze e i ruoli. È un tema delicato, perché tocca da vicino le persone e il loro lavoro, ed è spesso affrontato nei media con toni estremi: o la promessa che l'AI libererà tutti dalle attività noiose, o il timore che sostituirà intere professioni. Il documento di perimetro chiede un approccio diverso: riconoscere che gli effetti sul lavoro dipendono tanto dalle capacità tecnologiche quanto dalle scelte organizzative, e non sono predeterminati. Non facciamo previsioni occupazionali, che richiederebbero analisi specialistiche; diamo strumenti per capire che cosa può cambiare e da che cosa dipende. Il confine con il Tema 16: qui studiamo che cosa cambia nel lavoro; nel Tema 16 vedremo come gestire e accompagnare il cambiamento. Suggerimento per l'apertura: chiedere ai partecipanti di descrivere in tre righe come è cambiato il loro lavoro negli ultimi due anni, se è cambiato, per effetto dell'AI. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; il dibattito sugli effetti dell'AI sul lavoro è molto attivo, e stime e studi vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere come l'AI possa modificare le attività professionali, i processi operativi, la collaborazione, le competenze e i ruoli, riconoscendo che gli effetti sul lavoro dipendono tanto dalle capacità tecnologiche quanto dalle scelte organizzative. La consapevolezza da sviluppare: l'AI può supportare, automatizzare o trasformare singole attività, ma ciò non implica automaticamente né la sostituzione delle professioni né il miglioramento dei processi. Gli esiti dipendono dalla distribuzione del lavoro, dalle interdipendenze tra attività, dalle competenze e dalle modalità di supervisione. Il messaggio centrale del tema: l'AI può modificare come vengono svolti i compiti, organizzati i processi e distribuite competenze e responsabilità; gli effetti non sono predeterminati dalla tecnologia, dipendono dal contesto e dalle scelte organizzative, e possono comprendere sia nuovi benefici sia nuove attività e rischi.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Capire come l'AI può cambiare attività, processi, collaborazione, competenze e ruoli", "Riconoscere il peso delle scelte organizzative"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Supportare, automatizzare o trasformare un'attività non implica sostituire una professione né migliorare un processo.\n\nGli esiti dipendono da distribuzione del lavoro, interdipendenze, competenze e supervisione." });
  }
  {
    const s = content("Compito, processo, ruolo", "Il documento di perimetro indica tre livelli da distinguere, che attraversano tutto il modulo e che conviene presentare subito. Il compito: cambia il modo in cui si svolge un'operazione specifica. Per esempio, scrivere la bozza di una risposta a un cliente, riassumere un documento, compilare un modulo. Il processo: cambiano sequenze di attività, passaggi di consegne, controlli e interdipendenze. Per esempio, l'intero percorso dalla richiesta del cliente alla risposta, con le persone, i sistemi e i controlli coinvolti. Il ruolo: cambia l'insieme di responsabilità, attività e competenze professionali. Per esempio, che cosa fa e di che cosa risponde un addetto all'assistenza clienti. I tre livelli sono collegati, ma un cambiamento a un livello non implica automaticamente un cambiamento agli altri. Si può trasformare un compito senza che il processo migliori, come visto nel Tema 12 per i colli di bottiglia. Si possono automatizzare molti compiti senza che il ruolo scompaia, perché il ruolo comprende anche altre attività. Molta della confusione nel dibattito sull'AI e il lavoro nasce dal passare da un livello all'altro senza accorgersene: 'l'AI può scrivere email, quindi gli addetti all'assistenza verranno sostituiti'.");
    const l = [["FiCheckSquare", "Compito", "Cambia il modo di svolgere un'operazione", "Scrivere la bozza di una risposta"], ["FiGitBranch", "Processo", "Cambiano sequenze, passaggi, controlli, interdipendenze", "Dalla richiesta del cliente alla risposta"], ["FiUser", "Ruolo", "Cambia l'insieme di responsabilità, attività, competenze", "Che cosa fa un addetto all'assistenza"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.55, i === 1 ? C.accent6 : C.background2, l[i][1]);
      await iconCircle(s, x + 1.08, 1.27, 0.7, l[i][0]);
      txt(s, l[i][1], { x: x + 0.15, y: 2.05, w: 2.56, h: 0.42, fontSize: 18, bold: true, color: C.text1, align: "center" });
      txt(s, l[i][2], { x: x + 0.2, y: 2.5, w: 2.46, h: 0.6, fontSize: 12, color: C.text2, align: "center" });
      txt(s, l[i][3], { x: x + 0.2, y: 3.15, w: 2.46, h: 0.45, fontSize: 11, italic: true, color: C.accent1, align: "center" });
    }
    banner(s, 3.9, "Un cambiamento a un livello non implica gli altri. 'L'AI scrive email, quindi gli addetti verranno sostituiti' salta due livelli.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Nove domande guida", "Le nove domande guida accompagnano il modulo. Le prime tre riguardano le attività: come l'AI modifica la natura del lavoro, la differenza tra compiti, mansioni, ruoli e processi, e quali caratteristiche rendono un'attività più o meno trasformabile. La quarta riguarda i processi: perché automatizzare un compito non equivale a migliorare un processo. Le successive tre riguardano le persone: come cambiano collaborazione, supervisione e responsabilità; quali effetti sui ruoli, senza assumere risultati occupazionali predeterminati; come cambiano competenze e opportunità di apprendimento. Le ultime due riguardano gli effetti meno visibili: perché la trasformazione può creare nuove attività oltre a ridurne alcune, e quali rischi emergono quando si introduce l'AI in processi già inefficienti. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Come può l'AI modificare il lavoro quotidiano?", "Compiti, mansioni, ruoli, processi: che differenza?", "Che cosa rende un'attività trasformabile?", "Perché un compito automatizzato non migliora il processo?", "Come cambiano collaborazione, supervisione, responsabilità?", "Quali effetti sui ruoli, senza esiti predeterminati?", "Come cambiano competenze e apprendimento?", "Perché la trasformazione crea anche nuove attività?", "Quali rischi in processi già inefficienti?"], 3, 1.12, 1.0, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in quattro dimensioni. La trasformazione delle attività: come cambia il lavoro e quali attività sono più trasformabili, nei sottotemi 13.1 e 13.2. La trasformazione dei processi: dal compito al processo, nel 13.3. Collaborazione, ruoli e competenze: come si lavora con l'AI, come evolvono ruoli e responsabilità, come cambia la collaborazione nei team, quali competenze servono, dal 13.4 al 13.7. Condizioni e rischi, nel 13.8. Il documento indica 13.1, 13.3, 13.4 e 13.5 come i sottotemi da approfondire maggiormente, perché chiariscono i cambiamenti essenziali di compiti, processi e ruoli. Tre precisazioni trasversali accompagnano tutto il tema. Esposizione non equivale a sostituzione: la possibilità tecnica di automatizzare un'attività non permette di dedurre che sarà adottata, né quali effetti avrà sull'occupazione. Compiti semplici possono essere formativi: affidarli all'AI può ridurre le occasioni di pratica. Il nuovo lavoro va conteggiato: supervisione, eccezioni e controllo modificano il bilancio della trasformazione. Nelle slide, un indicatore in alto a destra ricorda la dimensione di cui stiamo parlando.");
    const d = [["FiCheckSquare", "Attività", "13.1  13.2"], ["FiGitBranch", "Processi", "13.3"], ["FiUsers", "Persone: collaborazione, ruoli, competenze", "13.4  13.5  13.6  13.7"], ["FiAlertTriangle", "Condizioni e rischi", "13.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.0, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.03, w: 1.9, h: 0.6, fontSize: 13, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.65, w: 1.9, h: 0.35, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Tre precisazioni trasversali", { x: 0.5, y: 3.3, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const p = ["Esposizione non equivale a sostituzione", "Compiti semplici possono essere formativi", "Il nuovo lavoro va conteggiato"];
    p.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.7, 2.86, 0.85, t, { fill: C.accent6, fontSize: 13 }));
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, la collaborazione nei team e tra funzioni, con priorità media. Vanno compresi e applicati: le differenze tra livelli di trasformazione, il riconoscimento delle attività, le modifiche nei flussi, la supervisione e la distribuzione delle responsabilità. Vanno conosciuti: l'evoluzione delle mansioni, la collaborazione tra funzioni, le nuove attività e il rischio di erosione dell'esperienza professionale. Vanno solo accennati: Business Process Reengineering, workforce planning, analisi occupazionali specialistiche, progettazione organizzativa avanzata e metodologie complete di change management. Confini: non ripetiamo la collaborazione conversazionale del Tema 5, le tecniche di verifica del Tema 7, il funzionamento degli agenti del Tema 11, la classificazione dei benefici del Tema 12. Non trattiamo il patrimonio informativo, del Tema 14, la scelta dei progetti, del Tema 15, la gestione del cambiamento, del Tema 16, né governance, privacy e normativa, dei Temi 17 e 18.");
    pathSlide(s, [["13.1", "Come l'AI modifica il lavoro", "Alta"], ["13.2", "Attività trasformabili", "Alta"], ["13.3", "Dal compito al processo", "Alta"], ["13.4", "Collaborazione tra persone e AI", "Alta"], ["13.5", "Ruoli e responsabilità", "Alta"], ["13.6", "Team e funzioni", "Media"], ["13.7", "Competenze e modi di lavorare", "Alta"], ["13.8", "Condizioni e rischi", "Alta"]],
      [["Comprendere e applicare", "Livelli di trasformazione, attività, flussi, supervisione, responsabilità", C.accent1, C.background1], ["Conoscere", "Mansioni, collaborazione tra funzioni, nuove attività, erosione dell'esperienza", C.accent6, C.text1], ["Solo accennare", "Reengineering, workforce planning, analisi occupazionali, change management", C.background2, C.text1]]);
  }

  // =====================================================================
  section("13.1 La natura del lavoro");
  divider("13.1", "Come l'AI modifica la natura del lavoro", "Le capacità tecniche dell'AI non consentono, da sole, di dedurre effetti certi su professioni o occupazione", "Partiamo dal quadro generale. In questo sottotema, da comprendere, costruiamo il vocabolario per parlare di lavoro e AI: attività, compiti, mansioni, ruoli. Vediamo i tipi di lavoro e come l'AI interviene su ciascuno, la differenza tra attività assistite, automatizzate e trasformate, e soprattutto la distinzione tra l'automazione dei compiti e la sostituzione delle professioni, che è la prima integrazione del tema. E una distinzione che il dibattito pubblico trascura spesso: tra l'esposizione di un lavoro all'AI e la sua effettiva trasformazione.");
  {
    const s = content("Attività, compiti, mansioni, ruoli", "La prima domanda guida chiede la differenza tra compiti, mansioni, ruoli e processi, e il sottotema parte da qui. Usiamo definizioni semplici e funzionali, utili per ragionare. Un'attività o un compito è un'unità di lavoro con un obiettivo definito: rispondere a un'email, preparare un preventivo, controllare una fattura, condurre un colloquio. La mansione è l'insieme dei compiti assegnati a una posizione, spesso descritto in un mansionario: per esempio, gestire le richieste dei clienti, aggiornare l'anagrafica, preparare i report mensili. Il ruolo è più ampio della mansione: comprende le responsabilità, cioè di che cosa si risponde, le relazioni con gli altri, le competenze richieste, il contributo atteso all'organizzazione, e anche ciò che non è scritto nel mansionario ma che la persona fa, come aiutare i colleghi nuovi o gestire i clienti difficili. Il processo, infine, attraversa i ruoli: è la sequenza di attività, svolte da persone e sistemi diversi, che produce un risultato. Lo schema in slide mostra la gerarchia. Ragionare sull'AI a livello di compiti, invece che di ruoli interi, è uno degli strumenti più utili di questo modulo: l'AI interviene quasi sempre su compiti, non su ruoli.");
    workTag(s, 0);
    const l = [["Compito", "Un'unità di lavoro con un obiettivo", "Preparare un preventivo"], ["Mansione", "L'insieme dei compiti di una posizione", "Gestire richieste, anagrafica, report"], ["Ruolo", "Mansione più responsabilità, relazioni, competenze, contributo", "Anche ciò che non è scritto: aiutare i nuovi, i clienti difficili"]];
    l.forEach((e, i) => {
      const y = 1.15 + i * 0.9, w = 6.0 + i * 0.5;
      shapeBox(s, 0.5, y, w, 0.8, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: 0.65, y, w: 1.5, h: 0.8, fontSize: 15, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.15, y: y + 0.06, w: w - 1.8, h: 0.35, fontSize: 12, bold: true, color: i === 2 ? C.background1 : C.text1 });
      txt(s, e[2], { x: 2.15, y: y + 0.42, w: w - 1.8, h: 0.35, fontSize: 11, italic: true, color: i === 2 ? C.accent6 : C.text2 });
    });
    shapeBox(s, 0.5, 3.95, 9.0, 0.55, C.background2, "processo");
    txt(s, [{ text: "Processo: ", options: { bold: true, color: C.accent1 } }, { text: "attraversa i ruoli, sequenza di attività di persone e sistemi diversi che produce un risultato.", options: { color: C.text1 } }], { x: 0.7, y: 3.95, w: 8.6, h: 0.55, fontSize: 12, valign: "middle" });
    txt(s, "L'AI interviene quasi sempre su compiti, non su ruoli interi.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Tipi di lavoro", "Il sottotema distingue quattro tipi di lavoro, utili per capire dove l'AI generativa interviene di più. Il lavoro manuale: attività fisiche, come produrre, assemblare, trasportare, manutenere. L'AI generativa interviene poco direttamente, anche se può supportare con istruzioni, diagnosi, documentazione; la robotica è un altro discorso. Il lavoro ripetitivo: attività con regole stabili, come compilare, registrare, controllare formalmente. Qui l'automazione tradizionale, vista nel Tema 11, interviene da tempo; l'AI la estende ai casi con informazioni non strutturate. Il lavoro informativo: attività basate sulla gestione di informazioni e documenti, come cercare, riassumere, organizzare, comunicare. È l'ambito in cui l'AI generativa ha l'impatto più diretto, come visto nei Temi 8 e 9. Il lavoro cognitivo: attività che richiedono analisi, interpretazione, giudizio, creatività, relazione. L'AI può supportarle, per esempio esplorando alternative o preparando analisi, ma il giudizio, la relazione e la responsabilità restano umani. Un'osservazione importante, spesso notata dagli economisti: a differenza delle ondate di automazione precedenti, che riguardavano soprattutto il lavoro manuale e ripetitivo, l'AI generativa tocca soprattutto il lavoro informativo e cognitivo, cioè professioni che finora erano state poco esposte all'automazione.");
    workTag(s, 0);
    const t = [["FiTool", "Manuale", "Produrre, assemblare, manutenere", "Intervento indiretto: istruzioni, diagnosi"], ["FiRepeat", "Ripetitivo", "Compilare, registrare, controllare", "Automazione tradizionale, estesa dall'AI"], ["FiFileText", "Informativo", "Cercare, riassumere, comunicare", "L'impatto più diretto dell'AI generativa"], ["FiCpu", "Cognitivo", "Analizzare, giudicare, creare, relazionarsi", "Supporto; giudizio e relazione restano umani"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.75, i === 2 ? C.accent6 : C.background2, t[i][1]);
      await iconCircle(s, x + 0.72, 1.27, 0.66, t[i][0]);
      txt(s, t[i][1], { x: x + 0.1, y: 2.0, w: 1.95, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, t[i][2], { x: x + 0.12, y: 2.42, w: 1.91, h: 0.6, fontSize: 11, color: C.text2, align: "center" });
      txt(s, t[i][3], { x: x + 0.12, y: 3.05, w: 1.91, h: 0.75, fontSize: 11, bold: true, color: C.accent1, align: "center" });
    }
    banner(s, 4.1, "A differenza delle ondate precedenti, l'AI generativa tocca soprattutto il lavoro informativo e cognitivo.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Assistite, automatizzate, trasformate", "Il sottotema distingue tre modi in cui l'AI può intervenire su un'attività. Un'attività assistita resta svolta dalla persona, che usa l'AI come supporto: chiede una bozza, una sintesi, un suggerimento, e poi decide e completa. Il modo di lavorare cambia poco, la responsabilità resta interamente della persona. È il caso più diffuso oggi. Un'attività automatizzata è svolta dal sistema, in tutto o in parte, con la persona che interviene solo per supervisione o eccezioni, come visto nel Tema 11. Il modo di lavorare cambia molto per quella attività. Un'attività trasformata cambia nella sua natura: non si fa più la stessa cosa più rapidamente, ma si fa una cosa diversa. Per esempio, l'analisi dei reclami passa dalla lettura di un campione all'analisi sistematica di tutti i reclami, con un obiettivo nuovo: individuare le cause ricorrenti. Oppure il lavoro di un addetto passa dal redigere le risposte al supervisionare e migliorare le risposte preparate dal sistema. Il sottotema parla anche dell'evoluzione delle modalità di esecuzione del lavoro: per la stessa attività, il passaggio da assistita a automatizzata o trasformata avviene spesso gradualmente, ed è il risultato di scelte, non un esito automatico della tecnologia.");
    workTag(s, 0);
    const t = [["Assistita", "La persona svolge, l'AI supporta", "Bozza, sintesi, suggerimento", C.background2, C.text1], ["Automatizzata", "Il sistema svolge, la persona supervisiona", "Eccezioni e controlli restano umani", C.accent6, C.text1], ["Trasformata", "Si fa una cosa diversa", "Da un campione di reclami a tutti, per trovare le cause", C.accent1, C.background1]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.3, e[3], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.45, fontSize: 18, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.72, w: 2.56, h: 0.6, fontSize: 13, bold: true, color: e[4] });
      txt(s, e[2], { x: x + 0.15, y: 2.4, w: 2.56, h: 0.95, fontSize: 12, italic: true, color: e[4] });
      if (i < 2) arrow(s, x + 2.88, 2.15, 0.17);
    });
    banner(s, 3.7, "Il passaggio da assistita ad automatizzata o trasformata è spesso graduale, ed è il risultato di scelte, non della tecnologia.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Il compito non è il ruolo", "L'integrazione A del tema: un ruolo comprende attività diverse, e l'automazione di alcune non determina automaticamente la scomparsa dell'intero ruolo. È una delle idee più importanti per leggere in modo equilibrato il dibattito sull'AI e il lavoro. Un esempio storico spesso citato dagli economisti è quello degli sportelli bancari automatici. Quando, a partire dagli anni Settanta, si diffusero i bancomat, molti prevedevano la scomparsa dei cassieri di banca, perché il compito principale, distribuire contanti, veniva automatizzato. Negli Stati Uniti, secondo le analisi dell'economista James Bessen, il numero dei cassieri bancari non diminuì per molti anni: il costo di apertura delle filiali si ridusse, le banche aprirono più filiali, e il ruolo del cassiere si spostò verso la relazione con i clienti e la vendita di servizi. Il lavoro cambiò profondamente, ma non scomparve, almeno in quella fase; anni dopo, con altre tecnologie come l'home banking, le dinamiche sono cambiate. L'esempio non dimostra che l'AI non sostituirà mai nessun ruolo: dimostra che dall'automazione di un compito non si può dedurre l'effetto sul ruolo. Gli effetti dipendono da quanta parte del ruolo è automatizzata, da che cosa si fa con il tempo liberato, dalla domanda di mercato, dalle scelte delle organizzazioni.");
    workTag(s, 0);
    shapeBox(s, 0.5, 1.15, 9.0, 1.65, C.background2, "esempio storico");
    txt(s, "Un esempio storico: i bancomat e i cassieri", { x: 0.7, y: 1.22, w: 8.6, h: 0.38, fontSize: 15, bold: true, color: C.accent1 });
    txt(s, bullets(["Previsione: il compito principale è automatizzato, i cassieri scompariranno", "Negli Stati Uniti, per molti anni, i cassieri non diminuirono: più filiali, ruolo spostato verso relazione e servizi (Bessen)", "Anni dopo, con altre tecnologie, le dinamiche sono cambiate"], { space: 4 }), { x: 0.7, y: 1.63, w: 8.6, h: 1.15, fontSize: 12, color: C.text1 });
    txt(s, "Da che cosa dipende l'effetto sul ruolo", { x: 0.5, y: 2.95, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const d = ["Quanta parte del ruolo è automatizzata", "Che cosa si fa con il tempo liberato", "La domanda di mercato", "Le scelte delle organizzazioni"];
    d.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.32, 2.15, 0.7, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.2, "Dall'automazione di un compito non si può dedurre l'effetto sul ruolo.", { h: 0.65, fontSize: 15 });
  }
  {
    const s = content("Esposizione e trasformazione", "Una distinzione che il sottotema chiede di rendere esplicita, ed è anche una delle precisazioni trasversali del tema: l'esposizione di un lavoro all'AI non equivale alla sua effettiva trasformazione. Molti studi stimano l'esposizione delle professioni all'AI: quanti compiti di una professione potrebbero, in teoria, essere svolti o accelerati dall'AI. Per esempio, uno studio di Eloundou e colleghi, pubblicato nel 2023, ha stimato che per circa l'80 per cento dei lavoratori statunitensi almeno il 10 per cento dei compiti fosse esposto ai modelli linguistici, e che per circa il 19 per cento almeno la metà dei compiti lo fosse. Sono stime utili per capire dove l'AI può intervenire. Ma esposizione significa possibilità tecnica, non adozione, e ancora meno sostituzione. Tra l'una e l'altra ci sono molti passaggi: che l'AI sia davvero abbastanza affidabile per quel compito; che convenga economicamente; che l'organizzazione la adotti; che i processi vengano adattati; che le regole lo consentano; che i clienti lo accettino. E l'effetto dell'adozione può essere un aumento della produttività della persona, un cambiamento del ruolo, una riduzione della domanda di lavoro, o anche un aumento, a seconda dei casi. Il messaggio del sottotema è netto: le capacità tecniche dell'AI non consentono, da sole, di dedurre effetti certi su professioni o occupazione.");
    workTag(s, 0);
    const ch = ["Esposizione", "Affidabilità", "Convenienza", "Adozione", "Processi adattati", "Effetto sul lavoro"];
    ch.forEach((t, i) => {
      const x = 0.5 + i * 1.53;
      chip(s, x, 1.2, 1.38, 0.7, t, { fill: i === 0 ? C.accent1 : (i === 5 ? C.text1 : C.background2), color: i === 0 || i === 5 ? C.background1 : C.text1, fontSize: 11 });
      if (i < 5) arrow(s, x + 1.39, 1.39, 0.13);
    });
    txt(s, "Tra la possibilità tecnica e l'effetto ci sono molti passaggi, ciascuno incerto", { x: 0.5, y: 2.0, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2, align: "center" });
    await card(s, 0.5, 2.5, 4.35, 1.6, { icon: "FiBarChart2", inline: true, head: "Uno studio sull'esposizione (2023)", headSize: 13, bodySize: 12, body: "Circa 80% dei lavoratori USA con almeno il 10% dei compiti esposti; circa 19% con almeno la metà." });
    await card(s, 5.15, 2.5, 4.35, 1.6, { icon: "FiShuffle", inline: true, head: "Effetti possibili", headSize: 13, bodySize: 12, fill: C.accent6, body: "Più produttività, ruoli che cambiano, meno domanda di lavoro, o anche di più: dipende dai casi." });
    banner(s, 4.3, "Esposizione significa possibilità tecnica, non adozione, e ancor meno sostituzione.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Effetti diversi, scelte decisive", "Gli ultimi due punti del sottotema. L'eterogeneità degli effetti tra funzioni e professioni: l'AI non tocca allo stesso modo tutti i lavori. Anche all'interno della stessa azienda, l'impatto può essere molto diverso tra l'assistenza clienti, il marketing, l'amministrazione, la produzione, la ricerca, le risorse umane. E all'interno della stessa funzione, tra persone con esperienze e attività diverse, come abbiamo visto nel Tema 12 per i lavoratori meno e più esperti. Le generalizzazioni, come 'l'AI trasformerà il marketing', dicono poco su che cosa accadrà a una specifica persona in una specifica azienda. Il ruolo delle scelte organizzative nel determinare gli impatti: è forse il messaggio più importante del sottotema. Con la stessa tecnologia, due organizzazioni possono fare scelte molto diverse. Una può usare l'AI per ridurre il personale a parità di lavoro; un'altra per gestire più clienti con le stesse persone; un'altra ancora per migliorare la qualità del servizio o liberare tempo per attività di maggior valore. Può automatizzare le attività formative dei giovani o usarle per accelerarne l'apprendimento. Può concentrare la supervisione su pochi esperti o distribuirla. Gli effetti sul lavoro dipendono da queste scelte almeno quanto dalle capacità della tecnologia.");
    workTag(s, 0);
    await card(s, 0.5, 1.15, 4.35, 2.0, { icon: "FiGrid", head: "Effetti eterogenei", headSize: 15, bodySize: 12,
      body: bullets(["Tra funzioni: assistenza, marketing, produzione", "Tra persone: esperienza, attività"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.0, { icon: "FiSliders", head: "Scelte decisive", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Stessa tecnologia, scelte diverse", "Effetti diversi sul lavoro"], { space: 4 }) });
    txt(s, "Con la stessa tecnologia, un'organizzazione può scegliere di", { x: 0.5, y: 3.3, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const c = ["Ridurre il personale a parità di lavoro", "Servire più clienti con le stesse persone", "Migliorare la qualità del servizio", "Accelerare l'apprendimento dei giovani"];
    c.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.68, 2.15, 0.75, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Gli effetti dipendono dalle scelte almeno quanto dalle capacità della tecnologia.", { x: 0.5, y: 4.55, w: 9, h: 0.4, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  keySlide("Le capacità tecniche dell'AI non consentono, da sole, di dedurre effetti certi su professioni o occupazione.", "Sottotema 13.1  ·  Come l'AI modifica la natura del lavoro", "Concetto chiave del primo sottotema. Compiti, mansioni, ruoli e processi sono livelli diversi, e l'AI interviene quasi sempre sui compiti. L'AI generativa tocca soprattutto il lavoro informativo e cognitivo. Le attività possono essere assistite, automatizzate o trasformate. L'automazione di un compito non determina la scomparsa del ruolo, come mostra l'esempio storico dei bancomat; l'esposizione non è trasformazione; gli effetti sono eterogenei e dipendono dalle scelte organizzative. Esercizio suggerito: ciascun partecipante elenca i cinque compiti principali del proprio ruolo e indica, per ciascuno, se oggi è svolto senza AI, con AI assistita o in modo automatizzato.");

  // =====================================================================
  section("13.2 Attività trasformabili");
  divider("13.2", "Individuare le attività trasformabili", "Qualità delle informazioni, variabilità, contesto, rischio e organizzazione condizionano l'applicazione", "Se l'AI interviene sui compiti, quali compiti sono più adatti? In questo sottotema, da comprendere e riconoscere, vediamo come scomporre il lavoro in attività e quali caratteristiche rendono un'attività più o meno trasformabile. Il documento pone un confine preciso: qui riconosciamo le caratteristiche delle attività, senza introdurre una metodologia completa di prioritizzazione dei casi d'uso, che appartiene al Tema 15. Alcuni criteri li abbiamo già incontrati nel Tema 11 per gli agenti; qui li guardiamo dal punto di vista del lavoro.");
  {
    const s = content("Scomporre il lavoro in attività", "Il primo passo per capire come l'AI può cambiare un lavoro è scomporlo in attività. Il ruolo nel suo insieme è troppo ampio per una valutazione utile; le singole attività invece si possono esaminare una per una. L'esempio fittizio in slide scompone il ruolo di un addetto all'ufficio acquisti in otto attività, con una stima del tempo dedicato a ciascuna e una prima valutazione del possibile intervento dell'AI. Alcune attività sono candidate al supporto, come la preparazione delle richieste di offerta o il confronto tra offerte, visto nel Tema 8. Alcune a un'automazione parziale, come la registrazione degli ordini e il sollecito delle consegne. Altre restano essenzialmente umane, come la negoziazione con i fornitori o la gestione dei problemi di qualità, anche se l'AI può aiutare a prepararle. Due osservazioni. La prima: la scomposizione mostra che nessun ruolo è interamente trasformabile, e che il tempo liberato da alcune attività può essere spostato verso altre, come la negoziazione o lo sviluppo dei fornitori. La seconda: la scomposizione formale, come quella del mansionario, non coincide con il lavoro reale; per farla bene bisogna chiedere a chi svolge il ruolo come passa davvero il tempo.");
    workTag(s, 0);
    table(s, [["Attività (addetto acquisti, esempio fittizio)", "Tempo", "Intervento possibile dell'AI"],
      ["Preparare richieste di offerta", "15%", "Supporto"],
      ["Confrontare le offerte", "15%", "Supporto"],
      ["Registrare gli ordini", "15%", "Automazione parziale"],
      ["Sollecitare le consegne", "10%", "Automazione parziale"],
      ["Negoziare con i fornitori", "15%", "Preparazione assistita, svolgimento umano"],
      ["Gestire problemi di qualità", "15%", "Supporto all'analisi, gestione umana"],
      ["Sviluppare nuovi fornitori", "10%", "Supporto alla ricerca"],
      ["Coordinarsi con produzione e amministrazione", "5%", "Prevalentemente umano"]],
      { y: 1.12, colW: [4.2, 1.0, 3.8], rowH: 0.36, fontSize: 11, blankCorner: false });
    banner(s, 4.45, "Nessun ruolo è interamente trasformabile. E il mansionario non è il lavoro reale: chiedere a chi lo svolge.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Le caratteristiche delle attività", "Il sottotema elenca alcune caratteristiche che influenzano quanto un'attività sia adatta all'AI. Conviene pensarle come scale, non come categorie: un'attività si colloca in un punto di ciascuna. Ripetitiva e standardizzata, oppure unica e non strutturata: le prime si prestano di più all'automazione, le seconde al supporto. Basata su informazioni e documenti, oppure su attività fisiche o relazionali: l'AI generativa interviene soprattutto sulle prime. Prevedibile, oppure variabile: le attività con molte eccezioni sono più difficili da automatizzare, come visto nel Tema 11. Basata su regole, oppure su interpretazione e giudizio: l'interpretazione e il giudizio possono essere supportati, ma richiedono competenze e controllo umano. Il grafico in slide colloca alcune attività fittizie su due di queste scale, la variabilità e il bisogno di giudizio, e mostra che si formano gruppi con possibilità diverse. Le attività prevedibili e con poco giudizio sono candidate all'automazione; quelle variabili e con molto giudizio, al supporto; quelle intermedie, all'esecuzione parziale con supervisione. Non sono regole rigide, ma una prima mappa.");
    workTag(s, 0);
    shapeBox(s, 0.5, 1.15, 5.6, 3.35, C.background1, "mappa", { color: HEX.a3, width: 1 });
    s.addShape(pres.shapes.LINE, { x: 0.9, y: 4.2, w: 5.0, h: 0, line: { color: HEX.a2, width: 1.5, endArrowType: "triangle" }, objectName: "asse x" });
    s.addShape(pres.shapes.LINE, { x: 0.9, y: 1.3, w: 0, h: 2.9, line: { color: HEX.a2, width: 1.5, beginArrowType: "triangle" }, objectName: "asse y" });
    txt(s, "Variabilità →", { x: 4.3, y: 4.22, w: 1.6, h: 0.25, fontSize: 10, color: C.text2, align: "right" });
    txt(s, "Giudizio ↑", { x: 0.55, y: 1.15, w: 1.2, h: 0.25, fontSize: 10, color: C.text2 });
    const p = [["Registrare ordini", 1.0, 3.7, C.accent1], ["Sollecitare consegne", 1.6, 3.22, C.accent1], ["Preparare richieste", 2.2, 2.74, C.accent2], ["Confrontare offerte", 2.8, 2.26, C.accent2], ["Gestire qualità", 3.7, 1.78, C.accent5], ["Negoziare", 4.4, 1.3, C.accent5]];
    p.forEach(e => chip(s, e[1], e[2], 1.35, 0.36, e[0], { fill: e[3], color: C.background1, fontSize: 9 }));
    const l = [["Prevedibili, poco giudizio", "Candidate all'automazione", C.accent1, C.background1], ["Intermedie", "Esecuzione parziale con supervisione", C.accent2, C.background1], ["Variabili, molto giudizio", "Candidate al supporto", C.accent5, C.background1]];
    l.forEach((e, i) => {
      const y = 1.15 + i * 1.15;
      shapeBox(s, 6.35, y, 3.15, 1.0, e[2], e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.38, fontSize: 13, bold: true, color: e[3] });
      txt(s, e[1], { x: 6.5, y: y + 0.48, w: 2.9, h: 0.45, fontSize: 12, color: e[3] });
    });
    txt(s, "Esempio fittizio. Una prima mappa, non regole rigide.", { x: 0.5, y: 4.6, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Informazioni, rischio, controllo", "Oltre alle caratteristiche dell'attività in sé, il sottotema indica tre condizioni che influenzano la trasformabilità. La disponibilità delle informazioni necessarie: un'attività può essere perfettamente adatta all'AI in teoria, ma se le informazioni necessarie non sono accessibili, sono sparse in luoghi diversi, sono di scarsa qualità o sono nella testa delle persone, l'AI non può svolgerla bene. È il tema del Tema 14. I diversi livelli di rischio operativo: a parità di caratteristiche, un'attività con conseguenze gravi in caso di errore richiede più controllo, e quindi è meno automatizzabile, di una con conseguenze lievi. Preparare la bozza di una comunicazione interna e preparare la bozza di una risposta a un'autorità sono compiti simili, con rischi molto diversi. La necessità di competenze e controllo umano: alcune attività richiedono competenze specialistiche per verificare il risultato, e se queste competenze non sono disponibili nel momento in cui l'attività si svolge, l'AI non può essere usata in sicurezza. Il sottotema distingue di conseguenza tre livelli di intervento: il supporto, in cui la persona svolge l'attività con l'aiuto dell'AI; l'esecuzione parziale, in cui l'AI svolge una parte e la persona il resto; l'automazione, in cui l'AI svolge l'attività con supervisione. Sono gli stessi livelli visti nel Tema 11, ora applicati alla scelta delle attività.");
    workTag(s, 0);
    await iconGrid(s, [
      { icon: "FiDatabase", head: "Informazioni disponibili", body: "Accessibili, di qualità, non solo nella testa delle persone" },
      { icon: "FiAlertTriangle", head: "Rischio operativo", body: "Bozza interna o risposta a un'autorità: compiti simili, rischi diversi" },
      { icon: "FiUserCheck", head: "Competenze e controllo", body: "Chi sa verificare deve esserci, quando serve" },
    ], 3, { y: 1.15, h: 2.0, headSize: 14, bodySize: 12 });
    txt(s, "Tre livelli di intervento", { x: 0.5, y: 3.35, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const l = ["Supporto: la persona svolge, l'AI aiuta", "Esecuzione parziale: l'AI una parte, la persona il resto", "Automazione: l'AI svolge, la persona supervisiona"];
    l.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.72, 2.86, 0.85, t, { fill: [C.background2, C.accent6, C.accent1][i], color: i === 2 ? C.background1 : C.text1, fontSize: 12 }));
  }
  {
    const s = content("Fattibile o trasformabile?", "L'ultimo punto del sottotema: la differenza tra fattibilità tecnica e trasformabilità effettiva, e l'importanza del contesto in cui l'attività viene svolta. È la stessa distinzione vista nel Tema 12 tra fattibilità e convenienza, applicata alle attività. Che l'AI sia tecnicamente in grado di svolgere un compito non significa che quel compito, in quell'azienda, possa essere effettivamente trasformato. Il contesto conta in molti modi. Il volume: un'attività svolta dieci volte l'anno non giustifica lo sforzo di trasformarla. La qualità delle informazioni, come visto. Le regole: norme di settore, contratti, politiche aziendali possono richiedere che certe attività siano svolte o verificate da persone. I clienti: alcuni si aspettano un contatto umano per certe attività, o lo richiedono. Le competenze disponibili per supervisionare. Il modo in cui l'attività è collegata alle altre, che vedremo nel 13.3. Per questo, la stessa attività può essere trasformabile in un'azienda e non in un'altra. La consapevolezza del sottotema lo dice: non tutte le attività sono ugualmente adatte all'AI; qualità delle informazioni, variabilità, contesto, rischio e organizzazione ne condizionano l'applicazione. La valutazione e la scelta delle attività da trasformare, con criteri di priorità, appartengono al Tema 15.");
    workTag(s, 0);
    const c = [["Volume", "Dieci volte l'anno non giustifica lo sforzo"], ["Informazioni", "Disponibili e di qualità?"], ["Regole", "Norme, contratti, politiche che richiedono persone"], ["Clienti", "Alcuni si aspettano un contatto umano"], ["Competenze", "Chi supervisiona?"], ["Collegamenti", "Come l'attività si lega alle altre (13.3)"]];
    rowsLabel(s, c, { y: 1.15, h: 0.4, lw: 2.2 });
    banner(s, 4.05, "La stessa attività può essere trasformabile in un'azienda e non in un'altra.", { h: 0.75, fontSize: 13 });
  }
  keySlide("Non tutte le attività sono ugualmente adatte all'AI: qualità delle informazioni, variabilità, contesto, rischio e organizzazione ne condizionano l'applicazione.", "Sottotema 13.2  ·  Individuare le attività trasformabili", "Concetto chiave del sottotema 13.2. Per capire come l'AI può cambiare un lavoro bisogna scomporlo in attività, partendo dal lavoro reale e non dal mansionario. Le attività si collocano su scale: ripetitive o uniche, informative o relazionali, prevedibili o variabili, basate su regole o su giudizio. Contano anche la disponibilità delle informazioni, il rischio e le competenze per il controllo, e i livelli di intervento vanno dal supporto all'automazione. Fattibilità tecnica e trasformabilità effettiva sono diverse, e il contesto è decisivo. Esercizio suggerito: ciascun partecipante scompone il proprio ruolo in sei o otto attività, stima il tempo per ciascuna e le colloca sulla mappa variabilità e giudizio.");

  // =====================================================================
  section("13.3 Dal compito al processo");
  divider("13.3", "Dal compito al processo", "Introdurre AI in un processo non equivale automaticamente a riprogettarlo o migliorarlo", "Passiamo dai compiti ai processi. È uno dei sottotemi su cui il documento chiede di approfondire di più, ed è da comprendere e applicare. Nel Tema 12 abbiamo visto, dal punto di vista del valore, che accelerare un'attività non migliora necessariamente il processo. Qui guardiamo al processo dal punto di vista del lavoro: come cambiano le sequenze, i passaggi, i controlli, i punti di intervento umano. E due integrazioni: il rischio di automatizzare processi inefficienti, e il fatto che la trasformazione può creare nuovo lavoro. Il Business Process Reengineering e la progettazione organizzativa avanzata sono solo da accennare.");
  {
    const s = content("Compito e processo", "Il primo punto del sottotema è la differenza tra compito e processo, già introdotta. Un compito è un'unità di lavoro; un processo è una sequenza di attività interdipendenti, svolte da persone e sistemi diversi, che produce un risultato per un cliente, interno o esterno. Le interdipendenze sono la caratteristica chiave del processo: l'output di un'attività è l'input della successiva; un ritardo in un punto si propaga; un errore in un punto si ritrova più avanti; un cambiamento in un'attività può richiedere cambiamenti in altre. Applicare l'AI a un singolo passaggio di un processo, senza considerare le interdipendenze, produce tre effetti possibili. Nel caso migliore, il miglioramento del passaggio si traduce in un miglioramento del processo. Spesso, il miglioramento resta locale, perché il collo di bottiglia è altrove, come visto nel Tema 12. A volte, il miglioramento locale peggiora il processo: più volume prodotto in una fase crea code nella successiva; più velocità riduce la qualità che una fase successiva deve correggere; un nuovo formato di output non è compatibile con ciò che la fase successiva si aspetta. La consapevolezza del sottotema: introdurre AI in un processo non equivale automaticamente a riprogettarlo o migliorarlo.");
    workTag(s, 1);
    const st = ["Attività A", "Attività B", "Attività C", "Risultato"];
    st.forEach((t, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, t, { fill: i === 1 ? C.accent1 : (i === 3 ? C.text1 : C.background2), color: i === 1 || i === 3 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    txt(s, "AI applicata a B", { x: 2.8, y: 1.9, w: 2.05, h: 0.3, fontSize: 11, italic: true, bold: true, color: C.accent1, align: "center" });
    const r = [["Il processo migliora", "Il caso migliore", C.accent6], ["Il miglioramento resta locale", "Il collo di bottiglia è altrove", C.background2], ["Il processo peggiora", "Code dopo, qualità da correggere, formati incompatibili", C.background2]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.4, 2.86, 1.2, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 2.48, w: 2.56, h: 0.4, fontSize: 13, bold: true, color: i === 2 ? C.accent5 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 2.9, w: 2.56, h: 0.65, fontSize: 12, color: C.text1 });
    });
    banner(s, 3.85, "Le interdipendenze sono la chiave: l'output di un'attività è l'input della successiva.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Un processo trasformato", "Il documento propone un esempio illustrativo, che mostra come può cambiare un processo: la risposta a una richiesta di un cliente. La tabella in slide confronta le fasi nella modalità tradizionale e in una possibile trasformazione con l'AI. Nella ricezione, la lettura manuale della richiesta diventa una classificazione e sintesi assistita. Nell'analisi, la ricerca delle informazioni diventa un recupero guidato di fonti pertinenti, come visto nel Tema 8. Nella preparazione, la stesura della risposta diventa la produzione di una bozza. Nella verifica, il controllo manuale diventa la revisione umana della bozza, delle fonti e delle eccezioni: una verifica diversa, più centrata sulla correttezza delle informazioni e sui casi particolari. Nell'invio, la comunicazione al cliente avviene da parte di una persona, o dopo un'approvazione, secondo i livelli visti nel Tema 11. Il documento sottolinea il messaggio dell'esempio: possono cambiare la distribuzione delle attività, i passaggi di controllo e le competenze necessarie, non soltanto i tempi. La persona che prima scriveva le risposte ora le rivede, verifica le fonti e gestisce le eccezioni: un lavoro diverso, che richiede competenze in parte diverse. E una trasformazione utile va valutata sull'intero processo, non sulla singola operazione accelerata.");
    workTag(s, 1);
    table(s, [["Fase", "Modalità tradizionale", "Possibile trasformazione con AI"],
      ["Ricezione", "Lettura manuale", "Classificazione e sintesi assistita"],
      ["Analisi", "Ricerca delle informazioni", "Recupero guidato di fonti pertinenti"],
      ["Preparazione", "Stesura della risposta", "Produzione di una bozza"],
      ["Verifica", "Controllo manuale", "Revisione umana di bozza, fonti, eccezioni"],
      ["Invio", "Comunicazione al cliente", "Invio umano o dopo approvazione"]],
      { y: 1.15, colW: [1.8, 3.2, 4.0], rowH: 0.44, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.83, w: 9, h: 0.25, fontSize: 10, italic: true, color: C.accent2 });
    banner(s, 4.15, "Cambiano distribuzione delle attività, controlli e competenze, non solo i tempi. Si valuta sull'intero processo.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Che cosa cambia nel processo", "Il sottotema elenca i principali cambiamenti che l'AI può portare in un processo, al di là dell'accelerazione dei singoli passaggi. Cambiamenti nelle sequenze operative: l'ordine delle attività può cambiare, per esempio la classificazione automatica permette di smistare subito le richieste invece di farle passare tutte dallo stesso ufficio. Eliminazione di attività: alcuni passaggi diventano inutili, come la trascrizione manuale di dati già estratti automaticamente. Modifica di attività: altre cambiano natura, come la stesura che diventa revisione. Accorpamento di attività: passaggi prima svolti da persone diverse possono essere svolti da una sola persona con il supporto dell'AI, riducendo i passaggi di consegne. Introduzione di nuovi controlli e verifiche: servono controlli sugli output dell'AI che prima non esistevano. Ridefinizione dei punti di intervento umano: dove, nel processo, una persona decide, approva, verifica. Quest'ultimo cambiamento è il più delicato: spostare il punto di intervento umano significa cambiare chi vede che cosa e chi risponde di che cosa. Una trasformazione ben progettata decide consapevolmente dove collocare le persone, in base al rischio, come visto nel Tema 11; una trasformazione non progettata li sposta per effetto collaterale.");
    workTag(s, 1);
    await iconGrid(s, [
      { icon: "FiShuffle", head: "Sequenze", body: "Smistare subito invece che tutto da un ufficio" },
      { icon: "FiMinusCircle", head: "Eliminazione", body: "Trascrizioni ora inutili" },
      { icon: "FiEdit", head: "Modifica", body: "La stesura diventa revisione" },
      { icon: "FiLayers", head: "Accorpamento", body: "Meno passaggi di consegne" },
      { icon: "FiCheckSquare", head: "Nuovi controlli", body: "Sugli output dell'AI" },
      { icon: "FiUserCheck", head: "Punti di intervento umano", body: "Chi decide, approva, verifica", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Spostare il punto di intervento umano cambia chi vede che cosa e chi risponde: va deciso, non subito.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Automatizzare l'inefficienza", "L'integrazione B del tema: il rischio di automatizzare processi inefficienti. Rendere più rapidi i passaggi di un processo inefficiente può conservarne i problemi strutturali. È un principio noto da tempo nella gestione dei processi, molto prima dell'AI: automatizzare un processo sbagliato produce un processo sbagliato più veloce. L'esempio fittizio in slide lo mostra. In un'azienda, le richieste di acquisto passano per quattro livelli di approvazione, di cui due raramente modificano la decisione e sono stati aggiunti anni prima per motivi che non esistono più. I documenti vengono compilati in un formato e poi ricopiati in un altro sistema. Si introduce un assistente AI che prepara automaticamente le richieste e le inoltra. Il tempo di preparazione crolla, ma il processo resta lento, perché le quattro approvazioni restano; e ora l'AI produce anche le ricopiature, invece di eliminarle. In più, il processo è più difficile da cambiare, perché ora è incorporato in un sistema automatico. La domanda giusta, prima di introdurre l'AI in un processo, è: questo processo ha senso così com'è? Quali passaggi servono davvero? A volte la semplificazione del processo produce più benefici dell'AI, e non costa nulla. Il Business Process Reengineering, l'approccio sistematico alla riprogettazione dei processi, è solo da accennare.");
    workTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 2.2, "Il processo (esempio fittizio)", "Quattro approvazioni, di cui due quasi mai decisive e nate per motivi che non esistono più. Dati compilati in un formato e ricopiati in un altro sistema.", { fontSize: 12 });
    docBox(s, 5.15, 1.15, 4.35, 2.2, "Con l'AI", "La preparazione crolla, ma le quattro approvazioni restano; l'AI fa le ricopiature invece di eliminarle; il processo ora è più difficile da cambiare.", { fontSize: 12, bar: C.accent5, labelColor: C.accent5 });
    shapeBox(s, 0.5, 3.55, 9.0, 0.7, C.text1, "principio");
    txt(s, "Automatizzare un processo sbagliato produce un processo sbagliato più veloce.", { x: 0.7, y: 3.55, w: 8.6, h: 0.7, fontSize: 15, bold: true, color: C.background1, valign: "middle", align: "center" });
    txt(s, "Prima di introdurre l'AI: questo processo ha senso così com'è? Quali passaggi servono davvero?", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("La trasformazione crea nuovo lavoro", "L'integrazione D del tema: la trasformazione può creare nuovo lavoro. Il risparmio su certe operazioni può essere compensato da nuovi compiti di verifica e coordinamento. È una delle domande guida, e una delle precisazioni trasversali: il nuovo lavoro va conteggiato. Quali sono le nuove attività tipiche introdotte dall'AI in un processo? La verifica degli output, come visto in tutto il percorso. La gestione delle eccezioni che il sistema non sa trattare, spesso i casi più difficili, concentrati su poche persone. La preparazione e l'aggiornamento delle informazioni su cui il sistema si basa, come documentazione, istruzioni, esempi. Il monitoraggio del funzionamento del sistema, visto nel Tema 11. Il coordinamento tra persone e sistemi, e tra persone che usano strumenti diversi. La gestione dei reclami e delle correzioni dovute agli errori del sistema. La formazione delle persone all'uso degli strumenti. Queste attività non sono un fallimento della trasformazione: sono parte di essa. Ma vanno previste, assegnate e conteggiate. Se non lo sono, finiscono per ricadere su qualcuno senza essere riconosciute, spesso sulle persone più esperte, e il bilancio della trasformazione risulta migliore di quanto sia.");
    workTag(s, 1);
    await iconGrid(s, [
      { icon: "FiSearch", head: "Verifica degli output", body: "In tutto il percorso" },
      { icon: "FiAlertCircle", head: "Gestione delle eccezioni", body: "I casi difficili, su poche persone" },
      { icon: "FiBookOpen", head: "Informazioni di base", body: "Documentazione, istruzioni, esempi" },
      { icon: "FiActivity", head: "Monitoraggio", body: "Del funzionamento del sistema" },
      { icon: "FiShare2", head: "Coordinamento", body: "Tra persone e sistemi" },
      { icon: "FiRotateCcw", head: "Correzioni e reclami", body: "Dovuti agli errori del sistema" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Non un fallimento, ma parte della trasformazione: va prevista, assegnata e conteggiata.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Ottimizzare o trasformare", "L'ultimo punto del sottotema: la distinzione tra ottimizzazione locale e trasformazione complessiva. L'ottimizzazione locale migliora uno o più passaggi di un processo, lasciandone invariata la struttura: le stesse fasi, le stesse persone, gli stessi controlli, con alcune attività più rapide. È il modo più comune e più semplice di introdurre l'AI, e può produrre benefici reali, soprattutto se riguarda i colli di bottiglia. La trasformazione complessiva ripensa il processo nel suo insieme, alla luce di ciò che l'AI rende possibile: quali passaggi servono ancora, in quale ordine, chi li svolge, dove si colloca il controllo umano, quali nuove attività sono necessarie, quale risultato si vuole ottenere. Richiede più tempo e più coinvolgimento, e comporta più rischi, ma può produrre benefici molto maggiori. La lezione storica del paradosso di Solow, vista nel Tema 12, riguarda proprio questo: i benefici delle tecnologie dell'informazione arrivarono quando le organizzazioni ripensarono i processi, non quando si limitarono ad accelerare quelli esistenti. Non esiste una scelta giusta in assoluto: spesso conviene partire da ottimizzazioni locali, imparare, e poi trasformare. Ma è importante sapere quale delle due si sta facendo, e non aspettarsi dalla prima i risultati della seconda.");
    workTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiZap", head: "Ottimizzazione locale", headSize: 16, bodySize: 12,
      body: bullets(["Stessa struttura, alcuni passaggi più rapidi", "Semplice e comune", "Benefici reali, soprattutto sui colli di bottiglia"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiRefreshCw", head: "Trasformazione complessiva", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Ripensare passaggi, ordine, persone, controlli", "Più tempo, coinvolgimento e rischi", "Benefici potenzialmente maggiori"], { space: 5 }) });
    banner(s, 3.9, "Spesso conviene ottimizzare, imparare, poi trasformare. Ma non aspettarsi dalla prima i risultati della seconda.", { h: 0.85, fontSize: 13 });
  }
  keySlide("Introdurre AI in un processo non equivale automaticamente a riprogettarlo o migliorarlo.", "Sottotema 13.3  ·  Dal compito al processo", "Concetto chiave del sottotema 13.3. I processi sono sequenze di attività interdipendenti, e l'AI applicata a un passaggio può migliorare il processo, lasciarlo invariato o peggiorarlo. Possono cambiare sequenze, attività, controlli e punti di intervento umano. Automatizzare un processo inefficiente ne conserva i problemi, e la trasformazione crea anche nuovo lavoro, da conteggiare. Ottimizzazione locale e trasformazione complessiva sono diverse. Esercizio suggerito: partendo dall'esempio della richiesta del cliente, i partecipanti disegnano un processo del proprio lavoro, prima e dopo un possibile intervento dell'AI, indicando le attività eliminate, modificate, accorpate e quelle nuove.");

  // =====================================================================
  section("13.4 Collaborazione persone e AI");
  divider("13.4", "Collaborazione tra persone e AI", "Le persone possono spostarsi verso interpretazione, verifica e supervisione, senza perdere il bisogno di competenze", "Dalle attività e dai processi alle persone. Come si lavora con l'AI, nel quotidiano? Il documento chiede di approfondire questo sottotema, da comprendere, e di tenerlo distinto dal successivo: qui parliamo di come si lavora con l'AI, cioè dei modelli operativi di collaborazione; nel 13.5 parleremo di come evolvono i ruoli nel tempo. Nel Tema 5 abbiamo visto la collaborazione conversazionale, una persona che dialoga con un assistente; nel Tema 11 la distribuzione del lavoro con gli agenti. Qui guardiamo agli effetti sul lavoro delle persone.");
  {
    const s = content("Strumento personale o di processo", "Il sottotema distingue due modi in cui l'AI entra nel lavoro, con effetti diversi sulle persone. L'AI come supporto individuale: ciascuna persona usa l'AI, per sua scelta, per le proprie attività, in modo diverso da un collega all'altro. Il processo resta invariato, e l'AI è uno strumento personale, come lo sono il foglio di calcolo o il motore di ricerca. È la situazione oggi più diffusa. Ha il vantaggio della flessibilità e dell'autonomia, e lo svantaggio che i benefici restano individuali e disomogenei, come vedremo nel 13.6. L'AI come componente operativa delle attività: l'AI è parte del processo, progettata per svolgere una funzione definita, uguale per tutti, come la classificazione delle richieste in arrivo o la preparazione delle bozze di risposta. Il processo cambia, e le persone lavorano con l'AI in un modo stabilito dall'organizzazione. I benefici possono essere più ampi e misurabili, ma l'autonomia individuale si riduce, e il disegno della collaborazione diventa una scelta organizzativa. Le due forme convivono spesso nella stessa azienda, anche per la stessa persona: un addetto può lavorare in un processo con un componente AI e, insieme, usare un assistente personale per altre attività.");
    workTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiUser", head: "Supporto individuale", headSize: 16, bodySize: 12,
      body: bullets(["Ciascuno lo usa a modo suo", "Il processo non cambia", "Flessibilità e autonomia", "Benefici individuali e disomogenei"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiSettings", head: "Componente operativa", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Funzione definita, uguale per tutti", "Il processo cambia", "Benefici più ampi e misurabili", "Meno autonomia: è una scelta organizzativa"], { space: 4 }) });
    banner(s, 3.95, "Spesso convivono, anche per la stessa persona: un processo con l'AI integrata e un assistente personale per il resto.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Distribuire il lavoro", "Il cuore del sottotema è la distribuzione del lavoro tra persona e sistema. Nel Tema 11 abbiamo visto la regola generale: alle persone le decisioni, ai sistemi la preparazione delle decisioni. Qui guardiamo ai modelli di collaborazione più frequenti, che il sottotema elenca. Il modello più diffuso è la preparazione automatica con revisione umana: il sistema prepara, la persona rivede, corregge e approva. Funziona bene se la revisione è reale e se la persona ha le competenze per farla; funziona male se la revisione diventa un'approvazione automatica, come visto nel Tema 11 per l'affaticamento da approvazione. Un secondo modello è la collaborazione nell'esecuzione: persona e sistema lavorano insieme sulla stessa attività, alternandosi, come nel lavoro su un documento in cui la persona scrive alcune parti e chiede al sistema di svilupparne altre. Un terzo modello è il coordinamento tra persone e strumenti: la persona organizza il lavoro di più strumenti e sistemi, come un regista, verificando i risultati e integrandoli. In tutti i modelli conviene chiarire che cosa fa il sistema, che cosa fa la persona, in quale ordine, e chi decide alla fine. Il disegno della collaborazione è più importante della scelta dello strumento.");
    workTag(s, 2);
    const m = [["FiEdit", "Preparazione e revisione", "Il sistema prepara, la persona rivede e approva", "Se la revisione è reale"], ["FiUsers", "Esecuzione condivisa", "Persona e sistema si alternano sulla stessa attività", "Se è chiaro chi fa che cosa"], ["FiSliders", "Coordinamento", "La persona organizza più strumenti, come un regista", "Se sa verificare e integrare"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.55, i === 0 ? C.accent6 : C.background2, m[i][1]);
      await iconCircle(s, x + 1.08, 1.27, 0.7, m[i][0]);
      txt(s, m[i][1], { x: x + 0.15, y: 2.05, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, m[i][2], { x: x + 0.2, y: 2.5, w: 2.46, h: 0.6, fontSize: 12, color: C.text2, align: "center" });
      txt(s, m[i][3], { x: x + 0.2, y: 3.15, w: 2.46, h: 0.45, fontSize: 11, italic: true, bold: true, color: C.accent1, align: "center" });
    }
    banner(s, 3.95, "Chiarire che cosa fa il sistema, che cosa la persona, in quale ordine, chi decide. Il disegno conta più dello strumento.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Dall'esecuzione alla supervisione", "Uno spostamento che il sottotema mette al centro: il passaggio dall'esecuzione alla supervisione. In molti lavori, l'introduzione dell'AI sposta l'attività delle persone dal fare al controllare: invece di scrivere, si rivede; invece di calcolare, si verifica; invece di cercare, si valuta ciò che è stato trovato; invece di gestire tutti i casi, si gestiscono le eccezioni. La consapevolezza del sottotema lo esprime così: le persone possono spostarsi verso interpretazione, verifica e supervisione. E aggiunge subito una precisazione importante: senza che questo elimini il bisogno di competenze professionali. Anzi, la supervisione richiede spesso competenze più solide dell'esecuzione: per riconoscere un errore in un documento preparato da altri, bisogna sapere come andrebbe fatto, e accorgersi di ciò che manca, non solo di ciò che è scritto. Questo spostamento ha anche effetti sulla soddisfazione e sul senso del lavoro, che possono essere positivi o negativi: alcune persone apprezzano liberarsi delle attività ripetitive e concentrarsi su quelle di giudizio; altre trovano la supervisione meno gratificante della creazione, o faticosa per la concentrazione che richiede. Anche la gestione delle eccezioni, che spesso diventa la parte principale del lavoro, concentra sulle persone i casi più difficili.");
    workTag(s, 2);
    const p = [["Scrivere", "Rivedere"], ["Calcolare", "Verificare"], ["Cercare", "Valutare ciò che è stato trovato"], ["Tutti i casi", "Le eccezioni"]];
    p.forEach((e, i) => {
      const y = 1.15 + i * 0.55;
      chip(s, 0.5, y, 2.4, 0.46, e[0], { fill: C.background2, fontSize: 12 });
      arrow(s, 3.0, y + 0.07, 0.45);
      chip(s, 3.55, y, 2.6, 0.46, e[1], { fill: C.accent6, fontSize: 12 });
    });
    shapeBox(s, 6.4, 1.15, 3.1, 2.1, C.text1, "competenze");
    txt(s, "La supervisione richiede spesso competenze più solide dell'esecuzione", { x: 6.55, y: 1.25, w: 2.8, h: 1.0, fontSize: 13, bold: true, color: C.accent6 });
    txt(s, "Per riconoscere un errore bisogna sapere come andrebbe fatto.", { x: 6.55, y: 2.3, w: 2.8, h: 0.85, fontSize: 12, color: C.background1 });
    await card(s, 0.5, 3.45, 4.35, 1.45, { head: "Per alcuni", headSize: 13, bodySize: 12, fill: C.accent6, body: "Liberarsi del ripetitivo e concentrarsi sul giudizio." });
    await card(s, 5.15, 3.45, 4.35, 1.45, { head: "Per altri", headSize: 13, bodySize: 12, body: "Supervisione meno gratificante, faticosa, e i casi più difficili concentrati." });
  }
  {
    const s = content("Autonomia e responsabilità", "Tre ultimi punti del sottotema. La preservazione dell'autonomia professionale: quando l'AI diventa una componente del processo, c'è il rischio che le persone perdano margini di decisione, perché il sistema propone e la persona si limita ad approvare, o perché il modo di lavorare è definito dallo strumento. L'autonomia professionale ha valore sia per le persone, perché incide sulla motivazione e sul senso del lavoro, sia per l'organizzazione, perché è ciò che permette di adattarsi ai casi non previsti e di accorgersi degli errori. Un buon disegno della collaborazione lascia alle persone lo spazio per decidere diversamente da ciò che propone il sistema, e per segnalare quando il sistema non funziona. La responsabilità delle decisioni e dei risultati: come in tutto il percorso, chi decide e chi firma risponde, anche quando il lavoro è stato preparato dall'AI. Nel lavoro quotidiano questo significa che la persona deve avere il tempo e le informazioni per esercitare davvero la propria responsabilità, non solo il nome sul documento. La necessità di conoscere capacità e limiti dell'AI: per collaborare bene con un sistema, bisogna sapere che cosa sa fare e dove sbaglia, cioè le competenze di AI literacy costruite in questo percorso. Senza questa conoscenza, la collaborazione oscilla tra fiducia eccessiva e rifiuto.");
    workTag(s, 2);
    await iconGrid(s, [
      { icon: "FiCompass", head: "Autonomia professionale", body: "Spazio per decidere diversamente dal sistema e segnalare quando non funziona" },
      { icon: "FiAward", head: "Responsabilità reale", body: "Tempo e informazioni per esercitarla, non solo il nome sul documento" },
      { icon: "FiBookOpen", head: "Conoscere capacità e limiti", body: "Senza, si oscilla tra fiducia eccessiva e rifiuto" },
    ], 3, { y: 1.15, h: 2.2, headSize: 14, bodySize: 12 });
    banner(s, 3.6, "L'autonomia conta per le persone, perché dà senso al lavoro, e per l'organizzazione, perché intercetta errori e casi nuovi.", { h: 0.85, fontSize: 13 });
  }
  keySlide("Le persone possono spostarsi verso interpretazione, verifica e supervisione, senza che questo elimini il bisogno di competenze professionali.", "Sottotema 13.4  ·  Collaborazione tra persone e AI", "Concetto chiave del sottotema 13.4. L'AI può entrare nel lavoro come supporto individuale o come componente operativa del processo, con effetti diversi su autonomia e benefici. I modelli di collaborazione vanno dalla preparazione con revisione all'esecuzione condivisa e al coordinamento, e il loro disegno conta più dello strumento. Il lavoro si sposta dall'esecuzione alla supervisione, che richiede competenze solide e può essere vissuta in modi diversi. Autonomia professionale, responsabilità reale e conoscenza dei limiti dell'AI sono condizioni di una buona collaborazione. Esercizio suggerito: per un'attività svolta con l'AI, i partecipanti descrivono chi fa che cosa, in quale ordine, e dove hanno spazio per decidere diversamente dal sistema.");

  // =====================================================================
  section("13.5 Ruoli e responsabilità");
  divider("13.5", "Evoluzione dei ruoli e delle responsabilità", "Le conseguenze sui ruoli non sono predeterminate dalla tecnologia", "Se il 13.4 riguardava come si lavora con l'AI, questo sottotema riguarda come evolvono i ruoli nel tempo. È tra quelli da approfondire maggiormente, e tocca la domanda che sta a cuore a molti partecipanti: che cosa succederà al mio lavoro? Il documento chiede di affrontarla con equilibrio, senza assumere risultati occupazionali predeterminati. Vediamo come cambia la composizione delle mansioni, quali competenze acquistano o perdono importanza, quali nuove responsabilità emergono, e un caso trasversale importante: il paradosso del supervisore inesperto. Le analisi occupazionali specialistiche e il workforce planning sono solo da accennare.");
  {
    const s = content("La composizione delle mansioni", "Il primo effetto dell'AI sui ruoli è il cambiamento nella composizione delle mansioni: la stessa posizione continua a esistere, ma il tempo si distribuisce diversamente tra le attività. Il grafico fittizio in slide mostra come potrebbe cambiare il ruolo di un addetto all'assistenza clienti. Prima dell'AI, gran parte del tempo era dedicata alla stesura delle risposte e alla ricerca delle informazioni. Con l'AI, quel tempo si riduce; aumenta il tempo dedicato alla revisione delle bozze, alla gestione dei casi complessi e delle eccezioni, e compaiono attività nuove, come il miglioramento della base di conoscenza su cui il sistema si basa. Il ruolo ha lo stesso nome, ma è diverso. Il sottotema parla di redistribuzione delle attività, e questa può avvenire in più direzioni: all'interno dello stesso ruolo, come nell'esempio; tra ruoli diversi, quando alcune attività passano da una posizione a un'altra; tra persone e sistemi. I numeri del grafico sono inventati e servono solo a mostrare il tipo di cambiamento. In un caso reale, la nuova composizione dipende dalle scelte fatte: per esempio, il tempo liberato può essere dedicato a più clienti, a una relazione più approfondita con ciascuno, o ad altre attività.");
    workTag(s, 2);
    s.addChart(pres.charts.BAR, [
      { name: "Stesura risposte", labels: ["Prima", "Con AI"], values: [40, 10] },
      { name: "Ricerca informazioni", labels: ["Prima", "Con AI"], values: [25, 10] },
      { name: "Revisione bozze", labels: ["Prima", "Con AI"], values: [5, 25] },
      { name: "Casi complessi ed eccezioni", labels: ["Prima", "Con AI"], values: [20, 30] },
      { name: "Base di conoscenza", labels: ["Prima", "Con AI"], values: [0, 10] },
      { name: "Altro", labels: ["Prima", "Con AI"], values: [10, 15] }], {
      x: 0.5, y: 1.1, w: 6.0, h: 3.2, barDir: "bar", barGrouping: "percentStacked", chartColors: [HEX.a2, HEX.a3, HEX.a1, HEX.a5, HEX.a4, "C9CED4"],
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 9, valGridLine: { color: HEX.a3, size: 0.5 }, valAxisLabelFormatCode: "0%",
      showLegend: true, legendPos: "b", legendFontSize: 9, legendFontFace: "+mn-lt", legendColor: HEX.dk2, barGapWidthPct: 40,
      showTitle: true, title: "Addetto all'assistenza: distribuzione del tempo (numeri inventati)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
    const r = [["Diminuiscono", "Stesura, ricerca"], ["Aumentano", "Revisione, casi complessi"], ["Compaiono", "Base di conoscenza"]];
    r.forEach((e, i) => {
      const y = 1.15 + i * 1.0;
      shapeBox(s, 6.75, y, 2.75, 0.88, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.9, y: y + 0.06, w: 2.5, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.9, y: y + 0.44, w: 2.5, h: 0.38, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.4, "Stesso nome, ruolo diverso. La nuova composizione dipende dalle scelte fatte.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Competenze che cambiano peso", "Il sottotema chiede di riconoscere le competenze che acquisiscono maggiore importanza e quelle che possono perdere centralità. Senza pretendere di prevedere il futuro di ogni professione, alcune tendenze sono ragionevolmente chiare, almeno per il lavoro informativo e cognitivo. Acquistano importanza: la capacità di formulare problemi e obiettivi, cioè di sapere che cosa chiedere; la valutazione critica dei risultati, vista nel Tema 7; la conoscenza del dominio e del contesto, che permette di riconoscere gli errori; il giudizio nei casi complessi e nelle eccezioni; la relazione con le persone, clienti e colleghi; la capacità di coordinare il lavoro di persone e strumenti; la responsabilità e la capacità di decidere. Possono perdere centralità: alcune competenze di esecuzione, come la stesura di testi standard, la ricerca manuale di informazioni, la formattazione, alcuni calcoli e trascrizioni. Due cautele. 'Perdere centralità' non significa diventare inutili: molte di queste competenze restano necessarie per verificare il lavoro dell'AI, come vedremo nel 13.7. E le competenze specialistiche, che il sottotema richiama esplicitamente, restano decisive: l'AI amplifica gli esperti, ma non ne fa a meno, soprattutto per i casi difficili e per la supervisione.");
    workTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 2.85, { icon: "FiTrendingUp", head: "Acquistano importanza", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Formulare problemi e obiettivi", "Valutazione critica dei risultati", "Conoscenza del dominio e del contesto", "Giudizio nei casi complessi", "Relazione con le persone", "Coordinare persone e strumenti"], { space: 3 }) });
    await card(s, 5.15, 1.15, 4.35, 2.85, { icon: "FiTrendingDown", head: "Possono perdere centralità", headSize: 15, bodySize: 12,
      body: bullets(["Stesura di testi standard", "Ricerca manuale di informazioni", "Formattazione", "Alcuni calcoli e trascrizioni"], { space: 3 }) });
    banner(s, 4.2, "'Perdere centralità' non è 'diventare inutili': servono per verificare. E le competenze specialistiche restano decisive.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Nuove attività e responsabilità", "Il sottotema richiama la comparsa di nuove attività e responsabilità, e l'integrazione D: la trasformazione può introdurre responsabilità inedite. Alcune riguardano il coordinamento e il controllo dell'AI, che il sottotema elenca esplicitamente: definire come gli strumenti devono essere usati in un'attività, verificare periodicamente la qualità dei risultati, gestire le eccezioni, mantenere aggiornate le informazioni su cui il sistema si basa, segnalare i problemi, rispondere degli esiti delle attività assistite o automatizzate. In alcune organizzazioni queste attività si concentrano in figure specifiche, come referenti interni per l'AI in un reparto, o responsabili della qualità di un processo automatizzato; in altre si distribuiscono tra tutti. Altre nuove attività riguardano il lavoro stesso: attività prima impossibili, che l'AI rende sostenibili, come visto nel Tema 12, e che richiedono qualcuno che le svolga. È importante riconoscere queste nuove responsabilità per tre ragioni: perché richiedono tempo, che va conteggiato; perché richiedono competenze, che vanno sviluppate; e perché, se non vengono assegnate esplicitamente, finiscono per non essere svolte, o per ricadere su chi non le ha scelte.");
    workTag(s, 2);
    await iconGrid(s, [
      { icon: "FiSliders", head: "Definire l'uso", body: "Come gli strumenti si usano in un'attività" },
      { icon: "FiSearch", head: "Verificare la qualità", body: "Periodicamente, sui risultati" },
      { icon: "FiAlertCircle", head: "Gestire le eccezioni", body: "I casi che il sistema non tratta" },
      { icon: "FiDatabase", head: "Aggiornare le informazioni", body: "Su cui il sistema si basa" },
      { icon: "FiFlag", head: "Segnalare problemi", body: "E proporre miglioramenti" },
      { icon: "FiAward", head: "Rispondere degli esiti", body: "Delle attività assistite o automatizzate" },
    ], 3, { y: 1.15, H: 2.8, headSize: 13, bodySize: 12 });
    txt(s, "Da riconoscere perché richiedono", { x: 0.5, y: 4.1, w: 2.6, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 3.1, 4.1, 2.05, 0.55, "Tempo, da conteggiare", { fill: C.background2, fontSize: 11 });
    chip(s, 5.25, 4.1, 2.05, 0.55, "Competenze, da sviluppare", { fill: C.background2, fontSize: 11 });
    chip(s, 7.4, 4.1, 2.1, 0.55, "Assegnazione esplicita", { fill: C.background2, fontSize: 11 });
  }
  {
    const s = content("Il supervisore inesperto", "Il caso trasversale del documento, e l'integrazione C: il paradosso del supervisore inesperto. Quando un lavoratore junior impara una professione, lo fa spesso preparando documenti, analisi, bozze, che un collega esperto rivede e corregge. Facendo e sbagliando, sotto la guida di qualcuno, sviluppa l'esperienza che gli permetterà, un giorno, di fare il lavoro da solo e di rivedere quello degli altri. Se la preparazione viene interamente affidata all'AI, queste occasioni di apprendimento pratico si riducono. E allo stesso tempo, al junior viene spesso chiesto di controllare i documenti preparati dall'AI: un compito di supervisione, che richiede proprio l'esperienza che non ha avuto modo di sviluppare. Il risultato è un paradosso: si chiede più giudizio a chi ha avuto meno occasioni di formarlo. Nel breve periodo il problema non si vede, perché gli esperti attuali possono supervisionare; nel lungo periodo, quando gli esperti attuali lasceranno, potrebbe mancare chi sa davvero come si fa il lavoro. Il documento sottolinea che questo effetto non è inevitabile: l'AI può sostenere l'apprendimento se è impiegata per esercitazioni, spiegazioni e feedback. L'organizzazione deve considerare tanto la produttività immediata quanto lo sviluppo delle competenze nel tempo.");
    workTag(s, 2);
    const st = [["Prima", "Il junior prepara, l'esperto rivede: si impara facendo", C.accent6, C.text1], ["Con l'AI", "L'AI prepara, il junior controlla: meno pratica, più giudizio richiesto", C.background2, C.text1], ["Nel tempo", "Gli esperti lasciano: chi sa davvero come si fa?", C.text1, C.background1]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.7, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.42, fontSize: 16, bold: true, color: i === 2 ? C.accent6 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.68, w: 2.56, h: 1.1, fontSize: 12, color: e[3] });
      if (i < 2) arrow(s, x + 2.88, 1.85, 0.17);
    });
    banner(s, 3.05, "Si chiede più giudizio a chi ha avuto meno occasioni di formarlo.", { h: 0.65, fontSize: 15 });
    shapeBox(s, 0.5, 3.9, 9.0, 1.05, C.accent6, "non inevitabile");
    txt(s, [{ text: "Non è inevitabile: ", options: { bold: true, color: C.accent1 } }, { text: "l'AI può sostenere l'apprendimento con esercitazioni, spiegazioni e feedback. Contano la produttività immediata e lo sviluppo delle competenze nel tempo.", options: { color: C.text1 } }], { x: 0.7, y: 3.9, w: 8.6, h: 1.05, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Compiti e occupazione", "Il sottotema chiede di distinguere il cambiamento dei compiti dagli effetti sull'occupazione, e una delle domande guida chiede quali effetti possano esserci sui ruoli professionali, senza assumere risultati occupazionali predeterminati. È il punto più sensibile del tema, e conviene trattarlo con onestà. Che l'AI cambi i compiti e la composizione delle mansioni è ormai evidente in molti lavori. Che cosa questo comporti per l'occupazione, cioè per il numero di persone che svolgono un certo lavoro, è molto più incerto, e dipende da fattori che vanno oltre la tecnologia: quanto l'AI aumenta la produttività di ciascuna persona; se la domanda di quel lavoro cresce quando il suo costo si riduce, come è accaduto in passato in alcuni casi; quali nuove attività nascono; quali scelte fanno le organizzazioni; come evolvono le regole e il contesto economico. Gli effetti possono essere diversi per professioni diverse, e nel tempo: un ruolo può crescere in una fase e ridursi in un'altra. Le analisi occupazionali specialistiche sono solo da accennare, e richiederebbero dati e metodi che non sono oggetto di questo percorso. Il messaggio del sottotema, condiviso con il 13.1, è che le conseguenze sui ruoli non sono predeterminate dalla tecnologia: dipendono anche, e molto, dalle scelte delle organizzazioni.");
    workTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 1.6, { icon: "FiCheckSquare", inline: true, head: "Il cambiamento dei compiti", headSize: 14, bodySize: 12, fill: C.accent6, body: "Evidente in molti lavori: composizione delle mansioni, attività nuove e ridotte." });
    await card(s, 5.15, 1.15, 4.35, 1.6, { icon: "FiHelpCircle", inline: true, head: "L'effetto sull'occupazione", headSize: 14, bodySize: 12, body: "Molto più incerto: dipende da fattori oltre la tecnologia." });
    txt(s, "Da che cosa dipende", { x: 0.5, y: 2.9, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const d = ["Aumento di produttività", "Domanda che cresce se il costo cala", "Nuove attività", "Scelte delle organizzazioni", "Regole e contesto economico"];
    d.forEach((t, i) => chip(s, 0.5 + i * 1.82, 3.28, 1.7, 0.75, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 4.2, "Le conseguenze sui ruoli non sono predeterminate dalla tecnologia. Analisi occupazionali specialistiche: solo accennate.", { h: 0.75, fontSize: 13 });
  }
  keySlide("Le conseguenze sui ruoli non sono predeterminate dalla tecnologia.", "Sottotema 13.5  ·  Evoluzione dei ruoli e delle responsabilità", "Concetto chiave del sottotema 13.5. L'AI cambia la composizione delle mansioni: alcune attività diminuiscono, altre aumentano, altre compaiono. Acquistano importanza le competenze di formulazione, valutazione, dominio, giudizio, relazione e coordinamento; alcune competenze di esecuzione perdono centralità ma restano necessarie per verificare. Nascono nuove responsabilità, da riconoscere e assegnare. Il paradosso del supervisore inesperto mostra il rischio di ridurre le occasioni di apprendimento, rischio evitabile con scelte consapevoli. Il cambiamento dei compiti è evidente, l'effetto sull'occupazione è incerto e dipende dalle scelte. Esercizio suggerito: discutere in gruppo come organizzare il lavoro di un junior in un'attività in cui l'AI prepara le bozze, in modo che continui a imparare.");

  // =====================================================================
  section("13.6 Team e funzioni");
  divider("13.6", "AI e collaborazione nei team e tra funzioni", "Un miglioramento individuale non produce automaticamente maggiore efficacia del team", "Dai singoli ai gruppi. Il lavoro si svolge quasi sempre in team, e tra funzioni diverse: vendite e amministrazione, produzione e qualità, marketing e assistenza. In questo sottotema, di priorità media e da conoscere, vediamo come l'AI può influire sulla collaborazione: la condivisione delle informazioni, il coordinamento, la comunicazione interna, i passaggi di consegne. E un rischio specifico: le differenze di utilizzo tra persone e reparti, che possono creare frammentazione. Il confine con il 13.3: lì la sequenza operativa del processo, qui il coordinamento tra persone e funzioni.");
  {
    const s = content("Dove la collaborazione migliora", "Il sottotema elenca alcuni ambiti in cui l'AI può migliorare la collaborazione. La condivisione delle informazioni: verbali delle riunioni prodotti automaticamente, sintesi di conversazioni lunghe, risposte rapide a domande sulla documentazione del team, come visto nel Tema 8. Chi non era presente può recuperare, chi arriva nuovo può orientarsi. Il coordinamento tra attività e persone: aggiornamenti sullo stato dei progetti, promemoria delle scadenze, riepiloghi di chi sta facendo che cosa. La comunicazione interna: messaggi più chiari, adattati a destinatari diversi, tradotti per colleghi di altre sedi. I passaggi di consegne: quando un'attività passa da una persona all'altra, o da una funzione all'altra, l'AI può aiutare a preparare un riepilogo completo dello stato, delle decisioni prese e dei punti aperti. La collaborazione su documenti e conoscenze: documenti condivisi su cui più persone lavorano con il supporto dell'AI, basi di conoscenza comuni. Sono benefici concreti, che riguardano il lavoro collettivo e non solo quello individuale. Ma, come vedremo, non si ottengono automaticamente: dipendono da come gli strumenti sono adottati nel team, e possono anche peggiorare la collaborazione se ciascuno li usa a modo suo.");
    workTag(s, 2);
    await iconGrid(s, [
      { icon: "FiShare2", head: "Condivisione", body: "Verbali, sintesi, risposte sulla documentazione" },
      { icon: "FiCalendar", head: "Coordinamento", body: "Stato dei progetti, scadenze, chi fa che cosa" },
      { icon: "FiMessageSquare", head: "Comunicazione interna", body: "Più chiara, adattata, tradotta" },
      { icon: "FiRepeat", head: "Passaggi di consegne", body: "Stato, decisioni, punti aperti" },
      { icon: "FiFileText", head: "Documenti condivisi", body: "Basi di conoscenza comuni" },
      { icon: "FiUsers", head: "Lavoro collettivo", body: "Non solo individuale", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Benefici concreti, ma non automatici: dipendono da come gli strumenti sono adottati nel team.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Usi diversi, frammentazione", "Il rischio principale che il sottotema mette in evidenza riguarda le differenze di utilizzo tra persone e reparti, e la coerenza degli strumenti e delle modalità operative. In molte organizzazioni l'AI entra in modo spontaneo: alcune persone la usano molto, altre poco o per nulla; reparti diversi adottano strumenti diversi; ciascuno sviluppa le proprie pratiche. Questo crea alcuni problemi tipici di collaborazione. Le duplicazioni: lo stesso lavoro svolto due volte, in modi diversi, per esempio due reparti che preparano analisi simili con strumenti diversi, con risultati che non coincidono. La frammentazione delle informazioni: conoscenze, documenti e risultati sparsi in strumenti diversi, non condivisi né confrontabili. Le incoerenze: comunicazioni ai clienti con stili, contenuti o informazioni diverse a seconda di chi le ha preparate e con quale strumento. Le asimmetrie: chi usa molto l'AI produce più rapidamente, e i colleghi che ricevono il suo lavoro devono adattarsi, o si sentono in difficoltà; chi non la usa può essere escluso da alcune modalità di lavoro. Non serve imporre a tutti lo stesso modo di lavorare, ma conviene concordare nel team alcuni elementi comuni: quali strumenti, per quali attività, con quali regole di condivisione e di verifica. La gestione della diffusione nell'organizzazione è il tema del Tema 16.");
    workTag(s, 2);
    rowsLabel(s, [["Duplicazioni", "Lo stesso lavoro due volte, con risultati che non coincidono"], ["Frammentazione", "Conoscenze e risultati sparsi in strumenti diversi"], ["Incoerenze", "Comunicazioni diverse ai clienti secondo chi e con che cosa"], ["Asimmetrie", "Chi usa molto produce in fretta, chi riceve deve adattarsi"]], { y: 1.15, h: 0.55, lw: 2.3 });
    banner(s, 3.7, "Non serve uniformare tutto: concordare nel team strumenti, attività, regole di condivisione e verifica.", { h: 0.75, fontSize: 13 });
    txt(s, "La coerenza tra colleghi va costruita, non si crea da sola.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Individuale e collettivo", "La consapevolezza del sottotema, e uno dei suoi punti centrali: la differenza tra miglioramento individuale e miglioramento del lavoro collettivo. Un miglioramento individuale non produce automaticamente maggiore efficacia del team; il coordinamento rimane essenziale. Abbiamo visto nel Tema 12 che la produttività organizzativa non è la somma di quella individuale; qui vediamo il motivo dal punto di vista della collaborazione. L'efficacia di un team dipende dalle interdipendenze tra le persone e tra le funzioni: chi aspetta il lavoro di chi, chi ha bisogno delle informazioni di chi, dove si prendono le decisioni. L'AI può migliorare il lavoro di ciascuno lasciando invariate le interdipendenze, e allora il team non cambia; o può persino peggiorarle, per esempio quando più persone producono più rapidamente materiale che altri devono leggere, come visto nel Tema 12 per il lavoro trasferito, creando sovraccarico informativo. Alcuni esempi di attenzioni utili per il lavoro collettivo. Usare l'AI per ridurre il lavoro degli altri, non solo il proprio: sintesi invece di testi più lunghi, informazioni più chiare nei passaggi di consegne. Rendere visibile al team ciò che è stato prodotto con l'AI e ciò che è stato verificato. Considerare le interdipendenze tra funzioni quando si introducono nuovi strumenti, come visto nel 13.3 per i processi.");
    workTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiUser", head: "Miglioramento individuale", headSize: 15, bodySize: 12,
      body: bullets(["Ciascuno lavora meglio", "Le interdipendenze restano", "Il team può non cambiare, o peggiorare"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiUsers", head: "Miglioramento collettivo", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Cambiano le interdipendenze", "Meno attese, informazioni più chiare", "Il coordinamento resta essenziale"], { space: 4 }) });
    txt(s, "Attenzioni utili", { x: 0.5, y: 3.55, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const c = ["Ridurre il lavoro degli altri, non solo il proprio", "Rendere visibile che cosa è AI e che cosa è verificato", "Considerare le interdipendenze tra funzioni"];
    c.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.92, 2.86, 0.85, t, { fill: C.background2, fontSize: 12 }));
  }
  keySlide("Un miglioramento individuale non produce automaticamente maggiore efficacia del team: il coordinamento rimane essenziale.", "Sottotema 13.6  ·  AI e collaborazione nei team e tra funzioni", "Concetto chiave del sottotema 13.6. L'AI può migliorare la condivisione delle informazioni, il coordinamento, la comunicazione interna, i passaggi di consegne e la collaborazione su documenti. Ma le differenze di utilizzo tra persone e reparti possono creare duplicazioni, frammentazione, incoerenze e asimmetrie, e i miglioramenti individuali non diventano automaticamente miglioramenti del team, perché l'efficacia collettiva dipende dalle interdipendenze. Esercizio suggerito: in ciascun team rappresentato, elencare gli strumenti AI usati dai diversi componenti e per quali attività, e individuare almeno un elemento comune da concordare.");

  // =====================================================================
  section("13.7 Competenze");
  divider("13.7", "Competenze e modi di lavorare", "Supervisione efficace e autonomia professionale richiedono competenze da preservare e sviluppare", "Quali competenze servono per lavorare con l'AI? In questo sottotema, da comprendere, raccogliamo le competenze emerse lungo tutto il percorso e le guardiamo dal punto di vista del lavoro quotidiano. Affrontiamo anche il rovescio: il rischio di perdita delle competenze per eccessiva delega, e la riduzione delle occasioni di apprendimento pratico, cioè l'integrazione C vista dal lato delle competenze. Il confine con il 13.5: lì l'evoluzione delle responsabilità e delle mansioni, qui le capacità da sviluppare e da mantenere.");
  {
    const s = content("Le competenze per lavorare con l'AI", "Il sottotema elenca una serie di competenze, che corrispondono in buona parte ai temi di questo percorso. Le competenze digitali e l'alfabetizzazione AI: sapere che cos'è l'AI, come funziona a grandi linee, che cosa sa fare e dove sbaglia, i Temi dall'1 al 4. La capacità di formulare problemi e obiettivi: sapere che cosa chiedere, e perché, i Temi 5 e 6. La valutazione critica degli output, il Tema 7. La supervisione delle attività assistite dall'AI: sapere dove controllare, come, con quale intensità, il Tema 11. Le competenze interpretative e decisionali: attribuire significato ai risultati e decidere, i Temi 9 e 12. La collaborazione uomo-AI: saper distribuire il lavoro tra sé e il sistema, il 13.4. L'apprendimento continuo: gli strumenti cambiano rapidamente, e le competenze vanno aggiornate. A queste si aggiunge la competenza che il sottotema richiama esplicitamente: la capacità di riconoscere e correggere gli errori. È la sintesi di tutte le altre, e dipende in modo decisivo dalla conoscenza del dominio. Non basta sapere che l'AI può sbagliare: bisogna saper vedere dove ha sbagliato, in un lavoro che si conosce. Per il relatore: la corrispondenza con i temi del percorso è indicata in questa nota e non sulla slide, così la slide resta valida anche quando il modulo è presentato da solo.");
    workTag(s, 2);
    const c = [["AI literacy", "Che cosa sa fare, dove sbaglia"], ["Formulare problemi", "Che cosa chiedere, e perché"], ["Valutazione critica", "Fatti, fonti, ragionamenti"], ["Supervisione", "Dove controllare, quanto"], ["Interpretare e decidere", "Dare senso ai risultati"], ["Collaborare con l'AI", "Distribuire il lavoro"], ["Apprendimento continuo", "Strumenti che cambiano"], ["Riconoscere e correggere gli errori", "La sintesi di tutte"]];
    c.forEach((e, i) => {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.15 + row * 1.15;
      const last = i === 7;
      shapeBox(s, x, y, 2.15, 1.02, last ? C.accent1 : (row ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: x + 0.12, y: y + 0.08, w: 1.9, h: 0.55, fontSize: 13, bold: true, color: last ? C.background1 : C.text1, valign: "middle" });
      txt(s, e[1], { x: x + 0.12, y: y + 0.65, w: 1.9, h: 0.3, fontSize: 11, italic: true, color: last ? C.accent6 : C.accent1 });
    });
    banner(s, 3.6, "Non basta sapere che l'AI può sbagliare: bisogna saper vedere dove ha sbagliato, in un lavoro che si conosce.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Strumento o modo di lavorare", "Una distinzione che il sottotema chiede di rendere esplicita: conoscere uno strumento non equivale a saper lavorare efficacemente con l'AI. Conoscere uno strumento significa sapere dove si clicca, quali funzioni offre, come si scrive una richiesta. È una competenza utile ma limitata, e anche facilmente superata, perché gli strumenti cambiano di continuo. Saper lavorare con l'AI significa sapere quando usarla e quando no, per quali attività e con quale livello di fiducia; come integrarla nel proprio lavoro e in quello del team; come verificare i risultati con l'intensità giusta; come mantenere le proprie competenze; come rispondere di ciò che si produce. È una competenza professionale, che dipende dalla conoscenza del proprio lavoro, e che resta valida anche quando gli strumenti cambiano. Questa distinzione ha conseguenze pratiche per la formazione: corsi che insegnano solo a usare uno strumento producono una competenza che invecchia rapidamente; percorsi come questo, che insegnano a ragionare sull'AI, costruiscono una competenza più duratura. Ha conseguenze anche per la valutazione: chi usa molto uno strumento non è necessariamente chi lavora meglio con l'AI. Il sottotema richiama anche l'importanza dell'esperienza professionale: è l'esperienza che permette di usare l'AI con giudizio.");
    workTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiTool", head: "Conoscere uno strumento", headSize: 16, bodySize: 12,
      body: bullets(["Funzioni, comandi, richieste", "Utile ma limitato", "Invecchia con lo strumento"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiAward", head: "Saper lavorare con l'AI", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Quando sì e quando no, con quale fiducia", "Integrare, verificare, rispondere", "Dura anche quando gli strumenti cambiano"], { space: 5 }) });
    banner(s, 3.9, "Chi usa molto uno strumento non è necessariamente chi lavora meglio con l'AI. È l'esperienza a dare il giudizio.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("La perdita delle competenze", "Il sottotema richiama il rischio di perdita delle competenze per eccessiva delega, già visto nel Tema 5 come delega cognitiva e nel Tema 12 come costo di lungo periodo. Qui lo guardiamo dal punto di vista delle modalità di lavoro. Le competenze si mantengono esercitandole. Se una persona delega sistematicamente all'AI un'attività che prima svolgeva, come scrivere un certo tipo di documento, fare un certo tipo di analisi, ragionare su un certo tipo di problema, quella competenza tende a indebolirsi. Per chi ha anni di esperienza, l'effetto è lento e parziale: la competenza di base resta, anche se meno allenata. Per chi la competenza la sta ancora costruendo, l'effetto può essere più netto: la competenza non si sviluppa del tutto. Il problema non è la delega in sé, che è proprio ciò che rende utile l'AI, ma la delega senza consapevolezza: delegare tutto, sempre, senza chiedersi quali competenze si vuole mantenere. Alcune pratiche, a livello individuale e di team: decidere consapevolmente quali attività delegare e quali continuare a svolgere, anche solo ogni tanto; usare l'AI per imparare, chiedendo spiegazioni e non solo risultati; formarsi un'opinione prima di guardare la risposta dell'AI, come visto nel Tema 7; alternare lavoro con e senza AI nei percorsi formativi.");
    workTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 1.75, { icon: "FiUser", inline: true, head: "Chi ha esperienza", headSize: 14, bodySize: 12, body: "Effetto lento e parziale: la competenza resta, meno allenata." });
    await card(s, 5.15, 1.2, 4.35, 1.75, { icon: "FiUserPlus", inline: true, head: "Chi sta imparando", headSize: 14, bodySize: 12, fill: C.accent6, iconBg: C.accent5, body: "Effetto più netto: la competenza può non svilupparsi del tutto." });
    shapeBox(s, 0.5, 3.1, 9.0, 0.6, C.text1, "delega");
    txt(s, "Il problema non è delegare, ma delegare senza chiedersi quali competenze mantenere.", { x: 0.7, y: 3.1, w: 8.6, h: 0.6, fontSize: 14, bold: true, color: C.background1, valign: "middle", align: "center" });
    const p = ["Scegliere che cosa delegare", "Chiedere spiegazioni", "Un'opinione prima della risposta", "Con e senza AI nella formazione"];
    p.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.9, 2.15, 0.75, t, { fill: C.background2, fontSize: 12 }));
  }
  {
    const s = content("Meno pratica, più supervisione", "L'integrazione C torna in questo sottotema, dal punto di vista delle competenze: quando l'AI svolge attività formative essenziali, le persone potrebbero sviluppare meno esperienza diretta, pur essendo chiamate a supervisionare risultati complessi. Il sottotema la collega alla riduzione delle occasioni di apprendimento pratico. Abbiamo visto il caso del supervisore inesperto nel 13.5. Qui conviene allargare lo sguardo: in molte professioni, l'esperienza si costruisce attraverso compiti semplici e ripetuti, che sono proprio quelli più facilmente affidati all'AI. Il praticante che redige le prime bozze di contratto, l'analista junior che prepara i primi report, l'addetto che risponde alle prime richieste dei clienti: in queste attività si impara il mestiere, anche sbagliando. Una delle precisazioni trasversali del tema lo dice in modo semplice: compiti semplici possono essere formativi, e il loro affidamento all'AI può ridurre occasioni di pratica, pur generando vantaggi immediati. Il documento ricorda però che è un rischio possibile, non una conseguenza inevitabile: un utilizzo dell'AI progettato per l'apprendimento può anche aiutare a sviluppare competenze. Per esempio, l'AI può proporre esercizi, spiegare gli errori, simulare casi, dare un feedback immediato che un collega esperto non sempre ha il tempo di dare. La differenza la fa il modo in cui l'organizzazione disegna il lavoro e la formazione.");
    workTag(s, 2);
    docBox(s, 0.5, 1.15, 4.35, 1.8, "Dove si impara il mestiere", "Le prime bozze di contratto, i primi report, le prime risposte ai clienti: compiti semplici, proprio quelli più facili da affidare all'AI.", { fontSize: 12 });
    await card(s, 5.15, 1.15, 4.35, 1.8, { icon: "FiBookOpen", inline: true, head: "L'AI per imparare", headSize: 14, bodySize: 12, fill: C.accent6, body: "Esercizi, spiegazioni degli errori, casi simulati, feedback immediato." });
    banner(s, 3.15, "Compiti semplici possono essere formativi. Un rischio possibile, non inevitabile: la differenza la fa il disegno del lavoro e della formazione.", { h: 0.85, fontSize: 13 });
  }
  keySlide("Supervisione efficace e autonomia professionale richiedono competenze da preservare e sviluppare.", "Sottotema 13.7  ·  Competenze e modi di lavorare", "Concetto chiave del sottotema 13.7. Lavorare con l'AI richiede alfabetizzazione AI, capacità di formulare problemi, valutazione critica, supervisione, interpretazione e decisione, collaborazione e apprendimento continuo, e soprattutto la capacità di riconoscere e correggere gli errori, che dipende dalla conoscenza del dominio. Conoscere uno strumento non è saper lavorare con l'AI. La delega senza consapevolezza può indebolire le competenze, specialmente di chi sta imparando, e l'affidamento all'AI dei compiti formativi può ridurre le occasioni di pratica; ma l'AI può anche essere usata per imparare. Esercizio suggerito: ciascun partecipante indica un'attività che delega all'AI e una competenza che vuole mantenere, e propone una pratica concreta per farlo.");

  // =====================================================================
  section("13.8 Condizioni e rischi");
  divider("13.8", "Condizioni e rischi della trasformazione", "L'impatto dell'AI va valutato osservando l'intero lavoro svolto, non solo le prestazioni degli strumenti", "Ultimo sottotema, di consapevolezza critica. Raccogliamo i rischi della trasformazione del lavoro emersi nel modulo e ne aggiungiamo alcuni: gli effetti inattesi sui flussi, i nuovi colli di bottiglia, il sovraccarico informativo, l'aumento delle verifiche, la dipendenza, la perdita di conoscenze, le differenze tra persone e gruppi. E chiudiamo con un principio di metodo: osservare il lavoro reale. Le integrazioni B e D si ritrovano qui: la trasformazione può generare nuove inefficienze, dipendenze e attività, e occorre valutarne gli effetti reali nell'organizzazione.");
  {
    const s = content("Adozione e trasformazione effettiva", "Il primo punto del sottotema riprende una distinzione vista nel Tema 12 dal punto di vista del valore: la differenza tra adozione degli strumenti e trasformazione effettiva. Dal punto di vista del lavoro, l'adozione significa che gli strumenti sono disponibili e usati; la trasformazione significa che il modo di lavorare è cambiato in modo stabile e intenzionale: attività, processi, ruoli, competenze. Si può avere molta adozione con poca trasformazione: tutti usano un assistente per scrivere email più in fretta, ma il lavoro è organizzato esattamente come prima. In questo caso i benefici restano individuali e spesso modesti. Si può avere anche una trasformazione con poca adozione visibile: un processo riprogettato con un componente AI integrato, che le persone usano senza nemmeno percepirlo come uno strumento separato. La trasformazione effettiva, quella che produce i cambiamenti più rilevanti, richiede scelte esplicite: come cambia il processo, chi fa che cosa, dove si collocano i controlli, come si sviluppano le competenze. Senza queste scelte, l'AI si aggiunge al lavoro esistente senza trasformarlo, e a volte lo complica. La gestione di questo passaggio, cioè l'accompagnamento del cambiamento, è il tema del Tema 16.");
    workTag(s, 3);
    table(s, [["", "Poca trasformazione", "Molta trasformazione"],
      ["Molta adozione", "Tutti usano l'AI, il lavoro è organizzato come prima: benefici individuali", "Strumenti diffusi e processi ripensati"],
      ["Poca adozione visibile", "Nessun cambiamento", "AI integrata nel processo, quasi invisibile"]],
      { y: 1.15, colW: [2.4, 3.3, 3.3], rowH: 0.75, fontSize: 12 });
    banner(s, 3.6, "La trasformazione richiede scelte esplicite: processo, ruoli, controlli, competenze. Senza, l'AI si aggiunge al lavoro, e a volte lo complica.", { h: 0.85, fontSize: 13 });
    txt(s, "La trasformazione va accompagnata: non avviene da sola.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Effetti inattesi sul lavoro", "Il sottotema elenca diversi effetti inattesi che la trasformazione può produrre sui flussi operativi. Alcuni li abbiamo incontrati; qui li mettiamo insieme. Nuovi colli di bottiglia: accelerare la produzione sposta il collo di bottiglia sulla verifica o sull'approvazione, spesso a carico di poche persone esperte. Sovraccarico informativo: più contenuti prodotti più facilmente, più email, più report, più sintesi, più materiale da leggere per tutti. Aumento delle attività di verifica: ogni output dell'AI con conseguenze va controllato, e il controllo richiede tempo e attenzione, come visto nel Tema 12. Introduzione di nuovo lavoro operativo: gestione delle eccezioni, aggiornamento delle informazioni, monitoraggio, coordinamento, come visto nel 13.3. Effetti indesiderati sulla qualità: errori sistematici, qualità apparente scambiata per effettiva, come visto nel Tema 12. Effetti indesiderati sulla collaborazione: frammentazione, asimmetrie, meno confronto tra colleghi perché si chiede all'AI invece che a un collega, come visto nel 13.6. Nessuno di questi effetti è inevitabile, ma tutti sono frequenti, e tutti hanno una caratteristica comune: non si vedono guardando le prestazioni dello strumento, ma solo guardando il lavoro nel suo insieme.");
    workTag(s, 3);
    await iconGrid(s, [
      { icon: "FiFilter", head: "Nuovi colli di bottiglia", body: "Verifica e approvazione, su pochi esperti" },
      { icon: "FiInbox", head: "Sovraccarico informativo", body: "Più email, report, sintesi da leggere" },
      { icon: "FiSearch", head: "Più verifiche", body: "Ogni output con conseguenze va controllato" },
      { icon: "FiPlusCircle", head: "Nuovo lavoro operativo", body: "Eccezioni, aggiornamenti, monitoraggio" },
      { icon: "FiAlertTriangle", head: "Effetti sulla qualità", body: "Errori sistematici, qualità apparente" },
      { icon: "FiUsers", head: "Effetti sulla collaborazione", body: "Frammentazione, meno confronto tra colleghi" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Non si vedono guardando lo strumento, ma solo guardando il lavoro nel suo insieme.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Rischi strutturali", "Altri rischi del sottotema, più strutturali. Il rischio di automatizzare inefficienze esistenti, l'integrazione B vista nel 13.3: un processo inefficiente reso più veloce resta inefficiente, e diventa più difficile da cambiare. La dipendenza dagli strumenti: quando un'attività dipende interamente da uno strumento AI, un'interruzione del servizio, un cambiamento del fornitore, un aggiornamento che modifica il comportamento del modello, un aumento dei prezzi possono bloccare o peggiorare il lavoro. Conviene sapere come si lavorerebbe senza lo strumento, e avere una procedura di riserva, come visto nel Tema 11. La perdita di conoscenze e competenze: non solo quelle individuali, viste nel 13.7, ma quelle dell'organizzazione. Quando le persone esperte lasciano e il loro lavoro è stato in parte affidato all'AI, la conoscenza di come e perché si fanno le cose può andare persa, perché non è più esercitata né trasmessa. Le differenze di utilizzo tra persone e gruppi: chi ha più competenze, più tempo, più accesso agli strumenti trae più vantaggio dall'AI, e le differenze tra persone e gruppi possono crescere. Infine, la necessità di preservare responsabilità e controllo: con processi più automatizzati e più persone coinvolte, il rischio è che nessuno sappia più chi risponde di che cosa.");
    workTag(s, 3);
    rowsLabel(s, [["Inefficienze automatizzate", "Più veloci e più difficili da cambiare"], ["Dipendenza dagli strumenti", "Interruzioni, cambi di fornitore, aggiornamenti, prezzi"], ["Conoscenze organizzative", "Chi sa come e perché si fanno le cose, se gli esperti lasciano?"], ["Differenze tra persone", "Chi ha più competenze, tempo e accesso ne trae più vantaggio"], ["Responsabilità e controllo", "Chi risponde di che cosa, nei processi automatizzati?"]], { y: 1.15, h: 0.52, lw: 2.8 });
    banner(s, 4.2, "Sapere come si lavorerebbe senza lo strumento, e chi risponde di che cosa.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Osservare il lavoro reale", "Il principio di metodo con cui il sottotema, e il tema, si chiudono: l'importanza di osservare il lavoro reale. La consapevolezza del sottotema lo dice chiaramente: l'impatto dell'AI va valutato osservando l'intero lavoro effettivamente svolto, non solo le prestazioni degli strumenti. Che cosa significa in pratica? Guardare come le persone lavorano davvero, non come i processi sono descritti nelle procedure o come i fornitori descrivono gli strumenti. Chiedere a chi svolge il lavoro che cosa è cambiato, che cosa è più facile, che cosa è più difficile, dove passa ora il tempo. Seguire un'attività dall'inizio alla fine, attraverso le persone e le funzioni, per vedere dove si sono spostati il lavoro, le attese e i controlli. Osservare non solo chi usa lo strumento, ma anche chi riceve il suo lavoro e chi lo verifica. Osservare nel tempo, perché alcuni effetti, come la perdita di competenze o il sovraccarico, emergono dopo mesi. Combinare le osservazioni con gli indicatori visti nel Tema 12. È un lavoro meno tecnico e meno spettacolare della valutazione degli strumenti, ma è il solo modo di sapere che cosa l'AI sta davvero facendo al lavoro di un'organizzazione. E coinvolgere le persone nell'osservazione è anche il primo passo per gestire bene il cambiamento, come vedremo nel Tema 16. Gli indicatori di risultato sono quelli visti nel Tema 12.");
    workTag(s, 3);
    numList(s, ["Guardare come si lavora davvero, non le procedure o le promesse", "Chiedere a chi lavora: che cosa è cambiato, dove passa ora il tempo?", "Seguire un'attività dall'inizio alla fine, tra persone e funzioni", "Osservare anche chi riceve e chi verifica il lavoro", "Osservare nel tempo, insieme agli indicatori di risultato"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "Il solo modo di sapere che cosa l'AI sta davvero facendo al lavoro. Coinvolgere le persone è il primo passo.", { h: 0.7, fontSize: 13 });
  }
  keySlide("L'impatto dell'AI va valutato osservando l'intero lavoro effettivamente svolto, non solo le prestazioni degli strumenti.", "Sottotema 13.8  ·  Condizioni e rischi della trasformazione", "Concetto chiave dell'ultimo sottotema. L'adozione degli strumenti non è la trasformazione del lavoro, che richiede scelte esplicite. La trasformazione può produrre effetti inattesi: nuovi colli di bottiglia, sovraccarico informativo, più verifiche, nuovo lavoro, effetti sulla qualità e sulla collaborazione. Ci sono rischi strutturali: inefficienze automatizzate, dipendenza dagli strumenti, perdita di conoscenze, differenze crescenti tra persone, responsabilità poco chiare. Il metodo è osservare il lavoro reale, con chi lo svolge, nel tempo. Esercizio suggerito: scegliere un'attività in cui l'AI è già usata e intervistare in coppia un collega su che cosa è cambiato, che cosa è più facile, che cosa è più difficile e chi ne è stato toccato.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle nove domande guida. Come cambia il lavoro: soprattutto a livello di compiti, specialmente nel lavoro informativo e cognitivo, con attività assistite, automatizzate o trasformate. Compiti, mansioni, ruoli, processi: livelli diversi, e un cambiamento in uno non implica gli altri. Attività trasformabili: dipende da ripetitività, variabilità, giudizio, informazioni, rischio, contesto. Compito e processo: le interdipendenze fanno sì che un passaggio migliore possa lasciare invariato o peggiorare il processo. Collaborazione, supervisione, responsabilità: dal fare al controllare, con competenze più solide e responsabilità che resta. Ruoli: cambia la composizione delle mansioni; gli effetti sull'occupazione non sono predeterminati. Competenze e apprendimento: crescono quelle di giudizio, e va protetta la pratica di chi impara. Nuove attività: verifica, eccezioni, monitoraggio, coordinamento, da conteggiare. Processi inefficienti: automatizzarli li rende più veloci e più difficili da cambiare. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Come cambia il lavoro?", "Sui compiti: assistiti, automatizzati, trasformati"], ["Compiti, mansioni, ruoli, processi?", "Livelli diversi, non si implicano"], ["Che cosa rende trasformabile?", "Variabilità, giudizio, informazioni, rischio, contesto"], ["Compito o processo?", "Le interdipendenze decidono"], ["Collaborazione e responsabilità?", "Dal fare al controllare; la responsabilità resta"], ["Effetti sui ruoli?", "Composizione che cambia; occupazione non predeterminata"], ["Competenze e apprendimento?", "Più giudizio; proteggere la pratica"], ["Perché nuove attività?", "Verifica, eccezioni, monitoraggio, coordinamento"], ["Processi inefficienti?", "Più veloci e più difficili da cambiare"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.74;
      shapeBox(s, x, y, 4.4, 0.66, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.66, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.04, w: 3.8, h: 0.3, fontSize: 11, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.33, w: 3.8, h: 0.3, fontSize: 10, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere compiti, mansioni, ruoli e processi; comprendere come l'AI possa modificare la natura di alcune attività; riconoscere le caratteristiche che influenzano la trasformabilità dei compiti; distinguere automazione di un'attività e trasformazione di un processo; spiegare perché automatizzare processi inefficienti può non produrre miglioramenti; riconoscere nuovi modelli di collaborazione tra persone e AI; comprendere come possano evolvere mansioni e responsabilità; distinguere automazione dei compiti e sostituzione dei ruoli; identificare possibili effetti sulla collaborazione nei team; riconoscere le competenze necessarie per lavorare con l'AI; comprendere i rischi di erosione delle competenze e delle occasioni di apprendimento; riconoscere che la trasformazione può ridurre attività esistenti e crearne di nuove.");
    const r = ["Compiti, mansioni, ruoli, processi", "Come cambiano le attività", "Che cosa rende trasformabile un compito", "Attività automatizzata o processo trasformato", "Automatizzare processi inefficienti", "Modelli di collaborazione persone e AI", "Come evolvono mansioni e responsabilità", "Compiti automatizzati, ruoli non sostituiti", "Effetti sulla collaborazione nei team", "Competenze per lavorare con l'AI", "Erosione di competenze e apprendimento", "Attività ridotte e attività nuove"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Domande sul cambiamento del lavoro", "Traduciamo il modulo in una scheda pratica: le domande da porsi quando l'AI entra in un'attività o in un processo, dal proprio punto di vista o da quello di chi organizza il lavoro. Attività: quali compiti cambiano, e come: assistiti, automatizzati, trasformati? Hanno le caratteristiche giuste, ci sono le informazioni, quale rischio comportano? Processi: che cosa cambia nella sequenza, nei controlli, nei punti di intervento umano? Il processo aveva senso così com'era? Quale nuovo lavoro si crea, e chi lo fa? Persone: come si distribuisce il lavoro tra persona e sistema? Come cambiano le mansioni e le responsabilità? Quali competenze crescono, quali vanno mantenute? Chi sta imparando, ha ancora occasioni di pratica? Il team usa gli strumenti in modo coerente? Rischi: quali effetti inattesi si osservano: colli di bottiglia, sovraccarico, verifiche? Da che cosa si dipende? Chi risponde di che cosa? Che cosa dice chi svolge davvero il lavoro? Sono domande semplici, ma che spostano l'attenzione dallo strumento al lavoro, che è il punto di questo modulo.");
    const f = [["Attività", ["Quali compiti, come cambiano?", "Informazioni e rischio?"], C.background2], ["Processi", ["Sequenza, controlli, persone?", "Aveva senso così?", "Quale nuovo lavoro?"], C.accent6], ["Persone", ["Chi fa che cosa?", "Competenze da mantenere?", "Chi impara, pratica ancora?"], C.background2], ["Rischi", ["Effetti inattesi?", "Dipendenze?", "Chi risponde? Che cosa dice chi lavora?"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Domande che spostano l'attenzione dallo strumento al lavoro.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei semplificazioni frequenti quando si parla di AI e lavoro, una per ciascuno dei principali messaggi del modulo. Primo: 'l'AI scrive email, quindi gli addetti spariranno'. È il salto da un compito al ruolo intero: un ruolo comprende molte attività, e l'automazione di alcune non determina la scomparsa dell'intero ruolo, come mostra l'esempio dei bancomat. Secondo: 'è esposto, quindi verrà sostituito'. L'esposizione indica una possibilità tecnica; tra questa e l'effetto sul lavoro ci sono affidabilità, convenienza, adozione e scelte organizzative. Terzo: 'mettiamo l'AI nel processo attuale', così com'è. Automatizzare un processo inefficiente produce un processo inefficiente più veloce, e più difficile da cambiare. Quarto: 'ognuno usa lo strumento che vuole'. I miglioramenti individuali non si sommano automaticamente: senza regole comuni nascono duplicazioni, frammentazione e incoerenze. Quinto: 'il junior controlla l'AI, così impara'. Senza occasioni di pratica, chi sta imparando non sviluppa le competenze che servono proprio per controllare; è il paradosso del supervisore inesperto. Sesto: 'lo usano tutti, quindi il lavoro è cambiato'. L'adozione non è trasformazione: il cambiamento si osserva guardando il lavoro reale. Suggerimento: chiedere ai partecipanti quale di queste frasi hanno sentito più spesso in azienda.");
    const a = [["FiMail", "\"Scrive email: gli addetti spariranno\"", "Un compito non è il ruolo", "13.1"], ["FiPercent", "\"È esposto, quindi sarà sostituito\"", "Esposizione non è sostituzione", "13.1"], ["FiShuffle", "\"Mettiamo l'AI nel processo attuale\"", "Si automatizza l'inefficienza", "13.3"], ["FiGrid", "\"Ognuno usa lo strumento che vuole\"", "Servono regole comuni nel team", "13.6"], ["FiUserCheck", "\"Il junior controlla l'AI e impara\"", "Senza pratica, niente competenza", "13.7"], ["FiActivity", "\"Lo usano tutti: il lavoro è cambiato\"", "Adozione non è trasformazione", "13.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 2.95, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.7, y: y + 0.1, w: 0.55, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 13 abbiamo visto come l'AI può cambiare il lavoro, e che gli effetti dipendono dalle scelte organizzative. Il tema successivo, il Tema 14, è dedicato all'AI, ai dati e alla conoscenza aziendale: il patrimonio informativo dell'azienda, la qualità e l'aggiornamento delle informazioni, l'organizzazione e l'accessibilità della conoscenza, come l'AI può usare informazioni aziendali specifiche, l'integrazione con i sistemi, gli accessi e i permessi, l'affidabilità delle risposte basate sulla conoscenza aziendale. È il naturale complemento di questo modulo: abbiamo visto più volte che la trasformabilità di un'attività dipende dalla disponibilità delle informazioni, che le conoscenze organizzative rischiano di perdersi, che l'AI vale quanto le informazioni su cui si basa. Nel Tema 14 guarderemo proprio a queste condizioni informative. Seguiranno il Tema 15, sulla valutazione e la scelta delle opportunità, e il Tema 16, sull'adozione e il cambiamento organizzativo, dove molte questioni aperte in questo modulo, come accompagnare le persone, troveranno una risposta operativa. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 12: valore; Tema 13: lavoro e processi (completato)", { x: 0.75, y: 4.07, w: 3.9, h: 0.55, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 14: AI, dati e conoscenza aziendale", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Patrimonio informativo, qualità, accessi, affidabilità", { x: 5.4, y: 2.4, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.0, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 15: opportunità e valutazione", "Tema 16: adozione e cambiamento organizzativo"], { space: 5 }), { x: 5.4, y: 3.35, w: 3.9, h: 1.2, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le stime sull'esposizione (circa l'80 per cento dei lavoratori statunitensi con almeno il 10 per cento dei compiti esposti, circa il 19 per cento con almeno la metà) vengono dall'analisi completa di Eloundou e colleghi; una sintesi è stata pubblicata su Science nel 2024. Verificato a ottobre 2026; da controllare se la sintesi su Science riporta gli stessi valori. Le fonti citate nel modulo. Il dibattito sugli effetti dell'AI sul lavoro è molto attivo e in rapida evoluzione: le stime di esposizione e gli studi sugli effetti vengono aggiornati di continuo, ed è consigliabile verificarli prima di ogni edizione. L'esempio storico dei bancomat è tra i più citati nella letteratura economica, ma va presentato con le sue cautele, come fatto nelle slide. Gli esempi aziendali del modulo sono fittizi, tranne quello della richiesta del cliente, tratto dal documento di perimetro.");
    const src = [
      "Eloundou, T., Manning, S., Mishkin, P., Rock, D. (2024). GPTs are GPTs: Labor market impact potential of LLMs. Science, 384(6702), 1306-1308. Analisi completa: arXiv:2303.10130 (2023).",
      "Bessen, J. (2015). Learning by Doing: The Real Connection between Innovation, Wages, and Wealth. Yale University Press.",
      "Autor, D. H., Levy, F., Murnane, R. J. (2003). The Skill Content of Recent Technological Change. Quarterly Journal of Economics, 118(4), 1279-1333.",
      "Gli esempi aziendali e i numeri delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema13_AI_trasformazione_lavoro_processi.pptx" });
  await applyTheme("Tema13_AI_trasformazione_lavoro_processi.pptx", THEME);
  console.log("done");
})();
