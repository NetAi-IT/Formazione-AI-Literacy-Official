  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
