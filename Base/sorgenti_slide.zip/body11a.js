  function areaTag(s, active) {
    const st = ["Capacità", "Agenti", "Supervisione", "Affidabilità"];
    st.forEach((t, i) => {
      const x = 6.3 + i * 0.81;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.78, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "area " + t });
      txt(s, t, { x, y: 0.42, w: 0.78, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, 0.5, y, 9.0, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: 0.7 + lw, y, w: 8.6 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }
  // staircase of the four operational levels; active: index highlighted
  function levels(s, y, h, active, o) {
    o = o || {};
    const L = [["Suggerisce", "Propone; la persona esegue"], ["Prepara", "Predispone; la persona completa"], ["Esegue con approvazione", "Agisce dopo una conferma"], ["Esegue entro limiti", "Opera in un perimetro, monitorato"]];
    L.forEach((e, i) => {
      const x = 0.5 + i * 2.3, dy = (3 - i) * (o.step || 0.22);
      const on = active === undefined || active === i;
      const fill = active === i ? C.accent1 : (on ? C.accent6 : C.background2);
      const fc = active === i ? C.background1 : C.text1;
      shapeBox(s, x, y + dy, 2.15, h - dy, fill, e[0]);
      txt(s, String(i + 1), { x: x + 0.12, y: y + dy + 0.06, w: 0.4, h: 0.4, fontSize: 18, bold: true, color: active === i ? C.accent6 : C.accent1 });
      txt(s, e[0], { x: x + 0.12, y: y + dy + 0.45, w: 1.95, h: 0.5, fontSize: 13, bold: true, color: fc });
      txt(s, e[1], { x: x + 0.12, y: y + dy + 0.95, w: 1.95, h: 0.5, fontSize: 11, color: fc });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 11", { placeholder: "kicker" });
    s.addText("Assistenti, agenti e automazioni con l'AI", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti all'undicesimo tema, che chiude l'area 'Esplorare le possibilità dell'AI'. Nei temi precedenti abbiamo visto che cosa l'AI può fare con testi, documenti, dati, immagini, audio e video. In quasi tutti i casi, però, l'AI produceva un contenuto: una risposta, una sintesi, una tabella, un'immagine. Una persona lo leggeva, lo valutava e poi decideva che cosa farne. In questo tema facciamo un passo diverso: guardiamo all'AI che agisce. Assistenti che usano strumenti e applicazioni, agenti che perseguono un obiettivo coordinando più passaggi, automazioni che integrano componenti AI nei processi. È un passaggio che amplia molto le possibilità, ed è anche quello in cui cambiano di più i rischi, perché un'azione può avere conseguenze dirette. Un'avvertenza importante dal documento di perimetro: per il pubblico aziendale bisogna evitare di presentare gli agenti come lavoratori digitali indistintamente autonomi, di considerare una maggiore autonomia sempre desiderabile, di confondere fattibilità tecnica e opportunità, e di valutare un sistema solo sulla base di dimostrazioni riuscite. Suggerimento per l'apertura: chiedere ai partecipanti quali attività ripetitive del loro lavoro vorrebbero affidare a un sistema che agisce al loro posto, e che cosa servirebbe per fidarsi. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; gli strumenti agentici, i protocolli di collegamento e le pratiche di sicurezza evolvono molto rapidamente, quindi esempi, dimostrazioni e riferimenti vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è sviluppare la comprensione di come l'AI possa evolvere da strumento conversazionale a componente operativa di attività e processi, attraverso assistenti, strumenti, agenti e automazioni; distinguere i livelli di autonomia; riconoscere le condizioni necessarie per un utilizzo affidabile. La consapevolezza da sviluppare: il passaggio dalla generazione di risposte all'esecuzione di azioni amplia le possibilità dell'AI, ma introduce rischi e responsabilità differenti. Le capacità operative devono essere accompagnate da autorizzazioni adeguate, limiti, verifiche e supervisione proporzionata alle conseguenze. Il messaggio centrale del tema: il passaggio dall'assistenza all'azione amplia le possibilità dell'AI, ma rende fondamentali la definizione dei limiti, il controllo delle azioni, la supervisione e la gestione degli errori. Il confine con l'area successiva: qui spieghiamo che cosa significa rendere un sistema AI operativo; nei Temi 12 e 15 si valuterà dove, perché e a quali condizioni convenga impiegarlo.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Capire come l'AI passa dalla conversazione all'azione", "Distinguere assistenti, agenti e automazioni", "Riconoscere livelli di autonomia e condizioni di affidabilità"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Dalla risposta all'azione cambiano rischi e responsabilità.\n\nLe capacità operative richiedono autorizzazioni, limiti, verifiche e supervisione proporzionata alle conseguenze." });
  }
  {
    const s = content("Nove domande guida", "Le nove domande guida accompagnano il modulo. Le prime tre riguardano il passaggio all'azione: che cosa distingue un chatbot da un assistente e da un agente, che differenza c'è tra suggerire, preparare ed eseguire, come i sistemi usano strumenti, file e applicazioni. La quarta e la quinta riguardano agenti e automazioni: che cosa distingue un agente da un workflow automatizzato, e quando è preferibile un'automazione tradizionale. La sesta e la settima riguardano il ruolo umano: la differenza tra automazione, autonomia e supervisione, e come collaborano persone e agenti. Le ultime due riguardano l'affidabilità: come cambiano rischi e controlli quando l'AI agisce, e perché una dimostrazione riuscita non dimostra l'affidabilità operativa. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Che cosa distingue chatbot, assistente e agente?", "Suggerire, preparare, eseguire: che differenza c'è?", "Come usano strumenti, file e applicazioni?", "Agente o workflow automatizzato?", "Quando è meglio un'automazione tradizionale?", "Automazione, autonomia, supervisione: che differenza?", "Come collaborano persone, assistenti e agenti?", "Come cambiano rischi e controlli quando l'AI agisce?", "Perché una demo riuscita non prova l'affidabilità?"], 3, 1.12, 1.0, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in quattro passaggi. Il passaggio dalla conversazione alle capacità operative: come gli assistenti sono diventati capaci di usare strumenti e applicazioni, nei sottotemi 11.1 e 11.2. Agenti e automazioni come modalità diverse di esecuzione, nell'11.3 e nell'11.4. Autonomia, supervisione e collaborazione: quanta discrezionalità dare al sistema, con quali controlli, e come distribuire il lavoro tra persone e AI, dall'11.5 all'11.7. Robustezza, verificabilità e rischi operativi, nell'11.8. Il nucleo prioritario, secondo il documento, è composto da 11.3, 11.4, 11.5 e 11.8: agenti, automazioni, autonomia e affidabilità. Tre precisazioni trasversali accompagnano tutto il tema. L'autonomia non è una caratteristica assoluta: un sistema può scegliere i passaggi ma chiedere conferma prima di agire. Un errore operativo può produrre effetti diretti e talvolta difficilmente reversibili. L'affidabilità si valuta sul processo completo, non sulla riuscita dei singoli passaggi. Nelle slide, un indicatore in alto a destra ricorda l'area di cui stiamo parlando.");
    const d = [["FiTool", "Capacità operative", "11.1  11.2"], ["FiCpu", "Agenti e automazioni", "11.3  11.4"], ["FiUsers", "Supervisione e collaborazione", "11.5  11.6  11.7"], ["FiShield", "Affidabilità", "11.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.0, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.03, w: 1.9, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.65, w: 1.9, h: 0.35, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Tre precisazioni trasversali", { x: 0.5, y: 3.3, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const p = ["L'autonomia non è assoluta: si può scegliere i passaggi e chiedere conferma", "Un errore operativo può avere effetti diretti, difficili da annullare", "L'affidabilità si valuta sul processo completo, non sui singoli passaggi"];
    p.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.7, 2.86, 1.0, t, { fill: C.accent6, fontSize: 12 }));
  }
  {
    const s = content("Chatbot, assistenti, agenti, automazioni", "Una distinzione che attraversa tutto il modulo, e il primo risultato atteso. Le denominazioni commerciali non sono uniformi: lo stesso nome può indicare cose diverse a seconda del fornitore. Il documento propone quindi una distinzione funzionale, basata su ciò che il sistema fa. Il chatbot risponde e sostiene conversazioni: spiega un argomento, risponde a domande. L'assistente AI supporta attività usando, quando disponibili, contesto e strumenti: prepara un riepilogo dai documenti di un progetto, redige una bozza di email a partire dalla conversazione precedente. L'agente AI persegue un obiettivo coordinando passaggi e strumenti, se abilitati: raccoglie informazioni da più fonti, prepara un report, chiede l'approvazione prima di inviarlo. L'automazione esegue attività secondo un meccanismo definito: trasferisce dati tra due sistemi ogni notte, invia un report ogni lunedì. Le categorie possono sovrapporsi: un assistente può avere capacità agentiche, e un agente può essere inserito in un workflow automatizzato. Il documento chiede di evitare una semplificazione frequente: che un agente sia soltanto un'automazione più avanzata. Come vedremo, sono modalità di esecuzione diverse, adatte a situazioni diverse.");
    table(s, [["Tipologia", "Funzione prevalente", "Esempio"],
      ["Chatbot", "Rispondere e sostenere conversazioni", "Spiegare un argomento"],
      ["Assistente AI", "Supportare attività con contesto e strumenti", "Preparare un riepilogo da documenti"],
      ["Agente AI", "Perseguire obiettivi coordinando passaggi e strumenti", "Raccogliere informazioni, preparare un report, chiedere approvazione"],
      ["Automazione", "Eseguire attività secondo un meccanismo definito", "Trasferire dati tra sistemi ogni notte"]],
      { y: 1.15, colW: [1.9, 3.5, 3.6], rowH: 0.52, fontSize: 12, blankCorner: false });
    banner(s, 3.95, "Le categorie si sovrappongono. Un agente non è soltanto un'automazione più avanzata.", { h: 0.65, fontSize: 14 });
    txt(s, "Distinzione funzionale: le denominazioni commerciali non sono uniformi.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, la collaborazione tra persone e agenti, con priorità media. Vanno compresi bene: le differenze tra agenti e automazioni, gli strumenti, i livelli di autonomia, il controllo umano, la propagazione degli errori. Vanno conosciuti e sperimentati: attività a più passaggi, approvazioni, collaborazione tra persone e agenti, interazioni con applicazioni. Vanno solo accennati: framework agentici, API, protocolli tecnici, orchestrazione di più agenti, implementazione di automazioni in produzione. Confini: non ripetiamo il funzionamento interno dei modelli del Tema 2, il catalogo degli strumenti del Tema 4, la collaborazione conversazionale e la delega cognitiva del Tema 5, la progettazione delle istruzioni del Tema 6, i metodi generali di verifica delle risposte del Tema 7: qui si controllano soprattutto azioni e processi. Non trattiamo architetture e connessioni aziendali, del Tema 14, né la valutazione delle iniziative, del Tema 15. Sicurezza, privacy e obblighi normativi sono approfonditi nei Temi 17 e 18.");
    pathSlide(s, [["11.1", "Dalla conversazione all'azione", "Alta"], ["11.2", "Strumenti e integrazioni", "Alta"], ["11.3", "Che cosa sono gli agenti AI", "Alta"], ["11.4", "Automazione tradizionale e intelligente", "Alta"], ["11.5", "Autonomia e supervisione umana", "Alta"], ["11.6", "Attività e processi supportabili", "Alta"], ["11.7", "Collaborazione persone e agenti", "Media"], ["11.8", "Limiti, rischi, affidabilità", "Alta"]],
      [["Comprendere bene", "Agenti e automazioni, strumenti, livelli di autonomia, controllo umano, errori", C.accent1, C.background1], ["Conoscere e sperimentare", "Attività a più passaggi, approvazioni, collaborazione, applicazioni", C.accent6, C.text1], ["Solo accennare", "Framework agentici, API, protocolli, orchestrazione, produzione", C.background2, C.text1]]);
  }

  // =====================================================================
  section("11.1 Dalla conversazione all'azione");
  divider("11.1", "Dalla conversazione all'azione", "Non tutti gli assistenti AI possono eseguire azioni: distinguere ciò che propongono da ciò che fanno", "Partiamo dall'evoluzione che ha portato dai primi chatbot agli assistenti di oggi. In questo sottotema, da comprendere, vediamo che cosa sono gli assistenti integrati negli strumenti di lavoro, che cosa si intende con il termine copilot, la distinzione fondamentale tra rispondere, suggerire, preparare ed eseguire, e la differenza tra ciò che i nomi commerciali promettono e ciò che i sistemi fanno davvero. È la base per tutto il modulo: prima di chiedersi quanto sia affidabile un sistema che agisce, bisogna sapere che cosa può fare.");
  {
    const s = content("Dai chatbot agli assistenti", "Un breve percorso evolutivo, utile per orientarsi. I chatbot tradizionali, diffusi da molti anni su siti e servizi clienti, seguivano percorsi predefiniti: riconoscevano alcune domande e fornivano risposte preparate. Con i modelli linguistici sono arrivati gli assistenti conversazionali: capaci di sostenere una conversazione aperta su qualsiasi argomento, di scrivere, riassumere, spiegare, ma limitati a ciò che si scriveva nella conversazione. Il passo successivo sono stati gli assistenti integrati negli strumenti di lavoro: dentro il programma di posta, il foglio di calcolo, l'editor di documenti, il sistema di gestione dei clienti. Questi assistenti hanno accesso al contesto, cioè al documento aperto, alla casella di posta, ai dati del cliente, e possono intervenire direttamente sul lavoro. Infine, i sistemi con capacità di azione: assistenti e agenti che usano strumenti, cercano informazioni, modificano file, inviano messaggi, operano su più applicazioni. Ogni passo ha ampliato le possibilità e, insieme, il raggio delle possibili conseguenze. Il documento chiede di comprendere questo percorso senza confondere i diversi stadi: molti sistemi in uso oggi si fermano ai primi.");
    areaTag(s, 0);
    const st = [["Chatbot tradizionali", "Percorsi e risposte predefiniti"], ["Assistenti conversazionali", "Conversazione aperta, solo sul testo scritto"], ["Assistenti integrati", "Dentro gli strumenti, con accesso al contesto"], ["Sistemi che agiscono", "Usano strumenti, modificano, inviano, operano"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.1, 2.2, i === 3 ? C.accent1 : (i === 2 ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.3, w: 1.8, h: 0.7, fontSize: 14, bold: true, color: i === 3 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 2.05, w: 1.8, h: 1.2, fontSize: 12, color: i === 3 ? C.background1 : C.text1 });
      if (i < 3) arrow(s, x + 2.11, 2.15, 0.17);
    });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 0.5, y: 3.6, w: 9.0, h: 0.3, fill: { color: C.accent5 }, line: { type: "none" }, objectName: "freccia conseguenze" });
    txt(s, "Più possibilità, e insieme un raggio più ampio di possibili conseguenze. Molti sistemi in uso si fermano ai primi stadi.", { x: 0.5, y: 4.05, w: 9, h: 0.7, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Assistenti integrati e copilot", "Gli assistenti integrati negli strumenti di lavoro sono oggi la forma più diffusa di AI in azienda. Il termine copilot, reso popolare da alcuni prodotti, esprime bene l'idea: un copilota affianca il pilota, lo supporta, può prendere i comandi in alcune fasi, ma il pilota resta responsabile del volo. Un assistente integrato lavora nel contesto dell'applicazione in cui si trova. Nella posta, può riassumere una conversazione lunga e proporre una risposta. Nel foglio di calcolo, suggerire formule e grafici. Nell'editor, riscrivere un paragrafo o generare una sezione. Nel sistema di gestione dei clienti, riassumere lo storico di un cliente prima di una chiamata. Il vantaggio principale è il supporto contestuale: l'assistente non deve ricevere le informazioni dalla persona, perché le vede già. Il documento chiede di distinguere anche tra assistenti generalisti, capaci di aiutare in molte attività diverse, e assistenti specializzati, progettati per un dominio o un compito specifico, come il supporto legale, l'assistenza tecnica o la contabilità. I secondi sono spesso più affidabili nel loro ambito, ma meno flessibili. In ogni caso, il termine copilot ricorda il punto essenziale: la responsabilità resta di chi pilota.");
    areaTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMail", head: "Nella posta", body: "Riassume una conversazione, propone una risposta" },
      { icon: "FiGrid", head: "Nel foglio di calcolo", body: "Suggerisce formule e grafici" },
      { icon: "FiEdit3", head: "Nell'editor", body: "Riscrive, genera una sezione" },
      { icon: "FiUsers", head: "Nella gestione clienti", body: "Riassume lo storico prima di una chiamata" },
    ], 2, { y: 1.15, H: 2.3, headSize: 14, bodySize: 12 });
    chip(s, 0.5, 3.65, 4.4, 0.6, "Generalisti: molte attività, più flessibili", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.65, 4.4, 0.6, "Specializzati: un dominio, spesso più affidabili", { fill: C.accent6, fontSize: 12 });
    banner(s, 4.4, "Copilot: affianca e supporta, ma la responsabilità resta di chi pilota.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Suggerire, preparare, eseguire", "La distinzione più importante del sottotema, e una delle domande guida. Un sistema può fare quattro cose diverse, con conseguenze molto diverse. Rispondere: fornisce un'informazione o un contenuto. 'Ecco come si scrive una email di sollecito'. Suggerire: propone un'azione specifica, che la persona decide se compiere. 'Ti suggerisco di inviare un sollecito al cliente Rossi, la fattura è scaduta da trenta giorni'. Preparare: predispone l'azione, pronta per essere completata. 'Ho preparato la bozza del sollecito, la trovi nelle bozze'. Eseguire: compie l'azione. 'Ho inviato il sollecito al cliente Rossi'. L'esempio mostra la differenza: nei primi tre casi, nulla accade nel mondo finché una persona non agisce. Nel quarto, qualcosa è già accaduto: il cliente ha ricevuto l'email, con il tono, il contenuto e gli eventuali errori del sistema. Se la fattura era già stata pagata ieri, il danno alla relazione è fatto. Questa distinzione tornerà nell'11.5 come scala dei livelli di autonomia. Il punto qui è di sapere, davanti a un sistema, che cosa può fare tra queste quattro cose, e quale sta facendo in un dato momento.");
    areaTag(s, 0);
    const a = [["Rispondere", "\"Ecco come si scrive un'email di sollecito.\""], ["Suggerire", "\"Ti suggerisco un sollecito al cliente Rossi: fattura scaduta da 30 giorni.\""], ["Preparare", "\"Ho preparato la bozza del sollecito: la trovi nelle bozze.\""], ["Eseguire", "\"Ho inviato il sollecito al cliente Rossi.\""]];
    a.forEach((e, i) => {
      const y = 1.15 + i * 0.66;
      shapeBox(s, 0.5, y, 9.0, 0.58, i === 3 ? C.accent1 : (i % 2 ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: 0.7, y, w: 1.9, h: 0.58, fontSize: 14, bold: true, color: i === 3 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.6, y, w: 6.7, h: 0.58, fontSize: 12, italic: true, color: i === 3 ? C.background1 : C.text1, valign: "middle" });
    });
    banner(s, 3.9, "Nei primi tre casi nulla accade finché una persona non agisce. Nel quarto, è già accaduto: se la fattura era stata pagata ieri, il danno è fatto.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Capacità e limiti degli assistenti", "Che cosa sanno fare, in concreto, gli assistenti attuali, e dove si fermano? Le capacità dipendono da tre fattori, che vedremo meglio nell'11.2: il modello su cui si basano, gli strumenti a cui hanno accesso, i permessi che hanno ricevuto. Alcuni limiti tipici. L'accesso al contesto è parziale: un assistente integrato nella posta vede le email, ma non necessariamente i documenti condivisi o il gestionale. La memoria tra sessioni è spesso limitata: l'assistente può non ricordare che cosa si è fatto ieri. Le azioni possibili sono definite dagli strumenti disponibili: un assistente che non ha uno strumento per inviare email può prepararle ma non inviarle, anche se nella conversazione sembra capace di farlo. Le capacità dichiarate e quelle reali possono non coincidere: un sistema può rispondere 'fatto' a una richiesta che non era in grado di eseguire, come visto nel Tema 3 per le affermazioni infondate. Quest'ultimo punto merita attenzione: quando un assistente afferma di aver compiuto un'azione, conviene verificare che l'azione sia stata effettivamente compiuta, almeno finché non si conosce bene il sistema. La consapevolezza del sottotema: non tutti gli assistenti AI possono eseguire azioni; occorre distinguere ciò che il sistema può proporre da ciò che può realmente fare.");
    areaTag(s, 0);
    rowsLabel(s, [["Contesto parziale", "Vede la posta, ma non necessariamente i documenti o il gestionale"], ["Memoria limitata", "Può non ricordare che cosa si è fatto ieri"], ["Azioni definite dagli strumenti", "Senza lo strumento per inviare, può preparare ma non inviare"], ["Dichiarato e reale", "Può rispondere 'fatto' a ciò che non era in grado di fare"]], { y: 1.15, h: 0.56, lw: 2.9 });
    banner(s, 3.75, "Quando un assistente dice di aver compiuto un'azione, verificare che sia stata compiuta davvero.", { h: 0.7, fontSize: 14 });
    txt(s, "Capacità = modello + strumenti + permessi (11.2).", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Nomi commerciali e funzionalità", "L'ultimo punto del sottotema: la differenza tra denominazioni commerciali e funzionalità effettive. Il mercato usa termini come assistente, copilot, agente, agente autonomo, lavoratore digitale, in modo non uniforme e spesso promozionale. Lo stesso termine, agente, può indicare un sistema che esegue in autonomia una sequenza complessa di operazioni, oppure un semplice chatbot con una personalità definita. E un prodotto chiamato assistente può avere capacità agentiche avanzate. Per questo, davanti a uno strumento, conviene non fermarsi al nome ma porre alcune domande funzionali. Che cosa può leggere: quali file, applicazioni, dati? Che cosa può modificare o inviare? Lo fa da solo o chiede conferma? Con quali permessi opera: i miei, o altri? Che cosa registra delle operazioni compiute? Che cosa succede se sbaglia: si può annullare? Le risposte a queste domande dicono molto più del nome. Il Tema 4 ha presentato l'ecosistema degli strumenti; qui il documento chiede di evitare un catalogo commerciale e di fornire invece i criteri funzionali per valutarli. Sono le stesse domande che torneranno nei sottotemi successivi.");
    areaTag(s, 0);
    txt(s, "Al posto del nome, sei domande funzionali", { x: 0.5, y: 1.12, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const q = [["FiEye", "Che cosa può leggere?"], ["FiEdit", "Che cosa può modificare o inviare?"], ["FiCheckSquare", "Agisce da solo o chiede conferma?"], ["FiKey", "Con quali permessi opera?"], ["FiList", "Che cosa registra delle operazioni?"], ["FiRotateCcw", "Se sbaglia, si può annullare?"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.55 + row * 0.95;
      shapeBox(s, x, y, 2.86, 0.82, row ? C.accent6 : C.background2, q[i][1]);
      await iconCircle(s, x + 0.15, y + 0.16, 0.5, q[i][0]);
      txt(s, q[i][1], { x: x + 0.78, y, w: 2.0, h: 0.82, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    }
    banner(s, 3.6, "Assistente, copilot, agente, lavoratore digitale: termini non uniformi e spesso promozionali. Le risposte dicono più del nome.", { h: 0.85, fontSize: 13 });
    txt(s, "Criteri funzionali, non un catalogo commerciale.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Non tutti gli assistenti AI possono eseguire azioni: occorre distinguere ciò che il sistema può proporre da ciò che può realmente fare.", "Sottotema 11.1  ·  Dalla conversazione all'azione", "Concetto chiave del primo sottotema. Dai chatbot tradizionali agli assistenti conversazionali, agli assistenti integrati negli strumenti di lavoro, fino ai sistemi che agiscono, le possibilità sono cresciute insieme al raggio delle conseguenze. Rispondere, suggerire, preparare ed eseguire sono quattro cose diverse: solo l'ultima cambia qualcosa nel mondo senza un intervento umano. Le capacità reali dipendono da modello, strumenti e permessi, e vanno valutate con domande funzionali, non dal nome commerciale. Esercizio suggerito: prendere gli assistenti AI disponibili in azienda e compilare per ciascuno una scheda con le sei domande funzionali.");

  // =====================================================================
  section("11.2 Strumenti e integrazioni");
  divider("11.2", "Strumenti, integrazioni e capacità operative", "La capacità di compiere operazioni dipende da strumenti e permessi disponibili, non solo dal modello", "Che cosa permette a un sistema AI di passare dalla risposta all'azione? Gli strumenti. In questo sottotema, da comprendere, vediamo la differenza tra un modello AI e un sistema dotato di strumenti, i tipi di operazioni che gli strumenti permettono, la distinzione tra operazioni che leggono e operazioni che modificano, e il tema centrale delle autorizzazioni: con quale identità e con quali permessi agisce il sistema. Le API e i protocolli tecnici con cui gli strumenti vengono collegati sono solo da accennare; le architetture di integrazione aziendale appartengono al Tema 14.");
  {
    const s = content("Modello e sistema con strumenti", "Una distinzione fondamentale. Un modello linguistico, da solo, può soltanto produrre testo: riceve un testo e genera un testo. Non può leggere un file che non gli viene fornito, cercare sul web, consultare un database, inviare un'email. Tutto ciò che sembra 'fare' è in realtà testo generato. Un sistema dotato di strumenti è un'applicazione che collega il modello a funzioni software esterne. Il modello, quando lo ritiene utile, produce una richiesta strutturata di usare uno strumento, per esempio 'cerca nel calendario gli impegni di martedì'. L'applicazione esegue davvero l'operazione e restituisce il risultato al modello, che lo usa per proseguire. Lo schema in slide mostra il ciclo. Il punto da cogliere è che il modello decide quale strumento usare e con quali parametri, ma è l'applicazione a eseguire l'operazione, con i permessi che le sono stati concessi. Ne derivano due conseguenze. Le capacità operative non dipendono solo da quanto è 'intelligente' il modello, ma da quali strumenti sono collegati. E i rischi operativi non dipendono solo dagli errori del modello, ma da che cosa gli strumenti permettono di fare. Per il relatore, se emerge una domanda tecnica: per collegare gli strumenti ai modelli si stanno diffondendo protocolli standard, il più noto dei quali è il Model Context Protocol (MCP), proposto da Anthropic nel 2024 e adottato da molti fornitori; non serve approfondirlo, ma è utile sapere che un nuovo collegamento significa nuove capacità e nuovi permessi da valutare. Informazione citata a memoria: da verificare prima della sessione.");
    areaTag(s, 0);
    const b = [["Modello", "Decide quale strumento usare e come", C.accent6, C.text1], ["Applicazione", "Esegue davvero l'operazione, con i permessi concessi", C.accent1, C.background1], ["Strumenti", "Calendario, posta, file, database, web", C.background2, C.text1]];
    b.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 1.6, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.3, w: 2.56, h: 0.42, fontSize: 17, bold: true, color: e[3], align: "center" });
      txt(s, e[1], { x: x + 0.15, y: 1.8, w: 2.56, h: 0.9, fontSize: 12, color: e[3], align: "center" });
      if (i < 2) arrow(s, x + 2.88, 1.85, 0.17);
    });
    txt(s, "Il risultato torna al modello, che prosegue", { x: 0.5, y: 2.9, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2, align: "center" });
    await card(s, 0.5, 3.35, 4.35, 1.6, { icon: "FiTool", inline: true, head: "Le capacità operative", headSize: 14, bodySize: 12, body: "Dipendono da quali strumenti sono collegati, non solo dal modello." });
    await card(s, 5.15, 3.35, 4.35, 1.6, { icon: "FiAlertTriangle", inline: true, head: "I rischi operativi", headSize: 14, bodySize: 12, fill: C.accent6, iconBg: C.accent5, body: "Dipendono da che cosa gli strumenti permettono di fare." });
  }
  {
    const s = content("Che cosa possono fare gli strumenti", "Il sottotema elenca le principali capacità che gli strumenti aggiungono. Accedere a file: leggere documenti, fogli di calcolo, presentazioni in una cartella o in un archivio. Accedere ad applicazioni e servizi esterni: posta, calendario, sistemi di gestione dei clienti, gestionali, piattaforme di collaborazione. Usare funzioni software: eseguire codice per calcoli, come visto nel Tema 9, convertire formati, generare grafici. Cercare informazioni: sul web, in un archivio documentale, in un database. Scrivere: creare o modificare documenti, aggiornare record, inviare messaggi, creare eventi in calendario. Interagire con applicazioni aziendali: aprire una pratica, aggiornare lo stato di un ordine, registrare un'attività. Alcuni sistemi possono anche usare il computer come una persona, guardando lo schermo e cliccando, o navigare su siti web compilando moduli. Per l'utente, la conseguenza pratica è che lo stesso assistente può avere capacità molto diverse a seconda della configurazione: in un'azienda può solo leggere la posta, in un'altra inviare email, aggiornare il gestionale e creare ordini. Conoscere quali strumenti sono abilitati è il primo passo per usarlo bene.");
    areaTag(s, 0);
    await iconGrid(s, [
      { icon: "FiFolder", head: "File", body: "Documenti, fogli di calcolo, presentazioni" },
      { icon: "FiGlobe", head: "Applicazioni e servizi", body: "Posta, calendario, gestione clienti, gestionali" },
      { icon: "FiCpu", head: "Funzioni software", body: "Codice, conversioni, grafici" },
      { icon: "FiSearch", head: "Ricerca", body: "Web, archivi documentali, database" },
      { icon: "FiEdit", head: "Scrittura", body: "Documenti, record, messaggi, eventi" },
      { icon: "FiMonitor", head: "Uso del computer", body: "Guardare lo schermo, cliccare, compilare" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Lo stesso assistente può solo leggere in un'azienda, e inviare, aggiornare e ordinare in un'altra.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Leggere o modificare", "La distinzione operativa più importante del sottotema: tra operazioni informative e operazioni che modificano dati. Le operazioni informative leggono e cercano: consultare un documento, cercare un'email, leggere i dati di un cliente, controllare la disponibilità in magazzino. Non cambiano nulla nel mondo. Il loro rischio principale riguarda l'accesso, cioè quali informazioni il sistema può vedere, e l'uso che ne fa, per esempio includendole in una risposta a chi non dovrebbe vederle. Le operazioni che modificano scrivono, aggiornano, inviano, cancellano: modificare un documento condiviso, aggiornare un prezzo nel gestionale, inviare un'email a un cliente, cancellare un evento, creare un ordine, effettuare un pagamento. Cambiano qualcosa nel mondo, e il loro rischio riguarda le conseguenze di un'azione sbagliata. Tra le operazioni che modificano, conviene distinguere ulteriormente quelle facilmente reversibili, come una bozza salvata, da quelle difficili o impossibili da annullare, come un'email inviata o un pagamento eseguito, che vedremo nell'11.5. Molte organizzazioni iniziano abilitando solo operazioni informative, e introducono gradualmente quelle che modificano, con controlli adeguati.");
    areaTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiEye", head: "Operazioni informative", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Leggere, cercare, consultare", "Non cambiano nulla nel mondo", "Rischio: accesso e uso delle informazioni"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiEdit", head: "Operazioni che modificano", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Scrivere, aggiornare, inviare, cancellare", "Cambiano qualcosa nel mondo", "Rischio: conseguenze di un'azione sbagliata"], { space: 5 }) });
    chip(s, 5.15, 3.85, 2.1, 0.55, "Reversibili: una bozza", { fill: C.background2, fontSize: 11 });
    chip(s, 7.4, 3.85, 2.1, 0.55, "Irreversibili: un invio", { fill: C.accent5, color: C.background1, fontSize: 11 });
    txt(s, "Spesso si parte dalle sole operazioni informative, e si introducono gradualmente le altre con controlli adeguati.", { x: 0.5, y: 3.85, w: 4.4, h: 0.9, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Identità, autorizzazioni, permessi", "Quando un sistema AI agisce su un'applicazione, lo fa con una certa identità e con certi permessi. È un tema centrale, che il documento chiede di comprendere senza entrare negli aspetti tecnici. Ci sono due modelli principali. Nel primo, il sistema agisce a nome dell'utente, con i suoi permessi: può vedere e fare ciò che può vedere e fare la persona che lo usa. Se l'utente può leggere tutti i contratti, anche l'assistente può. Nel secondo, il sistema agisce con un'identità propria, un account di servizio, con permessi definiti appositamente, che possono essere più ampi o più ristretti di quelli dell'utente. Entrambi i modelli pongono domande. Nel primo: è opportuno che l'assistente possa fare tutto ciò che posso fare io, anche in automatico, anche senza che io lo veda? Nel secondo: chi ha definito i permessi, e chi risponde delle azioni? Un principio di buona pratica, noto in sicurezza informatica come principio del privilegio minimo: concedere a un sistema solo i permessi strettamente necessari per il compito. Un assistente che deve riassumere le email non ha bisogno di poterle inviare o cancellare. La trattazione approfondita della sicurezza appartiene al Tema 17.");
    areaTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiUser", head: "A nome dell'utente", headSize: 15, bodySize: 12,
      body: bullets(["Vede e fa ciò che può la persona", "È opportuno che lo faccia anche in automatico?"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiServer", head: "Con un'identità propria", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Account di servizio con permessi dedicati", "Chi li ha definiti? Chi risponde delle azioni?"], { space: 5 }) });
    shapeBox(s, 0.5, 3.7, 9.0, 1.25, C.text1, "privilegio minimo");
    txt(s, "Principio del privilegio minimo", { x: 0.75, y: 3.78, w: 8.5, h: 0.38, fontSize: 15, bold: true, color: C.accent6 });
    txt(s, "Solo i permessi strettamente necessari. Un assistente che riassume le email non ha bisogno di poterle inviare o cancellare.", { x: 0.75, y: 4.18, w: 8.5, h: 0.7, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Disponibile non è autorizzato", "Una distinzione che il sottotema chiede di rendere esplicita: la disponibilità di uno strumento non equivale all'autorizzazione a utilizzarlo. Che un sistema abbia tecnicamente accesso a un'applicazione non significa che sia opportuno, consentito o sicuro usarla per un certo compito. Alcuni esempi. Un assistente collegato alla posta può tecnicamente inviare email a qualsiasi indirizzo, ma la politica aziendale può prevedere che le comunicazioni ai clienti passino per una revisione. Un agente con accesso al gestionale può modificare i prezzi, ma questa operazione richiede di regola l'approvazione di un responsabile. Uno strumento di ricerca web può raggiungere qualsiasi sito, ma alcuni contenuti non dovrebbero essere scaricati o usati. Un sistema che legge tutti i documenti condivisi può includere in una risposta informazioni riservate a cui l'utente che pone la domanda non dovrebbe accedere. In tutti questi casi, il limite non è tecnico ma organizzativo: regole su chi può fare che cosa, in quali condizioni, con quali approvazioni. Queste regole devono valere anche per i sistemi AI, e spesso vanno tradotte in limiti tecnici espliciti, perché il sistema non le conosce se non gli vengono imposte.");
    areaTag(s, 0);
    table(s, [["Disponibile tecnicamente", "Ma le regole prevedono"],
      ["Inviare email a qualsiasi indirizzo", "Revisione delle comunicazioni ai clienti"],
      ["Modificare i prezzi nel gestionale", "Approvazione di un responsabile"],
      ["Raggiungere qualsiasi sito", "Limiti su contenuti e fonti"],
      ["Leggere tutti i documenti condivisi", "Riservatezza verso chi pone la domanda"]],
      { y: 1.15, colW: [4.5, 4.5], rowH: 0.48, fontSize: 13, blankCorner: false, accentCol: 1 });
    banner(s, 3.75, "Il limite non è tecnico ma organizzativo. Le regole valgono anche per l'AI, e spesso vanno tradotte in limiti tecnici espliciti.", { h: 0.85, fontSize: 13 });
    txt(s, "Il sistema non conosce le regole aziendali se non gli vengono imposte.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Il contesto disponibile", "L'ultimo punto del sottotema: l'importanza del contesto e delle informazioni disponibili. Un sistema che agisce prende decisioni, e la qualità delle decisioni dipende dalle informazioni che ha. Un assistente che deve rispondere a un cliente sa che il cliente ha già chiamato due volte questa settimana? Che ha un reclamo aperto? Che è un cliente strategico? Un agente che deve riprogrammare una riunione sa che uno dei partecipanti è in ferie, o che la riunione era stata già spostata due volte? Le persone portano in ogni azione una grande quantità di contesto implicito, spesso senza rendersene conto: conoscono le persone, la storia, le priorità non scritte, le sensibilità. Un sistema AI ha solo il contesto che gli è stato reso accessibile attraverso gli strumenti e le istruzioni. Quando il contesto manca, il sistema non si ferma: agisce con le informazioni che ha, in modo plausibile ma potenzialmente inappropriato. È lo stesso fenomeno visto nel Tema 3, il sistema che riempie i vuoti, con la differenza che qui non produce una frase sbagliata ma un'azione sbagliata. Per questo, prima di affidare un'azione a un sistema, conviene chiedersi: ha le informazioni che userei io per decidere?");
    areaTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.6, "Che cosa sa una persona", "Il cliente ha già chiamato due volte, ha un reclamo aperto, è strategico. Un partecipante è in ferie.", { fontSize: 12, fill: C.accent6 });
    docBox(s, 5.15, 1.15, 4.35, 1.6, "Che cosa sa il sistema", "Solo ciò che gli è reso accessibile attraverso strumenti e istruzioni.", { fontSize: 12 });
    banner(s, 2.95, "Quando il contesto manca, il sistema non si ferma: agisce in modo plausibile ma potenzialmente inappropriato.", { h: 0.8, fontSize: 13 });
    shapeBox(s, 0.5, 3.95, 9.0, 0.95, C.accent6, "domanda");
    txt(s, [{ text: "Prima di affidare un'azione: ", options: { bold: true, color: C.accent1 } }, { text: "il sistema ha le informazioni che userei io per decidere?", options: { color: C.text1 } }], { x: 0.7, y: 3.95, w: 8.6, h: 0.95, fontSize: 15, valign: "middle" });
  }
  keySlide("La capacità di compiere operazioni dipende dagli strumenti e dai permessi realmente disponibili, non soltanto dalle capacità del modello linguistico.", "Sottotema 11.2  ·  Strumenti, integrazioni e capacità operative", "Concetto chiave del sottotema 11.2. Un modello da solo produce testo; un sistema con strumenti legge file, cerca, scrive, invia, aggiorna applicazioni. Le operazioni informative e quelle che modificano hanno rischi diversi. Il sistema agisce con un'identità e dei permessi, che vanno limitati al necessario. La disponibilità tecnica di uno strumento non equivale all'autorizzazione a usarlo, e le regole aziendali vanno imposte esplicitamente. Le decisioni del sistema sono buone quanto il contesto che ha a disposizione. Esercizio suggerito: per un'attività concreta che si vorrebbe affidare a un assistente, elencare gli strumenti necessari, distinguere le operazioni informative da quelle che modificano, e definire i permessi minimi.");
