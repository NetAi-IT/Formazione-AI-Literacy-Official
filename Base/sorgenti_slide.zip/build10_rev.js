const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 10: AI multimodale e creazione di contenuti";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 10  ·  AI multimodale e creazione di contenuti";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function opTag(s, active) {
    const st = ["Interpretare", "Generare", "Trasformare"];
    const act = Array.isArray(active) ? active : [active];
    st.forEach((t, i) => {
      const x = 6.62 + i * 0.97, on = act.indexOf(i) >= 0;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.92, h: 0.26, rectRadius: 0.13, fill: { color: on ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "operazione " + t });
      txt(s, t, { x, y: 0.42, w: 0.92, h: 0.26, fontSize: 9, bold: true, color: on ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1, italic: !!o.italic });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, 0.5, y, 9.0, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: 0.7 + lw, y, w: 8.6 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }

  // ===================== REVISIONE 16 OTTOBRE 2026 =====================
  // Helper aggiuntivo: illustrazione schematica per l'esempio di generazione immagini
  function scene(s, x, y, w, h, v) {
    const P = v === 1
      ? { bg: "FCE7B2", rack: "D9480F", box: "1C7ED6", box2: "37B24D", fork: "F08C00", floor: "C92A2A" }
      : { bg: "F2F3F5", rack: "5B6573", box: "8A939E", box2: "2E7D7A", fork: "2E7D7A", floor: "8A939E" };
    s.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: P.bg }, line: { color: "D5D9DE", width: 0.75 }, objectName: "sfondo illustrazione " + v });
    s.addShape(pres.shapes.RECTANGLE, { x: x + 0.08, y: y + h * 0.86, w: w - 0.16, h: 0.035, fill: { color: P.floor }, line: { type: "none" }, objectName: "pavimento" });
    const rackW = v === 1 ? 0.5 : 0.36, gap = v === 1 ? 0.12 : 0.08;
    const sx = v === 1 ? x + 0.18 : x + w * 0.4;
    const top = y + 0.22, rh = h * 0.86 - 0.22;
    for (let r = 0; r < 3; r++) {
      const rx = sx + r * (rackW + gap);
      s.addShape(pres.shapes.RECTANGLE, { x: rx, y: top, w: 0.035, h: rh, fill: { color: P.rack }, line: { type: "none" }, objectName: "montante" });
      s.addShape(pres.shapes.RECTANGLE, { x: rx + rackW - 0.035, y: top, w: 0.035, h: rh, fill: { color: P.rack }, line: { type: "none" }, objectName: "montante" });
      for (let l = 0; l < 3; l++) {
        const ly = top + 0.12 + l * (rh / 3);
        s.addShape(pres.shapes.RECTANGLE, { x: rx, y: ly + rh / 3 - 0.16, w: rackW, h: 0.03, fill: { color: P.rack }, line: { type: "none" }, objectName: "ripiano" });
        if ((r + l) % 3 !== 1) s.addShape(pres.shapes.RECTANGLE, { x: rx + 0.07, y: ly + rh / 3 - 0.16 - 0.2, w: rackW * 0.36, h: 0.2, fill: { color: (r + l) % 2 ? P.box : P.box2 }, line: { type: "none" }, objectName: "scatola" });
        if ((r + l) % 2 === 0) s.addShape(pres.shapes.RECTANGLE, { x: rx + rackW * 0.52, y: ly + rh / 3 - 0.16 - 0.15, w: rackW * 0.3, h: 0.15, fill: { color: P.box }, line: { type: "none" }, objectName: "scatola" });
      }
    }
    const k = v === 1 ? 1 : 0.8;
    const fx = v === 1 ? x + w - 0.78 : x + w - 0.62, fb = y + h * 0.86;
    s.addShape(pres.shapes.RECTANGLE, { x: fx + 0.1 * k, y: fb - 0.38 * k, w: 0.42 * k, h: 0.28 * k, fill: { color: P.fork }, line: { type: "none" }, objectName: "carrello" });
    s.addShape(pres.shapes.RECTANGLE, { x: fx + 0.22 * k, y: fb - 0.58 * k, w: 0.2 * k, h: 0.2 * k, fill: { type: "none" }, line: { color: P.fork, width: 1.5 }, objectName: "cabina" });
    s.addShape(pres.shapes.RECTANGLE, { x: fx + 0.04 * k, y: fb - 0.7 * k, w: 0.04 * k, h: 0.62 * k, fill: { color: P.rack }, line: { type: "none" }, objectName: "montante carrello" });
    s.addShape(pres.shapes.RECTANGLE, { x: fx - 0.16 * k, y: fb - 0.12 * k, w: 0.22 * k, h: 0.03, fill: { color: P.rack }, line: { type: "none" }, objectName: "forche" });
    s.addShape(pres.shapes.OVAL, { x: fx + 0.14 * k, y: fb - 0.13 * k, w: 0.13 * k, h: 0.13 * k, fill: { color: "22262B" }, line: { type: "none" }, objectName: "ruota" });
    s.addShape(pres.shapes.OVAL, { x: fx + 0.38 * k, y: fb - 0.13 * k, w: 0.13 * k, h: 0.13 * k, fill: { color: "22262B" }, line: { type: "none" }, objectName: "ruota" });
    if (v === 1) {
      s.addShape(pres.shapes.RECTANGLE, { x: sx + 0.06, y: top + 0.02, w: 0.42, h: 0.17, fill: { color: "FFFFFF" }, line: { color: "C92A2A", width: 0.75 }, objectName: "scritta inventata" });
      txt(s, "ZXQ-7", { x: sx + 0.06, y: top + 0.02, w: 0.42, h: 0.17, fontSize: 7, bold: true, color: "C92A2A", align: "center", valign: "middle" });
    } else {
      s.addShape(pres.shapes.RECTANGLE, { x: x + 0.15, y: y + 0.3, w: w * 0.3, h: h * 0.45, fill: { type: "none" }, line: { color: "8A939E", width: 1, dashType: "dash" }, objectName: "spazio titolo" });
      txt(s, "Spazio per il titolo", { x: x + 0.15, y: y + 0.3, w: w * 0.3, h: h * 0.45, fontSize: 8, italic: true, color: C.text2, align: "center", valign: "middle" });
    }
  }
  // Helper: miniatura di slide per l'esempio documento-presentazione
  function thumb(s, x, y, w, h, label, title) {
    s.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: C.background1 }, line: { color: C.accent3, width: 1 }, shadow: { type: "outer", blur: 2, offset: 1, angle: 45, color: "000000", opacity: 0.12 }, objectName: "miniatura " + label });
    s.addShape(pres.shapes.RECTANGLE, { x, y, w: 0.07, h, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "barra miniatura" });
    txt(s, label, { x: x + 0.2, y: y + 0.08, w: 1.9, h: 0.24, fontSize: 9, bold: true, color: C.accent2 });
    txt(s, title, { x: x + 0.2, y: y + 0.32, w: 1.9, h: h - 0.4, fontSize: 12, bold: true, color: C.text1 });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 10", { placeholder: "kicker" });
    s.addText("AI multimodale e creazione di contenuti", { placeholder: "title" });
    s.addText([{ text: "Area: Esplorare le possibilità dell'AI", options: { breakLine: true } }, { text: "Contenuti aggiornati a ottobre 2026", options: { fontSize: 12 } }], { placeholder: "sub" });
    s.addNotes("Benvenuti al decimo tema, il terzo dell'area 'Esplorare le possibilità dell'AI'. Nel Tema 8 abbiamo lavorato su testi e documenti, nel Tema 9 sui dati. Qui allarghiamo lo sguardo alle altre forme in cui le informazioni si presentano: immagini, audio, video, e i materiali di comunicazione che le combinano, come le presentazioni. I sistemi AI attuali non lavorano più solo con il testo: leggono una schermata, descrivono una fotografia, trascrivono e riassumono una riunione, generano un'illustrazione o un breve video, trasformano un documento in slide. Sono possibilità che cambiano molte attività quotidiane: assistenza tecnica, comunicazione, marketing, formazione, accessibilità. Il filo del modulo è pratico: che cosa si può fare, come ottenere buoni risultati, e quali attenzioni permettono di usare questi strumenti con fiducia. Tra queste, una è nuova e importante: un contenuto può essere molto realistico senza essere autentico. Il punto di vista resta quello di chi usa gli strumenti: non entriamo nelle architetture dei modelli né nella produzione audiovisiva professionale. Suggerimento per l'apertura: mostrare due immagini, una fotografia reale e una generata, e chiedere ai partecipanti di indovinare quale sia quale; poi mostrare come la stessa immagine generata possa essere modificata in pochi secondi. Usare immagini prive di persone reali riconoscibili o di marchi. Nota per il relatore: contenuti verificati a ottobre 2026, compresi gli obblighi di trasparenza dell'articolo 50 dell'AI Act; le capacità di generazione di immagini, voci e video evolvono molto rapidamente, quindi esempi, dimostrazioni e riferimenti normativi vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo è conoscere le principali possibilità dell'AI multimodale nell'interpretare, generare e trasformare contenuti visivi, sonori e audiovisivi, e saperle usare nel lavoro con risultati affidabili. Le possibilità sono concrete: mostrare una schermata invece di descriverla, ottenere un verbale da una registrazione, creare illustrazioni e varianti per un materiale formativo, trasformare un documento in una presentazione, produrre sottotitoli e versioni audio che rendono i contenuti accessibili. La consapevolezza che accompagna queste possibilità ha tre parti, che riprenderemo nel modulo senza ripeterle a ogni slide. Primo: un contenuto realistico non è necessariamente autentico, quindi provenienza e contesto contano. Secondo: ogni passaggio tra modalità può perdere o alterare informazioni, e un controllo mirato sugli elementi critici permette di sfruttare il risparmio di tempo senza rinunciare all'affidabilità. Terzo: le capacità dipendono dallo strumento e cambiano rapidamente, quindi vanno verificate sugli strumenti autorizzati, non dedotte dall'etichetta 'multimodale'. Il messaggio centrale del tema: l'AI multimodale amplia il modo in cui comprendiamo, creiamo e trasformiamo contenuti; usata con criterio, fa risparmiare tempo e rende la comunicazione più chiara e inclusiva.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Conoscere che cosa l'AI sa fare con immagini, audio e video", "Applicarla a casi concreti: assistenza, verbali, comunicazione, formazione", "Ottenere risultati affidabili con controlli proporzionati"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Realismo, autenticità e accuratezza sono cose diverse.\n\nNelle trasformazioni si controllano gli elementi critici, non tutto.\n\nLe capacità dipendono dallo strumento e crescono rapidamente." });
  }
  {
    const s = content("Il filo conduttore", "Il tema è organizzato in quattro passaggi. Comprendere le modalità: che cosa significa multimodalità, nel sottotema 10.1. Interpretare e generare contenuti nelle diverse modalità: immagini, audio, video e materiali di comunicazione, dal 10.2 al 10.6. Trasformare e combinare, cioè passare da una modalità all'altra conservando significato e utilità, nel 10.7. Valutare i risultati: autenticità, accuratezza, provenienza e trasparenza, nel 10.8. Trasversale a tutto il tema c'è la distinzione tra tre operazioni: interpretare un contenuto, cioè comprenderlo e descriverlo; generarne uno nuovo; trasformarlo da una forma all'altra. Ciascuna porta un valore preciso e richiede un'attenzione specifica. Interpretare fa risparmiare tempo nel capire schermate, foto e registrazioni; l'attenzione va agli errori di riconoscimento su dettagli e numeri. Generare permette di creare illustrazioni, voci e video in tempi brevi; l'attenzione va alla differenza tra realistico e autentico. Trasformare rende i contenuti più accessibili e riutilizzabili; l'attenzione va alle informazioni che si perdono o cambiano nel passaggio. Nelle slide, un indicatore in alto a destra ricorda di quale operazione si sta parlando.");
    const d = [["FiLayers", "Comprendere le modalità", "10.1"], ["FiImage", "Interpretare e generare", "10.2  10.3  10.4  10.5  10.6"], ["FiRepeat", "Trasformare e combinare", "10.7"], ["FiShield", "Valutare i risultati", "10.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.0, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.25, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.0, w: 1.9, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.65, w: 1.9, h: 0.4, fontSize: 11, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 1.95, 0.17);
    }
    txt(s, "Tre operazioni trasversali: che cosa offrono, a che cosa fare attenzione", { x: 0.5, y: 3.3, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    const o = [["Interpretare", "Capire foto, schermate, audio in pochi secondi", "Errori di riconoscimento"], ["Generare", "Immagini, voci e video in tempi brevi", "Realistico non è autentico"], ["Trasformare", "Contenuti accessibili e riutilizzabili", "Informazioni perse o alterate"]];
    o.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 3.7, 2.86, 1.25, C.accent6, e[0]);
      txt(s, e[0], { x: x + 0.15, y: 3.76, w: 2.56, h: 0.34, fontSize: 15, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 4.1, w: 2.56, h: 0.42, fontSize: 11, color: C.text1 });
      txt(s, [{ text: "Attenzione: ", options: { bold: true, color: C.accent5 } }, { text: e[2], options: { color: C.text2 } }], { x: x + 0.15, y: 4.55, w: 2.56, h: 0.32, fontSize: 11 });
    });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, il video, con priorità media. Vanno compresi e sperimentati: interpretazione di immagini, generazione e modifica visiva, trascrizione, interazione vocale e trasformazioni tra modalità. Vanno conosciuti: generazione video, presentazioni, accessibilità, autenticità, provenienza e trasparenza. Vanno solo accennati: architetture multimodali, modelli di diffusione, editing professionale, produzione audiovisiva specialistica e verifica forense tecnica. Tre sottotemi contengono un esempio dimostrativo fittizio: la generazione e modifica di un'immagine nel 10.3, il passaggio dalla riunione al verbale nel 10.4, il passaggio dal documento alle slide nel 10.6. Confini con gli altri temi: non ripetiamo i meccanismi del Tema 2, la teoria degli errori del Tema 3, i confronti tra strumenti del Tema 4, le tecniche di prompting del Tema 6, la metodologia di verifica del Tema 7. Il confine più importante è con il Tema 8: lì la conoscenza contenuta nei documenti, qui le modalità visive, sonore e audiovisive. I workflow automatizzati appartengono al Tema 11; gli obblighi giuridici sono approfonditi nei Temi 17 e 18. Un'avvertenza pratica, valida per tutto il modulo: immagini, registrazioni e video aziendali possono contenere dati personali o riservati, e vanno caricati solo negli strumenti autorizzati.");
    pathSlide(s, [["10.1", "Fondamenti dell'AI multimodale", "Alta"], ["10.2", "Comprensione delle immagini", "Alta"], ["10.3", "Generazione e modifica delle immagini", "Alta"], ["10.4", "Audio, voce e parlato", "Alta"], ["10.5", "Comprensione e generazione video", "Media"], ["10.6", "Presentazioni e comunicazione", "Alta"], ["10.7", "Trasformazioni tra modalità", "Alta"], ["10.8", "Limiti, autenticità, affidabilità", "Alta"]],
      [["Comprendere e sperimentare", "Interpretare immagini, generare e modificare, trascrivere, voce, trasformazioni", C.accent1, C.background1], ["Conoscere", "Video, presentazioni, accessibilità, autenticità, provenienza, trasparenza", C.accent6, C.text1], ["Solo accennare", "Architetture, modelli di diffusione, editing professionale, verifica forense", C.background2, C.text1]]);
  }

  // =====================================================================
  section("10.1 Fondamenti");
  divider("10.1", "Fondamenti dell'AI multimodale", "Testo, immagini, audio e video combinati in un'unica interazione: le capacità effettive dipendono dal sistema", "Partiamo dai concetti. Che cosa significa che un sistema AI è multimodale? Quali sono le modalità, che cosa vuol dire comprenderle o generarle, e perché il valore maggiore nasce quando si combinano? In questo sottotema, da comprendere, costruiamo il vocabolario per tutto il modulo. Senza entrare nelle architetture, vedremo una distinzione utile: quella tra un modello che elabora più modalità e un'applicazione che collega più modelli specializzati. Spiega perché due strumenti entrambi 'multimodali' possono offrire risultati diversi. Concetto chiave: la multimodalità può essere realizzata con architetture differenti, e capacità effettive e modalità supportate dipendono dal sistema impiegato. Esercizio suggerito: con lo strumento autorizzato in azienda, fornire la stessa informazione in tre modalità diverse, per esempio una tabella scritta, una sua fotografia e una lettura ad alta voce, e confrontare le risposte.");
  {
    const s = content("Che cosa significa multimodale", "Una modalità è una forma in cui l'informazione si presenta: testo, immagini, audio, video. Gli esseri umani sono naturalmente multimodali: in una riunione ascoltiamo le parole, guardiamo le slide, osserviamo le espressioni, leggiamo gli appunti, e integriamo tutto in una comprensione unica. I primi sistemi di AI generativa erano essenzialmente testuali. Un sistema multimodale può ricevere e, in molti casi, produrre informazioni in più modalità: può ricevere una fotografia e una domanda scritta, una registrazione, una schermata, e rispondere con un testo, un'immagine, una voce. Le quattro modalità principali sono quelle in slide. Il testo, che resta la modalità centrale e spesso il ponte tra le altre. Le immagini: fotografie, illustrazioni, diagrammi, schermate, documenti scansionati. L'audio: parlato, musica, suoni. Il video: immagini nel tempo, spesso con audio. Il punto più importante è nella riga in basso: la multimodalità permette di combinare informazioni di natura diversa in un'unica richiesta, come facciamo noi. Una foto, una domanda e un documento di riferimento possono stare nella stessa interazione. Un sistema può gestire molto bene alcune modalità e meno bene altre: anche questo va verificato sullo strumento.");
    opTag(s, -1);
    const m = [["FiType", "Testo", "La modalità centrale, spesso il ponte tra le altre"], ["FiImage", "Immagini", "Fotografie, illustrazioni, diagrammi, schermate, scansioni"], ["FiMic", "Audio", "Parlato, musica, suoni"], ["FiFilm", "Video", "Immagini nel tempo, spesso con audio"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.4, i === 0 ? C.accent6 : C.background2, m[i][1]);
      await iconCircle(s, x + 0.68, 1.3, 0.8, m[i][0]);
      txt(s, m[i][1], { x: x + 0.1, y: 2.2, w: 1.95, h: 0.42, fontSize: 17, bold: true, color: C.text1, align: "center" });
      txt(s, m[i][2], { x: x + 0.15, y: 2.65, w: 1.85, h: 0.8, fontSize: 11, color: C.text2, align: "center" });
    }
    banner(s, 3.8, "Il valore nasce dalla combinazione: una foto, una domanda e un documento nella stessa richiesta, come facciamo noi in una riunione.", { h: 0.7, fontSize: 13 });
    txt(s, "Un sistema può gestire molto bene alcune modalità e meno bene altre.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Mostrare invece di descrivere", "Confrontiamo, dal punto di vista di chi lo usa, un sistema solo testuale con uno multimodale. Con un sistema testuale, per chiedere aiuto su un errore bisogna descriverlo a parole; per analizzare un grafico bisogna trascriverne i valori; per riassumere una riunione bisogna prima averla trascritta. Con un sistema multimodale si mostra direttamente ciò che si ha davanti, e si possono combinare più elementi nella stessa richiesta. Gli esempi in tabella vengono dal lavoro quotidiano. Una schermata di errore con la domanda 'che cosa devo fare?'. La foto della lavagna di una riunione, che diventa un elenco di azioni. La foto di un componente guasto insieme al manuale caricato, per identificarlo e trovare la procedura di sostituzione. La registrazione di una riunione insieme alle slide proiettate, per un verbale che collega ciò che è stato detto a ciò che è stato mostrato. L'interazione diventa più naturale e più rapida, e diventano possibili compiti che prima richiedevano molto lavoro di preparazione. Due cose da sapere, che riprenderemo nei sottotemi. Il sistema interpreta al posto nostro ciò che è rilevante e può collegare male elementi diversi, per esempio attribuire a una slide un commento detto su un'altra. E una schermata o una foto può contenere più informazioni di quelle che si intende condividere, come nomi in un'altra finestra o documenti sulla scrivania: conviene ritagliare prima di caricare.");
    opTag(s, [0, 2]);
    table(s, [["Compito", "Solo testo", "Multimodale"],
      ["Un errore a schermo", "Descriverlo a parole", "Schermata + 'che cosa devo fare?'"],
      ["Appunti alla lavagna", "Ricopiarli", "Foto: diventa un elenco di azioni"],
      ["Un componente guasto", "Cercare codice e manuale", "Foto + manuale: la procedura"],
      ["Una riunione da riassumere", "Trascriverla prima", "Registrazione + slide: il verbale"]],
      { y: 1.15, colW: [2.6, 2.6, 3.8], rowH: 0.44, fontSize: 12, accentCol: 2, blankCorner: false });
    await card(s, 0.5, 3.6, 4.35, 1.35, { icon: "FiZap", inline: true, head: "Il vantaggio", headSize: 14, bodySize: 12, fill: C.accent6, body: "Più naturale e rapido; compiti prima troppo onerosi." });
    await card(s, 5.15, 3.6, 4.35, 1.35, { icon: "FiCrop", inline: true, head: "Da sapere", headSize: 14, bodySize: 12, body: "Il sistema interpreta e collega: ritagliare ciò che si mostra." });
  }
  {
    const s = content("Comprendere e generare", "Una distinzione fondamentale: comprendere e generare. Comprendere una modalità significa ricevere un contenuto in quella forma ed estrarne informazioni: descrivere un'immagine, trascrivere un audio, riassumere un video. Generare significa produrre un contenuto in quella forma: creare un'immagine, sintetizzare una voce, produrre un video. Le due capacità sono indipendenti: un sistema può comprendere bene le immagini senza saperle generare, o generare audio senza comprenderlo. La tabella incrocia modalità e capacità con esempi concreti. La terza operazione, la trasformazione, combina le prime due: si comprende un contenuto in una modalità e se ne genera uno in un'altra, come da un audio a una trascrizione, da un testo a un'immagine, da un documento a una presentazione. Sono le tre operazioni del filo conduttore, ciascuna con il suo valore e la sua attenzione specifica.");
    opTag(s, [0, 1]);
    table(s, [["Modalità", "Comprendere", "Generare"],
      ["Immagini", "Descrivere una foto, leggere una schermata", "Creare un'illustrazione, modificare una foto"],
      ["Audio", "Trascrivere una riunione, riconoscere il parlato", "Sintetizzare una voce, leggere un testo"],
      ["Video", "Riassumere un filmato, individuare eventi", "Produrre un'animazione o un video formativo"]],
      { y: 1.15, colW: [1.8, 3.6, 3.6], rowH: 0.5, fontSize: 12, blankCorner: false });
    shapeBox(s, 0.5, 3.35, 9.0, 0.85, C.accent6, "trasformare");
    txt(s, [{ text: "Trasformare ", options: { bold: true, color: C.accent1 } }, { text: "combina le due: comprendere in una modalità e generare in un'altra. Audio in testo, testo in immagine, documento in slide.", options: { color: C.text1 } }], { x: 0.7, y: 3.35, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
    txt(s, "Le capacità sono indipendenti: si può comprendere una modalità senza saperla generare, e viceversa.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Un modello o più modelli?", "Una distinzione da introdurre in modo semplice, senza entrare nelle architetture. Un modello multimodale nativo è addestrato per elaborare più modalità insieme: riceve, per esempio, immagini e testo nello stesso modello. Un'applicazione che combina modelli specializzati collega più sistemi: uno trascrive l'audio, uno elabora la trascrizione, uno legge la risposta con una voce sintetica. Per l'utente le due soluzioni possono sembrare identiche: in entrambi i casi si parla e si riceve una risposta vocale. Il comportamento però può essere diverso. In una catena, ogni passaggio può introdurre errori che si propagano, e alcune informazioni si perdono: se l'audio viene prima trascritto, tono, pause ed enfasi non arrivano al modello linguistico. In un modello nativo, alcune di queste informazioni possono essere conservate. Nella pratica molti strumenti combinano le due soluzioni, e le catene di modelli specializzati restano spesso la scelta migliore per compiti specifici. La conseguenza per l'utente non è scegliere un'architettura, ma ricordare che le capacità effettive dipendono dal sistema impiegato.");
    opTag(s, -1);
    txt(s, "Applicazione che combina modelli specializzati", { x: 0.5, y: 1.12, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const ch = ["Voce", "Riconoscimento vocale", "Modello linguistico", "Sintesi vocale", "Risposta"];
    ch.forEach((t, i) => {
      chip(s, 0.5 + i * 1.84, 1.5, 1.6, 0.65, t, { fill: i === 0 || i === 4 ? C.background2 : C.accent6, fontSize: 11 });
      if (i < 4) arrow(s, 2.12 + i * 1.84, 1.66, 0.2);
    });
    txt(s, "Ogni passaggio può introdurre errori; tono, pause ed enfasi si perdono nella trascrizione", { x: 0.5, y: 2.2, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent5 });
    txt(s, "Modello multimodale nativo", { x: 0.5, y: 2.65, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.03, 1.6, 0.65, "Voce", { fill: C.background2, fontSize: 11 });
    arrow(s, 2.12, 3.19, 0.2);
    chip(s, 2.34, 3.03, 5.28, 0.65, "Un solo modello per più modalità", { fill: C.accent1, color: C.background1, fontSize: 12 });
    arrow(s, 7.64, 3.19, 0.2);
    chip(s, 7.86, 3.03, 1.6, 0.65, "Risposta", { fill: C.background2, fontSize: 11 });
    banner(s, 3.95, "Per l'utente possono sembrare identici; la differenza spiega perché due strumenti 'multimodali' rendono in modo diverso.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Capacità che dipendono dal sistema", "Un principio di metodo per tutto il tema: le capacità effettive e le modalità supportate dipendono dal sistema impiegato. L'etichetta 'multimodale' dice poco. Due strumenti entrambi definiti multimodali possono differire su molti aspetti: quali modalità accettano in ingresso e quali producono in uscita; quanto bene leggono dettagli piccoli, testi nelle immagini, grafici complessi; quali lingue e accenti riconoscono nel parlato; quanto lunghi possono essere gli audio e i video elaborati; se un video viene analizzato in tutti i fotogrammi o in una selezione; se i contenuti vengono elaborati sul dispositivo o inviati a un servizio esterno; quali regole d'uso applicano, per esempio sulla generazione di immagini di persone reali. Queste capacità migliorano rapidamente: un limite osservato un anno fa può non esistere più nei sistemi più recenti, e un limite ancora presente in uno strumento può essere superato in un altro. Per questo il modulo si concentra sui concetti durevoli; per le funzionalità specifiche conviene verificare quelle degli strumenti autorizzati in azienda, con una prova sui propri casi d'uso.");
    opTag(s, -1);
    const q = ["Quali modalità in ingresso e in uscita?", "Quanto bene legge dettagli, testi, grafici?", "Quali lingue e accenti nel parlato?", "Quale durata massima di audio e video?", "Video analizzati in tutti i fotogrammi o in una selezione?", "Elaborazione sul dispositivo o su un servizio esterno?", "Quali regole d'uso, per esempio sulle persone reali?"];
    q.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.62;
      shapeBox(s, x, y, 4.4, 0.54, C.background2, "domanda " + (i + 1));
      txt(s, t, { x: x + 0.2, y, w: 4.0, h: 0.54, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 3.75, "Le capacità crescono rapidamente: verificarle sugli strumenti autorizzati, con una prova sui propri casi d'uso.", { h: 0.75, fontSize: 13 });
    txt(s, "In questo modulo: concetti durevoli, non funzionalità dei prodotti.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }

  // =====================================================================
  section("10.2 Immagini: comprendere");
  divider("10.2", "Comprensione e analisi delle immagini", "Schermate, diagrammi, fotografie e documenti visivi: informazioni utili in pochi secondi, con limiti da conoscere e gestire", "Entriamo nelle modalità, partendo dalla comprensione delle immagini. È una delle capacità multimodali più mature e più utili nel lavoro quotidiano: leggere una schermata, interpretare un diagramma, estrarre informazioni da una fotografia, digitalizzare appunti e documenti. In questo sottotema, da conoscere e sperimentare, vediamo le applicazioni pratiche, i limiti ricorrenti presentati come elementi da gestire, e una distinzione importante, trattata una sola volta: quella tra descrivere ciò che si vede e comprenderne il significato. Il confine con il Tema 8: lì i documenti scansionati per il loro contenuto testuale; qui le immagini come modalità visiva. Concetto chiave: descrivere ciò che appare in un'immagine non equivale a comprenderne necessariamente significato, provenienza e contesto. Esercizio suggerito: dare ai partecipanti una schermata o una foto fittizia con alcuni dettagli importanti piccoli, chiedere una descrizione all'AI e verificare quali dettagli sono stati letti correttamente, quali mancati e quali ricostruiti.");
  {
    const s = content("Che cosa si può fare con un'immagine", "Le applicazioni pratiche della comprensione delle immagini sono molte. Interpretare schermate e messaggi di errore: capire che cosa mostra un programma, che cosa significa un avviso, dove cliccare. Leggere diagrammi e schemi: processi, organigrammi, mappe, grafici, con la possibilità di farli spiegare o trasformare in testo. Estrarre informazioni da fotografie: quante unità ci sono, quali etichette, quale stato presenta un macchinario o un'area di magazzino. Supportare l'assistenza tecnica: la foto di un componente o di un pannello di controllo, insieme al manuale, aiuta a identificare il pezzo e la procedura. Digitalizzare testi nelle immagini: lavagne, cartelli, etichette, moduli compilati, appunti scritti a mano. Analizzare documentazione visiva: fotografie di sopralluogo, cataloghi, controlli visivi di documenti o ambienti. Si aggiunge l'accessibilità: descrizioni di immagini e grafici per chi non vede. In molti di questi casi il sistema fornisce in pochi secondi un risultato utile. L'affidabilità varia con il compito: conoscere dove i sistemi sbagliano più spesso, come vedremo tra due slide, permette di sfruttarli con fiducia.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMonitor", head: "Schermate ed errori", body: "Che cosa significa, che cosa fare, dove cliccare" },
      { icon: "FiShare2", head: "Diagrammi e schemi", body: "Processi, organigrammi, grafici spiegati o trascritti" },
      { icon: "FiCamera", head: "Informazioni da foto", body: "Quantità, etichette, stato di un macchinario" },
      { icon: "FiTool", head: "Assistenza tecnica", body: "Foto del componente + manuale: pezzo e procedura" },
      { icon: "FiType", head: "Testi nelle immagini", body: "Lavagne, etichette, moduli, scritte a mano" },
      { icon: "FiFolder", head: "Documentazione visiva", body: "Sopralluoghi, cataloghi, controlli visivi" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Risultati utili in pochi secondi. Conoscere i limiti ricorrenti permette di usarli con fiducia.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Schermate e assistenza tecnica", "Le schermate sono probabilmente l'uso più frequente della comprensione visiva nel lavoro d'ufficio. Si cattura lo schermo e si chiede: che cosa significa questo errore? Come esporto questi dati? Dove si trova questa impostazione? Il sistema legge il testo dell'interfaccia, riconosce menu, pulsanti e campi, e guida passo per passo. È un supporto prezioso per l'assistenza tecnica: risolve molte richieste ripetitive prima che arrivino all'help desk, aiuta con programmi poco familiari, rende più rapido l'apprendimento di un nuovo software. Lo stesso vale per un pannello di una macchina o il display di un dispositivo fotografato. Tre buone pratiche lo rendono affidabile. Indicare versione e contesto: il sistema riconosce l'interfaccia ma non sempre conosce la versione del programma o la configurazione aziendale, e può suggerire passaggi che nel nostro caso non esistono. Per modifiche a configurazioni o dati di sistemi aziendali, procedere con prudenza e, nel dubbio, con l'assistenza interna. Prima di condividere, ritagliare la parte rilevante: una schermata può contenere dati personali, dati di clienti, credenziali, notifiche o altre finestre.");
    opTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.6, "Domande tipiche", "Che cosa significa questo errore?\nCome esporto questi dati?\nDove si trova questa impostazione?", { fontSize: 13, fill: C.accent6 });
    await card(s, 5.15, 1.15, 4.35, 1.6, { icon: "FiThumbsUp", inline: true, head: "Il valore", headSize: 14, bodySize: 12, body: "Guida passo per passo, meno richieste ripetitive all'assistenza, programmi nuovi appresi più in fretta." });
    rowsLabel(s, [["Indicare versione e contesto", "Così i passaggi suggeriti corrispondono al proprio programma"], ["Modifiche a sistemi aziendali", "Prudenza; nel dubbio, l'assistenza interna"], ["Prima di condividere", "Ritagliare; niente dati personali, credenziali, notifiche, altre finestre"]], { y: 2.95, h: 0.56, lw: 2.9 });
  }
  {
    const s = content("Limiti da conoscere e gestire", "Una sola slide raccoglie i limiti ricorrenti della comprensione visiva, perché si gestiscono con poche pratiche semplici. Non sono motivi per rinunciare agli strumenti: indicano dove guardare. Il testo nelle immagini è oggi letto in modo molto affidabile quando è stampato, chiaro e in una lingua diffusa; richiede più attenzione con scritte a mano, caratteri piccoli o sfocati, riflessi. Gli errori più insidiosi riguardano numeri e codici: un 8 letto come 3, uno 0 come una O. A differenza di una parola sbagliata, un numero sbagliato resta plausibile, quindi i dati critici si controllano sull'originale. I diagrammi semplici e ordinati sono interpretati bene; quelli densi, con frecce che si incrociano o legende separate, conviene farli descrivere relazione per relazione. Dettagli piccoli e conteggi in immagini affollate possono sfuggire, anche perché molte applicazioni riducono la risoluzione prima dell'elaborazione: aiuta caricare un ritaglio o un'immagine nitida e chiedere dove si trova esattamente l'elemento descritto. Relazioni spaziali, distanze e proporzioni, e immagini ruotate o con prospettive insolite, restano fonte di errori: misure e conteggi vanno considerati stime. Questi limiti si riducono rapidamente nei sistemi più recenti e variano molto tra strumenti. Ciò che resta costante è che il sistema risponde con la stessa sicurezza quando ha visto bene e quando ha ricostruito in modo plausibile. I valori letti da un grafico in un'immagine sono stime: l'analisi quantitativa appartiene al Tema 9.");
    opTag(s, 0);
    table(s, [["", "Di solito affidabile", "Richiede attenzione", "Come gestirlo"],
      ["Testo", "Stampato, chiaro, lingue diffuse", "A mano, piccolo, sfocato; numeri e codici", "Cifre e codici critici sull'originale"],
      ["Diagrammi", "Semplici e ordinati", "Densi, frecce incrociate, legende separate", "Farli descrivere relazione per relazione"],
      ["Dettagli e conteggi", "Elementi evidenti", "Oggetti piccoli, scene affollate", "Ritagli nitidi; chiedere dove si trova"],
      ["Spazio e misure", "Disposizioni semplici", "Destra e sinistra, distanze, prospettive", "Considerare misure e conteggi stime"]],
      { y: 1.15, colW: [1.7, 2.2, 2.6, 2.5], rowH: 0.5, fontSize: 11, blankCorner: true, accentCol: 3 });
    banner(s, 3.85, "Un numero sbagliato resta plausibile, e la sicurezza della risposta è la stessa: per i dati critici, uno sguardo all'originale.", { h: 0.8, fontSize: 13 });
    txt(s, "Prestazioni in rapido miglioramento e diverse tra strumenti.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Osservare o interpretare", "Una distinzione importante, che qui trattiamo una volta per tutte: osservare ciò che appare in un'immagine non equivale a comprenderne il significato, la provenienza o il contesto. L'esempio fittizio lo mostra. Davanti alla fotografia di un magazzino con alcuni scaffali vuoti, un sistema può dare una descrizione accurata: scaffali metallici, alcuni pieni, alcuni vuoti, un carrello elevatore, luce artificiale. Fin qui osservazione, ed è utile. Ma che cosa significa? Gli scaffali vuoti indicano una carenza di scorte, un'area svuotata per un inventario, un reparto in riorganizzazione, o un magazzino nuovo? La foto è di oggi o di due anni fa? È davvero il nostro magazzino? Queste domande non trovano risposta nell'immagine. Se gli si chiede un'interpretazione, il sistema ne propone una plausibile, e può essere un buon punto di partenza per ragionare: basta trattarla come ipotesi e completarla con il contesto che conosciamo noi. È lo stesso passaggio visto nel Tema 9 dalla descrizione all'interpretazione dei dati. Nelle immagini è più sottile, perché ciò che si vede sembra parlare da sé. Una pratica utile: chiedere al sistema di separare nella risposta ciò che osserva da ciò che ipotizza.");
    opTag(s, 0);
    docBox(s, 0.5, 1.15, 4.35, 1.6, "Osservazione (esempio fittizio)", "Scaffali metallici, alcuni pieni e alcuni vuoti, un carrello elevatore, luce artificiale.", { fontSize: 13, fill: C.accent6 });
    shapeBox(s, 5.15, 1.15, 4.35, 1.6, C.background2, "interpretazioni");
    txt(s, "Interpretazioni possibili", { x: 5.35, y: 1.22, w: 4.0, h: 0.3, fontSize: 11, bold: true, color: C.accent5 });
    txt(s, bullets(["Carenza di scorte", "Area svuotata per un inventario", "Reparto in riorganizzazione", "Magazzino nuovo"], { space: 2 }), { x: 5.35, y: 1.55, w: 4.0, h: 1.15, fontSize: 12, color: C.text1 });
    txt(s, "Domande a cui l'immagine non risponde", { x: 0.5, y: 2.95, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.33, 2.9, 0.55, "Che cosa significa?", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.33, 2.9, 0.55, "Quando è stata scattata?", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.33, 2.9, 0.55, "Da dove viene?", { fill: C.background2, fontSize: 12 });
    banner(s, 4.1, "Pratica utile: chiedere di separare ciò che il sistema osserva da ciò che ipotizza. Il contesto lo aggiungiamo noi.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Immagini e persone", "Un aspetto che merita attenzione specifica: la presenza di persone. Fotografie e video di lavoro contengono spesso colleghi, clienti, visitatori, passanti. Tre considerazioni. La prima riguarda i dati personali: il volto e l'immagine di una persona sono dati personali, e caricarli in uno strumento AI è un trattamento di dati, da fare negli strumenti autorizzati e per finalità legittime. Le regole specifiche sono trattate nei Temi 17 e 18. La seconda riguarda l'identificazione: molti strumenti di uso generale sono configurati per non riconoscere le persone dal volto, e l'identificazione biometrica è soggetta a limiti normativi specifici. Non è un compito per cui usare questi strumenti. La terza riguarda le inferenze: chiedere di dedurre da una foto età, stato d'animo, intenzioni o condizioni personali produce risposte che sembrano oggettive ma sono stime incerte, spesso influenzate da stereotipi; inoltre l'AI Act vieta il riconoscimento delle emozioni sul luogo di lavoro, salvo motivi medici o di sicurezza. Descrivere una scena è una cosa; giudicare le persone che vi compaiono è un'altra.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiUser", head: "Dati personali", body: "Volti e immagini sono dati personali: solo strumenti autorizzati, finalità legittime" },
      { icon: "FiUserX", head: "Identificazione", body: "Molti strumenti non identificano dal volto; limiti normativi specifici" },
      { icon: "FiAlertTriangle", head: "Inferenze sulle persone", body: "Età, stato d'animo, intenzioni: stime incerte, rischio di stereotipi" },
    ], 3, { y: 1.2, h: 2.1, headSize: 14, bodySize: 12 });
    banner(s, 3.55, "Descrivere una scena è una cosa; giudicare le persone che vi compaiono è un'altra.", { h: 0.75, fontSize: 15 });
    txt(s, "Volti e inferenze sulle persone sono soggetti a regole specifiche: in caso di dubbio, chiedere prima.", { x: 0.5, y: 4.45, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }

  // =====================================================================
  section("10.3 Immagini: generare");
  divider("10.3", "Generazione e trasformazione delle immagini", "Illustrazioni, concept, varianti e modifiche in pochi minuti: più creatività e produttività, con requisiti professionali da verificare", "Dalla comprensione alla generazione. I sistemi di generazione di immagini producono in pochi secondi illustrazioni, immagini dall'aspetto fotografico, concept e varianti a partire da una descrizione, e modificano immagini esistenti: aggiungono o rimuovono elementi, cambiano stile, adattano il formato. In questo sottotema, da conoscere e sperimentare, vediamo che cosa si può produrre, come si arriva a un buon risultato per passi successivi, le applicazioni nella comunicazione, nel marketing e nella formazione, un esempio dimostrativo, e come capire quando un'immagine è pronta all'uso e quando va rifinita. I modelli di diffusione, la tecnologia su cui si basano molti di questi sistemi, sono solo da accennare. Concetto chiave: la generazione visiva accelera l'esplorazione creativa e la produzione di materiali; controllo dei dettagli, fedeltà ai riferimenti e conformità ai requisiti professionali vanno verificati in base all'uso. Esercizio suggerito: generare un'immagine per una slide interna su un tema fittizio, chiedere due modifiche successive, poi valutarla con la lista della slide sui requisiti professionali.");
  {
    const s = content("Dalla descrizione all'immagine", "Dal punto di vista dell'utente: si descrive ciò che si vuole e il sistema produce una o più immagini. La descrizione può indicare soggetto, composizione, stile, colori, atmosfera, formato. Il risultato può essere un'illustrazione, un'immagine dall'aspetto fotografico, uno schizzo, un'icona. Valgono i principi generali di una buona richiesta, visti nel Tema 6: chiarezza, contesto, esempi, iterazione. Il punto da cogliere è che la descrizione orienta l'immagine ma non la determina del tutto: i dettagli non descritti li completa il sistema, come la luce, lo sfondo, la disposizione degli oggetti. È un vantaggio creativo, perché propone soluzioni a cui non si era pensato. Per arrivare esattamente a ciò che serve si procede per affinamenti: partire da un risultato e chiedere modifiche mirate, e in molti strumenti fornire un'immagine di riferimento, una palette o un esempio di stile. Ottenere una serie coerente, come lo stesso personaggio in più scene o lo stesso prodotto da più angolazioni, è più impegnativo: alcuni strumenti offrono funzioni dedicate, altrimenti servono più prove.");
    opTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 1.65, "Una descrizione può indicare", "Soggetto, composizione, stile, colori, atmosfera, formato.", { fontSize: 13 });
    await card(s, 5.15, 1.15, 4.35, 1.65, { icon: "FiStar", inline: true, head: "Il sistema completa i dettagli", headSize: 14, bodySize: 12, fill: C.accent6, body: "Luce, sfondo, disposizione: propone soluzioni a cui non si era pensato." });
    await card(s, 0.5, 3.0, 4.35, 1.45, { icon: "FiSliders", inline: true, head: "Affinare per passi", headSize: 14, bodySize: 12, body: "Modifiche mirate su un risultato; spesso anche immagini di riferimento." });
    await card(s, 5.15, 3.0, 4.35, 1.45, { icon: "FiCopy", inline: true, head: "Serie coerenti", headSize: 14, bodySize: 12, body: "Funzioni dedicate in alcuni strumenti; altrimenti più prove." });
    txt(s, "Valgono i principi di una buona richiesta: chiarezza, contesto, esempi, iterazione.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Che cosa si può produrre", "Le applicazioni della generazione di immagini nel lavoro sono molte. Illustrazioni per presentazioni, documenti e materiali formativi, in uno stile coerente con il materiale. Concept di prodotto: un packaging, l'allestimento di uno stand, una variante di design, da vedere prima di investire. Prototipazione visiva: ambienti, schermate di un'interfaccia, scenari d'uso, utili per discutere un'idea con colleghi e clienti. Comunicazione e marketing: visual per campagne, post, newsletter, sito. Varianti e adattamento dei formati: più versioni della stessa idea con colori, composizioni o stili diversi, e adattamento a canali con formati differenti. Elementi grafici: icone, sfondi, pattern. Il valore è duplice: creatività, perché si esplorano dieci idee nel tempo che prima ne richiedeva una, e produttività, perché molti materiali si realizzano senza attendere tempi di produzione. Non tutte le immagini generate sono semplici bozze. Alcuni risultati si possono usare direttamente, per esempio un'illustrazione per una slide interna o uno sfondo. Altri richiedono editing, verifiche o strumenti professionali, come vedremo nella slide sulla qualità.");
    opTag(s, 1);
    await iconGrid(s, [
      { icon: "FiFeather", head: "Illustrazioni", body: "Presentazioni, documenti, materiali formativi" },
      { icon: "FiPackage", head: "Concept di prodotto", body: "Packaging, stand, varianti di design" },
      { icon: "FiPenTool", head: "Prototipazione visiva", body: "Ambienti, interfacce, scenari d'uso" },
      { icon: "FiSpeaker", head: "Comunicazione e marketing", body: "Campagne, post, newsletter, sito" },
      { icon: "FiCopy", head: "Varianti e formati", body: "Colori, stili, adattamento ai canali" },
      { icon: "FiGrid", head: "Elementi grafici", body: "Icone, sfondi, pattern" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Alcuni risultati si usano direttamente; altri richiedono editing, verifiche o strumenti professionali.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Modificare immagini esistenti", "Oltre a generare immagini nuove, i sistemi trasformano immagini esistenti. Aggiungere elementi: un oggetto, una scritta, uno sfondo. Rimuovere elementi: un oggetto di disturbo, un difetto, un passante, ricostruendo lo sfondo. Sostituire: il colore di un prodotto, lo sfondo di una foto, un oggetto con un altro. Cambiare stile: da fotografia a disegno o acquerello. Modificare la composizione: estendere un'immagine oltre i suoi bordi, cambiarne l'inquadratura. Adattare il formato: da orizzontale a verticale per i social, a risoluzioni diverse. Sono operazioni che un tempo richiedevano competenze di fotoritocco e ore di lavoro, e oggi si ottengono con una richiesta: un grande risparmio per chi prepara cataloghi, materiali promozionali, presentazioni. Un'attenzione specifica riguarda le immagini usate come documentazione: rimuovere un elemento dalla foto di un cantiere o di un danno cambia ciò che la foto documenta. In quei casi si lavora su una copia e si dichiarano le modifiche, come vedremo nel 10.8.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiPlusCircle", head: "Aggiungere", body: "Un oggetto, una scritta, uno sfondo" },
      { icon: "FiMinusCircle", head: "Rimuovere", body: "Un oggetto di disturbo, un difetto" },
      { icon: "FiRefreshCw", head: "Sostituire", body: "Colore, sfondo, oggetto" },
      { icon: "FiFeather", head: "Cambiare stile", body: "Da foto a disegno o acquerello" },
      { icon: "FiMaximize", head: "Composizione", body: "Estendere, reinquadrare" },
      { icon: "FiSmartphone", head: "Formato", body: "Orizzontale, verticale, risoluzione" },
    ], 3, { y: 1.15, H: 2.6, headSize: 13, bodySize: 12 });
    shapeBox(s, 0.5, 3.95, 9.0, 1.0, C.text1, "attenzione documentazione");
    txt(s, [{ text: "Foto usate come documentazione: ", options: { bold: true, color: C.accent6 } }, { text: "togliere un elemento dalla foto di un cantiere o di un danno cambia ciò che documenta. Lavorare su una copia e dichiarare le modifiche.", options: { color: C.background1 } }], { x: 0.7, y: 3.95, w: 8.6, h: 1.0, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Esempio: un'immagine in due passi", "Un esempio dimostrativo fittizio, che mostra il procedimento per affinamenti. Le due illustrazioni sono schematiche, disegnate per la slide: rappresentano il tipo di risultato atteso, non sono output reali di uno strumento. La richiesta iniziale chiede un'illustrazione per la copertina di un corso interno sulla sicurezza in magazzino, con soggetto, stile, colori, formato e l'indicazione di non inserire testo. La prima versione rispetta il soggetto e la composizione, ma ha colori troppo accesi rispetto allo stile dei materiali aziendali e contiene una scritta inventata su uno scaffale: è un caso tipico, perché i sistemi tendono ad aggiungere testi decorativi. La richiesta di modifica non riparte da zero: chiede di mantenere soggetti e stile, cambiare palette, togliere la scritta e lasciare spazio libero per il titolo. La seconda versione è quasi pronta. Restano due controlli rapidi: i dettagli del carrello elevatore, perché un formatore sulla sicurezza noterebbe subito un mezzo poco realistico, e la coerenza con le altre copertine del corso. Il titolo si aggiunge in impaginazione, non si fa generare. Da proporre in aula con lo strumento autorizzato, seguendo gli stessi passaggi.");
    opTag(s, [1, 2]);
    promptBox(s, 0.5, 1.15, 2.95, 1.5, "Illustrazione in stile piatto per la copertina di un corso sulla sicurezza in magazzino: scaffali e un carrello elevatore, colori sobri, formato 16:9, nessun testo.", { label: "1. Richiesta iniziale", fontSize: 10 });
    promptBox(s, 0.5, 2.8, 2.95, 1.5, "Mantieni soggetti e stile. Usa verde petrolio e grigi, togli la scritta sullo scaffale, sposta la scena a destra e lascia spazio a sinistra per il titolo.", { label: "2. Richiesta di modifica", fontSize: 10, fill: C.accent6 });
    txt(s, "Versione 1", { x: 3.65, y: 1.1, w: 2.8, h: 0.28, fontSize: 11, bold: true, color: C.accent5 });
    scene(s, 3.65, 1.4, 2.8, 1.6, 1);
    txt(s, "Versione 2", { x: 6.7, y: 1.1, w: 2.8, h: 0.28, fontSize: 11, bold: true, color: C.accent1 });
    scene(s, 6.7, 1.4, 2.8, 1.6, 2);
    arrow(s, 6.47, 2.05, 0.2);
    docBox(s, 3.65, 3.15, 2.8, 1.15, "Che cosa si vede", "Composizione giusta; colori troppo accesi; una scritta inventata.", { fontSize: 11, bar: C.accent5, labelColor: C.accent5 });
    docBox(s, 6.7, 3.15, 2.8, 1.15, "Che cosa resta da fare", "Controllare il carrello; titolo aggiunto in impaginazione.", { fontSize: 11 });
    banner(s, 4.45, "Esempio fittizio: illustrazioni schematiche, non output reali. Si affina il risultato invece di ripartire da zero.", { h: 0.5, fontSize: 12 });
  }
  {
    const s = content("Applicazioni alla comunicazione", "Vediamo le principali applicazioni nella comunicazione, nel marketing e nella formazione, con il loro valore e l'attenzione principale. Formazione e materiali interni, come presentazioni, newsletter, intranet, corsi: illustrazioni che rendono i contenuti più chiari e coinvolgenti; l'attenzione è la coerenza con lo stile aziendale. Marketing e social: visual e varianti in tempi brevi, utili anche per confrontare alternative prima di una campagna; l'attenzione va a marchio, diritti e trasparenza. Concept e prototipi, per vedere e confrontare idee prima di investire: grande risparmio di tempo nelle fasi iniziali; l'attenzione è non confondere il concept con il prodotto finale. Adattamento di formati per canali e destinatari diversi: rapido ed efficace; l'attenzione è la fedeltà all'originale. Comunicazione esterna su larga scala: possibile e sempre più diffusa; richiede una revisione prima della pubblicazione, soprattutto quando compaiono persone o prodotti reali. Le linee guida aziendali sull'uso delle immagini generate, quando esistono, vanno seguite. Se non esistono, è un buon momento per chiederle.");
    opTag(s, [1, 2]);
    table(s, [["Applicazione", "Valore", "Attenzione principale"],
      ["Formazione e materiali interni", "Contenuti più chiari e coinvolgenti", "Coerenza con lo stile aziendale"],
      ["Marketing e social", "Visual e varianti in tempi brevi", "Marchio, diritti, trasparenza"],
      ["Concept e prototipi", "Confrontare idee prima di investire", "Distinguere concept e prodotto finale"],
      ["Adattamento di formati", "Un contenuto per più canali", "Fedeltà all'originale"],
      ["Comunicazione esterna", "Produzione su scala", "Revisione prima di pubblicare"]],
      { y: 1.15, colW: [2.8, 3.1, 3.1], rowH: 0.46, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 4.1, "Seguire le linee guida aziendali sulle immagini generate. Se non esistono, è il momento di chiederle.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Qualità e requisiti professionali", "Quando un'immagine generata è pronta all'uso? Dipende dall'uso, e conviene ragionare per tre casi. Usabile direttamente: illustrazioni per slide e materiali interni, sfondi, icone, varianti da confrontare. Se il risultato è coerente e privo di errori evidenti, non serve altro. Da rifinire: immagini con testo, dettagli tecnici, serie che devono essere coerenti tra loro. I sistemi sono molto migliorati, ma scritte ed etichette possono ancora risultare imprecise, mani e meccanismi complessi possono avere incoerenze, e la coerenza tra più immagini richiede funzioni dedicate o più prove; spesso basta un passaggio di editing o uno strumento di grafica. Con verifiche o professionisti: prodotti reali, macchinari, luoghi riconoscibili, campagne esterne, packaging, materiali di marchio. Un prodotto reale generato può risultare simile ma non fedele, con dettagli che chi lo conosce riconosce subito. In tutti i casi ci sono quattro requisiti da verificare, che la generazione non garantisce automaticamente. Identità visiva: colori, caratteri e stile aziendali; i loghi si inseriscono come file originali, non si fanno generare. Diritti: esistono questioni aperte sui contenuti generati e le condizioni d'uso degli strumenti variano; imitare lo stile riconoscibile di un artista vivente o riprodurre personaggi e marchi altrui può creare problemi. Persone reali: generare immagini di persone riconoscibili richiede il loro consenso ed espone a rischi di inganno; molti strumenti lo limitano. Trasparenza: quando un'immagine può essere scambiata per una fotografia reale, è opportuno, e in alcuni casi obbligatorio, dichiararlo. Le regole specifiche sono nei Temi 17 e 18.");
    opTag(s, 1);
    const lv = [["Usabile direttamente", "Illustrazioni interne, sfondi, icone, varianti", C.accent6, C.text1], ["Da rifinire", "Testi nell'immagine, dettagli tecnici, serie coerenti", C.background2, C.text1], ["Con verifiche o professionisti", "Prodotti reali, campagne, packaging, marchio", C.text1, C.background1]];
    lv.forEach((l, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.45, l[2], l[0]);
      txt(s, l[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.5, fontSize: 14, bold: true, color: i === 2 ? C.accent6 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: x + 0.15, y: 1.75, w: 2.56, h: 0.75, fontSize: 12, color: l[3] });
    });
    txt(s, "Da verificare in ogni caso", { x: 0.5, y: 2.75, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const rq = [["Identità visiva", "Colori, caratteri, stile; loghi originali, non generati"], ["Diritti", "Stili di artisti viventi, personaggi e marchi altrui"], ["Persone reali", "Consenso; rischio di inganno"], ["Trasparenza", "Dichiarare se può sembrare una fotografia"]];
    rq.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 3.15 + row * 0.9;
      shapeBox(s, x, y, 4.4, 0.8, C.background2, e[0]);
      txt(s, e[0], { x: x + 0.2, y, w: 1.5, h: 0.8, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: x + 1.75, y, w: 2.55, h: 0.8, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }

  // =====================================================================
  section("10.4 Audio e voce");
  divider("10.4", "AI per audio, voce e linguaggio parlato", "Trascrivere, riassumere, tradurre e dare voce ai contenuti: un risparmio di tempo concreto, con una revisione proporzionata", "Passiamo all'audio. Le tecnologie vocali sono forse quelle con l'impatto più immediato sul lavoro quotidiano: trascrivere riunioni, interviste e telefonate, ottenere verbali e riepiloghi, interagire con un assistente a voce, tradurre il parlato, far leggere un testo da una voce naturale, rendere i contenuti accessibili. In questo sottotema, da conoscere e sperimentare, partiamo dai benefici, vediamo un esempio dalla riunione al verbale, poi gli errori tipici in una sola slide e il modo di gestirli con una revisione mirata, e infine le regole pratiche per registrare e trascrivere in modo corretto. Concetto chiave: le tecnologie vocali fanno risparmiare tempo e migliorano l'accessibilità; una revisione proporzionata degli elementi critici, come nomi, numeri e impegni, mantiene l'affidabilità. Esercizio suggerito: registrare, con l'informazione ai partecipanti e uno strumento autorizzato, una breve discussione simulata con nomi, numeri e impegni, e confrontare trascrizione e verbale automatici con quanto effettivamente detto.");
  {
    const s = content("Le capacità vocali", "Una panoramica delle capacità, nell'ordine in cui portano valore nel lavoro. La trascrizione automatica: una registrazione diventa testo, con l'indicazione di chi parla e dei tempi, ricercabile e condivisibile. Verbali e riepiloghi: dal contenuto di una riunione o di un'intervista si ricavano sintesi, decisioni, attività e responsabili. L'interazione vocale: si conversa a voce con un assistente, con tempi di risposta sempre più simili a una conversazione, utile quando mani o occhi sono occupati. La traduzione del parlato: ciò che viene detto in una lingua viene restituito in un'altra, come sottotitolo o come voce, anche quasi in tempo reale. La sintesi vocale: un testo viene letto da una voce artificiale molto naturale, in molte lingue, per video formativi, versioni audio di documenti, assistenti telefonici. L'accessibilità: sottotitoli, letture e comandi vocali rendono i contenuti fruibili a più persone. La qualità di tutte queste capacità è molto migliorata e continua a migliorare; i risultati dipendono dalla qualità dell'audio, dalla lingua, dagli accenti e dalla terminologia.");
    opTag(s, [0, 1, 2]);
    await iconGrid(s, [
      { icon: "FiFileText", head: "Trascrizione automatica", body: "Da audio a testo, con chi parla e quando" },
      { icon: "FiList", head: "Verbali e riepiloghi", body: "Sintesi, decisioni, attività, responsabili" },
      { icon: "FiMessageCircle", head: "Interazione vocale", body: "Domande e dettatura con mani e occhi liberi" },
      { icon: "FiGlobe", head: "Traduzione del parlato", body: "Sottotitoli o voce, anche quasi in tempo reale" },
      { icon: "FiVolume2", head: "Sintesi vocale", body: "Testi letti da voci naturali, in molte lingue" },
      { icon: "FiUsers", head: "Accessibilità", body: "Sottotitoli, letture, comandi vocali" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Qualità molto migliorata; i risultati dipendono da audio, lingua, accenti e terminologia.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Riunioni, interviste, comunicazioni", "L'applicazione più diffusa delle tecnologie vocali in azienda è la trascrizione e la sintesi delle riunioni. Molti strumenti di videoconferenza la offrono direttamente: al termine si ottengono trascrizione, riassunto, decisioni e attività con i responsabili. I benefici sono concreti: nessuno deve dedicarsi agli appunti e tutti partecipano alla discussione; chi era assente recupera in pochi minuti; le attività concordate non si perdono; le riunioni passate diventano ricercabili. Lo stesso vale per interviste, focus group, telefonate di assistenza, colloqui di formazione. Il passaggio dalla registrazione al verbale è una catena di trasformazioni, e il punto delicato non è l'intero testo ma pochi elementi: nomi, numeri, decisioni, impegni e attribuzioni. Una revisione proporzionata si concentra su questi, e così mantiene quasi tutto il risparmio di tempo. Due buone pratiche: far rivedere il verbale a chi ha partecipato, o almeno al responsabile della riunione, prima di diffonderlo; conservare la trascrizione, o la registrazione quando consentito, come riferimento per i punti controversi.");
    opTag(s, [0, 2]);
    const ch = [["Registrazione", C.background2], ["Trascrizione", C.accent6], ["Riassunto", C.accent6], ["Decisioni e attività", C.accent1]];
    ch.forEach((e, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, e[0], { fill: e[1], color: i === 3 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    const r = [["Tutti partecipano", "Nessuno dedicato agli appunti"], ["Chi era assente", "Recupera in pochi minuti"], ["Attività", "Non si perdono"], ["Riunioni passate", "Diventano ricercabili"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 2.0, 2.05, 0.95, C.background2, e[0]);
      txt(s, e[0], { x: x + 0.12, y: 2.06, w: 1.85, h: 0.42, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 2.5, w: 1.85, h: 0.38, fontSize: 11, color: C.text2 });
    });
    await card(s, 0.5, 3.15, 4.35, 1.8, { icon: "FiCheckSquare", inline: true, head: "Revisione proporzionata", headSize: 14, bodySize: 12, fill: C.accent6, body: "Nomi, numeri, decisioni, impegni: li conferma chi ha partecipato, prima di diffondere." });
    await card(s, 5.15, 3.15, 4.35, 1.8, { icon: "FiArchive", inline: true, head: "Conservare la trascrizione", headSize: 14, bodySize: 12, body: "O la registrazione, quando consentito, come riferimento per i punti controversi." });
  }
  {
    const s = content("Esempio: dalla riunione al verbale", "Un esempio dimostrativo fittizio: un breve estratto di trascrizione di una riunione di progetto e il verbale operativo che se ne ricava. I nomi, gli importi e le date sono inventati. Osserviamo che cosa fa un buon verbale. Distingue le decisioni dalle proposte: la stampa con il fornitore attuale è decisa, ma a una condizione, la conferma del prezzo, e la condizione deve restare. La nuova data del 30 novembre è invece solo una proposta, da confermare lunedì, e va nei punti aperti, non nelle decisioni. Trasforma gli impegni in attività con responsabile e scadenza: Neri chiede la conferma entro giovedì. Non inventa attività che nessuno ha preso: Gallo ha segnalato un possibile ritardo, ma non si è impegnato a nulla. In basso, i quattro elementi da controllare prima di diffondere il verbale: importo, scadenze, condizioni e la distinzione tra decisione e proposta. È esattamente il controllo mirato di cui parlavamo: pochi minuti su pochi punti, non la rilettura di tutta la registrazione. In aula si può chiedere ai partecipanti di produrre il verbale con lo strumento autorizzato a partire dallo stesso estratto, e confrontare i risultati con questa versione.");
    opTag(s, [0, 2]);
    docBox(s, 0.5, 1.15, 4.35, 3.05, "Trascrizione (estratto fittizio)", "Rossi: La stampa del catalogo la facciamo con il fornitore attuale?\nNeri: Sì, ma solo se conferma il prezzo di 4.200 euro.\nRossi: Bene. Neri, chiedi tu la conferma entro giovedì?\nNeri: D'accordo.\nGallo: Per le foto dei prodotti forse servono due settimane in più.\nRossi: Allora pensiamo al 30 novembre, ne riparliamo lunedì.", { fontSize: 11, fill: C.background2 });
    arrow(s, 4.88, 2.5, 0.24);
    docBox(s, 5.15, 1.15, 4.35, 0.95, "Decisioni", "Stampa con il fornitore attuale, se conferma il prezzo di 4.200 euro.", { fontSize: 11, fill: C.accent6 });
    docBox(s, 5.15, 2.2, 4.35, 0.95, "Attività", "Neri: chiedere la conferma del prezzo al fornitore, entro giovedì.", { fontSize: 11, fill: C.accent6 });
    docBox(s, 5.15, 3.25, 4.35, 0.95, "Punti aperti", "Consegna al 30 novembre: proposta da confermare lunedì (tempi delle foto).", { fontSize: 11, fill: C.accent6, bar: C.accent5, labelColor: C.accent5 });
    banner(s, 4.35, "Prima di diffondere: importo, scadenze, condizione 'solo se', decisione o proposta. Esempio fittizio.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Errori di trascrizione e come ridurli", "Gli errori tipici delle trascrizioni sono prevedibili, e proprio per questo si controllano in modo mirato. La tabella mostra tre esempi fittizi. Nomi propri di persone, aziende e prodotti, specialmente se stranieri o poco comuni: Kessler diventa Kessel. Sigle e terminologia aziendale, sostituite da parole simili nel suono. Numeri, importi e percentuali, dove l'errore è grave e poco visibile: 'diciotto per cento' diventa 'otto per cento'. A destra, il rischio più specifico: l'attribuzione delle frasi alle persone. Molti strumenti distinguono le voci e indicano chi parla; con persone collegate da account separati in videoconferenza l'attribuzione è di solito affidabile, mentre con più persone nella stessa stanza e un solo microfono, voci simili o interruzioni può sbagliare. Nell'esempio l'impegno di consegnare entro venerdì finisce attribuito alla persona sbagliata: in un verbale cambia chi ha preso l'impegno. In alcuni sistemi si osserva anche l'aggiunta di frasi mai pronunciate durante pause o rumori. Come ridurre gli errori: fornire un vocabolario di nomi e sigle quando lo strumento lo consente, usare buoni microfoni e account separati, e rileggere solo i passaggi con nomi, numeri e impegni. Con questa revisione proporzionata il risparmio di tempo resta, e l'affidabilità pure.");
    opTag(s, 0);
    table(s, [["Detto", "Trascritto", "Tipo"],
      ["Il fornitore Kessler", "Il fornitore Kessel", "Nome"],
      ["Il modulo SDI", "Il modulo esse di", "Sigla"],
      ["Sconto del diciotto per cento", "Sconto dell'otto per cento", "Numero"]],
      { x: 0.5, y: 1.15, w: 4.6, colW: [1.85, 1.85, 0.9], rowH: 0.48, fontSize: 11, blankCorner: false, accentCol: 2 });
    docBox(s, 5.3, 1.15, 4.2, 0.9, "Detto (esempio fittizio)", "Bianchi: \"Riesci entro venerdì?\"  Verdi: \"Sì, me ne occupo io.\"", { fontSize: 11, fill: C.accent6 });
    docBox(s, 5.3, 2.12, 4.2, 0.9, "Trascritto con attribuzione errata", "Bianchi: \"Riesci entro venerdì? Sì, me ne occupo io.\"", { fontSize: 11, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Come ridurli", { x: 0.5, y: 3.2, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.55, 2.9, 0.55, "Vocabolario di nomi e sigle", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.55, 2.9, 0.55, "Buoni microfoni, account separati", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.55, 2.9, 0.55, "Rileggere nomi, numeri, impegni", { fill: C.background2, fontSize: 12 });
    banner(s, 4.25, "Una revisione mirata conserva il risparmio di tempo; le attribuzioni importanti le conferma chi era presente.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Sintesi vocale e interazione", "Due capacità di generazione vocale. La sintesi vocale trasforma un testo in parlato, con voci molto naturali, intonazione ed espressività, in molte lingue. Applicazioni: narrazione di video formativi, versioni audio di documenti e procedure, messaggi e assistenti telefonici, contenuti per chi preferisce ascoltare o non può leggere. Alcuni sistemi riproducono la voce di una persona specifica a partire da poche registrazioni: è una capacità con usi legittimi, come dare voce a un formatore in più lingue o restituire la voce a chi l'ha persa, ma solo con il consenso esplicito della persona e nelle regole aziendali, come vedremo nel 10.8. L'interazione vocale permette di conversare con un assistente: porre domande, dettare, ricevere risposte parlate. È utile quando le mani o gli occhi sono occupati, in magazzino, in officina, alla guida, per chi ha difficoltà con la tastiera, o semplicemente perché parlare è più rapido che scrivere. Un'attenzione pratica: una risposta ascoltata non si rilegge, quindi per informazioni importanti conviene chiedere anche la versione scritta.");
    opTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiVolume2", head: "Sintesi vocale", headSize: 15, bodySize: 12,
      body: bullets(["Voci naturali, in molte lingue", "Video formativi, documenti in audio, assistenti", "Voce di una persona specifica: solo con il suo consenso"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiMessageCircle", head: "Interazione vocale", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Domande, dettatura, risposte parlate", "Mani o occhi occupati, difficoltà con la tastiera", "Più rapido che scrivere"], { space: 5 }) });
    banner(s, 3.9, "Per informazioni importanti ricevute a voce, chiedere anche la versione scritta.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Tradurre il parlato", "La traduzione del parlato combina riconoscimento, traduzione e, a volte, sintesi vocale. Può avvenire in modi diversi: sottotitoli tradotti in una videoconferenza, traduzione di una registrazione, conversazione bilingue quasi in tempo reale con un dispositivo che ascolta e traduce. Le opportunità sono grandi: riunioni con colleghi o clienti di altri paesi senza una lingua comune, formazione per personale di lingue diverse, assistenza a clienti stranieri, visite di fornitori. Per le lingue più diffuse e per conversazioni ordinarie la qualità è oggi buona. Per l'uso professionale conviene conoscere due aspetti. La traduzione somma due passaggi, riconoscimento e traduzione, e quella quasi in tempo reale lavora frase per frase con meno contesto. E chi ascolta spesso non può verificarla, perché non conosce la lingua di partenza. Per questo, nelle conversazioni con conseguenze, come trattative, accordi, istruzioni di sicurezza, comunicazioni mediche o legali, la traduzione automatica è un ottimo supporto ma non sostituisce un interprete o una conferma scritta.");
    opTag(s, [0, 2]);
    const ch = [["Parlato", C.background2], ["Riconoscimento", C.accent6], ["Traduzione", C.accent6], ["Testo o voce", C.background2]];
    ch.forEach((e, i) => {
      chip(s, 0.5 + i * 2.3, 1.2, 2.05, 0.65, e[0], { fill: e[1], fontSize: 13 });
      if (i < 3) arrow(s, 2.57 + i * 2.3, 1.37, 0.2);
    });
    await card(s, 0.5, 2.05, 4.35, 1.75, { icon: "FiThumbsUp", inline: true, head: "Opportunità", headSize: 14, bodySize: 12, fill: C.accent6, body: "Riunioni senza lingua comune, formazione multilingue, assistenza a clienti stranieri." });
    await card(s, 5.15, 2.05, 4.35, 1.75, { icon: "FiInfo", inline: true, head: "Da sapere", headSize: 14, bodySize: 12, body: "Due passaggi sommati, meno contesto in tempo reale, chi ascolta non può verificare." });
    banner(s, 4.0, "Trattative, accordi, sicurezza, ambiti medici o legali: ottimo supporto, ma con interprete o conferma scritta.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Uno strumento di accessibilità", "L'AI multimodale è uno strumento concreto di accessibilità. Trascrizioni, sottotitoli, descrizioni, sintesi vocale e traduzioni rendono le informazioni fruibili a persone con esigenze diverse. Le persone sorde o con difficoltà uditive seguono riunioni e video grazie ai sottotitoli automatici. Le persone cieche o ipovedenti ascoltano documenti con la sintesi vocale e ricevono descrizioni di immagini e grafici. Le persone con dislessia possono ascoltare invece di leggere. Chi ha difficoltà motorie può usare la voce invece della tastiera. Chi non conosce bene la lingua riceve traduzioni e versioni semplificate. E chiunque, in situazioni temporanee, in viaggio, in un ambiente rumoroso, con le mani occupate, beneficia di modalità alternative. È uno dei contributi più concreti e meno discussi dell'AI multimodale, e un'opportunità per rendere più inclusiva la comunicazione aziendale, oggi a costi molto più bassi di un tempo. La condizione è un controllo adeguato sui contenuti importanti: un sottotitolo sbagliato, per chi non può ascoltare l'audio, è un errore che non ha modo di correggere.");
    opTag(s, [0, 1, 2]);
    await iconGrid(s, [
      { icon: "FiType", head: "Sottotitoli", body: "Per chi non sente o è in un luogo rumoroso" },
      { icon: "FiVolume2", head: "Sintesi vocale", body: "Per chi non vede o fatica a leggere" },
      { icon: "FiImage", head: "Descrizioni di immagini", body: "Grafici e foto per chi non vede" },
      { icon: "FiMic", head: "Comandi vocali", body: "Per chi non usa la tastiera" },
      { icon: "FiGlobe", head: "Traduzioni", body: "Per chi non conosce bene la lingua" },
      { icon: "FiAlignLeft", head: "Versioni semplificate", body: "Per chi ha bisogno di testi più chiari" },
    ], 3, { y: 1.15, H: 2.7, headSize: 13, bodySize: 12 });
    banner(s, 4.05, "Comunicazione più inclusiva a costi bassi. Per i contenuti importanti, un controllo: chi non può ascoltare non può correggere.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Registrare e trascrivere correttamente", "Registrazione e trascrizione coinvolgono le voci e le parole di altre persone, e quindi i loro dati personali. Senza entrare nell'analisi normativa, che appartiene ai Temi 17 e 18, alcune regole pratiche sono chiare. Informare sempre i partecipanti, prima di iniziare, che la conversazione viene registrata o trascritta e se sarà elaborata con l'AI. Quanto alla base giuridica, il consenso non è l'unica possibile: a seconda della situazione possono valere altre basi previste dalla normativa sulla protezione dei dati, come un obbligo contrattuale o un interesse legittimo valutato dall'azienda. Non è una scelta del singolo: la definiscono l'azienda e le funzioni competenti, e la policy interna dice quando serve il consenso, come raccoglierlo e come gestire chi preferisce di no. Usare solo strumenti autorizzati, perché una registrazione contiene spesso informazioni riservate e caricarla in uno strumento non autorizzato significa portarla fuori dal controllo aziendale. Più attenzione con gli esterni, come clienti, fornitori, candidati, per cui possono valere regole più stringenti. Definire per quanto tempo conservare registrazioni e trascrizioni e chi può accedervi, e non registrare mai di nascosto. L'avviso automatico degli strumenti di videoconferenza è un buon punto di partenza, ma non sostituisce l'informazione esplicita, specialmente quando la trascrizione viene poi elaborata da sistemi AI.");
    opTag(s, 0);
    numList(s, ["Informare i partecipanti prima di iniziare, anche dell'elaborazione con l'AI", "Seguire la policy aziendale: consenso o altre basi giuridiche, le definisce l'azienda", "Solo strumenti autorizzati: le registrazioni contengono informazioni riservate", "Più attenzione con esterni: clienti, fornitori, candidati", "Conservazione e accesso definiti; mai registrazioni nascoste"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "Il consenso non è sempre l'unica base possibile; informare le persone è sempre necessario.", { h: 0.65, fontSize: 13 });
  }

  // =====================================================================
  section("10.5 Video");
  divider("10.5", "AI per comprensione e generazione video", "Sintetizzare, spiegare e produrre video diventa più rapido; autenticità e provenienza richiedono verifiche adeguate", "Il video combina immagini, tempo e spesso audio, ed è la modalità più complessa, ma anche quella in cui le capacità sono cresciute più in fretta. Gli obiettivi del sottotema, a priorità media, sono conoscere che cosa i sistemi permettono oggi di fare con i video, sia nell'analizzarli sia nel generarli, le opportunità per formazione e comunicazione, e la distinzione tra video documentale e video sintetico. La produzione audiovisiva specialistica e l'editing professionale sono solo da accennare. Concetto chiave: coerenza visiva e plausibilità di una sequenza non dimostrano da sole che gli eventi siano accaduti; il valore di un video come documentazione dipende dalla provenienza verificabile. Esercizio suggerito: mostrare un breve video generato, privo di persone reali e marchi, insieme a un video reale di soggetto simile, e discutere quali informazioni sulla provenienza aiutano a distinguerli.");
  {
    const s = content("Comprendere i video", "I sistemi multimodali analizzano filmati e sequenze audiovisive, combinando ciò che si vede e ciò che si sente. Le applicazioni sono molto pratiche. Sintesi di webinar, lezioni e filmati: una registrazione di un'ora diventa una sintesi con i punti principali. Capitoli e ricerca: un archivio di video formativi diventa navigabile, con l'indicazione del punto in cui si parla di un argomento. Istruzioni da video dimostrativi: una procedura mostrata in video diventa una lista di passaggi scritti. Estrazione di testi a schermo e slide mostrate. Due aspetti tecnici da conoscere. Molti sistemi analizzano una selezione di fotogrammi a intervalli, e un evento molto rapido tra due fotogrammi può sfuggire. E le relazioni temporali, come che cosa è successo prima e dopo o quanto è durato un evento, restano una fonte di errori più frequente. Per i video usati come documentazione, quindi, la sintesi automatica è un indice prezioso per trovare i passaggi rilevanti, da guardare direttamente quando contano.");
    opTag(s, 0);
    await iconGrid(s, [
      { icon: "FiAlignLeft", head: "Sintesi di webinar e filmati", body: "Un'ora di registrazione in punti chiave" },
      { icon: "FiBookmark", head: "Capitoli e ricerca", body: "Archivi formativi navigabili per argomento" },
      { icon: "FiList", head: "Istruzioni da video", body: "Una procedura dimostrata diventa passaggi scritti" },
      { icon: "FiMonitor", head: "Testi a schermo", body: "Slide e scritte mostrate nel video" },
    ], 2, { y: 1.15, H: 2.4, headSize: 14, bodySize: 12 });
    await card(s, 0.5, 3.75, 4.35, 1.2, { head: "Fotogrammi selezionati", headSize: 13, bodySize: 12, body: "Un evento molto rapido può sfuggire." });
    await card(s, 5.15, 3.75, 4.35, 1.2, { head: "Relazioni temporali", headSize: 13, bodySize: 12, fill: C.accent6, body: "Prima, dopo, durata: da controllare sui passaggi chiave." });
  }
  {
    const s = content("Generare e modificare video", "La generazione di video è la capacità multimodale progredita più rapidamente negli ultimi anni. Le opportunità per la comunicazione e la formazione sono concrete. Video formativi prodotti e aggiornati rapidamente, senza riprese, quando una procedura cambia. Animazioni esplicative per mostrare un processo, il funzionamento di un prodotto, un flusso di lavoro. Presentatori virtuali che leggono un testo con una voce sintetica, utili per contenuti standard e aggiornamenti frequenti, dichiarati come tali. Adattamento multilingue: doppiaggio, sottotitoli e in alcuni strumenti sincronizzazione del labiale, per raggiungere personale e clienti in più lingue con lo stesso video. Contenuti brevi per la comunicazione interna e i social. Modifiche a filmati esistenti: cambiare sfondo, rimuovere elementi, adattare il formato. I limiti principali si stanno riducendo ma restano da conoscere: la coerenza tra fotogrammi e scene, perché oggetti e persone possono cambiare aspetto o muoversi in modo innaturale, e il controllo preciso dell'azione rappresentata. I video generati sono in genere brevi; produzioni lunghe e coerenti richiedono montaggio e competenze specialistiche.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiBookOpen", head: "Video formativi", body: "Prodotti e aggiornati senza nuove riprese" },
      { icon: "FiPlayCircle", head: "Animazioni esplicative", body: "Processi, prodotti, flussi di lavoro" },
      { icon: "FiUser", head: "Presentatori virtuali", body: "Per contenuti standard, dichiarati come tali" },
      { icon: "FiGlobe", head: "Adattamento multilingue", body: "Doppiaggio, sottotitoli, labiale" },
      { icon: "FiSpeaker", head: "Comunicazione", body: "Contenuti brevi per intranet e social" },
      { icon: "FiScissors", head: "Modifiche", body: "Sfondi, elementi, formati" },
    ], 3, { y: 1.15, H: 2.9, headSize: 13, bodySize: 12 });
    shapeBox(s, 0.5, 4.2, 9.0, 0.75, C.text1, "limiti video");
    txt(s, [{ text: "Limiti in riduzione: ", options: { bold: true, color: C.accent6 } }, { text: "coerenza tra scene e controllo dell'azione. Per video lunghi servono montaggio e competenze.", options: { color: C.background1 } }], { x: 0.7, y: 4.2, w: 8.6, h: 0.75, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Documentale o sintetico", "La distinzione più importante del sottotema: contenuto documentale e contenuto sintetico. Un video documentale registra qualcosa che è accaduto davanti a una telecamera: una riunione, un evento, un'ispezione, una testimonianza. Il suo valore sta nel legame con la realtà. Un video sintetico è generato o profondamente modificato da un sistema: può rappresentare qualcosa che non è mai accaduto. Il suo valore sta nella comunicazione, nella spiegazione, nella creatività. Entrambi sono legittimi, e non vanno confusi. Poiché i video sintetici di alta qualità possono essere difficili da distinguere a occhio da quelli documentali, il valore di un video come prova non scompare, ma dipende sempre di più dalla provenienza: chi l'ha girato, quando, con quale dispositivo, come è arrivato a noi. Un video di una telecamera aziendale, conservato secondo le procedure, resta una documentazione solida; un video ricevuto da una fonte sconosciuta richiede verifiche prima di essere usato come prova. Ne derivano due regole pratiche. Quando si usa un video sintetico in modo che possa sembrare reale, dichiararlo. Quando si riceve un video come prova di qualcosa, chiedersi da dove viene, come vedremo nel 10.8.");
    opTag(s, [1, 2]);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiVideo", head: "Contenuto documentale", headSize: 15, bodySize: 12,
      body: bullets(["Registra qualcosa che è accaduto", "Valore: il legame con la realtà", "Riunioni, eventi, ispezioni, testimonianze"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiCpu", head: "Contenuto sintetico", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Generato o profondamente modificato", "Valore: comunicazione, spiegazione, creatività", "Può non essere mai accaduto"], { space: 4 }) });
    banner(s, 3.6, "Un video resta una prova importante quando la provenienza è verificabile: chi l'ha girato, quando, come è arrivato.", { h: 0.65, fontSize: 13 });
    chip(s, 0.5, 4.4, 4.4, 0.55, "Se si usa un video sintetico realistico: dichiararlo", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 4.4, 4.4, 0.55, "Se si riceve un video come prova: da dove viene?", { fill: C.background2, fontSize: 12 });
  }

  // =====================================================================
  section("10.6 Presentazioni");
  divider("10.6", "Presentazioni e materiali di comunicazione", "Dal documento alla presentazione in pochi minuti: più tempo per contenuti, chiarezza e verifica", "Un'applicazione che combina testo e immagini: presentazioni e materiali di comunicazione. È un ambito in cui l'AI è entrata rapidamente nel lavoro quotidiano: da un documento o da una scaletta si ottengono in pochi minuti slide impaginate, schemi, infografiche, versioni per destinatari diversi. In questo sottotema, da conoscere e sperimentare, vediamo che cosa si può fare, un esempio dal documento alle slide, l'adattamento ai destinatari, la coerenza tra testo e visivo e una checklist unica di controllo. Il confine con il 10.7: qui l'applicazione, lì il principio generale delle conversioni tra modalità. Concetto chiave: l'AI riduce drasticamente il tempo dedicato all'impaginazione; la cura visiva non garantisce da sola accuratezza, completezza e coerenza, ed è lì che va investito il tempo risparmiato. Esercizio suggerito: generare con lo strumento autorizzato una breve presentazione da un documento fittizio di due pagine e applicare la checklist, contando gli interventi necessari.");
  {
    const s = content("Dal testo alle slide", "Le possibilità sono molte. Trasformare documenti in presentazioni: una relazione diventa una presentazione per la direzione, un manuale una serie di schede, una procedura un diagramma di flusso. Organizzare le informazioni: scegliere che cosa mettere in evidenza, come raggrupparlo, in quale ordine presentarlo; è spesso il contributo più utile, perché propone una struttura su cui ragionare invece di una pagina bianca. Creare schemi e diagrammi: processi, organigrammi, mappe concettuali, linee del tempo. Adattare i contenuti ai destinatari, come vedremo tra due slide. Migliorare chiarezza e qualità visiva: titoli più efficaci, testi più brevi, gerarchia visiva, coerenza grafica. Ridurre il tempo dedicato all'impaginazione, la parte più meccanica del lavoro. Questi strumenti possono essere integrati nei programmi di presentazione o essere servizi separati, e la qualità dei risultati varia tra strumenti. Il tempo risparmiato sull'impaginazione conviene investirlo dove l'AI non può sostituirci del tutto: nella scelta del messaggio e nella verifica dei contenuti.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiRepeat", head: "Documenti in presentazioni", body: "Relazione in slide, procedura in diagramma" },
      { icon: "FiGrid", head: "Organizzare le informazioni", body: "Struttura, priorità, sequenza" },
      { icon: "FiShare2", head: "Schemi e diagrammi", body: "Processi, organigrammi, linee del tempo" },
      { icon: "FiUsers", head: "Adattare ai destinatari", body: "Direzione, team, formazione" },
      { icon: "FiEye", head: "Chiarezza e qualità visiva", body: "Titoli efficaci, testi brevi, gerarchia" },
      { icon: "FiClock", head: "Meno impaginazione", body: "La parte più meccanica del lavoro" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Il tempo risparmiato sull'impaginazione si investe nel messaggio e nella verifica dei contenuti.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Esempio: dal documento alle slide", "Un esempio dimostrativo fittizio. A sinistra l'estratto di un documento interno strutturato, con una proposta di nuovo processo per la gestione dei resi; numeri e date sono inventati. A destra le tre slide che ne ricava una buona trasformazione. La prima mette in evidenza il problema con un solo numero, il tempo medio di chiusura, invece di ripetere tutto il paragrafo. La seconda trasforma la proposta in una sequenza di tre passaggi, più facile da ricordare. La terza riunisce tempi e rischi, perché chi decide deve vederli insieme. È il valore dell'AI in questo lavoro: scegliere che cosa evidenziare, sintetizzare, dare forma visiva. Il controllo è altrettanto semplice: i numeri, 1.200 resi e 9 giorni, coincidono con il documento? Le fasi e le date sono le stesse? I rischi ci sono ancora, o sono spariti nella sintesi? Un errore tipico, da far cercare ai partecipanti, sarebbe una slide che mostra la proposta senza i rischi: più convincente, ma incompleta. In aula: dare lo stesso estratto allo strumento autorizzato e confrontare il risultato con questa struttura.");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 3.7, 3.1, "Documento (estratto fittizio)", "Gestione dei resi: proposta di un nuovo processo.\nOggi i resi arrivano via email e sono registrati a mano: nel 2025 sono stati 1.200, con un tempo medio di chiusura di 9 giorni.\nProposta: modulo online unico, verifica automatica della garanzia, notifica al cliente a ogni passaggio.\nTempi: pilota a gennaio su una linea di prodotto, estensione a marzo.\nRischi: formazione del personale, integrazione con il gestionale.", { fontSize: 10, fill: C.background2 });
    arrow(s, 4.27, 2.55, 0.28);
    thumb(s, 4.65, 1.15, 4.85, 0.95, "SLIDE 1", "Il problema");
    txt(s, "9 giorni", { x: 6.7, y: 1.2, w: 1.4, h: 0.5, fontSize: 22, bold: true, color: C.accent5, valign: "middle" });
    txt(s, "tempo medio di chiusura, 1.200 resi nel 2025", { x: 6.7, y: 1.68, w: 2.7, h: 0.35, fontSize: 9, color: C.text2 });
    thumb(s, 4.65, 2.2, 4.85, 0.95, "SLIDE 2", "La proposta in tre passi");
    ["Modulo online", "Garanzia verificata", "Cliente informato"].forEach((t, i) => chip(s, 6.6 + i * 0.97, 2.42, 0.9, 0.5, t, { fill: C.accent6, fontSize: 8 }));
    thumb(s, 4.65, 3.25, 4.85, 0.95, "SLIDE 3", "Tempi e rischi");
    chip(s, 6.6, 3.33, 1.35, 0.36, "Gen: pilota", { fill: C.accent6, fontSize: 9 });
    chip(s, 8.05, 3.33, 1.35, 0.36, "Mar: estensione", { fill: C.accent6, fontSize: 9 });
    txt(s, "Rischi: formazione, integrazione", { x: 6.6, y: 3.75, w: 2.8, h: 0.35, fontSize: 9, bold: true, color: C.accent5 });
    banner(s, 4.4, "Esempio fittizio. Controllo: numeri, fasi e rischi coincidono con il documento?", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Adattare ai destinatari", "Una delle possibilità più utili è adattare lo stesso contenuto a destinatari diversi, come visto nel Tema 8 per i testi. Da un unico documento di progetto si ottengono una presentazione sintetica per la direzione, con obiettivi, costi e rischi; una presentazione operativa per il gruppo di lavoro, con attività, tempi e responsabilità; un materiale formativo per chi userà il risultato, con istruzioni ed esempi; una scheda per la comunicazione interna, breve e visiva. L'AI è molto efficace in questo lavoro, che a mano richiederebbe di ripartire più volte da capo, e permette di tenere allineate le versioni quando il documento cambia. Ogni adattamento seleziona, ed è giusto che lo faccia: per questo ogni versione si controlla pensando al suo destinatario. La versione per la direzione contiene ancora i rischi principali? Quella formativa ha semplificato una regola fino a renderla scorretta?");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 2.6, 2.6, "Un documento di progetto", "Obiettivi, attività, tempi, costi, rischi, responsabilità, istruzioni.", { fontSize: 12, fill: C.accent6 });
    arrow(s, 3.2, 2.3, 0.35);
    const v = [["Direzione", "Obiettivi, costi, rischi"], ["Gruppo di lavoro", "Attività, tempi, responsabilità"], ["Formazione", "Istruzioni ed esempi"], ["Comunicazione interna", "Breve e visiva"]];
    v.forEach((e, i) => {
      const y = 1.15 + i * 0.66;
      shapeBox(s, 3.7, y, 5.8, 0.58, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 3.9, y, w: 2.3, h: 0.58, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 6.2, y, w: 3.2, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 3.95, "Ogni versione seleziona: si controlla pensando al suo destinatario.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Coerenza tra testo e visivo", "Quando un documento diventa un materiale visivo, possono nascere incoerenze tra ciò che dice il testo e ciò che mostra la grafica. L'esempio fittizio mostra un'infografica generata da un rapporto: il testo dice che le vendite online sono il 35 per cento del totale, ma la fetta 'online' del grafico sembra metà. Succede quando un grafico decorativo viene disegnato invece che calcolato dai dati. Altri errori tipici: icone che suggeriscono un significato diverso, come un consumatore con il carrello per indicare i clienti business; schemi semplificati fino a invertire due fasi; numeri arrotondati in modo diverso dal documento. Sono errori facili da correggere quando si sa dove guardarli. Il controllo consiste nel confrontare ogni elemento visivo con il contenuto di partenza: numeri, proporzioni, sequenze, icone. Quando possibile, conviene far costruire i grafici dai dati, come grafici veri e modificabili, invece che come immagini.");
    opTag(s, 2);
    docBox(s, 0.5, 1.15, 3.6, 1.5, "Rapporto (esempio fittizio)", "Le vendite online sono il 35% del totale.", { fontSize: 14, fill: C.accent6 });
    s.addChart(pres.charts.PIE, [{ name: "Canali", labels: ["Online", "Negozi"], values: [50, 50] }], { x: 4.3, y: 1.1, w: 2.0, h: 1.6, chartColors: [HEX.a5, HEX.a3], showLegend: false, showValue: false, showTitle: false, dataBorder: { pt: 1, color: "FFFFFF" } });
    txt(s, "Infografica: la fetta 'online' sembra metà", { x: 6.4, y: 1.2, w: 3.1, h: 1.4, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    const e = ["Proporzioni disegnate, non calcolate", "Icone che suggeriscono altro", "Schemi semplificati fino all'errore", "Numeri diversi dal documento"];
    e.forEach((t, i) => chip(s, 0.5 + i * 2.3, 2.9, 2.15, 0.7, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 3.85, "Confrontare numeri, proporzioni, sequenze e icone con il documento. Meglio grafici costruiti dai dati.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Checklist per le presentazioni AI", "Una checklist unica per valutare un materiale prodotto con l'AI, da applicare prima di usarlo o diffonderlo. La premessa è una sola: con l'AI una veste grafica curata costa pochissimo, e una presentazione ben impaginata ispira fiducia anche quando contiene errori, soprattutto perché le slide si guardano in fretta, in riunione. Per questo la cura visiva non basta, e l'attenzione va spostata sulle voci della lista. Il messaggio: lo si capisce in pochi secondi? Il destinatario: linguaggio, dettaglio e tono sono adatti? L'accuratezza: numeri, nomi, date e citazioni corrispondono alla fonte? La completezza: ci sono i rischi, le condizioni, i dati sfavorevoli? La coerenza: testo, grafici e icone dicono la stessa cosa? La sequenza: l'ordine delle slide costruisce un ragionamento, senza conclusioni non sostenute? La sobrietà: niente decorazioni o testo superflui? Le immagini: appropriate, coerenti con l'identità visiva, senza persone reali o marchi altrui non autorizzati, dichiarate se generate e realistiche? Le tre voci evidenziate, accuratezza, completezza e coerenza, sono quelle che la cura estetica non garantisce. Bastano pochi minuti, ed è anche un buon criterio per decidere quanto intervenire su una bozza.");
    opTag(s, 2);
    txt(s, "Una veste curata non garantisce accuratezza, completezza e coerenza: la lista sposta lì l'attenzione.", { x: 0.5, y: 1.08, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text2 });
    const c = [["Messaggio", "Chiaro in pochi secondi?"], ["Destinatario", "Linguaggio, dettaglio, tono adatti?"], ["Accuratezza", "Numeri, nomi, date come nella fonte?", 1], ["Completezza", "Rischi, condizioni, dati sfavorevoli?", 1], ["Coerenza", "Testo, grafici, icone dicono lo stesso?", 1], ["Sequenza", "L'ordine costruisce un ragionamento?"], ["Sobrietà", "Niente decorazioni e testo superflui?"], ["Immagini", "Appropriate, dichiarate se generate?"]];
    c.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.55 + row * 0.74;
      shapeBox(s, x, y, 4.4, 0.66, e[2] ? C.accent6 : C.background2, e[0]);
      s.addShape(pres.shapes.RECTANGLE, { x: x + 0.15, y: y + 0.2, w: 0.26, h: 0.26, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 }, objectName: "casella " + e[0] });
      txt(s, e[0], { x: x + 0.55, y, w: 1.5, h: 0.66, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: x + 2.0, y, w: 2.3, h: 0.66, fontSize: 11, color: C.text1, valign: "middle" });
    });
    txt(s, "Pochi minuti per intercettare la maggior parte dei problemi, e decidere quanto intervenire sulla bozza.", { x: 0.5, y: 4.5, w: 9, h: 0.45, fontSize: 13, italic: true, bold: true, color: C.accent1 });
  }

  // =====================================================================
  section("10.7 Trasformazioni");
  divider("10.7", "Integrazione e trasformazione tra modalità", "Convertire tra modalità rende i contenuti più accessibili, rapidi e riutilizzabili, quando la fedeltà è controllata", "Nei sottotemi precedenti abbiamo incontrato molte trasformazioni: dall'audio alla trascrizione, dal testo all'immagine, dal documento alla presentazione. In questo sottotema, da comprendere e sperimentare, le guardiamo insieme, come principio generale. Che cosa si guadagna trasformando un contenuto da una modalità all'altra? Come si combinano più fonti? Come si rendono i contenuti accessibili su scala? E come si controlla, in modo rapido, che il significato sia rimasto lo stesso? Il confine con il 10.4: lì le capacità vocali, qui le trasformazioni tra modalità in generale. Concetto chiave: il valore delle conversioni dipende dalla loro utilità e dalla fedeltà delle informazioni, non soltanto dalla comodità o dalla rapidità del processo. Esercizio suggerito: far percorrere ai partecipanti una catena di tre trasformazioni, da un breve audio fittizio a una trascrizione, a un riassunto, a una slide, e confrontare il risultato finale con l'audio originale, elencando che cosa si è perso o alterato.");
  {
    const s = content("La mappa delle conversioni", "La tabella mostra le conversioni più utili nel lavoro, con un esempio e il valore che portano. Audio in testo: la trascrizione di una riunione, che rende il contenuto ricercabile e condivisibile. Documento in presentazione: una relazione trasformata in slide, per comunicare in sintesi. Testo in audio: una procedura letta da una voce sintetica, da ascoltare in mobilità o per chi fatica a leggere. Video in sintesi: un webinar ridotto ai punti chiave, con un grande risparmio di tempo. Immagine in testo: la descrizione di una foto o i dati estratti da una schermata, che diventano riutilizzabili. Più fonti in un nuovo contenuto: registrazione, slide e documento combinati in un verbale completo. Ogni conversione rende un contenuto più accessibile, più rapido da consumare o adatto a un altro canale. E ogni conversione sceglie che cosa portare nella nuova forma e che cosa lasciare indietro, perché le modalità non sono equivalenti: un'immagine contiene informazioni che un testo non descrive del tutto, e un testo contiene precisazioni che un'immagine non mostra.");
    opTag(s, 2);
    table(s, [["Conversione", "Esempio", "Valore"],
      ["Audio in testo", "Trascrizione di una riunione", "Ricercabile, condivisibile"],
      ["Documento in presentazione", "Relazione trasformata in slide", "Comunicare in sintesi"],
      ["Testo in audio", "Procedura letta da una voce", "Ascolto in mobilità, accessibilità"],
      ["Video in sintesi", "Webinar in punti chiave", "Risparmio di tempo"],
      ["Immagine in testo", "Dati da una foto o una schermata", "Informazioni riutilizzabili"],
      ["Più fonti in un contenuto", "Registrazione, slide e documento", "Un verbale completo"]],
      { y: 1.15, colW: [2.7, 3.3, 3.0], rowH: 0.4, fontSize: 12, blankCorner: false, accentCol: 2 });
    banner(s, 4.1, "Ogni conversione sceglie che cosa portare nella nuova forma: il valore sta nel renderla più utile senza perderne il senso.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Le catene di trasformazione", "Spesso le trasformazioni non sono singole, ma formano catene. L'esempio è tipico: una riunione viene registrata; la registrazione viene trascritta; la trascrizione riassunta; il riassunto trasformato in slide per la direzione; le slide lette da una voce sintetica in un video di aggiornamento. Ogni passaggio è utile e, preso da solo, abbastanza affidabile. Ma ogni passaggio seleziona: la trascrizione perde il tono e le esitazioni, il riassunto le obiezioni minori, le slide le condizioni, il video la possibilità di rileggere. E gli errori si accumulano: un 'il budget dovrebbe bastare', detto con tono dubitativo, diventa nella trascrizione e nel riassunto 'il budget è sufficiente', poi un punto elenco nelle slide, poi un'affermazione nel video. Nessun errore di parola, ma il significato è cambiato. È il fenomeno del passaparola, applicato alle modalità. Due buone pratiche, semplici: accorciare le catene, partendo quando possibile dalla fonte originale invece che da una trasformazione intermedia; e, per i contenuti importanti, confrontare il risultato finale con la fonte, non solo con il passaggio precedente.");
    opTag(s, 2);
    const ch = ["Riunione", "Trascrizione", "Riassunto", "Slide", "Video"];
    const lost = ["", "Tono, esitazioni", "Obiezioni minori", "Condizioni", "Rileggibilità"];
    ch.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      chip(s, x, 1.2, 1.6, 0.7, t, { fill: i === 0 ? C.accent1 : C.accent6, color: i === 0 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 4) arrow(s, x + 1.62, 1.39, 0.2);
      if (i > 0) {
        txt(s, "Si perde:", { x, y: 1.98, w: 1.6, h: 0.25, fontSize: 9, color: C.text2, align: "center" });
        txt(s, lost[i], { x, y: 2.2, w: 1.6, h: 0.42, fontSize: 11, bold: true, color: C.accent5, align: "center" });
      }
    });
    docBox(s, 0.5, 2.75, 4.35, 1.0, "Detto (esempio fittizio)", "\"Sì... il budget dovrebbe bastare...\" (tono dubitativo)", { fontSize: 12, fill: C.accent6 });
    docBox(s, 5.15, 2.75, 4.35, 1.0, "Alla fine della catena", "\"Il budget è sufficiente.\"", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    chip(s, 0.5, 3.95, 4.4, 0.65, "Catene brevi: partire dalla fonte originale", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.95, 4.4, 0.65, "Confrontare il risultato finale con la fonte", { fill: C.background2, fontSize: 12 });
    txt(s, "Il passaparola delle modalità: ogni passaggio sembra ragionevole, ma il significato può cambiare.", { x: 0.5, y: 4.67, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Combinare più fonti", "Una forma particolarmente utile di trasformazione è creare un contenuto a partire da più fonti di natura diversa. Un verbale che combina la registrazione di una riunione, le slide proiettate e il documento discusso. Un materiale formativo che integra un video dimostrativo, il manuale e le domande frequenti. Un rapporto di sopralluogo che unisce fotografie, note vocali e una lista di controllo. Il valore è grande, perché ogni fonte compensa i limiti delle altre: le slide chiariscono a che cosa si riferiva una frase della registrazione, le fotografie documentano ciò che le note descrivono, e il lavoro di composizione che prima richiedeva ore si riduce a una revisione. L'attenzione specifica riguarda i collegamenti: il sistema può associare un commento alla slide sbagliata o una foto alla nota di un'altra stanza, e il risultato, ben integrato e scorrevole, non mostra le giunture tra le fonti. La soluzione è semplice: per i contenuti importanti, chiedere che ogni affermazione indichi la fonte da cui proviene, così il controllo diventa rapido. È il principio di tracciabilità visto nel Tema 8, applicato alle modalità.");
    opTag(s, 2);
    const f = [["FiMic", "Registrazione"], ["FiLayout", "Slide"], ["FiFileText", "Documento"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.15 + i * 0.85;
      shapeBox(s, 0.5, y, 2.6, 0.72, C.background2, f[i][1]);
      await iconCircle(s, 0.62, y + 0.12, 0.48, f[i][0]);
      txt(s, f[i][1], { x: 1.2, y, w: 1.8, h: 0.72, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
    }
    arrow(s, 3.2, 2.0, 0.4);
    shapeBox(s, 3.75, 1.15, 2.2, 2.4, C.accent1, "verbale");
    txt(s, "Un verbale integrato", { x: 3.85, y: 1.15, w: 2.0, h: 2.4, fontSize: 15, bold: true, color: C.background1, align: "center", valign: "middle" });
    await card(s, 6.2, 1.15, 3.3, 2.4, { icon: "FiLink", head: "Collegamenti da verificare", headSize: 14, bodySize: 12, iconBg: C.accent5, body: "Un commento sulla slide sbagliata, una foto con la nota di un'altra stanza." });
    banner(s, 3.8, "Ogni fonte compensa i limiti delle altre. Per i contenuti importanti: ogni affermazione indichi la sua fonte.", { h: 0.75, fontSize: 13 });
    txt(s, "Tracciabilità: ogni elemento del risultato deve poter essere ricondotto alla sua fonte.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Conversioni per l'accessibilità", "Le conversioni tra modalità sono anche la chiave dell'accessibilità su scala. Nel 10.4 l'abbiamo vista per l'audio; qui la estendiamo a tutte le modalità. Un contenuto disponibile in una sola modalità esclude chi non può usarla; disponibile in più modalità, include. Le conversioni più utili: testi alternativi per le immagini; sottotitoli e trascrizioni per audio e video; versioni audio e versioni semplificate dei documenti; descrizioni testuali di grafici e diagrammi; traduzioni. L'AI rende queste conversioni molto più rapide ed economiche, e quindi possibili su tutto un archivio: tutti i video formativi sottotitolati, tutte le immagini della intranet con un testo alternativo. È un'opportunità concreta per una comunicazione aziendale più inclusiva. Perché funzioni davvero, conviene un controllo mirato sui contenuti importanti: un testo alternativo generico, come 'immagine di un grafico', non aiuta, e uno sbagliato, come una descrizione che inverte una tendenza, arriva proprio a chi non può verificarlo.");
    opTag(s, 2);
    table(s, [["Contenuto originale", "Conversione accessibile", "Per chi"],
      ["Immagine", "Testo alternativo, descrizione", "Chi non vede"],
      ["Audio e video", "Sottotitoli, trascrizione", "Chi non sente, luoghi rumorosi"],
      ["Documento", "Versione audio, versione semplificata", "Chi fatica a leggere"],
      ["Grafico o diagramma", "Descrizione testuale", "Chi non vede"],
      ["Qualsiasi contenuto", "Traduzione", "Chi non conosce la lingua"]],
      { y: 1.15, colW: [2.6, 3.4, 3.0], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 3.85, "Accessibilità su tutto l'archivio, a costi bassi. Un controllo mirato evita che un errore arrivi a chi non può verificarlo.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Controllare con la fonte originale", "Ogni passaggio tra formati può introdurre tre tipi di variazione, che qui si presentano in forme specifiche. Omissioni: ciò che la nuova modalità non esprime si perde, come il tono di una frase nella trascrizione o una condizione scritta in piccolo che non entra nell'infografica. Reinterpretazioni: la conversione sceglie una lettura, come un'immagine generata da una descrizione ambigua o una sintesi vocale che con l'intonazione trasforma una domanda in un'affermazione. Alterazioni: il contenuto cambia, come un numero letto male in una schermata o un dettaglio aggiunto in un'immagine generata. Il controllo non richiede di rifare tutto il lavoro: si basa sulla fonte originale e su pochi passaggi. Primo, identificare gli elementi critici che devono sopravvivere: numeri, nomi, impegni, condizioni, il messaggio principale. Secondo, controllarli nel risultato uno per uno. Terzo, tornare all'originale solo per quei passaggi: riascoltare il punto in cui si parla dell'importo, guardare il dettaglio nella foto, rileggere la conclusione del documento. Quarto, quando serve, coinvolgere chi conosce l'originale: chi era presente, chi ha scritto il documento. Il criterio del sottotema: una conversione rapida ma infedele non fa risparmiare tempo, lo sposta su chi dovrà correggerne le conseguenze.");
    opTag(s, 2);
    txt(s, "Che cosa può cambiare", { x: 0.5, y: 1.08, w: 4.35, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const t = [["Omissioni", "Il tono, una condizione in piccolo"], ["Reinterpretazioni", "Una lettura scelta tra più possibili"], ["Alterazioni", "Un numero letto male, un dettaglio aggiunto"]];
    t.forEach((e, i) => {
      const y = 1.45 + i * 0.9;
      shapeBox(s, 0.5, y, 4.35, 0.8, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y: y + 0.06, w: 4.0, h: 0.32, fontSize: 13, bold: true, color: C.accent5 });
      txt(s, e[1], { x: 0.7, y: y + 0.38, w: 4.0, h: 0.36, fontSize: 12, color: C.text1 });
    });
    txt(s, "Come controllare con la fonte originale", { x: 5.15, y: 1.08, w: 4.35, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    numList(s, ["Individuare gli elementi critici", "Controllarli nel risultato, uno per uno", "Tornare all'originale solo per quei punti", "Coinvolgere chi conosce l'originale"], { x: 5.15, w: 4.35, y: 1.45, h: 0.6, fontSize: 12 });
    banner(s, 4.25, "Una conversione rapida ma infedele non fa risparmiare tempo: lo sposta su chi dovrà correggerla.", { h: 0.7, fontSize: 13 });
  }

  // =====================================================================
  section("10.8 Autenticità e affidabilità");
  divider("10.8", "Limiti, autenticità e affidabilità", "Distinguere realismo, provenienza e accuratezza permette di usare con fiducia i contenuti multimodali", "Ultimo sottotema, di consapevolezza critica. Con la generazione di immagini, voci e video realistici, ciò che sembra reale e ciò che è reale non coincidono più automaticamente. Questo non rende sospetto ogni contenuto: chiede di saper porre le domande giuste. In questo sottotema vediamo gli usi legittimi e i rischi dei contenuti sintetici, la distinzione tra realismo, autenticità e accuratezza, gli strumenti di provenienza, le contromisure organizzative contro le frodi, gli obblighi di trasparenza dell'AI Act nella loro portata effettiva, i diritti su immagini e voci, e la supervisione proporzionata. La verifica forense tecnica è solo da accennare. Gli errori tipici dei contenuti multimodali sono stati trattati nei sottotemi in cui nascono e non li ripetiamo. Concetto chiave: distinguere realismo, provenienza e accuratezza è essenziale per usare in modo critico, e con fiducia, i contenuti multimodali. Esercizio suggerito: presentare uno scenario fittizio di richiesta urgente via messaggio vocale da parte di un dirigente e discutere in gruppo quali verifiche fare e quali procedure aziendali le rendono possibili.");
  {
    const s = content("Contenuti sintetici: usi legittimi e rischi", "I contenuti sintetici realistici sono immagini, audio e video generati o modificati dall'AI in modo da sembrare registrazioni della realtà. Si parla di deepfake quando rappresentano in modo realistico persone, luoghi o eventi che non esistono o non sono accaduti così, per esempio una persona reale che dice cose mai dette. Le stesse tecnologie hanno molti usi legittimi e utili: video formativi con presentatori virtuali, doppiaggio e adattamento in più lingue, voci sintetiche per l'accessibilità, compresa la possibilità di restituire una voce a chi l'ha persa, prototipi ed effetti per la comunicazione, satira e finzione dichiarate. Il criterio è il consenso delle persone rappresentate e la trasparenza verso chi guarda. Gli usi dannosi esistono e vanno conosciuti: frodi con voce o volto imitati, disinformazione, danni alla reputazione. In ambito aziendale il rischio più concreto è la frode che imita una persona conosciuta. Due casi riportati dalla stampa: nel 2019 l'amministratore di un'azienda energetica britannica trasferì circa 220.000 euro dopo una telefonata in cui la voce del superiore era stata imitata; nel 2024, nella sede di Hong Kong di una multinazionale, un dipendente trasferì l'equivalente di circa 25 milioni di dollari dopo una videochiamata con colleghi ricreati artificialmente. Lo schema è sempre simile: richiesta urgente, persona di fiducia, canale che sembra sicuro. Le contromisure sono nella slide 'Difendersi dalle frodi'.");
    opTag(s, 1);
    await card(s, 0.5, 1.15, 5.4, 2.45, { icon: "FiCheckCircle", head: "Usi legittimi", headSize: 15, bodySize: 11, fill: C.accent6,
      body: bullets(["Formazione e presentatori virtuali", "Doppiaggio e adattamento in più lingue", "Accessibilità, anche restituire una voce", "Prototipi, effetti, comunicazione creativa", "Satira e finzione dichiarate"], { space: 3 }) });
    await card(s, 6.1, 1.15, 3.4, 2.45, { icon: "FiAlertTriangle", head: "Usi dannosi", headSize: 15, bodySize: 11, iconBg: C.accent5,
      body: bullets(["Frodi con voce o volto imitati", "Disinformazione", "Danni alla reputazione"], { space: 3 }) });
    shapeBox(s, 0.5, 3.75, 9.0, 1.2, C.text1, "casi");
    txt(s, "Casi riportati dalla stampa", { x: 0.75, y: 3.8, w: 8.5, h: 0.3, fontSize: 12, bold: true, color: C.accent6 });
    txt(s, bullets(["2019: voce di un superiore imitata al telefono, circa 220.000 euro trasferiti", "2024: videochiamata con colleghi ricreati, circa 25 milioni di dollari trasferiti"], { space: 2 }), { x: 0.75, y: 4.1, w: 8.5, h: 0.52, fontSize: 11, color: C.background1 });
    txt(s, "Criterio per gli usi legittimi: consenso delle persone e trasparenza verso chi guarda.", { x: 0.75, y: 4.62, w: 8.5, h: 0.28, fontSize: 11, italic: true, bold: true, color: C.accent3 });
  }
  {
    const s = content("Realismo, autenticità, accuratezza", "Il cuore del sottotema: tre caratteristiche che nel linguaggio comune si confondono. Il realismo: il contenuto appare plausibile, sembra reale; un'immagine sintetica può somigliare in tutto a una fotografia. L'autenticità: l'origine del contenuto è accertabile; un video ha una provenienza documentata, chi l'ha girato, quando, dove, con quale dispositivo. L'accuratezza: le informazioni corrispondono ai fatti o alla fonte; una descrizione riporta fedelmente quanto documentato. Le tre caratteristiche sono indipendenti. Un'immagine sintetica può essere realistica senza essere autentica come testimonianza di un evento. Una registrazione autentica può contenere affermazioni false: è vero che quella persona le ha dette, ma ciò che ha detto può essere sbagliato. Una presentazione professionale può riportare dati inesatti. La somiglianza con la realtà, da sola, non dimostra origine, autenticità o verità. Davanti a un contenuto multimodale che conta, le tre domande vanno poste separatamente: sembra reale? Da dove viene? Ciò che mostra è vero? Per la maggior parte dei contenuti quotidiani la risposta è rapida; per quelli usati come prova o per decisioni importanti merita più tempo.");
    opTag(s, -1);
    table(s, [["Caratteristica", "Significato", "Esempio"],
      ["Realismo", "Il contenuto appare plausibile", "Un'immagine sintetica somiglia a una fotografia"],
      ["Autenticità", "L'origine è effettivamente accertabile", "Un video ha una provenienza documentata"],
      ["Accuratezza", "Corrisponde ai fatti o alla fonte", "Una descrizione riporta fedelmente quanto documentato"]],
      { y: 1.15, colW: [2.0, 3.2, 3.8], rowH: 0.5, fontSize: 12, blankCorner: false });
    const e = ["Realistica ma non autentica: un'immagine sintetica", "Autentica ma non accurata: una registrazione con affermazioni false", "Professionale ma non accurata: una presentazione con dati inesatti"];
    e.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.25, 2.86, 0.75, t, { fill: C.accent6, fontSize: 11 }));
    banner(s, 4.2, "Tre domande separate: sembra reale? Da dove viene? Ciò che mostra è vero?", { h: 0.7, fontSize: 15 });
  }
  {
    const s = content("Provenienza e credenziali digitali", "Se il realismo non basta, l'autenticità si accerta con la provenienza: la storia documentata di un contenuto, da chi l'ha creato a come è arrivato a noi. Esistono strumenti tecnici che aiutano, in rapida diffusione. I metadati, informazioni incorporate nei file come data, dispositivo, posizione; utili, ma facili da modificare o rimuovere. Le filigrane digitali, inserite da molti sistemi di generazione nei contenuti che producono, spesso invisibili; con l'AI Act la marcatura leggibile dalle macchine diventa un obbligo per i fornitori di sistemi generativi, ma le filigrane possono essere alterate. Le credenziali di contenuto, come quelle dello standard C2PA, che registrano in modo verificabile origine e modifiche di un file; sempre più adottate da produttori di fotocamere, software e piattaforme, non ancora ovunque. Le etichette applicate dalle piattaforme ai contenuti generati. Anche etichette e metadati vanno interpretati: indicano come un contenuto è stato prodotto, non se ciò che mostra è vero, e l'assenza di un'etichetta non prova che un contenuto sia autentico. La verifica forense tecnica è solo da accennare. Per l'utente la verifica più efficace è spesso organizzativa: risalire alla fonte, chiedere conferma attraverso un canale indipendente, confrontare con altre fonti.");
    opTag(s, -1);
    const t = [["Metadati", "Data, dispositivo, posizione", "Facili da modificare o rimuovere"], ["Filigrane digitali", "Marcatura dei contenuti generati", "Possono essere alterate"], ["Credenziali di contenuto (C2PA)", "Origine e modifiche verificabili", "In diffusione, non ancora ovunque"], ["Etichette delle piattaforme", "Segnalano contenuti generati", "L'assenza non prova l'autenticità"]];
    table(s, [["Strumento", "Che cosa offre", "Limite"]].concat(t), { y: 1.15, colW: [3.0, 3.0, 3.0], rowH: 0.42, fontSize: 12, blankCorner: false });
    banner(s, 3.4, "Etichette e metadati dicono come è stato prodotto un contenuto, non se ciò che mostra è vero.", { h: 0.75, fontSize: 13 });
    txt(s, "Verifica più efficace per l'utente", { x: 0.5, y: 4.25, w: 3.0, h: 0.6, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
    chip(s, 3.5, 4.25, 1.9, 0.6, "Risalire alla fonte", { fill: C.accent6, fontSize: 11 });
    chip(s, 5.5, 4.25, 2.0, 0.6, "Canale indipendente", { fill: C.accent6, fontSize: 11 });
    chip(s, 7.6, 4.25, 1.9, 0.6, "Altre fonti", { fill: C.accent6, fontSize: 11 });
  }
  {
    const s = content("Difendersi dalle frodi", "Contro le frodi basate su contenuti sintetici la difesa più efficace non è tecnica, ma organizzativa, ed è alla portata di ogni azienda. Riconoscere a occhio o a orecchio un deepfake di buona qualità è sempre più difficile, e gli strumenti di rilevamento automatico non sono infallibili: conviene quindi che le decisioni importanti non dipendano dal solo riconoscimento di una voce o di un volto. Le contromisure. Verifica su un canale indipendente: davanti a una richiesta insolita, specialmente di pagamenti, credenziali o dati riservati, richiamare la persona a un numero noto, non a quello fornito nel messaggio, o confermare di persona. Procedure robuste: autorizzazioni a più firme, controlli incrociati, regole che valgono anche per le richieste del vertice. Attenzione a urgenza e segretezza, i due ingredienti tipici delle frodi, perché impediscono la verifica. Domande o parole di controllo concordate per le situazioni delicate. Segnalazione alla sicurezza aziendale in caso di dubbio, anche se poi la richiesta si rivela autentica. Nessuno dovrebbe sentirsi in imbarazzo nel verificare una richiesta del proprio superiore: è una procedura, non una mancanza di fiducia.");
    opTag(s, -1);
    await iconGrid(s, [
      { icon: "FiPhone", head: "Canale indipendente", body: "Richiamare a un numero noto, confermare di persona" },
      { icon: "FiUsers", head: "Procedure robuste", body: "Più firme, controlli incrociati, nessuna eccezione" },
      { icon: "FiClock", head: "Urgenza e segretezza", body: "Gli ingredienti tipici delle frodi" },
      { icon: "FiKey", head: "Domande di controllo", body: "Concordate per le situazioni delicate" },
      { icon: "FiFlag", head: "Segnalare", body: "In caso di dubbio, alla sicurezza aziendale" },
      { icon: "FiShield", head: "Non solo riconoscere", body: "Le decisioni non dipendono da voce e volto", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Verificare una richiesta del proprio superiore è una procedura, non una mancanza di fiducia.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Trasparenza e AI Act", "La trasparenza riguarda anche i contenuti che produciamo noi. Un'azienda può comunicare in modo fuorviante senza volerlo: immagini generate che sembrano fotografie reali di prodotti o sedi, 'clienti' o 'dipendenti' inesistenti in finte testimonianze, ritocchi che migliorano un prodotto oltre il reale, voci e presentatori sintetici non dichiarati, ricostruzioni presentate come documentazione. Il problema non è l'AI, ma la differenza tra ciò che il contenuto sembra e ciò che è. Su questo l'articolo 50 dell'AI Act, applicabile dal 2 agosto 2026, fissa obblighi precisi, che è importante non generalizzare. Chi fornisce sistemi che interagiscono con le persone, come chatbot e assistenti, deve far sapere che si sta interagendo con un'AI, salvo che sia evidente. Chi fornisce sistemi generativi deve marcare i contenuti prodotti in modo leggibile dalle macchine; sono escluse, tra l'altro, le funzioni di supporto all'editing che non alterano in modo sostanziale il contenuto; per i sistemi già sul mercato prima del 2 agosto 2026 il Regolamento (UE) 2026/1744 concede tempo fino al 2 dicembre 2026. Chi usa un sistema per creare deepfake, cioè immagini, audio o video che ritraggono in modo realistico persone, luoghi o eventi, deve dichiararlo; per opere evidentemente artistiche, creative, satiriche o di finzione l'obbligo si limita a una dichiarazione che non ostacoli la fruizione dell'opera. Chi pubblica testi generati per informare il pubblico su questioni di interesse pubblico deve dichiararlo, salvo che il testo abbia avuto una revisione umana e qualcuno ne abbia la responsabilità editoriale. L'articolo prevede anche l'informazione alle persone esposte a sistemi di riconoscimento delle emozioni o di categorizzazione biometrica, e alcune eccezioni per attività di contrasto autorizzate dalla legge. Ne segue che non ogni contenuto generato con l'AI va etichettato: un'illustrazione per una slide interna non è un deepfake. Policy aziendali, piattaforme e altre norme possono però chiedere di più. La Commissione europea ha pubblicato linee guida sull'articolo 50 e, il 10 giugno 2026, un codice di buone pratiche sulla trasparenza dei contenuti generati, ad adesione volontaria. Dettagli e casi particolari sono trattati nei Temi 17 e 18. Date e testi verificati a ottobre 2026 sulle pagine ufficiali della Commissione e sul Regolamento 2026/1744 (considerando 38); da ricontrollare prima di ogni edizione.");
    opTag(s, [1, 2]);
    table(s, [["Chi", "Che cosa chiede l'art. 50", "Da quando"],
      ["Fornitori di chatbot e assistenti", "Informare che si interagisce con un'AI, salvo sia evidente", "2 agosto 2026"],
      ["Fornitori di sistemi generativi", "Marcatura leggibile dalle macchine; escluso l'editing di supporto", "2 agosto 2026; 2 dicembre 2026 se già sul mercato"],
      ["Chi crea deepfake", "Dichiararlo; per opere artistiche o satiriche, senza ostacolarne la fruizione", "2 agosto 2026"],
      ["Chi pubblica testi generati di interesse pubblico", "Dichiararlo, salvo revisione umana con responsabilità editoriale", "2 agosto 2026"]],
      { y: 1.15, colW: [2.5, 4.4, 2.1], rowH: 0.56, fontSize: 11, blankCorner: false, accentCol: 1 });
    banner(s, 4.1, "Non ogni contenuto generato va etichettato: un'illustrazione per una slide interna non è un deepfake. Policy e piattaforme possono chiedere di più.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Diritti su contenuti, immagini, voci", "Introduciamo il tema dei diritti senza analisi normativa, che appartiene ai Temi 17 e 18, perché i partecipanti sappiano riconoscere quando serve un approfondimento. I contenuti di partenza: usare come base un'immagine, un video, una musica o un testo di cui non si hanno i diritti non diventa lecito perché passa attraverso un sistema AI. I contenuti generati: la titolarità dei contenuti prodotti con l'AI è una questione ancora in evoluzione, e le condizioni d'uso degli strumenti variano; conviene conoscerle per gli strumenti autorizzati. L'immagine delle persone: usare il volto di una persona, anche modificato o in un contenuto generato, richiede di regola il suo consenso. La voce delle persone: anche la voce è un elemento dell'identità personale; riprodurla con il consenso apre usi utili, come un formatore che parla in più lingue, imitarla senza consenso è problematico oltre che rischioso. Gli stili e le opere riconoscibili: imitare lo stile di un artista vivente, riprodurre personaggi, marchi, opere protette. Il comportamento pratico è semplice: nei casi dubbi, specialmente per contenuti destinati all'esterno, chiedere prima a chi in azienda si occupa di questi aspetti.");
    opTag(s, [1, 2]);
    await iconGrid(s, [
      { icon: "FiFile", head: "Contenuti di partenza", body: "Senza diritti non diventano leciti passando per l'AI" },
      { icon: "FiFileText", head: "Contenuti generati", body: "Titolarità in evoluzione, condizioni d'uso variabili" },
      { icon: "FiUser", head: "Immagine delle persone", body: "Di regola serve il consenso" },
      { icon: "FiMic", head: "Voce delle persone", body: "Con consenso usi utili; senza, da evitare" },
      { icon: "FiStar", head: "Stili e opere riconoscibili", body: "Artisti viventi, personaggi, marchi" },
      { icon: "FiHelpCircle", head: "Nei casi dubbi", body: "Chiedere prima a chi se ne occupa in azienda", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    txt(s, "Un'introduzione, senza analisi normativa: indica quando serve un approfondimento.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Verifica e supervisione proporzionate", "L'ultimo punto: la verifica proporzionata all'uso, come in tutto il percorso. È ciò che permette di sfruttare il risparmio di tempo dell'AI multimodale senza rinunciare all'affidabilità. Tre livelli. Per uso personale o esplorativo, come capire una schermata, farsi un'idea di un video, generare un concept, basta un controllo di plausibilità. Per uso interno, come verbali, materiali formativi, presentazioni interne, si controllano gli elementi critici sull'originale, come numeri, nomi, impegni e attribuzioni, e si fa rivedere a chi conosce il contenuto. Per uso esterno o decisionale, come comunicazione al pubblico, materiali per clienti, contenuti usati come prova o documentazione, decisioni basate su immagini o registrazioni, serve una verifica completa: provenienza accertata, confronto sistematico con l'originale, diritti verificati, trasparenza sui contenuti sintetici e coinvolgimento delle funzioni competenti. Due fattori alzano il livello: la presenza di persone reali e la possibilità che il contenuto venga scambiato per una rappresentazione della realtà. Il principio dei controlli proporzionati è sviluppato nel Tema 7.");
    opTag(s, -1);
    const lv = [["Personale o esplorativo", "Schermate, concept, farsi un'idea", "Controllo di plausibilità", C.background2, C.text1], ["Interno", "Verbali, formazione, presentazioni interne", "Elementi critici sull'originale, revisione di chi conosce", C.accent6, C.text1], ["Esterno o decisionale", "Pubblico, clienti, prove, decisioni", "Provenienza, confronto sistematico, diritti, trasparenza", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.9;
      shapeBox(s, 0.5, y, 9.0, 0.8, l[3], l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.3, h: 0.8, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 3.0, y, w: 2.9, h: 0.8, fontSize: 12, color: l[4], valign: "middle" });
      txt(s, l[2], { x: 6.0, y, w: 3.35, h: 0.8, fontSize: 12, bold: true, color: l[4], valign: "middle" });
    });
    txt(s, "Alzano il livello", { x: 0.5, y: 3.95, w: 2.3, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.8, 3.95, 3.25, 0.55, "Persone reali", { fill: C.background2, fontSize: 12 });
    chip(s, 6.2, 3.95, 3.3, 0.55, "Può sembrare la realtà", { fill: C.background2, fontSize: 12 });
    txt(s, "Controlli proporzionati: il risparmio di tempo resta, l'affidabilità pure.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Che cosa portiamo a casa", "Un unico riepilogo delle competenze del modulo. Al termine, il partecipante è in grado di: spiegare che cos'è l'AI multimodale e come combinare più modalità in un'unica interazione; usare l'AI per leggere schermate, diagrammi, fotografie e documenti visivi, sapendo dove controllare; generare e modificare immagini per formazione, comunicazione e prototipi, procedendo per affinamenti; valutare quando un'immagine è pronta all'uso, da rifinire o da affidare a professionisti; ottenere trascrizioni, verbali e traduzioni con una revisione mirata su nomi, numeri e impegni; sfruttare sintesi video, video formativi e adattamenti multilingue; trasformare documenti in presentazioni chiare, applicando una checklist di controllo; convertire contenuti tra modalità, anche per rendere la comunicazione accessibile; distinguere realismo, autenticità e accuratezza; proporzionare verifiche, trasparenza e rispetto dei diritti all'uso del contenuto. Suggerimento: chiedere ai partecipanti quale di queste competenze applicheranno per prima, e su quale attività.");
    const r = ["Spiegare l'AI multimodale e combinare più modalità", "Leggere schermate, diagrammi, foto e documenti visivi", "Generare e modificare immagini per affinamenti", "Valutare se un'immagine è pronta, da rifinire o da affidare", "Trascrizioni, verbali e traduzioni con revisione mirata", "Sintesi video, video formativi, versioni multilingue", "Dal documento a presentazioni chiare e controllate", "Convertire tra modalità, anche per l'accessibilità", "Distinguere realismo, autenticità e accuratezza", "Proporzionare verifiche, trasparenza e diritti"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.74;
      shapeBox(s, x, y, 4.4, 0.66, row % 2 ? C.background1 : C.background2, "competenza " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.66, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.66, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Una scheda pratica", "Il modulo tradotto in una scheda pratica, organizzata per operazione e scritta come azioni da fare con l'AI. Interpretare: mostrare invece di descrivere, con schermate, foto e documenti; controllare dettagli e numeri critici sull'originale; ricordare che contesto e provenienza li aggiungiamo noi. Generare: usare la generazione per esplorare e produrre varianti; affinare per passi invece di ripartire da zero; rispettare identità visiva, diritti e persone, e dichiarare i contenuti sintetici che potrebbero sembrare reali. Trasformare: partire dalla fonte originale; controllare gli elementi critici; usare le conversioni per rendere i contenuti accessibili su scala. Valutare: porre separatamente le tre domande su realismo, autenticità e accuratezza; verificare le richieste insolite su canali indipendenti; proporzionare i controlli all'uso. E sempre: strumenti autorizzati, persone coinvolte informate, regole aziendali seguite. Il messaggio centrale del tema: l'AI multimodale amplia il modo in cui comprendiamo, creiamo e trasformiamo contenuti; con controlli mirati, il risparmio di tempo diventa valore affidabile.");
    const f = [["Interpretare", ["Mostrare invece di descrivere", "Dettagli e numeri sull'originale", "Contesto e provenienza li aggiungiamo noi"], C.background2], ["Generare", ["Esplorare e produrre varianti", "Affinare per passi", "Marchio, diritti, persone; dichiarare"], C.accent6], ["Trasformare", ["Partire dalla fonte originale", "Elementi critici controllati", "Accessibilità su scala"], C.background2], ["Valutare", ["Reale? Da dove? Vero?", "Canali indipendenti", "Controlli proporzionati"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: strumenti autorizzati, persone coinvolte informate, regole aziendali seguite.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto. Con il Tema 10 completiamo l'esplorazione delle modalità: testi e documenti nel Tema 8, dati nel Tema 9, immagini, audio e video in questo tema. Il Tema 11 è dedicato ad assistenti, agenti e automazioni: come l'AI evolve da strumento conversazionale a componente operativa di attività e processi. Vedremo assistenti con strumenti e integrazioni, agenti AI, la differenza tra automazione tradizionale e intelligente, i livelli di autonomia e di supervisione umana. Molte capacità viste qui, come la trascrizione di riunioni, la lettura di schermate, la trasformazione di documenti, diventeranno componenti di flussi di lavoro più ampi, e i principi di verifica e di fedeltà conteranno ancora di più, perché gli errori potranno propagarsi in azioni e non solo in contenuti. Nel percorso, il Tema 12 riguarda la creazione di valore in azienda e il Tema 14 dati e conoscenza aziendale. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi e documenti\nTema 9: dati e analisi\nTema 10: multimodalità (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.9, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 11: Assistenti, agenti e automazioni", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Dallo strumento conversazionale alla componente operativa", { x: 5.4, y: 2.38, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.0, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 12: AI e creazione di valore in azienda", "Tema 14: dati e conoscenza aziendale"], { space: 5 }), { x: 5.4, y: 3.35, w: 3.9, h: 1.2, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Per l'articolo 50 dell'AI Act: obblighi, eccezioni e date verificati a ottobre 2026 sulla pagina ufficiale della Commissione europea dedicata agli obblighi di trasparenza dell'articolo 50 (digital-strategy.ec.europa.eu, domande frequenti) e sul Regolamento (UE) 2026/1744, pubblicato nella Gazzetta Ufficiale dell'Unione il 24 luglio 2026, in vigore dal 27 luglio 2026; il periodo transitorio di quattro mesi per la marcatura dei sistemi già sul mercato è nel considerando 38. Il codice di buone pratiche sulla trasparenza dei contenuti generati dall'AI risulta pubblicato il 10 giugno 2026 sulla pagina ufficiale della Commissione, con adesione volontaria; la Commissione ha pubblicato anche le linee guida sull'articolo 50. I due casi di frode sono stati riportati dalla stampa internazionale: conviene ricontrollarne i dettagli prima di citarli in aula. Le capacità degli strumenti multimodali, in particolare la generazione di immagini, video e voci, evolvono molto rapidamente: prima di ogni edizione è consigliabile aggiornare esempi e dimostrazioni con gli strumenti autorizzati in azienda. Tutti gli esempi del modulo, compresi i tre esempi dimostrativi, sono fittizi; le illustrazioni dell'esempio sulle immagini sono schematiche e non sono output di strumenti reali.");
    const src = [
      "Regolamento (UE) 2024/1689 (AI Act), art. 50: obblighi di trasparenza, applicabili dal 2 agosto 2026.",
      "Regolamento (UE) 2026/1744 (GUUE 24 luglio 2026): marcatura dei sistemi già sul mercato entro il 2 dicembre 2026 (considerando 38).",
      "Commissione europea: linee guida sull'art. 50 e codice di buone pratiche sulla trasparenza dei contenuti generati (10 giugno 2026, adesione volontaria), digital-strategy.ec.europa.eu.",
      "C2PA, Coalition for Content Provenance and Authenticity: standard per le credenziali di contenuto (c2pa.org).",
      "Frode vocale ai danni di un'azienda energetica britannica, The Wall Street Journal, agosto 2019. Frode in videochiamata presso la sede di Hong Kong di Arup, CNN e Financial Times, 2024.",
      "Esempi di schermate, trascrizioni, immagini, documenti e slide: fittizi.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 8 }), { x: 1.3, y: 1.15, w: 8.2, h: 3.4, fontSize: 12, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.6, w: 8.2, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }

  await pres.writeFile({ fileName: "Tema10_AI_multimodale_contenuti_REV.pptx" });
  await applyTheme("Tema10_AI_multimodale_contenuti_REV.pptx", THEME);
  console.log("done");
})();
