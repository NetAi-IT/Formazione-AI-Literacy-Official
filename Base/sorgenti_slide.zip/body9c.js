
  // =====================================================================
  section("9.6 Previsioni");
  divider("9.6", "AI, analisi predittiva e simulazioni", "Una previsione è una stima condizionata da dati, ipotesi e metodo, non una descrizione certa del futuro", "Finora abbiamo guardato a ciò che è successo. Con questo sottotema guardiamo avanti: previsioni, stime, proiezioni, simulazioni, scenari. Il documento di perimetro gli assegna priorità media e un livello di conoscenza: non entriamo nei modelli statistici o di Machine Learning, di cui il Tema 2 ha dato i principi, ma vogliamo che i partecipanti sappiano che cosa è una previsione, su che cosa si basa, quanto è incerta, e come distinguere una previsione calcolata da una supposizione generata dal modello. E vogliamo preservare con cura una distinzione: quella tra andamento storico osservato e previsione futura.");
  {
    const s = content("Descrivere e prevedere", "Riprendiamo i quattro tipi di analisi dell'introduzione. L'analisi descrittiva lavora su ciò che è accaduto: i dati sono osservazioni, e il risultato, se i dati e i calcoli sono corretti, è un fatto. L'analisi predittiva lavora su ciò che potrebbe accadere: il risultato è una stima, che dipende dai dati storici, dal metodo scelto e dalle ipotesi su come il futuro assomiglierà al passato. La differenza è fondamentale, e il documento chiede di preservarla con cura: un andamento storico osservato non è una previsione. Dire che le vendite sono cresciute del 5 per cento all'anno negli ultimi tre anni è una descrizione; dire che cresceranno del 5 per cento il prossimo anno è una previsione, che presuppone che le condizioni restino simili. Il passaggio tra le due è spesso implicito, e l'AI lo compie facilmente: chiedendo 'come andranno le vendite?', il sistema può semplicemente prolungare la tendenza osservata, presentandola come una previsione. Un'estrapolazione lineare è il metodo previsionale più semplice, e spesso il più fragile: funziona finché nulla cambia.");
    phaseTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiClock", head: "Analisi descrittiva", headSize: 16, bodySize: 13,
      body: bullets(["Che cosa è accaduto", "Dati osservati", "Il risultato è un fatto, se dati e calcoli sono corretti"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiTrendingUp", head: "Analisi predittiva", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Che cosa potrebbe accadere", "Dati storici, metodo, ipotesi", "Il risultato è una stima"], { space: 5 }) });
    shapeBox(s, 0.5, 3.7, 9.0, 1.25, C.text1, "esempio");
    txt(s, [{ text: "Descrizione: ", options: { bold: true, color: C.accent6 } }, { text: "le vendite sono cresciute del 5% all'anno negli ultimi tre anni.", options: { color: C.background1, breakLine: true } }, { text: "Previsione: ", options: { bold: true, color: C.accent6 } }, { text: "cresceranno del 5% il prossimo anno, se le condizioni restano simili.", options: { color: C.background1 } }], { x: 0.75, y: 3.7, w: 8.5, h: 1.25, fontSize: 14, valign: "middle", paraSpaceAfter: 6 });
  }
  {
    const s = content("Modelli previsionali e dati storici", "Una breve introduzione ai modelli previsionali, senza entrare nella tecnica. Un modello previsionale è un metodo che, a partire da dati storici, produce una stima di valori futuri o sconosciuti. I più semplici prolungano una tendenza, eventualmente tenendo conto della stagionalità. Altri usano più variabili: per esempio stimano le vendite a partire da prezzi, promozioni, giorni festivi, condizioni meteo. Altri ancora, basati su Machine Learning, apprendono relazioni complesse da grandi quantità di dati, come visto nel Tema 2. Tutti condividono un'ipotesi di fondo: che le relazioni osservate in passato continuino a valere nel periodo previsto. Questo spiega perché i modelli previsionali funzionano bene in contesti stabili e falliscono davanti a cambiamenti di contesto: una crisi, un nuovo concorrente, un cambio normativo, una pandemia. Spiega anche perché la qualità e la quantità dei dati storici sono decisive: con due anni di dati non si stima bene una stagionalità annuale, con dati di un periodo anomalo si apprendono relazioni anomale. Quando l'AI propone una previsione, la prima domanda è: su quali dati storici si basa, e quanto il futuro previsto assomiglia al passato osservato?");
    phaseTag(s, 2);
    const m = [["Prolungare una tendenza", "Con o senza stagionalità", C.background2], ["Più variabili", "Prezzi, promozioni, festività, meteo", C.accent6], ["Machine Learning", "Relazioni complesse apprese da molti dati", C.background2]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.25, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.4, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.65, fontSize: 12, color: C.text2 });
    });
    shapeBox(s, 0.5, 2.6, 9.0, 0.85, C.text1, "ipotesi di fondo");
    txt(s, [{ text: "Ipotesi comune: ", options: { bold: true, color: C.accent6 } }, { text: "le relazioni del passato continuano a valere. Funziona in contesti stabili, fallisce davanti ai cambiamenti.", options: { color: C.background1 } }], { x: 0.7, y: 2.6, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
    chip(s, 0.5, 3.65, 4.4, 0.6, "Due anni di dati: stagionalità poco stimabile", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.65, 4.4, 0.6, "Dati di un periodo anomalo: relazioni anomale", { fill: C.background2, fontSize: 12 });
    txt(s, "Prima domanda: su quali dati si basa, e quanto il futuro assomiglia al passato?", { x: 0.5, y: 4.45, w: 9, h: 0.45, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Stime, proiezioni, incertezza", "Ogni previsione è incerta, e una previsione ben fatta lo dichiara. Il grafico fittizio in slide mostra una serie storica di vendite e una proiezione per i sei mesi successivi, con tre linee: una stima centrale e un intervallo tra un valore basso e uno alto. L'intervallo si allarga man mano che ci si allontana dall'ultimo dato osservato: più lontano è il futuro, più è incerto. Questo è il modo corretto di presentare una previsione. Il modo scorretto, molto frequente, è presentare solo la stima centrale, con precisione apparente: 'a giugno venderemo 1.247 pezzi'. Un numero così preciso suggerisce una certezza che non esiste. Quando l'AI produce una previsione, conviene chiedere sempre l'intervallo di incertezza e il metodo usato per calcolarlo; diffidare dei numeri troppo precisi; e ricordare che anche l'intervallo dipende dalle ipotesi: se il contesto cambia, il valore reale può uscire dall'intervallo. Per le decisioni, l'incertezza è un'informazione preziosa, non un difetto della previsione: decidere sapendo che le vendite saranno tra 900 e 1.400 pezzi porta a scelte diverse, più prudenti e più flessibili, rispetto a sapere che saranno 1.247.");
    phaseTag(s, 2);
    const lab = ["G", "F", "M", "A", "M", "G", "L", "A", "S", "O", "N", "D", "G", "F", "M", "A", "M", "G"];
    const hist = [900, 940, 980, 1010, 1000, 1050, 1080, 1020, 1100, 1130, 1150, 1180];
    const n = null;
    const histS = hist.concat([n, n, n, n, n, n]);
    const c = [1180, 1200, 1215, 1230, 1240, 1250, 1260], lo = [1180, 1140, 1100, 1060, 1010, 960, 910], hi = [1180, 1260, 1330, 1400, 1470, 1540, 1610];
    const pad = [n, n, n, n, n, n, n, n, n, n, n];
    lineChart(s, lab, [{ name: "Storico", values: histS, color: HEX.dk1 }, { name: "Stima centrale", values: pad.concat(c), color: HEX.a1 }, { name: "Valore basso", values: pad.concat(lo), color: HEX.a2 }, { name: "Valore alto", values: pad.concat(hi), color: HEX.a2 }], { x: 0.5, y: 1.1, w: 5.6, h: 3.1, min: 800, max: 1700, legend: true, title: "Vendite e proiezione a sei mesi (esempio fittizio)" });
    shapeBox(s, 6.35, 1.15, 3.15, 1.35, C.background2, "scorretto");
    txt(s, "Precisione apparente", { x: 6.5, y: 1.22, w: 2.9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    txt(s, "\"A giugno venderemo 1.247 pezzi\"", { x: 6.5, y: 1.6, w: 2.9, h: 0.8, fontSize: 13, italic: true, color: C.text1 });
    shapeBox(s, 6.35, 2.65, 3.15, 1.55, C.accent6, "corretto");
    txt(s, "Stima con incertezza", { x: 6.5, y: 2.72, w: 2.9, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
    txt(s, "\"Tra 900 e 1.600 pezzi, stima centrale 1.250, se il contesto resta simile\"", { x: 6.5, y: 3.1, w: 2.9, h: 1.0, fontSize: 12, italic: true, color: C.text1 });
    banner(s, 4.4, "Più lontano è il futuro, più è incerto. L'incertezza è un'informazione per decidere, non un difetto.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Simulazioni, scenari, what-if", "Accanto alle previsioni, l'AI può supportare simulazioni e analisi di scenario, che rispondono a domande diverse. Una previsione chiede: che cosa succederà? Uno scenario chiede: che cosa succederebbe se? L'analisi what-if, cioè 'che cosa succede se', modifica una o più variabili e ne calcola le conseguenze: se aumentiamo il prezzo del 5 per cento e i volumi calano del 3, che cosa succede al margine? Le analisi di scenario costruiscono alcune combinazioni coerenti di ipotesi, di solito uno scenario prudente, uno centrale e uno favorevole. La tabella fittizia in slide mostra un esempio. Il valore di questi strumenti è che rendono esplicite le ipotesi e mostrano quanto il risultato dipende da esse: se in tutti gli scenari il progetto è conveniente, la decisione è robusta; se dipende dallo scenario, bisogna capire quale ipotesi conta di più. L'AI è molto efficace nel costruire questi modelli, anche in un foglio di calcolo. Ma le ipotesi di partenza, come l'elasticità dei volumi al prezzo o la crescita del mercato, sono scelte, e il sistema può proporle senza basi solide. Una simulazione è affidabile quanto le sue ipotesi.");
    phaseTag(s, 2);
    table(s, [["Ipotesi", "Prudente", "Centrale", "Favorevole"],
      ["Aumento prezzo", "+5%", "+5%", "+5%"],
      ["Variazione volumi", "-8%", "-3%", "0%"],
      ["Costi unitari", "+4%", "+2%", "+1%"],
      ["Margine risultante", "-3%", "+4%", "+8%"]],
      { y: 1.15, colW: [3.0, 2.0, 2.0, 2.0], rowH: 0.45, fontSize: 13, blankCorner: false, accentCol: 2 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.43, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    chip(s, 0.5, 3.75, 4.4, 0.6, "Previsione: che cosa succederà?", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.75, 4.4, 0.6, "Scenario: che cosa succederebbe se?", { fill: C.accent6, fontSize: 12 });
    txt(s, "Il risultato cambia segno tra gli scenari: la decisione dipende dalla reazione dei volumi. Una simulazione è affidabile quanto le sue ipotesi.", { x: 0.5, y: 4.45, w: 9, h: 0.5, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Le ipotesi alla base", "Ogni previsione e ogni simulazione si basa su ipotesi, spesso implicite. Renderle esplicite è il primo passo per valutarle. Le ipotesi tipiche riguardano quattro aspetti. La continuità: le tendenze e le relazioni del passato continueranno? Il contesto: mercato, concorrenza, norme, prezzi delle materie prime resteranno simili? I comportamenti: come reagiranno clienti, concorrenti, fornitori alle nostre scelte? I dati: sono rappresentativi del periodo da prevedere, o includono periodi anomali? Quando si chiede una previsione all'AI, una buona pratica è chiedere esplicitamente l'elenco delle ipotesi su cui si basa, e per ciascuna quanto è solida e quanto il risultato ne dipende. Spesso emerge che il risultato dipende in modo decisivo da una o due ipotesi, e che proprio quelle sono le più incerte. Su queste conviene concentrare la discussione, magari con chi conosce il mercato o il processo. L'esempio della slide precedente lo mostra: la convenienza dell'aumento di prezzo dipende quasi interamente dall'ipotesi sulla reazione dei volumi, e quella ipotesi non viene dai dati, ma da una valutazione.");
    phaseTag(s, 2);
    await iconGrid(s, [
      { icon: "FiArrowRight", head: "Continuità", body: "Tendenze e relazioni del passato continueranno?" },
      { icon: "FiGlobe", head: "Contesto", body: "Mercato, concorrenza, norme, materie prime" },
      { icon: "FiUsers", head: "Reazioni", body: "Come reagiranno clienti, concorrenti, fornitori?" },
      { icon: "FiDatabase", head: "Dati", body: "Rappresentativi del periodo da prevedere?" },
    ], 4, { y: 1.2, h: 1.9, headSize: 14, bodySize: 12 });
    banner(s, 3.35, "Chiedere l'elenco delle ipotesi: quanto è solida ciascuna, e quanto il risultato ne dipende?", { h: 0.7, fontSize: 14 });
    txt(s, "Spesso il risultato dipende da una o due ipotesi, e proprio quelle sono le più incerte: lì va concentrata la discussione, con chi conosce il mercato.", { x: 0.5, y: 4.2, w: 9, h: 0.7, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Calcolata o supposta?", "Il sottotema chiede di distinguere le previsioni calcolate dalle supposizioni generate dal modello. È l'equivalente, per il futuro, dell'integrazione A del 9.3. Una previsione calcolata è il risultato di un metodo applicato ai dati: un modello statistico, un foglio di calcolo con ipotesi esplicite, un codice eseguito. Si può ripetere, controllare, modificare cambiando le ipotesi. Una supposizione generata è un numero o una tendenza che il modello linguistico produce come testo, sulla base della sua conoscenza generale e del contesto della conversazione: 'il mercato dovrebbe crescere del 7-8 per cento nei prossimi anni'. Può essere ragionevole, può riprendere stime pubblicate, ma non è il risultato di un calcolo sui nostri dati, e spesso non è possibile sapere da dove venga. Il rischio è che le supposizioni generate vengano trattate come previsioni, e magari inserite in un piano o in un business plan. I segnali per distinguerle sono gli stessi del 9.3: c'è un metodo dichiarato? Ci sono i dati e i passaggi? Si può ripetere il calcolo? Se la risposta è no, il numero va trattato come un'opinione da verificare, non come una previsione.");
    phaseTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiCpu", head: "Previsione calcolata", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Un metodo applicato ai nostri dati", "Ipotesi esplicite", "Ripetibile e modificabile"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiMessageSquare", head: "Supposizione generata", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Testo prodotto dalla conoscenza generale", "'Il mercato dovrebbe crescere del 7-8%'", "Origine spesso non ricostruibile"], { space: 5 }) });
    txt(s, "Per distinguerle", { x: 0.5, y: 3.75, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 4.1, 2.9, 0.55, "Un metodo dichiarato?", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 4.1, 2.9, 0.55, "Dati e passaggi visibili?", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 4.1, 2.9, 0.55, "Il calcolo si può ripetere?", { fill: C.background2, fontSize: 12 });
    txt(s, "Se no: un'opinione da verificare, non una previsione.", { x: 0.5, y: 4.72, w: 9, h: 0.3, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Validare le previsioni", "Come si valuta l'affidabilità di una previsione? L'ultimo punto del sottotema riguarda la validazione. Il metodo più semplice e più potente è il confronto con il passato: si applica il metodo previsionale a un periodo passato, usando solo i dati precedenti, e si confronta la previsione con ciò che è effettivamente accaduto. Per esempio, si usano i dati fino a dicembre di due anni fa per prevedere l'anno scorso, e si misura l'errore. Se il metodo avrebbe sbagliato del 20 per cento sull'anno scorso, non c'è motivo di pensare che sarà più preciso sul prossimo. Questo controllo si può chiedere all'AI quando costruisce una previsione. Altri elementi di validazione: confrontare la previsione con metodi diversi, con stime indipendenti, con il giudizio di chi conosce il mercato; verificare che sia plausibile rispetto ai vincoli reali, come la capacità produttiva o la dimensione del mercato. E, nel tempo, monitorare: confrontare regolarmente le previsioni con i risultati effettivi, per capire quanto il metodo è affidabile e quando va rivisto. La modellazione avanzata e le metriche statistiche di errore sono solo da accennare: per le previsioni critiche servono competenze specialistiche.");
    phaseTag(s, 2);
    const st = [["Dati fino a due anni fa", C.background2, C.text1], ["Previsione dell'anno scorso", C.accent6, C.text1], ["Confronto con il reale", C.accent1, C.background1]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      chip(s, x, 1.2, 2.86, 0.75, e[0], { fill: e[1], color: e[2], fontSize: 13 });
      if (i < 2) arrow(s, x + 2.88, 1.42, 0.17);
    });
    txt(s, "Se avrebbe sbagliato del 20% sul passato, perché dovrebbe essere più preciso sul futuro?", { x: 0.5, y: 2.05, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent5, align: "center" });
    await iconGrid(s, [
      { icon: "FiColumns", head: "Confrontare", body: "Metodi diversi, stime indipendenti, esperti" },
      { icon: "FiShield", head: "Vincoli reali", body: "Capacità produttiva, dimensione del mercato" },
      { icon: "FiActivity", head: "Monitorare", body: "Previsioni contro risultati, nel tempo" },
    ], 3, { y: 2.65, h: 1.45, headSize: 14, bodySize: 12 });
    txt(s, "Modellazione avanzata e metriche di errore: solo accennate. Per previsioni critiche servono specialisti.", { x: 0.5, y: 4.35, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Una previsione è una stima condizionata da dati, ipotesi e metodo, non una descrizione certa del futuro.", "Sottotema 9.6  ·  AI, analisi predittiva e simulazioni", "Concetto chiave del sottotema 9.6. L'AI può produrre previsioni, proiezioni, simulazioni e analisi di scenario, rendendo accessibili strumenti prima riservati agli specialisti. Ma l'andamento storico non è una previsione, ogni previsione dipende dalla continuità tra passato e futuro, l'incertezza va dichiarata e usata, le ipotesi vanno rese esplicite, e le supposizioni generate dal modello non vanno confuse con previsioni calcolate. La validazione sul passato è il controllo più semplice e più utile. Esercizio suggerito: chiedere all'AI una previsione su un dataset fittizio, poi chiedere l'elenco delle ipotesi, l'intervallo di incertezza e un test sul periodo precedente, e discutere quanto cambia la fiducia nella previsione.");

  // =====================================================================
  section("9.7 Interpretazione e decisioni");
  divider("9.7", "Interpretazione e decisioni", "La solidità di una decisione non dipende solo dalla correttezza aritmetica degli indicatori", "Arriviamo alla fase finale del processo: dai risultati alle decisioni. In questo sottotema, di consapevolezza decisionale, vediamo come l'AI può aiutare a interpretare i risultati, formulare ipotesi, confrontare alternative e valutare scenari, e dove si collocano i suoi limiti. Due integrazioni sono centrali: dati corretti che portano a conclusioni sbagliate, già vista nel 9.4, e il rischio di decisioni apparentemente oggettive, cioè raccomandazioni numeriche che incorporano assunzioni discutibili. E una distinzione: tra analisi e raccomandazione, tra evidenza quantitativa e giudizio manageriale.");
  {
    const s = content("Dai risultati al significato", "Un'analisi produce risultati; interpretarli significa attribuire loro un significato per una decisione. L'AI può supportare l'interpretazione in diversi modi. Identificare le informazioni rilevanti: in un report con venti indicatori, quali sono quelli che contano per la decisione da prendere? Analizzare possibili cause e conseguenze: perché il margine è calato? Che cosa succederà se il trend continua? Generare ipotesi: quali spiegazioni alternative sono compatibili con i dati? Identificare informazioni mancanti: che cosa servirebbe sapere per decidere con più sicurezza? Su quest'ultimo punto l'AI è particolarmente utile, come visto nel Tema 7 per le omissioni: chiedere 'quali dati mancano per valutare questa decisione?' porta spesso a domande che non ci si era posti. La differenza rispetto alle fasi precedenti è che qui non ci sono più risposte corrette in senso aritmetico. Un'interpretazione può essere più o meno fondata, più o meno completa, più o meno prudente, e dipende dal contesto, dagli obiettivi e dai valori di chi decide. L'AI propone interpretazioni plausibili; la loro adeguatezza al caso concreto va valutata da chi conosce quel caso.");
    phaseTag(s, 3);
    await iconGrid(s, [
      { icon: "FiFilter", head: "Informazioni rilevanti", body: "Quali indicatori contano per questa decisione?" },
      { icon: "FiGitBranch", head: "Cause e conseguenze", body: "Perché è successo? Che cosa succederà?" },
      { icon: "FiHelpCircle", head: "Ipotesi alternative", body: "Quali spiegazioni sono compatibili con i dati?" },
      { icon: "FiSearch", head: "Informazioni mancanti", body: "Che cosa servirebbe sapere per decidere meglio?", fill: C.accent6 },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Qui non ci sono più risposte corrette in senso aritmetico. Un'interpretazione è più o meno fondata, completa, prudente.", { h: 0.7, fontSize: 13 });
    txt(s, "L'AI propone interpretazioni plausibili; la loro adeguatezza la valuta chi conosce il caso.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Confrontare alternative e scenari", "Un uso prezioso dell'AI nel supporto decisionale è il confronto strutturato tra alternative. Data una decisione, per esempio scegliere tra tre fornitori, tra due localizzazioni, tra mantenere o cambiare un processo, il sistema può costruire una matrice con criteri, valori, vantaggi e rischi di ciascuna alternativa; può combinare dati quantitativi, come costi e tempi, con elementi qualitativi, come affidabilità o rischio di dipendenza; può valutare ogni alternativa nei diversi scenari visti nel 9.6. Questo aiuta a non dimenticare criteri, a rendere esplicito il confronto e a discuterlo. Ma un confronto tra alternative richiede scelte che non sono tecniche. Quali criteri considerare? Quanto pesa ciascuno? Il costo conta più della flessibilità? Quale livello di rischio è accettabile? Se si chiede all'AI di scegliere l'alternativa migliore, il sistema dovrà assegnare dei pesi, e lo farà secondo criteri plausibili ma non necessariamente i nostri. Il risultato è una classifica che sembra oggettiva, ma che dipende da pesi che nessuno ha deciso esplicitamente. La pratica corretta è definire i criteri e i pesi, o almeno vedere quelli usati dal sistema, e verificare quanto la classifica cambia modificandoli.");
    phaseTag(s, 3);
    table(s, [["Criterio", "Peso", "Fornitore A", "Fornitore B", "Fornitore C"],
      ["Costo", "?", "Migliore", "Medio", "Peggiore"],
      ["Tempi di consegna", "?", "Medio", "Migliore", "Medio"],
      ["Affidabilità", "?", "Medio", "Medio", "Migliore"],
      ["Rischio di dipendenza", "?", "Alto", "Basso", "Medio"]],
      { y: 1.15, colW: [2.6, 1.0, 1.8, 1.8, 1.8], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.3, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    banner(s, 3.6, "Chi ha deciso i pesi? Una classifica che sembra oggettiva può dipendere da pesi che nessuno ha scelto esplicitamente.", { h: 0.75, fontSize: 13 });
    txt(s, "Definire criteri e pesi, o vedere quelli usati, e verificare quanto la classifica cambia modificandoli.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }
  {
    const s = content("Evidenza e giudizio", "Il sottotema chiede di distinguere l'evidenza quantitativa dal giudizio manageriale. L'evidenza quantitativa è ciò che i dati dicono: il margine del prodotto A è sceso del 4 per cento, il tempo medio di risposta è di due giorni, il 60 per cento dei clienti persi aveva avuto un reclamo. Il giudizio manageriale è ciò che chi decide aggiunge: la conoscenza del mercato, della strategia, delle persone; la valutazione di elementi non misurati, come la reputazione, le relazioni, le opportunità future; i valori e le priorità dell'organizzazione; la responsabilità per le conseguenze. Una buona decisione combina le due cose. Il rischio dell'analisi assistita dall'AI è di sbilanciare la combinazione in due direzioni opposte. Da un lato, dare troppo peso ai numeri, perché sono disponibili, precisi e presentati in modo convincente, trascurando ciò che non è misurato: 'non è nei dati' non significa 'non conta'. Dall'altro, usare i numeri solo per giustificare una decisione già presa, scegliendo l'analisi che la sostiene: con l'AI è facile produrre rapidamente molte analisi e scegliere quella più comoda. In entrambi i casi l'evidenza smette di informare la decisione.");
    phaseTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiBarChart2", head: "Evidenza quantitativa", headSize: 15, bodySize: 12,
      body: bullets(["Ciò che i dati dicono", "Margini, tempi, percentuali", "Precisa, ma parziale"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiUser", head: "Giudizio manageriale", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Mercato, strategia, persone", "Elementi non misurati, valori, priorità", "Responsabilità per le conseguenze"], { space: 4 }) });
    const r = [["Troppo peso ai numeri", "'Non è nei dati' non significa 'non conta'"], ["Numeri per giustificare", "Molte analisi rapide, si sceglie la più comoda"]];
    r.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 3.6, 4.35, 1.3, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 3.7, w: 3.95, h: 0.38, fontSize: 14, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.1, w: 3.95, h: 0.7, fontSize: 12, color: C.background1 });
    });
  }
  {
    const s = content("Analisi o raccomandazione", "Un'altra distinzione del sottotema: tra analisi e raccomandazione decisionale. Un'analisi descrive, spiega, stima: 'il prodotto A ha un margine inferiore del 4 per cento alla media, per l'aumento dei costi di trasporto'. Una raccomandazione dice che cosa fare: 'conviene eliminare il prodotto A dal catalogo'. Tra le due c'è un salto che richiede elementi che non sono nell'analisi: gli obiettivi dell'azienda, i vincoli, le alternative disponibili, gli effetti su altri prodotti e sui clienti, il rischio accettabile. Il prodotto A potrebbe essere poco redditizio ma necessario per mantenere clienti che acquistano anche prodotti molto redditizi. I sistemi AI tendono a produrre raccomandazioni anche quando non sono richieste, perché sono addestrati a essere utili e a concludere: un'analisi finisce spesso con 'si raccomanda di...'. Queste raccomandazioni sono formulate con sicurezza e appaiono come la conseguenza logica dei numeri, ma incorporano ipotesi su obiettivi e vincoli che il sistema non conosce. Conviene separare esplicitamente le due cose: chiedere prima l'analisi, poi, se utile, le opzioni possibili con vantaggi e rischi, e lasciare la raccomandazione a chi conosce obiettivi e vincoli.");
    phaseTag(s, 3);
    docBox(s, 0.5, 1.15, 4.0, 1.25, "Analisi", "Il prodotto A ha un margine inferiore del 4% alla media, per i costi di trasporto.", { fontSize: 13, fill: C.accent6 });
    arrow(s, 4.6, 1.6, 0.4);
    docBox(s, 5.1, 1.15, 4.4, 1.25, "Raccomandazione", "Conviene eliminare il prodotto A dal catalogo.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Il salto richiede elementi che non sono nell'analisi", { x: 0.5, y: 2.55, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const e = ["Obiettivi", "Vincoli", "Alternative", "Effetti su altri prodotti e clienti", "Rischio accettabile"];
    e.forEach((t, i) => chip(s, 0.5 + i * 1.82, 2.95, 1.7, 0.6, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 3.75, "I sistemi tendono a concludere con 'si raccomanda di...'. Chiedere prima l'analisi, poi le opzioni con vantaggi e rischi; la raccomandazione a chi conosce obiettivi e vincoli.", { h: 1.0, fontSize: 13 });
  }
  {
    const s = content("Il rischio di falsa oggettività", "L'integrazione D del tema: il rischio di decisioni apparentemente oggettive. L'esempio, proposto dal documento di perimetro, è questo: un sistema AI conclude che una categoria di clienti è meno redditizia. La conclusione sembra oggettiva, perché viene dai dati. Ma dipende da molte scelte analitiche. Come è stata definita la redditività: margine lordo, margine dopo i costi commerciali, valore nel tempo del cliente? Come sono stati attribuiti i costi: in proporzione al fatturato, al numero di ordini, al tempo dedicato? Quale periodo è stato considerato: un anno normale o un anno anomalo? Sono stati inclusi i costi indiretti, come assistenza e gestione dei resi? Il campione è rappresentativo? La tabella in slide mostra come, con gli stessi dati originali, scelte diverse possono portare a conclusioni diverse, persino opposte. Nessuna delle scelte è sbagliata in sé: sono scelte. Il problema nasce quando vengono fatte implicitamente, dal sistema o dall'analista, e il risultato viene presentato come un fatto. Il messaggio del documento: i dati non producono automaticamente decisioni oggettive; occorrono criteri, interpretazione e valutazione.");
    phaseTag(s, 3);
    docBox(s, 0.5, 1.12, 9.0, 0.62, "Conclusione del sistema (esempio fittizio)", "", { fontSize: 12 });
    txt(s, "La categoria di clienti B è meno redditizia.", { x: 4.2, y: 1.18, w: 5.2, h: 0.5, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
    table(s, [["Scelta analitica", "Opzione 1", "Opzione 2"],
      ["Definizione di redditività", "Margine lordo", "Valore del cliente nel tempo"],
      ["Attribuzione dei costi", "Per fatturato", "Per numero di ordini"],
      ["Periodo", "Ultimo anno (anomalo)", "Ultimi tre anni"],
      ["Costi indiretti", "Esclusi", "Inclusi"],
      ["Esito per la categoria B", "Meno redditizia", "Più redditizia"]],
      { y: 1.9, colW: [3.0, 3.0, 3.0], rowH: 0.38, fontSize: 12, blankCorner: false });
    banner(s, 4.35, "Gli stessi dati, scelte diverse, conclusioni opposte. I dati non producono automaticamente decisioni oggettive.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Assunzioni che sembrano fatti", "Generalizziamo l'esempio. Le raccomandazioni numeriche possono incorporare assunzioni discutibili, e non sono necessariamente adeguate al contesto: è ciò che il documento chiama rischio di considerare oggettive valutazioni basate su assunzioni. Le assunzioni più frequenti si nascondono in quattro punti. Nelle definizioni: che cosa si misura e come. Nei pesi: quanto conta ciascun criterio. Nei confini: quali costi, effetti, periodi e soggetti vengono considerati, e quali restano fuori. Negli obiettivi: che cosa si sta ottimizzando, se il margine di breve periodo, la crescita, la soddisfazione dei clienti, la riduzione del rischio. Ognuno di questi punti è una scelta legittima, ma è una scelta, e cambiarla cambia il risultato. Il pericolo specifico dell'AI è duplice. Il sistema fa queste scelte in modo implicito, scegliendo le opzioni più comuni. E presenta il risultato con un linguaggio e un formato che lo fanno apparire oggettivo: numeri precisi, tabelle ordinate, conclusioni nette. Domande utili: quali definizioni, pesi, confini e obiettivi sono stati usati? Chi li ha scelti? Che cosa cambierebbe con scelte diverse? Se la conclusione regge a scelte diverse, è robusta; se no, la decisione dipende dalle scelte, e queste vanno discusse.");
    phaseTag(s, 3);
    await iconGrid(s, [
      { icon: "FiBook", head: "Definizioni", body: "Che cosa si misura e come" },
      { icon: "FiSliders", head: "Pesi", body: "Quanto conta ciascun criterio" },
      { icon: "FiMaximize", head: "Confini", body: "Che cosa resta dentro e fuori" },
      { icon: "FiTarget", head: "Obiettivi", body: "Che cosa si sta ottimizzando" },
    ], 4, { y: 1.2, h: 1.6, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 3.0, 9.0, 0.85, C.background2, "domande");
    txt(s, "Quali scelte sono state fatte?   ·   Chi le ha fatte?   ·   Che cosa cambierebbe con scelte diverse?", { x: 0.7, y: 3.0, w: 8.6, h: 0.85, fontSize: 14, bold: true, color: C.accent1, valign: "middle", align: "center" });
    banner(s, 4.05, "Se la conclusione regge a scelte diverse, è robusta. Se no, la decisione dipende dalle scelte, e queste vanno discusse.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("La responsabilità resta umana", "L'ultimo punto del sottotema è la responsabilità umana nelle decisioni. È il principio che attraversa tutto il percorso, ripreso qui nella sua forma più concreta. Un'analisi assistita dall'AI può essere molto utile per decidere: rende disponibili più informazioni, più rapidamente, con confronti e scenari che prima richiedevano giorni. Ma la decisione resta di chi la prende, e con essa la responsabilità delle conseguenze. 'L'ha detto l'analisi' non è una giustificazione, così come non lo era 'l'ha detto il foglio di calcolo'. Questo ha tre implicazioni pratiche. Chi decide deve capire l'analisi su cui si basa, almeno nelle sue scelte principali: definizioni, ipotesi, limiti. Chi decide deve sapere quanto l'analisi è incerta, e tenerne conto. E chi decide deve poter spiegare la decisione, anche a chi la subisce, con argomenti che vanno oltre il risultato del sistema. Per le decisioni che riguardano le persone, come valutazioni, selezioni, assegnazioni, ci sono anche vincoli etici e normativi specifici, trattati nei Temi 17 e 18. Il concetto chiave del sottotema riassume tutto: la solidità di una decisione non dipende solo dalla correttezza aritmetica degli indicatori.");
    phaseTag(s, 3);
    shapeBox(s, 0.5, 1.15, 9.0, 1.0, C.text1, "principio");
    txt(s, "'L'ha detto l'analisi' non è una giustificazione, come non lo era 'l'ha detto il foglio di calcolo'.", { x: 0.75, y: 1.15, w: 8.5, h: 1.0, fontSize: 16, bold: true, color: C.background1, valign: "middle" });
    await iconGrid(s, [
      { icon: "FiEye", head: "Capire l'analisi", body: "Definizioni, ipotesi, limiti principali" },
      { icon: "FiActivity", head: "Conoscerne l'incertezza", body: "E tenerne conto nella decisione" },
      { icon: "FiMessageCircle", head: "Saper spiegare", body: "Con argomenti oltre il risultato del sistema" },
    ], 3, { y: 2.35, h: 1.5, headSize: 14, bodySize: 12 });
    txt(s, "Decisioni sulle persone (valutazioni, selezioni, assegnazioni): ci sono anche vincoli etici e normativi specifici.", { x: 0.5, y: 4.1, w: 9, h: 0.75, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("La solidità di una decisione non dipende solo dalla correttezza aritmetica degli indicatori.", "Sottotema 9.7  ·  Interpretazione e decisioni", "Concetto chiave del sottotema 9.7. L'AI può supportare l'interpretazione dei risultati, la generazione di ipotesi, l'individuazione di informazioni mancanti, il confronto tra alternative e scenari. Ma interpretare e decidere richiede criteri, pesi, obiettivi e conoscenza del contesto che non sono nei dati. L'analisi va distinta dalla raccomandazione, l'evidenza quantitativa dal giudizio manageriale, e le scelte analitiche implicite vanno rese esplicite, perché possono cambiare la conclusione pur con dati identici. La responsabilità della decisione resta umana. Esercizio suggerito: partire dall'esempio della redditività dei clienti, con un dataset fittizio, e far calcolare all'AI la redditività con due definizioni diverse, discutendo poi quale sia più adatta alla decisione da prendere.");

  // =====================================================================
  section("9.8 Limiti e affidabilità");
  divider("9.8", "Limiti e condizioni di affidabilità", "Un'analisi AI richiede controlli su dati, metodi e interpretazioni, proporzionati alle conseguenze dell'utilizzo", "Ultimo sottotema, da comprendere bene. Nei sottotemi precedenti abbiamo incontrato i limiti uno per uno, nel punto del processo in cui si presentano. Qui li riuniamo in un quadro complessivo, guardandoli dal punto di vista delle loro conseguenze sull'affidabilità. Due integrazioni si ritrovano qui: il calcolo verificabile, integrazione A, e la falsa oggettività, integrazione D. E il principio conclusivo, coerente con il Tema 7: la validazione proporzionata all'utilizzo previsto. Non ripetiamo i metodi generali di verifica: li applichiamo all'analisi dei dati.");
  {
    const s = content("Dove nascono gli errori", "Una mappa degli errori tipici dell'analisi assistita dall'AI, organizzata lungo il processo. Nei dati: dati incompleti o non rappresentativi del fenomeno, struttura interpretata in modo errato, come una colonna fraintesa o una riga di totale trattata come dato, definizioni diverse da quelle aziendali. Nelle elaborazioni: errori di calcolo, specialmente nei numeri generati senza codice; errori nelle trasformazioni, come unioni tra tabelle che duplicano o perdono righe; errori nelle aggregazioni, come medie di medie o somme di percentuali; mancanti trattati come zeri. Nell'analisi: relazioni casuali presentate come significative, conclusioni tratte da pochi dati, analisi prive di adeguato fondamento statistico. Nella rappresentazione: grafici incoerenti con i dati, periodi selezionati, commenti che vanno oltre i numeri. Nell'interpretazione: correlazioni lette come cause, stime e simulazioni confuse con dati reali, raccomandazioni basate su assunzioni implicite. La mappa mostra un punto importante: gli errori delle prime fasi si propagano a tutte le successive, e diventano più difficili da vedere man mano che il risultato si allontana dai dati di partenza.");
    phaseTag(s, 3);
    const m = [["Dati", ["Incompleti, non rappresentativi", "Struttura fraintesa", "Definizioni diverse"]], ["Elaborazioni", ["Calcoli generati, non eseguiti", "Unioni e aggregazioni errate", "Mancanti come zeri"]], ["Analisi", ["Relazioni casuali", "Conclusioni da pochi dati", "Fondamento statistico debole"]], ["Rappresentazione", ["Grafici incoerenti", "Periodi selezionati", "Commenti oltre i numeri"]], ["Interpretazione", ["Correlazioni come cause", "Stime come dati reali", "Assunzioni implicite"]]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 1.82;
      shapeBox(s, x, 1.15, 1.7, 2.75, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.1, y: 1.22, w: 1.5, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, bullets(e[1], { space: 5 }), { x: x + 0.1, y: 1.68, w: 1.55, h: 2.15, fontSize: 11, color: C.text1 });
    });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 0.5, y: 4.02, w: 9.0, h: 0.3, fill: { color: C.accent5 }, line: { type: "none" }, objectName: "propagazione" });
    txt(s, "Gli errori delle prime fasi si propagano, e diventano più difficili da vedere man mano che ci si allontana dai dati.", { x: 0.5, y: 4.45, w: 9, h: 0.45, fontSize: 12, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Dati reali, stime, simulazioni", "Un limite specifico, che il sottotema mette in evidenza: la confusione tra dati reali, stime e simulazioni. Nel Tema 7 abbiamo visto la distinzione in generale; nell'analisi assistita il rischio è particolarmente alto, per tre motivi. Primo, nella stessa conversazione o nello stesso report possono convivere numeri di natura diversa: un fatturato osservato, una quota di mercato stimata, una crescita simulata. Se non sono etichettati, vengono letti tutti come dati. Secondo, l'AI può completare i dati mancanti con stime senza dirlo chiaramente: un mese mancante interpolato, un valore di mercato preso dalla sua conoscenza generale, un totale stimato da un campione. Terzo, i risultati vengono riutilizzati: una simulazione prodotta per esplorare uno scenario finisce copiata in una presentazione, dove perde l'etichetta e diventa un dato. Il controllo è semplice da enunciare: per ogni numero importante, sapere se è osservato, stimato o simulato, e da dove viene. Una buona pratica è chiedere al sistema di etichettare esplicitamente la natura di ogni valore in tabelle e report, e mantenere queste etichette quando i risultati vengono riutilizzati.");
    phaseTag(s, 3);
    const t = [["Osservato", "Misurato o registrato", "Fatturato del trimestre", C.accent1, C.background1], ["Stimato", "Calcolato da dati parziali o ipotesi", "Quota di mercato", C.accent6, C.text1], ["Simulato", "Risultato di uno scenario", "Crescita in caso di nuovo prezzo", C.background2, C.text1]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.55, e[3], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.4, fontSize: 17, bold: true, color: i === 0 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.45, fontSize: 12, bold: true, color: e[4] });
      txt(s, e[2], { x: x + 0.15, y: 2.15, w: 2.56, h: 0.45, fontSize: 11, italic: true, color: e[4] });
    });
    const r = [["Convivono", "Numeri di natura diversa nello stesso report"], ["Completamenti silenziosi", "Mancanti stimati senza dirlo"], ["Riutilizzo", "La simulazione perde l'etichetta in una presentazione"]];
    r.forEach((e, i) => {
      const y = 2.9 + i * 0.5;
      txt(s, e[0], { x: 0.5, y, w: 2.6, h: 0.42, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
      txt(s, e[1], { x: 3.1, y, w: 6.4, h: 0.42, fontSize: 12, color: C.text1, valign: "middle" });
    });
    txt(s, "Chiedere di etichettare la natura di ogni valore, e mantenere le etichette nel riutilizzo.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Fondamento statistico", "Un altro limite del sottotema: le analisi prive di adeguato fondamento statistico. Senza entrare in metodi specialistici, tre situazioni frequenti che ogni utilizzatore dovrebbe riconoscere. Pochi dati: una differenza tra due gruppi di dieci persone, o un andamento su quattro mesi, può essere dovuta al caso. L'AI calcolerà comunque percentuali e medie, e le commenterà come se fossero solide. Una domanda utile: su quanti casi si basa questo risultato? Differenze piccole: una differenza del 2 per cento nella soddisfazione tra due sedi può essere rumore, non un fenomeno reale, specialmente se i dati variano molto. Molti confronti: come visto nel 9.4, se si confrontano molte categorie, alcune mostreranno differenze forti per puro caso. Chi analizza con l'AI può sempre chiedere al sistema di valutare se una differenza è statisticamente significativa, cioè se è improbabile che sia dovuta al caso. È un controllo utile, purché si ricordi che la significatività statistica non dice se una differenza è importante nella pratica, e che con pochi dati anche un test può essere poco affidabile. Per analisi destinate a decisioni rilevanti su dati limitati o complessi, conviene coinvolgere chi ha competenze statistiche.");
    phaseTag(s, 3);
    await iconGrid(s, [
      { icon: "FiUsers", head: "Pochi dati", body: "Due gruppi di dieci persone, quattro mesi di andamento" },
      { icon: "FiMinimize2", head: "Differenze piccole", body: "Il 2% tra due sedi può essere solo rumore" },
      { icon: "FiGrid", head: "Molti confronti", body: "Alcune differenze forti emergono per caso" },
    ], 3, { y: 1.2, h: 1.6, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 3.0, 9.0, 0.75, C.accent6, "domanda");
    txt(s, [{ text: "Domanda utile: ", options: { bold: true, color: C.accent1 } }, { text: "su quanti casi si basa questo risultato? La differenza è statisticamente significativa?", options: { color: C.text1 } }], { x: 0.7, y: 3.0, w: 8.6, h: 0.75, fontSize: 13, valign: "middle" });
    banner(s, 3.95, "Significativo non vuol dire importante nella pratica. Per decisioni rilevanti su dati limitati o complessi, coinvolgere competenze statistiche.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Tracciabilità di dati ed elaborazioni", "La tracciabilità, introdotta nel 9.3, è la condizione che rende controllabili tutti gli altri limiti. Un'analisi tracciabile permette di rispondere a quattro domande. Da quali dati parte? Fonte, data di estrazione, filtri, definizioni. Quali elaborazioni sono state eseguite? Pulizia, trasformazioni, calcoli, con il codice o le formule. Su quali ipotesi si basa? Scelte sui mancanti, sugli anomali, sulle definizioni, sulle previsioni. Come si arriva alle conclusioni? Quali risultati sostengono ciascuna affermazione. Senza tracciabilità, l'unico modo per controllare un'analisi è rifarla da capo. Con la tracciabilità, si possono controllare i punti critici in modo mirato. Nel lavoro con l'AI, la tracciabilità non è automatica: alcuni strumenti mostrano il codice e i passaggi, altri solo il risultato. Conviene preferire, per le analisi importanti, strumenti e modalità che lasciano traccia, e chiedere esplicitamente al sistema un registro delle operazioni e delle ipotesi. Un'analisi senza tracciabilità può essere usata per esplorare, ma non dovrebbe sostenere decisioni rilevanti.");
    phaseTag(s, 3);
    const q = [["FiDatabase", "Da quali dati?", "Fonte, estrazione, filtri, definizioni"], ["FiCpu", "Quali elaborazioni?", "Pulizia, trasformazioni, calcoli, codice"], ["FiHelpCircle", "Su quali ipotesi?", "Mancanti, anomali, definizioni, previsioni"], ["FiCheckCircle", "Quali conclusioni?", "Che cosa sostiene ogni affermazione"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.1, i % 2 ? C.accent6 : C.background2, q[i][1]);
      await iconCircle(s, x + 0.75, 1.27, 0.6, q[i][0]);
      txt(s, q[i][1], { x: x + 0.1, y: 1.95, w: 1.95, h: 0.4, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, q[i][2], { x: x + 0.12, y: 2.38, w: 1.91, h: 0.8, fontSize: 11, color: C.text2, align: "center" });
    }
    banner(s, 3.45, "Senza tracciabilità, l'unico controllo è rifare l'analisi. Con la tracciabilità, si controllano i punti critici.", { h: 0.75, fontSize: 13 });
    txt(s, "Un'analisi senza traccia può servire a esplorare, non a sostenere decisioni rilevanti.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("L'apparenza non è affidabilità", "Le integrazioni A e D si incontrano qui, in un'affermazione del documento di perimetro: l'affidabilità non deriva dall'apparenza professionale del risultato, ma da dati, elaborazioni, ipotesi e conclusioni controllabili. È il rischio di falsa oggettività, nella sua forma più generale. Un'analisi prodotta con l'AI ha quasi sempre un'apparenza professionale: tabelle ordinate, grafici curati, numeri con decimali, un linguaggio tecnico e sicuro, conclusioni nette. Sono tutti segnali che, nell'esperienza comune, associamo a un lavoro accurato, perché in passato un'analisi così curata richiedeva tempo e competenza. Con l'AI questo legame si è rotto: la cura formale è diventata gratuita, e non dice più nulla sulla qualità sostanziale. La slide mette a confronto i segnali di apparenza e i segnali di affidabilità. I primi riguardano la forma; i secondi riguardano la possibilità di controllo. Un'analisi affidabile può anche essere presentata in modo semplice; un'analisi presentata in modo impeccabile può non essere affidabile. Per valutare un'analisi, conviene ignorare la forma e cercare i segnali della colonna di destra.");
    phaseTag(s, 3);
    table(s, [["Segnali di apparenza", "Segnali di affidabilità"],
      ["Tabelle ordinate, grafici curati", "Dati di partenza dichiarati"],
      ["Numeri con decimali", "Calcoli eseguiti e controllabili"],
      ["Linguaggio tecnico e sicuro", "Ipotesi esplicite"],
      ["Conclusioni nette", "Incertezze e limiti dichiarati"],
      ["Raccomandazioni precise", "Conclusioni ricondotte ai risultati"]],
      { y: 1.15, colW: [4.5, 4.5], rowH: 0.45, fontSize: 13, blankCorner: false, accentCol: 1 });
    banner(s, 4.0, "Con l'AI la cura formale è diventata gratuita: non dice più nulla sulla qualità sostanziale.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Validazione proporzionata all'uso", "Il principio conclusivo del tema, coerente con il Tema 7 e con il Tema 8: la validazione proporzionata all'utilizzo previsto. Non ogni analisi richiede lo stesso controllo, e controllare tutto con la stessa intensità sarebbe impraticabile. Tre livelli, come nel Tema 8. Per esplorare, cioè per farsi un'idea, generare ipotesi, preparare una discussione, basta un controllo di plausibilità: ordini di grandezza, coerenza con ciò che si sa, uno sguardo ai dati. Per lavorare, cioè per analisi interne che orientano attività, conviene controllare i dati di partenza, verificare che i calcoli principali siano eseguiti e non generati, e rifare a campione alcuni risultati. Per decidere o comunicare, cioè per analisi che sostengono decisioni rilevanti, vengono presentate alla direzione o all'esterno, o riguardano persone, serve una validazione completa: tracciabilità di dati, elaborazioni e ipotesi, verifica indipendente dei risultati principali, esplicitazione delle scelte analitiche e della loro influenza, coinvolgimento di competenze specialistiche se necessario. Due fattori alzano il livello: dati di qualità incerta e conseguenze difficili da correggere.");
    phaseTag(s, 3);
    const lv = [["Per esplorare", "Idee, ipotesi, discussioni", "Plausibilità, ordini di grandezza, uno sguardo ai dati", C.background2, C.text1], ["Per lavorare", "Analisi interne che orientano attività", "Dati di partenza, calcoli eseguiti, controlli a campione", C.accent6, C.text1], ["Per decidere o comunicare", "Decisioni rilevanti, direzione, esterno, persone", "Tracciabilità, verifica indipendente, scelte esplicite, specialisti", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.9;
      shapeBox(s, 0.5, y, 9.0, 0.8, l[3], l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.3, h: 0.8, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 3.0, y, w: 2.9, h: 0.8, fontSize: 12, color: l[4], valign: "middle" });
      txt(s, l[2], { x: 6.0, y, w: 3.35, h: 0.8, fontSize: 12, bold: true, color: l[4], valign: "middle" });
    });
    txt(s, "Alzano il livello", { x: 0.5, y: 3.95, w: 2.3, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.8, 3.95, 3.25, 0.55, "Dati di qualità incerta", { fill: C.background2, fontSize: 12 });
    chip(s, 6.2, 3.95, 3.3, 0.55, "Conseguenze difficili da correggere", { fill: C.background2, fontSize: 12 });
    txt(s, "Più l'analisi pesa sulla decisione, più devono essere verificabili dati, calcoli e scelte.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Un'analisi AI richiede controlli su dati, metodi e interpretazioni, proporzionati alle conseguenze dell'utilizzo.", "Sottotema 9.8  ·  Limiti e condizioni di affidabilità", "Concetto chiave dell'ultimo sottotema. Gli errori dell'analisi assistita nascono nei dati, nelle elaborazioni, nell'analisi, nella rappresentazione e nell'interpretazione, e si propagano. Dati reali, stime e simulazioni vanno distinti ed etichettati; le analisi su pochi dati o con molti confronti vanno lette con cautela; la tracciabilità rende possibile il controllo. E l'affidabilità non deriva dall'apparenza professionale, che con l'AI è diventata gratuita, ma da dati, elaborazioni, ipotesi e conclusioni controllabili. Il controllo va proporzionato all'uso. Esercizio suggerito: dare ai partecipanti un report fittizio prodotto con l'AI, curato nella forma e con alcuni errori sostanziali nascosti, come un mese parziale, una stima non etichettata e una conclusione causale, e chiedere di individuarli usando la tabella dei segnali di affidabilità.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quali attività: tutto il processo, dalla comprensione dei dati all'interpretazione, con un contributo che cambia natura lungo le fasi. Dataset e fogli di calcolo: descrivere la struttura, individuare problemi di qualità, preparare i dati; ma il significato delle colonne e le definizioni vanno confermati. Elaborazioni quantitative: calcoli, aggregazioni, indicatori, statistiche, formule e codice; distinguendo i calcoli eseguiti dai numeri generati. Tendenze, anomalie, relazioni: l'AI le trova rapidamente; ma la correlazione non è causa, e cercando tra molte variabili si trovano relazioni casuali. Grafici e report: rapidi e professionali; ma comunicazione efficace e interpretazione corretta sono diverse. Descrivere, interpretare, prevedere: un fatto, un significato, una stima; e i passaggi tra loro non vanno fatti implicitamente. Decisioni: supporto all'interpretazione, alle alternative e agli scenari; ma analisi e raccomandazione sono diverse, e la responsabilità resta umana. Errori e rischi: lungo tutto il processo, con il rischio trasversale della falsa oggettività. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Quali attività?", "Tutto il processo: il contributo cambia natura lungo le fasi"], ["Dataset e fogli di calcolo?", "Struttura, qualità, preparazione; definizioni da confermare"], ["Elaborazioni quantitative?", "Calcoli, indicatori, codice; eseguiti, non generati"], ["Tendenze, anomalie, relazioni?", "Trovate rapidamente; correlazione non è causa"], ["Grafici e report?", "Rapidi e professionali; efficaci non vuol dire corretti"], ["Descrivere, interpretare, prevedere?", "Un fatto, un significato, una stima"], ["Decisioni aziendali?", "Supporto ad alternative e scenari; la responsabilità resta umana"], ["Errori e rischi?", "Lungo tutto il processo; il rischio trasversale è la falsa oggettività"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.92;
      shapeBox(s, x, y, 4.4, 0.82, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.82, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.08, w: 3.8, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.36, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: comprendere il ruolo dell'AI nel processo di analisi; riconoscere le tipologie di dati e i fattori che ne influenzano la qualità; distinguere dati, metriche e indicatori; comprendere le possibilità di elaborazione quantitativa assistita; distinguere calcoli eseguiti da risultati numerici generati; riconoscere pattern, tendenze, anomalie e correlazioni; comprendere il ruolo dell'AI nella produzione di grafici e report; distinguere analisi descrittiva, diagnostica, predittiva e prescrittiva; comprendere opportunità e limiti di previsioni e simulazioni; distinguere risultati quantitativi e interpretazioni; individuare il rischio di conclusioni errate da dati corretti; comprendere perché le decisioni supportate dall'AI richiedono giudizio e responsabilità umana.");
    const r = ["Il ruolo dell'AI nel processo di analisi", "Tipologie di dati e fattori di qualità", "Dati, metriche e indicatori", "Elaborazione quantitativa assistita", "Calcoli eseguiti o numeri generati", "Pattern, tendenze, anomalie, correlazioni", "Grafici e report con l'AI", "Descrittiva, diagnostica, predittiva, prescrittiva", "Opportunità e limiti delle previsioni", "Risultati quantitativi e interpretazioni", "Conclusioni errate da dati corretti", "Giudizio e responsabilità umana"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Quattro fasi: una scheda pratica", "Traduciamo il modulo in una scheda pratica, organizzata per fasi. Comprendere e preparare: da dove vengono i dati, con quali definizioni? Il significato delle colonne è confermato? Mancanti, duplicati e anomali sono stati gestiti consapevolmente? I dati rappresentano il fenomeno? Elaborare e analizzare: i calcoli sono eseguiti e controllabili? Base, periodo e definizione degli indicatori sono chiari? Media e mediana insieme, e uno sguardo ai dati? Le relazioni trovate sono ipotesi da verificare? Rappresentare e prevedere: il grafico è coerente con i dati, il periodo completo, le etichette giuste? Il commento resta nei numeri? Le previsioni dichiarano ipotesi e incertezza? Interpretare e valutare: dati osservati, stime e simulazioni sono distinti? Le scelte analitiche sono esplicite, e la conclusione regge a scelte diverse? Analisi e raccomandazione sono separate? Il controllo è proporzionato all'uso? E sempre: dati aziendali solo negli strumenti autorizzati, e responsabilità della decisione a chi decide. Non confondere un'analisi dall'aspetto professionale con un'analisi affidabile: è il messaggio centrale del tema.");
    const f = [["Comprendere", ["Provenienza e definizioni", "Colonne confermate", "Mancanti e anomali gestiti", "Rappresentatività"], C.background2], ["Elaborare", ["Calcoli eseguiti", "Base, periodo, definizione", "Media e mediana, e i dati", "Relazioni come ipotesi"], C.accent6], ["Rappresentare", ["Grafico coerente e completo", "Commento nei numeri", "Previsioni con ipotesi e incertezza"], C.background2], ["Interpretare", ["Osservato, stimato, simulato", "Scelte esplicite e robuste", "Analisi separata da raccomandazione"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 5 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 11, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: strumenti autorizzati, controlli proporzionati all'uso, responsabilità a chi decide.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei errori tipici nell'analisi dei dati con l'AI, uno per ciascuno dei principali messaggi del modulo. Primo: 'le colonne le ha capite lui'. Il significato delle colonne, le definizioni aziendali e la provenienza dei dati sono ipotesi del sistema finché non le conferma chi conosce il dato. Secondo: 'il numero l'ha calcolato'. Un numero può essere generato come qualsiasi altra parola: va chiesto il calcolo eseguito, con codice o formula, e i passaggi. Terzo: 'sono correlati, quindi uno causa l'altro'. Una relazione trovata nei dati è un'ipotesi da verificare: causalità inversa, terzo fattore, selezione, coincidenza. Quarto: 'il grafico è chiaro, quindi è giusto'. Una rappresentazione persuasiva non garantisce la validità di dati e conclusioni: colonna, periodo, scala, esclusioni. Quinto: 'a giugno venderemo 1.247 pezzi'. Una previsione è una stima condizionata da dati, ipotesi e metodo: va presentata con la sua incertezza. Sesto: 'l'ha detto l'analisi'. Definizioni, pesi e confini sono scelte, e la decisione resta di chi la prende. Suggerimento: chiedere ai partecipanti quale di questi errori hanno visto più spesso in report e presentazioni.");
    const a = [["FiColumns", "\"Le colonne le ha capite lui\"", "Definizioni da confermare", "9.2"], ["FiHash", "\"Il numero l'ha calcolato\"", "Calcolo eseguito, non generato", "9.3"], ["FiGitMerge", "\"Sono correlati, quindi è causa\"", "Una relazione è un'ipotesi", "9.4"], ["FiBarChart2", "\"Il grafico è chiaro, quindi è giusto\"", "Colonna, periodo, scala, esclusioni", "9.5"], ["FiTrendingUp", "\"A giugno venderemo 1.247 pezzi\"", "Una previsione ha un'incertezza", "9.6"], ["FiUserCheck", "\"L'ha detto l'analisi\"", "Le scelte e la decisione sono umane", "9.7"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 9 completiamo il secondo tema dell'area 'Esplorare le possibilità dell'AI'. Dopo testi, documenti e conoscenza, abbiamo esplorato i dati e l'analisi. Il tema successivo, il Tema 10, è dedicato all'AI multimodale e alla creazione di contenuti: la capacità dei sistemi di comprendere, generare e trasformare immagini, audio, video, presentazioni e materiali di comunicazione, e di passare da una modalità all'altra. Ritroveremo alcuni principi di questo modulo: un grafico o un'immagine realistica possono convincere senza essere corretti, e ogni trasformazione da una modalità all'altra può introdurre errori, omissioni e alterazioni del significato. I documenti di perimetro richiamano poi altri temi: assistenti, agenti e automazioni, nel Tema 11; AI, dati e conoscenza aziendale, nel Tema 14, dove si affronteranno le condizioni organizzative e tecnologiche per rendere disponibili e utilizzabili i dati di cui abbiamo parlato; opportunità e casi d'uso, nel Tema 15, con la selezione e la valutazione economica dei progetti. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi e documenti\nTema 9: dati e analisi (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.6, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 10: AI multimodale e creazione di contenuti", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Immagini, audio, video, presentazioni", { x: 5.4, y: 2.38, w: 3.9, h: 0.3, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 2.85, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 11: assistenti, agenti e automazioni", "Tema 14: dati e conoscenza aziendale", "Tema 15: opportunità e casi d'uso"], { space: 5 }), { x: 5.4, y: 3.2, w: 3.9, h: 1.5, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Il modulo si basa soprattutto su principi consolidati di statistica descrittiva e di lettura critica dei dati, che non dipendono da una singola fonte. Le capacità degli strumenti AI di analisi dei dati, in particolare l'esecuzione di codice e la produzione di grafici, evolvono rapidamente: prima di ogni edizione è consigliabile verificare le funzionalità degli strumenti autorizzati in azienda e aggiornare gli esempi. Tutti gli esempi numerici del modulo sono fittizi, tranne il quartetto di Anscombe.");
    const src = [
      "Anscombe, F. J. (1973). Graphs in Statistical Analysis. The American Statistician, 27(1), 17-21.",
      "Vigen, T. (2015). Spurious Correlations. Hachette Books.",
      "Gli esempi di dati, grafici, tabelle e report presenti nelle slide sono fittizi, salvo il quartetto di Anscombe.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema9_AI_dati_analisi.pptx" });
  await applyTheme("Tema9_AI_dati_analisi.pptx", THEME);
  console.log("done");
})();
