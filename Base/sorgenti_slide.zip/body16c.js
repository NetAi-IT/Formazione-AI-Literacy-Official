  // =====================================================================
  section("16.7 Supporto e coordinamento");
  divider("16.7", "Supporto e coordinamento", "L'autonomia individuale è più efficace quando esistono riferimenti operativi e canali di aiuto accessibili", "Settimo sottotema, con priorità media, a livello di conoscenza. Il documento distingue: il 16.3 riguarda orientamento e responsabilità manageriali, il 16.7 i meccanismi di supporto quotidiano; il 16.6 le dinamiche culturali, il 16.7 i riferimenti organizzativi. Vediamo la chiarezza sugli strumenti e sugli usi consentiti, materiali ed esempi, referenti e canali di supporto, raccolta di esigenze, coordinamento tra funzioni, equilibrio tra autonomia e pratiche comuni, gestione degli usi non autorizzati. Integrazione A. Il confine con i Temi 17 e 18: parliamo di supporto operativo, non di governance formale, norme o sicurezza.");
  {
    const s = content("Che cosa si può usare, e come", "I primi punti del sottotema riguardano la chiarezza: sugli strumenti approvati, sugli usi consentiti, e l'orientamento nella scelta tra gli strumenti disponibili. Abbiamo visto nel 16.2 che la mancanza di chiarezza è un ostacolo: nel dubbio, molte persone si astengono, e altre usano ciò che trovano. Le persone hanno bisogno di risposte semplici a domande semplici. Quali strumenti posso usare per il lavoro? Per quali attività? Quali informazioni posso inserire, e quali no? Che cosa devo verificare prima di usare un risultato? A chi chiedo se ho un dubbio? Il sottotema chiede che le indicazioni siano semplici, comprensibili e applicabili: non un regolamento di trenta pagine, ma poche indicazioni chiare, con esempi. Le regole formali, gli aspetti normativi e di sicurezza, saranno trattati nei Temi 17 e 18; qui ci interessa la loro traduzione operativa, ciò che serve a una persona nel momento in cui deve decidere se e come usare uno strumento. L'esempio in slide mostra una scheda di indicazioni, fittizia, del tipo che un'azienda potrebbe distribuire.");
    adTag(s, 3);
    docBox(s, 0.5, 1.15, 5.4, 3.0, "Indicazioni d'uso (esempio fittizio)", "Strumento approvato: l'assistente aziendale, con l'account di lavoro.\nSì: bozze, sintesi, riformulazioni, idee.\nNo: dati personali di clienti e colleghi in strumenti non approvati.\nSempre: verificare cifre, nomi e condizioni prima di inviare.\nDubbi: chiedere al referente del proprio reparto.", { fontSize: 12, fill: C.accent6 });
    rowsLabel(s, [["Semplici", "Poche indicazioni, non trenta pagine"], ["Comprensibili", "Con esempi"], ["Applicabili", "Nel momento della decisione"]], { y: 1.15, h: 0.85, lw: 1.3, x: 6.15, w: 3.35, fontSize: 11 });
    banner(s, 4.3, "Le regole formali sono dei Temi 17 e 18: qui la loro traduzione operativa.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Materiali e referenti", "Il sottotema indica due forme di supporto quotidiano. I materiali, esempi e istruzioni riutilizzabili: raccolte di istruzioni per le attività frequenti, esempi commentati di buon uso, guide brevi per le situazioni tipiche, liste degli errori comuni. Sono il prodotto naturale dei piloti, come visto nel 16.5, e permettono alle persone di non partire da zero. Funzionano se sono facili da trovare, aggiornati e vicini alle attività reali. I referenti e i canali di supporto: persone a cui rivolgersi quando si ha un dubbio o un problema. Una forma diffusa sono i referenti di reparto, a volte chiamati 'champion' o 'ambasciatori': colleghi con più esperienza che dedicano una parte del loro tempo ad aiutare gli altri, a raccogliere problemi, a condividere pratiche. Hanno il vantaggio di conoscere il lavoro del reparto, e di essere vicini. Per funzionare, hanno bisogno di tempo riconosciuto per questo ruolo, di un collegamento con chi coordina l'adozione, e di non diventare l'unico punto di riferimento, con il rischio di sovraccarico. A questi si aggiungono canali più strutturati, come uno spazio di domande e risposte condiviso o un supporto tecnico.");
    adTag(s, 3);
    await card(s, 0.5, 1.15, 4.35, 2.7, { icon: "FiFolder", head: "Materiali riutilizzabili", headSize: 15, bodySize: 12, body: bullets(["Istruzioni per le attività frequenti", "Esempi commentati, guide brevi", "Errori comuni", "Facili da trovare, aggiornati, vicini al lavoro"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.7, { icon: "FiUserCheck", head: "Referenti di reparto", headSize: 15, bodySize: 12, fill: C.accent6, body: bullets(["Colleghi più esperti, vicini al lavoro", "Aiutano, raccolgono problemi, condividono", "Servono tempo riconosciuto e collegamento", "Rischio di sovraccarico"], { space: 4 }) });
    banner(s, 4.05, "Nello scenario B, referenti e confronto tra colleghi; nello scenario A, solo l'iniziativa individuale.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Raccogliere e coordinare", "Il sottotema chiede di raccogliere problemi, esigenze e proposte; di coordinare tra funzioni e reparti; di condividere le esperienze efficaci; di ridurre duplicazioni e frammentazione. Quando l'adozione cresce, emergono problemi di coordinamento. Reparti diversi scelgono strumenti diversi per esigenze simili. Più gruppi sviluppano in parallelo le stesse istruzioni, o risolvono gli stessi problemi, senza saperlo. Le buone pratiche restano locali. Le esigenze che richiederebbero un intervento comune, come un'integrazione o una nuova funzione, non arrivano a chi può decidere. Un coordinamento leggero può aiutare molto: un punto in cui le esigenze e le proposte vengono raccolte; momenti periodici di scambio tra i referenti dei diversi reparti; uno spazio condiviso per le pratiche e i materiali; qualcuno che abbia una visione d'insieme. Alcune organizzazioni costruiscono strutture dedicate, come i centri di eccellenza AI: il documento chiede di solo accennarvi. Per la maggior parte delle aziende, il punto non è creare una struttura, ma assicurarsi che le informazioni circolino e che qualcuno se ne occupi.");
    adTag(s, 3);
    await twoPanel(s, "Senza coordinamento", bullets(["Strumenti diversi per esigenze simili", "Stesse istruzioni sviluppate in parallelo", "Buone pratiche locali", "Esigenze comuni che non arrivano a chi decide"], { space: 4 }), "Un coordinamento leggero", bullets(["Un punto di raccolta di esigenze e proposte", "Scambi periodici tra referenti", "Uno spazio condiviso per pratiche e materiali", "Qualcuno con una visione d'insieme"], { space: 4 }), { y: 1.15, h: 2.75, li: "FiGrid", ri: "FiGitMerge" });
    banner(s, 4.1, "Non serve per forza una struttura (centri di eccellenza: solo un accenno): serve che le informazioni circolino.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Autonomia e pratiche comuni", "Il sottotema chiede di trovare un equilibrio tra autonomia individuale e pratiche comuni, e di distinguere tra supporto operativo e governance formale. L'autonomia ha molti vantaggi: le persone conoscono il proprio lavoro, trovano usi che nessuno aveva previsto, adattano lo strumento alle proprie esigenze. Ma un'autonomia senza riferimenti produce frammentazione, pratiche incoerenti, rischi non visti, e lascia sole le persone meno esperte. Le pratiche comuni danno coerenza, facilitano l'apprendimento e il controllo, ma se sono troppe o troppo rigide soffocano la sperimentazione. L'equilibrio dipende dall'attività: per attività con rischi elevati o con effetti verso l'esterno servono pratiche comuni più definite; per attività interne e a basso rischio, più autonomia. La consapevolezza del sottotema lo riassume: l'autonomia individuale è più efficace quando esistono riferimenti operativi e canali di aiuto accessibili. Quanto alla distinzione con la governance formale: il supporto operativo aiuta le persone a usare bene gli strumenti; la governance definisce regole, responsabilità, controlli e conformità a livello di organizzazione. Sono collegati, ma diversi: la governance sarà trattata nei Temi 17 e 18.");
    adTag(s, 3);
    s.addShape(pres.shapes.RECTANGLE, { x: 0.5, y: 1.75, w: 9.0, h: 0.08, fill: { color: HEX.a3 }, line: { type: "none" }, objectName: "asse" });
    txt(s, "Più autonomia", { x: 0.5, y: 1.15, w: 3.0, h: 0.5, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Più pratiche comuni", { x: 6.5, y: 1.15, w: 3.0, h: 0.5, fontSize: 14, bold: true, color: C.accent1, align: "right" });
    docBox(s, 0.5, 2.0, 4.35, 1.4, "Attività interne, basso rischio", "Bozze per uso personale, idee, sintesi di lavoro: più spazio all'iniziativa.", { fontSize: 12 });
    docBox(s, 5.15, 2.0, 4.35, 1.4, "Rischi elevati, effetti all'esterno", "Comunicazioni ai clienti, documenti contrattuali: pratiche più definite.", { fontSize: 12, fill: C.accent6 });
    rowsLabel(s, [["Supporto operativo", "Aiuta le persone a usare bene gli strumenti (16.7)"], ["Governance formale", "Regole, responsabilità, controlli, conformità (Temi 17 e 18)"]], { y: 3.6, h: 0.55, lw: 2.2 });
  }
  {
    const s = content("Gestire gli usi non autorizzati", "L'ultimo punto del sottotema, e l'integrazione A nella sua forma operativa: il riconoscimento e la gestione degli usi non autorizzati. Il documento propone una lettura equilibrata. Chiarezza sugli strumenti consentiti e supporto alle esigenze reali possono ridurre gli incentivi all'uso improprio di servizi non autorizzati, senza eliminarlo automaticamente. Che cosa significa in pratica? Primo, capire: perché le persone usano strumenti non approvati? Quali esigenze soddisfano? Spesso la risposta indica che cosa manca nell'offerta aziendale. Secondo, offrire alternative: se esiste uno strumento approvato adeguato, facile da usare e conosciuto, l'incentivo a usare altro si riduce molto. Terzo, chiarire: indicazioni semplici su che cosa non si può fare, e perché, con particolare attenzione alle informazioni aziendali. Quarto, accompagnare: chi usava uno strumento non autorizzato ha spesso sviluppato competenze utili, che vanno portate sugli strumenti approvati. E infine, controllare dove serve: alcuni usi comportano rischi che richiedono misure specifiche, che saranno trattate nei Temi 17 e 18. Il documento è chiaro su un punto: lo Shadow AI va considerato qui come fenomeno di adozione, non come tema tecnico di cybersecurity.");
    adTag(s, 3);
    numList(s, ["Capire: perché? quali esigenze soddisfa?", "Offrire alternative: approvate, adeguate, facili, conosciute", "Chiarire: che cosa non si può fare, e perché", "Accompagnare: portare le competenze sugli strumenti approvati", "Controllare dove serve (Temi 17 e 18)"], { y: 1.15, h: 0.5, fontSize: 13 });
    banner(s, 4.1, "Chiarezza e supporto riducono gli incentivi allo Shadow AI, senza eliminarlo automaticamente (A).", { h: 0.8, fontSize: 14 });
  }
  keySlide("L'autonomia individuale è più efficace quando esistono riferimenti operativi chiari e canali di aiuto accessibili.", "Sottotema 16.7  ·  Regole operative, supporto e coordinamento dell'adozione  ·  Integrazione A", "Concetto chiave del settimo sottotema. Servono indicazioni semplici su strumenti e usi consentiti. Materiali riutilizzabili e referenti di reparto sono il supporto quotidiano. Un coordinamento leggero fa circolare esigenze e pratiche. L'equilibrio tra autonomia e pratiche comuni dipende dal rischio. Gli usi non autorizzati si gestiscono capendo, offrendo alternative, chiarendo, accompagnando e controllando dove serve. Esercizio suggerito: scrivere in gruppo una scheda di indicazioni d'uso di cinque righe per il proprio reparto, con strumenti consentiti, usi sì e no, verifica e a chi rivolgersi.");

  // =====================================================================
  section("16.8 Monitoraggio e sostenibilità");
  divider("16.8", "Monitoraggio e sostenibilità", "Monitorare significa osservare non soltanto quanto l'AI viene usata, ma come, perché e con quali risultati", "L'ultimo sottotema, da comprendere, e uno di quelli con maggiore attenzione didattica. Il documento distingue: il 16.1 definisce il fenomeno dell'adozione, il 16.8 ne osserva continuità, qualità e impatti; il 16.5 riguarda il passaggio all'estensione, il 16.8 il consolidamento nel tempo. Vediamo che cosa osservare, la differenza tra diffusione, intensità e qualità, tra metriche di adozione e indicatori di impatto, i costi, la sostenibilità, e la possibilità di modificare, ridimensionare o interrompere. Integrazione D. Sistemi avanzati di misurazione vanno solo accennati; le dimensioni del valore sono quelle del Tema 12.");
  {
    const s = content("Diffusione, intensità, qualità", "L'ottava domanda guida: come capire se l'uso è efficace e sostenibile nel tempo? Il sottotema parte dalla differenza tra diffusione, intensità e qualità dell'utilizzo, e dalla frequenza e continuità d'uso. La diffusione dice quante persone usano lo strumento. L'intensità dice quanto lo usano: con quale frequenza, per quante attività, con quale continuità nel tempo. La qualità dice come lo usano: su attività adatte, in modo appropriato, con verifica, con buoni risultati. Le tre dimensioni possono divergere. Molte persone che usano lo strumento una volta al mese: alta diffusione, bassa intensità. Poche persone che lo usano ogni giorno su attività importanti: bassa diffusione, alta intensità. Molte persone che lo usano spesso, ma senza verifica o per attività inadatte: alta diffusione e intensità, bassa qualità. La continuità è particolarmente informativa: un uso che si mantiene nel tempo indica che lo strumento è entrato nelle abitudini; un uso che cala dopo le prime settimane indica che qualcosa non funziona, come visto nel 16.1. La diffusione è la più facile da misurare, la qualità la più difficile: per questo la tentazione è guardare solo la prima.");
    adTag(s, 4);
    const d = [["FiUsers", "Diffusione", "Quante persone?", "Facile da misurare"], ["FiActivity", "Intensità", "Quanto: frequenza, attività, continuità", "Abbastanza facile"], ["FiAward", "Qualità", "Come: attività adatte, verifica, risultati", "Difficile da osservare"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.3, i === 2 ? C.accent6 : C.background2, d[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.62, d[i][0]);
      txt(s, d[i][1], { x: x + 0.15, y: 1.95, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.15, y: 2.37, w: 2.56, h: 0.55, fontSize: 12, color: C.text1, align: "center" });
      txt(s, d[i][3], { x: x + 0.15, y: 2.95, w: 2.56, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "center" });
    }
    banner(s, 3.7, "Possono divergere. La continuità nel tempo è molto informativa. La tentazione è guardare solo la più facile.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Adozione o impatto?", "La distinzione centrale del sottotema: metriche di adozione e indicatori di impatto. Le metriche di adozione descrivono l'uso: numero di utenti attivi, frequenza, numero di richieste, attività coperte. Sono spesso disponibili direttamente dagli strumenti, ed è per questo che sono le più usate nei rapporti. Gli indicatori di impatto descrivono gli effetti sul lavoro e sui risultati: tempo per completare un'attività, qualità degli output, errori, soddisfazione dei clienti, capacità operativa, come visto nel Tema 12. Sono più difficili da raccogliere, e spesso richiedono un confronto con la situazione precedente, come visto nel Tema 15. Le metriche di adozione sono utili per capire se lo strumento viene usato, e dove. Ma non dicono se l'uso produce benefici. È possibile un'alta adozione con impatto nullo, o negativo. La tabella confronta i due tipi di indicatori nello scenario dei documenti commerciali. Il sottotema chiede di osservare entrambi, e di non trattare i primi come prova dei secondi. Nello scenario A del modulo si osservava il numero di accessi; nello scenario B uso, qualità, problemi e risultati.");
    adTag(s, 4);
    table(s, [["Scenario fittizio", "Metriche di adozione", "Indicatori di impatto"],
      ["Che cosa misurano", "L'uso", "Gli effetti su lavoro e risultati"],
      ["Esempi", "Utenti attivi, richieste al giorno, documenti generati", "Tempo per offerta, errori nelle offerte, tasso di risposta dei clienti"],
      ["Fonte", "Spesso lo strumento stesso", "Processi, clienti, confronto con il prima"],
      ["Dicono", "Se e dove viene usato", "Se l'uso produce benefici (Tema 12)"]],
      { y: 1.15, colW: [2.0, 3.4, 3.6], rowH: 0.55, accentCol: 2, fontSize: 12 });
    banner(s, 4.05, "Alta adozione con impatto nullo, o negativo, è possibile. Osservare entrambi.", { h: 0.8, fontSize: 15 });
  }
  {
    const s = content("Che cosa osservare", "Il sottotema elenca diverse cose da osservare nel tempo, che vanno oltre i numeri dell'uso. Raccogliamole in un piccolo cruscotto, utile come traccia. L'uso effettivo: diffusione, intensità, continuità. I risultati osservati nelle attività: tempo, qualità, errori, effetti sul servizio. Il feedback e la soddisfazione degli utilizzatori: che cosa dicono, che cosa trovano utile, che cosa li frustra. Le difficoltà e gli ostacoli persistenti: quelli che non si sono risolti con il tempo, e che probabilmente sono strutturali. I costi di supporto e aggiornamento: quanto costa mantenere l'adozione, in tempo dei referenti, materiali, licenze, interventi. L'evoluzione dei bisogni formativi: che cosa le persone hanno bisogno di imparare ora, che non serviva all'inizio. La revisione delle pratiche operative: le istruzioni e le indicazioni sono ancora adeguate? La combinazione di dati quantitativi, come l'uso e i tempi, e qualitativi, come il feedback e le difficoltà, è importante: i numeri dicono che cosa succede, le persone dicono perché. Il documento chiede di solo accennare ai sistemi avanzati di misurazione: per la maggior parte delle organizzazioni, poche osservazioni regolari valgono più di un sistema complesso.");
    adTag(s, 4);
    await iconGrid(s, [
      { icon: "FiActivity", head: "Uso effettivo", body: "Diffusione, intensità, continuità" },
      { icon: "FiTarget", head: "Risultati nelle attività", body: "Tempo, qualità, errori, servizio" },
      { icon: "FiMessageCircle", head: "Feedback degli utilizzatori", body: "Che cosa è utile, che cosa frustra" },
      { icon: "FiAlertTriangle", head: "Ostacoli persistenti", body: "Probabilmente strutturali" },
      { icon: "FiDollarSign", head: "Costi di supporto", body: "Referenti, materiali, licenze, interventi" },
      { icon: "FiBookOpen", head: "Bisogni formativi e pratiche", body: "Che cosa serve ora? Le indicazioni reggono?" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "I numeri dicono che cosa succede, le persone dicono perché. Poche osservazioni regolari bastano.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Diffondere non è adottare", "L'integrazione D del tema: diffondere rapidamente non significa adottare efficacemente. Numerosità degli utenti e velocità di distribuzione non dimostrano benefici o sostenibilità. Il sottotema segnala anche il rischio di amplificare inefficienze attraverso una diffusione rapida: se un'attività era inefficiente, e l'AI la accelera, una diffusione rapida moltiplica l'inefficienza, come visto nel Tema 13. Il grafico confronta, con dati inventati, due iniziative in due aziende fittizie. L'iniziativa A ha distribuito rapidamente lo strumento a tutti: in tre mesi l'ottanta per cento delle persone lo aveva usato almeno una volta; ma l'uso abituale si è stabilizzato intorno al 15 per cento, e i benefici osservati sono modesti. L'iniziativa B è partita con un pilota e ha esteso gradualmente: in tre mesi solo il 20 per cento aveva accesso; ma l'uso abituale tra chi aveva accesso è stato alto, e i benefici osservati maggiori. Alla fine dell'anno, l'iniziativa B aveva meno utenti 'totali' ma più utenti abituali e più impatto. Un rapporto che mostrasse solo gli utenti totali al terzo mese avrebbe premiato l'iniziativa sbagliata.");
    adTag(s, 4);
    const lb = ["M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "M11", "M12"];
    lineChart(s, lb, [
      { name: "A: hanno usato almeno una volta", values: [40, 65, 80, 83, 85, 86, 87, 87, 88, 88, 88, 88], color: HEX.a2 },
      { name: "A: uso abituale", values: [12, 18, 17, 16, 15, 15, 15, 14, 15, 15, 15, 15], color: HEX.a5 },
      { name: "B: uso abituale", values: [3, 6, 10, 14, 18, 23, 28, 32, 36, 39, 41, 43], color: HEX.a1 },
    ], { x: 0.5, y: 1.05, w: 5.6, h: 3.5, min: 0, max: 100, legend: true, title: "% dei dipendenti, due iniziative (dati inventati)" });
    await card(s, 6.35, 1.15, 3.15, 1.65, { icon: "FiFastForward", inline: true, head: "Rapida", headSize: 13, bodySize: 12, body: "Molti hanno provato, pochi usano davvero." });
    await card(s, 6.35, 2.95, 3.15, 1.6, { icon: "FiTrendingUp", inline: true, head: "Graduale", headSize: 13, bodySize: 12, fill: C.accent6, body: "Meno utenti totali, più abituali, più impatto (D)." });
  }
  {
    const s = content("Sostenibile nel tempo", "Il sottotema chiede di valutare la sostenibilità dell'uso nel tempo. Un'adozione sostenibile è un'adozione che regge quando l'attenzione iniziale finisce: quando il progetto si chiude, quando i referenti cambiano ruolo, quando lo strumento si aggiorna, quando arriva una nuova priorità. Alcune domande per valutarla. L'uso dipende da poche persone, o è diffuso nei gruppi? Se il referente se ne va, che cosa succede? I materiali e le indicazioni vengono aggiornati, e da chi? I costi, di licenze e di supporto, sono sostenibili rispetto ai benefici osservati? Lo strumento è integrato nei processi, o è un'aggiunta che si può abbandonare senza che nessuno se ne accorga? I nuovi arrivati imparano a usarlo? Ci sono segnali di deterioramento, come un calo della qualità d'uso, verifiche sempre più superficiali, o un ritorno ai vecchi metodi? Come visto nel Tema 14 per le fonti informative e nel Tema 15 per i prototipi, molti sistemi funzionano finché qualcuno se ne occupa attivamente, e si degradano quando l'attenzione cala. La sostenibilità va progettata, non si produce da sola.");
    adTag(s, 4);
    qGrid(s, ["L'uso dipende da poche persone?", "Se il referente se ne va?", "Chi aggiorna materiali e indicazioni?", "Costi sostenibili rispetto ai benefici?", "È integrato, o un'aggiunta abbandonabile?", "I nuovi arrivati imparano a usarlo?"], 3, 1.12, 1.05, 12);
    banner(s, 3.65, "Regge quando l'attenzione iniziale finisce? Attenzione ai segnali di deterioramento: verifiche superficiali, ritorno ai vecchi metodi.", { h: 0.9, fontSize: 13 });
    txt(s, "La sostenibilità va progettata, non si produce da sola (Temi 14 e 15).", { x: 0.5, y: 4.62, w: 9, h: 0.3, fontSize: 12, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Che cosa decidere", "Gli ultimi punti del sottotema: la possibilità di modificare, ridimensionare o interrompere le iniziative, e l'apprendimento e il miglioramento continuo. Il monitoraggio serve a decidere. Alcune decisioni possibili. Consolidare: l'iniziativa funziona, si mantiene e si cura. Estendere: le condizioni sono presenti anche altrove, come visto nel 16.5. Modificare: cambiare le pratiche, la formazione, il supporto, le attività su cui si usa lo strumento. Ridimensionare: limitare l'uso alle attività o ai gruppi in cui produce benefici, e abbandonarlo dove non li produce. Interrompere: l'iniziativa non produce benefici sufficienti, o i costi e i rischi superano i vantaggi. Come per la sperimentazione del Tema 15, l'interruzione o il ridimensionamento non sono fallimenti: sono decisioni corrette sulla base di ciò che si è osservato. È la prima precisazione del tema applicata al livello dell'organizzazione: l'adozione non è sempre desiderabile. Un'organizzazione che non ridimensiona mai nulla probabilmente non sta guardando davvero i risultati. La consapevolezza del sottotema: monitorare significa osservare non soltanto quanto l'AI viene usata, ma come, perché e con quali risultati.");
    adTag(s, 4);
    const d = [["Consolidare", "Funziona: mantenere e curare"], ["Estendere", "Condizioni presenti altrove (16.5)"], ["Modificare", "Pratiche, formazione, supporto, attività"], ["Ridimensionare", "Solo dove produce benefici"], ["Interrompere", "Benefici insufficienti, costi o rischi maggiori"]];
    d.forEach((e, i) => {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.72, 1.85, i >= 3 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.1, y: 1.22, w: 1.55, h: 0.45, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.1, y: 1.7, w: 1.55, h: 1.2, fontSize: 11, color: C.text1 });
    });
    shapeBox(s, 0.5, 3.2, 9.0, 0.75, C.accent1, "non fallimenti");
    txt(s, "Ridimensionare o interrompere non sono fallimenti: sono decisioni corrette su ciò che si è osservato.", { x: 0.7, y: 3.2, w: 8.6, h: 0.75, fontSize: 14, bold: true, color: C.background1, valign: "middle" });
    txt(s, "Un'organizzazione che non ridimensiona mai nulla probabilmente non sta guardando davvero i risultati.", { x: 0.5, y: 4.1, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.accent5 });
  }
  keySlide("Monitorare significa osservare non soltanto quanto l'AI viene usata, ma come, perché e con quali risultati. Diffondere rapidamente non è adottare efficacemente.", "Sottotema 16.8  ·  Monitoraggio, consolidamento e sostenibilità dell'adozione  ·  Integrazione D", "Concetto chiave dell'ultimo sottotema. Diffusione, intensità e qualità sono diverse. Le metriche di adozione non sono indicatori di impatto. Da osservare: uso, risultati, feedback, ostacoli persistenti, costi, bisogni formativi, pratiche. La diffusione rapida può produrre molti utenti e poco impatto, e amplificare inefficienze. La sostenibilità va progettata. Il monitoraggio porta a consolidare, estendere, modificare, ridimensionare o interrompere. Esercizio suggerito: per un'iniziativa AI reale o immaginata, scegliere due metriche di adozione e due indicatori di impatto, e indicare quale risultato porterebbe a ridimensionarla.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Quando c'è adozione reale: quando l'uso è integrato in modo appropriato e continuo nel lavoro, e produce risultati, non quando ci sono licenze e accessi. Perché la disponibilità non basta: servono utilità percepita, competenze, tempo, condizioni operative. Ostacoli delle persone o delle condizioni: spesso strutturali, e i rimedi sono diversi. Responsabilità: la direzione orienta e dà risorse, i manager creano condizioni, i collaboratori sperimentano e segnalano. Formazione: avvia l'apprendimento, ma il trasferimento nel lavoro richiede strumenti, tempo, esercizio e supporto. Fiducia, sperimentazione, partecipazione: fiducia informata, sicurezza psicologica, obiezioni ascoltate come informazioni. Supporto e coordinamento: indicazioni semplici, materiali, referenti, coordinamento leggero. Efficacia e sostenibilità: osservare qualità e impatto, non solo diffusione, ed essere pronti a modificare, ridimensionare o interrompere. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Quando c'è adozione reale?", "Uso appropriato, continuo, con risultati"], ["Perché lo strumento non basta?", "Utilità percepita, competenze, tempo, condizioni"], ["Persone o condizioni?", "Spesso strutturali; rimedi diversi"], ["Quali responsabilità?", "Direzione orienta, manager abilitano, tutti segnalano"], ["Perché la formazione non basta?", "Trasferimento: strumenti, tempo, esercizio, supporto"], ["Fiducia e partecipazione?", "Fiducia informata, sicurezza psicologica, obiezioni ascoltate"], ["Quale supporto?", "Indicazioni semplici, materiali, referenti, coordinamento"], ["Efficace e sostenibile?", "Qualità e impatto; modificare o interrompere"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.9;
      shapeBox(s, x, y, 4.4, 0.8, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.06, w: 3.8, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.34, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere disponibilità tecnologica, uso, adozione e valore; riconoscere i principali fattori abilitanti e gli ostacoli all'adozione; comprendere il ruolo della direzione e dei responsabili aziendali; spiegare perché la formazione iniziale non garantisce l'applicazione delle competenze; comprendere il valore della sperimentazione progressiva e del feedback; distinguere fiducia informata ed entusiasmo acritico; riconoscere che dubbi e resistenze possono segnalare problemi reali; comprendere il fenomeno dello Shadow AI dal punto di vista organizzativo; riconoscere il ruolo di supporto, indicazioni pratiche e coordinamento; distinguere diffusione rapida e adozione efficace; comprendere perché monitorare anche la qualità dell'uso e i risultati; riconoscere quando un'iniziativa dovrebbe essere adattata, ridimensionata o interrotta.");
    const r = ["Disponibilità, uso, adozione, valore", "Fattori abilitanti e ostacoli", "Ruolo di direzione e responsabili", "Formazione e applicazione", "Sperimentazione progressiva e feedback", "Fiducia informata o entusiasmo acritico", "Dubbi e resistenze come segnali", "Lo Shadow AI come fenomeno organizzativo", "Supporto, indicazioni, coordinamento", "Diffusione rapida o adozione efficace", "Monitorare qualità e risultati", "Adattare, ridimensionare, interrompere"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Domande per un'iniziativa di adozione", "Traduciamo il modulo in una scheda pratica: le domande da porsi quando si introduce, si gestisce o si partecipa a un'iniziativa di adozione dell'AI. Cinque colonne, come le dimensioni del tema. Adozione: a che livello siamo, disponibilità, uso, adozione, valore? L'uso è utile per le attività reali? Quali ostacoli, individuali o strutturali? Persone: le finalità sono chiare? I responsabili creano condizioni, con tempo e ascolto? Le obiezioni vengono ascoltate? Si può parlare di errori? Competenze: la formazione è adatta al ruolo, con esempi vicini al lavoro? Ci sono occasioni per applicare e supporto dopo? Diffusione: c'è stato un pilota? Che cosa ne abbiamo imparato? Le condizioni del successo ci sono anche altrove? Ci sono indicazioni semplici, materiali, referenti? Risultati: osserviamo qualità e impatto, non solo utenti? È sostenibile? Che cosa ci porterebbe a modificare, ridimensionare o interrompere? Sono domande utili a chiunque, non solo a chi guida il progetto. E valgono anche per questo percorso di formazione.");
    const f = [["Adozione", ["A che livello?", "Utile per le attività reali?", "Ostacoli strutturali?"], C.background2], ["Persone", ["Finalità chiare?", "Tempo e ascolto?", "Obiezioni ascoltate?", "Si parla di errori?"], C.accent6], ["Competenze", ["Formazione per ruolo?", "Occasioni per applicare?", "Supporto dopo?"], C.background2], ["Diffusione", ["Pilota, che cosa imparato?", "Condizioni altrove?", "Indicazioni, referenti?"], C.accent6], ["Risultati", ["Qualità e impatto?", "Sostenibile?", "Quando ridimensionare?"], C.background2]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.72, 3.0, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.1, y: 1.22, w: 1.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.1, y: 1.68, w: 1.58, h: 2.4, fontSize: 11, color: C.text1 });
    }
    banner(s, 4.3, "Domande utili a chiunque, non solo a chi guida il progetto. E valgono anche per questo percorso.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Che cosa evitare", "Gli errori più comuni da evitare, che riassumono il modulo in negativo. Considerare adottato uno strumento perché le licenze sono state distribuite. Trattare il lancio come un evento concluso. Attribuire alla resistenza delle persone difficoltà che sono strutturali. Ignorare lo Shadow AI, o al contrario chiamare Shadow AI ogni iniziativa spontanea. Promuovere l'AI a parole senza dare tempo e risorse. Imporre obiettivi quantitativi d'uso, producendo adozione simbolica. Pensare che un corso basti. Estendere un pilota senza chiedersi quali condizioni lo hanno reso riuscito. Premiare l'entusiasmo e punire gli errori. Misurare solo gli utenti e gli accessi. Non ridimensionare mai nulla. Sono errori comprensibili, perché distribuire una tecnologia è molto più facile, e più visibile, che creare le condizioni per usarla bene.");
    rowList(s, ["Licenze distribuite = strumento adottato; il lancio come evento concluso", "Attribuire alla resistenza difficoltà strutturali", "Ignorare lo Shadow AI, o chiamare così ogni iniziativa spontanea", "Promuovere a parole senza tempo e risorse; imporre obiettivi d'uso", "Pensare che un corso basti; estendere un pilota senza capirne le condizioni", "Premiare l'entusiasmo e punire gli errori", "Misurare solo utenti e accessi; non ridimensionare mai nulla"], { y: 1.12, h: 0.47, gap: 0.07, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 16 si chiude l'area 'Comprendere il valore per l'azienda'. Abbiamo visto come l'AI crea valore, come trasforma il lavoro, quali condizioni informative servono, come scegliere le opportunità e, ora, come sostenerne l'adozione. I prossimi temi, il 17 e il 18, sono dedicati all'utilizzo responsabile dell'AI. Molte questioni che abbiamo toccato in quest'area, rimandandone l'approfondimento, verranno trattate lì: la protezione dei dati e delle informazioni riservate, la sicurezza, i rischi per le persone, le norme, le responsabilità formali, la governance. In particolare lo Shadow AI, che qui abbiamo esaminato come fenomeno di adozione, verrà ripreso dal punto di vista dei rischi e delle regole. Un'ultima osservazione, che riguarda questo percorso: tutto ciò che abbiamo detto sull'adozione vale anche per la formazione che state seguendo. Le competenze acquisite si consolideranno se ci saranno occasioni per applicarle, tempo, strumenti adatti, supporto e confronto tra colleghi. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Temi 12-16 (area completata)", { x: 0.75, y: 4.07, w: 3.9, h: 0.4, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMA AREA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Utilizzo responsabile dell'AI", { x: 5.4, y: 1.72, w: 3.9, h: 0.5, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Temi 17 e 18: dati, sicurezza, persone, norme, responsabilità, governance", { x: 5.4, y: 2.25, w: 3.9, h: 0.65, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "DA RIPRENDERE", { x: 5.4, y: 3.05, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Lo Shadow AI dal punto di vista dei rischi e delle regole", "Le condizioni di esclusione del Tema 15"], { space: 5 }), { x: 5.4, y: 3.4, w: 3.9, h: 1.3, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Gli studi sull'adozione delle tecnologie e sulla formazione sono consolidati, ma l'adozione dell'AI generativa è un fenomeno recente, e le indagini sul suo uso nelle aziende, come quelle sullo Shadow AI, vengono aggiornate di frequente, con numeri che variano molto: è consigliabile verificarle prima di ogni edizione. Il modello 70-20-10, la curva dell'oblio e l'hype cycle sono presentati come schemi indicativi, con le cautele dovute. Gli esempi aziendali e i numeri del modulo sono fittizi; lo scenario dei documenti commerciali è tratto dal documento di perimetro.");
    const src = [
      "Rogers, E. M. (2003). Diffusion of Innovations, 5a ed. Free Press (ed. orig. 1962).",
      "Davis, F. D. (1989). Perceived Usefulness, Perceived Ease of Use, and User Acceptance of Information Technology. MIS Quarterly, 13(3).",
      "Venkatesh, V. et al. (2003). User Acceptance of Information Technology: Toward a Unified View. MIS Quarterly, 27(3).",
      "Baldwin, T. T., Ford, J. K. (1988). Transfer of Training: A Review and Directions for Future Research. Personnel Psychology, 41(1).",
      "Kirkpatrick, D. L. (1994). Evaluating Training Programs: The Four Levels. Berrett-Koehler.",
      "Edmondson, A. (1999). Psychological Safety and Learning Behavior in Work Teams. Administrative Science Quarterly, 44(2).",
      "Microsoft e LinkedIn (2024). Work Trend Index. Per la diffusione dell'uso di strumenti personali.",
      "Gli esempi aziendali e i numeri delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 6 }), { x: 1.3, y: 1.1, w: 8.2, h: 3.8, fontSize: 11, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema16_Adozione_AI_cambiamento_organizzativo.pptx" });
  await applyTheme("Tema16_Adozione_AI_cambiamento_organizzativo.pptx", THEME);
  console.log("done");
})();
