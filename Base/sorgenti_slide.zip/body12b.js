
  // =====================================================================
  section("12.3 Efficienza e produttività");
  divider("12.3", "AI, efficienza e produttività del lavoro", "Un risparmio di tempo locale non implica un beneficio equivalente per l'organizzazione", "Entriamo nei meccanismi, partendo da quello più citato: l'efficienza. È il beneficio che quasi tutti associano all'AI, e il più facile da percepire: si scrive più in fretta, si riassume più in fretta, si analizza più in fretta. In questo sottotema, da comprendere e applicare, vediamo perché il tempo risparmiato non si trasforma automaticamente in produttività, attraverso due integrazioni centrali del tema: il paradosso della produttività individuale, e il passaggio dall'efficienza locale al risultato complessivo. È probabilmente il sottotema più importante per chi deve valutare iniziative AI in azienda.");
  {
    const s = content("Dove l'AI fa risparmiare tempo", "Partiamo dai benefici, che sono reali. L'AI può supportare due tipi di attività. Le attività ripetitive: compilare, trascrivere, classificare, riformattare, estrarre dati, preparare documenti standard. Qui l'AI riduce il lavoro manuale, spesso in modo consistente. Le attività cognitive: scrivere, riassumere, analizzare, cercare informazioni, preparare una presentazione, scrivere codice. Qui l'AI accelera la produzione di una prima versione, su cui la persona lavora. Il sottotema indica tre effetti. L'accelerazione delle attività e la riduzione dei tempi di esecuzione: la stessa attività richiede meno tempo. L'incremento della capacità produttiva: con le stesse persone si possono gestire più attività. La riduzione dei tempi di attesa, quando l'AI permette di rispondere o di produrre senza dover aspettare la disponibilità di qualcuno. Alcuni studi su attività specifiche hanno osservato aumenti di produttività significativi, che vedremo tra poco, con le loro avvertenze. Il punto di partenza del sottotema è quindi positivo: l'AI può davvero far risparmiare tempo. La domanda è che cosa succede a quel tempo, e se il risparmio di una singola attività arriva fino ai risultati dell'organizzazione.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiRepeat", head: "Attività ripetitive", headSize: 16, bodySize: 12,
      body: bullets(["Compilare, trascrivere, classificare", "Estrarre dati, documenti standard", "Meno lavoro manuale"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCpu", head: "Attività cognitive", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Scrivere, riassumere, analizzare", "Cercare, preparare, programmare", "Una prima versione più rapida"], { space: 5 }) });
    const e = ["Meno tempo per attività", "Più capacità con le stesse persone", "Meno attese"];
    e.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.7, 2.86, 0.6, t, { fill: C.background2, fontSize: 13 }));
    txt(s, "La domanda del sottotema: che cosa succede a quel tempo?", { x: 0.5, y: 4.45, w: 9, h: 0.45, fontSize: 14, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Efficienza e produttività", "Il sottotema chiede di distinguere due concetti spesso usati come sinonimi. L'efficienza riguarda le risorse usate per un'attività: un'attività è più efficiente se richiede meno tempo, meno costi, meno sforzo per ottenere lo stesso risultato. La produttività riguarda il rapporto tra i risultati ottenuti e le risorse impiegate, in un periodo: quante pratiche gestite, quanti clienti serviti, quanto valore prodotto per persona, per ora, per euro. Un aumento di efficienza può tradursi in un aumento di produttività, ma solo a certe condizioni: che il tempo risparmiato venga usato per produrre altri risultati, e che quei risultati servano. Se l'ufficio legale prepara i contratti in metà tempo, ma il numero di contratti da preparare è lo stesso, l'efficienza è aumentata ma la produttività, nel senso dei risultati per l'organizzazione, no, a meno che il tempo liberato venga impiegato in altro modo utile. L'esempio mostra la distinzione: l'efficienza si misura sull'attività, la produttività sui risultati. È la base delle due integrazioni che vedremo.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiClock", head: "Efficienza", headSize: 17, bodySize: 13,
      body: "Meno risorse per la stessa attività: tempo, costi, sforzo.\n\nSi misura sull'attività." });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiTrendingUp", head: "Produttività", headSize: 17, bodySize: 13, fill: C.accent6,
      body: "Risultati ottenuti rispetto alle risorse, in un periodo.\n\nSi misura sui risultati." });
    shapeBox(s, 0.5, 3.6, 9.0, 1.3, C.text1, "esempio");
    txt(s, [{ text: "Esempio: ", options: { bold: true, color: C.accent6 } }, { text: "contratti preparati in metà tempo, ma il numero di contratti da preparare è lo stesso. L'efficienza è aumentata; la produttività solo se il tempo liberato viene usato in altro modo utile.", options: { color: C.background1 } }], { x: 0.75, y: 3.6, w: 8.5, h: 1.3, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Risparmiato o recuperato", "Il primo motivo per cui il tempo risparmiato non è tutto recuperato è la verifica. Il sottotema parla di effetti di verifica e revisione sui tempi, e di differenza tra tempo risparmiato e tempo effettivamente recuperato. L'esempio fittizio in slide lo mostra con numeri inventati. Preparare una relazione richiedeva 120 minuti. Con l'AI, la prima bozza si ottiene in 20 minuti: un risparmio apparente di 100 minuti. Ma la bozza va letta e verificata, 25 minuti; alcune parti vanno corrette o riscritte, 20 minuti; e talvolta serve un passaggio aggiuntivo per controllare dati e fonti, 15 minuti. Il tempo totale con l'AI è di 80 minuti: il risparmio effettivo è di 40 minuti, meno della metà di quello apparente. È ancora un risparmio reale, e significativo. Ma chi misura solo il tempo di produzione della bozza sopravvaluta il beneficio di più del doppio. Nel Tema 7 abbiamo visto che la verifica è necessaria; qui ne vediamo il costo. E il costo della verifica varia molto: per attività in cui gli errori sono facili da individuare è basso, per attività in cui sono difficili da notare può annullare il risparmio, o persino superarlo.");
    valTag(s, 1);
    s.addChart(pres.charts.BAR, [
      { name: "Produzione", labels: ["Senza AI", "Con AI"], values: [120, 20] },
      { name: "Verifica", labels: ["Senza AI", "Con AI"], values: [0, 25] },
      { name: "Correzione", labels: ["Senza AI", "Con AI"], values: [0, 20] },
      { name: "Controllo dati e fonti", labels: ["Senza AI", "Con AI"], values: [0, 15] }], {
      x: 0.5, y: 1.1, w: 5.4, h: 3.1, barDir: "bar", barGrouping: "stacked", chartColors: [HEX.a2, HEX.a1, HEX.a5, HEX.a4],
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisMinVal: 0, valAxisMaxVal: 130, valGridLine: { color: HEX.a3, size: 0.5 },
      showLegend: true, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, barGapWidthPct: 50,
      showTitle: true, title: "Minuti per preparare una relazione (esempio fittizio)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
    const k = [["Risparmio apparente", "100 min", C.background2, C.text1], ["Risparmio effettivo", "40 min", C.accent1, C.background1]];
    k.forEach((e, i) => {
      const y = 1.2 + i * 1.3;
      shapeBox(s, 6.15, y, 3.35, 1.15, e[2], e[0]);
      txt(s, e[0], { x: 6.35, y: y + 0.1, w: 3.0, h: 0.35, fontSize: 13, color: e[3] });
      txt(s, e[1], { x: 6.35, y: y + 0.45, w: 3.0, h: 0.6, fontSize: 28, bold: true, color: i ? C.background1 : C.accent5 });
    });
    banner(s, 4.4, "Chi misura solo la produzione della bozza sopravvaluta il beneficio di più del doppio.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Il paradosso della produttività", "L'integrazione A del tema: il paradosso della produttività individuale. Un risparmio di tempo locale non implica un beneficio equivalente per l'organizzazione. Anche quando il tempo è davvero risparmiato, al netto della verifica, che cosa ne succede? Il documento indica alcune possibilità, che conviene esplicitare. Il tempo liberato viene riutilizzato in attività di valore: più clienti seguiti, progetti prima rimandati, lavoro di migliore qualità. È il caso in cui il beneficio si trasforma davvero in valore. Il tempo viene assorbito da controlli e rilavorazioni, come abbiamo visto. Il tempo non è riutilizzabile: venti minuti risparmiati in giorni diversi, sparsi nella settimana, non si sommano facilmente in un'attività utile; oppure non ci sono altre attività di valore da svolgere. Il tempo si disperde: più riunioni, più email, più rifiniture di dettagli non necessari, a volte semplicemente un ritmo meno intenso, che può anche essere un beneficio per le persone, ma non è produttività. Nessuno di questi esiti è sbagliato in sé. Ma solo il primo produce un aumento di produttività per l'organizzazione, e non avviene da solo: richiede che qualcuno decida come usare la capacità liberata.");
    valTag(s, 1);
    const d = [["FiTrendingUp", "Riutilizzato in attività di valore", "Il beneficio diventa valore", C.accent1, C.background1], ["FiRotateCcw", "Assorbito da controlli e rilavorazioni", "Il beneficio si riduce", C.background2, C.text1], ["FiPieChart", "Frammentato, non riutilizzabile", "Minuti sparsi, nulla di utile da fare", C.background2, C.text1], ["FiWind", "Disperso", "Più riunioni, email, rifiniture", C.background2, C.text1]];
    for (let i = 0; i < 4; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.65, y = 1.15 + row * 1.2;
      shapeBox(s, x, y, 4.35, 1.08, d[i][3], d[i][1]);
      await iconCircle(s, x + 0.18, y + 0.24, 0.6, d[i][0], d[i][4] === C.background1 ? C.background1 : C.accent1, d[i][4] === C.background1 ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.95, y: y + 0.1, w: 3.3, h: 0.5, fontSize: 13, bold: true, color: d[i][4], valign: "middle" });
      txt(s, d[i][2], { x: x + 0.95, y: y + 0.58, w: 3.3, h: 0.42, fontSize: 12, color: d[i][4] });
    }
    banner(s, 3.65, "Solo il primo esito produce produttività per l'organizzazione, e non avviene da solo: qualcuno deve decidere come usare la capacità liberata.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Valorizzare la capacità liberata", "Se il tempo liberato non si trasforma da solo in valore, come lo si valorizza? Il sottotema parla di possibilità di valorizzare la capacità liberata, e la parola chiave è decidere. Alcune strade possibili. Assorbire più volumi senza aumentare le persone: utile quando la domanda cresce, o quando c'erano arretrati. Spostare tempo verso attività di maggior valore: dalla preparazione dei documenti alla relazione con i clienti, dalla compilazione all'analisi. Migliorare la qualità: usare il tempo per verifiche più accurate, per personalizzare, per approfondire. Ridurre i tempi di risposta o di consegna, se questo conta per i clienti. Dedicare tempo alla formazione e al miglioramento dei processi. Ridurre il ricorso a risorse esterne o agli straordinari. Ciascuna strada ha un valore diverso, e la scelta dipende dagli obiettivi dell'organizzazione. Il punto è che deve essere una scelta, presa a livello di team o di organizzazione, e non lasciata al caso. Il modo in cui il lavoro viene riorganizzato per valorizzare la capacità liberata è il tema del Tema 13; qui ci basta riconoscere che senza questa scelta il beneficio individuale resta individuale.");
    valTag(s, 1);
    await iconGrid(s, [
      { icon: "FiInbox", head: "Più volumi", body: "Domanda in crescita, arretrati" },
      { icon: "FiArrowUpRight", head: "Attività di maggior valore", body: "Dalla compilazione all'analisi e alla relazione" },
      { icon: "FiCheckCircle", head: "Più qualità", body: "Verifiche, personalizzazione, approfondimento" },
      { icon: "FiFastForward", head: "Tempi più brevi", body: "Risposte e consegne, se contano per i clienti" },
      { icon: "FiBookOpen", head: "Formazione e miglioramento", body: "Competenze e processi" },
      { icon: "FiMinusCircle", head: "Meno risorse esterne", body: "Consulenze, straordinari" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Deve essere una scelta di team o di organizzazione, non lasciata al caso.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Colli di bottiglia", "L'integrazione D del tema: dall'efficienza locale al risultato complessivo. Accelerare un'attività non migliora necessariamente l'intero processo, soprattutto quando il principale collo di bottiglia si trova altrove. L'esempio del documento di perimetro, con numeri inventati a scopo didattico, è in slide. Un'attività prevede tre passaggi: preparazione, revisione, approvazione. Prima dell'AI richiedevano 30, 20 e 10 minuti, per un totale di 60. Con l'AI la preparazione scende a 10 minuti, due terzi in meno; ma la revisione sale a 25, perché bisogna verificare il lavoro dell'AI; l'approvazione resta a 10. Il totale scende a 45 minuti: una riduzione del 25 per cento, molto meno dei due terzi della preparazione. E il documento aggiunge che neppure questo miglioramento dimostra da solo un pari valore economico: contano il riutilizzo del tempo, la qualità e i vincoli del processo. Se, per esempio, l'approvazione avviene una sola volta al giorno, perché il responsabile la fa la sera, il tempo complessivo dalla richiesta alla consegna non cambia affatto: il collo di bottiglia è l'approvazione, non la preparazione. È un principio noto nella gestione delle operazioni, reso popolare dalla teoria dei vincoli: il ritmo di un processo è determinato dal suo passaggio più lento.");
    valTag(s, 1);
    s.addChart(pres.charts.BAR, [{ name: "Prima dell'AI", labels: ["Preparazione", "Revisione", "Approvazione"], values: [30, 20, 10] }, { name: "Con AI", labels: ["Preparazione", "Revisione", "Approvazione"], values: [10, 25, 10] }], {
      x: 0.5, y: 1.1, w: 5.2, h: 2.9, barDir: "col", chartColors: [HEX.a2, HEX.a1], showValue: true, dataLabelFontSize: 10, dataLabelColor: HEX.dk1, dataLabelPosition: "outEnd",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 35, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, barGapWidthPct: 60,
      showTitle: true, title: "Minuti per passaggio (esempio fittizio)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
    const k = [["Preparazione", "-67%", C.background2, C.text1], ["Processo complessivo", "-25%", C.accent1, C.background1]];
    k.forEach((e, i) => {
      const y = 1.2 + i * 1.3;
      shapeBox(s, 6.0, y, 3.5, 1.15, e[2], e[0]);
      txt(s, e[0], { x: 6.2, y: y + 0.1, w: 3.1, h: 0.35, fontSize: 13, color: e[3] });
      txt(s, e[1], { x: 6.2, y: y + 0.45, w: 3.1, h: 0.6, fontSize: 28, bold: true, color: i ? C.background1 : C.accent1 });
    });
    banner(s, 4.15, "Se l'approvazione avviene una volta al giorno, il tempo dalla richiesta alla consegna non cambia: il collo di bottiglia è altrove.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Individuale e organizzativa", "Due punti del sottotema completano il quadro. La differenza tra produttività individuale e organizzativa, che è una delle precisazioni trasversali del tema. La produttività individuale misura che cosa riesce a fare una persona; quella organizzativa che cosa riesce a fare l'organizzazione nel suo insieme. La seconda non è la somma della prima, perché dipende dalle interdipendenze tra le persone, dai processi, dai colli di bottiglia, dall'uso della capacità liberata. Il rischio di trasferire il lavoro anziché eliminarlo. È un fenomeno sottile e frequente. Se con l'AI si scrivono più facilmente email più lunghe, qualcuno deve leggerle. Se si producono più facilmente report, qualcuno deve esaminarli. Se si generano più facilmente proposte, qualcuno deve valutarle. Il lavoro risparmiato da chi produce viene trasferito a chi riceve, e il totale può persino aumentare. Lo stesso accade quando l'AI sposta il lavoro dalla produzione alla verifica, cioè dal giovane collaboratore che prepara al responsabile che controlla, spesso una persona più costosa e con meno tempo. Per riconoscere questi effetti bisogna guardare all'intero flusso di lavoro, non solo a chi usa lo strumento.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiUser", head: "Individuale e organizzativa", headSize: 15, bodySize: 12,
      body: bullets(["Ciò che fa una persona, ciò che fa l'organizzazione", "La seconda non è la somma della prima", "Interdipendenze, processi, colli di bottiglia"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiShuffle", head: "Lavoro trasferito", headSize: 15, bodySize: 12, fill: C.accent6, iconBg: C.accent5,
      body: bullets(["Email più lunghe: qualcuno deve leggerle", "Più report: qualcuno deve esaminarli", "Dalla produzione alla verifica, verso chi costa di più"], { space: 4 }) });
    chip(s, 0.5, 3.6, 2.6, 0.7, "Chi produce risparmia", { fill: C.accent6, fontSize: 13 });
    arrow(s, 3.2, 3.79, 0.5, C.accent5);
    chip(s, 3.8, 3.6, 2.6, 0.7, "Chi riceve lavora di più", { fill: C.background2, fontSize: 13 });
    txt(s, "Il totale può persino aumentare", { x: 6.6, y: 3.6, w: 2.9, h: 0.7, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    txt(s, "Guardare all'intero flusso di lavoro, non solo a chi usa lo strumento.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent1 });
  }
  {
    const s = content("Che cosa dicono alcuni studi", "Alcuni studi hanno misurato gli effetti dell'AI generativa sulla produttività in contesti reali o controllati. Due sono spesso citati, e utili anche per le loro avvertenze. Il primo, di Brynjolfsson, Li e Raymond, pubblicato nel 2025 sul Quarterly Journal of Economics, ha osservato 5.172 operatori di assistenza clienti di un'azienda di software: con un assistente AI, il numero di problemi risolti per ora è aumentato in media del 15 per cento, con un aumento del 36 per cento per gli operatori meno esperti e nessun aumento significativo per i più esperti. Se qualcuno ricorda i dati del 14 e del 34 per cento: vengono dalla prima versione del 2023, ancora molto citata. Il secondo, di Dell'Acqua e colleghi, presentato nel 2023 e pubblicato nel 2026 sulla rivista Organization Science, ha coinvolto 758 consulenti di una società di consulenza. Su compiti adatti alle capacità dell'AI, chi la usava ha completato in media il 12,2 per cento di compiti in più, il 25,1 per cento più velocemente e con una qualità superiore di circa il 32 per cento; su un compito scelto apposta al di fuori di quelle capacità, chi usava l'AI arrivava alla soluzione corretta in media 19 punti percentuali meno spesso di chi lavorava senza. Se qualcuno ricorda il dato 'oltre il 40 per cento' sulla qualità: viene dalla prima versione del 2023. Gli autori parlano di una frontiera tecnologica frastagliata: non è sempre evidente quali compiti stiano al di qua o al di là. Gli stessi studi sono presentati brevemente nel Tema 1 come segnale di rilevanza; qui li usiamo per ragionare sul valore. Tre avvertenze, coerenti con il documento. I risultati riguardano compiti e contesti specifici, e non si trasferiscono automaticamente. Misurano la produttività su attività, non necessariamente su risultati organizzativi. E il documento chiede di evitare di trasformare stime o esperienze isolate in promesse generali di produttività.");
    valTag(s, 1);
    await card(s, 0.5, 1.15, 4.35, 2.45, { icon: "FiHeadphones", head: "Assistenza clienti (2025)", headSize: 14, bodySize: 12,
      body: bullets(["5.172 operatori", "+15% di problemi risolti per ora, in media", "+36% per i meno esperti, nessun aumento significativo per i più esperti"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.45, { icon: "FiBriefcase", head: "Consulenti (2026)", headSize: 14, bodySize: 12, fill: C.accent6,
      body: bullets(["Compiti adatti: +12% compiti, +25% velocità, qualità +32% circa", "Compito fuori dalle capacità: 19 punti in meno di soluzioni corrette", "Una frontiera 'frastagliata'"], { space: 4 }) });
    shapeBox(s, 0.5, 3.8, 9.0, 1.15, C.text1, "avvertenze");
    txt(s, "Avvertenze", { x: 0.75, y: 3.86, w: 8.5, h: 0.32, fontSize: 13, bold: true, color: C.accent6 });
    txt(s, "Compiti e contesti specifici, non trasferibili automaticamente; produttività su attività, non su risultati organizzativi; nessuna promessa generale.", { x: 0.75, y: 4.2, w: 8.5, h: 0.7, fontSize: 12, color: C.background1 });
  }

  {
    const s = content("Velocità, qualità, carichi", "L'ultimo punto del sottotema: i compromessi tra velocità, qualità e carichi di lavoro, applicati all'efficienza. Quando l'AI accelera un'attività, si aprono tre possibilità, e la scelta tra esse ha conseguenze diverse. Si può mantenere la stessa qualità e liberare tempo: il caso ideale, se il tempo viene valorizzato. Si può aumentare la velocità a scapito della qualità, comprimendo la verifica: un rischio frequente quando ci si aspetta che l'AI faccia risparmiare tempo e la pressione sui tempi aumenta; gli errori aumentano, e spesso vengono pagati più avanti nel processo o dai clienti. Si può aumentare il volume di lavoro richiesto a ogni persona, assumendo che l'AI renda tutto più rapido: se le aspettative crescono più del beneficio reale, il risultato è un aumento dei carichi e dello stress, e una spinta a ridurre i controlli. Quest'ultimo effetto è particolarmente importante per chi gestisce persone: se gli obiettivi vengono aumentati sulla base dei benefici attesi invece che di quelli misurati, il divario ricade sulle persone. È anche un buon motivo per misurare i benefici prima di cambiare gli obiettivi, come vedremo nel 12.8.");
    valTag(s, 1);
    const c = [["Stessa qualità, tempo liberato", "Il caso ideale, se il tempo viene valorizzato", C.accent6, C.text1], ["Più velocità, meno qualità", "Verifica compressa: errori pagati più avanti o dai clienti", C.background2, C.text1], ["Più volume per persona", "Aspettative oltre il beneficio reale: carichi, stress, meno controlli", C.text1, C.background1]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.92;
      shapeBox(s, 0.5, y, 9.0, 0.82, e[2], e[0]);
      txt(s, e[0], { x: 0.7, y, w: 3.3, h: 0.82, fontSize: 14, bold: true, color: e[3] === C.background1 ? C.accent6 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 4.0, y, w: 5.3, h: 0.82, fontSize: 13, color: e[3], valign: "middle" });
    });
    banner(s, 4.0, "Se gli obiettivi crescono sui benefici attesi invece che misurati, il divario ricade sulle persone.", { h: 0.85, fontSize: 14 });
  }
  keySlide("Un risparmio di tempo locale non implica un beneficio equivalente per l'organizzazione; accelerare un'attività non migliora il processo se il collo di bottiglia è altrove.", "Sottotema 12.3  ·  AI, efficienza e produttività del lavoro", "Concetto chiave del sottotema 12.3, che riunisce le integrazioni A e D. L'AI può far risparmiare tempo su attività ripetitive e cognitive. Ma efficienza e produttività sono diverse; il tempo risparmiato si riduce con la verifica; il tempo liberato può essere riutilizzato, assorbito, frammentato o disperso, e diventa valore solo se qualcuno decide come usarlo; il processo va al ritmo del suo collo di bottiglia; la produttività organizzativa non è la somma di quella individuale, e il lavoro può essere trasferito invece che eliminato. Gli studi disponibili mostrano benefici reali su compiti specifici, da non trasformare in promesse generali. Esercizio suggerito: ricostruire con i partecipanti un processo reale in tre o quattro passaggi, stimare i tempi prima e dopo l'AI, compresa la verifica, e individuare il collo di bottiglia.");

  // =====================================================================
  section("12.4 Qualità");
  divider("12.4", "AI, qualità e miglioramento delle prestazioni", "L'AI può migliorare alcune dimensioni della qualità ma introdurre nuovi errori: servono criteri osservabili", "Il secondo meccanismo di creazione di valore è la qualità. Spesso l'AI non fa risparmiare tempo, ma permette di fare meglio: risultati più completi, più coerenti, più rapidi da ottenere. In questo sottotema, da comprendere, vediamo dove l'AI può migliorare la qualità, ma anche come può introdurre nuovi errori, in particolare errori sistematici, la differenza tra qualità apparente ed effettiva, e la necessità di criteri osservabili per valutare il miglioramento. Il confine con il 12.3: lì tempi e capacità, qui qualità e affidabilità.");
  {
    const s = content("Dove migliora la qualità", "Il sottotema elenca diversi modi in cui l'AI può migliorare la qualità del lavoro. Completezza dei contenuti: l'AI può suggerire elementi dimenticati, controllare che un documento contenga tutte le sezioni richieste, ricordare casi da considerare. Standardizzazione di alcune attività: risposte, documenti e procedure più uniformi, basati sugli stessi modelli e sulle stesse informazioni. Riduzione delle operazioni manuali: meno trascrizioni e copiature, e quindi meno errori di battitura o di trasferimento. Supporto alla revisione e al controllo: rilettura, individuazione di incoerenze, confronto con requisiti e checklist, come visto nel Tema 7. Maggiore disponibilità delle informazioni: accesso più rapido a procedure, documentazione, storico, come visto nel Tema 8. Coerenza e uniformità dei risultati tra persone diverse. Miglioramento dei tempi di risposta, che per il cliente è spesso una componente della qualità del servizio. In molti casi questi benefici sono più importanti del risparmio di tempo, e meno visibili: una riduzione degli errori evita costi che nessuno vede, come reclami, rilavorazioni, rischi.");
    valTag(s, 1);
    await iconGrid(s, [
      { icon: "FiCheckSquare", head: "Completezza", body: "Elementi dimenticati, sezioni, casi" },
      { icon: "FiLayers", head: "Standardizzazione", body: "Stessi modelli e informazioni" },
      { icon: "FiEdit", head: "Meno operazioni manuali", body: "Meno errori di trascrizione" },
      { icon: "FiSearch", head: "Revisione e controllo", body: "Incoerenze, requisiti, checklist" },
      { icon: "FiBookOpen", head: "Informazioni disponibili", body: "Procedure, documentazione, storico" },
      { icon: "FiClock", head: "Tempi di risposta", body: "Una componente della qualità del servizio" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Benefici spesso più importanti del tempo, e meno visibili: gli errori evitati non si vedono.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Qualità apparente ed effettiva", "La distinzione centrale del sottotema, che abbiamo incontrato in molti temi precedenti: qualità apparente e qualità effettiva. I risultati prodotti con l'AI hanno quasi sempre un'alta qualità apparente: testi fluidi, documenti ben strutturati, report curati, presentazioni gradevoli. La qualità effettiva riguarda la sostanza: correttezza, completezza rispetto a ciò che serve, adeguatezza al destinatario e allo scopo. Il rischio, quando si valuta l'impatto dell'AI sulla qualità, è di misurare la prima e credere di aver misurato la seconda. Un esempio fittizio: dopo l'introduzione dell'AI nella preparazione delle offerte, i commerciali giudicano le offerte 'più professionali'. È un miglioramento reale della qualità apparente, e può avere effetti positivi sui clienti. Ma se nello stesso periodo aumentano le offerte con condizioni errate, la qualità effettiva è peggiorata. Il punto non è che la qualità apparente non conti: conta, per la comunicazione e la percezione. Il punto è che non va confusa con l'altra, e che entrambe vanno osservate con criteri diversi. Nel Tema 7 abbiamo visto come valutare la qualità effettiva di un singolo output; qui parliamo di valutare l'effetto dell'AI sulla qualità del lavoro nel suo insieme.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiStar", head: "Qualità apparente", headSize: 16, bodySize: 12,
      body: bullets(["Fluidità, struttura, cura formale", "Con l'AI quasi sempre alta", "Conta per comunicazione e percezione"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCheckCircle", head: "Qualità effettiva", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Correttezza, completezza, adeguatezza", "Da verificare caso per caso", "Ciò che determina il valore"], { space: 5 }) });
    docBox(s, 0.5, 3.7, 9.0, 1.2, "Esempio fittizio", "Le offerte preparate con l'AI sono giudicate 'più professionali' (qualità apparente in aumento), ma nello stesso periodo aumentano le offerte con condizioni errate (qualità effettiva in calo).", { fontSize: 12 });
  }
  {
    const s = content("Il rischio di errori sistematici", "Un rischio specifico che il sottotema mette in evidenza: l'AI può introdurre errori sistematici. Gli errori umani sono di solito sparsi: una persona sbaglia un calcolo, un'altra dimentica un passaggio, in momenti diversi e in modi diversi. Gli errori di un sistema AI usato da molte persone per la stessa attività tendono invece a ripetersi: se lo strumento interpreta male una clausola, la interpreta male in tutti i contratti; se la documentazione su cui si basa contiene un'informazione superata, tutte le risposte la riportano; se ha una tendenza a omettere un certo tipo di eccezione, la omette sempre. Questo ha due conseguenze. Gli errori possono diffondersi su larga scala prima che qualcuno se ne accorga, proprio perché il sistema è usato tanto e in modo uniforme. E la standardizzazione, che è un beneficio di qualità, può trasformarsi in un rischio: se tutti fanno la stessa cosa nello stesso modo, un errore nel modo diventa un errore ovunque. Le contromisure sono quelle viste nei temi precedenti, applicate a livello organizzativo: controlli a campione regolari, monitoraggio degli errori nel tempo, aggiornamento delle informazioni di base, attenzione ai segnali deboli, come un aumento anche lieve di reclami su un certo tema.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiUsers", head: "Errori umani", headSize: 16, bodySize: 12,
      body: bullets(["Sparsi, in momenti e modi diversi", "Un calcolo sbagliato, un passaggio dimenticato"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiCopy", head: "Errori sistematici", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Si ripetono: stessa clausola, stessa informazione superata", "Diffusi su larga scala prima che qualcuno se ne accorga"], { space: 5 }) });
    shapeBox(s, 0.5, 3.6, 9.0, 0.6, C.accent6, "standardizzazione");
    txt(s, "Se tutti fanno la stessa cosa nello stesso modo, un errore nel modo diventa un errore ovunque.", { x: 0.7, y: 3.6, w: 8.6, h: 0.6, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    const c = ["Controlli a campione regolari", "Monitoraggio nel tempo", "Informazioni aggiornate", "Segnali deboli"];
    c.forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.35, 2.15, 0.55, t, { fill: C.background2, fontSize: 12 }));
  }
  {
    const s = content("Criteri osservabili", "La consapevolezza del sottotema si chiude con una richiesta precisa: occorrono criteri osservabili per valutare l'effetto dell'AI sulla qualità. 'Le risposte sono migliori' non è un criterio; 'il numero di risposte che richiedono una seconda interazione con il cliente è sceso dal 18 al 12 per cento' lo è. La tabella in slide propone, per alcune dimensioni della qualità, indicatori osservabili tipici. Accuratezza: tasso di errori trovati in revisione o segnalati dopo la consegna. Completezza: percentuale di documenti che superano una lista di controllo dei requisiti. Rilavorazioni: quante volte un risultato deve essere rifatto o corretto. Soddisfazione: valutazioni dei clienti o dei destinatari interni, reclami. Coerenza: differenze tra risultati prodotti da persone diverse sullo stesso tipo di caso. Tempi di risposta: tempo tra richiesta e risposta. Due avvertenze. Gli indicatori vanno misurati prima e dopo l'introduzione dell'AI, altrimenti non si sa se qualcosa è cambiato; e conviene misurarne più d'uno, per non migliorare una dimensione a spese di un'altra. Il 12.8 svilupperà questi aspetti. La relazione tra qualità, velocità e affidabilità, che il sottotema richiama, si vede proprio misurando più indicatori insieme.");
    valTag(s, 1);
    table(s, [["Dimensione", "Indicatore osservabile"],
      ["Accuratezza", "Errori trovati in revisione o segnalati dopo la consegna"],
      ["Completezza", "Documenti che superano la lista dei requisiti"],
      ["Rilavorazioni", "Risultati rifatti o corretti"],
      ["Soddisfazione", "Valutazioni dei destinatari, reclami"],
      ["Coerenza", "Differenze tra persone sullo stesso tipo di caso"],
      ["Tempi di risposta", "Tempo tra richiesta e risposta"]],
      { y: 1.15, colW: [2.6, 6.4], rowH: 0.4, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 4.05, "'Le risposte sono migliori' non è un criterio. Misurare prima e dopo, e più di un indicatore insieme.", { h: 0.75, fontSize: 13 });
  }
  keySlide("L'AI può migliorare alcune dimensioni della qualità ma introdurre nuovi errori: occorrono criteri osservabili per valutarne l'effetto.", "Sottotema 12.4  ·  AI, qualità e miglioramento delle prestazioni", "Concetto chiave del sottotema 12.4. L'AI può rendere il lavoro più completo, standardizzato, coerente, con meno operazioni manuali, più supporto alla revisione e informazioni più disponibili. Ma la qualità apparente non è quella effettiva, gli errori di un sistema usato da molti tendono a essere sistematici e a diffondersi, e la standardizzazione può trasformarsi in un rischio. Servono criteri osservabili, misurati prima e dopo, su più dimensioni. Esercizio suggerito: per un'attività in cui si usa l'AI, definire due o tre indicatori osservabili di qualità e discutere come misurarli prima e dopo.");

  // =====================================================================
  section("12.5 Competenze");
  divider("12.5", "AI come amplificatore delle competenze", "Alcuni benefici non sono risparmi di tempo, ma l'accesso ad attività prima troppo difficili o costose", "Terzo meccanismo: l'amplificazione delle competenze e delle capacità. Qui il valore non sta nel fare più in fretta ciò che già si faceva, ma nel poter fare ciò che prima non si riusciva a fare: un compito al di sopra delle proprie competenze, un'analisi che richiedeva uno specialista, un servizio che non era sostenibile con le risorse disponibili. In questo sottotema, da comprendere, vediamo come l'AI può amplificare le capacità delle persone, l'integrazione B, cioè il valore di fare cose prima impossibili, e i rischi: dipendenza, riduzione delle competenze, e la differenza tra amplificare e sostituire.");
  {
    const s = content("Persone con esperienze diverse", "Il primo punto del sottotema: il supporto a persone con differenti livelli di esperienza. Gli studi citati nel 12.3 hanno osservato un fenomeno ricorrente: in molti compiti, l'AI aiuta soprattutto le persone meno esperte. Nello studio sull'assistenza clienti, i benefici erano molto maggiori per gli operatori nuovi, che con l'AI raggiungevano più rapidamente le prestazioni dei colleghi esperti; per i più esperti, i benefici erano quasi nulli. Una spiegazione plausibile è che l'AI renda accessibili a tutti le conoscenze e le pratiche che prima erano patrimonio dei più esperti. È un effetto con implicazioni importanti: riduzione dei tempi di inserimento dei nuovi colleghi, maggiore uniformità delle prestazioni, possibilità per persone junior di affrontare compiti più complessi. Ma ha anche un rovescio, che vedremo tra poco: se le persone meno esperte svolgono compiti al di sopra delle loro competenze grazie all'AI, sono anche quelle meno in grado di accorgersi quando l'AI sbaglia. E se i più esperti non ricevono benefici, il loro ruolo può cambiare, per esempio verso la supervisione e la gestione dei casi difficili. Il sottotema elenca anche l'accesso facilitato a conoscenze e strumenti, la riduzione delle barriere tecniche, come visto nel Tema 9 per l'analisi dei dati, e il supporto all'apprendimento operativo.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiUserPlus", head: "Meno esperti", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Benefici maggiori", "Raggiungono prima le prestazioni degli esperti", "Compiti più complessi accessibili"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiAward", head: "Più esperti", headSize: 16, bodySize: 12,
      body: bullets(["Benefici spesso minori", "Il ruolo si sposta verso supervisione e casi difficili"], { space: 5 }) });
    shapeBox(s, 0.5, 3.8, 9.0, 1.1, C.text1, "rovescio");
    txt(s, [{ text: "Il rovescio: ", options: { bold: true, color: C.accent6 } }, { text: "chi svolge compiti oltre le proprie competenze grazie all'AI è anche chi meno si accorge quando l'AI sbaglia.", options: { color: C.background1 } }], { x: 0.75, y: 3.8, w: 8.5, h: 1.1, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Fare cose prima impossibili", "L'integrazione B del tema: il valore dell'AI può derivare dal fare cose prima impossibili. Alcuni benefici non sono risparmi di tempo, ma l'accesso ad attività prima troppo difficili, costose o poco praticabili. Alcuni esempi. Analizzare tutti i commenti dei clienti dell'ultimo anno, migliaia di testi, per capire i motivi di insoddisfazione: prima si leggeva un campione, o nulla. Offrire documentazione e assistenza in dieci lingue invece che in due. Preparare per ogni cliente una proposta personalizzata, invece che una standard. Permettere a un piccolo ufficio senza analisti di fare analisi dei dati. Confrontare in modo sistematico tutte le offerte dei fornitori, invece che le tre principali. Creare materiali formativi per ogni procedura, invece che per le principali. In questi casi, misurare il beneficio come tempo risparmiato non ha senso: prima l'attività non si faceva, quindi non c'era tempo da risparmiare. Il valore va cercato nei risultati che l'attività nuova rende possibili: clienti trattenuti, mercati raggiunti, decisioni migliori, rischi evitati. È un tipo di valore spesso più importante dell'efficienza, ma anche più difficile da dimostrare, perché richiede di stimare che cosa si guadagna da qualcosa che prima non c'era.");
    valTag(s, 1);
    const e = [["Prima", "Ora possibile"], ["Leggere un campione di commenti", "Analizzarli tutti, migliaia"], ["Assistenza in due lingue", "In dieci lingue"], ["Una proposta standard", "Una proposta per cliente"], ["Nessun analista", "Analisi dei dati in un piccolo ufficio"], ["Tre offerte confrontate", "Tutte le offerte"]];
    table(s, e, { y: 1.15, colW: [4.5, 4.5], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 3.85, "Prima l'attività non si faceva: misurare il tempo risparmiato non ha senso. Il valore sta nei risultati che rende possibili.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Competenze umane e capacità AI", "Il sottotema parla di collaborazione tra competenze umane e capacità AI, e di importanza della conoscenza del contesto. Riprendiamo un principio emerso in molti temi: l'AI amplifica le competenze di chi la usa, ma non le sostituisce. Il risultato di una collaborazione dipende da entrambi i contributi. L'AI porta velocità, ampiezza di conoscenze generali, capacità di elaborare grandi quantità di informazioni, disponibilità continua. La persona porta la conoscenza del contesto: i clienti, l'azienda, la storia, le regole non scritte, le priorità. Porta il giudizio: che cosa è importante, che cosa è plausibile, che cosa è accettabile. Porta la responsabilità. E porta la capacità di riconoscere quando l'AI sbaglia, che dipende proprio dalle competenze. Questo spiega perché lo stesso strumento produce risultati molto diversi nelle mani di persone diverse, e perché le competenze di dominio restano decisive anche quando l'AI riduce le barriere tecniche. Un esperto con l'AI fa spesso meglio di un esperto senza; un inesperto con l'AI fa spesso meglio di un inesperto senza, ma non sempre meglio di un esperto, e soprattutto può non sapere quando l'AI lo sta portando fuori strada.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiCpu", head: "Che cosa porta l'AI", headSize: 16, bodySize: 12,
      body: bullets(["Velocità", "Ampiezza di conoscenze generali", "Grandi quantità di informazioni", "Disponibilità continua"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiUser", head: "Che cosa porta la persona", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Conoscenza del contesto", "Giudizio su importanza e plausibilità", "Responsabilità", "Capacità di riconoscere gli errori"], { space: 4 }) });
    banner(s, 3.9, "Lo stesso strumento produce risultati diversi in mani diverse: le competenze di dominio restano decisive.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Dipendenza e competenze", "Il rischio di dipendenza e di riduzione delle competenze, che il sottotema richiama e che il Tema 5 ha trattato come delega cognitiva. Qui lo guardiamo dal punto di vista del valore per l'azienda. Se le persone delegano sistematicamente all'AI attività che prima svolgevano, alcune competenze possono indebolirsi per mancanza di esercizio: scrivere, analizzare, calcolare, ragionare su un problema complesso. Per i più esperti il rischio è contenuto; per chi si forma oggi, il rischio è di non sviluppare mai quelle competenze. È un problema di valore per tre ragioni. Le competenze servono per verificare il lavoro dell'AI: senza di esse, la qualità effettiva peggiora senza che nessuno se ne accorga. Servono per gestire i casi difficili e le eccezioni, come visto nel Tema 11. E servono quando l'AI non è disponibile, o non è adatta al compito, come nello studio sui consulenti, dove proprio sui compiti al di fuori delle capacità dell'AI chi la usava sbagliava di più. Il valore apparente di breve periodo, cioè più velocità oggi, può nascondere un costo di lungo periodo, cioè meno capacità domani. Alcune contromisure: alternare lavoro con e senza AI nella formazione, chiedere spiegazioni e non solo risultati, mantenere momenti di revisione tra colleghi.");
    valTag(s, 1);
    const r = [["Verificare l'AI", "Senza competenze, la qualità peggiora senza che nessuno se ne accorga"], ["Gestire i casi difficili", "Le eccezioni richiedono chi sa come si fa"], ["Quando l'AI non basta", "Fuori dalle sue capacità, chi la usa sbaglia di più"]];
    r.forEach((e, i) => {
      const y = 1.15 + i * 0.75;
      shapeBox(s, 0.5, y, 9.0, 0.65, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.8, h: 0.65, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.5, y, w: 5.8, h: 0.65, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 3.5, "Più velocità oggi può nascondere meno capacità domani.", { h: 0.65, fontSize: 15 });
    const c = ["Alternare con e senza AI nella formazione", "Chiedere spiegazioni, non solo risultati", "Revisione tra colleghi"];
    c.forEach((t, i) => chip(s, 0.5 + i * 3.07, 4.35, 2.86, 0.6, t, { fill: C.background2, fontSize: 12 }));
  }
  {
    const s = content("Amplificare o sostituire", "L'ultimo punto del sottotema: la differenza tra amplificazione delle capacità e sostituzione delle competenze. Amplificare significa che la persona, con l'AI, fa di più o fa meglio ciò che sa fare, o affronta compiti un po' oltre le proprie competenze, mantenendo la capacità di capire e valutare il risultato. Sostituire significa che l'AI svolge il compito al posto della persona, che non ne comprende più il contenuto e non è in grado di valutarlo. La distinzione non dipende dallo strumento, ma da come viene usato e da come il lavoro è organizzato. Lo stesso assistente può amplificare un analista che lo usa per esplorare più ipotesi, e sostituire un collega che ne copia i risultati senza capirli. Nel primo caso il valore è solido; nel secondo è fragile, perché dipende interamente dall'affidabilità dello strumento, senza nessun controllo. Il sottotema chiede di riconoscere questa differenza, perché da essa dipende la sostenibilità del valore nel tempo. Un criterio pratico: la persona saprebbe spiegare il risultato, riconoscere un errore, e fare il lavoro anche senza l'AI, magari più lentamente? Se sì, l'AI amplifica; se no, sostituisce. La trasformazione dei ruoli e delle competenze è il tema del Tema 13.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiTrendingUp", head: "Amplificare", headSize: 17, bodySize: 12, fill: C.accent6,
      body: bullets(["Fare di più o meglio ciò che si sa fare", "Capire e valutare il risultato", "Valore solido"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCopy", head: "Sostituire", headSize: 17, bodySize: 12, iconBg: C.accent5,
      body: bullets(["L'AI fa al posto della persona", "Nessuno capisce né valuta", "Valore fragile, senza controllo"], { space: 5 }) });
    shapeBox(s, 0.5, 3.7, 9.0, 1.2, C.text1, "criterio");
    txt(s, "Criterio pratico", { x: 0.75, y: 3.78, w: 8.5, h: 0.35, fontSize: 14, bold: true, color: C.accent6 });
    txt(s, "La persona saprebbe spiegare il risultato, riconoscere un errore, e fare il lavoro anche senza l'AI? Se sì, amplifica; se no, sostituisce.", { x: 0.75, y: 4.15, w: 8.5, h: 0.7, fontSize: 13, color: C.background1 });
  }
  keySlide("Il valore dell'AI può derivare dal fare cose prima impossibili: alcuni benefici non sono risparmi di tempo, ma l'accesso ad attività prima troppo difficili, costose o poco praticabili.", "Sottotema 12.5  ·  AI come amplificatore delle competenze", "Concetto chiave del sottotema 12.5, che coincide con l'integrazione B. L'AI può amplificare le capacità delle persone, specialmente delle meno esperte, ridurre le barriere tecniche, sostenere l'apprendimento e rendere possibili attività prima impraticabili, il cui valore non si misura in tempo risparmiato. Ma le competenze umane e la conoscenza del contesto restano decisive, la dipendenza può indebolire le competenze necessarie per verificare e gestire i casi difficili, e amplificare non è sostituire. Esercizio suggerito: chiedere ai partecipanti di individuare un'attività che oggi non svolgono, per mancanza di tempo o di competenze, e che l'AI renderebbe possibile, e di descrivere quale risultato produrrebbe.");
