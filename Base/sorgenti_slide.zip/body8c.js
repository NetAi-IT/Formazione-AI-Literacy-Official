
  // =====================================================================
  section("8.6 Ricerca");
  divider("8.6", "Ricerca, approfondimento e organizzazione", "L'AI può sostenere ricerca e organizzazione della conoscenza, senza rendere automaticamente attendibili le informazioni", "Passiamo alla quarta modalità: recuperare conoscenza. In questo sottotema, da comprendere, guardiamo all'AI come supporto alla ricerca informativa e all'approfondimento di argomenti: trovare fonti, esplorare un tema, organizzare ciò che si è raccolto, preparare dossier. È un uso molto diffuso, che cambia il modo di cercare informazioni rispetto ai motori di ricerca tradizionali. La distinzione centrale del sottotema è tra la conoscenza incorporata nel modello e le informazioni recuperate da fonti esterne, e tra ricerca assistita e verifica delle fonti. Il metodo di verifica l'abbiamo visto nel Tema 7: qui ci concentriamo su come l'AI può sostenere la ricerca, e su che cosa non può garantire.");
  {
    const s = content("L'AI nel lavoro di ricerca", "L'AI può intervenire in diverse fasi del lavoro di ricerca e approfondimento. Nell'orientamento: capire rapidamente i concetti di base di un argomento nuovo, il lessico, le questioni principali, le domande giuste da porsi. Nell'identificazione di fonti e materiali: suggerire tipi di fonti, enti di riferimento, documenti normativi, parole chiave per la ricerca; con gli strumenti dotati di ricerca web, trovare e citare pagine specifiche. Nell'approfondimento: esplorare un aspetto specifico, chiedere spiegazioni, esempi, collegamenti. Nell'organizzazione: raggruppare le informazioni raccolte per tema, individuare sovrapposizioni e lacune, costruire uno schema. Nella produzione: preparare un dossier, una sintesi tematica, una nota di aggiornamento. Il valore principale è la velocità di orientamento: in pochi minuti si passa da 'non so nulla di questo argomento' a 'so che cosa cercare e dove'. Il limite principale, che svilupperemo, è che velocità di orientamento non significa attendibilità delle informazioni. Alcune funzioni di ricerca approfondita svolgono molte ricerche in sequenza e producono rapporti estesi con molte fonti: utili, ma con le stesse esigenze di verifica.");
    modeTag(s, 3);
    const ph = [["FiCompass", "Orientarsi", "Concetti, lessico, domande giuste"], ["FiSearch", "Trovare fonti", "Tipi di fonti, enti, parole chiave, pagine"], ["FiZoomIn", "Approfondire", "Spiegazioni, esempi, collegamenti"], ["FiFolder", "Organizzare", "Temi, sovrapposizioni, lacune"], ["FiFileText", "Produrre", "Dossier, sintesi tematiche, note"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.2, 1.66, 2.4, i % 2 ? C.accent6 : C.background2, ph[i][1]);
      await iconCircle(s, x + 0.53, 1.35, 0.6, ph[i][0]);
      txt(s, ph[i][1], { x: x + 0.08, y: 2.05, w: 1.5, h: 0.4, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, ph[i][2], { x: x + 0.1, y: 2.5, w: 1.46, h: 1.0, fontSize: 11, color: C.text2, align: "center" });
      if (i < 4) arrow(s, x + 1.665, 2.2, 0.17);
    }
    banner(s, 3.85, "Il valore: dalla domanda 'che cosa so?' a 'che cosa cercare e dove' in pochi minuti. Velocità di orientamento non significa attendibilità.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Incorporata o recuperata?", "Una distinzione fondamentale, introdotta nel Tema 2 e qui ripresa per le sue conseguenze pratiche. La conoscenza incorporata nel modello è ciò che il modello ha appreso durante l'addestramento: è vasta, ma ha una data limite, può contenere errori, non ha fonti precise da citare, e quando manca il sistema tende a ricostruire risposte plausibili. Le informazioni recuperate esternamente sono quelle che il sistema ottiene durante la conversazione: da una ricerca web, da documenti caricati, da una base documentale aziendale. Sono più aggiornate, possono essere citate e verificate, ma dipendono dalla qualità delle fonti trovate e dalla correttezza con cui il sistema le legge e le riporta. In pratica, la domanda da porsi davanti a una risposta è: da dove viene questa informazione? Se lo strumento indica le fonti consultate, la risposta si basa almeno in parte su informazioni recuperate, e si può controllare. Se non le indica, la risposta probabilmente viene dalla conoscenza incorporata, e va trattata con più cautela, soprattutto per fatti recenti, dati specifici, norme, prezzi, persone. Molti strumenti combinano le due cose nella stessa risposta, e non sempre distinguono chiaramente quale parte viene da dove.");
    modeTag(s, 3);
    table(s, [["", "Conoscenza incorporata", "Informazioni recuperate"],
      ["Origine", "Addestramento del modello", "Web, documenti caricati, basi documentali"],
      ["Aggiornamento", "Fino a una data limite", "Al momento della ricerca"],
      ["Fonti", "Non citabili con precisione", "Citabili e verificabili"],
      ["Rischio tipico", "Ricostruzioni plausibili ma errate", "Fonti scadenti, lettura imprecisa"]],
      { y: 1.15, colW: [2.0, 3.5, 3.5], rowH: 0.48, fontSize: 12, accentCol: 2 });
    banner(s, 3.75, "La domanda da porsi: da dove viene questa informazione? Senza fonti indicate, più cautela su fatti recenti, dati, norme, prezzi.", { h: 0.8, fontSize: 13 });
    txt(s, "Molti strumenti combinano le due cose, e non sempre distinguono quale parte viene da dove.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Attualità e attendibilità", "Due requisiti delle informazioni trovate, che l'AI non garantisce automaticamente. L'attualità: un'informazione corretta un anno fa può non esserlo oggi. Riguarda in particolare norme e scadenze, prezzi e tariffe, organigrammi e ruoli, prodotti e versioni, dati di mercato, eventi recenti. Se l'informazione viene dalla conoscenza incorporata, può essere superata senza alcun segnale. Se viene da una ricerca, può essere stata trovata in una pagina vecchia. Conviene verificare la data della fonte e, per le informazioni sensibili al tempo, cercare esplicitamente la versione più recente. L'attendibilità: chi ha prodotto l'informazione, con quali competenze e quali interessi? I criteri sono quelli visti nel Tema 7. Qui aggiungiamo un rischio specifico della ricerca assistita: il sistema seleziona e sintetizza le fonti secondo criteri non trasparenti, e può dare lo stesso peso a una fonte istituzionale e a un blog, o presentare come consolidata una posizione che compare in poche fonti. Inoltre la sintesi delle fonti può introdurre le stesse perdite di significato viste nell'8.3. Il risultato è che una risposta con molte fonti citate può sembrare più solida di quanto sia.");
    modeTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.45, { icon: "FiClock", head: "Attualità", headSize: 16, bodySize: 12,
      body: bullets(["Norme, scadenze, prezzi, ruoli, versioni", "Conoscenza incorporata: superata senza segnali", "Ricerca: pagina vecchia; controllare la data"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.45, { icon: "FiShield", head: "Attendibilità", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Chi, con quali competenze e interessi", "Fonti selezionate con criteri non trasparenti", "Stesso peso a fonti istituzionali e blog"], { space: 4 }) });
    banner(s, 3.85, "Una risposta con molte fonti citate può sembrare più solida di quanto sia.", { h: 0.65, fontSize: 14 });
    txt(s, "Le fonti trovate si valutano con gli stessi criteri di qualsiasi altra fonte.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Organizzare: dossier e sintesi", "Una volta raccolte le informazioni, l'AI è molto utile per organizzarle. Raggruppare per tema: da trenta appunti e documenti sparsi a una struttura per argomenti. Individuare sovrapposizioni, contraddizioni e lacune tra il materiale raccolto, applicando quanto visto nell'8.5. Costruire uno schema o un indice per un documento da produrre. Preparare un dossier: un documento che raccoglie e organizza le informazioni su un tema, per esempio un fornitore, un mercato, una normativa, in vista di una riunione o di una decisione. Preparare sintesi tematiche: note di aggiornamento periodiche su un argomento. Il modo più affidabile di farlo, coerente con quanto detto finora, è separare le fasi: prima raccogliere le fonti e verificarne attendibilità e attualità; poi fornire al sistema il materiale raccolto e chiedergli di organizzarlo, citando le fonti per ogni punto; infine rivedere il risultato. In questo modo il dossier si basa su fonti scelte e controllate, e non sulla conoscenza incorporata del modello. Un buon dossier dichiara le sue fonti, la data a cui è aggiornato e i punti che restano incerti o da approfondire.");
    modeTag(s, 3);
    const st = [["1", "Raccogliere", "Fonti scelte, verificate per attendibilità e attualità"], ["2", "Organizzare", "Il sistema struttura il materiale fornito, citando le fonti"], ["3", "Rivedere", "Coerenza, lacune, punti incerti"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.2, 2.86, 1.8, i === 1 ? C.accent6 : C.background2, e[1]);
      txt(s, e[0], { x: x + 0.2, y: 1.28, w: 0.5, h: 0.5, fontSize: 24, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.7, y: 1.33, w: 2.0, h: 0.42, fontSize: 16, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[2], { x: x + 0.2, y: 1.9, w: 2.5, h: 0.95, fontSize: 12, color: C.text2 });
      if (i < 2) arrow(s, x + 2.88, 1.95, 0.17);
    });
    shapeBox(s, 0.5, 3.2, 9.0, 1.75, C.text1, "buon dossier");
    txt(s, "Un buon dossier dichiara", { x: 0.75, y: 3.32, w: 8.5, h: 0.38, fontSize: 15, bold: true, color: C.accent6 });
    chip(s, 0.75, 3.85, 2.7, 0.55, "Le sue fonti", { fill: C.accent1, color: C.background1, fontSize: 13 });
    chip(s, 3.65, 3.85, 2.7, 0.55, "La data di aggiornamento", { fill: C.accent1, color: C.background1, fontSize: 13 });
    chip(s, 6.55, 3.85, 2.7, 0.55, "I punti incerti", { fill: C.accent1, color: C.background1, fontSize: 13 });
    txt(s, "Così si basa su fonti scelte e controllate, non sulla conoscenza incorporata.", { x: 0.75, y: 4.5, w: 8.5, h: 0.35, fontSize: 12, italic: true, color: C.accent3 });
  }
  {
    const s = content("Confrontare fonti e prospettive", "Un uso prezioso dell'AI nella ricerca è il confronto tra fonti e prospettive. Su molti argomenti, specialmente quelli complessi o dibattuti, esistono posizioni diverse: interpretazioni diverse di una norma, valutazioni diverse di una tecnologia, previsioni diverse su un mercato. Il sistema può aiutare a mappare queste posizioni, a individuare su che cosa concordano e su che cosa divergono, e a capire su quali assunzioni si basano. È un modo efficace per evitare di fermarsi alla prima fonte trovata, che è una forma del bias di conferma visto nel Tema 7. Ma ci sono tre cautele. Primo, il sistema tende a produrre un quadro equilibrato in apparenza, che può dare lo stesso peso a una posizione largamente condivisa e a una minoritaria, o al contrario ignorare posizioni minoritarie ma rilevanti. Secondo, la presentazione delle posizioni può semplificarle o deformarle: conviene risalire alle fonti delle posizioni più rilevanti per la decisione. Terzo, come per la generazione, il modo in cui poniamo la domanda può orientare la risposta: chiedere 'quali sono i vantaggi di' produce un quadro diverso da 'quali sono le valutazioni su'.");
    modeTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiGitBranch", head: "Che cosa può fare", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Mappare posizioni diverse", "Concordanze, divergenze, assunzioni", "Non fermarsi alla prima fonte"], { space: 5 }) });
    const c = [["Equilibrio apparente", "Stesso peso a posizioni maggioritarie e minoritarie"], ["Semplificazione", "Risalire alle fonti delle posizioni rilevanti"], ["Domanda orientata", "'Vantaggi di' e 'valutazioni su' danno quadri diversi"]];
    c.forEach((e, i) => {
      const y = 1.2 + i * 0.75;
      shapeBox(s, 5.15, y, 4.35, 0.65, C.background2, e[0]);
      txt(s, e[0], { x: 5.3, y: y + 0.04, w: 4.1, h: 0.3, fontSize: 13, bold: true, color: C.accent5 });
      txt(s, e[1], { x: 5.3, y: y + 0.33, w: 4.1, h: 0.3, fontSize: 11, color: C.text2 });
    });
    banner(s, 3.65, "Il confronto tra prospettive contrasta il bias di conferma. Ma il quadro prodotto va letto con le stesse cautele di una sintesi.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Ricerca assistita e verifica", "L'ultimo punto del sottotema è una distinzione che riprende il Tema 7: la ricerca assistita non è una verifica delle fonti. Quando il sistema trova e cita fonti, ha svolto una ricerca: ha individuato pagine o documenti che ritiene pertinenti e ne ha riportato il contenuto. Ma non ha verificato che le fonti siano attendibili, aggiornate, e che sostengano davvero ciò che la risposta afferma. Queste verifiche restano a chi usa il risultato, con l'intensità proporzionata all'uso. In particolare, i problemi visti nel Tema 7 si presentano anche qui: fonti citate che non contengono l'affermazione attribuita, fonti che la contengono con condizioni diverse, fonti esistenti ma poco attendibili. La ricerca assistita sposta il lavoro, non lo elimina: riduce molto il tempo per trovare il materiale, e lascia il tempo per valutarlo. Il rischio è che la comodità di una risposta già accompagnata da fonti faccia saltare proprio quel passaggio. Il concetto chiave del sottotema lo dice chiaramente: l'AI sostiene la ricerca, senza rendere automaticamente attendibili le informazioni trovate o generate.");
    modeTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiSearch", head: "Ricerca assistita", headSize: 16, bodySize: 13,
      body: bullets(["Trova fonti ritenute pertinenti", "Ne riporta il contenuto", "Riduce il tempo per trovare il materiale"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCheckCircle", head: "Verifica delle fonti", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Attendibili e aggiornate?", "Sostengono davvero l'affermazione?", "Resta a chi usa il risultato"], { space: 5 }) });
    banner(s, 3.7, "La ricerca assistita sposta il lavoro, non lo elimina. Il rischio è che una risposta già con le fonti faccia saltare la verifica.", { h: 0.85, fontSize: 13 });
    txt(s, "Verificare una fonte: esiste, è pertinente, sostiene davvero l'affermazione.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("L'AI può sostenere ricerca e organizzazione della conoscenza, senza rendere automaticamente attendibili le informazioni trovate o generate.", "Sottotema 8.6  ·  Ricerca, approfondimento e organizzazione", "Concetto chiave del sottotema 8.6. L'AI accelera molto l'orientamento su un argomento, la ricerca di fonti, l'approfondimento, l'organizzazione del materiale e la preparazione di dossier. Ma bisogna distinguere la conoscenza incorporata nel modello dalle informazioni recuperate esternamente, controllare attualità e attendibilità, leggere con cautela i quadri di sintesi su posizioni diverse, e ricordare che la ricerca assistita non è una verifica delle fonti. Esercizio suggerito: scegliere un argomento professionale con aspetti recenti, porre la stessa domanda a uno strumento senza ricerca web e a uno con ricerca web, e confrontare le risposte per attualità, fonti indicate e affermazioni verificabili.");

  // =====================================================================
  section("8.7 Conoscenza");
  divider("8.7", "AI e gestione della conoscenza", "L'AI può agevolare l'accesso alle informazioni documentali, ma non risolve da sola i problemi di organizzazione e qualità", "Ultimo sottotema del nucleo distintivo: la gestione della conoscenza. Mentre l'8.6 riguardava la ricerca su fonti esterne, qui guardiamo al patrimonio documentale dell'organizzazione: procedure, manuali, contratti, documentazione tecnica, verbali, FAQ. Le aziende producono enormi quantità di documenti, ma spesso trovare la risposta giusta al momento giusto resta difficile. L'AI apre una possibilità nuova: interrogare una raccolta documentale in linguaggio naturale, come si farebbe con un collega esperto. In questo sottotema, da comprendere nelle sue opportunità, vediamo che cosa significa, quali condizioni servono perché funzioni, e perché un archivio non è automaticamente conoscenza interrogabile. Gli aspetti tecnici, come l'architettura RAG vista nel Tema 2, restano solo accennati; la progettazione di questi sistemi in azienda appartiene al Tema 14.");
  {
    const s = content("Dati, informazioni, documenti", "Partiamo da quattro concetti che nel linguaggio comune si confondono, ma che è utile distinguere. I dati sono elementi elementari, come un numero, una data, un codice: '45', '12/03', 'ORD-4471'. Le informazioni sono dati con un significato e un contesto: 'l'ordine 4471 è stato consegnato il 12 marzo con 45 giorni di ritardo'. I documenti sono contenitori organizzati di informazioni, prodotti per uno scopo: un contratto, una procedura, un verbale, un manuale. La conoscenza è la capacità di usare le informazioni per capire, decidere e agire: sapere che cosa fare quando un ordine arriva in ritardo, quale clausola applicare, chi contattare, quali eccezioni esistono. In azienda, gran parte della conoscenza è distribuita: in parte nei documenti, in parte nelle persone, nella loro esperienza e nelle pratiche consolidate. La gestione della conoscenza si occupa di renderla accessibile a chi ne ha bisogno. L'AI interviene in questo passaggio: può aiutare a trovare e collegare le informazioni contenute nei documenti, e a presentarle in risposta a una domanda. Ma la conoscenza non scritta, o scritta male, resta fuori dalla sua portata.");
    modeTag(s, 3);
    const lv = [["Dati", "Elementi elementari", "45  ·  12/03  ·  ORD-4471"], ["Informazioni", "Dati con significato e contesto", "Ordine 4471 consegnato il 12/03 con 45 giorni di ritardo"], ["Documenti", "Contenitori organizzati per uno scopo", "Contratto, procedura, verbale, manuale"], ["Conoscenza", "Capacità di usare le informazioni per agire", "Che cosa fare, quale clausola, chi contattare"]];
    lv.forEach((l, i) => {
      const y = 1.12 + i * 0.78, w = 5.5 + i * 0.5;
      shapeBox(s, 0.5, y, w, 0.68, i === 3 ? C.accent1 : (i % 2 ? C.accent6 : C.background2), l[0]);
      txt(s, l[0], { x: 0.65, y, w: 1.6, h: 0.68, fontSize: 14, bold: true, color: i === 3 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 2.25, y: y + 0.05, w: w - 1.9, h: 0.3, fontSize: 12, bold: true, color: i === 3 ? C.background1 : C.text1 });
      txt(s, l[2], { x: 2.25, y: y + 0.34, w: w - 1.9, h: 0.3, fontSize: 11, italic: true, color: i === 3 ? C.accent6 : C.text2 });
    });
    txt(s, "La conoscenza non scritta, o scritta male, resta fuori dalla portata dell'AI.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 13, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Archivio o conoscenza interrogabile", "Questa è l'integrazione D del tema, ed è forse il messaggio più importante per chi pensa di introdurre in azienda un assistente basato sulla documentazione: possedere un archivio di documenti non equivale a poterlo interrogare in modo affidabile. Un archivio documentale è una raccolta di file, organizzata per cartelle o in un sistema di gestione: si cerca un documento, lo si apre, lo si legge. La conoscenza interrogabile è una raccolta su cui si può porre una domanda e ottenere una risposta corretta, basata sui documenti pertinenti e collegata ad essi. Il passaggio dall'uno all'altro non avviene semplicemente collegando un sistema AI all'archivio. Contano cinque condizioni. La reperibilità: i documenti giusti devono poter essere trovati dal sistema. La struttura: documenti chiari, con titoli, sezioni e informazioni esplicite, funzionano meglio di documenti confusi. L'aggiornamento: se l'archivio contiene versioni superate, il sistema può rispondere in base a quelle. La qualità: documenti contraddittori, incompleti o scritti male producono risposte contraddittorie, incomplete o sbagliate. La possibilità di verifica: le risposte devono rimandare ai documenti originali. In sintesi: l'AI rende interrogabile un archivio nella misura in cui l'archivio è già ben tenuto.");
    modeTag(s, 3);
    shapeBox(s, 0.5, 1.15, 2.6, 1.45, C.background2, "archivio");
    await iconCircle(s, 0.7, 1.3, 0.55, "FiArchive", C.accent2);
    txt(s, "Archivio", { x: 1.35, y: 1.32, w: 1.7, h: 0.5, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
    txt(s, "Si cerca un file, lo si apre, lo si legge", { x: 0.7, y: 1.95, w: 2.3, h: 0.6, fontSize: 11, color: C.text2 });
    arrow(s, 3.2, 1.7, 0.35);
    shapeBox(s, 3.65, 1.15, 2.6, 1.45, C.accent1, "interrogabile");
    await iconCircle(s, 3.85, 1.3, 0.55, "FiMessageCircle", C.background1, HEX.a1);
    txt(s, "Conoscenza interrogabile", { x: 4.5, y: 1.25, w: 1.7, h: 0.65, fontSize: 13, bold: true, color: C.background1, valign: "middle" });
    txt(s, "Una domanda, una risposta corretta e collegata ai documenti", { x: 3.85, y: 1.95, w: 2.3, h: 0.6, fontSize: 11, color: C.background1 });
    txt(s, "Non basta collegare un sistema AI all'archivio", { x: 6.45, y: 1.15, w: 3.05, h: 1.45, fontSize: 14, bold: true, italic: true, color: C.accent5, valign: "middle" });
    const cd = ["Reperibilità", "Struttura", "Aggiornamento", "Qualità", "Verificabilità"];
    cd.forEach((t, i) => chip(s, 0.5 + i * 1.82, 2.85, 1.7, 0.55, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 3.65, "L'AI rende interrogabile un archivio nella misura in cui l'archivio è già ben tenuto.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Come funziona per chi la usa", "Senza entrare nell'architettura tecnica, che il documento di perimetro chiede solo di accennare, è utile capire dal punto di vista dell'utilizzatore che cosa succede quando si interroga una raccolta documentale. Il funzionamento tipico, che nel Tema 2 abbiamo chiamato RAG, avviene in due passaggi. Primo, il recupero: a partire dalla domanda, il sistema cerca nella raccolta i passaggi più pertinenti. Secondo, la generazione: il modello produce una risposta basandosi su quei passaggi, e idealmente li cita. Questa semplice descrizione spiega molti comportamenti che l'utente osserva. Se il recupero non trova il passaggio giusto, perché la domanda usa parole diverse dal documento o perché il documento è mal strutturato, la risposta sarà incompleta o sbagliata, anche se l'informazione è nella raccolta. Se il recupero trova passaggi di documenti superati, la risposta sarà superata. Se il recupero non trova nulla di pertinente, un buon sistema dovrebbe dirlo, ma alcuni rispondono comunque con la conoscenza generale del modello. E se la generazione riporta male i passaggi trovati, la risposta sarà sbagliata nonostante il recupero corretto. Per l'utente, la conseguenza pratica è una: controllare i passaggi citati, non solo la risposta.");
    modeTag(s, 3);
    chip(s, 0.5, 1.3, 1.7, 0.8, "Domanda", { fill: C.background2, fontSize: 14 });
    arrow(s, 2.3, 1.54, 0.35);
    shapeBox(s, 2.75, 1.15, 2.6, 1.1, C.accent6, "recupero");
    txt(s, "1. Recupero", { x: 2.9, y: 1.22, w: 2.3, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Cerca i passaggi più pertinenti nella raccolta", { x: 2.9, y: 1.58, w: 2.3, h: 0.6, fontSize: 11, color: C.text1 });
    arrow(s, 5.45, 1.54, 0.35);
    shapeBox(s, 5.9, 1.15, 2.6, 1.1, C.accent1, "generazione");
    txt(s, "2. Generazione", { x: 6.05, y: 1.22, w: 2.3, h: 0.35, fontSize: 14, bold: true, color: C.background1 });
    txt(s, "Risponde sulla base dei passaggi, e li cita", { x: 6.05, y: 1.58, w: 2.3, h: 0.6, fontSize: 11, color: C.background1 });
    table(s, [["Che cosa va storto", "Che cosa vede l'utente"],
      ["Recupero manca il passaggio giusto", "Risposta incompleta, anche se l'informazione c'è"],
      ["Recupero trova documenti superati", "Risposta superata"],
      ["Nessun passaggio pertinente", "Risposta dalla conoscenza generale, o 'non so'"],
      ["Generazione riporta male", "Risposta errata con fonti corrette"]],
      { y: 2.45, colW: [4.2, 4.8], rowH: 0.42, fontSize: 12, blankCorner: false });
    txt(s, "Conseguenza pratica: controllare i passaggi citati, non solo la risposta.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Assistenti sulla documentazione", "Gli assistenti basati sulla documentazione sono strumenti che permettono di interrogare in linguaggio naturale una raccolta definita di documenti. Le opportunità sono concrete. Un assistente sulle procedure interne risponde a domande come 'come si richiede un rimborso spese per una trasferta all'estero?'. Un assistente sulla documentazione tecnica aiuta il servizio di assistenza a trovare la soluzione a un problema descritto dal cliente. Un assistente sulle condizioni contrattuali aiuta il commerciale a rispondere a domande su garanzie e tempi. Un assistente per l'inserimento dei nuovi colleghi raccoglie regole, contatti e prassi. Il valore è di ridurre il tempo per trovare le informazioni, rendere accessibile la conoscenza anche a chi non sa dove cercare, e alleggerire le persone esperte dalle domande ripetitive. Molti strumenti di uso comune permettono già oggi di creare piccoli assistenti su un insieme di documenti, mentre le soluzioni aziendali su larga scala richiedono progettazione, integrazione e gestione dei permessi, temi che appartengono al Tema 14. La progettazione di assistenti e agenti che svolgono azioni appartiene invece al Tema 11. Qui ci interessa che cosa possono offrire, e a quali condizioni.");
    modeTag(s, 3);
    await iconGrid(s, [
      { icon: "FiClipboard", head: "Procedure interne", body: "Come si richiede un rimborso per una trasferta all'estero?" },
      { icon: "FiTool", head: "Documentazione tecnica", body: "Soluzioni ai problemi descritti dai clienti" },
      { icon: "FiFileText", head: "Condizioni contrattuali", body: "Garanzie, tempi, condizioni per i commerciali" },
      { icon: "FiUserPlus", head: "Inserimento di nuovi colleghi", body: "Regole, contatti, prassi in un unico punto" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Meno tempo per trovare le informazioni, conoscenza accessibile a chi non sa dove cercare, esperti alleggeriti dalle domande ripetitive.", { h: 0.6, fontSize: 12 });
    txt(s, "Qui gli assistenti che rispondono; soluzioni su larga scala e agenti che svolgono azioni sono argomenti a sé.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Risposte collegate ai documenti", "Il sottotema riprende l'integrazione sulla tracciabilità: l'accesso alla conoscenza è più controllabile quando la risposta rimanda ai documenti e ai passaggi rilevanti. L'esempio fittizio in slide mostra una risposta di un assistente sulle procedure interne. La risposta indica il documento, la versione, la sezione, e riporta il passaggio. Questo permette all'utente tre cose. Verificare rapidamente che la risposta corrisponda a ciò che dice il documento. Controllare che il documento sia quello giusto e aggiornato: in questo caso la versione e la data. Approfondire, leggendo il contesto del passaggio, che spesso contiene condizioni ed eccezioni che la risposta ha omesso. Una risposta senza riferimenti, invece, non permette di distinguere un'informazione tratta dalla documentazione aziendale da un'informazione generica prodotta dal modello. Per chi valuta o sceglie uno strumento di questo tipo, la presenza di riferimenti precisi e cliccabili è un requisito importante. Per chi lo usa, la buona pratica è aprire il riferimento ogni volta che la risposta servirà per una decisione o un'azione con conseguenze.");
    modeTag(s, 3);
    shapeBox(s, 0.5, 1.15, 5.6, 3.0, C.background2, "risposta assistente");
    txt(s, "Domanda: entro quando va presentata la nota spese?", { x: 0.7, y: 1.25, w: 5.2, h: 0.35, fontSize: 12, bold: true, color: C.text1 });
    txt(s, "La nota spese va presentata entro 30 giorni dalla fine della trasferta, allegando i giustificativi in originale.", { x: 0.7, y: 1.65, w: 5.2, h: 0.7, fontSize: 12, color: C.text1 });
    docBox(s, 0.7, 2.45, 5.2, 1.55, "Fonte: Procedura rimborsi spese, v. 3.2 (gennaio), §4.1", "\"Le note spese devono essere presentate entro 30 giorni dalla conclusione della trasferta. Per le trasferte superiori a 15 giorni è ammessa la presentazione di note intermedie.\"", { fill: C.background1, fontSize: 11 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 4.2, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    await card(s, 6.35, 1.15, 3.15, 3.0, { icon: "FiLink", head: "Il riferimento permette di", headSize: 14, bodySize: 12, fill: C.accent6,
      body: bullets(["Verificare la risposta", "Controllare documento e versione", "Leggere il contesto: qui c'è un'eccezione omessa"], { space: 5 }) });
    txt(s, "Senza riferimenti non si distingue la documentazione aziendale dalla conoscenza generica del modello.", { x: 0.5, y: 4.5, w: 9, h: 0.45, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Aggiornamento e versionamento", "Un aspetto spesso sottovalutato della conoscenza interrogabile è il tempo. Le procedure cambiano, i listini si aggiornano, i contratti vengono rinnovati, le persone cambiano ruolo. Un archivio che contiene più versioni dello stesso documento, senza indicare quale è valida, è un problema già per una persona; per un sistema AI lo è di più, perché il recupero può trovare il passaggio della versione vecchia, magari perché è scritto in modo più simile alla domanda, e la risposta viene presentata con la stessa sicurezza. Il risultato è un'informazione superata, con l'aspetto di un'informazione aggiornata e documentata. Alcune condizioni rendono la raccolta più affidabile nel tempo. Chiarezza sulla versione valida: documenti superati rimossi o chiaramente marcati come tali. Date e numeri di versione visibili nei documenti. Responsabilità definite per l'aggiornamento di ciascun documento. Riesami periodici della raccolta. Per l'utente, il comportamento pratico è controllare la versione e la data del documento citato, specialmente per regole, prezzi e scadenze. Le modalità con cui l'azienda gestisce questi processi appartengono al Tema 14.");
    modeTag(s, 3);
    docBox(s, 0.5, 1.15, 2.8, 1.3, "Procedura rimborsi v. 2.0", "Presentazione entro 60 giorni", { fill: C.background2, bar: C.accent2, labelColor: C.accent2 });
    docBox(s, 0.5, 2.6, 2.8, 1.3, "Procedura rimborsi v. 3.2", "Presentazione entro 30 giorni", { fill: C.accent6 });
    chip(s, 3.45, 1.55, 1.5, 0.5, "Superata", { fill: C.accent5, color: C.background1, fontSize: 12 });
    chip(s, 3.45, 3.0, 1.5, 0.5, "Valida", { fill: C.accent1, color: C.background1, fontSize: 12 });
    await card(s, 5.2, 1.15, 4.3, 2.75, { icon: "FiAlertTriangle", inline: true, head: "Se convivono senza indicazioni", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: "Il recupero può trovare la versione vecchia, e la risposta arriva con la stessa sicurezza: un'informazione superata con l'aspetto di un'informazione aggiornata e documentata." });
    const cd = ["Versione valida chiara", "Date e versioni visibili", "Responsabili dell'aggiornamento", "Riesami periodici"];
    cd.forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.1, 2.15, 0.55, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Per l'utente: controllare versione e data del documento citato.", { x: 0.5, y: 4.72, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Condizioni per risposte utili", "Riassumiamo le condizioni necessarie per ottenere risposte utili da una raccolta documentale, che il sottotema chiede di comprendere. Sul lato dei documenti: contenuti corretti, aggiornati e non contraddittori; una struttura chiara, con titoli e sezioni che rendano facile trovare le informazioni; informazioni esplicite, perché ciò che è dato per scontato o è solo nella testa delle persone non può essere recuperato; formati leggibili, tema dell'8.8. Sul lato della raccolta: un perimetro chiaro, cioè sapere quali documenti contiene e quali no; versioni gestite; permessi coerenti, perché ciascuno dovrebbe poter interrogare solo ciò che è autorizzato a vedere. Sul lato dell'uso: domande chiare e specifiche, che usino quando possibile il lessico dei documenti; consapevolezza del perimetro, perché se la risposta non è nella raccolta il sistema potrebbe comunque rispondere; controllo dei riferimenti per le risposte con conseguenze. Il concetto chiave lo riassume: l'AI agevola l'accesso, ma non risolve da sola i problemi di organizzazione e qualità della conoscenza. Anzi, spesso li rende più visibili.");
    modeTag(s, 3);
    const col = [["FiFileText", "Documenti", ["Corretti, aggiornati, coerenti", "Struttura chiara", "Informazioni esplicite", "Formati leggibili"]], ["FiDatabase", "Raccolta", ["Perimetro chiaro", "Versioni gestite", "Permessi coerenti"]], ["FiUser", "Uso", ["Domande chiare, lessico dei documenti", "Consapevolezza del perimetro", "Controllo dei riferimenti"]]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      await card(s, x, 1.15, 2.86, 2.95, { icon: col[i][0], inline: true, head: col[i][1], headSize: 16, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: bullets(col[i][2], { space: 5 }) });
    }
    banner(s, 4.3, "L'AI agevola l'accesso, ma non risolve da sola i problemi di organizzazione e qualità. Spesso li rende più visibili.", { h: 0.65, fontSize: 13 });
  }
  keySlide("L'AI può agevolare l'accesso alle informazioni documentali, ma non risolve da sola i problemi di organizzazione e qualità della conoscenza.", "Sottotema 8.7  ·  AI e gestione della conoscenza", "Concetto chiave del sottotema 8.7. L'AI permette di interrogare raccolte documentali in linguaggio naturale, con assistenti sulle procedure, sulla documentazione tecnica, sulle condizioni contrattuali. È una possibilità di grande valore. Ma un archivio non è automaticamente conoscenza interrogabile: servono reperibilità, struttura, aggiornamento, qualità e possibilità di verifica. Il funzionamento in due passaggi, recupero e generazione, spiega perché le risposte possono essere incomplete, superate o sbagliate anche quando l'informazione è nella raccolta. Le risposte collegate ai documenti, con versione e passaggio, rendono l'accesso controllabile. Esercizio suggerito: se in azienda è disponibile uno strumento autorizzato per creare un piccolo assistente su documenti, caricare alcune procedure fittizie, di cui una in due versioni contraddittorie, e osservare come risponde alle domande, verificando i riferimenti.");

  // =====================================================================
  section("8.8 Limiti");
  divider("8.8", "Limiti e condizioni di efficacia", "Caricare un documento non garantisce che il sistema ne abbia elaborato tutte le parti e preservato il significato", "Ultimo sottotema, di consapevolezza critica, che attraversa tutte le modalità. Nei sottotemi precedenti abbiamo incontrato più volte limiti specifici: perdite di significato, riferimenti imprecisi, campi inventati, versioni superate. Qui li mettiamo insieme e li guardiamo dal punto di vista delle condizioni di efficacia: da che cosa dipende il fatto che un'elaborazione documentale funzioni bene o male. Non ripetiamo la teoria generale delle allucinazioni e dell'affidabilità del Tema 3: ne consideriamo gli effetti specifici sui documenti. E concludiamo con il principio dei controlli proporzionati all'uso, applicato al lavoro documentale.");
  {
    const s = content("Caricare non significa elaborare", "Il concetto chiave del sottotema contiene un'osservazione che vale la pena mettere all'inizio: poter caricare un documento non garantisce che il sistema ne abbia elaborato tutte le parti, interpretato correttamente il contenuto e preservato il significato. Quando carichiamo un file e otteniamo una risposta sicura e ben organizzata, tendiamo a pensare che il sistema abbia letto il documento come lo leggeremmo noi, tutto e con attenzione. Non è necessariamente così, per diversi motivi che vedremo. Il file può essere stato convertito in testo in modo incompleto: le tabelle possono essere state appiattite, le immagini ignorate, le scansioni lette male. Il documento può essere troppo lungo per essere elaborato interamente, oppure alcune parti possono ricevere meno attenzione di altre. Alcuni strumenti, con documenti molto grandi, ne usano solo i passaggi ritenuti pertinenti alla domanda. E anche quando il testo è tutto disponibile, l'interpretazione può essere sbagliata. Il problema è che nulla di tutto questo è visibile nella risposta. La risposta ha sempre lo stesso aspetto, sicuro e completo, sia quando il sistema ha elaborato tutto, sia quando ne ha elaborato una parte.");
    modeTag(s, -1);
    const st = [["FiUpload", "Caricato", "Il file è stato accettato"], ["FiFileText", "Convertito", "Tabelle, immagini, scansioni: tutto letto?"], ["FiLayers", "Elaborato", "Tutte le parti, con la stessa attenzione?"], ["FiCheckCircle", "Compreso", "Interpretato correttamente?"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.1, 2.1, i === 0 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.32, 0.65, st[i][0], i === 0 ? C.accent1 : C.accent2);
      txt(s, st[i][1], { x: x + 0.1, y: 2.05, w: 1.9, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, st[i][2], { x: x + 0.12, y: 2.45, w: 1.86, h: 0.8, fontSize: 11, color: C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Ogni passaggio può fallire in modo invisibile", { x: 0.5, y: 3.45, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent5, align: "center" });
    banner(s, 3.95, "La risposta ha sempre lo stesso aspetto, sicuro e completo, sia che il sistema abbia elaborato tutto, sia che ne abbia elaborato una parte.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Qualità e struttura dei documenti", "La prima condizione di efficacia riguarda i documenti di partenza. Un principio noto nell'informatica dice: se entra spazzatura, esce spazzatura. Vale anche qui, con una differenza importante: con l'AI, da documenti di scarsa qualità esce un risultato che non sembra spazzatura, perché è ben scritto e ben organizzato. Che cosa rende un documento adatto all'elaborazione? Un contenuto corretto, completo e coerente: se il documento contiene errori o contraddizioni, il sistema li riporterà, o sceglierà una delle versioni contraddittorie senza segnalarlo. Una struttura chiara: titoli, sezioni, numerazione, paragrafi con un tema ciascuno. Il linguaggio esplicito: abbreviazioni non spiegate, riferimenti impliciti come 'come concordato' o 'la solita procedura' non sono interpretabili. Un formato digitale nativo, cioè un file prodotto da un programma di scrittura, piuttosto che una scansione. Documenti con queste caratteristiche producono risultati migliori, sono più facili da controllare, e sono gli stessi che funzionano meglio anche per i lettori umani. Migliorare la qualità dei documenti è quindi un investimento che vale doppio.");
    modeTag(s, -1);
    await iconGrid(s, [
      { icon: "FiCheckSquare", head: "Contenuto corretto e coerente", body: "Errori e contraddizioni vengono riportati, o risolti in silenzio" },
      { icon: "FiList", head: "Struttura chiara", body: "Titoli, sezioni, numerazione, un tema per paragrafo" },
      { icon: "FiMessageSquare", head: "Linguaggio esplicito", body: "'Come concordato', 'la solita procedura': non interpretabili" },
      { icon: "FiFile", head: "Formato digitale nativo", body: "Meglio un file nativo che una scansione" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Se entra spazzatura, esce spazzatura. Con l'AI, però, il risultato non sembra spazzatura: è ben scritto e ben organizzato.", { h: 0.65, fontSize: 13 });
    txt(s, "I documenti che funzionano meglio per l'AI sono gli stessi che funzionano meglio per le persone.", { x: 0.5, y: 4.67, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Digitali, scansionati, impaginati", "Il formato del documento incide molto sulla qualità dell'elaborazione. Un documento digitale nativo, come un file Word o un PDF prodotto da un programma, contiene il testo in forma leggibile dal computer. Un documento scansionato è invece un'immagine: per elaborarlo, il testo deve essere riconosciuto, con tecniche di riconoscimento ottico o con le capacità visive dei modelli multimodali. Il riconoscimento può sbagliare, specialmente con scansioni di bassa qualità, scritture a mano, timbri, firme, caratteri piccoli, documenti storti o macchiati. E un errore di riconoscimento su una cifra cambia un importo. Anche nei documenti digitali, alcune parti sono più difficili del testo continuo. Le tabelle: possono essere lette riga per riga in modo corretto, oppure appiattite, con le celle mescolate e i valori associati alle intestazioni sbagliate. Le immagini e i grafici: a seconda dello strumento possono essere ignorati, descritti in modo generico o interpretati in modo impreciso. Le impaginazioni complesse: testo su più colonne, note a piè di pagina, riquadri, intestazioni ripetute, possono essere lette nell'ordine sbagliato. La multimodalità in sé appartiene al Tema 10: qui ci interessa il suo impatto sulla lettura dei documenti.");
    modeTag(s, -1);
    table(s, [["Elemento", "Che cosa può succedere", "Che cosa controllare"],
      ["Scansioni", "Riconoscimento errato di cifre e parole", "Importi, date, nomi nei punti critici"],
      ["Scritture a mano, timbri", "Letti male o ignorati", "Se contengono informazioni rilevanti"],
      ["Tabelle", "Celle mescolate, valori sotto l'intestazione sbagliata", "Alcuni valori riga per riga"],
      ["Immagini e grafici", "Ignorati o interpretati in modo impreciso", "Se l'informazione è solo lì"],
      ["Colonne, note, riquadri", "Ordine di lettura sbagliato", "Il senso dei passaggi collegati"]],
      { y: 1.15, colW: [2.2, 3.6, 3.2], rowH: 0.5, fontSize: 12, blankCorner: false });
    banner(s, 4.35, "Un errore di riconoscimento su una cifra cambia un importo.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Documenti lunghi e copertura", "Un limite specifico riguarda i contenuti molto lunghi. Anche se i sistemi attuali accettano documenti di centinaia di pagine, la lunghezza crea tre problemi. Il primo è il limite di contesto, visto nel Tema 2: oltre una certa dimensione, il documento non può essere considerato tutto insieme, e lo strumento ne usa solo una parte, o lo elabora a pezzi, spesso senza avvisare. Il secondo è l'attenzione non uniforme: studi sui modelli linguistici, come quello di Liu e colleghi sul fenomeno chiamato 'lost in the middle', hanno mostrato che le informazioni nella parte centrale di testi lunghi tendono a essere usate meno di quelle all'inizio e alla fine. I modelli più recenti hanno migliorato questo aspetto, ma non lo hanno eliminato. Il terzo è la copertura: in una sintesi o in un'analisi di un documento lungo, alcune sezioni possono essere trattate in dettaglio e altre ignorate, senza che la risposta lo dica. Per valutare la copertura, alcune tecniche pratiche: chiedere una sintesi per sezioni, che rende visibile se una sezione manca; porre domande mirate su parti specifiche, specialmente centrali; per i documenti lunghi e importanti, elaborarli per parti, con richieste distinte, e poi ricomporre.");
    modeTag(s, -1);
    await iconGrid(s, [
      { icon: "FiMaximize", head: "Limite di contesto", body: "Oltre una certa dimensione, solo una parte o a pezzi, spesso senza avviso" },
      { icon: "FiTarget", head: "Attenzione non uniforme", body: "Le parti centrali tendono a essere usate meno (Liu et al.)" },
      { icon: "FiPieChart", head: "Copertura", body: "Alcune sezioni in dettaglio, altre ignorate, senza dirlo" },
    ], 3, { y: 1.15, h: 1.75, headSize: 13, bodySize: 12 });
    txt(s, "Come valutare la copertura", { x: 0.5, y: 3.1, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    chip(s, 0.5, 3.5, 2.9, 0.65, "Sintesi per sezioni: si vede se una manca", { fill: C.accent6, fontSize: 11 });
    chip(s, 3.55, 3.5, 2.9, 0.65, "Domande mirate sulle parti centrali", { fill: C.accent6, fontSize: 11 });
    chip(s, 6.6, 3.5, 2.9, 0.65, "Elaborare per parti, poi ricomporre", { fill: C.accent6, fontSize: 11 });
    txt(s, "I modelli più recenti hanno migliorato questi aspetti, ma non li hanno eliminati.", { x: 0.5, y: 4.4, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Linguaggio tecnico e riferimenti", "Altri due limiti, frequenti nella documentazione aziendale. Il linguaggio tecnico e specialistico: documenti giuridici, tecnici, medici, finanziari usano termini con significati precisi, spesso diversi dal significato comune. 'Risoluzione' in un contratto, 'tolleranza' in una specifica tecnica, 'competenza' in contabilità. Il sistema conosce molti linguaggi specialistici, ma può interpretare un termine nel senso comune, confondere termini vicini, o non conoscere il gergo specifico di un settore o di un'azienda, con le sue sigle e i suoi codici. Il risultato può essere una sintesi scorrevole e sbagliata, difficile da riconoscere per chi non è esperto. Per questo, sui documenti specialistici, la revisione di chi conosce la materia resta indispensabile, come visto nel Tema 7. I riferimenti puntuali: come visto nell'8.3, i sistemi possono indicare articoli, pagine o sezioni in modo impreciso. La precisione dipende dallo strumento e dal formato: alcuni strumenti mostrano il passaggio esatto, altri ricostruiscono il riferimento in modo approssimativo. I numeri di pagina sono particolarmente fragili, perché la numerazione del documento può non coincidere con quella del file. Per i riferimenti importanti, aprire il documento nel punto indicato resta l'unico controllo affidabile.");
    modeTag(s, -1);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiCpu", head: "Linguaggio specialistico", headSize: 16, bodySize: 12,
      body: bullets(["Termini con significato tecnico preciso", "'Risoluzione', 'tolleranza', 'competenza'", "Sigle, codici e gergo aziendale", "Sintesi scorrevole e sbagliata"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiBookmark", head: "Riferimenti puntuali", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Articoli, pagine, sezioni imprecisi", "Dipende da strumento e formato", "Pagine del documento e del file diverse"], { space: 4 }) });
    banner(s, 3.8, "Sui documenti specialistici, la revisione esperta resta indispensabile. Per i riferimenti importanti, aprire il documento nel punto indicato.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Omissioni e alterazioni", "Torniamo, in chiusura, ai rischi che attraversano tutto il tema: omissioni e alterazioni. L'integrazione C, già vista nell'8.3, viene ripresa qui in forma generale: la riduzione o trasformazione di un documento può nascondere elementi decisivi anche quando il risultato appare scorrevole e ben organizzato. Le omissioni sono elementi presenti nel documento e assenti nel risultato: una condizione, un'eccezione, un rischio, una sezione intera. Le alterazioni sono elementi presenti in entrambi, ma con un significato diverso: un obbligo attenuato, un'incertezza trasformata in certezza, un importo cambiato, un'attribuzione spostata. Si aggiungono le aggiunte: elementi presenti nel risultato e assenti nel documento, dedotti o inventati dal sistema. In tutte le modalità del tema ritroviamo questi tre rischi in forme diverse: nella trasformazione dei testi, nella sintesi, nell'estrazione, nel confronto, nella consultazione documentale. Il denominatore comune è che sono difficili da vedere guardando solo il risultato. Si vedono confrontandolo con l'originale, sapendo che cosa cercare. Per questo la tracciabilità, che abbiamo incontrato in quasi tutti i sottotemi, non è un dettaglio tecnico: è la condizione che rende possibile il controllo.");
    modeTag(s, -1);
    const r = [["FiMinusCircle", "Omissioni", "Nel documento, non nel risultato", "Condizioni, eccezioni, rischi, sezioni"], ["FiShuffle", "Alterazioni", "In entrambi, con significato diverso", "Obblighi attenuati, incertezze diventate certezze"], ["FiPlusCircle", "Aggiunte", "Nel risultato, non nel documento", "Elementi dedotti o inventati"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.4, C.background2, r[i][1]);
      await iconCircle(s, x + 0.2, 1.3, 0.6, r[i][0], C.accent5);
      txt(s, r[i][1], { x: x + 0.95, y: 1.35, w: 1.8, h: 0.5, fontSize: 17, bold: true, color: C.text1, valign: "middle" });
      txt(s, r[i][2], { x: x + 0.2, y: 2.05, w: 2.46, h: 0.55, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, r[i][3], { x: x + 0.2, y: 2.62, w: 2.46, h: 0.85, fontSize: 12, color: C.text2 });
    }
    banner(s, 3.75, "Difficili da vedere guardando solo il risultato. La tracciabilità non è un dettaglio tecnico: è la condizione che rende possibile il controllo.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Controlli proporzionati all'uso", "L'ultimo punto del sottotema è la necessità di controlli proporzionati all'utilizzo previsto, il principio che abbiamo sviluppato nel Tema 7 e che qui applichiamo al lavoro documentale. Non ogni elaborazione richiede lo stesso controllo. La matrice in slide propone tre livelli. Per orientarsi, cioè per capire di che cosa parla un documento, decidere se leggerlo, prepararsi a una riunione, basta una lettura critica del risultato: è plausibile, manca qualcosa di ovvio? Per lavorare, cioè quando il risultato serve per un'attività interna, come una bozza, un'analisi preliminare, una tabella di lavoro, conviene controllare a campione e sui punti critici, usando i riferimenti. Per decidere o comunicare all'esterno, cioè quando il risultato sostituisce la lettura dell'originale per una decisione con conseguenze, o arriva a clienti, fornitori, enti, serve un controllo sistematico sugli elementi critici, con il confronto con l'originale e, se necessario, la revisione di un esperto. Due fattori alzano il livello: documenti di qualità incerta, come scansioni o documenti lunghi e complessi, e contenuti specialistici o con valore legale.");
    modeTag(s, -1);
    const lv = [["Per orientarsi", "Capire di che cosa parla, decidere se leggerlo", "Lettura critica del risultato", C.background2, C.text1], ["Per lavorare", "Bozze, analisi preliminari, tabelle di lavoro", "Controllo a campione e sui punti critici, con i riferimenti", C.accent6, C.text1], ["Per decidere o comunicare", "Sostituisce l'originale, arriva all'esterno", "Controllo sistematico, confronto con l'originale, esperto se serve", C.accent1, C.background1]];
    lv.forEach((l, i) => {
      const y = 1.15 + i * 0.9;
      shapeBox(s, 0.5, y, 9.0, 0.8, l[3], l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.3, h: 0.8, fontSize: 14, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 3.0, y, w: 2.9, h: 0.8, fontSize: 12, color: l[4], valign: "middle" });
      txt(s, l[2], { x: 6.0, y, w: 3.35, h: 0.8, fontSize: 12, bold: true, color: l[4], valign: "middle" });
    });
    txt(s, "Alzano il livello", { x: 0.5, y: 3.95, w: 2.3, h: 0.55, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.8, 3.95, 3.25, 0.55, "Scansioni, documenti lunghi o complessi", { fill: C.background2, fontSize: 11 });
    chip(s, 6.2, 3.95, 3.3, 0.55, "Contenuti specialistici o con valore legale", { fill: C.background2, fontSize: 11 });
    txt(s, "Più il risultato sostituisce la lettura dell'originale, più deve essere controllato.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("Poter caricare un documento non garantisce che il sistema ne abbia elaborato tutte le parti, interpretato correttamente il contenuto e preservato il significato.", "Sottotema 8.8  ·  Limiti e condizioni di efficacia", "Concetto chiave dell'ultimo sottotema. L'efficacia dell'elaborazione documentale dipende dalla qualità e dalla struttura dei documenti, dal formato, dalla presenza di tabelle, immagini e impaginazioni complesse, dalla lunghezza, dal linguaggio specialistico. Omissioni, alterazioni e aggiunte attraversano tutte le modalità e sono difficili da vedere guardando solo il risultato. Per questo servono tracciabilità e controlli proporzionati all'uso. Esercizio suggerito: caricare in uno strumento autorizzato un documento fittizio con una tabella, una nota a piè di pagina e una sezione centrale contenente un'informazione chiave, e verificare con domande mirate che cosa il sistema ha effettivamente elaborato.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle undici domande guida. Attività oltre la scrittura: trasformare, sintetizzare, estrarre, confrontare, ricercare, consultare raccolte documentali. Generare o trasformare: trasformare quando esiste materiale corretto, perché riduce le invenzioni e offre un originale per il controllo. Sintetizzare senza perdere condizioni: dichiarare lo scopo, chiedere riferimenti e un elenco separato di condizioni ed eccezioni. Sintesi o estrazione: la prima produce un testo da leggere, la seconda dati da usare, con controllo campo per campo. Confrontare documenti: riferimenti a entrambi i passaggi, differenze classificate per natura. Ricerca o raccolta: fonti esterne da verificare, oppure documenti dell'organizzazione con risposte collegate. Raccolta interrogabile: reperibilità, struttura, aggiornamento, qualità, verificabilità. Dal non strutturato ai dati: campi definiti, regole per i mancanti, validazione prima dell'uso. Formati e lunghezza: conversione, attenzione non uniforme, copertura. Sintesi fedele: confronto con l'originale sugli elementi decisivi. Quando risalire alle fonti: in proporzione all'uso, sempre quando il risultato sostituisce l'originale. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Oltre la scrittura?", "Trasformare, sintetizzare, estrarre, confrontare, consultare"], ["Generare o trasformare?", "Trasformare il materiale corretto, quando c'è"], ["Sintesi senza perdite?", "Scopo, riferimenti, elenco di condizioni ed eccezioni"], ["Sintesi o estrazione?", "Testo da leggere o dati da usare"], ["Confrontare con i passaggi?", "Riferimenti a entrambi, differenze classificate"], ["Ricerca o raccolta?", "Fonti esterne o documenti dell'organizzazione"], ["Raccolta interrogabile?", "Reperibile, strutturata, aggiornata, verificabile"], ["Dal testo ai dati?", "Campi definiti, regole, validazione"], ["Formati e lunghezza?", "Conversione, attenzione, copertura"], ["Sintesi fedele?", "Confronto con l'originale sugli elementi decisivi"], ["Quando risalire alle fonti?", "In proporzione all'uso, sempre se sostituisce l'originale"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.6, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.6, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.03, w: 3.8, h: 0.28, fontSize: 11, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.3, w: 3.8, h: 0.28, fontSize: 10, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: riconoscere le possibilità dell'AI per testi e documenti; distinguere generazione, trasformazione, analisi ed estrazione; comprendere opportunità e limiti nella redazione e revisione; identificare utilizzi nella sintesi e nell'analisi documentale; comprendere come ottenere dati strutturati da informazioni non strutturate; riconoscere modalità di confronto tra documenti e versioni; distinguere ricerca informativa e interrogazione di una raccolta documentale; comprendere il potenziale della conoscenza documentale interrogabile; riconoscere l'importanza della tracciabilità verso le fonti originali; individuare rischi di omissione, perdita di significato e interpretazione errata; comprendere come qualità dei file, formati e complessità incidano sull'elaborazione; riconoscere quando serve una verifica più approfondita.");
    const r = ["Riconoscere le possibilità su testi e documenti", "Distinguere generare, trasformare, analizzare, estrarre", "Opportunità e limiti in redazione e revisione", "Utilizzi nella sintesi e nell'analisi documentale", "Dati strutturati da informazioni non strutturate", "Confronto tra documenti e versioni", "Ricerca informativa o raccolta documentale", "Il potenziale della conoscenza interrogabile", "L'importanza della tracciabilità", "Omissioni, perdita di significato, errori", "Effetto di file, formati e complessità", "Quando serve una verifica più approfondita"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Quattro modalità: una scheda pratica", "Traduciamo il modulo in una scheda pratica, organizzata per modalità. Produrre: fornire il materiale di partenza, indicare destinatario e tono, scegliere il livello di supervisione in base alle conseguenze e alla visibilità del testo. Trasformare: partire da materiale corretto, dichiarare le modifiche ammesse, confrontare con l'originale gli elementi che non devono cambiare. Analizzare e strutturare: dichiarare lo scopo della sintesi, chiedere riferimenti ai passaggi, definire campi e regole per i mancanti nelle estrazioni, classificare le differenze nei confronti, validare prima dell'uso. Recuperare conoscenza: chiedersi da dove viene l'informazione, controllare attualità e attendibilità, aprire i riferimenti, controllare versione e data dei documenti. E per tutte le modalità: caricare i documenti solo negli strumenti autorizzati; tenere presenti i limiti di formato, lunghezza e linguaggio; proporzionare i controlli all'uso. Non confondere un'elaborazione convincente con un'elaborazione completa e verificata: è il messaggio centrale del tema.");
    const f = [["Produrre", ["Materiale di partenza", "Destinatario e tono", "Supervisione proporzionata"], C.background2], ["Trasformare", ["Partire da materiale corretto", "Modifiche ammesse dichiarate", "Confronto con l'originale"], C.accent6], ["Analizzare", ["Scopo e riferimenti", "Campi e regole per i mancanti", "Differenze classificate, validazione"], C.background2], ["Recuperare", ["Da dove viene?", "Attualità e attendibilità", "Riferimenti, versione e data"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: strumenti autorizzati, limiti di formato e lunghezza, controlli proporzionati all'uso.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei errori tipici nel lavoro su testi e documenti, uno per ciascuno dei principali messaggi del modulo. Primo: generare da zero quando esiste già un testo con i contenuti corretti. Trasformare il materiale esistente riduce le invenzioni e rende il controllo più semplice. Secondo: pensare che una sintesi sia fedele perché ogni frase è vera. Le perdite di significato stanno in ciò che manca: condizioni, eccezioni, incertezze. Terzo: usare un dato estratto come se fosse già validato. Gli errori di estrazione si propagano nei fogli di calcolo, nei report, nelle decisioni. Quarto: credere che l'AI abbia trovato tutte le differenze tra due versioni. L'elenco può essere incompleto, e per i documenti importanti serve anche il confronto tradizionale. Quinto: pensare che basti collegare l'AI all'archivio. Senza documenti aggiornati, strutturati e con le versioni gestite, le risposte ereditano il disordine. Sesto: dare per scontato che un documento caricato sia stato letto tutto. Conversione, attenzione e copertura possono fallire senza segnali. Suggerimento: chiedere ai partecipanti quale di questi errori vedono più spesso nel proprio lavoro.");
    const a = [["FiEdit3", "\"Lo genero da zero\"", "Se c'è il testo giusto, trasformarlo", "8.2"], ["FiFileText", "\"Ogni frase è vera, quindi è fedele\"", "Le perdite stanno in ciò che manca", "8.3"], ["FiDatabase", "\"Il dato estratto è pronto all'uso\"", "Estratto non vuol dire validato", "8.4"], ["FiColumns", "\"Ha trovato tutte le differenze\"", "L'elenco può essere incompleto", "8.5"], ["FiArchive", "\"Basta collegare l'AI all'archivio\"", "Le risposte ereditano il disordine", "8.7"], ["FiUpload", "\"L'ho caricato, quindi l'ha letto\"", "Caricare non è elaborare", "8.8"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 8 si apre l'area 'Esplorare le possibilità dell'AI', che guarda a che cosa si può fare concretamente con l'AI nei diversi ambiti di lavoro. Abbiamo iniziato dai testi, dai documenti e dalla conoscenza, perché è l'ambito più maturo e più trasversale. Il tema successivo, il Tema 9, è dedicato all'AI per dati e analisi: preparazione, elaborazione, analisi, interpretazione e rappresentazione dei dati. È il naturale proseguimento dell'8.4: abbiamo visto come trasformare testi in dati strutturati, ora vedremo come analizzarli. I documenti di perimetro richiamano poi altri temi dell'area e del percorso: l'AI multimodale, nel Tema 10; assistenti, agenti e automazioni, nel Tema 11, dove torneranno gli assistenti documentali e i flussi di estrazione automatica; AI, dati e conoscenza aziendale, nel Tema 14, dove si affronta la progettazione dei sistemi di conoscenza in azienda. In tutti questi temi resteranno validi i principi di questo modulo: fedeltà del significato, completezza, tracciabilità verso le fonti. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi, documenti e conoscenza (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.5, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 9: AI per dati e analisi", { x: 5.4, y: 1.72, w: 3.9, h: 0.4, fontSize: 16, bold: true, color: C.background1 });
    txt(s, "Dal testo strutturato all'analisi dei dati", { x: 5.4, y: 2.1, w: 3.9, h: 0.3, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 2.6, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 10: AI multimodale", "Tema 11: assistenti, agenti e automazioni", "Tema 14: dati e conoscenza aziendale"], { space: 5 }), { x: 5.4, y: 2.95, w: 3.9, h: 1.6, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Lo studio di Liu e colleghi è già presentato nel Tema 2; il lavoro di Lewis e colleghi introduce l'architettura RAG, qui solo accennata e approfondita nel Tema 14. Il modulo si basa soprattutto sull'esperienza pratica dell'uso dell'AI su testi e documenti, che evolve rapidamente: le capacità degli strumenti nella gestione di documenti lunghi, tabelle e scansioni migliorano di continuo. Prima di ogni edizione è consigliabile verificare le funzionalità degli strumenti autorizzati in azienda, e aggiornare gli esempi di conseguenza. Gli esempi usati nelle slide sono tutti fittizi.");
    const src = [
      "Liu, N. F. et al. (2024). Lost in the Middle: How Language Models Use Long Contexts. Transactions of the ACL, 12, 157-173.",
      "Lewis, P. et al. (2020). Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS 2020.",
      "Gli esempi di documenti, email, offerte e procedure presenti nelle slide sono fittizi.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema8_AI_testi_documenti_conoscenza.pptx" });
  await applyTheme("Tema8_AI_testi_documenti_conoscenza.pptx", THEME);
  console.log("done");
})();
