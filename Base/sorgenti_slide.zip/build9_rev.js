const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 9: AI per dati e analisi";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 9  ·  AI per dati e analisi";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function phaseTag(s, active) {
    const st = ["Comprendere", "Elaborare", "Rappresentare", "Interpretare"];
    st.forEach((t, i) => {
      const x = 6.3 + i * 0.81;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.78, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "fase " + t });
      txt(s, t, { x, y: 0.42, w: 0.78, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function scatter(s, xs, ys, o) {
    s.addChart(pres.charts.SCATTER, [{ name: "X", values: xs }, { name: o.name || "Y", values: ys }], {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: 0, lineDataSymbol: "circle", lineDataSymbolSize: o.size || 6, chartColors: [o.color || HEX.a1],
      valAxisMinVal: o.ymin, valAxisMaxVal: o.ymax, catAxisMinVal: o.xmin, catAxisMaxVal: o.xmax,
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 8, catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 8,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, showLegend: false,
      showTitle: !!o.title, title: o.title || "", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      valAxisLabelFontFace: "+mn-lt", catAxisLabelFontFace: "+mn-lt",
    });
  }


  // ---------- helper aggiunti nella revisione ----------
  function steps(s, items, o) {
    o = o || {};
    const n = items.length, gap = 0.18, W = 9.0, x0 = 0.5;
    const w = (W - gap * (n - 1)) / n, y = o.y || 1.12, h = o.h || 1.45;
    items.forEach((it, i) => {
      const x = x0 + i * (w + gap);
      const last = i === n - 1 && o.darkLast;
      shapeBox(s, x, y, w, h, last ? C.accent1 : (i % 2 ? C.accent6 : C.background2), "passo " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y: y + 0.08, w: 0.35, h: 0.34, fontSize: 18, bold: true, color: last ? C.background1 : C.accent1, valign: "middle" });
      txt(s, it[0], { x: x + 0.45, y: y + 0.08, w: w - 0.52, h: 0.34, fontSize: o.headSize || 12, bold: true, color: last ? C.background1 : C.text1, valign: "middle" });
      txt(s, it[1], { x: x + 0.12, y: y + 0.48, w: w - 0.22, h: h - 0.56, fontSize: o.bodySize || 10, color: last ? C.background1 : C.text1 });
      if (i < n - 1) s.addShape(pres.shapes.RIGHT_ARROW, { x: x + w + 0.02, y: y + h / 2 - 0.08, w: gap - 0.04, h: 0.16, fill: { color: C.accent2 }, line: { type: "none" }, objectName: "freccia passo" });
    });
  }
  function regionTable(s, x, y, w, o) {
    o = o || {};
    table(s, [["Regione", "Q3 2024 (k€)", "Q3 2025 (k€)", "Variazione"],
      ["Nord", "1.840", "1.950", "+6,0%"],
      ["Centro", "1.150", "1.012", "-12,0%"],
      ["Sud", "760", "790", "+3,9%"],
      ["Totale", "3.750", "3.752", "+0,1%"]],
      { x, y, w, colW: o.colW || [w * 0.25, w * 0.25, w * 0.25, w * 0.25], rowH: o.rowH || 0.3, fontSize: o.fontSize || 11, blankCorner: false, accentCol: 3 });
  }
  function regionChart(s, x, y, w, h, o) {
    o = o || {};
    s.addChart(pres.charts.BAR, [
      { name: "Q3 2024", labels: ["Nord", "Centro", "Sud"], values: [1840, 1150, 760] },
      { name: "Q3 2025", labels: ["Nord", "Centro", "Sud"], values: [1950, 1012, 790] },
    ], {
      x, y, w, h, barDir: "col", barGrouping: "clustered", chartColors: [HEX.a3, HEX.a1], barGapWidthPct: 60,
      showValue: !!o.values, dataLabelFontSize: 8, dataLabelColor: HEX.dk2, dataLabelFontFace: "+mn-lt", dataLabelPosition: "outEnd", dataLabelFormatCode: "#,##0",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.fs || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 2300, valGridLine: { style: "none" }, catGridLine: { style: "none" },
      showLegend: o.legend !== false, legendPos: "b", legendFontSize: 9, legendFontFace: "+mn-lt", legendColor: HEX.dk2,
      showTitle: !!o.title, title: o.title || "", titleFontSize: 10, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 9", { placeholder: "kicker" });
    s.addText("AI per dati e analisi", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.45, w: 8.6, h: 0.35, fontSize: 12, color: C.accent2 });
    s.addNotes("Benvenuti al nono tema, il secondo dell'area 'Esplorare le possibilità dell'AI'. Nel Tema 8 abbiamo lavorato su testi e documenti; qui passiamo ai dati. Il messaggio del modulo è semplice: l'AI rende l'analisi dei dati più accessibile, veloce ed esplorativa, e permette di ricavare informazioni utili anche senza competenze avanzate di programmazione. La qualità dei risultati dipende da tre cose su cui possiamo agire: usare bene gli strumenti, partire da dati di qualità, interpretare con competenza. Vedremo come capire e preparare un file, calcolare indicatori, trovare tendenze e anomalie, costruire grafici e report, fare stime e scenari, e arrivare a una decisione. Useremo per tutto il modulo un caso fittizio di vendite, così da seguire lo stesso esempio dai dati grezzi alla decisione. Il punto di vista è quello dell'utilizzatore: niente algoritmi specialistici né architetture di Business Intelligence. Apertura suggerita: chiedere ai partecipanti quali dati usano nel lavoro e quanto tempo dedicano a prepararli rispetto a interpretarli. Nota per il relatore: le funzioni di analisi dei dati negli strumenti AI evolvono rapidamente; verificare prima di ogni edizione che cosa permettono gli strumenti autorizzati in azienda (lettura di file, esecuzione di codice, collegamento a fonti dati).");
  }
  {
    const s = content("Obiettivo del modulo", "Che cosa vogliamo ottenere. Primo, conoscere che cosa l'AI permette di fare con i dati: esplorarli ponendo domande in linguaggio naturale, prepararli, calcolare indicatori, rappresentare i risultati, ragionare su scenari e alternative. Chi non sa scrivere una formula complessa o un'interrogazione su un database può oggi ottenere risultati utili descrivendo ciò che vuole sapere. Secondo, sapere da che cosa dipende la qualità del risultato, perché su questi fattori possiamo agire: l'uso corretto degli strumenti, per esempio scegliere uno strumento che esegue davvero i calcoli; la qualità dei dati, cioè completezza, definizioni chiare, provenienza nota; la capacità di interpretazione, che resta di chi conosce il contesto. È il filo del modulo: per ogni possibilità vedremo anche la pratica che la rende affidabile. Non si tratta di diffidare dell'AI, ma di usarla con competenza, con controlli proporzionati all'importanza dell'analisi.");
    await card(s, 0.5, 1.15, 4.35, 2.75, { icon: "FiTarget", head: "Che cosa permette l'AI", headSize: 16, bodySize: 14,
      body: bullets(["Esplorare i dati con domande in linguaggio naturale", "Preparare, calcolare e rappresentare più rapidamente", "Ricavare informazioni utili senza programmare"], { space: 6 }) });
    await card(s, 5.15, 1.15, 4.35, 2.75, { icon: "FiCompass", head: "Da che cosa dipende la qualità", headSize: 16, fill: C.accent6, bodySize: 14,
      body: bullets(["Uso corretto degli strumenti", "Qualità dei dati", "Capacità di interpretazione"], { space: 6 }) });
    banner(s, 4.08, "L'AI rende l'analisi dei dati più accessibile, veloce ed esplorativa. La qualità dei risultati dipende da strumenti usati bene, dati di qualità e interpretazione.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Il filo conduttore: quattro fasi", "Il modulo segue quattro fasi del lavoro analitico, e per ciascuna vediamo che cosa fa l'AI. Comprendere e preparare: l'AI descrive il file, segnala problemi di qualità, propone la pulizia; sottotemi 9.1 e 9.2. Elaborare e analizzare: calcola indicatori, aggregazioni, statistiche, trova tendenze e anomalie; 9.3 e 9.4. Rappresentare e prevedere: crea grafici, tabelle e report, costruisce stime e scenari; 9.5 e 9.6. Interpretare e valutare: propone ipotesi, aiuta a confrontare alternative, e vediamo quali controlli rendono affidabile il tutto; 9.7 e 9.8. Due precisazioni. È uno schema didattico: il lavoro reale è iterativo, un'anomalia riporta ai dati, un grafico suggerisce una nuova domanda. E il contributo cambia natura lungo il processo: nelle prime fasi contano soprattutto dati e calcoli corretti, nelle ultime il contesto e il giudizio di chi conosce il caso. Il sottotema 9.6, previsioni e simulazioni, è da conoscere e comprendere; gli altri anche da sperimentare. Algoritmi specialistici, modellazione avanzata e architetture di BI sono solo accennati: le condizioni per rendere disponibili i dati aziendali sono trattate nel Tema 14. Nelle slide, l'indicatore in alto a destra ricorda la fase.");
    const st = [["FiDatabase", "Comprendere e preparare", "Descrive il file, segnala problemi, propone la pulizia", "9.1  9.2"], ["FiCpu", "Elaborare e analizzare", "Calcola indicatori, trova tendenze e anomalie", "9.3  9.4"], ["FiBarChart2", "Rappresentare e prevedere", "Crea grafici e report, costruisce stime e scenari", "9.5  9.6"], ["FiCheckCircle", "Interpretare e valutare", "Propone ipotesi, aiuta a confrontare alternative", "9.7  9.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.55, dark ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.1, y: 2.03, w: 1.9, h: 0.55, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.62, w: 1.8, h: 0.62, fontSize: 11, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.1, y: 3.3, w: 1.9, h: 0.3, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.25, 0.17);
    }
    shapeBox(s, 0.5, 3.88, 9.0, 1.05, C.accent6, "iterazione");
    txt(s, [{ text: "Uno schema didattico: ", options: { bold: true, color: C.accent1 } }, { text: "il lavoro reale è iterativo, un'anomalia riporta ai dati, un grafico suggerisce una domanda. ", options: { color: C.text1 } }, { text: "Lungo il processo ", options: { bold: true, color: C.accent1 } }, { text: "cresce il peso di contesto e giudizio: prima contano dati e calcoli, poi l'interpretazione.", options: { color: C.text1 } }], { x: 0.7, y: 3.88, w: 8.6, h: 1.05, fontSize: 12, valign: "middle" });
  }
  {
    const s = content("Quattro tipi di analisi", "Una distinzione che attraversa tutto il modulo. L'analisi descrittiva risponde a 'che cosa è successo?': quanto abbiamo venduto, dove, con quale andamento. La diagnostica a 'perché è successo?': quali fattori spiegano il calo in una regione. La predittiva a 'che cosa potrebbe succedere?': quanto venderemo nel prossimo trimestre, con quale margine di incertezza. La prescrittiva a 'che cosa conviene fare?': quale prezzo, quanto ordinare, dove investire. L'AI può supportare tutte e quattro, ed è proprio questo uno dei suoi vantaggi: si passa rapidamente dalla descrizione alle ipotesi e agli scenari. Salendo nella scala crescono il valore per le decisioni, ma anche l'incertezza e la dipendenza dalle ipotesi: descrivere è relativamente oggettivo se i dati sono corretti, spiegare richiede di distinguere correlazione e causa, prevedere richiede ipotesi sul futuro, prescrivere anche criteri di valore. La pratica utile è semplice: chiedere all'AI di dichiarare il tipo di ogni affermazione, così una descrizione non diventa senza accorgersene una spiegazione o una raccomandazione. Nel caso delle vendite che seguiremo: il calo del Centro è una descrizione, il cliente principale come causa è una diagnosi verificata, il colloquio con il cliente è una scelta.");
    const t = [["Descrittiva", "Che cosa è successo?", "Vendite per regione e mese"], ["Diagnostica", "Perché è successo?", "Fattori del calo in una regione"], ["Predittiva", "Che cosa potrebbe succedere?", "Vendite del prossimo trimestre"], ["Prescrittiva", "Che cosa conviene fare?", "Prezzo, ordini, investimenti"]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 2.3, y = 1.2 + (3 - i) * 0.3;
      const f = [C.background2, C.accent6, C.accent2, C.accent1][i];
      const fc = i >= 2 ? C.background1 : C.text1;
      shapeBox(s, x, y, 2.15, 2.4 - (3 - i) * 0.3 + 0.3, f, e[0]);
      txt(s, e[0], { x: x + 0.15, y: y + 0.1, w: 1.9, h: 0.38, fontSize: 15, bold: true, color: i >= 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: y + 0.5, w: 1.9, h: 0.5, fontSize: 12, bold: true, color: fc });
      txt(s, e[2], { x: x + 0.15, y: y + 1.0, w: 1.9, h: 0.5, fontSize: 11, italic: true, color: fc });
    });
    txt(s, "Valore per le decisioni, incertezza e dipendenza dalle ipotesi crescono", { x: 0.5, y: 4.05, w: 6.0, h: 0.4, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
    s.addShape(pres.shapes.RIGHT_ARROW, { x: 6.6, y: 4.09, w: 2.9, h: 0.32, fill: { color: C.accent5 }, line: { type: "none" }, objectName: "freccia crescita" });
    txt(s, "Pratica utile: chiedere all'AI di indicare se ogni affermazione è una descrizione, una spiegazione, una previsione o una raccomandazione.", { x: 0.5, y: 4.52, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text1 });
  }

  // =====================================================================
  section("9.1 AI e analisi");
  divider("9.1", "L'AI come supporto all'analisi dei dati", "Interrogare i dati in linguaggio naturale li rende accessibili a molte più persone; la qualità dell'interpretazione resta decisiva", "Il primo sottotema colloca l'AI nel lavoro con i dati. Vediamo la differenza tra dati, informazioni e conoscenza, che cosa aggiunge l'AI agli strumenti già in uso, come funzionano le domande in linguaggio naturale, come strumenti tradizionali e AI lavorano insieme, e come cambia in concreto il flusso di lavoro. Il messaggio chiave: rendere più facile interrogare i dati è un'opportunità reale, perché molte più persone possono rispondere da sole alle proprie domande, più rapidamente e con i dati invece che con le impressioni. Perché l'interpretazione sia corretta servono anche alcune competenze di base e la conoscenza del dominio. Esercizio suggerito per il sottotema: dare ai partecipanti una domanda in linguaggio naturale su un dataset fittizio, chiedere di elencare le interpretazioni possibili dei termini e poi confrontare i risultati ottenuti con interpretazioni diverse.");
  {
    const s = content("Dati, informazioni, conoscenza", "Riprendiamo una distinzione del Tema 8 dal punto di vista dei numeri, introducendo il caso fittizio che seguiremo nel modulo: le vendite di un'azienda organizzata in tre regioni, Nord, Centro e Sud. Un dato è un valore registrato: 320. Diventa informazione con un significato e un contesto: a settembre 2025 la regione Centro ha fatturato 320 mila euro, al netto di IVA e resi. Diventa conoscenza quando permette di capire e agire: è il 26 per cento in meno di settembre 2024, il calo riguarda solo il Centro ed è legato a un cliente principale; prima di rivedere il budget conviene parlare con il cliente. L'AI aiuta in ogni passaggio: calcola il confronto con l'anno prima, scompone per regione e per cliente, propone ipotesi. Il passaggio all'ultimo livello richiede anche il dominio: sapere chi è quel cliente, se ci sono stati eventi particolari, che cosa include esattamente il dato. Per questo la combinazione più efficace è l'AI che esplora rapidamente e la persona che conosce il contesto.");
    phaseTag(s, 0);
    const lv = [["Dato", "320"], ["Informazione", "Settembre 2025, regione Centro: 320 k€ di fatturato netto"], ["Conoscenza", "-26% su settembre 2024, solo al Centro, legato a un cliente principale: parlarne con il cliente prima di rivedere il budget"]];
    lv.forEach((l, i) => {
      const y = 1.12 + i * 0.93;
      shapeBox(s, 0.5, y, 9.0, 0.82, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), l[0]);
      txt(s, l[0], { x: 0.7, y, w: 2.0, h: 0.82, fontSize: 15, bold: true, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, l[1], { x: 2.7, y, w: 6.6, h: 0.82, fontSize: i ? 13 : 20, bold: i === 0, color: i === 2 ? C.background1 : C.text1, valign: "middle" });
    });
    banner(s, 4.0, "L'AI aiuta in ogni passaggio. Per arrivare alla conoscenza servono anche il contesto e chi conosce il dominio.", { h: 0.65, fontSize: 13 });
    txt(s, "Esempio fittizio: il caso delle vendite, ripreso nel resto del modulo", { x: 0.5, y: 4.7, w: 9, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
  }
  {
    const s = content("Analisi dei dati e BI", "In azienda l'analisi dei dati si basa su strumenti consolidati: fogli di calcolo, usati da quasi tutti; strumenti di Business Intelligence, che raccolgono i dati dei sistemi aziendali in report e cruscotti con indicatori definiti; strumenti statistici e linguaggi di programmazione, usati dagli specialisti. Chi non aveva competenze tecniche dipendeva dai report predefiniti o dalla disponibilità degli analisti. L'AI non si limita a inserirsi in questi strumenti: apre modi nuovi di lavorare con i dati. Si possono porre domande in linguaggio naturale a un file o a una fonte dati; esplorare liberamente, seguendo una domanda dopo l'altra, senza aspettare un nuovo report; far scrivere ed eseguire analisi su un file, negli strumenti che leggono file ed eseguono codice; farsi spiegare un risultato, una formula, un grafico ricevuto. Una precisazione importante: non tutti i sistemi AI hanno le stesse capacità. Alcuni leggono file ed eseguono codice, altri sono collegati a fonti dati aziendali, altri lavorano solo sul testo della conversazione. Le funzioni dipendono dallo strumento e da come l'azienda lo ha configurato: conviene verificarle su quello autorizzato. Architetture di BI e integrazioni con i sistemi aziendali sono solo accennate: se ne parla nel Tema 14.");
    phaseTag(s, 0);
    txt(s, "Strumenti consolidati", { x: 0.5, y: 1.12, w: 4.35, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const tr = [["FiGrid", "Fogli di calcolo", "Calcoli, tabelle, grafici"], ["FiPieChart", "Business Intelligence", "Report e cruscotti con indicatori definiti"], ["FiTerminal", "Strumenti statistici e codice", "Analisi complesse, per specialisti"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.5 + i * 0.78;
      shapeBox(s, 0.5, y, 4.35, 0.68, C.background2, tr[i][1]);
      await iconCircle(s, 0.62, y + 0.11, 0.46, tr[i][0], C.accent2);
      txt(s, tr[i][1], { x: 1.2, y: y + 0.05, w: 3.5, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
      txt(s, tr[i][2], { x: 1.2, y: y + 0.35, w: 3.5, h: 0.3, fontSize: 11, color: C.text2 });
    }
    txt(s, "Che cosa aggiunge l'AI", { x: 5.15, y: 1.12, w: 4.35, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    const ai = ["Domande ai dati in linguaggio naturale", "Esplorazione libera, senza report predefiniti", "Analisi di file con codice eseguito, dove previsto", "Spiegazione di risultati, formule e grafici"];
    ai.forEach((t, i) => chip(s, 5.15, 1.5 + i * 0.585, 4.35, 0.5, t, { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.0, "Non solo un'integrazione: un nuovo modo di interrogare ed esplorare i dati. Le funzioni disponibili variano per strumento e configurazione.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Domande in linguaggio naturale", "La novità più visibile: interrogare i dati ponendo domande in linguaggio naturale invece di scrivere formule o codice. Esempio fittizio: quali sono i dieci clienti che hanno speso di più nell'ultimo trimestre? Per rispondere, il sistema traduce la domanda in operazioni precise e compie alcune scelte. 'Clienti': tutti quelli in anagrafica o quelli con almeno un acquisto? 'Ultimo trimestre': trimestre solare o ultimi novanta giorni? 'Speso di più': fatturato lordo o netto di resi e sconti? Ogni scelta è ragionevole, ma cambia il risultato, e nella risposta si vede l'elenco, non sempre le ipotesi. La soluzione è semplice e rende l'interrogazione ancora più efficace: inserire nella domanda le definizioni aziendali, per esempio 'fatturato netto di resi, trimestre solare', oppure chiedere al sistema di spiegare come ha interpretato la domanda e quali filtri ha applicato. In pochi secondi si ottiene così un risultato chiaro e anche la sua definizione. È lo stesso principio di un buon prompt visto nel Tema 6, applicato ai dati.");
    phaseTag(s, 0);
    docBox(s, 0.5, 1.15, 9.0, 0.75, "Domanda (esempio fittizio)", "Quali sono i dieci clienti che hanno speso di più nell'ultimo trimestre?", { fontSize: 14 });
    txt(s, "Le scelte implicite nella traduzione in operazioni", { x: 0.5, y: 2.05, w: 9, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const q = [["Clienti", "In anagrafica o con almeno un acquisto?"], ["Ultimo trimestre", "Trimestre solare o ultimi 90 giorni?"], ["Speso di più", "Fatturato lordo o netto di resi e sconti?"]];
    q.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.45, 2.86, 1.15, C.accent6, e[0]);
      txt(s, "'" + e[0] + "'", { x: x + 0.15, y: 2.52, w: 2.56, h: 0.38, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 2.92, w: 2.56, h: 0.6, fontSize: 12, color: C.text1 });
    });
    banner(s, 3.8, "Pratica utile: inserire le definizioni nella domanda, o chiedere all'AI come l'ha interpretata e quali filtri ha applicato.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Strumenti tradizionali e AI", "Più che scegliere tra analisi tradizionale e analisi assistita, conviene combinarle. Gli strumenti consolidati offrono definizioni e report ufficiali, calcoli ripetibili e controllati, visibilità di ogni passaggio. L'AI offre la possibilità di porre domande in linguaggio naturale, di esplorare rapidamente più ipotesi, di ottenere prime elaborazioni, grafici e spiegazioni senza competenze tecniche specifiche. Insieme funzionano bene: l'AI esplora e propone, gli strumenti e le definizioni aziendali rendono i risultati confrontabili e controllabili. Un esempio: si esplora un'esportazione con l'AI per capire dove si concentra un calo, poi si verifica il dato chiave nel report ufficiale. Evitiamo le generalizzazioni: un'analisi tradizionale ben impostata può essere rapidissima, per esempio un report già pronto, e un'analisi con l'AI può richiedere tempo se i dati sono disordinati o la domanda è complessa. I vantaggi tipici dell'AI sono la flessibilità e la riduzione delle barriere tecniche; la velocità dipende da dati, strumento e domanda. Il ponte tra i due approcci è la tracciabilità delle operazioni, che vedremo nel 9.3.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.15, 2.86, 2.75, { icon: "FiGrid", head: "Strumenti consolidati", headSize: 14, bodySize: 12,
      body: bullets(["Definizioni e report ufficiali", "Calcoli ripetibili e controllati", "Ogni passaggio visibile"], { space: 5 }) });
    await card(s, 3.57, 1.15, 2.86, 2.75, { icon: "FiMessageCircle", head: "AI", headSize: 14, bodySize: 12, fill: C.accent6,
      body: bullets(["Domande in linguaggio naturale", "Esplorazione rapida di più ipotesi", "Prime elaborazioni, grafici, spiegazioni"], { space: 5 }) });
    await card(s, 6.64, 1.15, 2.86, 2.75, { icon: "FiLink", head: "Insieme", headSize: 14, bodySize: 12, fill: C.accent1, headColor: C.background1, bodyColor: C.background1, iconBg: C.background1, iconFg: HEX.a1,
      body: "L'AI esplora e propone; strumenti e definizioni aziendali rendono i risultati confrontabili e controllabili." });
    banner(s, 4.08, "Velocità e flessibilità dipendono da dati, strumento e domanda. Il ponte tra i due approcci: rendere tracciabili le operazioni.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("La democratizzazione dell'analisi", "Il linguaggio naturale riduce le barriere tecniche, e questo è uno dei contributi più concreti dell'AI. Un responsabile commerciale può esplorare le vendite della propria area senza attendere un report; un responsabile del personale può analizzare le assenze per reparto; chiunque può creare un indicatore descrivendolo a parole, per esempio 'il tasso di reso per prodotto, sul numero di pezzi', o farsi spiegare un foglio di calcolo ricevuto. Più persone possono formulare e verificare domande analitiche, più rapidamente, e decidere con i dati invece che con le impressioni. Che cosa fa la differenza nella qualità del risultato? Due famiglie di competenze. Le competenze analitiche di base: confrontare gruppi omogenei, distinguere media e mediana, sapere che pochi dati danno risultati instabili, distinguere correlazione e causa. Non serve diventare statistici: bastano i principali modi in cui un'analisi può ingannare, e l'AI stessa può aiutare a controllarli se glielo si chiede. E la conoscenza del dominio: come sono stati raccolti i dati, che cosa misurano, quali eventi o stagionalità ne spiegano l'andamento, quali definizioni usa l'azienda. L'AI la possiede solo se le viene fornita. Con l'AI cambia il peso delle competenze: meno tecnica, più interpretazione e contesto.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.15, 4.35, 2.7, { icon: "FiUsers", head: "Che cosa diventa possibile", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Esplorare i dati della propria area senza attendere un report", "Creare un indicatore descrivendolo a parole", "Formulare e verificare domande analitiche", "Farsi spiegare un foglio o una formula"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.7, { icon: "FiBookOpen", head: "Le competenze che contano", headSize: 15, bodySize: 12,
      body: bullets(["Confronti tra gruppi omogenei", "Media e mediana; pochi dati, risultati instabili", "Correlazione e causalità", "Dominio: raccolta dei dati, definizioni, eventi"], { space: 4 }) });
    shapeBox(s, 0.5, 4.05, 9.0, 0.88, C.text1, "peso competenze");
    txt(s, [{ text: "Con l'AI cambia il peso delle competenze: ", options: { color: C.background1 } }, { text: "meno tecnica, più interpretazione e contesto.", options: { color: C.accent6, bold: true } }], { x: 0.7, y: 4.05, w: 8.6, h: 0.88, fontSize: 15, valign: "middle" });
  }
  {
    const s = content("Come cambia il workflow", "Questa slide mostra in concreto come cambia il processo operativo, passaggio per passaggio, senza promettere tempi o risparmi precisi: dipendono dai dati, dallo strumento e dalla complessità della domanda. Capire il file: prima si apriva, si scorreva, si chiedeva a chi lo aveva prodotto; ora l'AI descrive struttura e colonne, e resta da confermare il significato delle colonne e le definizioni. Preparare i dati: prima formule e correzioni a mano; ora i problemi vengono segnalati e la pulizia proposta, e resta da approvare le trasformazioni che cambiano i risultati. Calcolare: prima formule e tabelle pivot; ora una richiesta in linguaggio naturale, con codice eseguito negli strumenti che lo prevedono, e resta da controllare filtri e definizioni. Rappresentare: prima il grafico si costruiva a mano; ora si chiede e si modifica a parole, e resta da scegliere il messaggio. Interpretare: prima il commento era scritto da chi analizzava; ora l'AI propone una bozza e alcune ipotesi, e restano la verifica delle cause e la decisione. Il messaggio: si semplificano soprattutto i passaggi tecnici; definizioni, conferme e giudizio restano a chi analizza.");
    phaseTag(s, 0);
    table(s, [["Passaggio", "Workflow tradizionale", "Con l'AI", "Resta necessario"],
      ["Capire il file", "Aprire, scorrere, chiedere", "Struttura e colonne descritte", "Confermare significati"],
      ["Preparare", "Formule e correzioni a mano", "Problemi segnalati, pulizia proposta", "Approvare le trasformazioni"],
      ["Calcolare", "Formule, tabelle pivot", "Richiesta a parole, codice eseguito", "Controllare filtri e definizioni"],
      ["Rappresentare", "Grafico costruito a mano", "Grafici proposti e modificati a parole", "Scegliere il messaggio"],
      ["Interpretare", "Commento scritto da chi analizza", "Bozza di commento e ipotesi", "Verificare le cause, decidere"]],
      { y: 1.12, colW: [1.55, 2.35, 2.6, 2.5], rowH: 0.47, fontSize: 11, blankCorner: false, accentCol: 2 });
    banner(s, 4.12, "Si semplificano soprattutto i passaggi tecnici. Definizioni, conferme e giudizio restano a chi analizza; i tempi variano con dati e strumenti.", { h: 0.8, fontSize: 13 });
  }

  // =====================================================================
  section("9.2 Preparazione e qualità");
  divider("9.2", "Comprensione, preparazione e qualità dei dati", "L'AI aiuta a capire, controllare e preparare un file in poco tempo; confermare struttura, definizioni e rappresentatività rende affidabile tutto il resto", "Prima di analizzare, bisogna capire e preparare i dati: è spesso la fase più lunga del lavoro, ed è quella in cui l'AI fa risparmiare più fatica. In questo sottotema vediamo un flusso concreto di analisi di un file Excel, i tipi di dati e di formati, come l'AI riconosce colonne e formati, come segnala mancanti, duplicati e anomalie, come propone la pulizia, la rappresentatività del campione, definizioni, provenienza e indicatori. Il concetto chiave del sottotema: un dataset apparentemente ordinato non è necessariamente corretto, completo o rappresentativo. Per questo il valore dell'AI è doppio: rende la preparazione rapida e porta alla luce i problemi; a noi resta confermare le scelte che cambiano i risultati. Esercizio suggerito: dare ai partecipanti un piccolo file fittizio con problemi nascosti, come date in due formati, un duplicato con nome diverso, un mancante e un valore anomalo, e farlo analizzare all'AI prima senza e poi con una richiesta esplicita di controllo della qualità.");
  {
    const s = content("Analizzare un Excel con l'AI", "Un flusso concreto, con il caso fittizio delle vendite. Uno: si carica il file, vendite_2025.xlsx con 12.480 righe, in uno strumento autorizzato dall'azienda che legge file ed esegue codice. Non tutti gli assistenti lo fanno: alcuni lavorano solo sul testo incollato nella conversazione, ed è una differenza importante, come vedremo nel 9.3. Due: si chiede di descrivere il file; il sistema elenca righe, colonne, periodo coperto e segnala, per esempio, date in due formati. Tre: si pone la domanda, in linguaggio naturale e con le definizioni: come va il fatturato netto del terzo trimestre per regione, rispetto al 2024? Quattro: il sistema scrive ed esegue il codice, filtra, somma, calcola le variazioni. Cinque: restituisce una tabella, un grafico e una breve spiegazione, con le scelte dichiarate. Il risultato è già informativo: il totale è stabile, più 0,1 per cento, ma nasconde un Centro in calo del 12 per cento mentre Nord e Sud crescono. Senza competenze di programmazione, in pochi passaggi, si è arrivati a una domanda precisa da approfondire. Controllo rapido sui numeri: 1.840 più 1.150 più 760 fa 3.750; 1.950 più 1.012 più 790 fa 3.752. Promemoria: caricare solo dati autorizzati, nello strumento autorizzato.");
    phaseTag(s, 0);
    steps(s, [["Caricare", "vendite_2025.xlsx in uno strumento autorizzato che legge file ed esegue codice"], ["Comprendere", "Righe, colonne e periodo descritti; date in due formati segnalate"], ["Chiedere", "\"Fatturato netto Q3 per regione, rispetto al 2024?\""], ["Elaborare", "Il sistema scrive ed esegue il codice: filtri, somme, variazioni"], ["Restituire", "Tabella, grafico e spiegazione, con le scelte dichiarate"]], { y: 1.1, h: 1.45, darkLast: true });
    regionTable(s, 0.5, 2.72, 4.45, { colW: [1.0, 1.15, 1.15, 1.15], rowH: 0.3, fontSize: 10 });
    regionChart(s, 5.1, 2.65, 4.4, 1.65, { title: "Fatturato netto Q3 per regione (k€)" });
    banner(s, 4.38, "Spiegazione: il totale è stabile (+0,1%), ma il Centro cala del 12% mentre Nord e Sud crescono. Da approfondire.", { h: 0.6, fontSize: 12 });
  }
  {
    const s = content("Tipi di dati e formati", "Una prima distinzione. I dati strutturati sono organizzati in righe e colonne con un significato definito: una tabella di vendite, un elenco di clienti, un registro di presenze. I dati non strutturati sono testi, email, documenti, immagini, registrazioni: contengono informazioni, ma non in forma direttamente calcolabile; l'AI può trasformarli in dati con un'estrazione controllata, come visto nel Tema 8. Qui ci concentriamo sui dati strutturati. I formati più comuni sono tre. Il foglio di calcolo, come Excel, con più fogli, formule, celle unite, note: molto flessibile, e per questo spesso disordinato; l'AI è utile proprio nel riconoscere intestazioni su più righe, celle unite e righe di totale. Il file CSV, valori separati da virgole o punti e virgola: semplice, senza formule né formattazioni, usato per esportare dati dai sistemi. Le tabelle dei database e dei gestionali, a cui si accede con esportazioni, strumenti di BI o, in alcune configurazioni, collegando direttamente l'assistente alla fonte dati. Un dataset è un insieme di dati organizzato per un'analisi, come l'esportazione delle vendite dell'anno.");
    phaseTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 1.6, { icon: "FiGrid", inline: true, head: "Dati strutturati", headSize: 15, bodySize: 12, fill: C.accent6, body: "Righe e colonne con un significato definito: vendite, clienti, presenze." });
    await card(s, 5.15, 1.2, 4.35, 1.6, { icon: "FiFileText", inline: true, head: "Dati non strutturati", headSize: 15, bodySize: 12, body: "Testi, email, immagini, registrazioni. Si possono trasformare in dati, con un'estrazione controllata." });
    const f = [["Foglio di calcolo", "Più fogli, formule, celle unite, note: flessibile e spesso disordinato"], ["CSV", "Solo dati separati da un carattere: semplice, usato per le esportazioni"], ["Database e gestionali", "Esportazioni, strumenti di BI o collegamenti dell'assistente, dove previsti"]];
    f.forEach((e, i) => {
      const y = 3.0 + i * 0.62;
      shapeBox(s, 0.5, y, 9.0, 0.54, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.5, h: 0.54, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.2, y, w: 6.1, h: 0.54, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Struttura, variabili e formati", "Il primo uso dell'AI su un dataset è capirlo, ed è un aiuto prezioso soprattutto con file preparati da altri o esportazioni da sistemi poco noti. Nell'estratto fittizio in slide il sistema riconosce le colonne e il loro tipo, segnala due formati di data, un importo mancante, lo stesso cliente scritto in due modi, una riga di totale mescolata ai dati, e propone come normalizzare formati e nomi. Ogni colonna è una variabile, e il tipo determina quali operazioni hanno senso: le numeriche continue, come importi e durate, si sommano e si mediano; le discrete, come pezzi e ordini, si contano; le categoriche, come regione e canale, servono a raggruppare; le ordinali, come una valutazione da 1 a 5, hanno un ordine, ma la loro media va usata con cautela. Tra i problemi di formato più comuni: numeri memorizzati come testo, separatori decimali diversi, per cui 1.200 può essere milleduecento o uno virgola due, date come 03/04 che possono essere 3 aprile o 4 marzo, codici come i CAP che perdono gli zeri iniziali. L'AI li individua bene. Una cosa va confermata da chi conosce il dato: il significato delle colonne. 'Importo' è con o senza IVA? 'Stato 3' che cosa indica? Una conferma all'inizio evita errori che si propagherebbero in modo coerente, e quindi difficile da notare, in tutta l'analisi.");
    phaseTag(s, 0);
    table(s, [["Data", "Cliente", "Importo", "Stato"],
      ["03/04/2025", "Rossi Srl", "1.200", "3"],
      ["2025-04-05", "ROSSI S.R.L.", "980", "3"],
      ["07/04/2025", "Bianchi Spa", "", "2"],
      ["Totale", "", "2.180", ""]],
      { x: 0.5, y: 1.12, w: 4.9, colW: [1.25, 1.45, 1.1, 1.1], rowH: 0.34, fontSize: 11, blankCorner: false });
    txt(s, "Estratto fittizio", { x: 0.5, y: 2.86, w: 3, h: 0.25, fontSize: 10, italic: true, color: C.accent2 });
    shapeBox(s, 5.6, 1.12, 3.9, 1.98, C.accent6, "che cosa fa l'AI");
    txt(s, "Che cosa fa l'AI", { x: 5.78, y: 1.18, w: 3.6, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
    txt(s, bullets(["Riconosce colonne e tipi di dato", "Segnala due formati di data e un importo mancante", "Trova lo stesso cliente scritto in due modi e la riga di totale", "Propone come normalizzare formati e nomi"], { space: 3 }), { x: 5.78, y: 1.52, w: 3.6, h: 1.55, fontSize: 11, color: C.text1 });
    txt(s, "Tipo di variabile e operazioni sensate", { x: 0.5, y: 3.18, w: 9, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
    const v = ["Continua: somme, medie", "Discreta: conteggi", "Categorica: raggruppare", "Ordinale: medie con cautela"];
    v.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.5, 2.15, 0.48, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 4.12, "Da confermare con chi conosce il dato: 'Importo' è con o senza IVA? 'Stato 3' che cosa indica? Una conferma all'inizio vale per tutta l'analisi.", { h: 0.82, fontSize: 12 });
  }
  {
    const s = content("Mancanti, duplicati, anomali", "Quattro problemi di qualità ricorrenti, che l'AI individua rapidamente anche su file di migliaia di righe, e per ciascuno può proporre un trattamento. I dati mancanti: celle vuote o valori convenzionali come 'n.d.' o 999. Un dato mancante non è uno zero: trattato come zero abbassa la media, escluso cambia il conteggio. Conviene anche chiedere perché manca: se mancano soprattutto i dati di una sede, l'analisi può risultare distorta. I duplicati: righe ripetute, per esempio da un'esportazione doppia, o lo stesso cliente scritto in modi diversi; gonfiano totali e conteggi. I valori anomali: un ordine da un milione tra ordini da mille euro può essere una virgola spostata o un grande cliente; va capito prima di decidere. I valori incoerenti: una consegna precedente all'ordine, una quantità negativa; spesso conviene correggerli alla fonte. Una buona pratica: chiedere all'AI di segnalare i problemi e proporre un trattamento senza modificare i dati, e confermare le trasformazioni che cambiano i risultati prima di applicarle. Le correzioni evidenti, come un formato di data, si possono accettare rapidamente; quelle di sostanza, come escludere righe, si decidono con il contesto.");
    phaseTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMinusCircle", head: "Mancanti", body: "Celle vuote, 'n.d.', 999. Proposta: escludere o segnalare, non trattarli come zero" },
      { icon: "FiCopy", head: "Duplicati", body: "Righe ripetute, clienti scritti in modi diversi. Proposta: unire dopo controllo" },
      { icon: "FiZap", head: "Anomali", body: "Valori lontani dagli altri. Proposta: verificare se errore o caso reale" },
      { icon: "FiXOctagon", head: "Incoerenti", body: "Consegna prima dell'ordine, quantità negative. Proposta: correggere alla fonte" },
    ], 4, { y: 1.15, h: 2.2, headSize: 14, bodySize: 11 });
    banner(s, 3.55, "L'AI individua i problemi e propone il trattamento in pochi istanti; le trasformazioni che cambiano i risultati si confermano prima di applicarle.", { h: 0.85, fontSize: 13 });
    txt(s, "Esempio: un importo mancante trattato come zero abbassa la media; escluso, cambia il conteggio.", { x: 0.5, y: 4.55, w: 9, h: 0.38, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Pulizia e trasformazione", "Una volta individuati i problemi, l'AI può proporre un piano di pulizia ed eseguirlo, direttamente o scrivendo formule o codice. Le operazioni sono di tre tipi: pulizia, cioè togliere duplicati, righe di totale, errori evidenti; normalizzazione, cioè rendere omogenei formati, nomi, unità e categorie; trasformazione, cioè creare nuove colonne, come il mese dalla data o il margine da prezzo e costo, e unire tabelle diverse. Nell'esempio fittizio, il piano proposto per il file delle vendite: rimuovere tre righe di totale e 41 righe duplicate, uniformare i nomi di 27 clienti scritti in modi diversi, convertire 2.310 date nello stesso formato. Due voci sono segnate come da confermare, perché cambiano i risultati: escludere 312 ordini annullati e 18 righe senza regione. Sono proprio queste le scelte da prendere consapevolmente: unire due clienti con nomi simili ma diversi, eliminare un caso importante o unire tabelle con la chiave sbagliata cambierebbe i numeri senza segnali evidenti. Tre buone pratiche: chiedere il piano prima dell'esecuzione, con il numero di righe coinvolte; confermare le scelte di sostanza; conservare i dati originali. Gli stessi numeri torneranno nel registro delle operazioni del 9.3.");
    phaseTag(s, 0);
    promptBox(s, 0.5, 1.12, 5.4, 2.6, "1. Rimuovere 3 righe di totale\n2. Rimuovere 41 righe duplicate\n3. Uniformare i nomi di 27 clienti\n4. Convertire 2.310 date in gg/mm/aaaa\n5. Escludere 312 ordini annullati?   DA CONFERMARE\n6. 18 righe senza regione: escludere?   DA CONFERMARE", { label: "Piano di pulizia proposto dall'AI (esempio fittizio)", fontSize: 11 });
    const op = [["Pulizia", "Duplicati, righe di totale, errori evidenti"], ["Normalizzazione", "Formati, nomi, unità, categorie omogenei"], ["Trasformazione", "Nuove colonne, unioni tra tabelle"]];
    op.forEach((e, i) => {
      const y = 1.12 + i * 0.89;
      shapeBox(s, 6.1, y, 3.4, 0.8, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.25, y: y + 0.06, w: 3.1, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.25, y: y + 0.38, w: 3.1, h: 0.36, fontSize: 11, color: C.text2 });
    });
    banner(s, 3.92, "Buone pratiche: chiedere il piano prima dell'esecuzione, con le righe coinvolte; confermare le scelte di sostanza; conservare i dati originali.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Rappresentatività e distorsioni", "Un dataset può essere pulito e corretto e tuttavia non rappresentare il fenomeno da analizzare. È un problema generale dell'analisi dei dati, non specifico dell'AI, ma conviene conoscerlo perché l'AI analizza i dati che riceve. Alcuni casi tipici. Un questionario compilato solo da chi ha voluto rispondere: rappresenta i clienti più motivati. I dati di un solo canale estesi a tutti i clienti. I dati di un periodo particolare, come una promozione o una crisi, trattati come normali. I dati dei soli clienti attuali, che escludono quelli persi: si perde proprio l'informazione sul perché se ne sono andati; è la distorsione da sopravvivenza. La buona notizia è che l'AI può aiutare anche qui, se glielo si chiede: 'chi o che cosa manca in questi dati? Come potrebbe cambiare la conclusione?' Spesso le risposte indicano domande da porre a chi conosce la raccolta dei dati. Nel caso delle vendite, per esempio, conviene chiedersi se gli ordini online sono registrati nella regione del cliente o in un'altra: lo vedremo nel 9.4.");
    phaseTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMessageSquare", head: "Chi ha scelto di rispondere", body: "Questionari volontari: i più motivati" },
      { icon: "FiShoppingCart", head: "Un solo canale", body: "Conclusioni estese a tutti i clienti" },
      { icon: "FiCalendar", head: "Un periodo particolare", body: "Promozioni o crisi trattate come normali" },
      { icon: "FiUserX", head: "Solo chi è rimasto", body: "Distorsione da sopravvivenza: mancano i clienti persi" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Pratica utile: chiedere all'AI chi o che cosa manca in questi dati, e come potrebbe cambiare la conclusione.", { h: 0.7, fontSize: 13 });
    txt(s, "Un dataset pulito e corretto può comunque non rappresentare il fenomeno.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Definizioni e indicatori", "Questa slide riunisce due aspetti: dati, metriche e indicatori, e le definizioni e la provenienza che li rendono confrontabili. Il dato è il valore registrato: l'ordine 4471 del 12 settembre, 1.180 euro. La metrica è una misura calcolata con una regola: il valore medio dell'ordine nel terzo trimestre, 1.240 euro, cioè 3.752 mila euro di fatturato netto diviso 3.026 ordini. L'indicatore, o KPI, è una metrica scelta per un obiettivo, con un riferimento: 1.240 euro contro l'obiettivo di 1.300. Ogni passaggio comporta scelte: la formula, per esempio se includere le spese di spedizione, e che cosa conta come buon risultato. Le definizioni spesso non sono scritte nel file: un 'cliente attivo' ha acquistato negli ultimi dodici mesi o negli ultimi sei? Il fatturato è al netto dei resi? Gli ordini annullati sono inclusi? E la provenienza: da quale sistema, quando, con quali filtri e trasformazioni, chi può confermarlo. La pratica che fa la differenza: indicare all'AI definizioni e provenienza nella richiesta. Così il sistema non ne usa di plausibili ma diverse, e i risultati diventano confrontabili con i report ufficiali. Dove le informazioni mancano, è un'incertezza da dichiarare.");
    phaseTag(s, 0);
    const lv = [["Dato", "Il valore registrato", "Ordine 4471, 12 settembre, 1.180 €"], ["Metrica", "Misura calcolata con una regola", "Valore medio dell'ordine Q3: 1.240 €"], ["Indicatore", "Metrica scelta per un obiettivo", "1.240 € contro l'obiettivo di 1.300 €"]];
    lv.forEach((l, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.12, 2.86, 1.45, i === 2 ? C.accent1 : (i ? C.accent6 : C.background2), l[0]);
      const fc = i === 2 ? C.background1 : C.text1;
      txt(s, l[0], { x: x + 0.15, y: 1.18, w: 2.56, h: 0.4, fontSize: 17, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, l[1], { x: x + 0.15, y: 1.58, w: 2.56, h: 0.35, fontSize: 12, bold: true, color: fc });
      txt(s, l[2], { x: x + 0.15, y: 1.95, w: 2.56, h: 0.55, fontSize: 12, italic: true, color: fc });
      if (i < 2) arrow(s, x + 2.88, 1.68, 0.17);
    });
    docBox(s, 0.5, 2.75, 4.35, 1.2, "Definizioni", "'Cliente attivo': 12 mesi o 6? 'Fatturato': al netto dei resi? 'Ordine': inclusi gli annullati?", { fontSize: 12 });
    docBox(s, 5.15, 2.75, 4.35, 1.2, "Provenienza", "Da quale sistema, quando, con quali filtri e trasformazioni; chi può confermarlo.", { fontSize: 12, fill: C.accent6 });
    banner(s, 4.12, "Indicare all'AI definizioni e provenienza nella richiesta: i risultati diventano confrontabili con i report ufficiali.", { h: 0.8, fontSize: 13 });
  }

  // =====================================================================
  section("9.3 Elaborazione");
  divider("9.3", "Elaborazione e analisi quantitativa", "L'AI calcola indicatori e statistiche a partire da richieste in linguaggio naturale; metodo, dati e passaggi dichiarati rendono affidabile il risultato", "Con i dati compresi e preparati, passiamo all'elaborazione: calcoli, aggregazioni, indicatori, confronti, statistiche descrittive. È l'area in cui l'AI rende accessibili a tutti operazioni che prima richiedevano formule, tabelle pivot o codice. Vediamo come una richiesta in parole diventa un'operazione, alcune attenzioni su percentuali e medie che valgono per qualsiasi analisi, le formule e il codice generati dall'AI, e una distinzione centrale: un calcolo eseguito con uno strumento e un numero generato come testo hanno lo stesso aspetto, ma un'affidabilità diversa. Chiudiamo con la tracciabilità, che rende un risultato ripetibile e verificabile. Il concetto chiave: metodo, dati e passaggi di elaborazione sono determinanti per l'affidabilità di un risultato numerico. Esercizio suggerito: incollare in una conversazione una tabella fittizia di una trentina di righe e chiedere totale e media; poi caricare lo stesso file in uno strumento che esegue codice, chiedere di usarlo, e confrontare entrambi i risultati con un foglio di calcolo.");
  {
    const s = content("Le operazioni tipiche", "Le operazioni quantitative più comuni sono poche, e l'AI le esegue tutte partendo da una richiesta in linguaggio naturale. La tabella associa alcune richieste realistiche, sul caso delle vendite, all'operazione eseguita. 'Qual è il margine di ogni ordine?' è un calcolo sulle righe, prezzo meno costo. 'Quanto abbiamo fatturato nel terzo trimestre?' è un'aggregazione, una somma. 'Fatturato per regione e mese' è un raggruppamento, ciò che nei fogli di calcolo si fa con una tabella pivot. 'Tasso di reso per prodotto' è un indicatore, un rapporto. 'Come va il Centro rispetto al 2024?' è un confronto tra periodi. Per chi non usa formule o codice è un cambiamento sostanziale: basta descrivere che cosa si vuole sapere. Ogni operazione comporta però una scelta, indicata nell'ultima colonna: il costo include il trasporto? Il fatturato è lordo o netto? I resi si contano sugli ordini o sui pezzi? Le scelte, più che l'aritmetica, determinano il risultato. La pratica: chiedere all'AI di dichiararle insieme al risultato, o inserirle direttamente nella richiesta.");
    phaseTag(s, 1);
    table(s, [["Richiesta in linguaggio naturale", "Operazione eseguita", "Scelta da dichiarare"],
      ["\"Qual è il margine di ogni ordine?\"", "Calcolo sulle righe", "Costo con o senza trasporto?"],
      ["\"Quanto abbiamo fatturato nel Q3?\"", "Aggregazione (somma)", "Lordo o netto di resi?"],
      ["\"Fatturato per regione e mese\"", "Raggruppamento (pivot)", "Ordini annullati inclusi?"],
      ["\"Tasso di reso per prodotto\"", "Indicatore (rapporto)", "Su ordini o su pezzi?"],
      ["\"Il Centro rispetto al 2024?\"", "Confronto tra periodi", "Stesso trimestre o mese prima?"]],
      { y: 1.12, colW: [3.6, 2.5, 2.9], rowH: 0.47, fontSize: 11, blankCorner: false, accentCol: 1 });
    banner(s, 4.12, "Operazioni semplici, richieste a parole. Il risultato è più utile se l'AI dichiara insieme le scelte fatte.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Percentuali, rapporti, variazioni", "Gli indicatori relativi sono i più usati e anche i più fraintesi, con o senza AI. Tre attenzioni. La base: 'il 30 per cento dei reclami riguarda le consegne' e 'il 30 per cento delle consegne genera reclami' sono affermazioni molto diverse, e una richiesta vaga può produrre l'una o l'altra. Le basi piccole: passare da 2 a 6 reclami è più 200 per cento, ma riguarda quattro casi; conviene affiancare sempre i valori assoluti. Il periodo di confronto: rispetto al mese precedente pesa la stagionalità, rispetto allo stesso periodo dell'anno prima il confronto è di solito più significativo; e il periodo scelto può cambiare la conclusione. Nel caso delle vendite abbiamo confrontato il terzo trimestre 2025 con il terzo trimestre 2024 proprio per questo. Con l'AI queste attenzioni diventano facili da applicare: basta chiedere formula, base e periodo, e i valori assoluti accanto alle percentuali. Sono dettagli che, specificati una volta in un prompt, si riutilizzano per tutte le analisi successive.");
    phaseTag(s, 1);
    const at = [["Percentuale di che cosa?", "'30% dei reclami riguarda le consegne' non è '30% delle consegne genera reclami'"], ["Basi piccole", "Da 2 a 6 reclami: +200%, ma sono quattro casi. Affiancare i valori assoluti"], ["Periodo di confronto", "Sul mese precedente pesa la stagionalità; sullo stesso periodo dell'anno prima, di solito, è più significativo"]];
    at.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.85, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.9, h: 0.85, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.6, y, w: 5.7, h: 0.85, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 4.1, "Pratica utile: chiedere formula, base e periodo, e i valori assoluti accanto alle percentuali.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Statistiche descrittive di base", "L'analisi descrittiva riassume i dati con poche misure, che conviene conoscere anche senza essere statistici. Misure di posizione: la media, cioè la somma divisa per il numero dei valori; la mediana, cioè il valore centrale. Misure di dispersione: minimo, massimo, deviazione standard. L'esempio fittizio in slide: il valore degli ordini di dieci clienti. Nove sono tra 1.100 e 1.900 euro, uno arriva a 20.000. La somma è 33.100 euro, quindi la media è 3.310 euro, ma nessun cliente reale si avvicina a quel valore. La mediana, la media dei due valori centrali 1.400 e 1.500, è 1.450 euro e descrive meglio il cliente tipico. Quando i dati sono asimmetrici, come accade spesso con importi, redditi e tempi, la media da sola è fuorviante. È un principio statistico generale; l'AI aiuta ad applicarlo, perché calcola in un istante tutte le misure. Se si chiede 'qual è il valore tipico degli ordini?', il sistema può rispondere con la media, la misura più comune: conviene chiedere media e mediana insieme, e un'indicazione della dispersione.");
    phaseTag(s, 1);
    s.addChart(pres.charts.BAR, [{ name: "Valore ordini (€)", labels: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "L"], values: [1100, 1200, 1300, 1400, 1400, 1500, 1600, 1700, 1900, 20000] }], {
      x: 0.5, y: 1.1, w: 5.4, h: 3.0, barDir: "col", chartColors: [HEX.a1], valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 9, catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 10,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 21000, barGapWidthPct: 40, valAxisLabelFormatCode: "#,##0",
      showTitle: true, title: "Valore degli ordini di dieci clienti, in euro (esempio fittizio)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt", catAxisLabelFontFace: "+mn-lt",
    });
    shapeBox(s, 6.15, 1.15, 3.35, 1.3, C.background2, "media");
    txt(s, "Media", { x: 6.35, y: 1.22, w: 3.0, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    txt(s, "3.310 €", { x: 6.35, y: 1.55, w: 3.0, h: 0.45, fontSize: 24, bold: true, color: C.text1 });
    txt(s, "Nessun cliente reale vicino", { x: 6.35, y: 2.02, w: 3.0, h: 0.35, fontSize: 11, color: C.text2 });
    shapeBox(s, 6.15, 2.6, 3.35, 1.3, C.accent6, "mediana");
    txt(s, "Mediana", { x: 6.35, y: 2.67, w: 3.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
    txt(s, "1.450 €", { x: 6.35, y: 3.0, w: 3.0, h: 0.45, fontSize: 24, bold: true, color: C.text1 });
    txt(s, "Descrive il cliente tipico", { x: 6.35, y: 3.47, w: 3.0, h: 0.35, fontSize: 11, color: C.text2 });
    banner(s, 4.3, "Pratica utile: chiedere media e mediana insieme. Se sono molto diverse, ci sono valori estremi da guardare.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Le statistiche non bastano", "Un esempio classico mostra perché le misure di sintesi, da sole, non bastano. Nel 1973 lo statistico Francis Anscombe costruì quattro piccoli insiemi di dati, noti come quartetto di Anscombe, con praticamente le stesse statistiche: media di x pari a 9, media di y circa 7,5, stessa varianza, correlazione circa 0,82 e stessa retta di regressione. Ma i grafici mostrano situazioni completamente diverse: una relazione lineare con un po' di variabilità; una curva; una relazione lineare quasi perfetta alterata da un solo valore anomalo; e nessuna relazione, con tutti i valori di x uguali tranne uno, che da solo crea la correlazione. Anche qui si tratta di un principio generale della statistica. Per chi usa l'AI la buona pratica è economica: insieme alla sintesi statistica, chiedere un grafico dei dati. Con l'AI costa una riga di richiesta, e permette di vedere subito se medie e correlazioni descrivono bene la situazione.");
    phaseTag(s, 1);
    const x = [10, 8, 13, 9, 11, 14, 6, 4, 12, 7, 5], x4 = [8, 8, 8, 8, 8, 8, 8, 19, 8, 8, 8];
    const ys = [[8.04, 6.95, 7.58, 8.81, 8.33, 9.96, 7.24, 4.26, 10.84, 4.82, 5.68], [9.14, 8.14, 8.74, 8.77, 9.26, 8.10, 6.13, 3.10, 9.13, 7.26, 4.74], [7.46, 6.77, 12.74, 7.11, 7.81, 8.84, 6.08, 5.39, 8.15, 6.42, 5.73], [6.58, 5.76, 7.71, 8.84, 8.47, 7.04, 5.25, 12.50, 5.56, 7.91, 6.89]];
    for (let i = 0; i < 4; i++) {
      scatter(s, i === 3 ? x4 : x, ys[i], { x: 0.5 + i * 2.27, y: 1.1, w: 2.2, h: 2.2, xmin: 2, xmax: 20, ymin: 2, ymax: 14, title: "Insieme " + (i + 1), size: 5 });
    }
    shapeBox(s, 0.5, 3.45, 9.0, 0.6, C.background2, "statistiche");
    txt(s, "Per tutti e quattro:  media x = 9   ·   media y ≈ 7,5   ·   correlazione ≈ 0,82   ·   stessa retta di regressione", { x: 0.7, y: 3.45, w: 8.6, h: 0.6, fontSize: 13, bold: true, color: C.text1, valign: "middle", align: "center" });
    banner(s, 4.2, "Pratica utile: insieme alla sintesi statistica, chiedere un grafico dei dati. Costa una riga di richiesta.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Formule e codice generati dall'AI", "Uno degli usi più utili dell'AI con i dati: generare strumenti di calcolo, cioè formule per i fogli di calcolo o codice in linguaggi come Python o SQL. Si descrive ciò che si vuole, per esempio 'una formula che calcoli i giorni lavorativi tra la data dell'ordine in colonna B e la data di consegna in colonna C', e si ottiene la formula pronta: =GIORNI.LAVORATIVI.TOT(B2;C2). Per chi non conosce le funzioni è una porta d'accesso a elaborazioni prima difficili; per chi le conosce è un acceleratore. Il vantaggio fondamentale: il calcolo lo esegue il foglio di calcolo, in modo deterministico, e la formula resta visibile e controllabile. Come per qualsiasi formula, conviene controllare la logica: l'intervallo copre tutti i dati? Include le righe di totale? Considera le festività? La funzione, per esempio, conta i giorni di inizio e fine compresi e accetta un elenco di festività come terzo argomento. La pratica: provare la formula su pochi casi di cui si conosce il risultato, e chiedere all'AI di spiegarla passo per passo. La programmazione analitica complessa è solo da accennare.");
    phaseTag(s, 1);
    docBox(s, 0.5, 1.15, 5.0, 1.0, "Richiesta", "Una formula che calcoli i giorni lavorativi tra la data dell'ordine (colonna B) e la data di consegna (colonna C).", { fontSize: 12 });
    promptBox(s, 0.5, 2.3, 5.0, 0.85, "=GIORNI.LAVORATIVI.TOT(B2;C2)", { label: "Formula generata", fontSize: 13 });
    await card(s, 5.75, 1.15, 3.75, 2.0, { icon: "FiCheckCircle", inline: true, head: "Il vantaggio", headSize: 14, bodySize: 12, fill: C.accent6,
      body: "La formula arriva pronta; il calcolo lo esegue il foglio, e resta visibile e controllabile." });
    txt(s, "Da controllare nella logica, come per qualsiasi formula", { x: 0.5, y: 3.3, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
    chip(s, 0.5, 3.7, 2.9, 0.55, "L'intervallo copre tutti i dati?", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.7, 2.9, 0.55, "Include le righe di totale?", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.7, 2.9, 0.55, "Considera le festività?", { fill: C.background2, fontSize: 12 });
    txt(s, "Pratica utile: provarla su pochi casi di risultato noto, e chiederne la spiegazione passo per passo.", { x: 0.5, y: 4.45, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Calcolo eseguito o numero generato", "La distinzione più importante del sottotema. Un modello linguistico, quando produce un numero senza usare uno strumento di calcolo, lo genera come qualsiasi altra parola: è plausibile, spesso giusto su operazioni semplici, ma diventa poco affidabile con molti dati, calcoli complessi o numeri grandi. Molti ambienti AI attuali, invece, quando ricevono un file scrivono ed eseguono codice o usano strumenti di calcolo: è il modo di lavorare che conviene preferire per l'analisi dei dati. Il calcolo è effettivo, i passaggi e i valori intermedi sono visibili, e il risultato è ripetibile: stesso codice e stessi dati, stesso risultato. Non tutti gli strumenti hanno questa capacità, e non sempre la usano se non glielo si chiede: conviene verificarlo sullo strumento autorizzato. Come riconoscere un calcolo eseguito: il codice o lo strumento usato sono indicati; ci sono risultati intermedi; i numeri del commento coincidono con quelli dell'output; le righe elaborate corrispondono a quelle del file. Una precisazione da tenere a mente: ripetibile non significa corretto. Se il filtro esclude le righe sbagliate o la definizione di fatturato non è quella aziendale, il codice ripete lo stesso errore ogni volta. L'esecuzione rende il calcolo verificabile; filtri, definizioni e logica restano da controllare. Primo controllo rapido: l'ordine di grandezza, per esempio una media per cliente superiore al totale.");
    phaseTag(s, 1);
    await card(s, 0.5, 1.12, 4.35, 2.05, { icon: "FiMessageSquare", head: "Numero generato come testo", headSize: 15, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Prodotto parola dopo parola", "Spesso giusto su operazioni semplici", "Poco affidabile su molti dati o calcoli complessi"], { space: 4 }) });
    await card(s, 5.15, 1.12, 4.35, 2.05, { icon: "FiCpu", head: "Calcolo eseguito con strumenti", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Codice o formule eseguiti sui dati", "Ripetibile: stessi dati, stesso risultato", "Passaggi e valori intermedi controllabili"], { space: 4 }) });
    txt(s, "Come riconoscerlo", { x: 0.5, y: 3.28, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const sg = ["Codice o strumento indicato", "Valori intermedi visibili", "Commento uguale all'output", "Righe elaborate = righe del file"];
    sg.forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.6, 2.15, 0.5, t, { fill: C.background2, fontSize: 11 }));
    banner(s, 4.25, "L'esecuzione rende il calcolo ripetibile e verificabile, non corretto per definizione: filtri, definizioni e logica restano da controllare.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Tracciabilità delle operazioni", "La tracciabilità è la possibilità di ricostruire come si è arrivati a un risultato. Il registro in slide, ancora sul caso fittizio, è ciò che conviene chiedere all'AI per le analisi importanti: file di partenza e righe, ordini annullati esclusi, duplicati rimossi, righe senza regione escluse, definizione degli importi, raggruppamento, formula della variazione, codice salvato con il report. Sono gli stessi numeri del piano di pulizia del 9.2, e restano 12.109 righe analizzate. Molti strumenti che eseguono codice permettono di ottenerlo con una sola richiesta, per esempio 'elenca le operazioni eseguite, con il numero di righe coinvolte'. La tracciabilità serve a quattro cose: verificare, perché chi controlla ripercorre i passaggi; ripetere, perché la stessa analisi sul mese successivo dà risultati confrontabili; spiegare, perché chi riceve il risultato ne capisce significato e limiti; correggere, perché se emerge un errore nei dati si sa che cosa ne è influenzato. Un buon registro risponde a quattro domande: da quali dati, con quali elaborazioni, su quali ipotesi, per quali conclusioni. Senza traccia, un'analisi serve a esplorare; con la traccia, può sostenere decisioni rilevanti. Senza tracciabilità l'unico controllo è rifare tutto; con la tracciabilità si controllano i punti critici.");
    phaseTag(s, 1);
    promptBox(s, 0.5, 1.12, 5.6, 2.95, "1. File: vendite_2025.xlsx (12.480 righe)\n2. Esclusi ordini annullati: 312 righe\n3. Rimossi duplicati: 41 righe\n4. Righe senza regione (18): escluse\n5. Importi: netti di IVA e resi\n6. Raggruppamento per regione e trimestre\n7. Variazione = Q3 2025 / Q3 2024 - 1\n8. Codice salvato con il report", { label: "Registro delle operazioni (esempio fittizio)", fontSize: 11 });
    const u = [["Verificare", "Ripercorrere i passaggi"], ["Ripetere", "Risultati confrontabili nel tempo"], ["Spiegare", "Significato e limiti"], ["Correggere", "Sapere che cosa è influenzato"]];
    u.forEach((e, i) => {
      const y = 1.12 + i * 0.75;
      shapeBox(s, 6.35, y, 3.15, 0.65, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.04, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.33, w: 2.9, h: 0.28, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.22, "Un buon registro dice da quali dati, con quali elaborazioni, su quali ipotesi, per quali conclusioni. Senza traccia si esplora; con la traccia si decide.", { h: 0.75, fontSize: 12 });
  }

  // =====================================================================
  section("9.4 Pattern e tendenze");
  divider("9.4", "Pattern, tendenze e anomalie", "L'AI esplora rapidamente andamenti, anomalie e relazioni e propone ipotesi da verificare; una relazione nei dati non prova da sola un nesso causale", "Dai calcoli ai fenomeni: andamenti nel tempo, schemi che si ripetono, anomalie, relazioni tra variabili. È uno degli usi più promettenti dell'AI, che esplora in pochi minuti molte combinazioni e segnala ciò che merita attenzione: un lavoro che a mano richiederebbe molte tabelle. Vediamo tendenza e stagionalità, un esempio di scostamento sul caso delle vendite, le correlazioni e come leggerle, e un metodo per passare dall'osservazione a un'interpretazione solida. Il concetto chiave del sottotema: individuare una relazione nei dati non prova automaticamente un nesso causale. Il modo più produttivo di usare l'AI qui è come generatore e verificatore di ipotesi. Esercizio suggerito: presentare una correlazione fittizia trovata dall'AI con il suo commento causale, e chiedere ai partecipanti almeno tre spiegazioni alternative e, per ciascuna, il dato che permetterebbe di verificarla.");
  {
    const s = content("Andamenti nel tempo", "L'analisi degli andamenti temporali è tra le più comuni: vendite, costi, reclami, assenze nel tempo. Un andamento osservato combina di solito tre componenti. La tendenza di fondo: la direzione di lungo periodo. La stagionalità: oscillazioni regolari, come il picco di fine anno o il calo di agosto. Le variazioni irregolari: casuali o dovute a eventi. Il grafico fittizio mostra tre anni di vendite mensili, con una crescita moderata, una forte stagionalità con picchi a fine anno e piccole irregolarità. L'AI può separare queste componenti e descriverle in poche righe, e confrontare automaticamente ogni mese con lo stesso mese dell'anno prima. Due errori tipici, di qualsiasi analisi: leggere la stagionalità come tendenza, per esempio il calo di gennaio rispetto a dicembre che si ripete ogni anno, e dichiarare una tendenza a partire da pochi punti: tre mesi di crescita non fanno un trend. La pratica utile, facile da chiedere all'AI: confronti con lo stesso periodo dell'anno precedente e scomposizione in tendenza e stagionalità.");
    phaseTag(s, 1);
    const lab = [], v = [];
    const base = [80, 78, 85, 88, 90, 87, 82, 70, 92, 98, 115, 135];
    for (let y = 0; y < 3; y++) for (let m = 0; m < 12; m++) { lab.push(m === 0 ? String(2023 + y) : ""); v.push(Math.round(base[m] * (1 + 0.08 * y) + ((m * 7 + y * 3) % 5) - 2)); }
    lineChart(s, lab, [{ name: "Vendite mensili", values: v }], { x: 0.5, y: 1.1, w: 6.0, h: 3.0, min: 60, max: 160, title: "Vendite mensili in migliaia di pezzi, tre anni (esempio fittizio)" });
    const c = [["Tendenza", "Direzione di lungo periodo"], ["Stagionalità", "Oscillazioni regolari, come il picco di fine anno"], ["Irregolari", "Casuali o dovute a eventi"]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 6.75, y, 2.75, 0.85, i === 1 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.9, y: y + 0.06, w: 2.5, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.9, y: y + 0.4, w: 2.5, h: 0.4, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.3, "Pratica utile: confrontare con lo stesso periodo dell'anno prima e chiedere di separare tendenza e stagionalità. Pochi punti non fanno un trend.", { h: 0.68, fontSize: 12 });
  }
  {
    const s = content("Anomalie e scostamenti", "Un esempio di valore aziendale, sul caso fittizio. Il grafico mostra il fatturato netto mensile della regione Centro, gennaio-settembre, nel 2024 e nel 2025. L'AI, a cui si è chiesto di confrontare ogni mese con l'anno prima e di segnalare gli scostamenti rilevanti, evidenzia settembre: 320 mila euro contro 430, cioè 110 mila euro e il 26 per cento in meno. Sugli altri mesi del trimestre lo scarto è piccolo: meno 20 a luglio, meno 8 ad agosto. Uno scostamento così merita un approfondimento, e qui l'AI è utile due volte: propone le ipotesi e, per ciascuna, la verifica possibile nei dati. Un cliente principale ha ordinato meno? Si guarda il fatturato per cliente. Ordini spostati sul canale online e registrati in un'altra regione? Si guardano canale e regione degli ordini. Ordini sospesi non ancora fatturati? Si guarda la colonna Stato. Un concorrente nell'area? Questo nei dati non c'è: lo sa il responsabile di zona. Nell'esempio, la scomposizione per cliente mostra che il calo di settembre coincide con un solo cliente principale. In pochi passaggi uno scostamento diventa una domanda precisa per chi segue quel cliente. Due attenzioni: anomalo non significa sbagliato, quindi non va eliminato in automatico; e conviene chiedere con quale criterio un valore è stato definito anomalo.");
    phaseTag(s, 1);
    lineChart(s, ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set"], [{ name: "2024", values: [380, 360, 400, 390, 410, 400, 420, 300, 430], color: HEX.a2 }, { name: "2025", values: [390, 370, 405, 400, 415, 410, 400, 292, 320], color: HEX.a1 }], { x: 0.5, y: 1.1, w: 5.0, h: 2.75, min: 0, max: 500, symbol: "circle", legend: true, title: "Regione Centro, fatturato netto mensile (k€, esempio fittizio)" });
    shapeBox(s, 5.7, 1.12, 3.8, 2.73, C.background2, "ipotesi e verifiche");
    txt(s, "Settembre: -110 k€ (-26%)", { x: 5.85, y: 1.18, w: 3.5, h: 0.33, fontSize: 13, bold: true, color: C.accent5 });
    const hv = [["Un cliente principale ha ordinato meno", "fatturato per cliente"], ["Ordini online registrati altrove", "canale e regione"], ["Ordini sospesi non fatturati", "colonna Stato"], ["Un concorrente nell'area", "responsabile di zona"]];
    hv.forEach((e, i) => {
      txt(s, [{ text: e[0], options: { bold: true, color: C.text1, breakLine: true } }, { text: "Verifica: " + e[1], options: { color: C.accent1 } }], { x: 5.85, y: 1.55 + i * 0.56, w: 3.5, h: 0.52, fontSize: 10.5 });
    });
    banner(s, 4.02, "Esito: il calo di settembre coincide con un solo cliente principale. In pochi passaggi lo scostamento diventa una domanda precisa per chi lo segue.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Relazioni e correlazioni", "Il confronto tra variabili cerca relazioni: quando una cresce, l'altra cresce o cala? La misura più comune è la correlazione, un numero tra meno uno e più uno che indica quanto due variabili variano insieme in modo lineare. Il grafico fittizio mostra visite commerciali e fatturato di venti clienti: una correlazione positiva evidente. L'AI calcola le correlazioni tra molte variabili in pochi secondi e segnala le più forti: è un ottimo punto di partenza per l'esplorazione. Tre cose da sapere per leggerle bene. La correlazione misura solo relazioni lineari: un legame curvo può avere correlazione bassa, come nel secondo insieme di Anscombe. È sensibile ai valori anomali: un solo punto può crearla o cancellarla, come nel quarto insieme. E non indica né la direzione né la causa: le visite producono fatturato, o i clienti con più fatturato ricevono più visite? Lo vediamo nella prossima slide.");
    phaseTag(s, 1);
    const vx = [2, 3, 3, 4, 5, 5, 6, 6, 7, 8, 8, 9, 10, 10, 11, 12, 13, 14, 15, 16];
    const vy = [18, 22, 30, 26, 35, 41, 38, 47, 44, 52, 58, 55, 63, 70, 66, 74, 80, 78, 90, 94];
    scatter(s, vx, vy, { x: 0.5, y: 1.1, w: 5.0, h: 3.0, xmin: 0, xmax: 18, ymin: 0, ymax: 100, title: "Visite commerciali (x) e fatturato in k€ (y), 20 clienti fittizi", size: 7 });
    const c = [["Solo relazioni lineari", "Legami curvi possono avere correlazione bassa"], ["Sensibile agli anomali", "Un punto può crearla o cancellarla"], ["Né direzione né causa", "Visite che producono fatturato, o il contrario?"]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.98;
      shapeBox(s, 5.75, y, 3.75, 0.88, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 5.9, y: y + 0.06, w: 3.5, h: 0.32, fontSize: 13, bold: true, color: i === 2 ? C.accent5 : C.accent1 });
      txt(s, e[1], { x: 5.9, y: y + 0.4, w: 3.5, h: 0.42, fontSize: 11, color: C.text2 });
    });
    txt(s, "La correlazione va da -1 a +1 e misura quanto due variabili variano insieme in modo lineare.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Correlazione e causalità", "Questa slide riunisce correlazione, causalità e conclusioni errate da dati corretti. Una correlazione può avere spiegazioni diverse da un nesso causale. Causalità inversa: i clienti grandi ricevono più visite perché sono importanti, non il contrario. Terzo fattore: le filiali con più formazione e meno assenze hanno anche un responsabile più attento, che spiega entrambe le cose. Selezione: alla formazione partecipa chi era già più motivato. Coincidenza: con pochi dati, una correlazione può essere casuale. A destra un esempio fittizio di dati corretti e conclusione infondata: i clienti che usano l'app spendono in media il 40 per cento in più; la conclusione 'spingere tutti a usare l'app aumenterà la spesa del 40 per cento' non regge, perché chi usa l'app è forse già più fedele, chi viene spinto può comportarsi diversamente, e una differenza tra gruppi non è l'effetto di un intervento. Un'altra attenzione: se si chiede di 'trovare relazioni interessanti' tra molte variabili, alcune correlazioni forti emergono per puro caso; con 50 variabili si fanno 1.225 confronti. Esistono raccolte celebri di correlazioni assurde, come quella di Tyler Vigen. La pratica: partire da domande precise, chiedere all'AI spiegazioni alternative e quali dati le distinguerebbero, verificare la relazione su un altro periodo o gruppo. Per avvicinarsi a una prova causale servono confronti controllati, metodi specialistici da accennare soltanto.");
    phaseTag(s, 1);
    await iconGrid(s, [
      { icon: "FiRepeat", head: "Causalità inversa", body: "I clienti grandi ricevono più visite" },
      { icon: "FiShare2", head: "Terzo fattore", body: "Un fattore comune spiega entrambi" },
      { icon: "FiFilter", head: "Selezione", body: "Partecipa chi era già motivato" },
      { icon: "FiShuffle", head: "Coincidenza", body: "Con pochi dati, può essere caso" },
    ], 2, { x: 0.5, w: 4.45, y: 1.12, H: 2.75, gap: 0.15, headSize: 12, bodySize: 11 });
    docBox(s, 5.15, 1.12, 4.35, 0.85, "Dato corretto (esempio fittizio)", "Chi usa l'app spende in media il 40% in più.", { fontSize: 12, fill: C.accent6 });
    docBox(s, 5.15, 2.07, 4.35, 0.85, "Conclusione da non trarre", "Spingere tutti a usare l'app aumenterà la spesa del 40%.", { fontSize: 12, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Chi usa l'app è forse già più fedele: una differenza tra gruppi non è l'effetto di un intervento.", { x: 5.15, y: 3.05, w: 4.35, h: 0.8, fontSize: 12, italic: true, color: C.text2 });
    banner(s, 4.02, "Una correlazione trovata dall'AI è un'ipotesi: chiedere spiegazioni alternative e quali dati le distinguono. Tra molte variabili, alcune relazioni forti emergono per caso.", { h: 0.9, fontSize: 12 });
  }
  {
    const s = content("Verificare le ipotesi", "Come si passa da un fenomeno osservato a un'interpretazione solida? Un metodo in cinque passaggi, che l'AI rende rapido. Primo, descrivere il fenomeno senza interpretarlo: che cosa si osserva, con quali numeri, su quali dati e in quale periodo. Secondo, formulare più ipotesi, non una sola: l'AI le genera in pochi secondi, come abbiamo visto con lo scostamento di settembre. Terzo, per ciascuna ipotesi, chiedersi che cosa dovremmo osservare se fosse vera: se il calo dipende da un cliente, dovrebbe concentrarsi su quel cliente; se dipende dal canale online, dovrebbe comparire un aumento altrove. Quarto, controllare quelle conseguenze nei dati, con analisi mirate che l'AI esegue rapidamente, o con altre informazioni, come una telefonata al responsabile di zona. Quinto, dichiarare il livello di certezza: confermata, probabile, possibile. Usata così, l'AI non è un generatore di conclusioni ma uno strumento per esplorare e verificare ipotesi: l'uso più utile e più solido nell'analisi.");
    phaseTag(s, 1);
    numList(s, ["Descrivere il fenomeno senza interpretarlo", "Formulare più ipotesi, non una sola: l'AI aiuta a generarle", "Per ciascuna: che cosa dovremmo osservare se fosse vera?", "Controllare quelle conseguenze nei dati o con altre informazioni", "Dichiarare il livello di certezza: confermata, probabile, possibile"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "Usata così, l'AI è uno strumento per generare e verificare ipotesi: l'uso più utile e più solido nell'analisi.", { h: 0.65, fontSize: 13 });
  }

  // =====================================================================
  section("9.5 Visualizzazione");
  divider("9.5", "Visualizzazione e comunicazione dei risultati", "L'AI produce in pochi minuti grafici, tabelle e report chiari; una comunicazione efficace è utile quando poggia su dati e conclusioni validi", "Un'analisi serve se qualcuno la capisce e la usa. In questo sottotema vediamo che cosa l'AI può produrre, con esempi concreti, come aiuta a scegliere la rappresentazione e a migliorare titoli ed etichette, come rendere un grafico chiaro e onesto, come comunicare i risultati in modo comprensibile, e chiudiamo con cinque prompt pronti per l'intero processo di analisi. Il concetto chiave: una rappresentazione persuasiva non garantisce la validità dei dati né delle conclusioni. Con l'AI ottenere una comunicazione curata è facile; perché sia anche corretta servono dati e interpretazioni fondati. Esercizio suggerito: dare ai partecipanti un piccolo dataset fittizio e chiedere all'AI due grafici degli stessi dati che comunichino messaggi opposti, poi chiedere di migliorarli e discutere quale sia la rappresentazione più onesta.");
  {
    const s = content("Che cosa può produrre l'AI", "Quattro esempi concreti, tutti costruiti sul caso fittizio delle vendite e coerenti tra loro. Un grafico: il fatturato netto del terzo trimestre 2025 per regione, con le etichette dei valori. Una tabella riepilogativa: regione, fatturato e variazione sull'anno prima. Una dashboard: pochi indicatori in una schermata, qui fatturato del trimestre, numero di ordini e valore medio dell'ordine; 3.752 mila euro divisi per 3.026 ordini fanno circa 1.240 euro. Un report sintetico: un titolo che dice il messaggio e tre righe di commento. Il valore principale è la velocità e la possibilità di provare più rappresentazioni prima di scegliere; i tempi effettivi dipendono da strumento e dati. Il controllo che resta utile è semplice: verificare che i numeri del commento coincidano con quelli di tabella e grafico. Lo vedremo nelle prossime slide.");
    phaseTag(s, 2);
    const P = [[0.5, 1.12, "Grafico"], [5.1, 1.12, "Tabella riepilogativa"], [0.5, 2.72, "Dashboard"], [5.1, 2.72, "Report sintetico"]];
    P.forEach((p, i) => {
      shapeBox(s, p[0], p[1], 4.4, 1.5, i % 3 === 0 ? C.background2 : C.accent6, "esempio " + p[2]);
      txt(s, p[2], { x: p[0] + 0.15, y: p[1] + 0.06, w: 4.1, h: 0.26, fontSize: 11, bold: true, color: C.accent1 });
    });
    s.addChart(pres.charts.BAR, [{ name: "Q3 2025 (k€)", labels: ["Nord", "Centro", "Sud"], values: [1950, 1012, 790] }], {
      x: 0.6, y: 1.36, w: 4.2, h: 1.22, barDir: "bar", chartColors: [HEX.a1], showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 9, dataLabelColor: HEX.dk1, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "#,##0",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 9, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 2400,
      valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false, barGapWidthPct: 45,
    });
    table(s, [["Regione", "Q3 2025 (k€)", "Var. sul 2024"], ["Nord", "1.950", "+6,0%"], ["Centro", "1.012", "-12,0%"], ["Sud", "790", "+3,9%"]],
      { x: 5.25, y: 1.4, w: 4.1, colW: [1.2, 1.45, 1.45], rowH: 0.26, fontSize: 9, blankCorner: false, accentCol: 2 });
    const k = [["3.752 k€", "Fatturato netto Q3"], ["3.026", "Ordini Q3"], ["1.240 €", "Valore medio ordine"]];
    k.forEach((e, i) => {
      const x = 0.65 + i * 1.38;
      shapeBox(s, x, 3.05, 1.28, 1.05, C.background1, "indicatore " + e[1]);
      txt(s, e[0], { x, y: 3.12, w: 1.28, h: 0.45, fontSize: 15, bold: true, color: C.accent1, align: "center", valign: "middle" });
      txt(s, e[1], { x: x + 0.05, y: 3.58, w: 1.18, h: 0.45, fontSize: 9, color: C.text2, align: "center" });
    });
    txt(s, "Vendite Q3: totale stabile, Centro in calo", { x: 5.25, y: 3.02, w: 4.1, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
    txt(s, bullets(["Totale 3.752 k€, +0,1% sul 2024", "Centro -12%: calo concentrato a settembre", "Nord +6,0% e Sud +3,9%"], { space: 2 }), { x: 5.25, y: 3.36, w: 4.1, h: 0.8, fontSize: 10, color: C.text1 });
    banner(s, 4.35, "In pochi minuti più rappresentazioni da confrontare, per scegliere quella che rende chiaro il messaggio. Esempi fittizi.", { h: 0.6, fontSize: 12 });
  }
  {
    const s = content("Scegliere la rappresentazione", "La scelta del grafico dipende da che cosa si vuole mostrare e da chi lo leggerà: non ci sono regole fisse, ma indicazioni che funzionano spesso. Per confrontare categorie, le barre, perché le lunghezze si confrontano facilmente. Per un andamento nel tempo, le linee. Per la composizione di un totale, barre in pila o, con poche voci, una torta, che diventa difficile da leggere con molte fette o quote simili. Per la relazione tra due variabili, la dispersione. Per la distribuzione dei valori, l'istogramma. Per valori precisi da consultare, spesso una tabella. L'ultima colonna mostra come l'AI può aiutare in ciascun caso: ordinare le barre ed etichettarle, mostrare il periodo completo e il confronto con l'anno prima, raggruppare le voci minori dichiarandolo, evidenziare i punti anomali, provare intervalli diversi, formattare unità e decimali. La pratica: dire all'AI quale messaggio si vuole far vedere e a chi, chiedere di motivare la scelta e, se utile, di proporre due alternative. Un buon grafico ha un messaggio visibile in pochi secondi.");
    phaseTag(s, 2);
    table(s, [["Che cosa mostrare", "Spesso adatta", "Come può aiutare l'AI"],
      ["Confronto tra categorie", "Barre", "Ordinare per valore, etichettare"],
      ["Andamento nel tempo", "Linee", "Periodo completo, confronto anno prima"],
      ["Composizione di un totale", "Barre in pila; torta con poche voci", "Raggruppare le voci minori, dichiarandolo"],
      ["Relazione tra due variabili", "Dispersione", "Evidenziare i punti anomali"],
      ["Distribuzione dei valori", "Istogramma", "Provare intervalli diversi"],
      ["Valori precisi", "Tabella", "Formattare unità e decimali"]],
      { y: 1.12, colW: [2.75, 2.75, 3.5], rowH: 0.4, fontSize: 11, blankCorner: false, accentCol: 2 });
    banner(s, 4.12, "Nessuna regola fissa: dipende da messaggio e pubblico. Dire all'AI che cosa far vedere e a chi, e chiedere di motivare la scelta.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Tabelle, dashboard e report", "Tre forme di comunicazione con esigenze diverse, che l'AI produce bene. Le tabelle riepilogative presentano i risultati in forma compatta; vale la pena controllare che i totali siano coerenti con i dati, che gli arrotondamenti non portino somme diverse da cento, e che cosa contiene la voce 'altro'. Le dashboard servono a un uso ripetuto nel tempo: conta soprattutto la stabilità delle definizioni, perché se un indicatore cambia formula da un mese all'altro l'andamento perde significato. Le dashboard costruite al volo con l'AI sono ottime per esplorare e per preparare una discussione; per l'uso ufficiale servono definizioni concordate, di solito negli strumenti di BI. I report analitici combinano testo, numeri e grafici: il controllo più utile è che ogni numero citato nel testo si ritrovi in tabelle e grafici, e che grafici e tabelle si riferiscano allo stesso periodo. Una richiesta utile all'AI dopo aver prodotto un report: 'controlla che ogni numero citato nel testo compaia nelle tabelle, e segnala le differenze'.");
    phaseTag(s, 2);
    const f = [["FiGrid", "Tabelle riepilogative", ["Totali coerenti con i dati", "Arrotondamenti: somme diverse da 100", "Che cosa contiene 'altro'?"]], ["FiMonitor", "Dashboard", ["Uso ripetuto nel tempo", "Definizioni stabili", "Esplorative o ufficiali?"]], ["FiFileText", "Report analitici", ["Testo, numeri e grafici", "Coerenza tra le parti", "Ogni numero citato va ritrovato"]]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.15, 2.86, 2.9, { icon: f[i][0], head: f[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: bullets(f[i][2], { space: 5 }) });
    }
    banner(s, 4.25, "Le dashboard prodotte al volo sono ottime per esplorare; per l'uso ufficiale servono definizioni concordate e stabili.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Grafici chiari e onesti", "Lo stesso insieme di dati fittizi, due grafici. A sinistra gli ultimi sei mesi: una crescita costante e rassicurante. A destra gli ultimi trenta: la crescita recente è un recupero parziale dopo un forte calo, e le vendite sono ancora sotto i livelli di due anni fa. Nessuno dei due è falso, ma comunicano messaggi diversi. L'AI segue la richiesta: se si chiede di 'mostrare la crescita', sceglierà il periodo in cui c'è crescita. La buona notizia è che l'AI è anche un ottimo aiuto per rendere un grafico chiaro e onesto, se glielo si chiede. Può scrivere un titolo che dice il messaggio, per esempio 'Le vendite recuperano, ma restano sotto il 2023', invece di un generico 'Vendite'; mostrare il periodo completo e il confronto con l'anno prima; dichiarare assi, unità e fonte; sostituire la legenda con etichette dirette; togliere decorazioni ed effetti tridimensionali che deformano le proporzioni. Altri meccanismi da conoscere: due assi diversi sullo stesso grafico, torte con percentuali che non sommano a cento, scale logaritmiche non segnalate. La domanda di controllo: quale periodo, quale scala, quali categorie, e che cosa vedrei con scelte diverse?");
    phaseTag(s, 2);
    const full = [100, 102, 99, 101, 98, 96, 97, 94, 90, 88, 85, 82, 80, 78, 75, 73, 70, 68, 66, 65, 64, 63, 62, 64, 66, 68, 70, 72, 74, 77];
    const labF = full.map((v, i) => (i % 6 === 0 ? "M" + (i + 1) : ""));
    lineChart(s, ["M25", "M26", "M27", "M28", "M29", "M30"], [{ name: "Vendite", values: full.slice(24) }], { x: 0.5, y: 1.1, w: 4.3, h: 2.5, min: 60, max: 80, symbol: "circle", title: "Ultimi 6 mesi: sembra una crescita costante" });
    lineChart(s, labF, [{ name: "Vendite", values: full, color: HEX.a5 }], { x: 5.2, y: 1.1, w: 4.3, h: 2.5, min: 0, max: 110, title: "Ultimi 30 mesi: un recupero parziale" });
    txt(s, "Stessi dati fittizi, indice delle vendite (mese 1 = 100)", { x: 0.5, y: 3.62, w: 9, h: 0.26, fontSize: 10, italic: true, color: C.accent2, align: "center" });
    txt(s, "Come l'AI può migliorare un grafico, se glielo si chiede", { x: 0.5, y: 3.9, w: 9, h: 0.28, fontSize: 12, bold: true, color: C.accent1 });
    const m = ["Titolo che dice il messaggio", "Periodo completo e confronti", "Assi, unità e fonte", "Etichette dirette", "Niente effetti 3D"];
    m.forEach((t, i) => chip(s, 0.5 + i * 1.82, 4.22, 1.7, 0.48, t, { fill: C.accent6, fontSize: 10 }));
    txt(s, "Domanda di controllo: quale periodo, quale scala, e che cosa vedrei con scelte diverse?", { x: 0.5, y: 4.73, w: 9, h: 0.27, fontSize: 11, italic: true, bold: true, color: C.accent5 });
  }
  {
    const s = content("Dati e grafico coerenti", "Un controllo di base: il grafico rappresenta davvero i dati? Possono esserci scarti tra dati e rappresentazione, in qualsiasi strumento. Una colonna diversa da quella intesa, per esempio il fatturato lordo invece del netto. Righe incluse o escluse senza dichiararlo, come le righe di totale o i mesi incompleti. Un'aggregazione diversa da quella attesa, la somma invece della media. Etichette che non corrispondono ai dati, come 'migliaia di euro' su dati in euro. E il caso più frequente nei grafici prodotti automaticamente da esportazioni recenti: l'ultimo periodo parziale, il mese in corso con pochi giorni di dati, che mostra un calo che non c'è. La pratica è rapida: chiedere all'AI di dichiarare nel grafico fonte, periodo ed esclusioni, e controllare due o tre valori sulla tabella dei dati, insieme a titolo, etichette e unità. Un buon grafico dichiara da dove vengono i dati, su quale periodo e che cosa è stato escluso.");
    phaseTag(s, 2);
    const e = [["Colonna sbagliata", "Lordo invece di netto"], ["Righe incluse o escluse", "Totali, mesi incompleti"], ["Aggregazione diversa", "Somma invece di media"], ["Etichette e unità", "Migliaia su dati in euro"], ["Ultimo periodo parziale", "Un calo che non c'è"]];
    e.forEach((x, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const xx = 0.5 + col * 3.07, y = 1.15 + row * 1.0;
      shapeBox(s, xx, y, 2.86, 0.88, i === 4 ? C.accent6 : C.background2, x[0]);
      txt(s, x[0], { x: xx + 0.15, y: y + 0.06, w: 2.56, h: 0.35, fontSize: 13, bold: true, color: i === 4 ? C.accent5 : C.accent1 });
      txt(s, x[1], { x: xx + 0.15, y: y + 0.44, w: 2.56, h: 0.36, fontSize: 12, color: C.text2 });
    });
    shapeBox(s, 6.64, 2.15, 2.86, 0.88, C.text1, "buon grafico");
    txt(s, "Un buon grafico dichiara fonte, periodo ed esclusioni", { x: 6.79, y: 2.15, w: 2.56, h: 0.88, fontSize: 12, bold: true, color: C.accent6, valign: "middle" });
    banner(s, 3.3, "Pratica utile: chiedere all'AI di indicare nel grafico fonte, periodo ed esclusioni, e controllare due o tre valori sulla tabella.", { h: 0.85, fontSize: 13 });
    txt(s, "Il mese in corso con pochi giorni di dati è uno degli scarti più frequenti nei grafici automatici.", { x: 0.5, y: 4.35, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Comunicare i risultati", "Questa slide riunisce comunicazione, commenti generati e storytelling. L'AI è particolarmente utile nel rendere i risultati comprensibili: titoli che dicono il messaggio, commenti in linguaggio semplice per chi non legge facilmente i numeri, un racconto costruito con messaggio principale, sequenza logica, contesto e implicazione, versioni diverse dello stesso contenuto per la direzione, per un reparto, per un cliente. È il data storytelling, una competenza preziosa perché i dati senza racconto spesso non vengono capiti né usati. Perché il messaggio regga, alcune attenzioni sul testo. Ogni affermazione deve potersi ritrovare nei numeri presentati. Gli arrotondamenti devono essere fedeli: più 70 per cento non è 'quasi raddoppiato'. Le cause vanno citate solo se verificate: 'grazie alla campagna' è un'interpretazione, non un dato. Limiti e incertezze vanno dichiarati. Un racconto efficace seleziona che cosa mostrare: se lo costruisce l'AI, conviene rileggere la selezione. In sintesi: comunicazione efficace e interpretazione corretta sono qualità diverse. L'AI rende facile la prima; la seconda si costruisce con dati verificati e con le pratiche viste nei sottotemi precedenti. Prima di chiedersi se un report è convincente, conviene chiedersi se è corretto.");
    phaseTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 2.65, { icon: "FiMessageCircle", head: "Come aiuta l'AI", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Titoli che dicono il messaggio", "Commenti in linguaggio semplice", "Racconto: messaggio, sequenza, contesto, implicazione", "Versioni per pubblici diversi"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.65, { icon: "FiCheckSquare", head: "Perché il messaggio regga", headSize: 15, bodySize: 12,
      body: bullets(["Ogni affermazione si ritrova nei numeri", "Arrotondamenti fedeli: +70% non è 'quasi raddoppiato'", "Cause solo se verificate", "Limiti e incertezze dichiarati"], { space: 4 }) });
    shapeBox(s, 0.5, 3.98, 9.0, 0.95, C.text1, "comunicare e interpretare");
    txt(s, [{ text: "Comunicazione efficace e interpretazione corretta sono qualità diverse: ", options: { color: C.background1 } }, { text: "l'AI rende facile la prima; la seconda si costruisce con dati e verifiche.", options: { color: C.accent6, bold: true } }], { x: 0.7, y: 3.98, w: 8.6, h: 0.95, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Cinque prompt per l'analisi", "Cinque prompt pronti, che seguono il processo del modulo e si adattano a contesti diversi cambiando nomi di colonne, periodi e definizioni. Uno, comprendere un dataset: chiede struttura, significato probabile delle colonne, periodo, e l'elenco delle ipotesi da confermare. Due, problemi di qualità: chiede di contare e classificare i problemi e di proporre un trattamento senza modificare i dati, così le scelte restano nostre. Tre, calcolare KPI: chiede di usare il codice, fornisce le definizioni aziendali e chiede di mostrare le formule; è il prompt che rende il risultato confrontabile con i report ufficiali. Quattro, tendenze e anomalie: chiede il confronto con lo stesso periodo dell'anno prima, il criterio usato per gli scostamenti e ipotesi verificabili. Cinque, report sintetico: fissa pubblico, lunghezza e struttura, e chiede di distinguere dati osservati, stime e ipotesi e di indicare i limiti. Funzionano al meglio negli strumenti che leggono file ed eseguono codice; con strumenti che lavorano solo sul testo, il terzo va adattato chiedendo formule da usare nel proprio foglio di calcolo. Promemoria: dati autorizzati, in strumenti autorizzati. Esercizio suggerito: applicare i cinque prompt a un file fittizio, in sequenza, e confrontare i risultati con quelli ottenuti con richieste generiche.");
    phaseTag(s, 2);
    const p = [["Comprendere un dataset", "Descrivi questo file: che cosa rappresenta ogni riga, significato probabile e tipo di ogni colonna, periodo coperto. Elenca le ipotesi che devo confermare."],
      ["Problemi di qualità", "Controlla mancanti, duplicati, formati incoerenti e valori anomali. Per ognuno indica quante righe riguarda e proponi un trattamento, senza modificare i dati."],
      ["Calcolare KPI", "Usa il codice per calcolare fatturato netto, ordini e valore medio per regione e trimestre. Fatturato al netto di IVA e resi, annullati esclusi. Mostra le formule."],
      ["Tendenze e anomalie", "Confronta ogni mese con lo stesso mese dell'anno prima. Segnala gli scostamenti rilevanti, il criterio usato e due o tre ipotesi verificabili per ciascuno."],
      ["Report sintetico", "Prepara una pagina per la direzione: tre messaggi, una tabella, un grafico. Distingui dati osservati, stime e ipotesi, e indica i limiti dell'analisi."]];
    p.forEach((e, i) => {
      const y = 1.1 + i * 0.7;
      shapeBox(s, 0.5, y, 2.15, 0.62, i % 2 ? C.accent6 : C.accent1, "uso " + (i + 1));
      txt(s, String(i + 1), { x: 0.6, y, w: 0.35, h: 0.62, fontSize: 16, bold: true, color: i % 2 ? C.accent1 : C.background1, valign: "middle" });
      txt(s, e[0], { x: 0.95, y, w: 1.65, h: 0.62, fontSize: 12, bold: true, color: i % 2 ? C.text1 : C.background1, valign: "middle" });
      shapeBox(s, 2.75, y, 6.75, 0.62, C.background2, "prompt " + (i + 1));
      txt(s, e[1], { x: 2.88, y, w: 6.5, h: 0.62, fontSize: 10, color: C.text1, fontFace: "Courier New", valign: "middle" });
    });
    txt(s, "Adattare colonne, periodi e definizioni al proprio file. Dati autorizzati, in strumenti autorizzati.", { x: 0.5, y: 4.62, w: 9, h: 0.33, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }

  // =====================================================================
  section("9.6 Previsioni");
  divider("9.6", "AI, analisi predittiva e simulazioni", "L'AI rende accessibili stime, scenari e simulazioni utili alla pianificazione; ogni previsione resta una stima condizionata da dati, ipotesi e metodo", "Finora abbiamo guardato al passato; ora guardiamo avanti: previsioni, stime, scenari, simulazioni. È un sottotema da conoscere e comprendere, senza entrare nei modelli statistici o di Machine Learning. L'AI rende questi strumenti accessibili anche a chi non è specialista: costruire tre scenari in un foglio di calcolo o una proiezione con intervallo di incertezza diventa una richiesta in linguaggio naturale. Vediamo la differenza tra descrivere e prevedere, il ruolo dei dati storici, il valore degli intervalli per la pianificazione, scenari e simulazioni con le loro ipotesi, e come validare una previsione. Il concetto chiave: una previsione è una stima condizionata da dati, ipotesi e metodo, non una descrizione certa del futuro; proprio per questo, se dichiara ipotesi e incertezza, è uno strumento prezioso per decidere. Esercizio suggerito: chiedere all'AI una previsione su un dataset fittizio, poi l'elenco delle ipotesi, l'intervallo di incertezza e una prova sul periodo precedente, e discutere quanto cambia la fiducia nella previsione.");
  {
    const s = content("Descrivere e prevedere", "Questa slide riunisce la distinzione tra descrivere e prevedere e quella tra previsione calcolata e supposizione generata. L'analisi descrittiva lavora su ciò che è accaduto: se dati e calcoli sono corretti, il risultato è un fatto. Esempio: le vendite sono cresciute del 5 per cento all'anno negli ultimi tre anni. L'analisi predittiva lavora su ciò che potrebbe accadere: il risultato è una stima, che dipende da dati storici, metodo e ipotesi. Esempio: cresceranno del 5 per cento il prossimo anno, se le condizioni restano simili. Il passaggio dall'una all'altra va reso esplicito: prolungare una tendenza è il metodo più semplice, e funziona finché il contesto non cambia. Seconda distinzione. Una previsione calcolata è il risultato di un metodo applicato ai nostri dati, con ipotesi esplicite: si può ripetere e modificare. Una supposizione generata è un numero prodotto come testo dalla conoscenza generale del modello, per esempio 'il mercato dovrebbe crescere del 7-8 per cento': può essere ragionevole e riprendere stime pubblicate, ma non è un calcolo sui nostri dati e la sua origine spesso non si ricostruisce. Per distinguerle: c'è un metodo dichiarato? Dati e passaggi sono visibili? Il calcolo si può ripetere? Se no, il numero va trattato come un'opinione da verificare, prima di inserirlo in un piano.");
    phaseTag(s, 2);
    await card(s, 0.5, 1.12, 4.35, 1.5, { icon: "FiClock", inline: true, head: "Analisi descrittiva", headSize: 15, bodySize: 12,
      body: "Che cosa è accaduto: un fatto, se dati e calcoli sono corretti. +5% all'anno negli ultimi tre anni." });
    await card(s, 5.15, 1.12, 4.35, 1.5, { icon: "FiTrendingUp", inline: true, head: "Analisi predittiva", headSize: 15, bodySize: 12, fill: C.accent6,
      body: "Che cosa potrebbe accadere: una stima. +5% il prossimo anno, se le condizioni restano simili." });
    txt(s, "Previsione calcolata o supposizione generata?", { x: 0.5, y: 2.72, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    docBox(s, 0.5, 3.05, 4.35, 1.0, "Calcolata", "Un metodo applicato ai nostri dati, con ipotesi esplicite: ripetibile e modificabile.", { fontSize: 12, fill: C.accent6 });
    docBox(s, 5.15, 3.05, 4.35, 1.0, "Supposta", "Testo dalla conoscenza generale: 'il mercato dovrebbe crescere del 7-8%'. Origine non ricostruibile.", { fontSize: 12, bar: C.accent5, labelColor: C.accent5 });
    banner(s, 4.2, "Per distinguerle: metodo dichiarato, dati e passaggi visibili, calcolo ripetibile. Se mancano, è un'opinione da verificare.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Modelli previsionali e dati storici", "Una breve introduzione ai modelli previsionali, senza tecnica. Un modello previsionale usa i dati storici per stimare valori futuri o sconosciuti. I più semplici prolungano una tendenza, con o senza stagionalità. Altri usano più variabili, come prezzi, promozioni, festività, meteo. Altri ancora, basati su Machine Learning, apprendono relazioni complesse da grandi quantità di dati. L'AI generativa può costruire e applicare questi modelli più semplici, negli strumenti che eseguono codice, e spiegarne il funzionamento. Il ruolo dei dati storici è centrale: sono la base su cui il modello stima tendenza, stagionalità e relazioni. Contano la quantità, la qualità e soprattutto la somiglianza con il periodo da prevedere. Con pochi cicli stagionali, per esempio due anni di dati mensili, la stagionalità si stima con molta incertezza. I periodi anomali, come una crisi o una promozione eccezionale, vanno segnalati o trattati a parte, altrimenti il modello apprende relazioni anomale. E tutti i modelli condividono un'ipotesi: che le relazioni del passato continuino a valere. Per questo funzionano bene in contesti stabili e meno davanti a cambiamenti come un nuovo concorrente o una nuova norma. La prima domanda da porre all'AI su una previsione: su quali dati si basa, e quanto il futuro previsto assomiglia al passato osservato?");
    phaseTag(s, 2);
    const m = [["Prolungare una tendenza", "Con o senza stagionalità", C.background2], ["Più variabili", "Prezzi, promozioni, festività, meteo", C.accent6], ["Machine Learning", "Relazioni complesse apprese da molti dati", C.background2]];
    m.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.2, e[2], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.4, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.6, fontSize: 12, color: C.text2 });
    });
    shapeBox(s, 0.5, 2.52, 9.0, 0.9, C.text1, "dati storici");
    txt(s, [{ text: "Il ruolo dei dati storici: ", options: { bold: true, color: C.accent6 } }, { text: "sono la base del modello. Contano quantità, qualità e somiglianza con il periodo da prevedere: il modello assume che le relazioni del passato continuino.", options: { color: C.background1 } }], { x: 0.7, y: 2.52, w: 8.6, h: 0.9, fontSize: 13, valign: "middle" });
    chip(s, 0.5, 3.6, 4.4, 0.6, "Pochi cicli stagionali: stagionalità stimata con incertezza", { fill: C.background2, fontSize: 12 });
    chip(s, 5.1, 3.6, 4.4, 0.6, "Periodi anomali: da segnalare o trattare a parte", { fill: C.background2, fontSize: 12 });
    txt(s, "Prima domanda: su quali dati si basa, e quanto il futuro previsto assomiglia al passato osservato?", { x: 0.5, y: 4.42, w: 9, h: 0.48, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Stime e intervalli", "Ogni previsione è incerta, e una previsione ben fatta lo dichiara con un intervallo. Il grafico fittizio mostra un anno di vendite mensili e la proiezione per i sei mesi successivi: una stima centrale e un intervallo tra un valore basso e uno alto, che si allarga allontanandosi dall'ultimo dato osservato. A giugno la stima centrale è 1.250 pezzi, l'intervallo va da 900 a 1.600. Presentare solo '1.247 pezzi' suggerisce una precisione che non esiste. Il valore dell'intervallo è soprattutto per la pianificazione: la stima centrale serve per budget e obiettivi; il valore basso per definire scorte minime e un piano di contenimento dei costi; il valore alto per verificare capacità produttiva, personale e fornitori. Si pianifica così per più esiti, con decisioni più robuste e flessibili. Quando si chiede una previsione all'AI conviene chiedere sempre l'intervallo e il metodo usato per calcolarlo, e ricordare che anche l'intervallo dipende dalle ipotesi: se il contesto cambia, il valore reale può uscirne. L'incertezza non è un difetto della previsione: è un'informazione per decidere.");
    phaseTag(s, 2);
    const lab = ["G", "F", "M", "A", "M", "G", "L", "A", "S", "O", "N", "D", "G", "F", "M", "A", "M", "G"];
    const hist = [900, 940, 980, 1010, 1000, 1050, 1080, 1020, 1100, 1130, 1150, 1180];
    const n = null;
    const histS = hist.concat([n, n, n, n, n, n]);
    const c = [1180, 1195, 1205, 1220, 1230, 1240, 1250], lo = [1180, 1140, 1090, 1040, 990, 950, 900], hi = [1180, 1250, 1320, 1390, 1460, 1530, 1600];
    const pad = [n, n, n, n, n, n, n, n, n, n, n];
    lineChart(s, lab, [{ name: "Storico", values: histS, color: HEX.dk1 }, { name: "Stima centrale", values: pad.concat(c), color: HEX.a1 }, { name: "Valore basso", values: pad.concat(lo), color: HEX.a2 }, { name: "Valore alto", values: pad.concat(hi), color: HEX.a2 }], { x: 0.5, y: 1.1, w: 5.5, h: 3.1, min: 800, max: 1700, legend: true, title: "Vendite in pezzi e proiezione a sei mesi (esempio fittizio)" });
    shapeBox(s, 6.2, 1.12, 3.3, 1.0, C.background2, "dichiarare l'incertezza");
    txt(s, "Dichiarare l'incertezza", { x: 6.35, y: 1.17, w: 3.0, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
    txt(s, "Non '1.247 pezzi', ma tra 900 e 1.600, stima centrale 1.250", { x: 6.35, y: 1.48, w: 3.0, h: 0.6, fontSize: 11, italic: true, color: C.text1 });
    const u = [["Stima centrale", "Budget e obiettivi"], ["Valore basso", "Scorte minime, contenimento dei costi"], ["Valore alto", "Capacità, personale, fornitori"]];
    u.forEach((e, i) => {
      const y = 2.25 + i * 0.66;
      shapeBox(s, 6.2, y, 3.3, 0.58, i === 0 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.35, y: y + 0.03, w: 3.0, h: 0.26, fontSize: 11, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.35, y: y + 0.29, w: 3.0, h: 0.26, fontSize: 10, color: C.text2 });
    });
    banner(s, 4.38, "Più lontano è il futuro, più l'intervallo si allarga. Pianificare per più esiti rende le decisioni più robuste.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Scenari, simulazioni, ipotesi", "Questa slide riunisce scenari e ipotesi. Una previsione chiede: che cosa succederà? Uno scenario chiede: che cosa succederebbe se? L'analisi what-if modifica una o più variabili e ne calcola le conseguenze; l'analisi di scenario costruisce alcune combinazioni coerenti di ipotesi, di solito prudente, centrale e favorevole. L'esempio fittizio in tabella: un aumento di prezzo del 5 per cento, con base prezzo 100 e costo unitario 70. Nello scenario prudente i volumi calano del 12 per cento e i costi salgono del 4: il margine totale scende del 5,5 per cento, cioè 32,2 per 0,88 contro 30. Nello scenario centrale, volumi meno 4 e costi più 2, il margine sale del 7,5 per cento. In quello favorevole, volumi meno 1 e costi più 1, sale del 13,2 per cento. Il valore di questi strumenti è che rendono esplicite le ipotesi e mostrano quali contano davvero: qui il risultato cambia segno, e dipende soprattutto dalla reazione dei volumi. Su quell'ipotesi va concentrata la discussione, con chi conosce il mercato. Le ipotesi da rendere esplicite riguardano la continuità delle tendenze, il contesto, le reazioni di clienti e concorrenti, la rappresentatività dei dati. L'AI costruisce questi modelli rapidamente, anche in un foglio di calcolo; la pratica è chiederle l'elenco delle ipotesi, quanto è solida ciascuna e quanto il risultato ne dipende. Una simulazione è affidabile quanto le sue ipotesi.");
    phaseTag(s, 2);
    table(s, [["Ipotesi", "Prudente", "Centrale", "Favorevole"],
      ["Aumento prezzo", "+5%", "+5%", "+5%"],
      ["Variazione volumi", "-12%", "-4%", "-1%"],
      ["Costi unitari", "+4%", "+2%", "+1%"],
      ["Margine totale", "-5,5%", "+7,5%", "+13,2%"]],
      { y: 1.12, colW: [3.0, 2.0, 2.0, 2.0], rowH: 0.4, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Esempio fittizio. Base: prezzo 100, costo unitario 70. Margine totale = (prezzo - costo) × volumi.", { x: 0.5, y: 3.17, w: 9, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    txt(s, "Ipotesi da esplicitare", { x: 0.5, y: 3.52, w: 1.9, h: 0.45, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    const h = ["Continuità", "Contesto", "Reazioni dei clienti", "Dati rappresentativi"];
    h.forEach((t, i) => chip(s, 2.4 + i * 1.79, 3.52, 1.68, 0.45, t, { fill: i === 2 ? C.accent6 : C.background2, fontSize: 11 }));
    banner(s, 4.12, "Il margine cambia segno tra gli scenari: conta soprattutto la reazione dei volumi. Gli scenari mostrano dove concentrare la discussione.", { h: 0.82, fontSize: 13 });
  }
  {
    const s = content("Validare le previsioni", "Come si valuta l'affidabilità di una previsione? Il controllo più semplice e potente è il confronto con il passato: si applica il metodo a un periodo già trascorso, usando solo i dati precedenti, e si confronta la previsione con ciò che è accaduto. Per esempio, si usano i dati fino a dicembre di due anni fa per prevedere l'anno scorso, e si misura l'errore. Se il metodo avrebbe sbagliato del 20 per cento sull'anno scorso, non c'è motivo di pensare che sia più preciso sul prossimo. È un controllo che si può chiedere direttamente all'AI quando costruisce una previsione. Altri elementi: confrontare la previsione con metodi diversi, con stime indipendenti, con il giudizio di chi conosce il mercato; verificare che sia plausibile rispetto ai vincoli reali, come la capacità produttiva o la dimensione del mercato; e monitorare nel tempo previsioni e risultati, per capire quando il metodo va rivisto. La modellazione avanzata e le metriche statistiche di errore sono solo da accennare: per previsioni critiche servono competenze specialistiche.");
    phaseTag(s, 2);
    const st = [["Dati fino a due anni fa", C.background2, C.text1], ["Previsione dell'anno scorso", C.accent6, C.text1], ["Confronto con il reale", C.accent1, C.background1]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      chip(s, x, 1.2, 2.86, 0.75, e[0], { fill: e[1], color: e[2], fontSize: 13 });
      if (i < 2) arrow(s, x + 2.88, 1.42, 0.17);
    });
    txt(s, "Se avrebbe sbagliato del 20% sul passato, perché dovrebbe essere più preciso sul futuro?", { x: 0.5, y: 2.05, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent5, align: "center" });
    await iconGrid(s, [
      { icon: "FiColumns", head: "Confrontare", body: "Metodi diversi, stime indipendenti, esperti" },
      { icon: "FiShield", head: "Vincoli reali", body: "Capacità produttiva, dimensione del mercato" },
      { icon: "FiActivity", head: "Monitorare", body: "Previsioni contro risultati, nel tempo" },
    ], 3, { y: 2.65, h: 1.45, headSize: 14, bodySize: 12 });
    txt(s, "La prova sul passato si può chiedere direttamente all'AI. Per previsioni critiche servono competenze specialistiche.", { x: 0.5, y: 4.35, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }

  // =====================================================================
  section("9.7 Interpretazione e decisioni");
  divider("9.7", "Interpretazione e decisioni", "L'AI aiuta a valutare alternative, vincoli, trade-off e conseguenze; la solidità di una decisione dipende anche da criteri e giudizio, non solo dagli indicatori", "Arriviamo alla fase finale: dai risultati alle decisioni. Apriamo con il caso completo delle vendite, dai dati grezzi alla decisione, poi vediamo come l'AI aiuta a interpretare, a confrontare alternative, a esplorare opzioni, trade-off e conseguenze, e come evitare la falsa oggettività, cioè conclusioni numeriche che dipendono da scelte non dichiarate. Il concetto chiave: la solidità di una decisione non dipende solo dalla correttezza aritmetica degli indicatori, ma anche dai criteri, dalle ipotesi e dal giudizio di chi decide. L'AI rende disponibili più informazioni e più alternative, più rapidamente: è un supporto concreto alla qualità delle decisioni. Esercizio suggerito: partire dall'esempio della redditività dei clienti con un dataset fittizio, far calcolare all'AI la redditività con due definizioni diverse e discutere quale sia più adatta alla decisione da prendere.");
  {
    const s = content("Un caso completo: le vendite", "Il caso fittizio che abbiamo seguito nel modulo, ricomposto in cinque passaggi. Dati grezzi: il file vendite_2025.xlsx, 12.480 righe, con duplicati, ordini annullati e formati incoerenti corretti dopo conferma; restano 12.109 righe analizzate. Indicatori: il fatturato netto del terzo trimestre per regione mostra un totale stabile, più 0,1 per cento. Scostamento: il Centro è in calo del 12 per cento, cioè 138 mila euro in meno, e quasi tutto il calo è a settembre, meno 110 mila euro sull'anno prima. Diagnosi: la scomposizione per cliente e per canale mostra che il calo coincide con un solo cliente principale; l'ipotesi di ordini registrati in un'altra regione è esclusa. Decisione: il responsabile commerciale incontra il cliente; il budget del Centro sarà rivisto solo dopo il colloquio, perché il calo potrebbe essere temporaneo. Il contributo dell'AI: pulizia proposta e registro, calcoli eseguiti con codice, scostamento segnalato con le ipotesi, tabella, grafico e bozza di report. Il contributo della persona: conferma di definizioni ed esclusioni, scelta del confronto con il 2024, verifica con il commerciale, decisione. In poco tempo, e senza programmare, i dati grezzi diventano un'azione mirata.");
    phaseTag(s, 3);
    steps(s, [["Dati grezzi", "12.480 righe; duplicati, annullati e formati corretti con conferma"], ["Indicatori", "Fatturato netto Q3 per regione: totale stabile, +0,1%"], ["Scostamento", "Centro -12%; settembre -110 k€ sull'anno prima"], ["Diagnosi", "Calo legato a un cliente principale, verificato per cliente e canale"], ["Decisione", "Incontro con il cliente, poi revisione mirata del budget"]], { y: 1.1, h: 1.35, darkLast: true });
    regionTable(s, 0.5, 2.62, 4.45, { colW: [1.0, 1.15, 1.15, 1.15], rowH: 0.3, fontSize: 10 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 4.15, w: 3, h: 0.25, fontSize: 10, italic: true, color: C.accent2 });
    shapeBox(s, 5.1, 2.6, 2.13, 1.75, C.accent6, "contributo AI");
    txt(s, "L'AI", { x: 5.22, y: 2.65, w: 1.9, h: 0.28, fontSize: 12, bold: true, color: C.accent1 });
    txt(s, bullets(["Pulizia proposta e registro", "Calcoli eseguiti con codice", "Scostamento e ipotesi", "Tabella, grafico, bozza"], { space: 2 }), { x: 5.22, y: 2.95, w: 1.95, h: 1.35, fontSize: 10, color: C.text1 });
    shapeBox(s, 7.37, 2.6, 2.13, 1.75, C.background2, "contributo persona");
    txt(s, "La persona", { x: 7.49, y: 2.65, w: 1.9, h: 0.28, fontSize: 12, bold: true, color: C.accent1 });
    txt(s, bullets(["Definizioni ed esclusioni", "Confronto con il 2024", "Verifica con il commerciale", "La decisione"], { space: 2 }), { x: 7.49, y: 2.95, w: 1.95, h: 1.35, fontSize: 10, color: C.text1 });
    banner(s, 4.45, "Dai dati grezzi a un'azione mirata: l'AI accelera i passaggi, la persona dà loro significato.", { h: 0.5, fontSize: 12 });
  }
  {
    const s = content("Dai risultati al significato", "Questa slide riunisce l'interpretazione dei risultati e la distinzione tra evidenza quantitativa e giudizio. Interpretare significa attribuire ai risultati un significato per una decisione, e l'AI aiuta a porsi le domande giuste: quali indicatori contano per questa decisione, tra i venti di un report? Quali cause e conseguenze sono plausibili? Quali spiegazioni alternative sono compatibili con i dati? Che cosa servirebbe sapere per decidere meglio? Su quest'ultima domanda l'AI è particolarmente utile: chiedere 'quali dati mancano per valutare questa decisione?' porta spesso a domande che non ci si era posti. Una buona decisione combina due cose. L'evidenza quantitativa: ciò che i dati dicono, precisa ma parziale. Il giudizio: la conoscenza del mercato, della strategia, delle persone, gli elementi non misurati come reputazione e relazioni, le priorità dell'organizzazione. L'equilibrio si perde in due modi: dare troppo peso ai numeri perché sono disponibili e precisi, dimenticando che 'non è nei dati' non significa 'non conta'; oppure usare i numeri per giustificare una scelta già fatta, scegliendo tra le molte analisi rapide quella più comoda. Con l'AI è facile produrre molte analisi: il valore sta nell'usarle per informare la scelta.");
    phaseTag(s, 3);
    txt(s, "L'AI aiuta a chiedersi", { x: 0.5, y: 1.1, w: 4.4, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
    rowList(s, ["Quali indicatori contano per questa decisione?", "Quali cause e conseguenze sono plausibili?", "Quali spiegazioni alternative?", "Che cosa manca per decidere meglio?"], { x: 0.5, w: 4.4, y: 1.47, h: 0.52, gap: 0.08, fontSize: 12 });
    docBox(s, 5.1, 1.12, 4.4, 1.25, "Evidenza quantitativa", "Ciò che i dati dicono: margini, tempi, percentuali. Precisa, ma parziale.", { fontSize: 12 });
    docBox(s, 5.1, 2.5, 4.4, 1.32, "Giudizio di chi decide", "Mercato, strategia, persone, elementi non misurati, priorità e responsabilità.", { fontSize: 12, fill: C.accent6 });
    banner(s, 4.0, "Una buona decisione combina le due: 'non è nei dati' non significa 'non conta', e i numeri informano la scelta, non la giustificano dopo.", { h: 0.92, fontSize: 13 });
  }
  {
    const s = content("Confrontare alternative e scenari", "Un uso prezioso dell'AI nel supporto decisionale è il confronto strutturato tra alternative: scegliere tra tre fornitori, tra due localizzazioni, tra mantenere o cambiare un processo. Il sistema costruisce in pochi minuti una matrice con criteri, valori, vantaggi e rischi; combina dati quantitativi, come costi e tempi, con elementi qualitativi, come affidabilità e rischio di dipendenza; valuta ogni alternativa negli scenari visti nel 9.6. Così si dimenticano meno criteri e il confronto diventa esplicito e discutibile. Una parte del lavoro però non è tecnica: quali criteri considerare e quanto pesa ciascuno. Il costo conta più della flessibilità? Quale rischio è accettabile? Se si chiede all'AI di scegliere l'alternativa migliore, dovrà assegnare dei pesi, plausibili ma non necessariamente i nostri. Nella tabella fittizia i pesi sono volutamente un punto interrogativo. La pratica: indicare criteri e pesi, o almeno farsi mostrare quelli usati, e chiedere all'AI come cambia la classifica con due o tre combinazioni di pesi. Se la scelta regge, è robusta; se cambia, si sa esattamente su che cosa discutere.");
    phaseTag(s, 3);
    table(s, [["Criterio", "Peso", "Fornitore A", "Fornitore B", "Fornitore C"],
      ["Costo", "?", "Migliore", "Medio", "Peggiore"],
      ["Tempi di consegna", "?", "Medio", "Migliore", "Medio"],
      ["Affidabilità", "?", "Medio", "Medio", "Migliore"],
      ["Rischio di dipendenza", "?", "Alto", "Basso", "Medio"]],
      { y: 1.15, colW: [2.6, 1.0, 1.8, 1.8, 1.8], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.3, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    banner(s, 3.6, "L'AI costruisce la matrice in pochi minuti e mostra come cambia la classifica modificando i pesi. Criteri e pesi li sceglie chi decide.", { h: 0.8, fontSize: 13 });
    txt(s, "Pratica utile: chiedere la classifica con due o tre combinazioni di pesi. Se regge, la scelta è robusta.", { x: 0.5, y: 4.52, w: 9, h: 0.4, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }
  {
    const s = content("Analisi, opzioni e scelta", "Tra un'analisi e una decisione ci sono le opzioni, ed è qui che l'AI può dare un contributo molto concreto. L'analisi dice: il prodotto A ha un margine inferiore del 4 per cento alla media, per l'aumento dei costi di trasporto. Invece di chiedere 'che cosa devo fare?', conviene chiedere le opzioni con vantaggi, vincoli e conseguenze. Nell'esempio fittizio: eliminare A riduce i costi, ma A potrebbe essere acquistato da clienti che comprano anche prodotti molto redditizi, e bisogna valutare l'effetto sulle vendite collegate; rinegoziare il trasporto recupera margine senza toccare il catalogo, ma dipende dal fornitore e dai tempi della trattativa; aumentare il prezzo di A dà un margine immediato, ma bisogna stimare la reazione dei clienti, con gli scenari del 9.6. L'AI è efficace nel costruire questa tabella, nel far emergere trade-off e conseguenze di secondo livello e nel collegarla ai dati disponibili. I sistemi tendono a concludere con una raccomandazione, perché sono addestrati a essere utili: è un buon punto di partenza per la discussione, ma la scelta tiene conto di obiettivi, vincoli e rischio accettabile che conosce chi decide.");
    phaseTag(s, 3);
    docBox(s, 0.5, 1.12, 9.0, 0.72, "Analisi (esempio fittizio)", "Il prodotto A ha un margine inferiore del 4% alla media, per i costi di trasporto.", { fontSize: 13, fill: C.accent6 });
    table(s, [["Opzione", "Vantaggi", "Vincoli e rischi", "Conseguenze da valutare"],
      ["Eliminare A", "Costi più bassi", "Clienti che comprano A con altro", "Vendite collegate"],
      ["Rinegoziare il trasporto", "Margine recuperato, catalogo invariato", "Dipende dal fornitore", "Tempi della trattativa"],
      ["Aumentare il prezzo di A", "Margine immediato", "Reazione dei clienti", "Volumi, posizionamento"]],
      { y: 2.0, colW: [2.2, 2.45, 2.3, 2.05], rowH: 0.5, fontSize: 11, blankCorner: false });
    banner(s, 4.18, "Chiedere all'AI opzioni, trade-off e conseguenze, non una risposta unica: la scelta tiene conto di obiettivi e vincoli che conosce chi decide.", { h: 0.78, fontSize: 13 });
  }
  {
    const s = content("Il rischio di falsa oggettività", "Questa slide riunisce la falsa oggettività e le assunzioni implicite. Esempio fittizio: un sistema AI conclude che la categoria di clienti B è meno redditizia. Sembra un fatto, perché viene dai dati. Ma dipende da scelte analitiche: la redditività è il margine lordo o il valore del cliente nel tempo? I costi sono attribuiti in proporzione al fatturato o al numero di ordini? Il periodo è un anno anomalo o tre anni? I costi indiretti, come assistenza e gestione dei resi, sono inclusi? La tabella mostra che, con gli stessi dati, le opzioni della prima colonna portano a 'meno redditizia', quelle della seconda a 'più redditizia'. Nessuna scelta è sbagliata in sé: il problema nasce quando sono implicite e il risultato viene presentato come un fatto. Le scelte si nascondono in quattro punti: definizioni, cioè che cosa si misura e come; pesi, quanto conta ciascun criterio; confini, che cosa resta dentro e fuori; obiettivi, che cosa si sta ottimizzando. È un rischio di qualsiasi analisi; con l'AI conta di più perché le scelte vengono fatte rapidamente, spesso con le opzioni più comuni, e presentate con numeri precisi. La pratica è chiedere all'AI di elencarle e di ripetere il calcolo con scelte diverse: se la conclusione regge, è robusta; se no, la decisione dipende dalle scelte, e queste vanno discusse.");
    phaseTag(s, 3);
    shapeBox(s, 0.5, 1.12, 9.0, 0.58, C.background2, "conclusione");
    s.addShape(pres.shapes.RECTANGLE, { x: 0.5, y: 1.22, w: 0.06, h: 0.38, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, [{ text: "Conclusione del sistema (esempio fittizio):  ", options: { bold: true, color: C.accent1, fontSize: 11 } }, { text: "la categoria di clienti B è meno redditizia.", options: { bold: true, color: C.text1, fontSize: 14 } }], { x: 0.72, y: 1.12, w: 8.6, h: 0.58, valign: "middle" });
    table(s, [["Scelta analitica", "Opzione 1", "Opzione 2"],
      ["Redditività", "Margine lordo", "Valore nel tempo"],
      ["Costi attribuiti", "Per fatturato", "Per numero di ordini"],
      ["Periodo", "Un anno anomalo", "Ultimi tre anni"],
      ["Costi indiretti", "Esclusi", "Inclusi"],
      ["Esito per B", "Meno redditizia", "Più redditizia"]],
      { x: 0.5, y: 1.85, w: 5.75, colW: [2.05, 1.85, 1.85], rowH: 0.36, fontSize: 11, blankCorner: false });
    txt(s, "Dove si nascondono le scelte", { x: 6.45, y: 1.85, w: 3.05, h: 0.3, fontSize: 12, bold: true, color: C.text1 });
    const a = [["Definizioni", "che cosa si misura"], ["Pesi", "quanto conta ogni criterio"], ["Confini", "che cosa resta fuori"], ["Obiettivi", "che cosa si ottimizza"]];
    a.forEach((e, i) => {
      const y = 2.2 + i * 0.47;
      shapeBox(s, 6.45, y, 3.05, 0.42, i % 2 ? C.background2 : C.accent6, e[0]);
      txt(s, [{ text: e[0] + ": ", options: { bold: true, color: C.accent1 } }, { text: e[1], options: { color: C.text1 } }], { x: 6.58, y, w: 2.85, h: 0.42, fontSize: 11, valign: "middle" });
    });
    banner(s, 4.2, "Stessi dati, scelte diverse, conclusioni opposte. Chiedere all'AI quali scelte ha fatto e se la conclusione regge con scelte diverse.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Decidere con l'AI", "L'ultimo punto del sottotema è il rapporto tra AI e decisione. Un'analisi assistita dall'AI rende disponibili più informazioni, più alternative e più scenari, in tempi che prima avrebbero richiesto giorni di lavoro di un analista: è un supporto reale alla qualità delle decisioni. La decisione e le sue conseguenze restano di chi decide, come è sempre stato con qualsiasi strumento di analisi: 'l'ha detto l'analisi' non è una giustificazione, come non lo era 'l'ha detto il foglio di calcolo'. In pratica questo significa tre cose, che l'AI stessa aiuta a fare. Capire l'analisi nelle sue scelte principali: definizioni, ipotesi, limiti; basta chiedere all'AI di riassumerli. Conoscerne l'incertezza e tenerne conto, per esempio pianificando sugli intervalli. Saper spiegare la decisione, anche a chi ne subisce gli effetti, con argomenti che vanno oltre il risultato del sistema. Per le decisioni che riguardano le persone, come valutazioni, selezioni o assegnazioni, valgono anche vincoli etici e normativi specifici, trattati nei Temi 17 e 18.");
    phaseTag(s, 3);
    shapeBox(s, 0.5, 1.12, 9.0, 1.05, C.text1, "principio");
    txt(s, [{ text: "L'AI amplia informazioni, alternative e scenari disponibili. ", options: { color: C.background1 } }, { text: "Decisione e conseguenze restano di chi decide, come con qualsiasi strumento di analisi.", options: { color: C.accent6, bold: true } }], { x: 0.75, y: 1.12, w: 8.5, h: 1.05, fontSize: 15, valign: "middle" });
    await iconGrid(s, [
      { icon: "FiEye", head: "Capire l'analisi", body: "Definizioni, ipotesi, limiti: l'AI li riassume su richiesta" },
      { icon: "FiActivity", head: "Usarne l'incertezza", body: "Pianificare sugli intervalli e sugli scenari" },
      { icon: "FiMessageCircle", head: "Saper spiegare", body: "Con argomenti oltre il risultato del sistema" },
    ], 3, { y: 2.35, h: 1.55, headSize: 14, bodySize: 12 });
    txt(s, "Per le decisioni sulle persone (valutazioni, selezioni, assegnazioni) valgono anche vincoli etici e normativi specifici.", { x: 0.5, y: 4.12, w: 9, h: 0.65, fontSize: 12, italic: true, color: C.text2 });
  }

  // =====================================================================
  section("9.8 Limiti e affidabilità");
  divider("9.8", "Limiti e condizioni di affidabilità", "Conoscere i limiti permette di usare l'AI con fiducia: controlli su dati, metodi e interpretazioni, proporzionati alle conseguenze dell'utilizzo", "Ultimo sottotema. I limiti li abbiamo già incontrati uno per uno, ciascuno con la sua pratica, nel punto del processo in cui si presentano: qui non li ripetiamo. Ci concentriamo su tre aspetti trasversali: distinguere dati osservati, stime, scenari e simulazioni; riconoscere i problemi di fondamento statistico, che sono propri di qualsiasi analisi e non dell'AI; e una procedura semplice per decidere quanto controllare un'analisi in base al suo utilizzo. Il concetto chiave: un'analisi con l'AI richiede controlli su dati, metodi e interpretazioni, proporzionati alle conseguenze dell'utilizzo. Non tutto va controllato allo stesso modo: un'esplorazione si controlla in pochi minuti, un'analisi per la direzione richiede una verifica completa. Esercizio suggerito: dare ai partecipanti un report fittizio prodotto con l'AI, curato nella forma e con alcuni errori sostanziali nascosti, come un mese parziale, una stima non etichettata e una conclusione causale, e chiedere di individuarli applicando la procedura dei tre livelli.");
  {
    const s = content("Dati reali, stime, simulazioni", "Un aspetto trasversale: la natura dei numeri. Quattro categorie da tenere distinte. Osservato: misurato o registrato, come il fatturato del terzo trimestre. Stimato: calcolato da dati parziali o con un modello, come la previsione di giugno. Scenario: un insieme coerente di ipotesi sul futuro, come lo scenario prudente. Simulato: le conseguenze calcolate di un'ipotesi, come il margine con un prezzo più alto del 5 per cento. Confonderle è facile per tre motivi, e per ciascuno c'è una pratica. Numeri di natura diversa convivono nello stesso report: si chiede all'AI di etichettare la natura di ogni valore. L'AI può completare dati mancanti con stime senza dirlo chiaramente, per esempio un mese interpolato o un valore di mercato preso dalla conoscenza generale: si chiede di segnalare sempre i valori stimati e la loro origine. I risultati vengono riutilizzati: una simulazione copiata in una presentazione perde l'etichetta e diventa un dato; si mantiene l'etichetta anche nel riutilizzo. La domanda di controllo per ogni numero importante: è osservato, stimato o simulato, e da dove viene?");
    phaseTag(s, 3);
    const t = [["Osservato", "Misurato o registrato", "Fatturato netto Q3", C.accent1, C.background1], ["Stimato", "Calcolato da dati parziali o con un modello", "Previsione di giugno", C.accent6, C.text1], ["Scenario", "Insieme coerente di ipotesi", "Scenario prudente", C.background2, C.text1], ["Simulato", "Conseguenze calcolate di un'ipotesi", "Margine con prezzo +5%", C.background2, C.text1]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.12, 2.15, 1.6, e[3], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.18, w: 1.9, h: 0.38, fontSize: 16, bold: true, color: i === 0 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.58, w: 1.9, h: 0.6, fontSize: 11, bold: true, color: e[4] });
      txt(s, e[2], { x: x + 0.15, y: 2.2, w: 1.9, h: 0.45, fontSize: 11, italic: true, color: e[4] });
    });
    const r = [["Convivono nello stesso report", "Chiedere di etichettare la natura di ogni valore"], ["Completamenti silenziosi", "Chiedere di segnalare i valori stimati e la loro origine"], ["Riutilizzo", "Mantenere l'etichetta anche nelle presentazioni"]];
    r.forEach((e, i) => {
      const y = 2.9 + i * 0.5;
      shapeBox(s, 0.5, y, 9.0, 0.44, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 3.2, h: 0.44, fontSize: 12, bold: true, color: C.accent5, valign: "middle" });
      txt(s, e[1], { x: 3.9, y, w: 5.4, h: 0.44, fontSize: 12, color: C.text1, valign: "middle" });
    });
    txt(s, "Per ogni numero importante: osservato, stimato o simulato, e da dove viene?", { x: 0.5, y: 4.48, w: 9, h: 0.42, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Fondamento statistico", "Tre situazioni che ogni utilizzatore dovrebbe riconoscere. Pochi dati: una differenza tra due gruppi di dieci persone, o un andamento su quattro mesi, può essere dovuta al caso. Differenze piccole: il 2 per cento di differenza nella soddisfazione tra due sedi può essere rumore, soprattutto se i dati variano molto. Molti confronti: confrontando molte categorie, alcune mostrano differenze forti per puro caso. Una precisazione importante: questi non sono rischi propri dell'AI, sono limiti di qualsiasi analisi statistica, anche fatta a mano. L'AI li rende più frequenti solo perché produce analisi più facilmente, ma è anche un buon alleato per controllarli: si può chiederle su quanti casi si basa un risultato e se una differenza è statisticamente significativa, cioè improbabile che sia dovuta al caso. Due cautele: significativo non vuol dire importante nella pratica, e con pochi dati anche un test può essere poco affidabile. Per decisioni rilevanti su dati limitati o complessi conviene coinvolgere chi ha competenze statistiche.");
    phaseTag(s, 3);
    await iconGrid(s, [
      { icon: "FiUsers", head: "Pochi dati", body: "Due gruppi di dieci persone, quattro mesi di andamento" },
      { icon: "FiMinimize2", head: "Differenze piccole", body: "Il 2% tra due sedi può essere solo rumore" },
      { icon: "FiGrid", head: "Molti confronti", body: "Alcune differenze forti emergono per caso" },
    ], 3, { y: 1.15, h: 1.55, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 2.88, 9.0, 0.85, C.accent6, "non specifici dell'AI");
    txt(s, [{ text: "Limiti di qualsiasi analisi statistica, non specifici dell'AI. ", options: { bold: true, color: C.accent1 } }, { text: "L'AI aiuta a controllarli: su quanti casi si basa il risultato? La differenza è statisticamente significativa?", options: { color: C.text1 } }], { x: 0.7, y: 2.88, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
    banner(s, 3.92, "Significativo non vuol dire importante nella pratica. Per decisioni rilevanti su dati limitati o complessi, coinvolgere competenze statistiche.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Quanto controllare: tre livelli", "Il principio dei controlli proporzionati, tradotto in una procedura in tre passi. Primo: classificare l'uso dell'analisi. Secondo: applicare i controlli di quel livello. Terzo: alzare il livello se i dati sono di qualità incerta o se le conseguenze di un errore sarebbero difficili da correggere. Livello esplorare: per farsi un'idea, generare ipotesi, preparare una discussione. Basta un controllo di plausibilità, ordini di grandezza e uno sguardo ai dati, anche con un grafico. Livello lavorare: analisi interne che orientano attività, come il caso delle vendite fino alla telefonata al commerciale. Oltre ai controlli precedenti: dati di partenza e definizioni confermati, calcoli eseguiti con strumenti e non generati come testo, due o tre valori ricontrollati. Livello decidere o comunicare: analisi per la direzione, per l'esterno, per decisioni che riguardano persone. Si aggiungono il registro completo delle operazioni, una verifica indipendente dei risultati principali, le scelte analitiche esplicite con la loro influenza, e il coinvolgimento di specialisti se necessario. Più l'analisi pesa sulla decisione, più devono essere verificabili dati, calcoli e scelte. Il metodo generale è quello del Tema 7, qui applicato ai dati.");
    phaseTag(s, 3);
    const st = [["1", "Classificare l'uso"], ["2", "Applicare i controlli del livello"], ["3", "Alzare il livello se serve"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      chip(s, x, 1.1, 2.86, 0.45, e[0] + ".  " + e[1], { fill: i === 0 ? C.accent1 : C.accent6, color: i === 0 ? C.background1 : C.text1, fontSize: 12 });
      if (i < 2) arrow(s, x + 2.88, 1.17, 0.17);
    });
    table(s, [["Livello", "Quando", "Controlli"],
      ["Esplorare", "Farsi un'idea, preparare una discussione", "Plausibilità, ordini di grandezza, uno sguardo ai dati"],
      ["Lavorare", "Analisi interne che orientano attività", "+ dati e definizioni confermati, calcoli eseguiti, 2-3 valori ricontrollati"],
      ["Decidere o comunicare", "Direzione, esterno, decisioni sulle persone", "+ registro completo, verifica indipendente, scelte esplicite, specialisti"]],
      { y: 1.72, colW: [2.1, 3.0, 3.9], rowH: 0.55, fontSize: 11, blankCorner: false, accentCol: 2 });
    txt(s, "Alzano il livello", { x: 0.5, y: 4.0, w: 2.3, h: 0.5, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.8, 4.0, 3.25, 0.5, "Dati di qualità incerta", { fill: C.background2, fontSize: 12 });
    chip(s, 6.2, 4.0, 3.3, 0.5, "Conseguenze difficili da correggere", { fill: C.background2, fontSize: 12 });
    txt(s, "Più l'analisi pesa sulla decisione, più devono essere verificabili dati, calcoli e scelte.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Quattro fasi: una scheda pratica", "La sintesi operativa del modulo, organizzata per fasi e scritta come elenco di azioni da fare con l'AI. Comprendere: far descrivere il file, confermare colonne e definizioni, approvare la pulizia proposta, chiedere chi o che cosa manca nei dati. Elaborare: chiedere calcoli eseguiti con strumenti, dichiarare base e periodo degli indicatori, chiedere media e mediana insieme a un grafico, trattare le relazioni come ipotesi da verificare. Rappresentare: un titolo che dica il messaggio, periodo completo, unità e fonte dichiarati, previsioni con intervallo e ipotesi. Interpretare: distinguere osservato, stimato e simulato, chiedere opzioni con trade-off e conseguenze, proporzionare i controlli all'uso. E il messaggio del modulo, da lasciare ai partecipanti: l'AI rende l'analisi dei dati più accessibile, veloce ed esplorativa, e permette di ricavare informazioni utili anche senza programmare; la qualità dei risultati dipende da strumenti autorizzati e usati bene, da dati di qualità e dalla capacità di interpretazione. Suggerimento: chiedere ai partecipanti quale delle azioni della scheda applicheranno per prima su un file del proprio lavoro.");
    const f = [["Comprendere", ["Far descrivere il file", "Confermare colonne e definizioni", "Approvare la pulizia", "Chiedere chi manca nei dati"], C.background2], ["Elaborare", ["Calcoli eseguiti con strumenti", "Base e periodo dichiarati", "Media, mediana e un grafico", "Relazioni come ipotesi"], C.accent6], ["Rappresentare", ["Titolo con il messaggio", "Periodo, unità e fonte", "Previsioni con intervallo e ipotesi"], C.background2], ["Interpretare", ["Osservato, stimato, simulato", "Opzioni con trade-off", "Controlli proporzionati all'uso"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.12, 2.15, 2.9, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.22, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 5 }), { x: x + 0.15, y: 1.72, w: 1.92, h: 2.25, fontSize: 11, color: C.text1 });
    }
    banner(s, 4.15, "L'AI rende l'analisi più accessibile, veloce ed esplorativa. La qualità dipende da strumenti autorizzati e usati bene, dati di qualità e interpretazione.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 9 completiamo il secondo tema dell'area 'Esplorare le possibilità dell'AI'. Dopo testi e documenti, abbiamo esplorato dati e analisi. Il Tema 10 è dedicato all'AI multimodale e alla creazione di contenuti: immagini, audio, video, presentazioni, e il passaggio da una modalità all'altra. Ritroveremo un principio di questo modulo: un grafico o un'immagine ben fatti comunicano molto, e conviene che poggino su contenuti corretti. Altri temi collegati: assistenti, agenti e automazioni nel Tema 11; AI, dati e conoscenza aziendale nel Tema 14, con le condizioni organizzative e tecnologiche per rendere disponibili i dati di cui abbiamo parlato; opportunità e casi d'uso nel Tema 15, con la selezione e la valutazione dei progetti. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere contenuti.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi e documenti\nTema 9: dati e analisi (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.6, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 10: AI multimodale e creazione di contenuti", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Immagini, audio, video, presentazioni", { x: 5.4, y: 2.38, w: 3.9, h: 0.3, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 2.85, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 11: assistenti, agenti e automazioni", "Tema 14: dati e conoscenza aziendale", "Tema 15: opportunità e casi d'uso"], { space: 5 }), { x: 5.4, y: 3.2, w: 3.9, h: 1.5, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Il modulo si basa soprattutto su principi consolidati di statistica descrittiva e di lettura critica dei dati, che non dipendono da una singola fonte. Le capacità degli strumenti AI di analisi dei dati, in particolare la lettura di file, l'esecuzione di codice, il collegamento a fonti dati e la produzione di grafici, evolvono rapidamente e variano da strumento a strumento: prima di ogni edizione è consigliabile verificare le funzionalità degli strumenti autorizzati in azienda e aggiornare gli esempi. Tutti gli esempi numerici del modulo sono fittizi, tranne il quartetto di Anscombe: il caso delle vendite (file, tabella per regione, andamento del Centro, dashboard e registro delle operazioni), gli esempi su media e mediana, sugli scenari di prezzo, sulla proiezione con intervallo, sulle alternative di fornitura e sulla redditività dei clienti. Nessuna percentuale di risparmio o di produttività è attribuita all'uso dell'AI.");
    const src = [
      "Anscombe, F. J. (1973). Graphs in Statistical Analysis. The American Statistician, 27(1), 17-21.",
      "Vigen, T. (2015). Spurious Correlations. Hachette Books.",
      "Gli esempi di dati, grafici, tabelle e report presenti nelle slide sono fittizi, salvo il quartetto di Anscombe. Il caso delle vendite è coerente in tutto il modulo.",
      "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.5, fontSize: 13, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema9_AI_dati_analisi_REV.pptx" });
  await applyTheme("Tema9_AI_dati_analisi_REV.pptx", THEME);
  console.log("done");
})();
