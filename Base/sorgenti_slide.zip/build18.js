const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 18: Normativa, regole e governance dell'AI";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 18  ·  Normativa, regole e governance";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: o.fmt || "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5, X = o.x || 0.5, W = o.w || 9.0;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, X, y, W, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: X + 0.15, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: X + 0.15 + lw, y, w: W - 0.3 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }
  function govTag(s, active) {
    const st = ["Governance", "Norme", "Ruoli", "Policy", "Controlli", "Literacy"];
    const act = Array.isArray(active) ? active : [active];
    st.forEach((t, i) => {
      const x = 6.0 + i * 0.58, on = act.includes(i);
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.56, h: 0.26, rectRadius: 0.13, fill: { color: on ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "dimensione " + t });
      txt(s, t, { x, y: 0.42, w: 0.56, h: 0.26, fontSize: 6.5, bold: true, color: on ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 18", { placeholder: "kicker" });
    s.addText("Normativa, regole e governance dell'AI", { placeholder: "title" });
    s.addText("Area: Utilizzare l'AI responsabilmente", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al diciottesimo e ultimo tema del percorso, il secondo dell'area 'Utilizzare l'AI responsabilmente'. Nel Tema 17 abbiamo adottato il punto di vista di chi usa l'AI: rischi, precauzioni, comportamenti. Qui adottiamo il punto di vista dell'organizzazione: quali norme si applicano, quali responsabilità ha l'azienda, quali regole, controlli e competenze servono. È il confine decisivo indicato dal documento di perimetro: il Tema 17 riguarda che cosa l'utilizzatore deve riconoscere, proteggere e segnalare; il Tema 18 quali regole, responsabilità e controlli l'organizzazione deve definire. Due avvertenze importanti, che ripeteremo nella prossima slide. La prima: questo modulo è una formazione di consapevolezza, non un parere legale né un audit di conformità. La seconda: la normativa sull'AI è in evoluzione. Il regolamento europeo, l'AI Act, è stato modificato nel 2026 da un regolamento detto Digital Omnibus, che ha spostato alcune scadenze e riscritto alcune disposizioni. Le informazioni del modulo sono state verificate a ottobre 2026 e vanno ricontrollate sulle fonti ufficiali prima di ogni edizione. Suggerimento per l'apertura: chiedere ai partecipanti se sanno quali strumenti di AI sono approvati nella loro azienda, e chi decide quali lo sono. Nota per il relatore: i contenuti normativi sono stati verificati a ottobre 2026 sui testi ufficiali (EUR-Lex e Gazzetta Ufficiale); vanno ricontrollati prima di ogni edizione.");
  }
  {
    const s = content("Prima di cominciare", "Una slide di avvertenze, che il documento di perimetro chiede di rendere esplicite. Primo: questo modulo è una formazione di AI Awareness, non un parere legale né un audit di conformità. Serve a comprendere il quadro, le logiche e le domande da porsi; per valutare il rispetto degli obblighi applicabili a una specifica organizzazione servono approfondimenti e figure competenti, come i consulenti legali, il responsabile della protezione dei dati, le funzioni di compliance. Secondo: la normativa è in evoluzione. L'AI Act, il Regolamento europeo 2024/1689, entrato in vigore nell'agosto 2024, si applica in modo progressivo, con date diverse per obblighi diversi. Nel 2026 è stato modificato dal Regolamento 2026/1744, il cosiddetto Digital Omnibus sull'AI, pubblicato nella Gazzetta Ufficiale dell'Unione il 24 luglio 2026 ed entrato in vigore il 27 luglio 2026, che ha rinviato alcune scadenze e riscritto alcune disposizioni, tra cui l'articolo 4 sull'alfabetizzazione. Le informazioni del modulo sono state verificate a ottobre 2026. Terzo, una nota per il formatore: prima di ogni edizione, verificare il testo vigente e le date su EUR-Lex, sulla pagina della Commissione europea dedicata all'AI Act e sulla Gazzetta Ufficiale italiana. E non presentare mai una singola data come scadenza universale per tutti gli obblighi.");
    await card(s, 0.5, 1.15, 2.86, 3.0, { icon: "FiInfo", head: "Non è un parere legale", headSize: 14, bodySize: 12, body: "Formazione di consapevolezza, non audit di conformità. Per valutare gli obblighi servono figure competenti." });
    await card(s, 3.57, 1.15, 2.86, 3.0, { icon: "FiRefreshCw", head: "Norme in evoluzione", headSize: 14, bodySize: 12, fill: C.accent6, body: "AI Act (Reg. UE 2024/1689) modificato dal Digital Omnibus (Reg. UE 2026/1744, in vigore dal 27 luglio 2026)." });
    await card(s, 6.64, 1.15, 2.86, 3.0, { icon: "FiCalendar", head: "Verificato a ottobre 2026", headSize: 14, bodySize: 12, body: "Prima di ogni edizione: EUR-Lex, Commissione europea, Gazzetta Ufficiale. Nessuna data unica per tutti gli obblighi." });
    banner(s, 4.35, "Le date e i contenuti normativi di queste slide vanno ricontrollati sulle fonti ufficiali.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere i principali riferimenti normativi e i principi di governance dell'AI, riconoscendo le responsabilità delle organizzazioni che sviluppano, forniscono o usano sistemi di AI, e l'importanza di politiche, competenze, controlli e processi proporzionati ai rischi e agli obblighi applicabili. La consapevolezza da sviluppare: l'uso professionale dell'AI richiede non solo comportamenti prudenti dei singoli, come visto nel Tema 17, ma regole condivise, responsabilità identificabili, competenze adeguate e misure di controllo organizzative. E una frase che conviene sottolineare: la governance deve abilitare usi appropriati e conformi, senza coincidere con un elenco di divieti. Il messaggio centrale del documento di perimetro: l'uso dell'AI in azienda richiede responsabilità, regole, competenze e controlli proporzionati ai rischi e agli obblighi applicabili; la governance deve rendere possibile un'adozione consapevole, conforme e controllabile, senza ridursi a divieti o adempimenti formali.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 13,
      body: bullets(["Comprendere i riferimenti normativi e i principi di governance", "Riconoscere le responsabilità di chi sviluppa, fornisce o usa l'AI", "Capire il ruolo di politiche, competenze, controlli proporzionati"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 13,
      body: "Non bastano comportamenti prudenti dei singoli: servono regole condivise, responsabilità identificabili, competenze, controlli.\n\nLa governance abilita usi appropriati e conformi: non è un elenco di divieti." });
  }
  {
    const s = content("Tre piani da distinguere", "Il documento di perimetro chiede di distinguere tre piani, che useremo per tutto il modulo e che aiutano a non confondere questioni diverse. Gli obblighi normativi: quali disposizioni si applicano al sistema, all'organizzazione e alla specifica finalità d'uso. Sono decisi dal legislatore, e l'organizzazione deve rispettarli. Le responsabilità organizzative: chi propone, autorizza, attua, verifica, aggiorna e interrompe gli usi. Sono decise dall'organizzazione, e devono essere chiare. Le misure operative: politiche, competenze, procedure, controlli, monitoraggio, gestione di anomalie e incidenti. Sono gli strumenti con cui l'organizzazione rispetta gli obblighi e governa i rischi. I tre piani sono collegati, ma diversi. Un'organizzazione può rispettare formalmente gli obblighi normativi senza avere responsabilità chiare; può avere una policy scritta, una misura operativa, senza che nessuno sia responsabile di applicarla; può avere responsabilità chiare senza conoscere gli obblighi pertinenti. Una governance efficace tiene insieme i tre piani.");
    const p = [["FiBookOpen", "Obblighi normativi", "Quali disposizioni si applicano: al sistema, all'organizzazione, alla finalità", "Decisi dal legislatore"], ["FiUsers", "Responsabilità organizzative", "Chi propone, autorizza, attua, verifica, aggiorna, interrompe", "Decise dall'organizzazione"], ["FiSettings", "Misure operative", "Politiche, competenze, procedure, controlli, monitoraggio, incidenti", "Gli strumenti per rispettare e governare"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.75, i === 1 ? C.accent6 : C.background2, p[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.66, p[i][0]);
      txt(s, p[i][1], { x: x + 0.15, y: 2.0, w: 2.56, h: 0.5, fontSize: 15, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, p[i][2], { x: x + 0.15, y: 2.52, w: 2.56, h: 0.8, fontSize: 12, color: C.text1, align: "center" });
      txt(s, p[i][3], { x: x + 0.15, y: 3.35, w: 2.56, h: 0.45, fontSize: 11, bold: true, color: C.accent1, align: "center" });
    }
    banner(s, 4.1, "Collegati ma diversi: una policy senza responsabili, o responsabili senza conoscere gli obblighi, non è governance.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Otto domande guida", "Le otto domande guida accompagnano il modulo. Perché l'AI è soggetta a una regolamentazione specifica, e perché serve una governance. Come si colloca l'AI Act rispetto al GDPR e ad altre discipline. Che cosa significa classificare un sistema secondo l'approccio basato sul rischio. Quali responsabilità si collegano ai ruoli di provider e deployer. Quali indicazioni dovrebbe contenere una policy aziendale sull'AI. Come si organizzano controlli, supervisione e valutazione dei rischi. Che cosa richiede un approccio contestualizzato all'AI literacy, che riguarda direttamente questo percorso. E come rendere la governance proporzionata alle attività e alle dimensioni dell'azienda. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Perché una regolamentazione e una governance?", "AI Act, GDPR e altre discipline?", "Che cosa significa la classificazione per rischio?", "Quali responsabilità per provider e deployer?", "Che cosa contiene una policy aziendale?", "Come organizzare controlli e supervisione?", "Che cosa richiede l'AI literacy contestualizzata?", "Come rendere la governance proporzionata?"], 4, 1.12, 1.5, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in sei dimensioni. Fondamenti e finalità della governance, nel 18.1. Fonti normative e logica dell'AI Act, nel 18.2 e 18.3. Ruoli della filiera e responsabilità aziendali, nel 18.4. Policy, controlli, rischi e supervisione, nel 18.5 e 18.6. AI literacy come misura organizzativa, nel 18.7. Coordinamento e proporzionalità della governance, nel 18.8. La sequenza consigliata, per non ripetere tre volte una panoramica sulla governance, è: finalità, nel 18.1; policy, nel 18.5; sistema organizzativo, nel 18.8. Nelle slide, l'indicatore in alto a destra ricorda la dimensione: Governance, Norme, Ruoli, Policy, Controlli, Literacy. Quattro integrazioni evitano quattro equivoci. A: non tutta l'AI è ad alto rischio secondo l'AI Act. B: acquistare un sistema conforme non rende conforme ogni suo uso. C: un corso di AI Awareness non equivale automaticamente alla conformità all'articolo 4. D: la governance deve essere proporzionata, non necessariamente complessa. Sulle slide gli equivoci sono numerati da 1 a 4, per non confonderli con le lettere dei quattro esempi, che non coincidono: per esempio l'equivoco A si illustra con l'esempio B.");
    const d = [["FiCompass", "Governance", "18.1  18.8"], ["FiBookOpen", "Norme", "18.2  18.3"], ["FiUsers", "Ruoli", "18.4"], ["FiFileText", "Policy", "18.5"], ["FiShield", "Controlli", "18.6"], ["FiBook", "Literacy", "18.7"]];
    for (let i = 0; i < 6; i++) {
      const x = 0.5 + i * 1.53;
      shapeBox(s, x, 1.15, 1.4, 1.5, C.background2, d[i][1]);
      await iconCircle(s, x + 0.43, 1.23, 0.54, d[i][0]);
      txt(s, d[i][1], { x: x + 0.05, y: 1.82, w: 1.3, h: 0.38, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.05, y: 2.2, w: 1.3, h: 0.32, fontSize: 11, bold: true, color: C.accent1, align: "center" });
    }
    txt(s, "Quattro equivoci da evitare", { x: 0.5, y: 2.8, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const p = ["1  Non tutta l'AI è ad alto rischio", "2  Sistema conforme non è uso conforme", "3  Un corso non è conformità all'articolo 4", "4  Proporzionata, non necessariamente complessa"];
    p.forEach((t, i) => chip(s, 0.5 + (i % 2) * 4.6, 3.17 + Math.floor(i / 2) * 0.6, 4.4, 0.5, t, { fill: C.accent6, fontSize: 12 }));
    txt(s, "Sequenza: finalità (18.1), policy (18.5), sistema organizzativo (18.8).", { x: 0.5, y: 4.45, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi. Cinque hanno priorità molto alta: il quadro normativo, l'approccio basato sul rischio, i ruoli e le responsabilità, le politiche aziendali, l'AI literacy. Tre hanno priorità alta: la governance, i rischi e controlli, la governance proporzionata. Il documento indica come priorità principale 18.3, 18.4, 18.5 e 18.7, perché distinguono categorie normative, soggetti obbligati, comportamenti regolati e alfabetizzazione contestualizzata. Da comprendere e applicare: leggere il caso d'uso prima della classificazione; distinguere provider e deployer; riconoscere quando servono policy o autorizzazioni; comprendere il ruolo dell'AI literacy. Da conoscere: il quadro di riferimento, l'applicazione progressiva delle disposizioni, gli elementi di un modello di governance, le principali responsabilità. Solo da accennare: analisi giuridiche articolo per articolo, audit legali, calcolo avanzato del rischio, procedure di conformità specializzate, sistemi di gestione completi, implementazione tecnica dei controlli. Confini: non ripetiamo le precauzioni dell'utilizzatore del Tema 17, né la formazione come leva di adozione del Tema 16, né i metodi di scelta dei casi d'uso del Tema 15.");
    pathSlide(s, [["18.1", "Perché serve una governance", "Alta"], ["18.2", "Il quadro normativo", "Alta"], ["18.3", "L'approccio basato sul rischio", "Alta"], ["18.4", "Ruoli e responsabilità", "Alta"], ["18.5", "Politiche aziendali", "Alta"], ["18.6", "Rischi, controlli e supervisione", "Alta"], ["18.7", "AI literacy e responsabilità", "Alta"], ["18.8", "Una governance proporzionata", "Alta"]],
      [["Comprendere e applicare", "Caso d'uso prima della classificazione, provider e deployer, policy, AI literacy", C.accent1, C.background1], ["Conoscere", "Quadro normativo, applicazione progressiva, elementi di governance", C.accent6, C.text1], ["Solo accennare", "Analisi giuridiche, audit, calcolo del rischio, sistemi di gestione", C.background2, C.text1]]);
    txt(s, "Priorità molto alta: 18.2, 18.3, 18.4, 18.5, 18.7", { x: 0.5, y: 4.95, w: 5.6, h: 0.25, fontSize: 10, italic: true, color: C.accent5 });
  }

  // =====================================================================
  section("18.1 Perché una governance");
  divider("18.1", "Perché serve una governance", "Governare l'AI significa definire condizioni, responsabilità e verifiche che consentano usi appropriati e controllabili", "Primo sottotema, priorità alta, da comprendere. La prima domanda guida: perché serve una governance? Vediamo che cosa significa governance dell'AI, la differenza tra il comportamento del singolo e la responsabilità dell'organizzazione, i principi di riferimento, la differenza tra conformità e governo complessivo, le conseguenze degli usi frammentati, il ciclo di vita, la proporzionalità e la governance abilitante. Integrazione D. Il documento distingue: il 18.1 spiega perché serve, il 18.8 come coordinarne le componenti.");
  {
    const s = content("Che cos'è la governance dell'AI", "Il sottotema parte dal significato e dalle finalità della governance dell'AI. In termini semplici, la governance è l'insieme delle regole, delle responsabilità, dei processi e dei controlli con cui un'organizzazione decide come usare l'AI, e verifica che venga usata come deciso. Risponde a domande come: quali strumenti si usano, per quali scopi, con quali informazioni? Chi decide se un nuovo strumento o un nuovo uso è accettabile? Chi controlla, e come? Che cosa succede quando qualcosa va storto? Come si aggiornano le regole quando cambiano gli strumenti? La consapevolezza del sottotema lo riassume: governare l'AI significa definire condizioni, responsabilità e verifiche che consentano usi appropriati e controllabili. Notate le parole 'che consentano': la governance non serve solo a impedire, ma a rendere possibile. Il sottotema chiede anche di distinguere il comportamento del singolo utilizzatore, di cui abbiamo parlato nel Tema 17, dalla responsabilità dell'organizzazione. Il singolo risponde delle proprie scelte; l'organizzazione risponde di avere creato le condizioni perché quelle scelte possano essere giuste: strumenti adatti, regole chiare, competenze, supporto, controlli.");
    govTag(s, 0);
    txt(s, "Le domande della governance", { x: 0.5, y: 1.1, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    rowList(s, ["Quali strumenti, per quali scopi, con quali informazioni?", "Chi decide se un nuovo strumento o uso è accettabile?", "Chi controlla, e come? Che cosa succede quando qualcosa va storto?", "Come si aggiornano le regole quando cambiano gli strumenti?"], { y: 1.45, h: 0.42, gap: 0.05, fontSize: 12 });
    docBox(s, 0.5, 3.5, 4.35, 1.3, "Il singolo", "Risponde delle proprie scelte d'uso.", { fontSize: 13 });
    docBox(s, 5.15, 3.5, 4.35, 1.3, "L'organizzazione", "Risponde delle condizioni: strumenti, regole, competenze, supporto, controlli.", { fontSize: 13, fill: C.accent6 });
  }
  {
    const s = content("Principi di riferimento", "Il sottotema richiama alcuni principi di affidabilità, trasparenza, equità e responsabilità, e la relazione tra opportunità, innovazione, rischio e controllo. Questi principi ricorrono in molti documenti internazionali sull'AI: le Linee guida etiche per un'AI affidabile, pubblicate nel 2019 dal gruppo di esperti di alto livello della Commissione europea, che hanno ispirato l'AI Act; i Principi dell'OCSE sull'intelligenza artificiale, adottati nel 2019 e aggiornati nel 2024; la Raccomandazione dell'UNESCO sull'etica dell'AI del 2021. Formulazioni diverse, ma un nucleo comune. Affidabilità: i sistemi funzionano come previsto, in modo robusto e sicuro. Trasparenza: si sa quando si usa l'AI e, nei limiti del possibile, come funziona. Equità: i sistemi non producono discriminazioni ingiustificate, come visto nel Tema 17. Responsabilità: è chiaro chi risponde delle decisioni e delle conseguenze. A questi si aggiungono spesso la supervisione umana, la tutela della riservatezza e il benessere sociale e ambientale. I principi sono il perché delle regole: quando una regola specifica non c'è, o non è chiara, aiutano a orientare la decisione.");
    govTag(s, 0);
    await iconGrid(s, [
      { icon: "FiCheckCircle", head: "Affidabilità", body: "Funziona come previsto, robusto e sicuro" },
      { icon: "FiEye", head: "Trasparenza", body: "Si sa quando si usa l'AI, e come funziona" },
      { icon: "FiUsers", head: "Equità", body: "Nessuna discriminazione ingiustificata" },
      { icon: "FiUserCheck", head: "Responsabilità", body: "È chiaro chi risponde di decisioni e conseguenze" },
    ], 4, { y: 1.15, H: 1.75, headSize: 13, bodySize: 11 });
    rowsLabel(s, [["UE, 2019", "Linee guida etiche per un'AI affidabile (gruppo di esperti della Commissione)"], ["OCSE, 2019 e 2024", "Principi sull'intelligenza artificiale"], ["UNESCO, 2021", "Raccomandazione sull'etica dell'AI"]], { y: 3.05, h: 0.4, lw: 1.9, fontSize: 11 });
    txt(s, "I principi sono il perché delle regole: orientano quando una regola manca.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Conformità e governo", "Il sottotema chiede di distinguere la conformità normativa dal governo complessivo dell'AI, e gli obblighi imposti dalla legge dalle scelte organizzative ulteriori. La conformità normativa è il rispetto degli obblighi di legge: l'AI Act, il GDPR, il diritto del lavoro, le norme di settore. È necessaria, ma non sufficiente. Il governo complessivo dell'AI comprende anche scelte che la legge non impone, ma che l'organizzazione fa per gestire i rischi, cogliere le opportunità e proteggere i propri interessi: quali strumenti adottare, quali usi incoraggiare, come proteggere i segreti aziendali, come mantenere la qualità del servizio, come formare le persone oltre il minimo. Molti rischi visti nel Tema 17 non sono regolati da norme specifiche sull'AI, ma riguardano comunque l'azienda: un errore in un'offerta, un danno reputazionale, una perdita di know-how. Per questo il documento chiede di non confondere i due piani: una governance che si limita alla conformità lascia scoperti rischi importanti; una governance che non conosce gli obblighi rischia di violarli. La distinzione serve anche nella comunicazione interna: dire 'è obbligatorio per legge' o 'è una scelta dell'azienda' cambia il modo in cui le persone percepiscono la regola, e conviene essere precisi.");
    govTag(s, 0);
    await twoPanel(s, "Conformità normativa", bullets(["Rispetto degli obblighi di legge", "AI Act, GDPR, lavoro, norme di settore", "Necessaria, non sufficiente"], { space: 5 }), "Governo complessivo", bullets(["Anche scelte non imposte dalla legge", "Strumenti, usi, segreti, qualità, formazione", "Rischi non regolati ma reali"], { space: 5 }), { y: 1.15, h: 2.45, li: "FiBookOpen", ri: "FiCompass" });
    banner(s, 3.8, "Solo conformità lascia scoperti rischi; senza conoscere gli obblighi si rischia di violarli. E dire 'è la legge' o 'è una scelta' non è lo stesso.", { h: 1.0, fontSize: 13 });
  }
  {
    const s = content("Il prezzo dell'assenza", "Il sottotema chiede di riconoscere le conseguenze di usi frammentati, non conosciuti o privi di coordinamento. È ciò che accade, in molte organizzazioni, quando l'AI arriva prima della governance. Gli usi frammentati: reparti diversi adottano strumenti diversi, con regole diverse o senza regole, come visto nel Tema 16. Gli usi non conosciuti: l'organizzazione non sa quali strumenti vengono usati, da chi, con quali informazioni; è lo Shadow AI visto nei Temi 16 e 17. Gli usi privi di coordinamento: nessuno ha una visione d'insieme, nessuno decide sui casi dubbi, nessuno verifica. Le conseguenze sono di vari tipi. Rischi non controllati: informazioni riservate in servizi esterni, decisioni sulle persone senza supervisione, contenuti ingannevoli. Obblighi non rispettati, perché nessuno ha verificato se un uso rientra in una categoria regolata. Costi duplicati e opportunità perse. Incertezza per le persone, che non sanno che cosa possono fare, e si astengono o fanno da sole. La governance non serve a eliminare l'iniziativa, ma a dare a questi usi un quadro: conoscerli, valutarli, guidarli.");
    govTag(s, 0);
    await iconGrid(s, [
      { icon: "FiGrid", head: "Frammentati", body: "Reparti diversi, strumenti e regole diversi" },
      { icon: "FiEyeOff", head: "Non conosciuti", body: "Chi usa che cosa, con quali informazioni? (Shadow AI)" },
      { icon: "FiShuffle", head: "Non coordinati", body: "Nessuna visione d'insieme, nessuno decide o verifica" },
      { icon: "FiAlertTriangle", head: "Rischi non controllati", body: "Riservatezza, decisioni, contenuti" },
      { icon: "FiBookOpen", head: "Obblighi non rispettati", body: "Nessuno ha verificato le categorie regolate" },
      { icon: "FiHelpCircle", head: "Incertezza", body: "Le persone si astengono, o fanno da sole" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Non eliminare l'iniziativa, ma darle un quadro: conoscere, valutare, guidare.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Lungo tutto il ciclo di vita", "Il sottotema chiede di considerare le responsabilità lungo il ciclo di vita: selezione, introduzione, uso, aggiornamento ed eventuale dismissione, e la necessità di adattare i controlli all'evoluzione tecnologica. È anche una delle precisazioni trasversali del documento: regole e controlli vanno aggiornati quando cambiano strumenti, usi e rischi, e non si esauriscono nell'approvazione iniziale. Le fasi. Selezione: quale strumento, per quale scopo, con quali condizioni del fornitore. Introduzione: configurazione, permessi, istruzioni, formazione, verifica iniziale. Uso: supporto, controlli, monitoraggio, gestione delle anomalie. Aggiornamento: quando cambia lo strumento, il fornitore aggiorna il modello, cambiano gli usi o le norme, si rivalutano rischi e regole. Dismissione: quando uno strumento viene abbandonato, che cosa succede ai dati, alle integrazioni, alle pratiche. Molte organizzazioni concentrano l'attenzione sulla prima approvazione, e trascurano il resto. Ma con l'AI i cambiamenti sono frequenti: un aggiornamento del modello può cambiarne il comportamento, una nuova funzione può aprire nuovi usi e nuovi rischi, come l'aggiunta di capacità operative vista nel Tema 11.");
    govTag(s, 0);
    const st = [["Selezione", "Strumento, scopo, condizioni"], ["Introduzione", "Configurazione, permessi, formazione"], ["Uso", "Supporto, controlli, monitoraggio"], ["Aggiornamento", "Nuovi modelli, usi, norme: rivalutare"], ["Dismissione", "Dati, integrazioni, pratiche"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.62, 1.55, i === 3 ? C.accent6 : C.background2, e[0]);
      txt(s, String(i + 1), { x: x + 0.1, y: 1.2, w: 0.5, h: 0.4, fontSize: 18, bold: true, color: C.accent1 });
      txt(s, e[0], { x: x + 0.1, y: 1.6, w: 1.45, h: 0.38, fontSize: 13, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.1, y: 1.98, w: 1.45, h: 0.65, fontSize: 11, color: C.text2 });
      if (i < 4) arrow(s, x + 1.63, 1.75, 0.19);
    });
    banner(s, 2.9, "Non si esaurisce nell'approvazione iniziale: regole e controlli si aggiornano quando cambiano strumenti, usi e rischi.", { h: 0.85, fontSize: 14 });
    txt(s, "Con l'AI i cambiamenti sono frequenti: un aggiornamento del modello cambia il comportamento; una nuova funzione apre nuovi usi e rischi.", { x: 0.5, y: 3.95, w: 9, h: 0.75, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Abilitante e proporzionata", "Gli ultimi punti del sottotema: il ruolo delle regole nel rendere possibile un'adozione sicura, la governance abilitante contro quella puramente restrittiva, e la proporzionalità dei presidi alla finalità, ai rischi e al contesto. La governance puramente restrittiva si esprime soprattutto con divieti: non usare, non caricare, non condividere. Riduce alcuni rischi, ma ha effetti collaterali noti: le persone non sanno che cosa possono fare, si astengono anche dove l'AI sarebbe utile, o usano strumenti non autorizzati, come visto con lo Shadow AI. La governance abilitante dice anche che cosa si può fare, con quali strumenti, a quali condizioni, e offre supporto: rende possibile un'adozione sicura. L'integrazione D aggiunge la proporzionalità: la governance deve essere proporzionata, non necessariamente complessa. Una piccola azienda che usa un assistente approvato per scrivere bozze non ha bisogno della stessa struttura di una banca che usa l'AI per valutare il credito. Ma il documento aggiunge un'avvertenza decisiva: la proporzionalità non esonera dagli obblighi pertinenti. Essere piccoli può giustificare presidi più semplici, non l'assenza degli obblighi che si applicano. Torneremo su questo nel 18.8.");
    govTag(s, 0);
    await twoPanel(s, "Puramente restrittiva", "Soprattutto divieti: non usare, non caricare, non condividere.\n\nEffetti: astensione dove servirebbe, Shadow AI.", "Abilitante", "Dice anche che cosa si può fare, con quali strumenti, a quali condizioni, con quale supporto.\n\nRende possibile un'adozione sicura.", { y: 1.15, h: 2.3, li: "FiSlash", ri: "FiUnlock" });
    shapeBox(s, 0.5, 3.6, 9.0, 1.2, C.accent1, "proporzionalità");
    txt(s, [{ text: "Proporzionata, non necessariamente complessa. ", options: { bold: true, color: C.background1 } }, { text: "Ma la proporzionalità non esonera dagli obblighi pertinenti: essere piccoli giustifica presidi più semplici, non l'assenza degli obblighi.", options: { color: C.accent6 } }], { x: 0.7, y: 3.6, w: 8.6, h: 1.2, fontSize: 14, valign: "middle" });
  }
  keySlide("Governare l'AI significa definire condizioni, responsabilità e verifiche che consentano usi appropriati e controllabili.", "Sottotema 18.1  ·  Perché serve una governance", "Concetto chiave del primo sottotema. La governance è l'insieme di regole, responsabilità, processi e controlli con cui l'organizzazione decide e verifica l'uso dell'AI. Si basa su principi comuni: affidabilità, trasparenza, equità, responsabilità. Non coincide con la conformità normativa. Senza governance, gli usi sono frammentati, sconosciuti, non coordinati. Copre tutto il ciclo di vita. Deve essere abilitante e proporzionata, senza che la proporzionalità diventi un'esenzione. Esercizio suggerito: elencare in gruppo tre domande sull'uso dell'AI nel proprio reparto a cui oggi nessuno saprebbe rispondere, come 'chi decide se possiamo usare questo strumento?'.");

  // =====================================================================
  section("18.2 Il quadro normativo");
  divider("18.2", "Il quadro normativo", "L'AI Act è centrale, ma non sostituisce le altre norme applicabili alla specifica attività", "Uno dei sottotemi a priorità molto alta, da conoscere e comprendere. La seconda domanda guida: come si colloca l'AI Act rispetto al GDPR e ad altre discipline? Vediamo obiettivi e impostazione dell'AI Act, le grandi categorie di obblighi, l'applicazione progressiva e le modifiche del 2026, il rapporto con il GDPR e con altre discipline, il quadro italiano, e la differenza tra atti vincolanti, orientamenti, standard e policy. Integrazione A. Nota per il formatore: verificare sempre il testo vigente e il calendario sulle fonti ufficiali; non presentare una singola data come scadenza universale.");
  {
    const s = content("L'AI Act: obiettivi e impostazione", "Il Regolamento (UE) 2024/1689, noto come AI Act, è la prima normativa organica sull'intelligenza artificiale adottata da una grande giurisdizione. È un regolamento europeo: si applica direttamente in tutti gli Stati membri, senza bisogno di recepimento, anche se lascia spazio a disposizioni nazionali su alcuni aspetti, come le autorità di vigilanza e le sanzioni. Gli obiettivi dichiarati sono due, da tenere insieme: tutelare la salute, la sicurezza e i diritti fondamentali delle persone di fronte ai rischi dell'AI; e favorire il buon funzionamento del mercato interno, cioè regole uguali in tutta l'Unione, e l'innovazione. L'impostazione è basata sul rischio: gli obblighi non riguardano l'AI in generale, ma dipendono da che cosa fa un sistema e per quale finalità è usato. Lo vedremo nel 18.3. I destinatari sono diversi: soprattutto i fornitori, cioè chi sviluppa e immette sul mercato i sistemi, e i deployer, cioè chi li usa in ambito professionale, oltre a importatori, distributori e fornitori di modelli per finalità generali. Lo vedremo nel 18.4. L'AI Act si applica anche a soggetti fuori dall'Unione, quando i loro sistemi sono immessi sul mercato europeo o i loro output sono usati nell'Unione.");
    govTag(s, 1);
    docBox(s, 0.5, 1.12, 9.0, 0.88, "Regolamento (UE) 2024/1689, AI Act", "Regolamento europeo: si applica direttamente in tutti gli Stati membri, con spazio per disposizioni nazionali su alcuni aspetti.", { fontSize: 13, fill: C.accent6 });
    await iconGrid(s, [
      { icon: "FiShield", head: "Tutela", body: "Salute, sicurezza, diritti fondamentali" },
      { icon: "FiGlobe", head: "Mercato interno", body: "Regole uguali in tutta l'Unione, innovazione" },
      { icon: "FiBarChart2", head: "Basato sul rischio", body: "Obblighi secondo ciò che fa il sistema e la finalità (18.3)" },
      { icon: "FiUsers", head: "Destinatari", body: "Fornitori, deployer, importatori, distributori, modelli generali (18.4)" },
    ], 4, { y: 2.1, H: 1.85, headSize: 13, bodySize: 11 });
    banner(s, 4.15, "Si applica anche a soggetti fuori dall'Unione, se i sistemi o i loro output sono usati nell'Unione.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Le grandi categorie di obblighi", "Il sottotema chiede un'introduzione alle grandi categorie dell'AI Act, che approfondiremo nel 18.3. Le pratiche vietate: usi dell'AI considerati inaccettabili, come la manipolazione che sfrutta vulnerabilità, il punteggio sociale, il riconoscimento delle emozioni sul luogo di lavoro e a scuola, salvo eccezioni. I sistemi ad alto rischio: sistemi usati in ambiti in cui possono incidere in modo significativo su salute, sicurezza o diritti, come l'occupazione, l'istruzione, l'accesso a servizi essenziali. Sono soggetti agli obblighi più articolati, soprattutto per i fornitori, ma anche per i deployer. Gli obblighi di trasparenza: per alcuni sistemi, come quelli che interagiscono con le persone o generano contenuti sintetici, bisogna informare le persone o marcare i contenuti. I modelli di AI per finalità generali, come i grandi modelli linguistici: i loro fornitori hanno obblighi specifici, per esempio di documentazione e di rispetto del diritto d'autore, e obblighi aggiuntivi per i modelli con rischio sistemico. Tutto il resto, cioè la grande maggioranza degli usi, non è soggetto a obblighi specifici dell'AI Act, salvo l'alfabetizzazione dell'articolo 4. Ma, come dice l'integrazione A, questo non significa assenza di rischi o di altri obblighi.");
    govTag(s, 1);
    const c = [["Pratiche vietate", "Usi inaccettabili: manipolazione, punteggio sociale, emozioni al lavoro e a scuola", "A86F1C", C.background1], ["Alto rischio", "Ambiti che incidono su salute, sicurezza, diritti: lavoro, istruzione, servizi essenziali", HEX.a1, C.background1], ["Trasparenza", "Informare le persone, marcare i contenuti sintetici", C.accent6, C.text1], ["Modelli per finalità generali", "Obblighi dei loro fornitori: documentazione, diritto d'autore, rischio sistemico", "D9ECEA", C.text1], ["Tutto il resto", "La maggioranza degli usi: nessun obbligo specifico dell'AI Act, salvo l'articolo 4", C.background2, C.text1]];
    c.forEach((e, i) => {
      const y = 1.12 + i * 0.62;
      shapeBox(s, 0.5, y, 9.0, 0.55, e[2], e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.6, h: 0.55, fontSize: 13, bold: true, color: e[3], valign: "middle" });
      txt(s, e[1], { x: 3.3, y, w: 6.1, h: 0.55, fontSize: 12, color: e[3], valign: "middle" });
    });
    banner(s, 4.3, "Nessun obbligo specifico non significa nessun rischio né nessun altro obbligo.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Un'applicazione progressiva", "Il sottotema chiede di conoscere l'applicazione progressiva, le eccezioni e le disposizioni transitorie, e la nota per il formatore è esplicita: non presentare una singola data come scadenza universale. La tabella riassume le principali tappe, verificate a ottobre 2026, comprese le modifiche del Regolamento 2026/1744, il Digital Omnibus. L'AI Act è entrato in vigore il 1° agosto 2024. Dal 2 febbraio 2025 si applicano le pratiche vietate e le disposizioni generali, compreso l'articolo 4 sull'alfabetizzazione, poi riscritto dal Digital Omnibus. Dal 2 agosto 2025 si applicano gli obblighi per i fornitori di modelli per finalità generali e le regole sulla governance pubblica e sulle sanzioni. Il 2 agosto 2026 è la data generale di applicazione, compresi gli obblighi di trasparenza dell'articolo 50. Il Digital Omnibus ha però rinviato gli obblighi per i sistemi ad alto rischio: al 2 dicembre 2027 per quelli dell'Allegato III, e al 2 agosto 2028 per quelli collegati a prodotti regolamentati dell'Allegato I. Ha inoltre previsto un periodo transitorio di quattro mesi, fino al 2 dicembre 2026, per la marcatura dei contenuti sintetici dei sistemi già sul mercato prima del 2 agosto 2026. Ha anche introdotto due nuovi divieti, sui contenuti intimi generati senza consenso e sul materiale pedopornografico: la data da cui si applicano non è riportata nella tabella, perché non è stato possibile verificarla sul testo ufficiale, e va controllata su EUR-Lex. Date confermate sul Regolamento 2026/1744 pubblicato nella Gazzetta Ufficiale dell'Unione il 24 luglio 2026. Altre eccezioni e regimi transitori esistono per casi specifici. Tutto da ricontrollare prima di ogni edizione.");
    govTag(s, 1);
    table(s, [["Data", "Che cosa si applica (sintesi, verificata a ottobre 2026)"],
      ["1 ago 2024", "Entrata in vigore dell'AI Act"],
      ["2 feb 2025", "Pratiche vietate; disposizioni generali, compreso l'articolo 4"],
      ["2 ago 2025", "Modelli per finalità generali; governance pubblica; sanzioni"],
      ["2 ago 2026", "Applicazione generale, compresa la trasparenza (art. 50)"],
      ["2 dic 2026", "Fine del transitorio per la marcatura dei sistemi già sul mercato"],
      ["2 dic 2027", "Alto rischio, Allegato III (rinviato dal Digital Omnibus)"],
      ["2 ago 2028", "Alto rischio, Allegato I: prodotti regolamentati (rinviato)"]],
      { y: 1.12, colW: [1.6, 7.4], rowH: 0.4, accentCol: 0, fontSize: 11, blankCorner: false });
    banner(s, 4.45, "Nessuna data unica per tutti gli obblighi. Eccezioni e transitori: verificare sempre su EUR-Lex.", { h: 0.5, fontSize: 13 });
  }
  {
    const s = content("AI Act e GDPR", "Il sottotema chiede di chiarire il rapporto con il GDPR, il Regolamento generale sulla protezione dei dati, in vigore dal 2018. È una delle precisazioni trasversali del documento: la conformità all'AI Act e la conformità al GDPR non sono equivalenti. Le due norme hanno oggetti diversi. L'AI Act regola i sistemi di AI, in base alla loro funzione e al rischio. Il GDPR regola il trattamento dei dati personali, con qualsiasi tecnologia. Quando un sistema di AI tratta dati personali, cosa che accade molto spesso, si applicano entrambi. Alcuni esempi di disposizioni del GDPR particolarmente rilevanti per l'AI: i principi di liceità, minimizzazione e limitazione della finalità, visti nel Tema 17 dal punto di vista dell'utilizzatore; l'articolo 22, che riguarda le decisioni basate unicamente su un trattamento automatizzato che producono effetti giuridici o significativi sulle persone; l'articolo 35, sulla valutazione d'impatto sulla protezione dei dati per i trattamenti a rischio elevato; gli obblighi di informazione verso le persone; le regole sui trasferimenti di dati fuori dall'Unione, rilevanti quando si usano servizi di fornitori extraeuropei. Un sistema non qualificato ad alto rischio dall'AI Act può comunque richiedere, per esempio, una valutazione d'impatto secondo il GDPR. Gli approfondimenti sono del responsabile della protezione dei dati.");
    govTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 1.3, "AI Act", "Regola i sistemi di AI, secondo funzione e rischio.", { fontSize: 13 });
    docBox(s, 5.15, 1.15, 4.35, 1.3, "GDPR", "Regola il trattamento dei dati personali, con qualsiasi tecnologia.", { fontSize: 13, fill: C.accent6 });
    txt(s, "Disposizioni del GDPR spesso rilevanti per l'AI", { x: 0.5, y: 2.7, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    rowList(s, ["Principi: liceità, minimizzazione, limitazione della finalità", "Art. 22: decisioni unicamente automatizzate con effetti significativi", "Art. 35: valutazione d'impatto per trattamenti a rischio elevato; informazioni; trasferimenti extra UE"], { y: 3.05, h: 0.42, gap: 0.05, fontSize: 12 });
    txt(s, "Conformità all'AI Act e al GDPR non sono equivalenti: spesso si applicano entrambi.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Non solo AI Act", "Il sottotema chiede di riconoscere la rilevanza di altre discipline: diritto d'autore, tutela dei consumatori, lavoro, discipline settoriali. La consapevolezza del sottotema: l'AI Act è centrale, ma non sostituisce le altre norme applicabili alla specifica attività. Alcuni esempi. Il diritto d'autore, visto nel Tema 17: riguarda sia i materiali usati con l'AI sia la tutela degli output; la normativa europea sul diritto d'autore prevede, per esempio, regole sull'estrazione di testo e dati. La tutela dei consumatori: pratiche commerciali scorrette, pubblicità ingannevole, informazioni ai clienti, rilevanti per chatbot, contenuti promozionali e recensioni. Il diritto del lavoro: in Italia, per esempio, le norme sui controlli a distanza dei lavoratori e gli obblighi di informazione sui sistemi decisionali o di monitoraggio automatizzati, che si applicano quando l'AI riguarda la gestione del personale. Le discipline settoriali: finanza, assicurazioni, sanità, dispositivi medici, trasporti, ciascuna con regole proprie. La responsabilità civile per danni, la sicurezza dei prodotti, la cybersicurezza. Per ogni uso rilevante, la domanda non è solo 'che cosa dice l'AI Act?', ma 'quali norme si applicano a questa attività?'.");
    govTag(s, 1);
    await iconGrid(s, [
      { icon: "FiCopy", head: "Diritto d'autore", body: "Materiali usati, tutela degli output, estrazione di dati" },
      { icon: "FiShoppingBag", head: "Consumatori", body: "Pratiche scorrette, pubblicità, informazioni ai clienti" },
      { icon: "FiBriefcase", head: "Lavoro", body: "Controlli a distanza, informazione su sistemi automatizzati" },
      { icon: "FiLayers", head: "Discipline settoriali", body: "Finanza, assicurazioni, sanità, dispositivi, trasporti" },
      { icon: "FiAlertCircle", head: "Responsabilità e prodotti", body: "Danni, sicurezza dei prodotti" },
      { icon: "FiShield", head: "Cybersicurezza", body: "Obblighi di sicurezza dei sistemi e delle reti" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Non solo 'che cosa dice l'AI Act?', ma 'quali norme si applicano a questa attività?'.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Il quadro italiano", "Il sottotema chiede un cenno al quadro legislativo italiano, da verificare nella versione vigente, e alla relazione tra regolamento europeo e discipline nazionali. L'Italia ha adottato la Legge 23 settembre 2025, n. 132, sull'intelligenza artificiale, in vigore dal 10 ottobre 2025, tra le prime leggi nazionali organiche in materia nell'Unione. La legge si affianca all'AI Act, senza sostituirlo, e contiene principi generali e disposizioni su alcuni ambiti. Alcuni elementi, da verificare. Designa le autorità nazionali per l'AI: l'Agenzia per l'Italia Digitale, AgID, e l'Agenzia per la Cybersicurezza Nazionale, ACN, con compiti diversi di promozione, notifica, vigilanza e sanzione. Nel lavoro, richiama i principi di sicurezza, affidabilità e trasparenza, e l'obbligo del datore di lavoro di informare i lavoratori sull'uso dell'AI, nei casi e modi previsti dalla normativa esistente. Nelle professioni intellettuali, limita l'AI ad attività strumentali e di supporto, con prevalenza del lavoro del professionista e obblighi di informazione verso i clienti. Nella sanità, mantiene la decisione in capo al medico. Sul diritto d'autore, chiarisce che sono tutelate le opere dell'ingegno umano, anche create con l'ausilio dell'AI. Delega inoltre il Governo ad adottare decreti legislativi entro dodici mesi dall'entrata in vigore della legge: il loro stato va verificato. Testo verificato sulla Gazzetta Ufficiale, Serie Generale n. 223 del 25 settembre 2025.");
    govTag(s, 1);
    docBox(s, 0.5, 1.15, 9.0, 0.8, "Legge 23 settembre 2025, n. 132", "In vigore dal 10 ottobre 2025. Si affianca all'AI Act, senza sostituirlo. Decreti attuativi: verificarne lo stato.", { fontSize: 13, fill: C.accent6 });
    rowsLabel(s, [["Autorità", "AgID e ACN, con compiti diversi"], ["Lavoro", "Sicurezza, affidabilità, trasparenza; informazione ai lavoratori"], ["Professioni intellettuali", "AI per attività strumentali e di supporto; informazione ai clienti"], ["Sanità", "La decisione resta al medico"], ["Diritto d'autore", "Tutelate le opere dell'ingegno umano, anche con ausilio dell'AI"]], { y: 2.1, h: 0.42, lw: 2.3, fontSize: 12 });
    txt(s, "Sintesi indicativa, da verificare sul testo vigente in Gazzetta Ufficiale.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent5 });
  }
  {
    const s = content("Che cosa obbliga, che cosa orienta", "Gli ultimi punti del sottotema: la differenza tra atti vincolanti, orientamenti, standard tecnici e policy interne, e l'importanza delle fonti ufficiali e degli aggiornamenti. Nel campo dell'AI circolano documenti di natura molto diversa, e conviene distinguerli. Gli atti vincolanti: regolamenti europei, come l'AI Act e il GDPR, e leggi nazionali, come la legge 132 del 2025. Obbligano. Gli orientamenti e le linee guida delle autorità: la Commissione europea ha pubblicato, per esempio, linee guida sulla definizione di sistema di AI e sulle pratiche vietate, e un codice di buone pratiche per i modelli per finalità generali; le autorità per la protezione dei dati pubblicano pareri. Non sono leggi, ma indicano come le autorità interpretano le norme. Gli standard tecnici: norme come la ISO/IEC 42001 del 2023, sui sistemi di gestione dell'AI, o gli standard armonizzati europei collegati all'AI Act, di cui va verificato lo stato. Sono volontari, salvo quando una norma vi rinvia, e possono aiutare a dimostrare la conformità. Le policy interne: le regole che l'organizzazione si dà, vincolanti per chi vi lavora, ma decise dall'organizzazione. La regola pratica: per gli obblighi, riferirsi sempre alle fonti ufficiali, EUR-Lex, la Commissione, la Gazzetta Ufficiale, e non a sintesi o articoli, compresa questa presentazione.");
    govTag(s, 1);
    const l = [["Atti vincolanti", "Regolamenti UE, leggi nazionali", "Obbligano", HEX.a1, C.background1], ["Orientamenti", "Linee guida della Commissione, codici di buone pratiche, pareri", "Indicano l'interpretazione", C.accent6, C.text1], ["Standard tecnici", "ISO/IEC 42001:2023; standard armonizzati: verificarne lo stato", "Volontari, aiutano a dimostrare", "D9ECEA", C.text1], ["Policy interne", "Regole dell'organizzazione", "Vincolano chi vi lavora", C.background2, C.text1]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.4, e[3], e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.22, w: 1.91, h: 0.45, fontSize: 14, bold: true, color: i === 0 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.7, w: 1.91, h: 1.05, fontSize: 11, color: e[4] });
      txt(s, e[2], { x: x + 0.12, y: 2.8, w: 1.91, h: 0.65, fontSize: 12, bold: true, color: i === 0 ? C.accent6 : C.accent5 });
    });
    banner(s, 3.75, "Per gli obblighi, le fonti ufficiali: EUR-Lex, Commissione europea, Gazzetta Ufficiale. Non le sintesi, compresa questa.", { h: 0.95, fontSize: 14 });
  }
  keySlide("L'AI Act è centrale, ma non sostituisce le altre norme applicabili: GDPR, lavoro, consumatori, diritto d'autore, discipline settoriali, legge nazionale.", "Sottotema 18.2  ·  Il quadro normativo", "Concetto chiave del secondo sottotema. L'AI Act tutela diritti e sicurezza e armonizza il mercato, con un approccio basato sul rischio. Prevede pratiche vietate, alto rischio, trasparenza, modelli per finalità generali; la maggior parte degli usi non ha obblighi specifici, salvo l'articolo 4. Si applica progressivamente, con date diverse, modificate dal Digital Omnibus del 2026. Il GDPR e altre discipline si applicano insieme. L'Italia ha la legge 132 del 2025. Atti vincolanti, orientamenti, standard e policy hanno valore diverso. Esercizio suggerito: per tre usi dell'AI in azienda, una bozza di email, un chatbot per i clienti, uno strumento di analisi dei curriculum, elencare quali discipline potrebbero essere pertinenti, oltre all'AI Act.");
  // =====================================================================
  section("18.3 L'approccio basato sul rischio");
  divider("18.3", "L'approccio basato sul rischio", "Il regime applicabile dipende dalla finalità e dalla qualificazione giuridica, non soltanto dalla presenza di un modello avanzato", "Uno dei sottotemi a priorità molto alta, e tra le priorità principali del tema, da comprendere. La terza domanda guida: che cosa significa classificare un sistema secondo l'approccio basato sul rischio? Vediamo la logica della classificazione, le pratiche vietate, i sistemi ad alto rischio dell'Allegato III e dell'Allegato I, la trasparenza, i modelli per finalità generali, l'importanza della finalità prevista, e la differenza tra classificazione legale e valutazione aziendale dei rischi. Integrazione A, con l'esempio B del documento. Le analisi articolo per articolo vanno solo accennate.");
  {
    const s = content("La logica della piramide", "Il sottotema parte dal significato della classificazione basata sul rischio. L'idea è semplice: non regolare l'AI in quanto tecnologia, ma i suoi usi, in proporzione ai rischi che comportano per salute, sicurezza e diritti fondamentali. Ne deriva una struttura spesso rappresentata come una piramide. In cima, le pratiche vietate: rischio inaccettabile, non consentite. Sotto, i sistemi ad alto rischio: consentiti, ma con obblighi articolati. Poi i sistemi soggetti a obblighi di trasparenza: consentiti, con obblighi di informazione. Alla base, tutti gli altri usi: rischio minimo, senza obblighi specifici dell'AI Act, salvo l'alfabetizzazione, e con la possibilità di adottare codici di condotta volontari. A questa piramide si affianca una categoria trasversale, i modelli per finalità generali, che riguarda i fornitori dei modelli, non i singoli usi. La piramide è una semplificazione utile, non una rappresentazione giuridica esatta: le categorie possono sovrapporsi, per esempio un sistema ad alto rischio può essere soggetto anche a obblighi di trasparenza. Il punto da ricordare è la logica: più alto il rischio dell'uso, più stringenti gli obblighi. E la grande maggioranza degli usi aziendali quotidiani si trova alla base della piramide.");
    govTag(s, 1);
    const lv = [["Pratiche vietate", "Rischio inaccettabile: non consentite", 3.0, "A86F1C", C.background1], ["Alto rischio", "Consentiti, con obblighi articolati", 4.2, HEX.a1, C.background1], ["Trasparenza", "Consentiti, con obblighi di informazione", 5.4, "D9ECEA", C.text1], ["Rischio minimo", "La maggioranza degli usi: nessun obbligo specifico, salvo l'art. 4", 7.0, C.background2, C.text1]];
    lv.forEach((e, i) => {
      const w = e[2], x = 0.5 + (7.0 - w) / 2, y = 1.15 + i * 0.75;
      shapeBox(s, x, y, w, 0.68, e[3], e[0]);
      txt(s, e[0] + ":  " + e[1], { x: x + 0.1, y, w: w - 0.2, h: 0.68, fontSize: i === 0 ? 11 : 12, bold: true, color: e[4], align: "center", valign: "middle" });
    });
    shapeBox(s, 7.75, 1.15, 1.75, 2.93, C.accent6, "modelli generali");
    txt(s, "Modelli per finalità generali", { x: 7.82, y: 1.25, w: 1.6, h: 0.65, fontSize: 12, bold: true, color: C.accent1 });
    txt(s, "Categoria trasversale: obblighi dei fornitori dei modelli", { x: 7.82, y: 1.95, w: 1.6, h: 1.9, fontSize: 11, color: C.text1 });
    banner(s, 4.25, "Una semplificazione, non una mappa giuridica esatta. Più alto il rischio dell'uso, più stringenti gli obblighi.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Le pratiche vietate", "Il sottotema chiede di conoscere le pratiche di AI vietate, elencate nell'articolo 5 dell'AI Act e applicabili dal 2 febbraio 2025. Sono usi considerati incompatibili con i valori dell'Unione. In sintesi: tecniche manipolative o ingannevoli che distorcono il comportamento delle persone causando danni significativi; lo sfruttamento delle vulnerabilità legate a età, disabilità o situazione socio-economica; il punteggio sociale, cioè la valutazione delle persone in base al comportamento sociale con trattamenti sfavorevoli ingiustificati; la previsione del rischio di reato basata unicamente sulla profilazione; la raccolta non mirata di immagini del volto da internet o da telecamere per creare banche dati di riconoscimento facciale; il riconoscimento delle emozioni sul luogo di lavoro e negli istituti di istruzione, salvo motivi medici o di sicurezza; la categorizzazione biometrica per dedurre caratteristiche sensibili, come l'orientamento sessuale o le opinioni politiche; l'identificazione biometrica remota in tempo reale in spazi pubblici a fini di contrasto, salvo eccezioni limitate. Il Digital Omnibus del 2026 ha aggiunto due divieti, sui contenuti intimi generati senza consenso e sul materiale pedopornografico; la data da cui si applicano va verificata sul testo ufficiale. Per un'azienda, il divieto più vicino all'esperienza quotidiana è probabilmente quello sul riconoscimento delle emozioni dei lavoratori. La Commissione ha pubblicato linee guida interpretative sulle pratiche vietate.");
    govTag(s, 1);
    await iconGrid(s, [
      { icon: "FiTarget", head: "Manipolazione", body: "Tecniche che distorcono il comportamento, o sfruttano vulnerabilità" },
      { icon: "FiStar", head: "Punteggio sociale", body: "Valutare le persone con trattamenti sfavorevoli ingiustificati" },
      { icon: "FiSmile", head: "Emozioni al lavoro e a scuola", body: "Salvo motivi medici o di sicurezza" },
      { icon: "FiCamera", head: "Biometria", body: "Raccolta non mirata di volti; categorie sensibili; identificazione in tempo reale" },
      { icon: "FiShield", head: "Previsione di reati", body: "Basata unicamente sulla profilazione" },
      { icon: "FiPlusCircle", head: "Aggiunti nel 2026", body: "Contenuti intimi senza consenso; materiale pedopornografico. Data: verificare" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 11 });
    banner(s, 4.35, "Art. 5, dal 2 febbraio 2025. Linee guida interpretative della Commissione. Sintesi, non testo normativo.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("L'alto rischio", "Il sottotema chiede di comprendere i sistemi ad alto rischio e le caratteristiche che ne determinano la qualificazione. Ci sono due vie, nell'articolo 6. La prima, l'Allegato I: sistemi che sono componenti di sicurezza di prodotti già regolati dalla normativa europea, o sono essi stessi quei prodotti, come macchine, dispositivi medici, giocattoli, ascensori, veicoli, quando il prodotto richiede una valutazione di conformità da parte di terzi. Per questi, gli obblighi si applicano dal 2 agosto 2028, dopo il rinvio del Digital Omnibus. La seconda, l'Allegato III: sistemi usati in otto ambiti elencati, in cui l'uso può incidere sui diritti delle persone. Tra questi, i più vicini alla vita aziendale sono l'occupazione e la gestione dei lavoratori, cioè sistemi per la selezione, il filtraggio delle candidature, la valutazione dei candidati, le decisioni su promozioni, licenziamenti, assegnazione di compiti e il monitoraggio delle prestazioni; l'istruzione e la formazione professionale, cioè sistemi per l'ammissione, la valutazione dell'apprendimento, il monitoraggio durante le prove; e l'accesso a servizi essenziali, come la valutazione del merito di credito delle persone e il calcolo dei premi per le assicurazioni vita e malattia. Per questi, gli obblighi si applicano dal 2 dicembre 2027. Gli altri ambiti riguardano biometria, infrastrutture critiche, attività di contrasto, migrazione, giustizia e processi democratici.");
    govTag(s, 1);
    await twoPanel(s, "Allegato I: prodotti regolati", "Componenti di sicurezza di prodotti già regolati, o prodotti stessi: macchine, dispositivi medici, giocattoli, veicoli.\n\nDal 2 agosto 2028.", "Allegato III: otto ambiti", "Tra cui lavoro, istruzione, servizi essenziali (credito, assicurazioni vita e malattia), biometria, infrastrutture, contrasto, migrazione, giustizia.\n\nDal 2 dicembre 2027.", { y: 1.15, h: 2.45, li: "FiPackage", ri: "FiList" });
    shapeBox(s, 0.5, 3.8, 9.0, 1.05, C.accent1, "lavoro");
    txt(s, [{ text: "Lavoro e gestione dei lavoratori: ", options: { bold: true, color: C.accent6 } }, { text: "selezione, filtraggio e valutazione delle candidature, promozioni, licenziamenti, assegnazione di compiti, monitoraggio delle prestazioni.", options: { color: C.background1 } }], { x: 0.7, y: 3.8, w: 8.6, h: 1.05, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Che cosa comporta l'alto rischio", "Per completezza, una sintesi di che cosa comporta la qualificazione ad alto rischio, senza entrare nel dettaglio degli articoli, come chiede il documento. I fornitori dei sistemi ad alto rischio hanno gli obblighi più estesi: un sistema di gestione dei rischi lungo tutto il ciclo di vita; requisiti sulla qualità dei dati di addestramento; documentazione tecnica; registrazione automatica degli eventi; trasparenza e istruzioni per i deployer; progettazione che consenta una supervisione umana effettiva; accuratezza, robustezza e cybersicurezza; un sistema di gestione della qualità; la valutazione della conformità, la marcatura CE e la registrazione in una banca dati europea. Anche i deployer, cioè le aziende che usano questi sistemi, hanno obblighi propri, che vedremo nel 18.4: usarli secondo le istruzioni, affidare la supervisione umana a persone con competenza, formazione e autorità adeguate, monitorarne il funzionamento, conservare i registri, informare i lavoratori e i loro rappresentanti prima di usare un sistema ad alto rischio sul luogo di lavoro, e informare le persone soggette a decisioni. Alcuni deployer, come gli enti pubblici e chi fornisce servizi pubblici, o chi valuta il merito di credito e le assicurazioni, devono anche svolgere una valutazione d'impatto sui diritti fondamentali. Il regime è impegnativo: è uno dei motivi per cui classificare correttamente un uso è così importante.");
    govTag(s, 1);
    await card(s, 0.5, 1.15, 4.35, 3.0, { icon: "FiTool", head: "Fornitori", headSize: 15, bodySize: 11, body: bullets(["Gestione dei rischi nel ciclo di vita", "Qualità dei dati, documentazione, registri", "Istruzioni, supervisione umana by design", "Accuratezza, robustezza, cybersicurezza", "Qualità, conformità, marcatura CE, registrazione"], { space: 3 }) });
    await card(s, 5.15, 1.15, 4.35, 3.0, { icon: "FiBriefcase", head: "Deployer (18.4)", headSize: 15, bodySize: 11, fill: C.accent6, body: bullets(["Uso secondo le istruzioni", "Supervisione a persone competenti, formate, con autorità", "Monitoraggio e conservazione dei registri", "Informare lavoratori e loro rappresentanti", "Per alcuni: valutazione d'impatto sui diritti"], { space: 3 }) });
    banner(s, 4.35, "Un regime impegnativo: per questo classificare correttamente un uso è così importante.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("La finalità decide", "Il punto centrale del sottotema: l'importanza della finalità prevista e delle condizioni effettive d'impiego, e le eventuali eccezioni previste dalla normativa. La qualificazione ad alto rischio non dipende da quanto è avanzata la tecnologia, ma da per che cosa è usata. Lo stesso modello linguistico può essere usato per scrivere email, e non rientra in alcuna categoria; o per classificare le candidature e decidere chi passa al colloquio, e rientra nell'ambito dell'occupazione dell'Allegato III. L'AI Act prevede anche delle eccezioni: un sistema che rientra in un ambito dell'Allegato III può non essere considerato ad alto rischio se non presenta un rischio significativo, per esempio perché svolge un compito procedurale limitato, migliora il risultato di un'attività umana già completata, rileva schemi decisionali senza sostituire la valutazione umana, o svolge un compito preparatorio. L'eccezione però non vale se il sistema effettua una profilazione delle persone, e il fornitore che la invoca deve documentare la propria valutazione. Sono condizioni precise, la cui applicazione richiede analisi competenti. Ne derivano due indicazioni pratiche. Leggere il caso d'uso prima della classificazione: non chiedersi 'questo strumento è ad alto rischio?', ma 'questo uso, con questa finalità, lo è?'. E fare attenzione ai cambi di finalità: usare uno strumento generico per uno scopo che rientra nell'Allegato III può cambiare la qualificazione, e le responsabilità, come vedremo nel 18.4.");
    govTag(s, 1);
    const u = [["Scrivere una bozza di email", "Nessuna categoria specifica", C.background2], ["Riassumere i curriculum per chi seleziona", "Da valutare: possibile eccezione se preparatorio, ma attenzione", C.accent6], ["Classificare le candidature e decidere chi passa al colloquio", "Ambito occupazione, Allegato III: alto rischio", "A86F1C"]];
    txt(s, "Lo stesso modello linguistico, tre finalità (esempi indicativi)", { x: 0.5, y: 1.1, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    u.forEach((e, i) => {
      const y = 1.48 + i * 0.68;
      shapeBox(s, 0.5, y, 9.0, 0.6, e[2], e[0]);
      txt(s, e[0], { x: 0.7, y, w: 4.7, h: 0.6, fontSize: 12, bold: true, color: i === 2 ? C.background1 : C.text1, valign: "middle" });
      txt(s, e[1], { x: 5.4, y, w: 4.0, h: 0.6, fontSize: 12, color: i === 2 ? C.background1 : C.accent1, valign: "middle" });
    });
    docBox(s, 0.5, 3.6, 9.0, 0.75, "Eccezioni (art. 6, par. 3)", "Compiti procedurali limitati, preparatori, che migliorano o rilevano senza sostituire la valutazione umana. Non con la profilazione. Analisi competenti.", { fontSize: 11 });
    txt(s, "Non 'lo strumento è ad alto rischio?', ma 'questo uso, con questa finalità, lo è?'", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Esempio B: la selezione", "Il secondo esempio del documento, che illustra l'integrazione A. Si valuta un sistema di AI che analizza le candidature per supportare le decisioni di selezione. La domanda: perché questo uso richiede un esame diverso dalla generazione di una bozza di email? Perché la finalità e il contesto incidono sulla classificazione normativa e sugli obblighi. La selezione del personale rientra tra gli ambiti dell'Allegato III, l'occupazione. Un sistema che filtra o valuta le candidature è, in linea di principio, un sistema ad alto rischio, salvo che rientri in una delle eccezioni, con le condizioni viste. Per l'azienda che lo usa, cioè il deployer, ne derivano obblighi specifici, da quando si applicheranno, oggi previsti per il 2 dicembre 2027 dopo il rinvio. Ma anche prima di quella data, altre norme si applicano già: il GDPR, con le regole sulle decisioni automatizzate e la valutazione d'impatto, le norme sul lavoro, quelle contro la discriminazione. E i rischi di bias visti nel Tema 17 sono presenti da subito. La bozza di email, invece, non rientra in alcuna categoria dell'AI Act: richiede le precauzioni del Tema 17, ma non obblighi specifici. L'apprendimento del documento: la corretta qualificazione richiede di verificare le disposizioni e le scadenze applicabili, con il supporto di figure competenti.");
    govTag(s, 1);
    await twoPanel(s, "Bozza di email", bullets(["Nessuna categoria dell'AI Act", "Precauzioni d'uso", "Nessun obbligo specifico"], { space: 5 }), "Analisi delle candidature", bullets(["Ambito occupazione, Allegato III", "In linea di principio alto rischio, salvo eccezioni", "Obblighi del deployer dal 2 dic 2027", "Già oggi: GDPR, lavoro, non discriminazione, bias"], { space: 4 }), { y: 1.15, h: 2.7, li: "FiMail", ri: "FiUserPlus" });
    banner(s, 4.05, "La finalità e il contesto decidono. Verificare disposizioni e scadenze con figure competenti.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Trasparenza e modelli generali", "Due altre categorie che il sottotema chiede di conoscere. Gli obblighi di trasparenza, nell'articolo 50, applicabili dal 2 agosto 2026. I fornitori di sistemi che interagiscono con le persone, come i chatbot, devono progettarli in modo che le persone sappiano di interagire con un'AI, salvo che sia evidente. I fornitori di sistemi che generano contenuti sintetici, audio, immagini, video o testo, devono marcarli in un formato leggibile dalle macchine, così che si possa riconoscere che sono generati; per i sistemi già sul mercato il Digital Omnibus ha previsto un periodo transitorio fino al 2 dicembre 2026. I deployer che usano sistemi per creare deepfake devono dichiararne la natura artificiale, con alcune eccezioni per opere artistiche o satiriche; e chi usa l'AI per generare testi pubblicati per informare il pubblico su questioni di interesse pubblico deve dichiararlo, salvo revisione umana e responsabilità editoriale. I deployer di sistemi di riconoscimento delle emozioni o di categorizzazione biometrica, dove consentiti, devono informare le persone. I modelli per finalità generali, dal 2 agosto 2025: la differenza tra un modello, come un grande modello linguistico, e un sistema destinato a un impiego specifico. Gli obblighi riguardano i fornitori dei modelli: documentazione tecnica, informazioni per chi li integra, una politica di rispetto del diritto d'autore, una sintesi dei contenuti usati per l'addestramento; e obblighi aggiuntivi per i modelli con rischio sistemico. Per un'azienda che usa questi modelli, sono obblighi del fornitore, non suoi.");
    govTag(s, 1);
    await card(s, 0.5, 1.15, 4.35, 3.05, { icon: "FiEye", head: "Trasparenza (art. 50, dal 2 ago 2026)", headSize: 13, bodySize: 11, body: bullets(["Chatbot: le persone sanno che è un'AI", "Contenuti sintetici marcati (transitorio fino al 2 dic 2026)", "Deepfake dichiarati; testi su temi di interesse pubblico", "Riconoscimento emozioni: informare le persone"], { space: 3 }) });
    await card(s, 5.15, 1.15, 4.35, 3.05, { icon: "FiCpu", head: "Modelli per finalità generali", headSize: 13, bodySize: 11, fill: C.accent6, body: bullets(["Dal 2 agosto 2025", "Obblighi dei fornitori dei modelli", "Documentazione, diritto d'autore, sintesi dei dati di addestramento", "Di più per il rischio sistemico"], { space: 3 }) });
    banner(s, 4.35, "Usare un modello generale non rende l'azienda fornitore del modello. Ma l'uso specifico può avere obblighi propri.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Generativa non è alto rischio", "L'integrazione A del tema, nelle sue due facce. Prima faccia: non tutta l'AI è ad alto rischio secondo l'AI Act, e il fatto di usare AI generativa non determina da solo questa qualificazione. È un equivoco diffuso, nato dall'attenzione mediatica: si pensa che l'AI Act 'vieti' o 'regoli pesantemente' strumenti come gli assistenti conversazionali. In realtà, la grande maggioranza degli usi aziendali dell'AI generativa, come scrivere, riassumere, tradurre, analizzare documenti, non rientra in alcuna categoria ad alto rischio. Seconda faccia, che il documento sottolinea con la stessa forza: la mancanza di qualificazione come alto rischio non implica assenza di rischi, vincoli o obblighi di altra natura. Un uso a rischio minimo secondo l'AI Act può comportare rischi seri di riservatezza, di sicurezza, di errore, di reputazione, visti nel Tema 17; e può essere soggetto al GDPR, al diritto d'autore, alle norme sui consumatori. È la distinzione tra classificazione legale del sistema e valutazione dei rischi operativi aziendali: la prima dice quali obblighi specifici dell'AI Act si applicano; la seconda, che vedremo nel 18.6, dice quali rischi l'azienda deve gestire, comunque. La consapevolezza del sottotema: il regime applicabile dipende dalla finalità e dalla qualificazione giuridica, non soltanto dalla presenza di un modello avanzato.");
    govTag(s, 1);
    await twoPanel(s, "Equivoco 1", "'Usiamo l'AI generativa, quindi siamo ad alto rischio.'\n\nNo: la maggioranza degli usi, scrivere, riassumere, tradurre, non rientra in alcuna categoria ad alto rischio.", "Equivoco 2", "'Non siamo ad alto rischio, quindi non c'è niente da fare.'\n\nNo: restano rischi operativi e altre norme: GDPR, diritto d'autore, consumatori.", { y: 1.15, h: 2.55, li: "FiXCircle", ri: "FiXCircle" });
    docBox(s, 0.5, 3.85, 4.35, 1.0, "Classificazione legale", "Quali obblighi specifici dell'AI Act si applicano.", { fontSize: 12 });
    docBox(s, 5.15, 3.85, 4.35, 1.0, "Valutazione aziendale dei rischi (18.6)", "Quali rischi l'azienda deve gestire, comunque.", { fontSize: 12, fill: C.accent6 });
  }
  keySlide("Il regime applicabile dipende dalla finalità e dalla qualificazione giuridica, non dalla presenza di un modello avanzato. E non essere ad alto rischio non significa non avere rischi né obblighi.", "Sottotema 18.3  ·  L'approccio basato sul rischio", "Concetto chiave del terzo sottotema. La piramide del rischio: pratiche vietate, alto rischio, trasparenza, rischio minimo, più i modelli per finalità generali. L'alto rischio passa per l'Allegato I, prodotti regolati, e l'Allegato III, otto ambiti tra cui lavoro e istruzione, con scadenze rinviate al 2027 e 2028. La finalità decide, con eccezioni precise. La selezione del personale è un esempio tipico. Generativa non è alto rischio, ma rischio minimo non è rischio zero. Esercizio suggerito: classificare in gruppo cinque usi fittizi dell'AI secondo la piramide, indicando per ciascuno che cosa si dovrebbe verificare con figure competenti.");

  // =====================================================================
  section("18.4 Ruoli e responsabilità");
  divider("18.4", "Ruoli e responsabilità", "Impiegare sistemi di terzi non elimina automaticamente le responsabilità dell'organizzazione utilizzatrice", "Uno dei sottotemi a priorità molto alta, e tra le priorità principali, da comprendere. La quarta domanda guida: quali responsabilità si collegano ai ruoli di provider e deployer? Vediamo i ruoli nella filiera, le responsabilità differenziate, quelle proprie delle aziende che usano soluzioni di terzi, l'importanza della finalità e delle istruzioni, i cambi di ruolo, la documentazione e i contratti, e la definizione interna di chi propone, autorizza, controlla e sospende. Integrazione B, con l'esempio A del documento.");
  {
    const s = content("I ruoli della filiera", "Il sottotema chiede di distinguere tra sviluppare, fornire, distribuire e usare un sistema di AI, e introduce le nozioni di provider e deployer. Il fornitore, o provider, è chi sviluppa un sistema o un modello di AI, o lo fa sviluppare, e lo immette sul mercato o lo mette in servizio con il proprio nome o marchio. È il soggetto con gli obblighi più estesi. Il deployer è chi usa un sistema di AI sotto la propria autorità, nell'ambito di un'attività professionale. Un'azienda che acquista e usa un assistente per i propri dipendenti è, in genere, un deployer. Non rientra in questa definizione l'uso personale non professionale. L'importatore è chi immette sul mercato europeo un sistema di un fornitore stabilito fuori dall'Unione. Il distributore è chi rende disponibile un sistema sul mercato, senza essere fornitore o importatore, come un rivenditore. Per i modelli per finalità generali c'è una figura specifica, il fornitore del modello, con obblighi propri, visti nel 18.3. Il sottotema ricorda anche che la stessa organizzazione può ricoprire ruoli diversi: per esempio essere deployer di un assistente acquistato e provider di un sistema che sviluppa internamente per i propri clienti. Le responsabilità sono differenziate in funzione del ruolo ricoperto, per ciascun sistema.");
    govTag(s, 2);
    const r = [["FiTool", "Provider", "Sviluppa o fa sviluppare, e immette sul mercato con il proprio nome", "Obblighi più estesi"], ["FiBriefcase", "Deployer", "Usa un sistema sotto la propria autorità, in attività professionale", "Il ruolo tipico di un'azienda"], ["FiGlobe", "Importatore", "Immette nell'UE un sistema di un fornitore extra UE", "Nei casi pertinenti"], ["FiTruck", "Distributore", "Rende disponibile sul mercato, come un rivenditore", "Nei casi pertinenti"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.55, i === 1 ? C.accent6 : C.background2, r[i][1]);
      await iconCircle(s, x + 0.75, 1.25, 0.62, r[i][0]);
      txt(s, r[i][1], { x: x + 0.1, y: 1.95, w: 1.95, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, r[i][2], { x: x + 0.12, y: 2.37, w: 1.91, h: 0.85, fontSize: 11, color: C.text1, align: "center" });
      txt(s, r[i][3], { x: x + 0.12, y: 3.25, w: 1.91, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "center" });
    }
    banner(s, 3.9, "La stessa organizzazione può avere ruoli diversi per sistemi diversi: deployer di un assistente acquistato, provider di un sistema sviluppato per i clienti.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Le responsabilità del deployer", "Il sottotema chiede di comprendere le responsabilità proprie delle aziende che usano soluzioni fornite da terzi. La consapevolezza del sottotema: impiegare sistemi di terzi non elimina automaticamente le responsabilità dell'organizzazione utilizzatrice. Il deployer ha responsabilità che dipendono dal tipo di sistema e di uso. Per tutti i sistemi: le misure per l'alfabetizzazione del personale, dell'articolo 4, che vedremo nel 18.7; e, quando applicabili, gli obblighi di trasparenza dell'articolo 50, per esempio sui deepfake. Per i sistemi ad alto rischio, gli obblighi più articolati visti nel 18.3: usarli secondo le istruzioni del fornitore; affidare la supervisione umana a persone con competenza, formazione e autorità; garantire che i dati di input sotto il proprio controllo siano pertinenti; monitorare il funzionamento e segnalare rischi e incidenti; conservare i registri; informare i lavoratori e le persone interessate; in alcuni casi, la valutazione d'impatto sui diritti fondamentali. A questi si aggiungono le responsabilità derivanti da altre norme, che non dipendono dal ruolo nell'AI Act: come titolare del trattamento dei dati secondo il GDPR, come datore di lavoro, come venditore verso i consumatori. In sintesi: il fornitore risponde di come il sistema è fatto; il deployer risponde di come lo usa.");
    govTag(s, 2);
    rowsLabel(s, [["Tutti i sistemi", "Alfabetizzazione del personale (art. 4, 18.7); trasparenza quando applicabile (art. 50)"], ["Alto rischio", "Istruzioni, supervisione competente, dati di input pertinenti, monitoraggio, registri, informazione, a volte valutazione d'impatto"], ["Altre norme", "Titolare del trattamento (GDPR), datore di lavoro, venditore verso i consumatori"]], { y: 1.15, h: 0.62, lw: 1.8, fontSize: 11 });
    banner(s, 3.35, "Il fornitore risponde di come il sistema è fatto; il deployer risponde di come lo usa.", { h: 0.85, fontSize: 16 });
    txt(s, "Impiegare sistemi di terzi non elimina automaticamente le responsabilità dell'organizzazione.", { x: 0.5, y: 4.3, w: 9, h: 0.5, fontSize: 13, bold: true, italic: true, color: C.accent1, align: "center" });
  }
  {
    const s = content("Esempio A: il prodotto 'conforme'", "L'integrazione B del tema, con il primo esempio del documento: acquistare un sistema dichiarato conforme non rende automaticamente conforme ogni suo uso. Un'azienda acquista un assistente di terzi e lo collega ai documenti interni. Il fornitore dichiara il prodotto conforme. La domanda: l'azienda può usarlo senza ulteriori verifiche? No, non automaticamente. La conformità dichiarata dal fornitore riguarda il prodotto, per gli usi previsti e alle condizioni indicate nelle sue istruzioni. Ma la conformità dell'uso dipende da elementi che il fornitore non controlla. La finalità concreta: per che cosa lo usa l'azienda? Se lo usa per uno scopo che rientra in un ambito ad alto rischio, il quadro cambia. I permessi e le informazioni trattate: a quali documenti è collegato, chi può vedere che cosa, se tratta dati personali, come visto nel Tema 14 e nel Tema 17. Il rispetto delle istruzioni del fornitore: limiti d'uso, configurazioni raccomandate, avvertenze. Gli obblighi propri dell'organizzazione, come il GDPR e l'informazione ai lavoratori. Anche la sicurezza delle integrazioni, come visto nel Tema 17. L'apprendimento: occorre considerare finalità concreta, permessi, informazioni trattate, istruzioni del fornitore e obblighi dell'organizzazione.");
    govTag(s, 2);
    docBox(s, 0.5, 1.15, 9.0, 0.85, "Esempio A (fittizio)", "Un'azienda acquista un assistente di terzi, dichiarato conforme, e lo collega ai documenti interni. Può usarlo senza ulteriori verifiche?", { fontSize: 13, fill: C.accent6 });
    txt(s, "No, non automaticamente. Che cosa resta da considerare", { x: 0.5, y: 2.15, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    await iconGrid(s, [
      { icon: "FiTarget", head: "Finalità concreta", body: "Per che cosa lo usa davvero l'azienda" },
      { icon: "FiKey", head: "Permessi e informazioni", body: "Documenti collegati, dati personali" },
      { icon: "FiFileText", head: "Istruzioni del fornitore", body: "Limiti d'uso, configurazioni, avvertenze" },
      { icon: "FiBriefcase", head: "Obblighi propri", body: "GDPR, lavoro, sicurezza delle integrazioni" },
    ], 4, { y: 2.5, H: 1.6, headSize: 12, bodySize: 11 });
    banner(s, 4.3, "Un sistema conforme non rende conforme ogni suo uso.", { h: 0.6, fontSize: 15 });
  }
  {
    const s = content("Quando cambia il ruolo", "Il sottotema chiede di conoscere gli effetti che modifiche sostanziali o cambi di finalità possono avere sulla qualificazione e sulle responsabilità, nei casi previsti. L'AI Act prevede, nell'articolo 25, che un deployer, o un altro soggetto della filiera, possa diventare fornitore, con i relativi obblighi, in alcuni casi relativi ai sistemi ad alto rischio. Se appone il proprio nome o marchio su un sistema ad alto rischio già sul mercato. Se apporta una modifica sostanziale a un sistema ad alto rischio, in modo che resti ad alto rischio. Se modifica la finalità prevista di un sistema, compreso un sistema per finalità generali, in modo che diventi ad alto rischio. Quest'ultimo caso è il più rilevante per un'azienda che usa l'AI generativa: se un assistente generico, non destinato dal fornitore a usi ad alto rischio, viene configurato e usato per selezionare i candidati, l'azienda potrebbe trovarsi nella posizione di fornitore di un sistema ad alto rischio, con obblighi molto più estesi di quelli di un deployer. Sono valutazioni tecniche e giuridiche complesse, da fare con figure competenti. Il messaggio pratico: un cambio di finalità o una modifica importante non sono solo scelte operative; possono cambiare il ruolo, e quindi le responsabilità.");
    govTag(s, 2);
    txt(s, "Il deployer può diventare provider, per i sistemi ad alto rischio, se (art. 25):", { x: 0.5, y: 1.1, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    numList(s, ["Appone il proprio nome o marchio su un sistema ad alto rischio già sul mercato", "Apporta una modifica sostanziale a un sistema ad alto rischio", "Modifica la finalità di un sistema, anche generale, che diventa ad alto rischio"], { y: 1.5, h: 0.52, fontSize: 13 });
    docBox(s, 0.5, 3.35, 9.0, 0.85, "Il caso più vicino (indicativo)", "Un assistente generico configurato e usato per selezionare i candidati: l'azienda potrebbe diventare fornitore di un sistema ad alto rischio.", { fontSize: 12, fill: C.accent6, bar: C.accent5, labelColor: C.accent5 });
    txt(s, "Un cambio di finalità non è solo una scelta operativa: può cambiare il ruolo. Valutazioni con figure competenti.", { x: 0.5, y: 4.35, w: 9, h: 0.5, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Documentazione e contratti", "Il sottotema chiede di considerare la rilevanza della finalità prevista dal fornitore, delle istruzioni e dell'uso concreto, e l'importanza della documentazione, dei contratti, delle condizioni e delle istruzioni del fornitore. È la terza precisazione trasversale del documento: l'acquisto e il contratto con il fornitore richiedono attenzione a finalità, istruzioni, documentazione e obblighi specifici. In pratica, quando si sceglie e si acquista uno strumento di AI, alcune informazioni del fornitore sono essenziali per la governance. La finalità prevista: per quali usi il fornitore ha progettato il sistema, e per quali lo esclude. Le istruzioni d'uso: limiti, configurazioni, avvertenze, condizioni di supervisione. Le condizioni sul trattamento dei dati: conservazione, uso per l'addestramento, luogo del trattamento, sub-fornitori, sicurezza, come visto nel Tema 17. Le condizioni sulla proprietà degli output e sulle garanzie in caso di contestazioni. Le informazioni sulle prestazioni e sui limiti noti. Gli impegni di aggiornamento e di comunicazione dei cambiamenti. Questa documentazione serve a diverse funzioni aziendali: acquisti, legale, protezione dei dati, IT, sicurezza. Non è compito dell'utilizzatore finale analizzarla, ma è compito dell'organizzazione farlo prima di approvare uno strumento.");
    govTag(s, 2);
    await iconGrid(s, [
      { icon: "FiTarget", head: "Finalità prevista", body: "Per quali usi è progettato, e quali esclude" },
      { icon: "FiFileText", head: "Istruzioni d'uso", body: "Limiti, configurazioni, avvertenze, supervisione" },
      { icon: "FiLock", head: "Trattamento dei dati", body: "Conservazione, addestramento, luogo, sub-fornitori" },
      { icon: "FiCopy", head: "Output e garanzie", body: "Proprietà, tutele in caso di contestazioni" },
      { icon: "FiBarChart2", head: "Prestazioni e limiti", body: "Che cosa fa bene, che cosa no" },
      { icon: "FiRefreshCw", head: "Aggiornamenti", body: "Come vengono comunicati i cambiamenti" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Non è compito dell'utente finale analizzarla; è compito dell'organizzazione, prima di approvare uno strumento.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Chi fa che cosa, all'interno", "Gli ultimi punti del sottotema: il coinvolgimento delle funzioni legale, privacy, IT, sicurezza, HR e management in base al contesto, e la definizione interna di chi propone, autorizza, controlla e sospende un uso. È il secondo dei tre piani dell'introduzione: le responsabilità organizzative. Il documento chiede di identificare quattro azioni, per ciascun uso rilevante. Chi propone: di solito chi ha il bisogno, una funzione o un responsabile, come visto nel Tema 15. Chi autorizza: chi ha il potere di decidere se l'uso è accettabile, considerati rischi e obblighi. Chi controlla: chi verifica che l'uso avvenga come previsto, e che i controlli funzionino. Chi sospende: chi può fermare un uso quando emerge un problema, rapidamente. Le funzioni da coinvolgere dipendono dal contesto. La funzione legale, per gli obblighi normativi e i contratti. Il responsabile della protezione dei dati, per i dati personali. L'IT e la sicurezza, per gli strumenti, le integrazioni e i rischi tecnici. Le risorse umane, per gli usi che riguardano i lavoratori. Il management, per le priorità e le risorse. In una piccola azienda, più ruoli possono coincidere in poche persone: il punto non è avere molte figure, ma che le quattro azioni abbiano qualcuno che se ne occupa.");
    govTag(s, 2);
    const a = [["Propone", "Chi ha il bisogno"], ["Autorizza", "Chi decide se è accettabile"], ["Controlla", "Chi verifica uso e controlli"], ["Sospende", "Chi può fermare, rapidamente"]];
    a.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 1.25, i === 3 ? C.accent1 : C.accent6, e[0]);
      txt(s, e[0], { x: x + 0.1, y: 1.2, w: 1.95, h: 0.5, fontSize: 16, bold: true, color: i === 3 ? C.background1 : C.accent1, align: "center" });
      txt(s, e[1], { x: x + 0.1, y: 1.72, w: 1.95, h: 0.6, fontSize: 11, color: i === 3 ? C.background1 : C.text1, align: "center" });
    });
    txt(s, "Funzioni da coinvolgere, secondo il contesto", { x: 0.5, y: 2.55, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    ["Legale", "Protezione dati", "IT e sicurezza", "Risorse umane", "Management"].forEach((t, i) => chip(s, 0.5 + i * 1.835, 2.92, 1.66, 0.55, t, { fill: C.background2, fontSize: 12 }));
    banner(s, 3.7, "In una piccola azienda più ruoli coincidono: conta che le quattro azioni abbiano qualcuno che se ne occupa.", { h: 0.9, fontSize: 14 });
  }
  keySlide("Impiegare sistemi di terzi non elimina le responsabilità dell'organizzazione: il fornitore risponde di come il sistema è fatto, il deployer di come lo usa.", "Sottotema 18.4  ·  Ruoli e responsabilità", "Concetto chiave del quarto sottotema. Provider, deployer, importatore e distributore hanno ruoli e responsabilità diversi, e la stessa organizzazione può averne più di uno. Il deployer ha obblighi propri, più articolati per l'alto rischio, oltre a quelli di altre norme. Un prodotto conforme non rende conforme ogni uso. Cambi di finalità e modifiche sostanziali possono trasformare un deployer in provider. Documentazione e contratti del fornitore sono essenziali. All'interno, servono responsabili per proporre, autorizzare, controllare e sospendere. Esercizio suggerito: per uno strumento di AI usato in azienda, individuare il ruolo dell'organizzazione e chi, internamente, propone, autorizza, controlla e può sospendere il suo uso.");

  // =====================================================================
  section("18.5 Politiche aziendali");
  divider("18.5", "Politiche aziendali", "Una policy è utile quando orienta decisioni e comportamenti concreti, non soltanto quando esiste come documento", "Uno dei sottotemi a priorità molto alta, e tra le priorità principali, da comprendere e applicare. La quinta domanda guida: quali indicazioni dovrebbe contenere una policy aziendale sull'AI? Vediamo funzione e obiettivi di una policy, gli elementi principali, la differenza tra policy scritta e policy praticata, la coerenza con gli strumenti disponibili e la revisione periodica. Integrazioni B e D. Il confine con il Tema 16: lì la chiarezza sulle regole come supporto all'adozione; qui i contenuti delle regole come strumento di governance. E con il Tema 17: lì i comportamenti dell'utente; qui le regole che l'organizzazione definisce.");
  {
    const s = content("A che cosa serve una policy", "Il sottotema parte dalla funzione e dagli obiettivi di una policy aziendale sull'AI. Una policy è un documento con cui l'organizzazione stabilisce le regole per l'uso dell'AI da parte delle persone che vi lavorano. Serve a diverse cose. Tradurre gli obblighi normativi in comportamenti concreti: le persone non possono leggere l'AI Act, ma possono seguire indicazioni chiare. Esprimere le scelte dell'organizzazione, oltre la legge: quali strumenti, quali usi, quali cautele. Dare certezza alle persone: sapere che cosa si può fare riduce sia l'astensione sia lo Shadow AI, come visto nel Tema 16. Distribuire le responsabilità: chi autorizza, chi supporta, a chi segnalare. Costituire un riferimento per i controlli e per la formazione. È il punto in cui i tre piani dell'introduzione si incontrano: la policy traduce gli obblighi normativi, assegna le responsabilità organizzative, e descrive le misure operative. Il documento, con le integrazioni B e D, chiede due attenzioni: la policy deve disciplinare gli usi concreti, anche di prodotti forniti da terzi, e non solo gli strumenti; e deve essere proporzionata alle esigenze reali, non un documento generico preso da un modello.");
    govTag(s, 3);
    await iconGrid(s, [
      { icon: "FiBookOpen", head: "Tradurre gli obblighi", body: "In comportamenti concreti e comprensibili" },
      { icon: "FiCompass", head: "Esprimere le scelte", body: "Strumenti, usi, cautele, oltre la legge" },
      { icon: "FiCheckCircle", head: "Dare certezza", body: "Meno astensione, meno Shadow AI" },
      { icon: "FiUsers", head: "Distribuire responsabilità", body: "Chi autorizza, supporta, riceve segnalazioni" },
      { icon: "FiShield", head: "Riferimento", body: "Per controlli e formazione" },
      { icon: "FiLayers", head: "I tre piani", body: "Obblighi, responsabilità, misure operative" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Usi concreti, anche di prodotti di terzi; proporzionata alle esigenze reali, non generica.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Gli elementi di una policy", "Il sottotema elenca gli elementi principali di una policy, che possiamo organizzare in una struttura essenziale. Gli strumenti approvati e i criteri per approvarne di nuovi: quali strumenti si possono usare, con quale account, e come chiedere di usarne altri. Gli usi, distinti in quattro categorie che il documento indica con precisione: consentiti, cioè liberi entro le regole generali; soggetti a condizioni, cioè consentiti con cautele specifiche; da autorizzare, cioè che richiedono un'approvazione preventiva o una valutazione specialistica; vietati. Le regole sulla condivisione di dati e documenti: quali informazioni si possono inserire, in quali strumenti, con quali precauzioni, come visto nel Tema 17. Le indicazioni per la revisione e la supervisione degli output, proporzionate alla criticità. Le condizioni di uso e pubblicazione dei contenuti generati, compresa la trasparenza e il diritto d'autore. Le responsabilità e i comportamenti attesi dai collaboratori. I canali per richieste, dubbi, anomalie e incidenti. E l'indicazione di chi mantiene la policy e quando viene rivista. Non serve che sia lunga: molte policy efficaci stanno in poche pagine, con esempi.");
    govTag(s, 3);
    rowsLabel(s, [["Strumenti", "Approvati, con quale account; come chiederne di nuovi"], ["Usi", "Consentiti, soggetti a condizioni, da autorizzare, vietati"], ["Dati e documenti", "Che cosa si può condividere, dove, con quali precauzioni"], ["Output", "Revisione proporzionata; uso e pubblicazione, trasparenza, diritti"], ["Persone", "Responsabilità e comportamenti attesi"], ["Canali", "Richieste, dubbi, anomalie, incidenti"], ["Manutenzione", "Chi la mantiene, quando si rivede"]], { y: 1.12, h: 0.4, lw: 1.9, fontSize: 12 });
    txt(s, "Non serve che sia lunga: poche pagine, con esempi.", { x: 0.5, y: 4.62, w: 9, h: 0.35, fontSize: 13, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Quattro categorie di uso", "Approfondiamo l'elemento centrale della policy: la classificazione degli usi in quattro categorie. È uno strumento semplice e molto efficace, perché permette alle persone di orientarsi rapidamente. Gli esempi in slide sono indicativi e fittizi: ogni organizzazione li definisce in base ai propri strumenti, rischi e obblighi. Consentiti: bozze di testi interni, riformulazioni, sintesi di documenti non riservati, idee, traduzioni di materiali pubblici, con gli strumenti approvati e le precauzioni generali. Soggetti a condizioni: comunicazioni verso clienti, con revisione obbligatoria; uso di documenti interni, solo negli strumenti aziendali; contenuti per la pubblicazione, con verifica dei diritti e indicazione dell'uso dell'AI quando richiesto. Da autorizzare: nuovi strumenti o integrazioni con i sistemi aziendali; usi che riguardano dati personali in modo sistematico; usi che riguardano decisioni sulle persone, come selezione e valutazione, che possono rientrare nell'alto rischio; agenti con capacità operative. Vietati: inserire dati personali o riservati in strumenti non approvati; usare l'AI per pratiche vietate dall'AI Act, come il riconoscimento delle emozioni dei colleghi; presentare contenuti sintetici come autentici; condividere credenziali. Il valore della classificazione sta soprattutto nelle due categorie intermedie: dicono che cosa si può fare, a quali condizioni, invece di lasciare solo l'alternativa tra libero e vietato.");
    govTag(s, 3);
    const c = [["Consentiti", "Bozze interne, riformulazioni, sintesi non riservate, idee, traduzioni di materiali pubblici", C.background2, C.text1], ["Soggetti a condizioni", "Comunicazioni ai clienti con revisione; documenti interni solo in strumenti aziendali; pubblicazioni con verifica dei diritti", C.accent6, C.text1], ["Da autorizzare", "Nuovi strumenti e integrazioni; dati personali sistematici; decisioni sulle persone; agenti con azioni", "D9ECEA", C.text1], ["Vietati", "Dati riservati in strumenti non approvati; pratiche vietate dall'AI Act; sintetico come autentico; credenziali", "A86F1C", C.background1]];
    c.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.85, e[2], e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.22, w: 1.91, h: 0.5, fontSize: 14, bold: true, color: i === 3 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.75, w: 1.91, h: 2.15, fontSize: 11, color: e[3] });
    });
    banner(s, 4.2, "Esempi indicativi e fittizi. Il valore è nelle categorie intermedie: che cosa si può fare, a quali condizioni.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Scritta o praticata", "Il punto più importante del sottotema, e la sua consapevolezza: la differenza tra una policy scritta e una policy conosciuta e concretamente praticabile. Una policy è utile quando orienta decisioni e comportamenti concreti, non soltanto quando esiste come documento. Molte organizzazioni hanno policy sull'AI che nessuno conosce, o che nessuno riesce ad applicare. Le cause sono ricorrenti. Il testo è lungo, giuridico, astratto: le persone non lo leggono, o non lo capiscono. Le regole non sono coerenti con gli strumenti effettivamente disponibili: la policy dice di usare solo strumenti approvati, ma non ne è stato approvato nessuno adatto alle esigenze, e le persone usano altro. Le regole sono troppo restrittive rispetto alle esigenze reali, e vengono aggirate. Non è chiaro a chi chiedere in caso di dubbio. La policy non viene aggiornata, e diventa obsoleta rispetto agli strumenti. Il sottotema chiede quindi testi accessibili, comprensibili e applicabili; coerenza con gli strumenti disponibili; un equilibrio tra autonomia dell'utilizzatore e controlli; e una revisione periodica. Una buona verifica: chiedere a qualche collega, senza preavviso, che cosa dice la policy su un caso concreto. Se non lo sa, la policy non funziona ancora.");
    govTag(s, 3);
    await twoPanel(s, "Perché non funziona", bullets(["Testo lungo, giuridico, astratto", "Incoerente con gli strumenti disponibili", "Troppo restrittiva: aggirata", "Non si sa a chi chiedere", "Non aggiornata"], { space: 3 }), "Che cosa serve", bullets(["Testi accessibili, con esempi", "Strumenti approvati adatti alle esigenze", "Equilibrio tra autonomia e controlli", "Canali chiari", "Revisione periodica"], { space: 3 }), { y: 1.15, h: 2.65, li: "FiXCircle", ri: "FiCheckCircle" });
    banner(s, 4.0, "La prova: chiedere a un collega che cosa dice la policy su un caso concreto. Se non lo sa, non funziona ancora.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Un esempio di policy essenziale", "Per rendere concreto il sottotema, un esempio di policy essenziale, interamente fittizio e semplificato, per un'azienda di medie dimensioni che usa un assistente aziendale approvato. Non è un modello da copiare, ma un'illustrazione di come gli elementi visti possono stare in una pagina. Notate alcune caratteristiche. È breve e scritta in linguaggio semplice. Dice prima che cosa si può fare, poi che cosa richiede attenzione o autorizzazione, poi che cosa è vietato. Dà esempi. Indica chi contattare. Indica quando sarà rivista. Una policy reale andrebbe costruita con le funzioni competenti, legale, protezione dei dati, IT, risorse umane, sulla base degli strumenti, dei rischi e degli obblighi specifici dell'organizzazione, e accompagnata da formazione e supporto. Suggerimento per l'aula: chiedere ai partecipanti di confrontare l'esempio con la policy della propria azienda, se esiste, o di individuare che cosa manca all'esempio per il loro contesto.");
    govTag(s, 3);
    promptBox(s, 0.5, 1.12, 9.0, 3.25, "POLICY SULL'USO DELL'AI (esempio fittizio, versione 1, revisione semestrale)\n1. Strumento approvato: l'assistente aziendale, con l'account di lavoro. Altri strumenti: richiesta al referente AI.\n2. Puoi usarlo per: bozze, sintesi, riformulazioni, idee, traduzioni.\n3. Con attenzione: testi per clienti (rileggi e verifica cifre e condizioni); contenuti da pubblicare (verifica diritti e trasparenza).\n4. Serve autorizzazione: nuovi strumenti o integrazioni; usi che riguardano candidati o colleghi; dati personali in modo sistematico.\n5. Non è consentito: dati personali o riservati in strumenti non approvati; credenziali; contenuti sintetici presentati come reali.\n6. Dubbi, anomalie, errori: referente AI del reparto o canale dedicato. Segnalare presto è un aiuto, non una colpa.", { label: "Una pagina", fontSize: 10 });
    banner(s, 4.5, "Non un modello da copiare: si costruisce con le funzioni competenti, sugli strumenti e gli obblighi reali.", { h: 0.45, fontSize: 13 });
  }
  keySlide("Una policy è utile quando orienta decisioni e comportamenti concreti, non soltanto quando esiste come documento.", "Sottotema 18.5  ·  Politiche aziendali", "Concetto chiave del quinto sottotema. La policy traduce obblighi, esprime scelte, dà certezza, distribuisce responsabilità. I suoi elementi: strumenti, usi in quattro categorie, dati, output, persone, canali, manutenzione. Le categorie intermedie, soggetti a condizioni e da autorizzare, sono le più utili. Una policy scritta non è una policy praticata: servono testi semplici, strumenti coerenti, canali chiari, revisione. Deve riguardare gli usi concreti, anche di prodotti di terzi, ed essere proporzionata. Esercizio suggerito: in piccoli gruppi, classificare dieci usi fittizi dell'AI nelle quattro categorie per il proprio reparto, e confrontare le scelte tra gruppi.");
  // =====================================================================
  section("18.6 Rischi e controlli");
  divider("18.6", "Rischi, controlli e supervisione", "I controlli sono efficaci quando funzionano nella pratica e sono mantenuti nel tempo, non soltanto quando risultano descritti", "Sesto sottotema, priorità alta, da comprendere. La sesta domanda guida: come si organizzano controlli, supervisione e valutazione dei rischi? Il documento distingue: il 18.3 tratta le categorie giuridiche, il 18.6 la valutazione e i controlli nel contesto aziendale; il 18.6 le misure, il 18.7 le competenze. Vediamo l'inventario degli usi, la valutazione dei rischi, i tipi di misure, la supervisione progettata, documentazione e tracciabilità, monitoraggio e incidenti, riesame e rischio residuo. Integrazioni A e B. Il calcolo avanzato del rischio e i sistemi di gestione completi vanno solo accennati.");
  {
    const s = content("Sapere che cosa c'è", "Il primo passo del sottotema, e di ogni governance: l'identificazione dei sistemi di AI e degli usi rilevanti in azienda. Non si può governare ciò che non si conosce. Eppure molte organizzazioni non sanno quali strumenti di AI vengono usati, da chi e per che cosa, come visto con lo Shadow AI. Un inventario degli usi, anche semplice, è la base di tutto il resto. Per ciascun uso rilevante, poche informazioni: lo strumento e il fornitore; la finalità; chi lo usa e quanti; quali informazioni tratta, in particolare dati personali o riservati; se produce effetti verso l'esterno o decisioni sulle persone; il responsabile interno; la classificazione secondo l'AI Act, se pertinente; i controlli previsti. L'inventario non deve essere un censimento burocratico di ogni uso individuale, ma una mappa degli usi che contano. Si costruisce con le funzioni e con le persone, chiedendo, non solo guardando i contratti, perché molti usi non passano dagli acquisti. E va aggiornato, perché gli usi cambiano rapidamente. La tabella mostra alcune righe di un inventario fittizio. È anche lo strumento con cui si individuano gli usi che richiedono attenzione particolare.");
    govTag(s, 4);
    table(s, [["Uso (fittizio)", "Strumento", "Informazioni", "Effetti", "Classificazione"],
      ["Bozze e sintesi interne", "Assistente aziendale", "Interne", "Interni", "Rischio minimo"],
      ["Chatbot sul sito", "Servizio di terzi", "Domande dei clienti", "Verso clienti", "Trasparenza"],
      ["Preselezione dei CV", "Da valutare", "Dati dei candidati", "Decisioni su persone", "Alto rischio, da verificare"],
      ["Analisi dei reclami", "Assistente aziendale", "Dati dei clienti", "Interni", "Rischio minimo, GDPR"]],
      { y: 1.15, colW: [2.2, 1.8, 1.7, 1.6, 1.7], rowH: 0.5, accentCol: 4, fontSize: 11, blankCorner: false });
    banner(s, 3.85, "Non si governa ciò che non si conosce. Una mappa degli usi che contano, costruita chiedendo, e aggiornata.", { h: 0.9, fontSize: 14 });
  }
  {
    const s = content("Valutare i rischi nel contesto", "Il sottotema chiede di valutare i rischi in rapporto al contesto operativo, considerando i possibili effetti su persone, dati, processi, attività e reputazione, e di distinguere la classificazione dell'AI Act dalla valutazione aziendale dei rischi. Abbiamo visto nel 18.3 che la classificazione legale dice quali obblighi specifici si applicano. La valutazione aziendale dei rischi dice quali rischi l'organizzazione deve gestire, che siano regolati o no. Le due cose vanno fatte entrambe, e possono dare risultati diversi. L'integrazione A lo dice con chiarezza: anche un uso non classificato ad alto rischio può richiedere controlli. Un assistente collegato all'intero archivio documentale non è ad alto rischio secondo l'AI Act, ma può esporre informazioni riservate, come visto nei Temi 14 e 17. La valutazione aziendale considera le dimensioni del rischio viste nel Tema 17: probabilità e gravità, reversibilità, chi è coinvolto. E considera gli effetti su diversi oggetti: le persone, clienti e lavoratori; i dati, personali e riservati; i processi e le attività, con errori o interruzioni; la reputazione. Non serve un metodo complesso, che il documento chiede di solo accennare; serve porsi le domande giuste, con le persone giuste, per gli usi che contano.");
    govTag(s, 4);
    docBox(s, 0.5, 1.15, 4.35, 1.5, "Classificazione AI Act (18.3)", "Quali obblighi specifici si applicano.", { fontSize: 13 });
    docBox(s, 5.15, 1.15, 4.35, 1.5, "Valutazione aziendale", "Quali rischi gestire, regolati o no: anche un uso non ad alto rischio può richiedere controlli.", { fontSize: 13, fill: C.accent6 });
    txt(s, "Effetti da considerare", { x: 0.5, y: 2.85, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Persone", "Dati", "Processi e attività", "Reputazione"].forEach((t, i) => chip(s, 0.5 + i * 2.3, 3.2, 2.15, 0.55, t, { fill: C.accent6, fontSize: 13 }));
    banner(s, 3.95, "Esempio: un assistente collegato all'intero archivio non è ad alto rischio, ma può esporre informazioni riservate.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Prevenire, rilevare, correggere", "Il sottotema chiede di conoscere le misure preventive, di rilevazione e correttive, e alcune misure specifiche: autorizzazioni, separazione dei ruoli e gestione dei privilegi. È una classificazione classica dei controlli, utile per verificare che non manchi nessun tipo. Le misure preventive riducono la probabilità che un problema si verifichi: la scelta di strumenti approvati, le configurazioni, i permessi minimi visti nel Tema 14, la formazione, le regole della policy, le autorizzazioni preventive per gli usi delicati. Le misure di rilevazione permettono di accorgersi quando un problema si verifica: il monitoraggio, i registri, le verifiche a campione, i canali di segnalazione. Le misure correttive permettono di intervenire e limitare i danni: la sospensione di un uso, la correzione, la comunicazione alle persone interessate, la revisione delle regole. La separazione dei ruoli significa che chi propone un uso non è la stessa persona che lo autorizza e lo controlla, quando i rischi lo giustificano. La gestione dei privilegi riguarda chi ha accesso a quali strumenti, configurazioni e informazioni. Un sistema di controlli equilibrato ha misure di tutti e tre i tipi: solo la prevenzione lascia ciechi sui problemi che sfuggono; solo la rilevazione arriva sempre tardi.");
    govTag(s, 4);
    const m = [["FiShield", "Preventive", "Strumenti approvati, configurazioni, permessi minimi, formazione, regole, autorizzazioni"], ["FiSearch", "Di rilevazione", "Monitoraggio, registri, verifiche a campione, segnalazioni"], ["FiTool", "Correttive", "Sospensione, correzione, comunicazione, revisione delle regole"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.3, i === 1 ? C.accent6 : C.background2, m[i][1]);
      await iconCircle(s, x + 1.1, 1.25, 0.62, m[i][0]);
      txt(s, m[i][1], { x: x + 0.15, y: 1.95, w: 2.56, h: 0.4, fontSize: 15, bold: true, color: C.text1, align: "center" });
      txt(s, m[i][2], { x: x + 0.15, y: 2.38, w: 2.56, h: 1.0, fontSize: 11, color: C.text2, align: "center" });
    }
    rowsLabel(s, [["Separazione dei ruoli", "Chi propone non è chi autorizza e controlla, quando i rischi lo giustificano"], ["Gestione dei privilegi", "Chi accede a quali strumenti, configurazioni, informazioni"]], { y: 3.6, h: 0.5, lw: 2.3, fontSize: 12 });
  }
  {
    const s = content("Supervisione progettata", "Il sottotema chiede una supervisione umana progettata come possibilità effettiva di comprendere, intervenire e arrestare il processo. Nel Tema 17 abbiamo visto, dal punto di vista della persona, le quattro condizioni del controllo effettivo: competenze, informazioni, tempo e potere di intervento, e il rischio della supervisione solo apparente. Qui guardiamo al lato dell'organizzazione: quelle condizioni non dipendono solo dalla persona, ma da come l'organizzazione progetta i processi. È l'organizzazione che decide chi supervisiona, e se ha la competenza e la formazione necessarie; che dà accesso alle informazioni per controllare, come i dati di partenza e le fonti; che dimensiona i carichi di lavoro in modo che ci sia tempo per verificare; che dà alla persona l'autorità di fermare o modificare, senza conseguenze negative; che prevede la possibilità tecnica di arrestare un processo automatico. Per i sistemi ad alto rischio, l'AI Act chiede espressamente ai deployer di affidare la supervisione a persone con competenza, formazione e autorità adeguate, e ai fornitori di progettare i sistemi in modo da consentirla. Ma il principio vale per tutti gli usi rilevanti: se l'organizzazione chiede a una persona di 'supervisionare' senza darle le condizioni per farlo, ha creato un controllo solo sulla carta.");
    govTag(s, 4);
    const c = [["Chi supervisiona", "Competenza e formazione adeguate"], ["Accesso", "Dati di partenza, fonti, criteri"], ["Carichi", "Tempo per verificare davvero"], ["Autorità", "Fermare o modificare senza conseguenze"], ["Arresto", "Possibilità tecnica di fermare il processo"]];
    c.forEach((e, i) => {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.15, 1.72, 1.6, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.1, y: 1.22, w: 1.55, h: 0.42, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.1, y: 1.68, w: 1.55, h: 0.95, fontSize: 11, color: C.text1 });
    });
    docBox(s, 0.5, 2.95, 9.0, 0.8, "Per l'alto rischio, l'AI Act", "Deployer: supervisione a persone con competenza, formazione e autorità. Fornitori: sistemi progettati per consentirla.", { fontSize: 12, fill: C.accent6 });
    banner(s, 3.95, "Chiedere di 'supervisionare' senza dare le condizioni è un controllo solo sulla carta.", { h: 0.85, fontSize: 14 });
  }
  {
    const s = content("Tracciare e gestire incidenti", "Il sottotema chiede documentazione e tracciabilità proporzionate alla criticità e agli obblighi, il monitoraggio del comportamento dei sistemi e delle anomalie, la segnalazione e gestione degli incidenti. La documentazione e la tracciabilità: sapere che cosa è stato deciso e perché, quali strumenti sono stati approvati e a quali condizioni, quali controlli sono previsti. Per i sistemi ad alto rischio, l'AI Act prevede la conservazione dei registri generati dal sistema; per gli altri usi, la documentazione deve essere proporzionata: troppa è un peso inutile, troppo poca impedisce di ricostruire e migliorare. Il monitoraggio: verificare nel tempo che i sistemi si comportino come previsto, che non emergano errori sistematici, che gli aggiornamenti dei fornitori non abbiano cambiato il comportamento, come visto nel Tema 16 dal punto di vista dell'adozione. La gestione degli incidenti: un incidente può essere una divulgazione di informazioni, un errore con conseguenze per un cliente, un comportamento anomalo di un assistente, una discriminazione, una manipolazione. Serve sapere chi riceve le segnalazioni, come si valuta la gravità, chi decide le azioni, chi comunica e a chi, e come si impara dall'accaduto. Per alcuni incidenti esistono obblighi di notifica, come quelli del GDPR sulle violazioni di dati personali, o quelli dell'AI Act sugli incidenti gravi dei sistemi ad alto rischio.");
    govTag(s, 4);
    await iconGrid(s, [
      { icon: "FiFileText", head: "Documentazione", body: "Che cosa è stato deciso, perché, a quali condizioni; proporzionata" },
      { icon: "FiActivity", head: "Monitoraggio", body: "Comportamento nel tempo, errori sistematici, aggiornamenti" },
      { icon: "FiAlertOctagon", head: "Incidenti", body: "Chi riceve, valuta, decide, comunica; come si impara" },
    ], 3, { y: 1.15, H: 2.4, headSize: 14, bodySize: 12 });
    docBox(s, 0.5, 3.7, 9.0, 0.75, "Obblighi di notifica, in alcuni casi", "Violazioni di dati personali (GDPR); incidenti gravi dei sistemi ad alto rischio (AI Act).", { fontSize: 12, fill: C.accent6 });
    txt(s, "Troppa documentazione è un peso; troppo poca impedisce di ricostruire e migliorare.", { x: 0.5, y: 4.55, w: 9, h: 0.35, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Riesame e rischio residuo", "Gli ultimi punti del sottotema: il riesame periodico dei controlli, specie dopo modifiche significative; il coinvolgimento specialistico per gli usi più sensibili; e il riconoscimento del rischio residuo dopo l'applicazione delle misure. Il riesame: i controlli vanno rivisti periodicamente, e in particolare quando cambia qualcosa di importante: un nuovo strumento o una nuova versione, un nuovo uso, un incidente, una nuova norma, un cambiamento organizzativo. È il ciclo di vita del 18.1 applicato ai controlli. Il coinvolgimento specialistico: per gli usi più sensibili, come quelli ad alto rischio, quelli che riguardano decisioni sulle persone o dati particolarmente delicati, servono competenze specifiche, legali, tecniche, di protezione dei dati, interne o esterne. Il rischio residuo: nessun insieme di controlli elimina tutti i rischi. Dopo le misure, resta un rischio residuo, che va riconosciuto, valutato e accettato consapevolmente da chi ne ha l'autorità, oppure ridotto ulteriormente, o evitato rinunciando all'uso. È lo stesso concetto visto nel Tema 15 per le opportunità, a livello di organizzazione. La consapevolezza del sottotema: i controlli sono efficaci quando funzionano nella pratica e sono mantenuti nel tempo, non soltanto quando risultano descritti. E l'integrazione B: la conformità del prodotto non elimina le verifiche sull'impiego aziendale.");
    govTag(s, 4);
    txt(s, "Quando riesaminare", { x: 0.5, y: 1.1, w: 9, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    ["Periodicamente", "Nuovo strumento o versione", "Nuovo uso", "Incidente", "Nuova norma"].forEach((t, i) => chip(s, 0.5 + i * 1.835, 1.45, 1.66, 0.55, t, { fill: C.accent6, fontSize: 11 }));
    docBox(s, 0.5, 2.2, 4.35, 1.75, "Coinvolgimento specialistico", "Per gli usi più sensibili: alto rischio, decisioni sulle persone, dati delicati. Competenze legali, tecniche, di protezione dei dati.", { fontSize: 12 });
    docBox(s, 5.15, 2.2, 4.35, 1.75, "Rischio residuo", "Nessun controllo elimina tutti i rischi: riconoscere, valutare, accettare consapevolmente, ridurre o evitare.", { fontSize: 12, fill: C.accent6 });
    banner(s, 4.12, "Efficaci se funzionano nella pratica e sono mantenuti, non solo descritti. Il prodotto conforme non elimina le verifiche.", { h: 0.8, fontSize: 13 });
  }
  keySlide("I controlli sono efficaci quando funzionano nella pratica e sono mantenuti nel tempo, non soltanto quando risultano descritti.", "Sottotema 18.6  ·  Rischi, controlli e supervisione", "Concetto chiave del sesto sottotema. Si parte dall'inventario degli usi che contano. La valutazione aziendale dei rischi è distinta dalla classificazione legale: anche usi non ad alto rischio richiedono controlli. Servono misure preventive, di rilevazione e correttive, con separazione dei ruoli e gestione dei privilegi. La supervisione va progettata dall'organizzazione. Documentazione, monitoraggio e gestione degli incidenti sono proporzionati. I controlli si riesaminano, e il rischio residuo si accetta consapevolmente. Esercizio suggerito: per un uso fittizio, un chatbot sul sito aziendale, individuare una misura preventiva, una di rilevazione e una correttiva, e chi ne è responsabile.");

  // =====================================================================
  section("18.7 AI literacy");
  divider("18.7", "AI literacy e responsabilità", "Le misure formative devono essere commisurate a persone, ruoli, sistemi e contesti d'uso", "Uno dei sottotemi a priorità molto alta, e tra le priorità principali, da comprendere. La settima domanda guida: che cosa richiede un approccio contestualizzato all'AI literacy? È il sottotema che riguarda più direttamente questo percorso. Vediamo il significato di AI literacy, l'articolo 4 dell'AI Act e la sua riscrittura nel 2026, le misure organizzative, la differenziazione per ruoli, il rapporto tra formazione introduttiva e approfondimento, la documentazione, e la differenza tra un attestato e la valutazione degli obblighi. Integrazione C, con l'esempio C del documento. Il confine con il Tema 16: lì la formazione come leva di adozione, qui come misura di alfabetizzazione nel quadro delle responsabilità organizzative.");
  {
    const s = content("Che cos'è l'AI literacy", "Il sottotema parte dal significato di alfabetizzazione all'intelligenza artificiale, o AI literacy. L'AI Act ne dà una definizione, nell'articolo 3: in sintesi, le competenze, le conoscenze e la comprensione che consentono a fornitori, deployer e persone interessate, tenendo conto dei rispettivi diritti e obblighi, di usare i sistemi di AI in modo informato, e di essere consapevoli delle opportunità, dei rischi e dei possibili danni che l'AI può causare. Notate tre elementi. È un insieme di competenze, conoscenze e comprensione: non solo sapere come funziona, ma saper usare e saper valutare. È relativa al ruolo e al contesto: ciò che serve a un fornitore è diverso da ciò che serve a un deployer o a una persona interessata. E comprende sia le opportunità sia i rischi: non è solo prudenza, ma anche capacità di cogliere il valore. È esattamente l'impostazione di questo percorso, che ha attraversato in diciotto temi i fondamenti, l'interazione, le possibilità, il valore per l'azienda e l'uso responsabile. Il sottotema chiede di considerare l'importanza di comprendere limiti, rischi e modalità appropriate di uso: l'alfabetizzazione non è entusiasmo, né diffidenza, ma la base per usare l'AI con giudizio.");
    govTag(s, 5);
    docBox(s, 0.5, 1.15, 9.0, 1.15, "Definizione (art. 3 AI Act, in sintesi)", "Competenze, conoscenze e comprensione che consentono a fornitori, deployer e persone interessate di usare i sistemi di AI in modo informato, consapevoli di opportunità, rischi e possibili danni.", { fontSize: 13, fill: C.accent6 });
    await iconGrid(s, [
      { icon: "FiLayers", head: "Competenze e comprensione", body: "Non solo sapere come funziona: saper usare e valutare" },
      { icon: "FiUsers", head: "Relativa al ruolo", body: "Fornitore, deployer, persona interessata, contesto" },
      { icon: "FiTrendingUp", head: "Opportunità e rischi", body: "Non solo prudenza: anche cogliere il valore" },
    ], 3, { y: 2.45, H: 1.65, headSize: 13, bodySize: 12 });
    banner(s, 4.3, "L'impostazione di questo percorso: fondamenti, interazione, possibilità, valore, uso responsabile.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("L'articolo 4, prima e dopo", "Il sottotema chiede di considerare la rilevanza dell'articolo 4 dell'AI Act, tenendo conto del testo vigente, e la nota per il formatore lo sottolinea. È un punto in cui la normativa è cambiata. Nel testo originale, applicabile dal 2 febbraio 2025, l'articolo 4 chiedeva a fornitori e deployer di adottare misure per garantire, nella misura del possibile, un livello sufficiente di alfabetizzazione del proprio personale e delle altre persone che si occupano dei sistemi per loro conto, tenendo conto delle loro conoscenze tecniche, esperienza, istruzione e formazione, del contesto d'uso e delle persone su cui i sistemi sono usati. Il Digital Omnibus, il Regolamento 2026/1744, in vigore dal 27 luglio 2026, ha riscritto l'articolo. Secondo il nuovo testo, verificato sul regolamento pubblicato nella Gazzetta Ufficiale dell'Unione (articolo 1, punto 5), fornitori e deployer devono ora adottare misure per sostenere lo sviluppo dell'alfabetizzazione del proprio personale e di chi opera per loro conto; il testo precisa che l'obbligo non richiede di garantire un livello specifico di alfabetizzazione di ciascun individuo. Un secondo paragrafo affida alla Commissione e agli Stati membri il compito di sostenere questi sforzi, con attenzione alle piccole e medie imprese. In sintesi: l'obbligo resta, ma è un obbligo di adottare misure, non di garantire un risultato individuale. È coerente con quanto il documento di perimetro già chiedeva di distinguere: adottare misure adeguate non è garantire un livello individuale predeterminato.");
    govTag(s, 5);
    await twoPanel(s, "Testo originale (dal 2 feb 2025)", "Misure per garantire, nella misura del possibile, un livello sufficiente di alfabetizzazione, tenendo conto di conoscenze, esperienza, formazione, contesto e persone interessate.", "Dopo il Digital Omnibus (dal 27 lug 2026)", "Misure per sostenere lo sviluppo dell'alfabetizzazione; nessun obbligo di garantire un livello specifico per ciascun individuo. Commissione e Stati membri sostengono, specie le PMI.", { y: 1.15, h: 2.75, li: "FiFileText", ri: "FiRefreshCw" });
    banner(s, 4.1, "L'obbligo resta: adottare misure, non garantire un risultato individuale. Verificare sul testo ufficiale vigente.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Misure commisurate", "Il sottotema chiede di considerare le misure organizzative per favorire conoscenze e competenze adeguate, i destinatari e le differenze tra ruoli, la valutazione di conoscenze pregresse, esperienza, formazione e contesto, il rapporto tra formazione introduttiva e approfondimento per ruolo, le esercitazioni in attività reali e l'aggiornamento continuo. La consapevolezza del sottotema: le misure formative devono essere commisurate a persone, ruoli, sistemi e contesti d'uso. In pratica, un approccio contestualizzato distingue diversi livelli. Una base comune per tutti, che è ciò che fa un percorso di AI Awareness come questo: che cosa sono i sistemi, come usarli, quali rischi, quali regole aziendali. Approfondimenti per ruolo: chi usa l'AI per comunicare con i clienti, chi la usa per analisi, chi gestisce persone, chi seleziona il personale, chi sviluppa o integra sistemi, chi supervisiona sistemi ad alto rischio ha bisogno di competenze specifiche, come visto nel Tema 16. Formazione sugli strumenti effettivamente in uso, con le loro caratteristiche e limiti. Esercitazioni su attività reali. Aggiornamento quando cambiano gli strumenti, gli usi o le regole. Il sottotema ricorda anche il ruolo dei fornitori e dei deployer: entrambi hanno obblighi di alfabetizzazione per il proprio personale; e le istruzioni e i materiali dei fornitori possono contribuire a quella dei deployer.");
    govTag(s, 5);
    const l = [["Base comune", "Per tutti: sistemi, uso, rischi, regole aziendali", "Un percorso di AI Awareness", C.background2], ["Per ruolo", "Clienti, analisi, gestione di persone, selezione, sviluppo, supervisione dell'alto rischio", "Competenze specifiche", C.accent6], ["Sugli strumenti", "Caratteristiche e limiti degli strumenti in uso, esercitazioni su attività reali", "Anche con i materiali dei fornitori", "D9ECEA"], ["Aggiornamento", "Quando cambiano strumenti, usi, regole", "Continuo", HEX.a1]];
    l.forEach((e, i) => {
      const y = 1.12 + i * 0.78;
      shapeBox(s, 0.5, y, 9.0, 0.7, e[3], e[0]);
      txt(s, e[0], { x: 0.7, y, w: 1.8, h: 0.7, fontSize: 14, bold: true, color: i === 3 ? C.background1 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 2.5, y: y + 0.04, w: 6.9, h: 0.34, fontSize: 12, color: i === 3 ? C.background1 : C.text1 });
      txt(s, e[2], { x: 2.5, y: y + 0.36, w: 6.9, h: 0.3, fontSize: 11, italic: true, color: i === 3 ? C.accent6 : C.text2 });
    });
    banner(s, 4.3, "Misure commisurate a persone, ruoli, sistemi e contesti d'uso.", { h: 0.6, fontSize: 15 });
  }
  {
    const s = content("Esempio C: il corso completato", "L'integrazione C del tema, con il terzo esempio del documento, e un esempio che riguarda direttamente noi. I dipendenti hanno partecipato a un corso introduttivo di AI. La domanda: la frequenza del corso attesta automaticamente la piena conformità all'articolo 4? No. Il percorso contribuisce all'alfabetizzazione, ma l'adeguatezza delle misure deve essere considerata rispetto a ruoli, esperienze, sistemi e contesti. Un corso introduttivo, anche ben fatto, è una base comune: non sostituisce gli approfondimenti per ruolo, la formazione sugli strumenti in uso, le esercitazioni, il supporto, l'aggiornamento. E, come visto nel Tema 16, la formazione da sola non produce comportamenti nel lavoro. Il sottotema aggiunge due distinzioni. È utile registrare e documentare le attività formative, per esempio chi ha partecipato, a quali contenuti, con quali risultati; ma questa registrazione non va presentata come prova automatica di conformità. E un attestato di partecipazione non equivale alla valutazione degli obblighi applicabili. Con la riscrittura dell'articolo 4 nel 2026, questo punto è ancora più chiaro: l'obbligo è adottare misure adeguate per sostenere lo sviluppo dell'alfabetizzazione, e la loro adeguatezza dipende dal contesto, non dal numero di attestati.");
    govTag(s, 5);
    docBox(s, 0.5, 1.15, 9.0, 0.85, "Esempio C (fittizio)", "I dipendenti hanno partecipato a un corso introduttivo di AI. La frequenza attesta automaticamente la piena conformità all'articolo 4?", { fontSize: 13, fill: C.accent6 });
    txt(s, "No. Il corso contribuisce, ma l'adeguatezza delle misure dipende da ruoli, esperienze, sistemi e contesti.", { x: 0.5, y: 2.1, w: 9, h: 0.45, fontSize: 13, bold: true, color: C.accent1 });
    docBox(s, 0.5, 2.65, 4.35, 1.6, "Registrare la formazione", "Utile: chi, quali contenuti, quali risultati. Ma non una prova automatica di conformità.", { fontSize: 12 });
    docBox(s, 5.15, 2.65, 4.35, 1.6, "Attestato di partecipazione", "Dice che una persona ha partecipato. Non equivale alla valutazione degli obblighi applicabili.", { fontSize: 12, fill: C.accent6 });
    banner(s, 4.5, "Un corso di AI Awareness, anche questo, non equivale automaticamente alla conformità all'articolo 4.", { h: 0.45, fontSize: 13 });
  }
  keySlide("Un corso di AI Awareness contribuisce all'alfabetizzazione, ma non equivale automaticamente alla conformità: le misure vanno commisurate a persone, ruoli, sistemi e contesti.", "Sottotema 18.7  ·  AI literacy e responsabilità", "Concetto chiave del settimo sottotema. L'AI literacy è un insieme di competenze, conoscenze e comprensione, relativo al ruolo, che riguarda opportunità e rischi. L'articolo 4, riscritto dal Digital Omnibus nel 2026, chiede a fornitori e deployer misure per sostenere lo sviluppo dell'alfabetizzazione, senza garantire un livello individuale. Le misure si articolano in base comune, approfondimenti per ruolo, formazione sugli strumenti, aggiornamento. Registrazioni e attestati sono utili, ma non sono prove automatiche di conformità. Esercizio suggerito: per il proprio ruolo, indicare che cosa di questo percorso è sufficiente, e quali approfondimenti specifici servirebbero, considerando gli strumenti e le attività reali.");

  // =====================================================================
  section("18.8 Governance proporzionata");
  divider("18.8", "Una governance proporzionata", "Non esiste un modello unico valido per tutte le aziende, ma è necessario rispettare gli obblighi pertinenti e rendere effettivi i controlli scelti", "L'ultimo sottotema, priorità alta, da conoscere. L'ottava domanda guida: come rendere la governance proporzionata alle attività e alle dimensioni aziendali? Il documento distingue: il 18.1 spiega perché serve una governance, il 18.5 i contenuti delle regole, il 18.8 come coordinare l'insieme di regole, competenze e verifiche. Vediamo i presidi essenziali, la proporzionalità, il collegamento tra regole, formazione e supporto, i framework e gli standard volontari, e il miglioramento continuo. Integrazioni C e D, con l'esempio D del documento.");
  {
    const s = content("I presidi essenziali", "Il sottotema elenca le componenti di una governance, che possiamo leggere come un insieme di presidi essenziali, validi per qualsiasi organizzazione, in forma più o meno strutturata. Primo: la mappatura degli strumenti e dei principali usi, vista nel 18.6. Secondo: l'individuazione di referenti, responsabilità e percorsi decisionali, cioè chi propone, autorizza, controlla, sospende, visto nel 18.4. Terzo: le modalità per proporre, valutare e autorizzare nuovi strumenti e usi, con il coinvolgimento delle funzioni pertinenti, legale, protezione dei dati, IT, risorse umane. Quarto: le policy essenziali, definite e mantenute, viste nel 18.5. Quinto: i criteri per autorizzazioni, controlli e segnalazioni, visti nel 18.6. Sesto: il collegamento tra regole, formazione e supporto agli utilizzatori: le regole devono essere insegnate, e le persone devono sapere a chi chiedere, come visto nel 18.7 e nel Tema 16. Settimo: il monitoraggio degli usi, delle anomalie e dei cambiamenti. Ottavo: il riesame periodico dei sistemi, dei rischi e delle pratiche. Lo schema in slide li mostra come un ciclo. In una piccola azienda possono stare in un documento di poche pagine e in una riunione periodica; in una grande organizzazione richiedono strutture dedicate. Ma le funzioni sono le stesse.");
    govTag(s, [0, 3, 4, 5]);
    const p = ["Mappare strumenti e usi", "Referenti e responsabilità", "Proporre, valutare, autorizzare", "Policy essenziali", "Criteri di controllo e segnalazione", "Regole, formazione, supporto", "Monitorare usi e anomalie", "Riesaminare periodicamente"];
    p.forEach((t, i) => {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.15 + row * 1.15;
      shapeBox(s, x, y, 2.15, 1.0, row ? C.accent6 : C.background2, t);
      txt(s, String(i + 1), { x: x + 0.1, y: y + 0.05, w: 0.5, h: 0.4, fontSize: 18, bold: true, color: C.accent1 });
      txt(s, t, { x: x + 0.1, y: y + 0.45, w: 1.95, h: 0.5, fontSize: 12, bold: true, color: C.text1 });
    });
    banner(s, 3.6, "In una piccola azienda: poche pagine e una riunione periodica. In una grande: strutture dedicate. Le funzioni sono le stesse.", { h: 0.95, fontSize: 14 });
    txt(s, "Rimandi: 18.4 responsabilità, 18.5 policy, 18.6 controlli, 18.7 formazione.", { x: 0.5, y: 4.65, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Esempio D: aziende diverse", "L'integrazione D del tema, con il quarto esempio del documento: la governance deve essere proporzionata, non necessariamente complessa. Una piccola impresa impiega un assistente approvato per usi limitati, come bozze, sintesi e traduzioni. Una seconda organizzazione sviluppa o usa sistemi di AI in attività particolarmente delicate, come la selezione del personale o la valutazione del credito. La domanda: devono necessariamente adottare gli stessi processi e strutture? No. I presidi possono variare in proporzione a usi, rischi e obblighi. La piccola impresa può avere una policy di una pagina, un referente, un elenco degli strumenti approvati, una formazione di base, e un momento periodico di verifica. La seconda organizzazione avrà bisogno di valutazioni dei rischi documentate, dell'analisi della classificazione secondo l'AI Act, degli obblighi del deployer o del fornitore per l'alto rischio, di valutazioni d'impatto, di supervisione progettata, di registri e monitoraggio, di competenze specialistiche. Ma l'apprendimento del documento ha una seconda parte, decisiva: senza trasformare la proporzionalità in un'esenzione. La piccola impresa che decidesse di usare l'AI per selezionare il personale avrebbe gli stessi obblighi della grande, per quell'uso. La proporzionalità riguarda la forma dei presidi, non l'esistenza degli obblighi.");
    govTag(s, [0, 3, 4, 5]);
    await twoPanel(s, "Piccola impresa, usi limitati", bullets(["Policy di una pagina", "Un referente, strumenti approvati", "Formazione di base", "Verifica periodica"], { space: 4 }), "Usi delicati: selezione, credito", bullets(["Valutazioni dei rischi documentate", "Classificazione AI Act, obblighi per l'alto rischio", "Valutazioni d'impatto, supervisione progettata", "Registri, monitoraggio, specialisti"], { space: 4 }), { y: 1.15, h: 2.6, li: "FiHome", ri: "FiBriefcase" });
    shapeBox(s, 0.5, 3.95, 9.0, 0.9, C.accent1, "non esenzione");
    txt(s, [{ text: "Proporzionalità, non esenzione. ", options: { bold: true, color: C.background1 } }, { text: "Se la piccola impresa usasse l'AI per selezionare il personale, avrebbe gli stessi obblighi, per quell'uso.", options: { color: C.accent6 } }], { x: 0.7, y: 3.95, w: 8.6, h: 0.9, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Framework e standard volontari", "Il sottotema chiede un cenno a framework e standard volontari, senza presentarli come obbligatori in modo indistinto, e la distinzione tra adempimenti legali e ulteriori scelte di gestione. Esistono diversi riferimenti che un'organizzazione può usare per strutturare la propria governance dell'AI. La norma ISO/IEC 42001 del 2023 definisce i requisiti di un sistema di gestione dell'AI, sul modello di altre norme di sistema di gestione come la ISO 9001 per la qualità o la ISO/IEC 27001 per la sicurezza delle informazioni; un'organizzazione può certificarsi. La ISO/IEC 23894 del 2023 dà indicazioni sulla gestione del rischio per l'AI. Il NIST AI Risk Management Framework, pubblicato nel 2023 dall'istituto statunitense per gli standard, propone un'impostazione articolata in quattro funzioni: governare, mappare, misurare, gestire. A livello europeo, sono previsti standard armonizzati collegati all'AI Act, il cui stato va verificato prima di ogni edizione, che possono aiutare a dimostrare la conformità per l'alto rischio. Sono strumenti utili, ma volontari: non sono obbligatori in generale, salvo quando una norma o un contratto vi rinviano. Adottarli è una scelta di gestione, che può avere senso per organizzazioni con usi complessi o che vogliono dimostrare la propria affidabilità; per una piccola azienda con usi semplici, i presidi essenziali sono spesso sufficienti. Il documento chiede di solo accennarvi.");
    govTag(s, 0);
    rowsLabel(s, [["ISO/IEC 42001:2023", "Sistema di gestione dell'AI; certificabile, come ISO 9001 e 27001"], ["ISO/IEC 23894:2023", "Gestione del rischio per l'AI"], ["NIST AI RMF (2023)", "Governare, mappare, misurare, gestire"], ["Standard armonizzati UE", "Collegati all'AI Act: verificarne lo stato"]], { y: 1.15, h: 0.55, lw: 2.4, fontSize: 12 });
    banner(s, 3.75, "Utili ma volontari, salvo rinvio di una norma o di un contratto. Adottarli è una scelta di gestione, non un adempimento.", { h: 0.85, fontSize: 14 });
    txt(s, "Per usi semplici, i presidi essenziali sono spesso sufficienti.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 12, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Formazione e governance", "L'integrazione C, nella sua seconda collocazione: la formazione è una componente del sistema di governance, non il sistema stesso. È un equivoco frequente, e comprensibile: dopo aver organizzato un percorso di formazione, si può avere l'impressione di aver 'fatto l'AI Act'. Ma la formazione funziona solo se è collegata alle altre componenti. Senza strumenti approvati, le persone formate non hanno con che cosa applicare. Senza una policy, non sanno quali regole seguire. Senza referenti e supporto, le domande che nascono nel lavoro restano senza risposta. Senza controlli e monitoraggio, non si sa se i comportamenti appresi vengono applicati. Senza riesame, la formazione invecchia con gli strumenti. Viceversa, regole e controlli senza formazione restano lettera morta: le persone non li conoscono o non li capiscono. Lo schema in slide mostra la formazione al centro di un sistema di componenti collegate. Per questo percorso, il messaggio è concreto: il valore di ciò che abbiamo fatto in questi diciotto temi dipende anche da ciò che l'organizzazione farà intorno, strumenti, regole, supporto, controlli, e da ciò che ciascuno farà nel proprio lavoro.");
    govTag(s, [0, 5]);
    s.addShape(pres.shapes.OVAL, { x: 3.75, y: 2.05, w: 2.5, h: 1.25, fill: { color: HEX.a1 }, line: { type: "none" }, objectName: "formazione" });
    txt(s, "Formazione", { x: 3.75, y: 2.05, w: 2.5, h: 1.25, fontSize: 16, bold: true, color: C.background1, align: "center", valign: "middle" });
    const n = [["Strumenti approvati", 0.5, 1.15], ["Policy", 3.75, 1.15], ["Referenti e supporto", 7.0, 1.15], ["Controlli e monitoraggio", 0.5, 3.0], ["Riesame", 7.0, 3.0]];
    n.forEach(e => chip(s, e[1], e[2], 2.5, 0.7, e[0], { fill: C.accent6, fontSize: 12 }));
    banner(s, 4.0, "Una componente del sistema di governance, non il sistema stesso. Senza le altre, non si applica; le altre, senza formazione, restano lettera morta.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("La checklist essenziale", "Il documento di perimetro propone una checklist concettuale di governance aziendale, che il sottotema traduce in uno strumento di orientamento. Nove domande. Sono noti gli strumenti di AI e i principali usi presenti nell'organizzazione? Per gli usi rilevanti è stata considerata la normativa applicabile? È chiaro quando l'azienda opera come deployer, provider o in altri ruoli? Esistono indicazioni comprensibili su strumenti approvati, usi consentiti e dati condivisibili? Sono individuati referenti e modalità di richiesta di supporto e autorizzazione? Sono previsti controlli proporzionati ai rischi e agli obblighi? Le misure di AI literacy sono coerenti con persone, ruoli e sistemi usati? Esiste un modo per segnalare anomalie e riesaminare gli usi? Le regole e i controlli sono aggiornati quando cambia il contesto? Il documento precisa, e va ripetuto: la checklist è uno strumento di orientamento didattico, non una prova di conformità. Aiuta a capire quali domande porre; per valutare il rispetto degli obblighi applicabili servono approfondimenti e, dove necessario, figure competenti.");
    govTag(s, [0, 1, 2, 3, 4, 5]);
    const q = ["Strumenti e usi sono noti?", "Normativa considerata per gli usi rilevanti?", "Ruolo chiaro: deployer, provider, altro?", "Indicazioni comprensibili su strumenti, usi, dati?", "Referenti e modalità di richiesta?", "Controlli proporzionati a rischi e obblighi?", "AI literacy coerente con persone, ruoli, sistemi?", "Modo per segnalare e riesaminare?", "Aggiornamento quando cambia il contesto?"];
    q.forEach((t, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.12 + row * 0.85;
      shapeBox(s, x, y, 2.9, 0.75, row % 2 ? C.accent6 : C.background2, "domanda " + (i + 1));
      txt(s, "☐", { x: x + 0.08, y, w: 0.35, h: 0.75, fontSize: 16, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.42, y, w: 2.43, h: 0.75, fontSize: 11, color: C.text1, valign: "middle" });
    });
    banner(s, 3.8, "Uno strumento di orientamento didattico, non una prova di conformità. Per valutare gli obblighi: approfondimenti e figure competenti.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Migliorare nel tempo", "Gli ultimi punti del sottotema: la distinzione tra presidi essenziali e strutture articolate, il miglioramento continuo, l'adeguamento alle evoluzioni normative e tecniche. La governance dell'AI non si costruisce una volta per tutte. Si comincia, di solito, dai presidi essenziali: sapere che cosa si usa, chi decide, quali regole, a chi chiedere. Poi si migliora, in base a ciò che si osserva: gli incidenti, le domande delle persone, i nuovi strumenti, i nuovi usi. E si adegua alle evoluzioni normative e tecniche, che nel campo dell'AI sono particolarmente rapide: in poco più di due anni dall'entrata in vigore, l'AI Act ha già avuto un'importante modifica con il Digital Omnibus, sono state pubblicate linee guida, codici di buone pratiche, leggi nazionali, e gli strumenti sono cambiati profondamente. È il principio del miglioramento continuo, visto nel Tema 16 per l'adozione, applicato alla governance. La consapevolezza del sottotema chiude il tema: non esiste un modello organizzativo unico valido per tutte le aziende, ma è necessario rispettare gli obblighi pertinenti e rendere effettivi i controlli scelti. Due condizioni, entrambe non negoziabili, con una grande libertà su come soddisfarle.");
    govTag(s, 0);
    const st = [["Presidi essenziali", "Che cosa si usa, chi decide, quali regole, a chi chiedere"], ["Osservare", "Incidenti, domande, nuovi strumenti e usi"], ["Migliorare", "Regole, controlli, formazione, supporto"], ["Adeguare", "Evoluzioni normative e tecniche"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 1.6, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.22, w: 1.91, h: 0.45, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.7, w: 1.91, h: 0.95, fontSize: 11, color: C.text1 });
      if (i < 3) arrow(s, x + 2.16, 1.8, 0.13);
    });
    txt(s, "In poco più di due anni: modifica dell'AI Act (Digital Omnibus), linee guida, codici di buone pratiche, leggi nazionali, strumenti nuovi.", { x: 0.5, y: 2.9, w: 9, h: 0.5, fontSize: 12, italic: true, color: C.text2 });
    banner(s, 3.55, "Nessun modello unico. Ma rispettare gli obblighi pertinenti e rendere effettivi i controlli scelti: due condizioni non negoziabili.", { h: 1.0, fontSize: 14 });
  }
  keySlide("Non esiste un modello organizzativo unico, ma è necessario rispettare gli obblighi pertinenti e rendere effettivi i controlli scelti.", "Sottotema 18.8  ·  Una governance proporzionata", "Concetto chiave dell'ultimo sottotema. I presidi essenziali sono gli stessi per tutti: mappare, assegnare responsabilità, autorizzare, regolare, controllare, formare e supportare, monitorare, riesaminare. Cambia la forma, in proporzione a usi, rischi e obblighi, senza diventare un'esenzione. Framework e standard sono utili ma volontari. La formazione è una componente della governance, non la governance. La checklist orienta, non certifica. La governance migliora nel tempo e si adegua all'evoluzione. Esercizio suggerito: applicare la checklist dei nove punti alla propria organizzazione, o al proprio reparto, indicando per ciascuna domanda sì, no o non so, e individuando le tre priorità.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle otto domande guida. Perché una regolamentazione e una governance: perché l'AI può incidere su diritti, sicurezza e persone, e perché i comportamenti dei singoli hanno bisogno di regole, responsabilità e controlli condivisi. AI Act, GDPR e altre discipline: l'AI Act è centrale, ma si applica insieme al GDPR, al diritto del lavoro, ai consumatori, al diritto d'autore, alle discipline settoriali e alla legge nazionale. Classificazione per rischio: pratiche vietate, alto rischio, trasparenza, rischio minimo; decide la finalità; generativa non è alto rischio, ma rischio minimo non è rischio zero. Provider e deployer: il fornitore risponde di come il sistema è fatto, il deployer di come lo usa; un prodotto conforme non rende conforme ogni uso. Policy: strumenti, usi in quattro categorie, dati, output, canali; scritta e praticata. Controlli e supervisione: inventario, valutazione nel contesto, misure preventive, di rilevazione e correttive, supervisione progettata, riesame. AI literacy: misure commisurate, che un corso introduttivo avvia ma non esaurisce. Proporzionalità: nella forma dei presidi, non nell'esistenza degli obblighi. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Perché regole e governance?", "Diritti e persone; regole, responsabilità, controlli condivisi"], ["AI Act e altre norme?", "Centrale, ma insieme a GDPR, lavoro, consumatori, legge 132"], ["Classificazione per rischio?", "Decide la finalità; rischio minimo non è rischio zero"], ["Provider e deployer?", "Come è fatto, come si usa; conforme non è uso conforme"], ["Che cosa contiene una policy?", "Strumenti, quattro categorie d'uso, dati, canali; praticata"], ["Controlli e supervisione?", "Inventario, valutazione, misure, supervisione progettata"], ["AI literacy contestualizzata?", "Misure commisurate; un corso avvia, non esaurisce"], ["Governance proporzionata?", "Nella forma dei presidi, non negli obblighi"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.9;
      shapeBox(s, x, y, 4.4, 0.8, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.8, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.06, w: 3.8, h: 0.32, fontSize: 12, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.4, w: 3.8, h: 0.34, fontSize: 11, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe saper: spiegare che cosa significa governance dell'AI e perché non coincide con la sola conformità normativa; descrivere la finalità generale dell'AI Act e il rapporto con altre normative; comprendere l'approccio europeo alla classificazione basata sul rischio; evitare di equiparare automaticamente AI generativa e sistema ad alto rischio; distinguere classificazione normativa e valutazione operativa del rischio; riconoscere le differenze tra provider, deployer e altri ruoli; comprendere che usare sistemi di terzi può comportare responsabilità proprie; spiegare a che cosa serve una policy aziendale sull'AI; riconoscere il ruolo di valutazione dei rischi, controlli, documentazione e supervisione; comprendere il significato dell'articolo 4 e delle misure di AI literacy contestualizzate; distinguere la partecipazione a un corso dalla verifica degli obblighi; comprendere il principio di proporzionalità della governance.");
    const r = ["Governance non è solo conformità", "AI Act e altre normative", "Classificazione basata sul rischio", "Generativa non è alto rischio", "Classificazione legale e rischio operativo", "Provider, deployer, altri ruoli", "Sistemi di terzi, responsabilità proprie", "A che cosa serve una policy", "Rischi, controlli, documentazione, supervisione", "Articolo 4 e AI literacy contestualizzata", "Un corso non è verifica degli obblighi", "Proporzionalità della governance"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Quattro equivoci, quattro esempi", "Riprendiamo le quattro integrazioni e i quattro esempi del documento, come sintesi del modulo. Sulla slide gli equivoci sono numerati da 1 a 4; le lettere restano agli esempi. Equivoco 1, integrazione A: equiparare ogni AI all'alto rischio, o al contrario pensare che senza alto rischio non ci siano obblighi. Esempio B, la selezione del personale: è la finalità che decide, e la qualificazione richiede verifiche. Equivoco 2, integrazione B: delegare interamente la conformità al fornitore. Esempio A, l'assistente acquistato e collegato ai documenti: un prodotto conforme non rende conforme ogni uso. Equivoco 3, integrazione C: confondere la formazione con la certificazione. Esempio C, il corso completato da tutti: contribuisce all'alfabetizzazione, ma non attesta la conformità all'articolo 4. Equivoco 4, integrazione D: identificare la governance con apparati necessariamente complessi. Esempio D, aziende diverse: i presidi variano in proporzione, senza che la proporzionalità diventi esenzione. Suggerimento per l'aula: usare questi quattro equivoci come esercizio finale, chiedendo ai partecipanti quale hanno sentito più spesso in azienda.");
    const e = [["1", "Non tutta l'AI è ad alto rischio", "Esempio B: la selezione del personale", "Decide la finalità; verificare"], ["2", "Conforme non è uso conforme", "Esempio A: l'assistente collegato ai documenti", "Finalità, permessi, istruzioni, obblighi propri"], ["3", "Un corso non è l'articolo 4", "Esempio C: il corso completato da tutti", "Contribuisce, non attesta"], ["4", "Proporzionata, non complessa", "Esempio D: aziende diverse", "Forma diversa, obblighi uguali"]];
    e.forEach((x, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const xx = 0.5 + col * 4.6, y = 1.12 + row * 1.85;
      shapeBox(s, xx, y, 4.4, 1.7, row === col ? C.accent6 : C.background2, "equivoco " + x[0]);
      txt(s, x[0], { x: xx + 0.15, y: y + 0.1, w: 0.5, h: 0.5, fontSize: 24, bold: true, color: C.accent1 });
      txt(s, x[1], { x: xx + 0.7, y: y + 0.12, w: 3.6, h: 0.42, fontSize: 14, bold: true, color: C.text1 });
      txt(s, x[2], { x: xx + 0.7, y: y + 0.6, w: 3.6, h: 0.45, fontSize: 11, color: C.text2 });
      txt(s, x[3], { x: xx + 0.7, y: y + 1.1, w: 3.6, h: 0.45, fontSize: 12, bold: true, color: C.accent1 });
    });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei semplificazioni frequenti quando si parla di regole e governance dell'AI, una per ciascuno dei passaggi principali del modulo. Primo: 'governare l'AI vuol dire vietarla'. La governance deve abilitare usi appropriati e conformi, non ridursi a un elenco di divieti; e la conformità non esaurisce il governo dell'AI. Secondo: 'la scadenza è il 2 agosto'. Non esiste una data unica per tutti gli obblighi, e le sintesi non sostituiscono le fonti ufficiali. Terzo: 'non siamo ad alto rischio, quindi non c'è niente da fare'. Restano rischi operativi e altre norme, come il GDPR; e, all'opposto, non tutta l'AI generativa è ad alto rischio. Conta la finalità: si classifica l'uso, non lo strumento, e cambiare finalità può cambiare il ruolo. Quarto: 'il fornitore dice che è conforme'. Un prodotto conforme non rende conforme ogni uso, e la responsabilità non passa tutta al fornitore. Quinto: 'abbiamo la policy, siamo a posto'. Una policy sconosciuta o non praticata non orienta nulla, e i controlli solo sulla carta non controllano. Sesto: 'tutti hanno l'attestato del corso'. Un attestato non prova la conformità all'articolo 4; e la proporzionalità riguarda la forma dei presidi, non è un'esenzione dagli obblighi. Suggerimento: chiedere ai partecipanti quale di queste frasi hanno sentito più spesso in azienda.");
    const a = [["FiSlash", "\"Governare l'AI vuol dire vietarla\"", "La governance abilita usi appropriati", "18.1"], ["FiCalendar", "\"La scadenza è il 2 agosto\"", "Nessuna data unica per tutti", "18.2"], ["FiAlertTriangle", "\"Non siamo ad alto rischio: niente da fare\"", "Altri rischi e altre norme restano", "18.3"], ["FiPackage", "\"Il fornitore dice che è conforme\"", "Conforme non è uso conforme", "18.4"], ["FiFileText", "\"Abbiamo la policy, siamo a posto\"", "Regole conosciute e praticate", "18.5"], ["FiAward", "\"Tutti hanno l'attestato del corso\"", "Un attestato non è conformità", "18.7"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 2.95, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.7, y: y + 0.1, w: 0.55, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Il percorso completato", "Con il Tema 18 si chiude il percorso di AI Literacy. In diciotto temi abbiamo attraversato cinque aree. Comprendere l'AI, nei Temi da 1 a 4: che cos'è, come funziona, che cosa sa fare e non fare, quali strumenti esistono. Interagire con l'AI, nei Temi da 5 a 7: come dialogare, come formulare le richieste, come verificare gli output con pensiero critico. Esplorare le possibilità dell'AI, nei Temi da 8 a 11: testi e documenti, dati e analisi, contenuti multimodali, assistenti, agenti e automazioni. Comprendere il valore per l'azienda, nei Temi da 12 a 16: creazione di valore, trasformazione del lavoro, dati e conoscenza aziendale, opportunità, adozione. Utilizzare l'AI responsabilmente, nei Temi 17 e 18: rischi e precauzioni dell'utilizzatore, norme e governance dell'organizzazione. Il filo che li lega è quello della definizione di AI literacy: competenze, conoscenze e comprensione per usare l'AI in modo informato, consapevoli delle opportunità e dei rischi. Come abbiamo detto nel 18.7 e nel Tema 16, il percorso è una base: il suo valore dipenderà dall'applicazione nel lavoro, dal confronto tra colleghi, dagli strumenti, dalle regole e dal supporto che l'organizzazione metterà a disposizione. Il passaggio successivo, indicato dal documento di perimetro, è una revisione trasversale dei diciotto temi, e la loro distribuzione nelle sessioni in presenza. Lasciare spazio alle domande finali, e ringraziare i partecipanti. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    const a = [["Comprendere l'AI", "Temi 1-4"], ["Interagire con l'AI", "Temi 5-7"], ["Esplorare le possibilità", "Temi 8-11"], ["Il valore per l'azienda", "Temi 12-16"], ["Uso responsabile", "Temi 17-18"]];
    a.forEach((e, i) => {
      const x = 0.5 + i * 1.84, dark = i === 4;
      shapeBox(s, x, 1.15, 1.72, 1.4, dark ? C.accent1 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.1, y: 1.22, w: 1.55, h: 0.75, fontSize: 13, bold: true, color: dark ? C.background1 : C.text1 });
      txt(s, e[1], { x: x + 0.1, y: 2.0, w: 1.55, h: 0.4, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1 });
      if (i < 4) arrow(s, x + 1.73, 1.7, 0.1);
    });
    docBox(s, 0.5, 2.75, 9.0, 0.85, "Il filo: l'AI literacy", "Competenze, conoscenze e comprensione per usare l'AI in modo informato, consapevoli di opportunità e rischi.", { fontSize: 13, fill: C.accent6 });
    banner(s, 3.8, "Una base: il valore dipende dall'applicazione nel lavoro, dal confronto, dagli strumenti, dalle regole e dal supporto.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti del modulo. Per gli obblighi normativi, riferirsi sempre ai testi ufficiali, e verificare prima di ogni edizione il testo vigente, le modifiche e le date di applicazione: la normativa sull'AI è in rapida evoluzione, e alcune informazioni del modulo, verificate a ottobre 2026, potrebbero cambiare. Verifiche sul testo ufficiale del Regolamento 2026/1744 (EUR-Lex), fatte a ottobre 2026: pubblicazione il 24 luglio 2026 ed entrata in vigore il 27 luglio 2026; nuove date per l'alto rischio, 2 dicembre 2027 per l'Allegato III e 2 agosto 2028 per l'Allegato I; transitorio di quattro mesi, fino al 2 dicembre 2026, per la marcatura dei sistemi già sul mercato; nuovo articolo 4; definizione di sistema di AI dell'articolo 3, punto 1, non modificata. Non è stato possibile verificare sul testo ufficiale la data di applicazione dei due nuovi divieti, che per questo non è riportata. La Legge 132/2025 è stata verificata sulla Gazzetta Ufficiale. Gli esempi aziendali e la policy di esempio sono fittizi; i quattro esempi A-D sono tratti dal documento di perimetro e presentati come esempi fittizi. Questo modulo non costituisce un parere legale.");
    const src = [
      "Regolamento (UE) 2024/1689 (AI Act). EUR-Lex: eur-lex.europa.eu/eli/reg/2024/1689/oj",
      "Regolamento (UE) 2026/1744 (Digital Omnibus sull'AI), GUUE L, 24 luglio 2026, in vigore dal 27 luglio 2026. EUR-Lex: eur-lex.europa.eu/eli/reg/2026/1744/oj",
      "Commissione europea, pagina sull'AI Act: digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai; linee guida su definizione di sistema di AI e pratiche vietate (2025).",
      "Regolamento (UE) 2016/679 (GDPR). Legge 23 settembre 2025, n. 132 (Gazzetta Ufficiale n. 223 del 25 settembre 2025).",
      "Gruppo di esperti di alto livello sull'AI (2019), Linee guida etiche per un'AI affidabile. OCSE, Principi sull'AI (2019, agg. 2024). UNESCO (2021).",
      "ISO/IEC 42001:2023; ISO/IEC 23894:2023; NIST AI Risk Management Framework 1.0 (2023).",
      "Esempi aziendali e policy di esempio fittizi. Non costituisce parere legale.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 6 }), { x: 1.3, y: 1.1, w: 8.2, h: 3.55, fontSize: 11, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema18_Normativa_regole_governance_AI.pptx" });
  await applyTheme("Tema18_Normativa_regole_governance_AI.pptx", THEME);
  console.log("done");
})();
