const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 12: AI e creazione di valore per l'azienda";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 12  ·  AI e creazione di valore per l'azienda";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function lineChart(s, labels, series, o) {
    s.addChart(pres.charts.LINE, series.map(e => ({ name: e.name, labels, values: e.values })), {
      x: o.x, y: o.y, w: o.w, h: o.h, lineSize: o.lineSize || 2.5, lineDataSymbol: o.symbol || "none", lineDataSymbolSize: 6, chartColors: series.map(e => e.color || HEX.a1),
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: o.catSize || 10, catAxisLabelFontFace: "+mn-lt",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisLabelFontFace: "+mn-lt", valAxisHidden: !!o.valHidden,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, valAxisMinVal: o.min, valAxisMaxVal: o.max,
      showLegend: !!o.legend, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, displayBlanksAs: "gap",
      showTitle: !!o.title, title: o.title || "", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
      catAxisLineShow: true, catAxisLineColor: HEX.a3, lineDash: o.dash,
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "riquadro " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function rowsLabel(s, rows, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.54, lw = o.lw || 2.5, X = o.x || 0.5, W = o.w || 9.0;
    rows.forEach((e, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, X, y, W, h, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: X + 0.15, y, w: lw, h, fontSize: o.headSize || 13, bold: true, color: o.headColor || C.accent1, valign: "middle" });
      txt(s, e[1], { x: X + 0.15 + lw, y, w: W - 0.3 - lw, h, fontSize: o.fontSize || 12, color: C.text1, valign: "middle" });
    });
  }
  function valTag(s, active) {
    const st = ["Definire", "Meccanismi", "Condizioni", "Verificare"];
    st.forEach((t, i) => {
      const x = 6.3 + i * 0.81;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.78, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "dimensione " + t });
      txt(s, t, { x, y: 0.42, w: 0.78, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function checkGrid(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, rh = o.rh || 0.66, gap = o.gap || 0.09;
    items.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = y0 + row * (rh + gap);
      shapeBox(s, x, y, 4.4, rh, row % 2 ? C.accent6 : C.background2, "voce " + (i + 1));
      s.addShape(pres.shapes.RECTANGLE, { x: x + 0.15, y: y + rh / 2 - 0.13, w: 0.26, h: 0.26, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 }, objectName: "casella " + (i + 1) });
      if (Array.isArray(e)) {
        txt(s, e[0], { x: x + 0.55, y, w: 1.9, h: rh, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
        txt(s, e[1], { x: x + 2.45, y, w: 1.85, h: rh, fontSize: 11, color: C.text1, valign: "middle" });
      } else txt(s, e, { x: x + 0.55, y, w: 3.8, h: rh, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 12", { placeholder: "kicker" });
    s.addText("AI e creazione di valore per l'azienda", { placeholder: "title" });
    s.addText("Area: Comprendere il valore per l'azienda", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al dodicesimo tema, che apre una nuova area del percorso: 'Comprendere il valore per l'azienda'. Nelle aree precedenti abbiamo visto che cos'è l'AI, come interagire con essa, e che cosa può fare: con testi e documenti, dati, contenuti multimodali, assistenti e agenti. Ora cambiamo prospettiva. Non ci chiediamo più che cosa l'AI sa fare, ma quando e come quello che sa fare diventa valore per l'azienda, per chi ci lavora, per i clienti. È una domanda meno ovvia di quanto sembri. Usare l'AI non produce automaticamente valore: ci sono costi, compromessi, condizioni, e i benefici che si vedono in una singola attività non sempre si ritrovano nei risultati dell'organizzazione. Questo tema fornisce i concetti per ragionare sul valore in modo realistico, senza entusiasmi ingiustificati e senza scetticismi preconcetti. Non entriamo nel calcolo analitico del ritorno sull'investimento, nei business case e nella selezione dei progetti: saranno ripresi nel Tema 15. Suggerimento per l'apertura: chiedere ai partecipanti di indicare un'attività in cui l'AI li ha fatti risparmiare tempo, e poi chiedere che cosa hanno fatto con quel tempo. La risposta introduce bene uno dei temi centrali del modulo. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026, compresi i dati dei due studi sulla produttività, citati nelle versioni pubblicate; la ricerca in questo campo è molto attiva, quindi conviene cercare studi più recenti prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo è comprendere attraverso quali meccanismi l'AI possa contribuire alla creazione di valore aziendale, distinguendo opportunità tecnologiche, benefici potenziali, risultati effettivi, costi, compromessi e condizioni necessarie. La consapevolezza da sviluppare: l'utilizzo dell'AI non produce automaticamente valore. Il valore nasce quando le capacità tecnologiche contribuiscono a risultati rilevanti per l'azienda, i dipendenti o i clienti, tenendo conto della qualità, della produttività, dell'innovazione, dei costi e degli effetti sull'organizzazione. Il messaggio centrale del tema: l'AI crea valore quando contribuisce a miglioramenti rilevanti e verificabili per l'organizzazione; il valore dipende dagli obiettivi, dai risultati effettivamente ottenuti, dai costi necessari e dall'impatto complessivo sulle attività e sui processi. Il confine con il Tema 15: qui spieghiamo come l'AI può creare valore; nel Tema 15 vedremo come valutare e scegliere opportunità specifiche per un'azienda.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Capire i meccanismi con cui l'AI crea valore", "Distinguere opportunità, benefici potenziali e risultati effettivi", "Considerare costi, compromessi e condizioni"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza", headSize: 16, fill: C.accent6, bodySize: 14,
      body: "Usare l'AI non produce automaticamente valore.\n\nIl valore nasce quando le capacità contribuiscono a risultati rilevanti per azienda, dipendenti o clienti, tenendo conto di qualità, produttività, innovazione, costi ed effetti sull'organizzazione." });
  }
  {
    const s = content("Tre equivalenze da evitare", "Il documento di perimetro indica tre equivalenze da evitare, che riassumono bene lo spirito del tema e che conviene presentare subito. Primo: un maggiore utilizzo dell'AI non equivale automaticamente a un maggiore valore aziendale. Si può usare molto uno strumento per attività poco rilevanti, o in modo che i benefici siano annullati dai costi. Secondo: il tempo risparmiato non equivale necessariamente a un identico aumento della produttività. Il tempo liberato può essere assorbito da controlli, o non essere riutilizzabile, o riguardare un'attività che non era il collo di bottiglia. Terzo: la fattibilità tecnologica non equivale a convenienza economica e organizzativa. Che qualcosa si possa fare con l'AI non significa che convenga farlo. Ciascuna di queste equivalenze corrisponde a un errore frequente nel modo in cui si parla di AI in azienda, e ciascuna verrà sviluppata nel modulo. Suggerimento: chiedere ai partecipanti se hanno sentito, in azienda o nei media, affermazioni che cadono in una di queste equivalenze.");
    const e = [["FiBarChart2", "Più utilizzo", "più valore", "Si può usare molto uno strumento per attività poco rilevanti"], ["FiClock", "Tempo risparmiato", "produttività equivalente", "Il tempo liberato può essere assorbito o non riutilizzabile"], ["FiTool", "Fattibilità tecnologica", "convenienza", "Si può fare non significa che convenga"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.15 + i * 1.08;
      shapeBox(s, 0.5, y, 9.0, 0.96, i % 2 ? C.accent6 : C.background2, e[i][1]);
      await iconCircle(s, 0.68, y + 0.2, 0.56, e[i][0]);
      txt(s, e[i][1], { x: 1.4, y: y + 0.06, w: 2.4, h: 0.84, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, "≠", { x: 3.8, y: y + 0.06, w: 0.5, h: 0.84, fontSize: 28, bold: true, color: C.accent5, align: "center", valign: "middle" });
      txt(s, e[i][2], { x: 4.3, y: y + 0.06, w: 2.4, h: 0.84, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[i][3], { x: 6.7, y: y + 0.06, w: 2.7, h: 0.84, fontSize: 11, color: C.text2, valign: "middle" });
    }
    banner(s, 4.4, "Ciascuna corrisponde a un errore frequente nel modo in cui si parla di AI in azienda.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Nove domande guida", "Le nove domande guida accompagnano il modulo. Le prime due riguardano la definizione: che cosa significa creare valore con l'AI, e quali tipi di benefici, economici e non, possiamo riconoscere. Le successive quattro riguardano i meccanismi: perché ridurre il tempo di un'attività non garantisce più produttività, come migliorare la qualità senza introdurre nuovi problemi, come l'AI può amplificare le competenze e rendere possibili attività prima impraticabili, e la differenza tra ottimizzazione e innovazione. La settima riguarda i costi: diretti, indiretti e nascosti. L'ottava la verifica: distinguere valore ipotizzato, beneficio percepito e miglioramento misurato. L'ultima riprende un tema trasversale: perché il miglioramento di una singola attività può non migliorare l'intero processo. Alla fine del modulo torneremo su tutte.");
    qGrid(s, ["Che cosa significa creare valore con l'AI?", "Quali benefici economici e non economici?", "Perché meno tempo non vuol dire più produttività?", "Come migliorare la qualità senza nuovi problemi?", "Come amplificare competenze e fare cose prima impossibili?", "Ottimizzare l'esistente o innovare?", "Quali costi diretti, indiretti e nascosti?", "Valore ipotizzato, percepito o misurato?", "Perché un'attività migliore non migliora il processo?"], 3, 1.12, 1.0, 12);
  }
  {
    const s = content("Il filo conduttore", "Il documento di perimetro organizza il tema in quattro dimensioni. Definire il valore: che cosa significa e in quali dimensioni si manifesta, nei sottotemi 12.1 e 12.2. Comprenderne i meccanismi: attraverso quali vie l'AI produce valore, cioè efficienza e produttività, qualità, amplificazione delle competenze, innovazione, dal 12.3 al 12.6. Considerarne le condizioni: costi, compromessi e vincoli organizzativi, nel 12.7. Verificarne l'effettività: distinguere benefici attesi, percepiti e misurati, nel 12.8. Tre precisazioni trasversali accompagnano tutto il tema. Distinguere sempre benefici potenziali e risultati effettivi. Separare produttività individuale e produttività organizzativa. Riconoscere il valore non immediatamente monetizzabile, senza considerarlo automaticamente dimostrato. Nelle slide, un indicatore in alto a destra ricorda la dimensione di cui stiamo parlando.");
    const d = [["FiCompass", "Definire il valore", "12.1  12.2"], ["FiSettings", "Comprenderne i meccanismi", "12.3  12.4  12.5  12.6"], ["FiSliders", "Considerarne le condizioni", "12.7"], ["FiCheckCircle", "Verificarne l'effettività", "12.8"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 3;
      shapeBox(s, x, 1.15, 2.1, 2.0, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.7, 1.27, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.1, y: 2.03, w: 1.9, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, d[i][2], { x: x + 0.1, y: 2.65, w: 1.9, h: 0.35, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.0, 0.17);
    }
    txt(s, "Tre precisazioni trasversali", { x: 0.5, y: 3.3, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const p = ["Distinguere benefici potenziali e risultati effettivi", "Separare produttività individuale e organizzativa", "Riconoscere il valore non monetizzabile, senza darlo per dimostrato"];
    p.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.7, 2.86, 1.0, t, { fill: C.accent6, fontSize: 12 }));
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è articolato in otto sottotemi, sette con priorità alta e uno, innovazione e business, con priorità media. Vanno compresi e applicati: le dimensioni del valore, efficienza e produttività, benefici netti, risultati individuali e complessivi, benefici attesi e misurati. Vanno conosciuti e compresi: l'ampliamento delle competenze, la qualità, l'innovazione, le opportunità di nuovi prodotti e servizi, i costi indiretti. Vanno solo accennati: ROI analitico, modelli finanziari, business case strutturati, valutazioni di investimento e sistemi avanzati di misurazione delle prestazioni, che saranno ripresi nel Tema 15. Confini: non ripetiamo le funzionalità viste nei Temi dall'8 all'11, perché qui il punto è il valore. Non trattiamo la riprogettazione di flussi, attività e ruoli, del Tema 13; le condizioni informative e tecnologiche, del Tema 14; la selezione delle iniziative, del Tema 15; la gestione del cambiamento, del Tema 16; normativa, sicurezza e governance, dei Temi 17 e 18.");
    pathSlide(s, [["12.1", "Che cosa significa creare valore", "Alta"], ["12.2", "Le dimensioni del valore", "Alta"], ["12.3", "Efficienza e produttività", "Alta"], ["12.4", "Qualità e prestazioni", "Alta"], ["12.5", "Amplificare le competenze", "Alta"], ["12.6", "Innovazione e business", "Media"], ["12.7", "Costi, compromessi, condizioni", "Alta"], ["12.8", "Dal potenziale al misurabile", "Alta"]],
      [["Comprendere e applicare", "Dimensioni, produttività, benefici netti, individuale e organizzativo, atteso e misurato", C.accent1, C.background1], ["Conoscere e comprendere", "Competenze, qualità, innovazione, nuovi servizi, costi indiretti", C.accent6, C.text1], ["Solo accennare", "ROI analitico, modelli finanziari, business case", C.background2, C.text1]]);
  }

  // =====================================================================
  section("12.1 Che cosa significa valore");
  divider("12.1", "Che cosa significa creare valore con l'AI", "Il valore non deriva dalla disponibilità di uno strumento, ma dal suo contributo a un obiettivo concreto", "Partiamo dalla domanda più semplice e più importante: che cosa intendiamo per valore? In questo sottotema, da comprendere, distinguiamo la capacità tecnologica dal valore aziendale, vediamo l'AI come mezzo e non come obiettivo, e chiariamo per chi e a quale livello si crea valore. Introduciamo anche due distinzioni che torneranno per tutto il modulo: tra beneficio percepito ed effettivo, e tra adozione tecnologica e impatto organizzativo.");
  {
    const s = content("Dalla capacità al valore", "Il primo punto del sottotema è la differenza tra capacità tecnologica e valore aziendale. Tra le due c'è una catena di passaggi, e ciascuno può interrompersi. La capacità: che cosa lo strumento sa fare, per esempio riassumere documenti, scrivere bozze, analizzare dati. L'utilizzo: le persone lo usano davvero, nelle attività in cui può servire. Il risultato: l'utilizzo produce un cambiamento osservabile nell'attività, come meno tempo, meno errori, risposte più rapide. Il valore: quel cambiamento conta per l'organizzazione, i dipendenti o i clienti, al netto dei costi necessari. Esempi di interruzione: uno strumento capace che nessuno usa, perché non è integrato nel lavoro; un uso diffuso che non produce risultati, perché riguarda attività marginali; un risultato locale che non cambia nulla per l'organizzazione, perché il tempo risparmiato non viene usato in modo diverso. Gran parte dei discorsi sull'AI si ferma al primo anello, la capacità, e dà per scontati gli altri. Questo modulo serve proprio a guardare gli anelli successivi.");
    valTag(s, 0);
    const ch = [["Capacità", "Che cosa sa fare lo strumento"], ["Utilizzo", "Le persone lo usano davvero"], ["Risultato", "Un cambiamento osservabile"], ["Valore", "Conta per qualcuno, al netto dei costi"]];
    ch.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.05, 1.5, i === 3 ? C.accent1 : (i ? C.accent6 : C.background2), e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.3, w: 1.8, h: 0.42, fontSize: 17, bold: true, color: i === 3 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.75, w: 1.85, h: 0.85, fontSize: 12, color: i === 3 ? C.background1 : C.text1 });
      if (i < 3) arrow(s, x + 2.07, 1.8, 0.2);
    });
    const br = ["Capace, ma nessuno lo usa", "Usato, ma su attività marginali", "Risultato locale, nulla cambia per l'organizzazione"];
    br.forEach((t, i) => chip(s, 1.3 + i * 2.3, 2.9, 2.15, 0.7, t, { fill: C.background2, color: C.accent5, fontSize: 11 }));
    banner(s, 3.85, "Gran parte dei discorsi sull'AI si ferma alla capacità e dà per scontati gli altri anelli.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("L'AI come mezzo", "Il secondo punto: l'AI è un mezzo, non un obiettivo. Sembra ovvio, ma nella pratica è frequente l'approccio opposto: 'dobbiamo usare l'AI', 'cerchiamo dove applicare l'AI', 'quanti dipendenti usano l'AI?'. È l'atteggiamento della soluzione in cerca di un problema. Il documento indica la relazione corretta: problemi, bisogni, obiettivi, risultati. Si parte da un problema o un bisogno reale: i tempi di risposta ai clienti sono troppo lunghi, le offerte contengono errori, i nuovi colleghi impiegano mesi per diventare autonomi. Si definisce un obiettivo: rispondere entro un giorno, dimezzare gli errori, ridurre i tempi di inserimento. Si valutano le soluzioni possibili, tra cui l'AI, ma anche un cambiamento di processo, una regola, una persona in più, un altro strumento. Si misurano i risultati rispetto all'obiettivo. In questa sequenza, l'AI è una delle possibili risposte, e a volte non è la migliore. Partire dall'AI porta invece a progetti che dimostrano che lo strumento funziona, ma non che risolve qualcosa di importante. Un buon segnale: quando si parla di un progetto AI, si riesce a dire quale problema risolve e come si capirà se l'ha risolto?");
    valTag(s, 0);
    const st = [["Problema o bisogno", "Le risposte ai clienti sono lente"], ["Obiettivo", "Rispondere entro un giorno"], ["Soluzioni possibili", "AI, processo, regole, persone, strumenti"], ["Risultato", "Misurato rispetto all'obiettivo"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.2, 2.05, 1.5, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: x + 0.12, y: 1.28, w: 1.85, h: 0.5, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.12, y: 1.8, w: 1.85, h: 0.8, fontSize: 12, italic: true, color: C.text1 });
      if (i < 3) arrow(s, x + 2.07, 1.8, 0.2);
    });
    shapeBox(s, 0.5, 2.9, 9.0, 0.85, C.text1, "anti modello");
    txt(s, [{ text: "La soluzione in cerca di un problema: ", options: { bold: true, color: C.accent6 } }, { text: "'dobbiamo usare l'AI', 'cerchiamo dove applicarla'. Dimostra che lo strumento funziona, non che risolve qualcosa.", options: { color: C.background1 } }], { x: 0.7, y: 2.9, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
    txt(s, "Un buon segnale: si sa dire quale problema risolve, e come si capirà se l'ha risolto?", { x: 0.5, y: 3.95, w: 9, h: 0.5, fontSize: 14, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Per chi e a quale livello", "Il valore ha un destinatario e un livello. Il documento indica tre destinatari. L'organizzazione: risultati economici, capacità operativa, competitività, gestione dei rischi. I dipendenti: meno attività ripetitive e frustranti, più tempo per il lavoro qualificato, supporto nell'apprendimento, minore stress in alcune attività; ma anche, potenzialmente, nuovi carichi e nuove pressioni. I clienti: risposte più rapide, servizi migliori o nuovi, maggiore personalizzazione. I tre valori non coincidono sempre: un'automazione può ridurre i costi per l'organizzazione peggiorando l'esperienza dei clienti, come un servizio di assistenza solo automatico; o migliorare l'esperienza dei clienti aumentando il carico dei dipendenti. E indica tre livelli. Il valore individuale: la singola persona lavora meglio o più rapidamente. Il valore di team: il gruppo coordina meglio, condivide di più, consegna prima. Il valore organizzativo: l'azienda ottiene risultati migliori. Il passaggio da un livello all'altro non è automatico, ed è uno dei temi centrali del modulo: molti benefici si fermano al livello individuale. Aggiungiamo un'ultima distinzione del sottotema: tra benefici economici, misurabili in denaro, e non economici, come la soddisfazione, la qualità del lavoro, la reputazione, che sono reali ma più difficili da misurare.");
    valTag(s, 0);
    const d = [["FiBriefcase", "Organizzazione", "Risultati, capacità, competitività, rischi"], ["FiUsers", "Dipendenti", "Meno ripetitività, più lavoro qualificato; ma anche nuovi carichi"], ["FiSmile", "Clienti", "Risposte rapide, servizi migliori, personalizzazione"]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.15, 2.86, 1.75, { icon: d[i][0], inline: true, head: d[i][1], headSize: 14, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: d[i][2] });
    }
    txt(s, "Tre livelli", { x: 0.5, y: 3.05, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    const l = ["Individuale", "Di team", "Organizzativo"];
    l.forEach((t, i) => {
      chip(s, 0.5 + i * 3.07, 3.42, 2.6, 0.55, t, { fill: [C.background2, C.accent6, C.accent1][i], color: i === 2 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 2) arrow(s, 3.15 + i * 3.07, 3.54, 0.35, C.accent5);
    });
    txt(s, "I valori per i tre destinatari non coincidono sempre, e molti benefici si fermano al livello individuale.", { x: 0.5, y: 4.2, w: 9, h: 0.6, fontSize: 13, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Percepito o effettivo", "Una distinzione che il sottotema introduce e che il 12.8 svilupperà: tra beneficio percepito e beneficio effettivo. Il beneficio percepito è quello che le persone sentono di ottenere: 'con l'AI scrivo le email in metà tempo', 'mi sento più produttivo'. È importante, perché influenza la soddisfazione e l'adozione. Ma non coincide necessariamente con il beneficio effettivo, cioè il cambiamento osservabile nei risultati. Le ragioni della differenza sono diverse. La percezione tende a considerare il tempo di produzione e a trascurare quello di verifica e correzione. Tende a ricordare i casi riusciti e a dimenticare quelli in cui si è dovuto rifare il lavoro. Può confondere la sensazione di fluidità e di sollievo con un risultato migliore. Al contrario, a volte la percezione sottovaluta i benefici, per esempio quando migliorano la qualità o riducono errori che nessuno vedeva. Alcuni studi sul lavoro con l'AI hanno osservato differenze significative tra il tempo che le persone credevano di aver risparmiato e quello misurato. La conclusione pratica è semplice: la percezione è un'informazione utile, ma non una misura. Per sapere se c'è un beneficio, bisogna osservare i risultati.");
    valTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiSmile", head: "Beneficio percepito", headSize: 16, bodySize: 12,
      body: bullets(["'Scrivo le email in metà tempo'", "Conta per soddisfazione e adozione", "Trascura verifica, correzioni, casi falliti"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiBarChart2", head: "Beneficio effettivo", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Il cambiamento osservabile nei risultati", "Comprende tutto il tempo e la qualità", "A volte maggiore del percepito"], { space: 5 }) });
    banner(s, 3.8, "La percezione è un'informazione utile, non una misura. Per sapere se c'è un beneficio, bisogna osservare i risultati.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Adozione non è impatto", "Gli ultimi due punti del sottotema. La dipendenza del valore dal contesto aziendale: lo stesso strumento può creare molto valore in un'azienda e poco in un'altra, a seconda delle attività svolte, della qualità dei dati, dell'organizzazione del lavoro, delle competenze, dei vincoli normativi. I risultati di un'altra azienda, o di uno studio, non si trasferiscono automaticamente. La differenza tra adozione tecnologica e impatto organizzativo: l'adozione misura quanto uno strumento è usato, per esempio quante persone hanno una licenza, quante richieste fanno ogni giorno; l'impatto misura quanto cambiano i risultati dell'organizzazione. Le due cose possono divergere a lungo. Un riferimento storico utile è il cosiddetto paradosso della produttività, formulato dall'economista Robert Solow nel 1987: 'si vede l'era dei computer dappertutto, tranne che nelle statistiche della produttività'. Ci vollero anni perché la diffusione dei computer si traducesse in aumenti di produttività misurabili, e il motivo principale fu che le organizzazioni dovevano cambiare il modo di lavorare, non solo adottare le nuove tecnologie. Non è detto che con l'AI accada lo stesso, ma la lezione è utile: l'adozione è una condizione necessaria, non una misura del valore prodotto.");
    valTag(s, 0);
    await card(s, 0.5, 1.2, 4.35, 2.0, { icon: "FiUsers", head: "Adozione", headSize: 16, bodySize: 12,
      body: bullets(["Licenze, utenti attivi, richieste", "Quanto è usato lo strumento"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.0, { icon: "FiTrendingUp", head: "Impatto", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Tempi, qualità, costi, risultati", "Quanto cambiano i risultati dell'organizzazione"], { space: 4 }) });
    shapeBox(s, 0.5, 3.4, 9.0, 1.1, C.text1, "solow");
    txt(s, [{ text: "\"Si vede l'era dei computer dappertutto, tranne che nelle statistiche della produttività.\"", options: { italic: true, color: C.background1, breakLine: true } }, { text: "Robert Solow, 1987", options: { color: C.accent6, fontSize: 11 } }], { x: 0.75, y: 3.4, w: 8.5, h: 1.1, fontSize: 14, valign: "middle" });
    txt(s, "L'adozione è una condizione necessaria, non una misura del valore. Il valore dipende anche dal contesto.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, bold: true, color: C.accent1 });
  }
  keySlide("Il valore non deriva dalla disponibilità di uno strumento, ma dal suo contributo a un obiettivo concreto e rilevante.", "Sottotema 12.1  ·  Che cosa significa creare valore con l'AI", "Concetto chiave del primo sottotema. Tra la capacità di uno strumento e il valore per l'azienda c'è una catena, capacità, utilizzo, risultato, valore, e ogni anello può interrompersi. L'AI è un mezzo: si parte da problemi e obiettivi, non dallo strumento. Il valore ha destinatari diversi, organizzazione, dipendenti e clienti, e livelli diversi, individuale, di team e organizzativo, che non coincidono sempre. Il beneficio percepito non è il beneficio effettivo, e l'adozione non è l'impatto. Esercizio suggerito: prendere un'iniziativa AI nota ai partecipanti e ricostruire la catena, indicando per ciascun anello che cosa si sa e che cosa si dà per scontato.");

  // =====================================================================
  section("12.2 Dimensioni del valore");
  divider("12.2", "Le principali dimensioni del valore", "Il valore è multidimensionale e non coincide soltanto con riduzione dei costi o risparmio di tempo", "Se il valore non è solo risparmio di tempo, in quali forme si presenta? In questo sottotema, da comprendere e distinguere, costruiamo una mappa sintetica delle dimensioni del valore. Il documento chiede che resti una mappa: le dimensioni principali verranno approfondite nei sottotemi successivi, l'efficienza nel 12.3, la qualità nel 12.4, le competenze nel 12.5, l'innovazione nel 12.6. Qui ci interessa vederle insieme, distinguere i benefici tangibili da quelli intangibili, il valore economico diretto da quello strategico, e capire che tra dimensioni diverse ci sono spesso compromessi.");
  {
    const s = content("Una mappa delle dimensioni", "Il sottotema elenca otto dimensioni principali del valore. Efficienza e riduzione dei tempi: fare le stesse cose con meno tempo o meno risorse. Produttività e capacità operativa: fare di più con le stesse risorse, gestire più volumi. Qualità e accuratezza dei risultati: risultati più completi, corretti, coerenti. Riduzione degli errori e delle rilavorazioni: meno lavoro da rifare. Esperienza del cliente: risposte più rapide, più disponibili, più personalizzate. Supporto alle decisioni: decisioni prese con più informazioni, analisi, scenari. Flessibilità e scalabilità: adattarsi a picchi di lavoro, crescere senza aumentare i costi nella stessa misura. Innovazione di prodotti e servizi: offrire qualcosa di nuovo. La mappa serve come promemoria: quando si valuta un'iniziativa AI, conviene chiedersi su quali dimensioni può avere un effetto, positivo o negativo, invece di guardare solo al tempo risparmiato. Molte iniziative hanno il loro valore principale in una dimensione diversa dall'efficienza, come la qualità o l'esperienza del cliente, e rischiano di essere giudicate male se si misura solo il tempo.");
    valTag(s, 0);
    const d = [["FiClock", "Efficienza", "Meno tempo e risorse"], ["FiTrendingUp", "Produttività", "Più volumi, stesse risorse"], ["FiCheckCircle", "Qualità", "Più completo, corretto, coerente"], ["FiRotateCcw", "Meno errori", "Meno rilavorazioni"], ["FiSmile", "Esperienza cliente", "Rapidità, disponibilità, personalizzazione"], ["FiCompass", "Decisioni", "Più informazioni e scenari"], ["FiMaximize", "Flessibilità", "Picchi e crescita"], ["FiStar", "Innovazione", "Prodotti e servizi nuovi"]];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.15 + row * 1.42;
      shapeBox(s, x, y, 2.15, 1.3, row ? C.accent6 : C.background2, d[i][1]);
      await iconCircle(s, x + 0.15, y + 0.15, 0.48, d[i][0]);
      txt(s, d[i][1], { x: x + 0.72, y: y + 0.12, w: 1.38, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, d[i][2], { x: x + 0.15, y: y + 0.72, w: 1.9, h: 0.52, fontSize: 11, color: C.text2 });
    }
    banner(s, 4.1, "Molte iniziative hanno il loro valore principale fuori dall'efficienza: misurare solo il tempo le giudica male.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Tangibili e intangibili", "Due distinzioni che aiutano a classificare i benefici. La prima: benefici tangibili e intangibili. I tangibili si misurano direttamente, spesso in denaro o in unità fisiche: ore risparmiate, costi ridotti, numero di pratiche gestite, errori evitati. Gli intangibili sono reali ma difficili da misurare direttamente: soddisfazione dei dipendenti, reputazione, qualità percepita, capacità di attrarre talenti, apprendimento organizzativo. La seconda: valore economico diretto e valore strategico o organizzativo. Il valore economico diretto si traduce in risultati economici nel breve periodo: minori costi, maggiori ricavi. Il valore strategico o organizzativo prepara risultati futuri o rafforza l'organizzazione: nuove competenze, conoscenza meglio organizzata, capacità di sperimentare, posizionamento rispetto ai concorrenti. Una delle precisazioni trasversali del tema riguarda proprio questi benefici: il valore non immediatamente monetizzabile va riconosciuto, ma senza considerarlo automaticamente dimostrato. Dire che un'iniziativa ha 'valore strategico' non basta: bisogna poter indicare in che cosa consiste e come si riconoscerà. Altrimenti l'etichetta diventa un modo per giustificare iniziative senza risultati.");
    valTag(s, 0);
    table(s, [["", "Tangibile", "Intangibile"],
      ["Economico diretto", "Costi ridotti, ricavi, ore risparmiate", "Minore turnover, meno reclami"],
      ["Strategico o organizzativo", "Capacità di gestire più volumi", "Competenze, conoscenza, reputazione"]],
      { y: 1.15, colW: [2.6, 3.2, 3.2], rowH: 0.6, fontSize: 13 });
    shapeBox(s, 0.5, 3.15, 9.0, 1.75, C.text1, "attenzione strategico");
    txt(s, "Riconoscere, non dare per dimostrato", { x: 0.75, y: 3.25, w: 8.5, h: 0.4, fontSize: 15, bold: true, color: C.accent6 });
    txt(s, "Dire che un'iniziativa ha 'valore strategico' non basta: in che cosa consiste, e come si riconoscerà? Altrimenti l'etichetta giustifica iniziative senza risultati.", { x: 0.75, y: 3.7, w: 8.5, h: 1.1, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Compromessi tra dimensioni", "Le dimensioni del valore non si muovono sempre nella stessa direzione: spesso migliorarne una ne peggiora un'altra. Il sottotema chiede di riconoscere questi compromessi. Alcuni esempi tipici. Velocità contro qualità: produrre più rapidamente le risposte ai clienti con l'AI può ridurre l'accuratezza se la revisione viene compressa. Efficienza contro esperienza del cliente: sostituire il contatto umano con un assistente automatico riduce i costi, ma può peggiorare la soddisfazione dei clienti che hanno problemi complessi. Standardizzazione contro personalizzazione: risposte coerenti e uniformi possono risultare generiche. Produttività contro carico di lavoro: più volumi gestiti con le stesse persone possono aumentare la pressione e lo stress. Costi contro rischi: ridurre i controlli fa risparmiare tempo, ma aumenta la probabilità che un errore arrivi all'esterno. Riconoscere i compromessi non significa rinunciare ai benefici, ma scegliere consapevolmente quale dimensione privilegiare e quale livello delle altre è accettabile. E significa misurare più dimensioni insieme: un'iniziativa che migliora l'efficienza del 30 per cento peggiorando la qualità del 10 per cento può essere un buon affare o un cattivo affare, a seconda del contesto.");
    valTag(s, 0);
    const t = [["Velocità", "Qualità"], ["Efficienza", "Esperienza del cliente"], ["Standardizzazione", "Personalizzazione"], ["Produttività", "Carico di lavoro"], ["Costi", "Rischi"]];
    t.forEach((e, i) => {
      const y = 1.15 + i * 0.6;
      chip(s, 0.5, y, 3.6, 0.5, e[0], { fill: C.accent6, fontSize: 13 });
      txt(s, "↔", { x: 4.1, y, w: 0.8, h: 0.5, fontSize: 20, bold: true, color: C.accent5, align: "center", valign: "middle" });
      chip(s, 4.9, y, 3.6, 0.5, e[1], { fill: C.background2, fontSize: 13 });
    });
    banner(s, 4.25, "Scegliere consapevolmente che cosa privilegiare, e misurare più dimensioni insieme.", { h: 0.65, fontSize: 14 });
  }
  {
    const s = content("Un esempio con più dimensioni", "Un esempio fittizio aiuta a vedere le dimensioni insieme. Un ufficio di assistenza clienti introduce un assistente AI che propone agli operatori una bozza di risposta per ogni richiesta, basata sulla documentazione dei prodotti. Dopo alcuni mesi, i risultati osservati sono quelli in slide, numeri inventati a scopo didattico. Il tempo medio per risposta è sceso. Il numero di richieste gestite per operatore è salito. La coerenza delle risposte è migliorata, perché tutte si basano sulla stessa documentazione. I nuovi operatori diventano autonomi più rapidamente. Ma il tasso di risposte da correggere dopo un reclamo è leggermente aumentato, perché alcune bozze contenevano informazioni non aggiornate e non tutti gli operatori le controllavano. E alcuni operatori esperti riferiscono di sentirsi meno valorizzati. Il valore di questa iniziativa non si riassume in un solo numero. Ci sono benefici di efficienza, di produttività, di qualità e di competenze, e un costo in termini di errori e di soddisfazione di una parte del personale. Una valutazione onesta li considera tutti, e porta a interventi mirati: aggiornare la documentazione, rafforzare la revisione, coinvolgere gli esperti nel miglioramento delle bozze.");
    valTag(s, 0);
    table(s, [["Dimensione", "Effetto osservato", "Segno"],
      ["Efficienza", "Tempo medio per risposta ridotto", "+"],
      ["Produttività", "Più richieste per operatore", "+"],
      ["Qualità", "Risposte più coerenti", "+"],
      ["Competenze", "Nuovi operatori autonomi prima", "+"],
      ["Errori", "Più correzioni dopo reclamo", "-"],
      ["Dipendenti", "Esperti meno valorizzati", "-"]],
      { y: 1.15, colW: [2.2, 5.6, 1.2], rowH: 0.38, fontSize: 12, blankCorner: false });
    txt(s, "Esempio fittizio: assistente che propone bozze di risposta agli operatori", { x: 0.5, y: 3.85, w: 9, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    banner(s, 4.2, "Il valore non si riassume in un numero. Una valutazione onesta considera tutto, e porta a interventi mirati.", { h: 0.7, fontSize: 13 });
  }
  keySlide("Il valore è multidimensionale e non coincide soltanto con riduzione dei costi o risparmio di tempo.", "Sottotema 12.2  ·  Le principali dimensioni del valore", "Concetto chiave del sottotema 12.2. Il valore dell'AI si manifesta in molte dimensioni: efficienza, produttività, qualità, meno errori, esperienza del cliente, decisioni, flessibilità, innovazione. Ci sono benefici tangibili e intangibili, economici diretti e strategici, e il valore non monetizzabile va riconosciuto senza darlo per dimostrato. Tra dimensioni diverse ci sono compromessi, che vanno scelti consapevolmente. Esercizio suggerito: per un'attività del proprio lavoro in cui si usa o si potrebbe usare l'AI, compilare la mappa delle otto dimensioni indicando per ciascuna l'effetto atteso, positivo, negativo o nullo.");

  // =====================================================================
  section("12.3 Efficienza e produttività");
  divider("12.3", "AI, efficienza e produttività del lavoro", "Un risparmio di tempo locale non implica un beneficio equivalente per l'organizzazione", "Entriamo nei meccanismi, partendo da quello più citato: l'efficienza. È il beneficio che quasi tutti associano all'AI, e il più facile da percepire: si scrive più in fretta, si riassume più in fretta, si analizza più in fretta. In questo sottotema, da comprendere e applicare, vediamo perché il tempo risparmiato non si trasforma automaticamente in produttività, attraverso due integrazioni centrali del tema: il paradosso della produttività individuale, e il passaggio dall'efficienza locale al risultato complessivo. È probabilmente il sottotema più importante per chi deve valutare iniziative AI in azienda.");
  {
    const s = content("Dove l'AI fa risparmiare tempo", "Partiamo dai benefici, che sono reali. L'AI può supportare due tipi di attività. Le attività ripetitive: compilare, trascrivere, classificare, riformattare, estrarre dati, preparare documenti standard. Qui l'AI riduce il lavoro manuale, spesso in modo consistente. Le attività cognitive: scrivere, riassumere, analizzare, cercare informazioni, preparare una presentazione, scrivere codice. Qui l'AI accelera la produzione di una prima versione, su cui la persona lavora. Il sottotema indica tre effetti. L'accelerazione delle attività e la riduzione dei tempi di esecuzione: la stessa attività richiede meno tempo. L'incremento della capacità produttiva: con le stesse persone si possono gestire più attività. La riduzione dei tempi di attesa, quando l'AI permette di rispondere o di produrre senza dover aspettare la disponibilità di qualcuno. Alcuni studi su attività specifiche hanno osservato aumenti di produttività significativi, che vedremo tra poco, con le loro avvertenze. Il punto di partenza del sottotema è quindi positivo: l'AI può davvero far risparmiare tempo. La domanda è che cosa succede a quel tempo, e se il risparmio di una singola attività arriva fino ai risultati dell'organizzazione.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiRepeat", head: "Attività ripetitive", headSize: 16, bodySize: 12,
      body: bullets(["Compilare, trascrivere, classificare", "Estrarre dati, documenti standard", "Meno lavoro manuale"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCpu", head: "Attività cognitive", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Scrivere, riassumere, analizzare", "Cercare, preparare, programmare", "Una prima versione più rapida"], { space: 5 }) });
    const e = ["Meno tempo per attività", "Più capacità con le stesse persone", "Meno attese"];
    e.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.7, 2.86, 0.6, t, { fill: C.background2, fontSize: 13 }));
    txt(s, "La domanda del sottotema: che cosa succede a quel tempo?", { x: 0.5, y: 4.45, w: 9, h: 0.45, fontSize: 14, bold: true, italic: true, color: C.accent1 });
  }
  {
    const s = content("Efficienza e produttività", "Il sottotema chiede di distinguere due concetti spesso usati come sinonimi. L'efficienza riguarda le risorse usate per un'attività: un'attività è più efficiente se richiede meno tempo, meno costi, meno sforzo per ottenere lo stesso risultato. La produttività riguarda il rapporto tra i risultati ottenuti e le risorse impiegate, in un periodo: quante pratiche gestite, quanti clienti serviti, quanto valore prodotto per persona, per ora, per euro. Un aumento di efficienza può tradursi in un aumento di produttività, ma solo a certe condizioni: che il tempo risparmiato venga usato per produrre altri risultati, e che quei risultati servano. Se l'ufficio legale prepara i contratti in metà tempo, ma il numero di contratti da preparare è lo stesso, l'efficienza è aumentata ma la produttività, nel senso dei risultati per l'organizzazione, no, a meno che il tempo liberato venga impiegato in altro modo utile. L'esempio mostra la distinzione: l'efficienza si misura sull'attività, la produttività sui risultati. È la base delle due integrazioni che vedremo.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiClock", head: "Efficienza", headSize: 17, bodySize: 13,
      body: "Meno risorse per la stessa attività: tempo, costi, sforzo.\n\nSi misura sull'attività." });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiTrendingUp", head: "Produttività", headSize: 17, bodySize: 13, fill: C.accent6,
      body: "Risultati ottenuti rispetto alle risorse, in un periodo.\n\nSi misura sui risultati." });
    shapeBox(s, 0.5, 3.6, 9.0, 1.3, C.text1, "esempio");
    txt(s, [{ text: "Esempio: ", options: { bold: true, color: C.accent6 } }, { text: "contratti preparati in metà tempo, ma il numero di contratti da preparare è lo stesso. L'efficienza è aumentata; la produttività solo se il tempo liberato viene usato in altro modo utile.", options: { color: C.background1 } }], { x: 0.75, y: 3.6, w: 8.5, h: 1.3, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Risparmiato o recuperato", "Il primo motivo per cui il tempo risparmiato non è tutto recuperato è la verifica. Il sottotema parla di effetti di verifica e revisione sui tempi, e di differenza tra tempo risparmiato e tempo effettivamente recuperato. L'esempio fittizio in slide lo mostra con numeri inventati. Preparare una relazione richiedeva 120 minuti. Con l'AI, la prima bozza si ottiene in 20 minuti: un risparmio apparente di 100 minuti. Ma la bozza va letta e verificata, 25 minuti; alcune parti vanno corrette o riscritte, 20 minuti; e talvolta serve un passaggio aggiuntivo per controllare dati e fonti, 15 minuti. Il tempo totale con l'AI è di 80 minuti: il risparmio effettivo è di 40 minuti, meno della metà di quello apparente. È ancora un risparmio reale, e significativo. Ma chi misura solo il tempo di produzione della bozza sopravvaluta il beneficio di più del doppio. Nel Tema 7 abbiamo visto che la verifica è necessaria; qui ne vediamo il costo. E il costo della verifica varia molto: per attività in cui gli errori sono facili da individuare è basso, per attività in cui sono difficili da notare può annullare il risparmio, o persino superarlo.");
    valTag(s, 1);
    s.addChart(pres.charts.BAR, [
      { name: "Produzione", labels: ["Senza AI", "Con AI"], values: [120, 20] },
      { name: "Verifica", labels: ["Senza AI", "Con AI"], values: [0, 25] },
      { name: "Correzione", labels: ["Senza AI", "Con AI"], values: [0, 20] },
      { name: "Controllo dati e fonti", labels: ["Senza AI", "Con AI"], values: [0, 15] }], {
      x: 0.5, y: 1.1, w: 5.4, h: 3.1, barDir: "bar", barGrouping: "stacked", chartColors: [HEX.a2, HEX.a1, HEX.a5, HEX.a4],
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
      valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 10, valAxisMinVal: 0, valAxisMaxVal: 130, valGridLine: { color: HEX.a3, size: 0.5 },
      showLegend: true, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, barGapWidthPct: 50,
      showTitle: true, title: "Minuti per preparare una relazione (esempio fittizio)", titleFontSize: 12, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
    const k = [["Risparmio apparente", "100 min", C.background2, C.text1], ["Risparmio effettivo", "40 min", C.accent1, C.background1]];
    k.forEach((e, i) => {
      const y = 1.2 + i * 1.3;
      shapeBox(s, 6.15, y, 3.35, 1.15, e[2], e[0]);
      txt(s, e[0], { x: 6.35, y: y + 0.1, w: 3.0, h: 0.35, fontSize: 13, color: e[3] });
      txt(s, e[1], { x: 6.35, y: y + 0.45, w: 3.0, h: 0.6, fontSize: 28, bold: true, color: i ? C.background1 : C.accent5 });
    });
    banner(s, 4.4, "Chi misura solo la produzione della bozza sopravvaluta il beneficio di più del doppio.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Il paradosso della produttività", "L'integrazione A del tema: il paradosso della produttività individuale. Un risparmio di tempo locale non implica un beneficio equivalente per l'organizzazione. Anche quando il tempo è davvero risparmiato, al netto della verifica, che cosa ne succede? Il documento indica alcune possibilità, che conviene esplicitare. Il tempo liberato viene riutilizzato in attività di valore: più clienti seguiti, progetti prima rimandati, lavoro di migliore qualità. È il caso in cui il beneficio si trasforma davvero in valore. Il tempo viene assorbito da controlli e rilavorazioni, come abbiamo visto. Il tempo non è riutilizzabile: venti minuti risparmiati in giorni diversi, sparsi nella settimana, non si sommano facilmente in un'attività utile; oppure non ci sono altre attività di valore da svolgere. Il tempo si disperde: più riunioni, più email, più rifiniture di dettagli non necessari, a volte semplicemente un ritmo meno intenso, che può anche essere un beneficio per le persone, ma non è produttività. Nessuno di questi esiti è sbagliato in sé. Ma solo il primo produce un aumento di produttività per l'organizzazione, e non avviene da solo: richiede che qualcuno decida come usare la capacità liberata.");
    valTag(s, 1);
    const d = [["FiTrendingUp", "Riutilizzato in attività di valore", "Il beneficio diventa valore", C.accent1, C.background1], ["FiRotateCcw", "Assorbito da controlli e rilavorazioni", "Il beneficio si riduce", C.background2, C.text1], ["FiPieChart", "Frammentato, non riutilizzabile", "Minuti sparsi, nulla di utile da fare", C.background2, C.text1], ["FiWind", "Disperso", "Più riunioni, email, rifiniture", C.background2, C.text1]];
    for (let i = 0; i < 4; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.65, y = 1.15 + row * 1.2;
      shapeBox(s, x, y, 4.35, 1.08, d[i][3], d[i][1]);
      await iconCircle(s, x + 0.18, y + 0.24, 0.6, d[i][0], d[i][4] === C.background1 ? C.background1 : C.accent1, d[i][4] === C.background1 ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.95, y: y + 0.1, w: 3.3, h: 0.5, fontSize: 13, bold: true, color: d[i][4], valign: "middle" });
      txt(s, d[i][2], { x: x + 0.95, y: y + 0.58, w: 3.3, h: 0.42, fontSize: 12, color: d[i][4] });
    }
    banner(s, 3.65, "Solo il primo esito produce produttività per l'organizzazione, e non avviene da solo: qualcuno deve decidere come usare la capacità liberata.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Valorizzare la capacità liberata", "Se il tempo liberato non si trasforma da solo in valore, come lo si valorizza? Il sottotema parla di possibilità di valorizzare la capacità liberata, e la parola chiave è decidere. Alcune strade possibili. Assorbire più volumi senza aumentare le persone: utile quando la domanda cresce, o quando c'erano arretrati. Spostare tempo verso attività di maggior valore: dalla preparazione dei documenti alla relazione con i clienti, dalla compilazione all'analisi. Migliorare la qualità: usare il tempo per verifiche più accurate, per personalizzare, per approfondire. Ridurre i tempi di risposta o di consegna, se questo conta per i clienti. Dedicare tempo alla formazione e al miglioramento dei processi. Ridurre il ricorso a risorse esterne o agli straordinari. Ciascuna strada ha un valore diverso, e la scelta dipende dagli obiettivi dell'organizzazione. Il punto è che deve essere una scelta, presa a livello di team o di organizzazione, e non lasciata al caso. Il modo in cui il lavoro viene riorganizzato per valorizzare la capacità liberata è il tema del Tema 13; qui ci basta riconoscere che senza questa scelta il beneficio individuale resta individuale.");
    valTag(s, 1);
    await iconGrid(s, [
      { icon: "FiInbox", head: "Più volumi", body: "Domanda in crescita, arretrati" },
      { icon: "FiArrowUpRight", head: "Attività di maggior valore", body: "Dalla compilazione all'analisi e alla relazione" },
      { icon: "FiCheckCircle", head: "Più qualità", body: "Verifiche, personalizzazione, approfondimento" },
      { icon: "FiFastForward", head: "Tempi più brevi", body: "Risposte e consegne, se contano per i clienti" },
      { icon: "FiBookOpen", head: "Formazione e miglioramento", body: "Competenze e processi" },
      { icon: "FiMinusCircle", head: "Meno risorse esterne", body: "Consulenze, straordinari" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Deve essere una scelta di team o di organizzazione, non lasciata al caso.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Colli di bottiglia", "L'integrazione D del tema: dall'efficienza locale al risultato complessivo. Accelerare un'attività non migliora necessariamente l'intero processo, soprattutto quando il principale collo di bottiglia si trova altrove. L'esempio del documento di perimetro, con numeri inventati a scopo didattico, è in slide. Un'attività prevede tre passaggi: preparazione, revisione, approvazione. Prima dell'AI richiedevano 30, 20 e 10 minuti, per un totale di 60. Con l'AI la preparazione scende a 10 minuti, due terzi in meno; ma la revisione sale a 25, perché bisogna verificare il lavoro dell'AI; l'approvazione resta a 10. Il totale scende a 45 minuti: una riduzione del 25 per cento, molto meno dei due terzi della preparazione. E il documento aggiunge che neppure questo miglioramento dimostra da solo un pari valore economico: contano il riutilizzo del tempo, la qualità e i vincoli del processo. Se, per esempio, l'approvazione avviene una sola volta al giorno, perché il responsabile la fa la sera, il tempo complessivo dalla richiesta alla consegna non cambia affatto: il collo di bottiglia è l'approvazione, non la preparazione. È un principio noto nella gestione delle operazioni, reso popolare dalla teoria dei vincoli: il ritmo di un processo è determinato dal suo passaggio più lento.");
    valTag(s, 1);
    s.addChart(pres.charts.BAR, [{ name: "Prima dell'AI", labels: ["Preparazione", "Revisione", "Approvazione"], values: [30, 20, 10] }, { name: "Con AI", labels: ["Preparazione", "Revisione", "Approvazione"], values: [10, 25, 10] }], {
      x: 0.5, y: 1.1, w: 5.2, h: 2.9, barDir: "col", chartColors: [HEX.a2, HEX.a1], showValue: true, dataLabelFontSize: 10, dataLabelColor: HEX.dk1, dataLabelPosition: "outEnd",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 35, valGridLine: { style: "none" },
      showLegend: true, legendPos: "b", legendFontSize: 10, legendFontFace: "+mn-lt", legendColor: HEX.dk2, barGapWidthPct: 60,
      showTitle: true, title: "Minuti per passaggio (esempio fittizio)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
    const k = [["Preparazione", "-67%", C.background2, C.text1], ["Processo complessivo", "-25%", C.accent1, C.background1]];
    k.forEach((e, i) => {
      const y = 1.2 + i * 1.3;
      shapeBox(s, 6.0, y, 3.5, 1.15, e[2], e[0]);
      txt(s, e[0], { x: 6.2, y: y + 0.1, w: 3.1, h: 0.35, fontSize: 13, color: e[3] });
      txt(s, e[1], { x: 6.2, y: y + 0.45, w: 3.1, h: 0.6, fontSize: 28, bold: true, color: i ? C.background1 : C.accent1 });
    });
    banner(s, 4.15, "Se l'approvazione avviene una volta al giorno, il tempo dalla richiesta alla consegna non cambia: il collo di bottiglia è altrove.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Individuale e organizzativa", "Due punti del sottotema completano il quadro. La differenza tra produttività individuale e organizzativa, che è una delle precisazioni trasversali del tema. La produttività individuale misura che cosa riesce a fare una persona; quella organizzativa che cosa riesce a fare l'organizzazione nel suo insieme. La seconda non è la somma della prima, perché dipende dalle interdipendenze tra le persone, dai processi, dai colli di bottiglia, dall'uso della capacità liberata. Il rischio di trasferire il lavoro anziché eliminarlo. È un fenomeno sottile e frequente. Se con l'AI si scrivono più facilmente email più lunghe, qualcuno deve leggerle. Se si producono più facilmente report, qualcuno deve esaminarli. Se si generano più facilmente proposte, qualcuno deve valutarle. Il lavoro risparmiato da chi produce viene trasferito a chi riceve, e il totale può persino aumentare. Lo stesso accade quando l'AI sposta il lavoro dalla produzione alla verifica, cioè dal giovane collaboratore che prepara al responsabile che controlla, spesso una persona più costosa e con meno tempo. Per riconoscere questi effetti bisogna guardare all'intero flusso di lavoro, non solo a chi usa lo strumento.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiUser", head: "Individuale e organizzativa", headSize: 15, bodySize: 12,
      body: bullets(["Ciò che fa una persona, ciò che fa l'organizzazione", "La seconda non è la somma della prima", "Interdipendenze, processi, colli di bottiglia"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiShuffle", head: "Lavoro trasferito", headSize: 15, bodySize: 12, fill: C.accent6, iconBg: C.accent5,
      body: bullets(["Email più lunghe: qualcuno deve leggerle", "Più report: qualcuno deve esaminarli", "Dalla produzione alla verifica, verso chi costa di più"], { space: 4 }) });
    chip(s, 0.5, 3.6, 2.6, 0.7, "Chi produce risparmia", { fill: C.accent6, fontSize: 13 });
    arrow(s, 3.2, 3.79, 0.5, C.accent5);
    chip(s, 3.8, 3.6, 2.6, 0.7, "Chi riceve lavora di più", { fill: C.background2, fontSize: 13 });
    txt(s, "Il totale può persino aumentare", { x: 6.6, y: 3.6, w: 2.9, h: 0.7, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    txt(s, "Guardare all'intero flusso di lavoro, non solo a chi usa lo strumento.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 13, italic: true, bold: true, color: C.accent1 });
  }
  {
    const s = content("Che cosa dicono alcuni studi", "Alcuni studi hanno misurato gli effetti dell'AI generativa sulla produttività in contesti reali o controllati. Due sono spesso citati, e utili anche per le loro avvertenze. Il primo, di Brynjolfsson, Li e Raymond, pubblicato nel 2025 sul Quarterly Journal of Economics, ha osservato 5.172 operatori di assistenza clienti di un'azienda di software: con un assistente AI, il numero di problemi risolti per ora è aumentato in media del 15 per cento, con un aumento del 36 per cento per gli operatori meno esperti e nessun aumento significativo per i più esperti. Se qualcuno ricorda i dati del 14 e del 34 per cento: vengono dalla prima versione del 2023, ancora molto citata. Il secondo, di Dell'Acqua e colleghi, presentato nel 2023 e pubblicato nel 2026 sulla rivista Organization Science, ha coinvolto 758 consulenti di una società di consulenza. Su compiti adatti alle capacità dell'AI, chi la usava ha completato in media il 12,2 per cento di compiti in più, il 25,1 per cento più velocemente e con una qualità superiore di circa il 32 per cento; su un compito scelto apposta al di fuori di quelle capacità, chi usava l'AI arrivava alla soluzione corretta in media 19 punti percentuali meno spesso di chi lavorava senza. Se qualcuno ricorda il dato 'oltre il 40 per cento' sulla qualità: viene dalla prima versione del 2023. Gli autori parlano di una frontiera tecnologica frastagliata: non è sempre evidente quali compiti stiano al di qua o al di là. Gli stessi studi sono presentati brevemente nel Tema 1 come segnale di rilevanza; qui li usiamo per ragionare sul valore. Tre avvertenze, coerenti con il documento. I risultati riguardano compiti e contesti specifici, e non si trasferiscono automaticamente. Misurano la produttività su attività, non necessariamente su risultati organizzativi. E il documento chiede di evitare di trasformare stime o esperienze isolate in promesse generali di produttività.");
    valTag(s, 1);
    await card(s, 0.5, 1.15, 4.35, 2.45, { icon: "FiHeadphones", head: "Assistenza clienti (2025)", headSize: 14, bodySize: 12,
      body: bullets(["5.172 operatori", "+15% di problemi risolti per ora, in media", "+36% per i meno esperti, nessun aumento significativo per i più esperti"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.45, { icon: "FiBriefcase", head: "Consulenti (2026)", headSize: 14, bodySize: 12, fill: C.accent6,
      body: bullets(["Compiti adatti: +12% compiti, +25% velocità, qualità +32% circa", "Compito fuori dalle capacità: 19 punti in meno di soluzioni corrette", "Una frontiera 'frastagliata'"], { space: 4 }) });
    shapeBox(s, 0.5, 3.8, 9.0, 1.15, C.text1, "avvertenze");
    txt(s, "Avvertenze", { x: 0.75, y: 3.86, w: 8.5, h: 0.32, fontSize: 13, bold: true, color: C.accent6 });
    txt(s, "Compiti e contesti specifici, non trasferibili automaticamente; produttività su attività, non su risultati organizzativi; nessuna promessa generale.", { x: 0.75, y: 4.2, w: 8.5, h: 0.7, fontSize: 12, color: C.background1 });
  }

  {
    const s = content("Velocità, qualità, carichi", "L'ultimo punto del sottotema: i compromessi tra velocità, qualità e carichi di lavoro, applicati all'efficienza. Quando l'AI accelera un'attività, si aprono tre possibilità, e la scelta tra esse ha conseguenze diverse. Si può mantenere la stessa qualità e liberare tempo: il caso ideale, se il tempo viene valorizzato. Si può aumentare la velocità a scapito della qualità, comprimendo la verifica: un rischio frequente quando ci si aspetta che l'AI faccia risparmiare tempo e la pressione sui tempi aumenta; gli errori aumentano, e spesso vengono pagati più avanti nel processo o dai clienti. Si può aumentare il volume di lavoro richiesto a ogni persona, assumendo che l'AI renda tutto più rapido: se le aspettative crescono più del beneficio reale, il risultato è un aumento dei carichi e dello stress, e una spinta a ridurre i controlli. Quest'ultimo effetto è particolarmente importante per chi gestisce persone: se gli obiettivi vengono aumentati sulla base dei benefici attesi invece che di quelli misurati, il divario ricade sulle persone. È anche un buon motivo per misurare i benefici prima di cambiare gli obiettivi, come vedremo nel 12.8.");
    valTag(s, 1);
    const c = [["Stessa qualità, tempo liberato", "Il caso ideale, se il tempo viene valorizzato", C.accent6, C.text1], ["Più velocità, meno qualità", "Verifica compressa: errori pagati più avanti o dai clienti", C.background2, C.text1], ["Più volume per persona", "Aspettative oltre il beneficio reale: carichi, stress, meno controlli", C.text1, C.background1]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.92;
      shapeBox(s, 0.5, y, 9.0, 0.82, e[2], e[0]);
      txt(s, e[0], { x: 0.7, y, w: 3.3, h: 0.82, fontSize: 14, bold: true, color: e[3] === C.background1 ? C.accent6 : C.accent1, valign: "middle" });
      txt(s, e[1], { x: 4.0, y, w: 5.3, h: 0.82, fontSize: 13, color: e[3], valign: "middle" });
    });
    banner(s, 4.0, "Se gli obiettivi crescono sui benefici attesi invece che misurati, il divario ricade sulle persone.", { h: 0.85, fontSize: 14 });
  }
  keySlide("Un risparmio di tempo locale non implica un beneficio equivalente per l'organizzazione; accelerare un'attività non migliora il processo se il collo di bottiglia è altrove.", "Sottotema 12.3  ·  AI, efficienza e produttività del lavoro", "Concetto chiave del sottotema 12.3, che riunisce le integrazioni A e D. L'AI può far risparmiare tempo su attività ripetitive e cognitive. Ma efficienza e produttività sono diverse; il tempo risparmiato si riduce con la verifica; il tempo liberato può essere riutilizzato, assorbito, frammentato o disperso, e diventa valore solo se qualcuno decide come usarlo; il processo va al ritmo del suo collo di bottiglia; la produttività organizzativa non è la somma di quella individuale, e il lavoro può essere trasferito invece che eliminato. Gli studi disponibili mostrano benefici reali su compiti specifici, da non trasformare in promesse generali. Esercizio suggerito: ricostruire con i partecipanti un processo reale in tre o quattro passaggi, stimare i tempi prima e dopo l'AI, compresa la verifica, e individuare il collo di bottiglia.");

  // =====================================================================
  section("12.4 Qualità");
  divider("12.4", "AI, qualità e miglioramento delle prestazioni", "L'AI può migliorare alcune dimensioni della qualità ma introdurre nuovi errori: servono criteri osservabili", "Il secondo meccanismo di creazione di valore è la qualità. Spesso l'AI non fa risparmiare tempo, ma permette di fare meglio: risultati più completi, più coerenti, più rapidi da ottenere. In questo sottotema, da comprendere, vediamo dove l'AI può migliorare la qualità, ma anche come può introdurre nuovi errori, in particolare errori sistematici, la differenza tra qualità apparente ed effettiva, e la necessità di criteri osservabili per valutare il miglioramento. Il confine con il 12.3: lì tempi e capacità, qui qualità e affidabilità.");
  {
    const s = content("Dove migliora la qualità", "Il sottotema elenca diversi modi in cui l'AI può migliorare la qualità del lavoro. Completezza dei contenuti: l'AI può suggerire elementi dimenticati, controllare che un documento contenga tutte le sezioni richieste, ricordare casi da considerare. Standardizzazione di alcune attività: risposte, documenti e procedure più uniformi, basati sugli stessi modelli e sulle stesse informazioni. Riduzione delle operazioni manuali: meno trascrizioni e copiature, e quindi meno errori di battitura o di trasferimento. Supporto alla revisione e al controllo: rilettura, individuazione di incoerenze, confronto con requisiti e checklist, come visto nel Tema 7. Maggiore disponibilità delle informazioni: accesso più rapido a procedure, documentazione, storico, come visto nel Tema 8. Coerenza e uniformità dei risultati tra persone diverse. Miglioramento dei tempi di risposta, che per il cliente è spesso una componente della qualità del servizio. In molti casi questi benefici sono più importanti del risparmio di tempo, e meno visibili: una riduzione degli errori evita costi che nessuno vede, come reclami, rilavorazioni, rischi.");
    valTag(s, 1);
    await iconGrid(s, [
      { icon: "FiCheckSquare", head: "Completezza", body: "Elementi dimenticati, sezioni, casi" },
      { icon: "FiLayers", head: "Standardizzazione", body: "Stessi modelli e informazioni" },
      { icon: "FiEdit", head: "Meno operazioni manuali", body: "Meno errori di trascrizione" },
      { icon: "FiSearch", head: "Revisione e controllo", body: "Incoerenze, requisiti, checklist" },
      { icon: "FiBookOpen", head: "Informazioni disponibili", body: "Procedure, documentazione, storico" },
      { icon: "FiClock", head: "Tempi di risposta", body: "Una componente della qualità del servizio" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Benefici spesso più importanti del tempo, e meno visibili: gli errori evitati non si vedono.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Qualità apparente ed effettiva", "La distinzione centrale del sottotema, che abbiamo incontrato in molti temi precedenti: qualità apparente e qualità effettiva. I risultati prodotti con l'AI hanno quasi sempre un'alta qualità apparente: testi fluidi, documenti ben strutturati, report curati, presentazioni gradevoli. La qualità effettiva riguarda la sostanza: correttezza, completezza rispetto a ciò che serve, adeguatezza al destinatario e allo scopo. Il rischio, quando si valuta l'impatto dell'AI sulla qualità, è di misurare la prima e credere di aver misurato la seconda. Un esempio fittizio: dopo l'introduzione dell'AI nella preparazione delle offerte, i commerciali giudicano le offerte 'più professionali'. È un miglioramento reale della qualità apparente, e può avere effetti positivi sui clienti. Ma se nello stesso periodo aumentano le offerte con condizioni errate, la qualità effettiva è peggiorata. Il punto non è che la qualità apparente non conti: conta, per la comunicazione e la percezione. Il punto è che non va confusa con l'altra, e che entrambe vanno osservate con criteri diversi. Nel Tema 7 abbiamo visto come valutare la qualità effettiva di un singolo output; qui parliamo di valutare l'effetto dell'AI sulla qualità del lavoro nel suo insieme.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiStar", head: "Qualità apparente", headSize: 16, bodySize: 12,
      body: bullets(["Fluidità, struttura, cura formale", "Con l'AI quasi sempre alta", "Conta per comunicazione e percezione"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCheckCircle", head: "Qualità effettiva", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Correttezza, completezza, adeguatezza", "Da verificare caso per caso", "Ciò che determina il valore"], { space: 5 }) });
    docBox(s, 0.5, 3.7, 9.0, 1.2, "Esempio fittizio", "Le offerte preparate con l'AI sono giudicate 'più professionali' (qualità apparente in aumento), ma nello stesso periodo aumentano le offerte con condizioni errate (qualità effettiva in calo).", { fontSize: 12 });
  }
  {
    const s = content("Il rischio di errori sistematici", "Un rischio specifico che il sottotema mette in evidenza: l'AI può introdurre errori sistematici. Gli errori umani sono di solito sparsi: una persona sbaglia un calcolo, un'altra dimentica un passaggio, in momenti diversi e in modi diversi. Gli errori di un sistema AI usato da molte persone per la stessa attività tendono invece a ripetersi: se lo strumento interpreta male una clausola, la interpreta male in tutti i contratti; se la documentazione su cui si basa contiene un'informazione superata, tutte le risposte la riportano; se ha una tendenza a omettere un certo tipo di eccezione, la omette sempre. Questo ha due conseguenze. Gli errori possono diffondersi su larga scala prima che qualcuno se ne accorga, proprio perché il sistema è usato tanto e in modo uniforme. E la standardizzazione, che è un beneficio di qualità, può trasformarsi in un rischio: se tutti fanno la stessa cosa nello stesso modo, un errore nel modo diventa un errore ovunque. Le contromisure sono quelle viste nei temi precedenti, applicate a livello organizzativo: controlli a campione regolari, monitoraggio degli errori nel tempo, aggiornamento delle informazioni di base, attenzione ai segnali deboli, come un aumento anche lieve di reclami su un certo tema.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiUsers", head: "Errori umani", headSize: 16, bodySize: 12,
      body: bullets(["Sparsi, in momenti e modi diversi", "Un calcolo sbagliato, un passaggio dimenticato"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiCopy", head: "Errori sistematici", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Si ripetono: stessa clausola, stessa informazione superata", "Diffusi su larga scala prima che qualcuno se ne accorga"], { space: 5 }) });
    shapeBox(s, 0.5, 3.6, 9.0, 0.6, C.accent6, "standardizzazione");
    txt(s, "Se tutti fanno la stessa cosa nello stesso modo, un errore nel modo diventa un errore ovunque.", { x: 0.7, y: 3.6, w: 8.6, h: 0.6, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    const c = ["Controlli a campione regolari", "Monitoraggio nel tempo", "Informazioni aggiornate", "Segnali deboli"];
    c.forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.35, 2.15, 0.55, t, { fill: C.background2, fontSize: 12 }));
  }
  {
    const s = content("Criteri osservabili", "La consapevolezza del sottotema si chiude con una richiesta precisa: occorrono criteri osservabili per valutare l'effetto dell'AI sulla qualità. 'Le risposte sono migliori' non è un criterio; 'il numero di risposte che richiedono una seconda interazione con il cliente è sceso dal 18 al 12 per cento' lo è. La tabella in slide propone, per alcune dimensioni della qualità, indicatori osservabili tipici. Accuratezza: tasso di errori trovati in revisione o segnalati dopo la consegna. Completezza: percentuale di documenti che superano una lista di controllo dei requisiti. Rilavorazioni: quante volte un risultato deve essere rifatto o corretto. Soddisfazione: valutazioni dei clienti o dei destinatari interni, reclami. Coerenza: differenze tra risultati prodotti da persone diverse sullo stesso tipo di caso. Tempi di risposta: tempo tra richiesta e risposta. Due avvertenze. Gli indicatori vanno misurati prima e dopo l'introduzione dell'AI, altrimenti non si sa se qualcosa è cambiato; e conviene misurarne più d'uno, per non migliorare una dimensione a spese di un'altra. Il 12.8 svilupperà questi aspetti. La relazione tra qualità, velocità e affidabilità, che il sottotema richiama, si vede proprio misurando più indicatori insieme.");
    valTag(s, 1);
    table(s, [["Dimensione", "Indicatore osservabile"],
      ["Accuratezza", "Errori trovati in revisione o segnalati dopo la consegna"],
      ["Completezza", "Documenti che superano la lista dei requisiti"],
      ["Rilavorazioni", "Risultati rifatti o corretti"],
      ["Soddisfazione", "Valutazioni dei destinatari, reclami"],
      ["Coerenza", "Differenze tra persone sullo stesso tipo di caso"],
      ["Tempi di risposta", "Tempo tra richiesta e risposta"]],
      { y: 1.15, colW: [2.6, 6.4], rowH: 0.4, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 4.05, "'Le risposte sono migliori' non è un criterio. Misurare prima e dopo, e più di un indicatore insieme.", { h: 0.75, fontSize: 13 });
  }
  keySlide("L'AI può migliorare alcune dimensioni della qualità ma introdurre nuovi errori: occorrono criteri osservabili per valutarne l'effetto.", "Sottotema 12.4  ·  AI, qualità e miglioramento delle prestazioni", "Concetto chiave del sottotema 12.4. L'AI può rendere il lavoro più completo, standardizzato, coerente, con meno operazioni manuali, più supporto alla revisione e informazioni più disponibili. Ma la qualità apparente non è quella effettiva, gli errori di un sistema usato da molti tendono a essere sistematici e a diffondersi, e la standardizzazione può trasformarsi in un rischio. Servono criteri osservabili, misurati prima e dopo, su più dimensioni. Esercizio suggerito: per un'attività in cui si usa l'AI, definire due o tre indicatori osservabili di qualità e discutere come misurarli prima e dopo.");

  // =====================================================================
  section("12.5 Competenze");
  divider("12.5", "AI come amplificatore delle competenze", "Alcuni benefici non sono risparmi di tempo, ma l'accesso ad attività prima troppo difficili o costose", "Terzo meccanismo: l'amplificazione delle competenze e delle capacità. Qui il valore non sta nel fare più in fretta ciò che già si faceva, ma nel poter fare ciò che prima non si riusciva a fare: un compito al di sopra delle proprie competenze, un'analisi che richiedeva uno specialista, un servizio che non era sostenibile con le risorse disponibili. In questo sottotema, da comprendere, vediamo come l'AI può amplificare le capacità delle persone, l'integrazione B, cioè il valore di fare cose prima impossibili, e i rischi: dipendenza, riduzione delle competenze, e la differenza tra amplificare e sostituire.");
  {
    const s = content("Persone con esperienze diverse", "Il primo punto del sottotema: il supporto a persone con differenti livelli di esperienza. Gli studi citati nel 12.3 hanno osservato un fenomeno ricorrente: in molti compiti, l'AI aiuta soprattutto le persone meno esperte. Nello studio sull'assistenza clienti, i benefici erano molto maggiori per gli operatori nuovi, che con l'AI raggiungevano più rapidamente le prestazioni dei colleghi esperti; per i più esperti, i benefici erano quasi nulli. Una spiegazione plausibile è che l'AI renda accessibili a tutti le conoscenze e le pratiche che prima erano patrimonio dei più esperti. È un effetto con implicazioni importanti: riduzione dei tempi di inserimento dei nuovi colleghi, maggiore uniformità delle prestazioni, possibilità per persone junior di affrontare compiti più complessi. Ma ha anche un rovescio, che vedremo tra poco: se le persone meno esperte svolgono compiti al di sopra delle loro competenze grazie all'AI, sono anche quelle meno in grado di accorgersi quando l'AI sbaglia. E se i più esperti non ricevono benefici, il loro ruolo può cambiare, per esempio verso la supervisione e la gestione dei casi difficili. Il sottotema elenca anche l'accesso facilitato a conoscenze e strumenti, la riduzione delle barriere tecniche, come visto nel Tema 9 per l'analisi dei dati, e il supporto all'apprendimento operativo.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiUserPlus", head: "Meno esperti", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Benefici maggiori", "Raggiungono prima le prestazioni degli esperti", "Compiti più complessi accessibili"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiAward", head: "Più esperti", headSize: 16, bodySize: 12,
      body: bullets(["Benefici spesso minori", "Il ruolo si sposta verso supervisione e casi difficili"], { space: 5 }) });
    shapeBox(s, 0.5, 3.8, 9.0, 1.1, C.text1, "rovescio");
    txt(s, [{ text: "Il rovescio: ", options: { bold: true, color: C.accent6 } }, { text: "chi svolge compiti oltre le proprie competenze grazie all'AI è anche chi meno si accorge quando l'AI sbaglia.", options: { color: C.background1 } }], { x: 0.75, y: 3.8, w: 8.5, h: 1.1, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Fare cose prima impossibili", "L'integrazione B del tema: il valore dell'AI può derivare dal fare cose prima impossibili. Alcuni benefici non sono risparmi di tempo, ma l'accesso ad attività prima troppo difficili, costose o poco praticabili. Alcuni esempi. Analizzare tutti i commenti dei clienti dell'ultimo anno, migliaia di testi, per capire i motivi di insoddisfazione: prima si leggeva un campione, o nulla. Offrire documentazione e assistenza in dieci lingue invece che in due. Preparare per ogni cliente una proposta personalizzata, invece che una standard. Permettere a un piccolo ufficio senza analisti di fare analisi dei dati. Confrontare in modo sistematico tutte le offerte dei fornitori, invece che le tre principali. Creare materiali formativi per ogni procedura, invece che per le principali. In questi casi, misurare il beneficio come tempo risparmiato non ha senso: prima l'attività non si faceva, quindi non c'era tempo da risparmiare. Il valore va cercato nei risultati che l'attività nuova rende possibili: clienti trattenuti, mercati raggiunti, decisioni migliori, rischi evitati. È un tipo di valore spesso più importante dell'efficienza, ma anche più difficile da dimostrare, perché richiede di stimare che cosa si guadagna da qualcosa che prima non c'era.");
    valTag(s, 1);
    const e = [["Prima", "Ora possibile"], ["Leggere un campione di commenti", "Analizzarli tutti, migliaia"], ["Assistenza in due lingue", "In dieci lingue"], ["Una proposta standard", "Una proposta per cliente"], ["Nessun analista", "Analisi dei dati in un piccolo ufficio"], ["Tre offerte confrontate", "Tutte le offerte"]];
    table(s, e, { y: 1.15, colW: [4.5, 4.5], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 3.85, "Prima l'attività non si faceva: misurare il tempo risparmiato non ha senso. Il valore sta nei risultati che rende possibili.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Competenze umane e capacità AI", "Il sottotema parla di collaborazione tra competenze umane e capacità AI, e di importanza della conoscenza del contesto. Riprendiamo un principio emerso in molti temi: l'AI amplifica le competenze di chi la usa, ma non le sostituisce. Il risultato di una collaborazione dipende da entrambi i contributi. L'AI porta velocità, ampiezza di conoscenze generali, capacità di elaborare grandi quantità di informazioni, disponibilità continua. La persona porta la conoscenza del contesto: i clienti, l'azienda, la storia, le regole non scritte, le priorità. Porta il giudizio: che cosa è importante, che cosa è plausibile, che cosa è accettabile. Porta la responsabilità. E porta la capacità di riconoscere quando l'AI sbaglia, che dipende proprio dalle competenze. Questo spiega perché lo stesso strumento produce risultati molto diversi nelle mani di persone diverse, e perché le competenze di dominio restano decisive anche quando l'AI riduce le barriere tecniche. Un esperto con l'AI fa spesso meglio di un esperto senza; un inesperto con l'AI fa spesso meglio di un inesperto senza, ma non sempre meglio di un esperto, e soprattutto può non sapere quando l'AI lo sta portando fuori strada.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiCpu", head: "Che cosa porta l'AI", headSize: 16, bodySize: 12,
      body: bullets(["Velocità", "Ampiezza di conoscenze generali", "Grandi quantità di informazioni", "Disponibilità continua"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiUser", head: "Che cosa porta la persona", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Conoscenza del contesto", "Giudizio su importanza e plausibilità", "Responsabilità", "Capacità di riconoscere gli errori"], { space: 4 }) });
    banner(s, 3.9, "Lo stesso strumento produce risultati diversi in mani diverse: le competenze di dominio restano decisive.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Dipendenza e competenze", "Il rischio di dipendenza e di riduzione delle competenze, che il sottotema richiama e che il Tema 5 ha trattato come delega cognitiva. Qui lo guardiamo dal punto di vista del valore per l'azienda. Se le persone delegano sistematicamente all'AI attività che prima svolgevano, alcune competenze possono indebolirsi per mancanza di esercizio: scrivere, analizzare, calcolare, ragionare su un problema complesso. Per i più esperti il rischio è contenuto; per chi si forma oggi, il rischio è di non sviluppare mai quelle competenze. È un problema di valore per tre ragioni. Le competenze servono per verificare il lavoro dell'AI: senza di esse, la qualità effettiva peggiora senza che nessuno se ne accorga. Servono per gestire i casi difficili e le eccezioni, come visto nel Tema 11. E servono quando l'AI non è disponibile, o non è adatta al compito, come nello studio sui consulenti, dove proprio sui compiti al di fuori delle capacità dell'AI chi la usava sbagliava di più. Il valore apparente di breve periodo, cioè più velocità oggi, può nascondere un costo di lungo periodo, cioè meno capacità domani. Alcune contromisure: alternare lavoro con e senza AI nella formazione, chiedere spiegazioni e non solo risultati, mantenere momenti di revisione tra colleghi.");
    valTag(s, 1);
    const r = [["Verificare l'AI", "Senza competenze, la qualità peggiora senza che nessuno se ne accorga"], ["Gestire i casi difficili", "Le eccezioni richiedono chi sa come si fa"], ["Quando l'AI non basta", "Fuori dalle sue capacità, chi la usa sbaglia di più"]];
    r.forEach((e, i) => {
      const y = 1.15 + i * 0.75;
      shapeBox(s, 0.5, y, 9.0, 0.65, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.8, h: 0.65, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.5, y, w: 5.8, h: 0.65, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 3.5, "Più velocità oggi può nascondere meno capacità domani.", { h: 0.65, fontSize: 15 });
    const c = ["Alternare con e senza AI nella formazione", "Chiedere spiegazioni, non solo risultati", "Revisione tra colleghi"];
    c.forEach((t, i) => chip(s, 0.5 + i * 3.07, 4.35, 2.86, 0.6, t, { fill: C.background2, fontSize: 12 }));
  }
  {
    const s = content("Amplificare o sostituire", "L'ultimo punto del sottotema: la differenza tra amplificazione delle capacità e sostituzione delle competenze. Amplificare significa che la persona, con l'AI, fa di più o fa meglio ciò che sa fare, o affronta compiti un po' oltre le proprie competenze, mantenendo la capacità di capire e valutare il risultato. Sostituire significa che l'AI svolge il compito al posto della persona, che non ne comprende più il contenuto e non è in grado di valutarlo. La distinzione non dipende dallo strumento, ma da come viene usato e da come il lavoro è organizzato. Lo stesso assistente può amplificare un analista che lo usa per esplorare più ipotesi, e sostituire un collega che ne copia i risultati senza capirli. Nel primo caso il valore è solido; nel secondo è fragile, perché dipende interamente dall'affidabilità dello strumento, senza nessun controllo. Il sottotema chiede di riconoscere questa differenza, perché da essa dipende la sostenibilità del valore nel tempo. Un criterio pratico: la persona saprebbe spiegare il risultato, riconoscere un errore, e fare il lavoro anche senza l'AI, magari più lentamente? Se sì, l'AI amplifica; se no, sostituisce. La trasformazione dei ruoli e delle competenze è il tema del Tema 13.");
    valTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.3, { icon: "FiTrendingUp", head: "Amplificare", headSize: 17, bodySize: 12, fill: C.accent6,
      body: bullets(["Fare di più o meglio ciò che si sa fare", "Capire e valutare il risultato", "Valore solido"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.3, { icon: "FiCopy", head: "Sostituire", headSize: 17, bodySize: 12, iconBg: C.accent5,
      body: bullets(["L'AI fa al posto della persona", "Nessuno capisce né valuta", "Valore fragile, senza controllo"], { space: 5 }) });
    shapeBox(s, 0.5, 3.7, 9.0, 1.2, C.text1, "criterio");
    txt(s, "Criterio pratico", { x: 0.75, y: 3.78, w: 8.5, h: 0.35, fontSize: 14, bold: true, color: C.accent6 });
    txt(s, "La persona saprebbe spiegare il risultato, riconoscere un errore, e fare il lavoro anche senza l'AI? Se sì, amplifica; se no, sostituisce.", { x: 0.75, y: 4.15, w: 8.5, h: 0.7, fontSize: 13, color: C.background1 });
  }
  keySlide("Il valore dell'AI può derivare dal fare cose prima impossibili: alcuni benefici non sono risparmi di tempo, ma l'accesso ad attività prima troppo difficili, costose o poco praticabili.", "Sottotema 12.5  ·  AI come amplificatore delle competenze", "Concetto chiave del sottotema 12.5, che coincide con l'integrazione B. L'AI può amplificare le capacità delle persone, specialmente delle meno esperte, ridurre le barriere tecniche, sostenere l'apprendimento e rendere possibili attività prima impraticabili, il cui valore non si misura in tempo risparmiato. Ma le competenze umane e la conoscenza del contesto restano decisive, la dipendenza può indebolire le competenze necessarie per verificare e gestire i casi difficili, e amplificare non è sostituire. Esercizio suggerito: chiedere ai partecipanti di individuare un'attività che oggi non svolgono, per mancanza di tempo o di competenze, e che l'AI renderebbe possibile, e di descrivere quale risultato produrrebbe.");

  // =====================================================================
  section("12.6 Innovazione");
  divider("12.6", "AI, innovazione e nuove opportunità", "La possibilità tecnica di un nuovo servizio non dimostra che il mercato lo desideri o che sia sostenibile", "Quarto meccanismo: l'innovazione. Finora abbiamo parlato di fare meglio ciò che già si fa, o di fare ciò che prima era troppo costoso. Qui guardiamo a nuovi prodotti, nuovi servizi, nuovi modi di relazionarsi con i clienti. Il documento assegna a questo sottotema una priorità media e un livello di esplorazione: vogliamo che i partecipanti riconoscano le opportunità di innovazione, distinguano ottimizzazione e innovazione, e sappiano che la fattibilità tecnica di un'idea non ne dimostra il valore per i clienti. La valutazione e la selezione delle opportunità appartengono al Tema 15.");
  {
    const s = content("Ottimizzare o innovare", "La distinzione centrale del sottotema, e una delle domande guida: la differenza tra ottimizzazione dell'esistente e innovazione di prodotti e servizi. L'ottimizzazione migliora ciò che l'azienda già fa: lo stesso servizio, più rapido, più economico, di qualità più alta. È ciò di cui abbiamo parlato nei sottotemi 12.3 e 12.4. Il suo valore è di solito più prevedibile e più facile da misurare, ma limitato: si può ridurre un costo fino a un certo punto. L'innovazione cambia ciò che l'azienda offre o il modo in cui lo offre: un servizio nuovo, un prodotto diverso, un nuovo canale, un nuovo modello di relazione con i clienti. Il suo valore potenziale è più alto, ma è più incerto, richiede sperimentazione, e dipende dalla risposta del mercato. Le due strade non sono alternative: molte aziende iniziano dall'ottimizzazione, che produce benefici più rapidi e costruisce competenze, e poi passano all'innovazione. Ma confonderle porta a errori di valutazione: giudicare un'iniziativa di innovazione con i criteri dell'ottimizzazione, chiedendo risparmi immediati, la fa sembrare un fallimento; presentare un'ottimizzazione come innovazione ne gonfia le aspettative.");
    valTag(s, 1);
    table(s, [["", "Ottimizzazione", "Innovazione"],
      ["Che cosa cambia", "Come si fa ciò che già si fa", "Che cosa si offre, o come"],
      ["Esempio", "Risposte ai clienti più rapide", "Un nuovo servizio di consulenza digitale"],
      ["Valore", "Più prevedibile, limitato", "Potenzialmente alto, incerto"],
      ["Come si valuta", "Tempi, costi, qualità", "Sperimentazione, risposta del mercato"]],
      { y: 1.15, colW: [2.4, 3.3, 3.3], rowH: 0.5, fontSize: 12, accentCol: 2 });
    banner(s, 3.85, "Giudicare l'innovazione con i criteri dell'ottimizzazione la fa sembrare un fallimento; il contrario gonfia le aspettative.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Le forme dell'innovazione", "Il sottotema elenca diverse forme in cui l'AI può sostenere l'innovazione. Miglioramento di prodotti e servizi esistenti: aggiungere funzioni basate sull'AI a un prodotto, come un assistente nel software venduto ai clienti. Personalizzazione dell'offerta: proposte, contenuti, servizi adattati al singolo cliente, prima sostenibili solo per i clienti più grandi. Nuove modalità di relazione con i clienti: assistenza disponibile a ogni ora, in più lingue, attraverso canali nuovi. Accelerazione della sperimentazione: prototipi, varianti, test di nuove idee in tempi molto più brevi. Supporto alla generazione di nuove idee: esplorazione di alternative, analisi di tendenze, stimolo alla creatività, come visto nel Tema 5. Nuovi servizi, prima impossibili o non sostenibili. Evoluzione delle modalità di erogazione del valore: per esempio, da un prodotto venduto una volta a un servizio continuativo. Il sottotema richiama anche le opportunità prima economicamente poco praticabili, collegate all'integrazione B: molte innovazioni rese possibili dall'AI non sono tecnicamente nuove, ma diventano sostenibili perché il loro costo si è ridotto drasticamente.");
    valTag(s, 1);
    await iconGrid(s, [
      { icon: "FiPackage", head: "Prodotti migliorati", body: "Funzioni AI in ciò che si vende" },
      { icon: "FiUser", head: "Personalizzazione", body: "Per ogni cliente, non solo i grandi" },
      { icon: "FiMessageCircle", head: "Nuove relazioni", body: "A ogni ora, in più lingue, nuovi canali" },
      { icon: "FiZap", head: "Sperimentazione rapida", body: "Prototipi e test in tempi brevi" },
      { icon: "FiStar", head: "Nuove idee", body: "Alternative, tendenze, creatività" },
      { icon: "FiRefreshCw", head: "Nuovi modelli", body: "Da prodotto a servizio continuativo" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Molte innovazioni non sono tecnicamente nuove: diventano sostenibili perché il loro costo crolla.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Fattibile non vuol dire desiderato", "L'integrazione B nella sua seconda forma: la possibilità tecnica di realizzare un nuovo servizio non dimostra da sola che il mercato lo desideri o che sia economicamente sostenibile. Il sottotema la esprime come differenza tra fattibilità tecnologica e valore per il cliente. È un errore classico dell'innovazione, molto precedente all'AI, ma che l'AI rende più frequente, perché abbassa drasticamente il costo di costruire qualcosa. Si può realizzare in pochi giorni un prototipo di assistente per i clienti, un servizio di analisi personalizzata, un generatore di proposte: la facilità di costruzione crea la tentazione di saltare la domanda più importante, cioè se qualcuno lo vuole. Tre domande, prima di investire. Il cliente ha davvero il problema che il servizio risolve, e quanto gli costa oggi? Preferirebbe questa soluzione a quelle che usa già, comprese quelle senza AI? Sarebbe disposto a pagarla, o ad acquistare di più per averla? E una domanda di sostenibilità: i costi di erogazione, compresi quelli di verifica, supervisione e assistenza visti nel Tema 11, sono compatibili con il prezzo? In alcuni casi i clienti preferiscono esplicitamente un contatto umano, e un servizio basato sull'AI, tecnicamente brillante, peggiora l'esperienza.");
    valTag(s, 1);
    const q = [["Il problema", "Il cliente ce l'ha davvero? Quanto gli costa oggi?"], ["La preferenza", "La preferirebbe alle soluzioni che usa già, anche senza AI?"], ["Il valore", "Pagherebbe, o acquisterebbe di più per averla?"], ["La sostenibilità", "I costi, compresi verifica e supervisione, reggono il prezzo?"]];
    rowsLabel(s, q, { y: 1.15, h: 0.6, lw: 2.3 });
    banner(s, 3.85, "L'AI abbassa il costo di costruire qualcosa, e crea la tentazione di saltare la domanda più importante: qualcuno lo vuole?", { h: 0.8, fontSize: 13 });
    txt(s, "Alcuni clienti preferiscono esplicitamente un contatto umano.", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Verificare la domanda reale", "L'ultimo punto del sottotema: la necessità di verificare l'esistenza di una domanda reale. Come si fa, senza entrare nelle metodologie di valutazione del Tema 15? Alcuni principi pratici, comuni a ogni innovazione, che l'AI rende anzi più facili da applicare. Parlare con i clienti prima di costruire: capire il problema dal loro punto di vista, non dal nostro. Sperimentare in piccolo: un prototipo semplice offerto a pochi clienti, un'offerta di prova, un test su un segmento, prima di un investimento completo. L'AI riduce molto il costo di questi esperimenti, ed è uno dei suoi contributi più preziosi all'innovazione. Osservare i comportamenti, non solo le opinioni: i clienti dicono spesso che un servizio è interessante, ma il segnale vero è se lo usano, se ci tornano, se sono disposti a pagare. Definire in anticipo che cosa conterà come successo, e che cosa porterà ad abbandonare l'idea: senza questo criterio, è facile continuare a investire in un'idea perché è tecnicamente riuscita. Il concetto chiave del sottotema riassume: la possibilità tecnica di realizzare un nuovo servizio non dimostra da sola che il mercato lo desideri o che sia economicamente sostenibile.");
    valTag(s, 1);
    numList(s, ["Parlare con i clienti prima di costruire: il problema dal loro punto di vista", "Sperimentare in piccolo: pochi clienti, un segmento, un'offerta di prova", "Osservare i comportamenti, non solo le opinioni: lo usano, ci tornano, pagano?", "Definire prima che cosa conta come successo, e quando abbandonare"], { y: 1.15, h: 0.58, fontSize: 13 });
    banner(s, 3.75, "L'AI riduce molto il costo degli esperimenti: uno dei suoi contributi più preziosi all'innovazione.", { h: 0.75, fontSize: 13 });
    txt(s, "Principi comuni a ogni innovazione; i metodi di valutazione sono un passo successivo.", { x: 0.5, y: 4.6, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("La possibilità tecnica di realizzare un nuovo servizio non dimostra da sola che il mercato lo desideri o che sia economicamente sostenibile.", "Sottotema 12.6  ·  AI, innovazione e nuove opportunità", "Concetto chiave del sottotema 12.6. L'AI può sostenere l'innovazione in molte forme: prodotti migliorati, personalizzazione, nuove relazioni con i clienti, sperimentazione rapida, nuove idee, nuovi servizi e modelli. Ottimizzazione e innovazione vanno distinte e valutate con criteri diversi. Ma la fattibilità tecnica non è valore per il cliente, e la facilità di costruire aumenta il rischio di saltare la verifica della domanda, che si fa parlando con i clienti, sperimentando in piccolo, osservando i comportamenti. Esercizio suggerito: in piccoli gruppi, proporre un'idea di nuovo servizio basato sull'AI per i clienti dell'azienda e rispondere alle quattro domande su problema, preferenza, valore e sostenibilità.");

  // =====================================================================
  section("12.7 Costi e condizioni");
  divider("12.7", "Costi, compromessi e condizioni", "Il prezzo dello strumento è solo una componente: formazione, controlli, errori, manutenzione, adattamenti", "Abbiamo visto i meccanismi con cui l'AI crea valore. Ora guardiamo all'altro lato del bilancio: i costi, i compromessi e le condizioni necessarie. In questo sottotema, da comprendere e applicare, vediamo i costi diretti, indiretti e nascosti dell'AI, l'integrazione C sul costo nascosto della verifica, della correzione e dell'integrazione, le condizioni organizzative e informative, la differenza tra beneficio lordo e netto, e l'integrazione D applicata ai costi: la valutazione deve considerare il risultato complessivo del processo. Senza entrare in modelli finanziari, che appartengono al Tema 15.");
  {
    const s = content("Diretti, indiretti, nascosti", "Il sottotema chiede di distinguere tre tipi di costi. I costi diretti sono quelli visibili e preventivati: le licenze degli strumenti, i servizi a consumo, l'infrastruttura, eventuali consulenze per l'introduzione. Sono quelli che compaiono nel budget, e spesso gli unici considerati. I costi indiretti sono reali ma non sempre attribuiti all'AI: il tempo di apprendimento e adozione delle persone, la formazione, il tempo dei referenti interni che supportano i colleghi, l'integrazione con i sistemi esistenti, la manutenzione e l'aggiornamento delle configurazioni, l'adattamento dei processi. I costi nascosti sono quelli che nessuno prevede e spesso nessuno misura: il tempo di verifica e correzione degli output, le rilavorazioni dovute agli errori, le conseguenze degli errori non intercettati, come reclami o danni alla reputazione, il tempo perso con strumenti non adatti al compito, la qualità peggiorata senza che nessuno se ne accorga, il lavoro trasferito ad altri. La distinzione è importante perché, quando si valuta un'iniziativa, si tende a confrontare i benefici lordi con i soli costi diretti: un confronto che sopravvaluta quasi sempre il valore.");
    valTag(s, 2);
    const c = [["Diretti", "Visibili, nel budget", ["Licenze, servizi a consumo", "Infrastruttura", "Consulenze iniziali"], C.background2], ["Indiretti", "Reali, non sempre attribuiti", ["Apprendimento e formazione", "Integrazione e manutenzione", "Adattamento dei processi"], C.accent6], ["Nascosti", "Né previsti né misurati", ["Verifica e correzione", "Errori non intercettati", "Lavoro trasferito ad altri"], C.text1]];
    c.forEach((e, i) => {
      const x = 0.5 + i * 3.07, dark = i === 2;
      shapeBox(s, x, 1.15, 2.86, 2.85, e[3], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.42, fontSize: 18, bold: true, color: dark ? C.accent6 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.65, w: 2.56, h: 0.35, fontSize: 11, italic: true, color: dark ? C.accent3 : C.text2 });
      txt(s, bullets(e[2], { space: 6 }), { x: x + 0.15, y: 2.1, w: 2.6, h: 1.8, fontSize: 12, color: dark ? C.background1 : C.text1 });
    });
    banner(s, 4.2, "Confrontare benefici lordi con i soli costi diretti sopravvaluta quasi sempre il valore.", { h: 0.7, fontSize: 14 });
  }
  {
    const s = content("Il costo nascosto", "L'integrazione C del tema: il costo nascosto dell'AI, cioè verifica, correzione e integrazione. Il prezzo dello strumento è soltanto una componente dei costi; occorre considerare formazione, controlli, errori, manutenzione e adattamenti operativi. Tre voci meritano un'attenzione particolare. La verifica e la supervisione: come visto nei Temi 7 e 11, gli output e le azioni dell'AI richiedono controlli proporzionati al rischio. Questi controlli hanno un costo in tempo, spesso di persone esperte, che può essere molto rilevante, e che cresce con l'importanza delle attività. La correzione degli errori: gli errori intercettati vanno corretti; quelli non intercettati producono costi più avanti, a volte molto superiori. L'integrazione: perché uno strumento produca valore, deve essere inserito nei processi e collegato ai sistemi e alle informazioni aziendali. Questo richiede lavoro tecnico, ma anche organizzativo: definire chi usa che cosa, come, con quali regole. Il documento chiede di non fermarsi al beneficio lordo apparente. In pratica: per ogni beneficio atteso, chiedersi quali attività di verifica, correzione e integrazione sono necessarie per ottenerlo, e quanto costano. Spesso è proprio questa domanda a distinguere le iniziative che creano valore da quelle che lo promettono.");
    valTag(s, 2);
    await iconGrid(s, [
      { icon: "FiSearch", head: "Verifica e supervisione", body: "Tempo, spesso di persone esperte, che cresce con il rischio" },
      { icon: "FiTool", head: "Correzione degli errori", body: "Intercettati: tempo. Non intercettati: costi più avanti, anche molto maggiori" },
      { icon: "FiLink", head: "Integrazione", body: "Processi, sistemi, informazioni, regole d'uso" },
    ], 3, { y: 1.15, h: 2.0, headSize: 14, bodySize: 12 });
    shapeBox(s, 0.5, 3.35, 9.0, 0.85, C.accent6, "domanda");
    txt(s, [{ text: "Per ogni beneficio atteso: ", options: { bold: true, color: C.accent1 } }, { text: "quali verifiche, correzioni e integrazioni servono per ottenerlo, e quanto costano?", options: { color: C.text1 } }], { x: 0.7, y: 3.35, w: 8.6, h: 0.85, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("La curva dell'adozione", "Un costo indiretto spesso sottovalutato riguarda i tempi di apprendimento e adozione. Quando si introduce un nuovo strumento, la produttività non sale subito: spesso, per un periodo iniziale, scende. Le persone devono imparare a usarlo, capire in quali attività serve e in quali no, sviluppare abitudini di verifica, adattare il modo di lavorare; nel frattempo commettono errori, sperimentano, a volte tornano al metodo precedente. Solo dopo questa fase i benefici iniziano a vedersi, e a volte crescono nel tempo, man mano che le persone diventano più capaci e i processi si adattano. Il grafico in slide, puramente illustrativo e senza dati reali, mostra questa dinamica, che nella letteratura economica sulle tecnologie è nota come curva a J. Le implicazioni sono pratiche. Valutare un'iniziativa troppo presto può far concludere che non funziona, quando è solo nella fase di apprendimento. Al contrario, attendere senza misurare può far continuare un'iniziativa che non produrrà mai benefici. E il costo della fase iniziale, in tempo e in produttività persa, è un investimento che va considerato. La formazione e l'accompagnamento possono ridurlo e accorciarlo; la gestione del cambiamento organizzativo è il tema del Tema 16.");
    valTag(s, 2);
    const lab = ["Avvio", "", "", "", "", "", "", "", "", "", "", "Nel tempo"];
    lineChart(s, lab, [{ name: "Produttività (illustrativa)", values: [100, 94, 90, 89, 92, 97, 103, 108, 112, 115, 117, 118] }, { name: "Prima dell'AI", values: [100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100], color: HEX.a3 }], { x: 0.5, y: 1.1, w: 5.6, h: 3.0, min: 80, max: 125, legend: true, title: "Curva a J dell'adozione (illustrativa, senza dati reali)" });
    const t = [["Apprendimento", "Imparare, sperimentare, sbagliare"], ["Adattamento", "Abitudini di verifica, nuovi modi di lavorare"], ["Benefici", "Crescono con competenze e processi"]];
    t.forEach((e, i) => {
      const y = 1.15 + i * 0.98;
      shapeBox(s, 6.35, y, 3.15, 0.88, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.06, w: 2.9, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.42, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.3, "Valutare troppo presto fa concludere che non funziona; non misurare fa continuare ciò che non funzionerà mai.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Le condizioni per generare valore", "Oltre ai costi, il sottotema indica alcune condizioni senza le quali il valore non si genera, qualunque sia la qualità dello strumento. La disponibilità e la qualità delle informazioni: un assistente sulla documentazione aziendale vale quanto la documentazione; un'analisi vale quanto i dati, come visto nei Temi 8 e 9. Le condizioni informative e tecnologiche sono il tema del Tema 14. La compatibilità con attività e processi: lo strumento deve inserirsi nel modo in cui il lavoro viene svolto, non richiedere passaggi aggiuntivi che ne annullano i vantaggi. Uno strumento ottimo, ma separato dagli applicativi in cui si lavora, viene usato poco. Gli effetti sulle modalità organizzative: l'introduzione dell'AI può richiedere di cambiare ruoli, responsabilità, flussi di approvazione, criteri di valutazione delle prestazioni. Se l'organizzazione non cambia, i benefici restano locali, come visto nel 12.3. La riprogettazione del lavoro è il tema del Tema 13. Le competenze delle persone, per usare bene lo strumento e per verificarne i risultati. E la sostenibilità dei benefici nel tempo: gli strumenti cambiano, i fornitori aggiornano i modelli, i costi variano, le persone cambiano ruolo. Un beneficio ottenuto oggi va mantenuto, con aggiornamenti, monitoraggio, formazione continua.");
    valTag(s, 2);
    await iconGrid(s, [
      { icon: "FiDatabase", head: "Informazioni", body: "Disponibili e di qualità" },
      { icon: "FiGitMerge", head: "Compatibilità", body: "Dentro il modo in cui si lavora, non a lato" },
      { icon: "FiUsers", head: "Organizzazione", body: "Ruoli, flussi, criteri che cambiano" },
      { icon: "FiBookOpen", head: "Competenze", body: "Per usare bene e per verificare" },
      { icon: "FiClock", head: "Sostenibilità", body: "Modelli, costi, persone cambiano: mantenere" },
      { icon: "FiAlertCircle", head: "Senza condizioni", body: "Nessun valore, qualunque sia lo strumento", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Se l'organizzazione non cambia, i benefici restano locali.", { h: 0.6, fontSize: 14 });
  }
  {
    const s = content("Beneficio lordo e beneficio netto", "La distinzione che il sottotema chiede di rendere operativa: beneficio lordo e beneficio netto. Il beneficio lordo è il miglioramento osservato o atteso, prima di sottrarre ciò che è servito per ottenerlo: le ore risparmiate, i costi evitati, i ricavi aggiuntivi. Il beneficio netto è ciò che resta dopo aver sottratto tutti i costi: diretti, indiretti e nascosti. Il grafico fittizio in slide, con numeri inventati e unità arbitrarie, mostra il passaggio. Un beneficio lordo di 100 si riduce per il costo degli strumenti, della verifica, delle correzioni, della formazione e dell'integrazione, fino a un beneficio netto di 35. È ancora un beneficio positivo, ma un terzo di quello lordo. In altri casi, il beneficio netto può essere nullo o negativo, anche con un beneficio lordo evidente. Il documento chiede di introdurre il concetto di beneficio netto senza entrare nei modelli finanziari di calcolo del ritorno sull'investimento, che appartengono al Tema 15. Il punto qui è concettuale: ogni volta che si sente parlare di un beneficio dell'AI, conviene chiedersi se è lordo o netto, e quali costi sono stati considerati.");
    valTag(s, 2);
    const cats = ["Beneficio lordo", "Strumenti", "Verifica", "Correzioni", "Formazione", "Integrazione", "Beneficio netto"];
    const vis = [100, 15, 20, 10, 10, 10, 35], base = [0, 85, 65, 55, 45, 35, 0];
    s.addChart(pres.charts.BAR, [{ name: "base", labels: cats, values: base }, { name: "valore", labels: cats, values: vis }], {
      x: 0.5, y: 1.1, w: 9.0, h: 2.85, barDir: "col", barGrouping: "stacked", chartColors: ["FFFFFF", HEX.a5], showLegend: false,
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: 110, valGridLine: { style: "none" }, barGapWidthPct: 40,
      showTitle: true, title: "Dal beneficio lordo al netto (numeri inventati, unità arbitrarie)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt",
    });
    txt(s, "100", { x: 0.95, y: 1.45, w: 0.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, align: "center" });
    txt(s, "35", { x: 8.15, y: 2.55, w: 0.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, align: "center" });
    banner(s, 4.1, "Ogni volta che si parla di un beneficio dell'AI: è lordo o netto? Quali costi sono stati considerati?", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Benefici locali, vincoli del processo", "L'integrazione D torna in questo sottotema: la valutazione deve tener conto del risultato complessivo del processo, anche quando il miglioramento della singola attività è evidente. Nel 12.3 l'abbiamo vista dal punto di vista dei tempi; qui dal punto di vista dei costi e dei vincoli. Un miglioramento locale può generare costi altrove nel processo: più volume prodotto in una fase può creare code nella fase successiva; più rapidità in una fase può ridurre la qualità che una fase successiva deve correggere; una nuova attività di verifica può essere aggiunta in una fase diversa da quella che ha ottenuto il beneficio, e a carico di un'altra funzione. Inoltre, i vincoli del processo complessivo limitano i benefici possibili: un'attività che non è il collo di bottiglia può essere accelerata indefinitamente senza effetti sul risultato. Per questo, il beneficio netto va calcolato sul processo, non sull'attività. Un esempio fittizio: un'iniziativa che dimezza i tempi di preparazione delle pratiche, ma raddoppia quelli di controllo nell'ufficio di un'altra funzione, e lascia invariato il tempo complessivo di evasione, ha un beneficio locale evidente e un beneficio netto per il processo negativo.");
    valTag(s, 2);
    const e = [["Più volume in una fase", "Code nella fase successiva"], ["Più rapidità", "Meno qualità, da correggere più avanti"], ["Nuova verifica", "A carico di un'altra funzione"], ["Fase non critica accelerata", "Nessun effetto sul risultato"]];
    rowsLabel(s, e, { y: 1.15, h: 0.52, lw: 3.2 });
    docBox(s, 0.5, 3.6, 9.0, 1.3, "Esempio fittizio", "Preparazione delle pratiche dimezzata, controllo raddoppiato nell'ufficio di un'altra funzione, tempo complessivo di evasione invariato: beneficio locale evidente, beneficio netto per il processo negativo.", { fontSize: 13, fill: C.accent6 });
  }
  keySlide("Il costo nascosto dell'AI: il prezzo dello strumento è soltanto una componente; occorre considerare formazione, controlli, errori, manutenzione e adattamenti operativi.", "Sottotema 12.7  ·  Costi, compromessi e condizioni", "Concetto chiave del sottotema 12.7, che coincide con l'integrazione C. I costi dell'AI sono diretti, indiretti e nascosti, e i più rilevanti sono spesso verifica, correzione e integrazione. L'adozione segue una curva a J, con un costo iniziale di apprendimento. Il valore richiede condizioni: informazioni, compatibilità con i processi, cambiamenti organizzativi, competenze, sostenibilità nel tempo. Il beneficio netto, calcolato sul processo e non sulla singola attività, può essere molto diverso dal beneficio lordo. Esercizio suggerito: per un'iniziativa AI fittizia, elencare in gruppo tutti i costi diretti, indiretti e nascosti che verrebbero in mente, e confrontare la lista con quella che comparirebbe in un tipico budget.");

  // =====================================================================
  section("12.8 Valore misurabile");
  divider("12.8", "Dal valore potenziale al valore misurabile", "Verificare che il tempo risparmiato diventi beneficio, includendo i costi per ottenerlo e mantenerlo", "Ultimo sottotema, da comprendere e applicare. Abbiamo visto che cos'è il valore, come si crea, che cosa costa. Resta la domanda finale: come si sa se c'è? In questo sottotema distinguiamo aspettative e risultati, benefici dichiarati e osservati, e introduciamo i concetti di base della misurazione: obiettivi, situazione iniziale, indicatori, confronto con e senza AI. Senza entrare nei sistemi avanzati di misurazione delle prestazioni e nell'analisi del ritorno sull'investimento, che appartengono al Tema 15. Le integrazioni A e C si ritrovano qui come criteri di misurazione: il tempo risparmiato deve tradursi in un beneficio valorizzato, e il beneficio va considerato al netto dei costi.");
  {
    const s = content("Ipotizzato, percepito, misurato", "Una delle domande guida chiede di distinguere valore ipotizzato, beneficio percepito e miglioramento effettivamente misurato. Sono tre livelli diversi di conoscenza del valore, e spesso vengono confusi. Il valore ipotizzato è quello atteso prima di iniziare: le stime di un fornitore, le promesse di un progetto, i risultati di altre aziende o di studi. È utile per decidere se provare, ma non dimostra nulla sul nostro caso. Il beneficio percepito è quello che le persone sentono dopo aver iniziato, come visto nel 12.1: importante per l'adozione, ma soggetto a distorsioni, nei due sensi. Il miglioramento misurato è quello osservato confrontando i risultati prima e dopo, o con e senza AI, con indicatori definiti. È l'unico che permette di dire che il valore c'è. Il sottotema parla di differenza tra aspettative e risultati, e tra benefici dichiarati e osservati. Il passaggio da un livello all'altro è il cuore del sottotema. Un'organizzazione che decide sulla base del valore ipotizzato, e valuta sulla base di quello percepito, non sa davvero se le sue iniziative AI funzionano. Il documento chiede di evitare di trasformare stime o esperienze isolate in promesse generali di produttività.");
    valTag(s, 3);
    const l = [["Ipotizzato", "Prima di iniziare", "Stime, promesse, risultati di altri", "Serve per decidere se provare", C.background2, C.text1], ["Percepito", "Dopo aver iniziato", "Ciò che le persone sentono", "Conta per l'adozione, ma distorto", C.accent6, C.text1], ["Misurato", "Confrontando", "Prima e dopo, con e senza, con indicatori", "L'unico che dice che il valore c'è", C.accent1, C.background1]];
    l.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 2.4, e[4], e[0]);
      txt(s, e[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.42, fontSize: 18, bold: true, color: i === 2 ? C.background1 : C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: 1.66, w: 2.56, h: 0.3, fontSize: 11, italic: true, color: e[5] });
      txt(s, e[2], { x: x + 0.15, y: 2.02, w: 2.56, h: 0.65, fontSize: 12, color: e[5] });
      txt(s, e[3], { x: x + 0.15, y: 2.75, w: 2.56, h: 0.7, fontSize: 12, bold: true, color: i === 2 ? C.accent6 : C.accent5 });
      if (i < 2) arrow(s, x + 2.88, 2.2, 0.17);
    });
    banner(s, 3.8, "Chi decide sul valore ipotizzato e valuta su quello percepito non sa se le sue iniziative funzionano.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Obiettivi e situazione iniziale", "Le basi della misurazione sono due, e vanno definite prima di introdurre l'AI, non dopo. La prima: obiettivi concreti. 'Migliorare l'efficienza con l'AI' non è un obiettivo misurabile. 'Ridurre da tre giorni a uno il tempo medio di risposta alle richieste di offerta, mantenendo il tasso di errori sotto il 2 per cento' lo è. Un obiettivo concreto indica che cosa deve cambiare, di quanto, entro quando, e quali vincoli vanno rispettati. La seconda: la situazione iniziale, cioè come stanno le cose prima. Quanto tempo richiede oggi l'attività? Quanti errori ci sono? Quanto costa? Quanto sono soddisfatti i clienti? Senza la situazione iniziale, non si può dire se qualcosa è migliorato: si può solo dire come stanno le cose dopo. Questo sembra ovvio, ma è uno degli errori più frequenti: si introduce lo strumento, e solo dopo, quando qualcuno chiede quali benefici ha prodotto, ci si accorge di non sapere come si lavorava prima. A quel punto restano le percezioni. Misurare la situazione iniziale richiede un po' di lavoro, ma è la condizione per sapere, più avanti, se l'investimento ha prodotto valore.");
    valTag(s, 3);
    docBox(s, 0.5, 1.15, 4.35, 1.4, "Non misurabile", "\"Migliorare l'efficienza con l'AI.\"", { fontSize: 14, bar: C.accent5, labelColor: C.accent5 });
    docBox(s, 5.15, 1.15, 4.35, 1.4, "Misurabile", "\"Da tre giorni a uno per le offerte, con errori sotto il 2%, entro sei mesi.\"", { fontSize: 13, fill: C.accent6 });
    const q = ["Che cosa cambia", "Di quanto", "Entro quando", "Con quali vincoli"];
    q.forEach((t, i) => chip(s, 0.5 + i * 2.3, 2.7, 2.15, 0.5, t, { fill: C.background2, fontSize: 12 }));
    shapeBox(s, 0.5, 3.4, 9.0, 1.5, C.text1, "situazione iniziale");
    txt(s, "La situazione iniziale, prima di introdurre l'AI", { x: 0.75, y: 3.48, w: 8.5, h: 0.38, fontSize: 15, bold: true, color: C.accent6 });
    txt(s, "Tempi, errori, costi, soddisfazione oggi. Senza, si può dire solo come stanno le cose dopo: restano le percezioni.", { x: 0.75, y: 3.9, w: 8.5, h: 0.9, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Indicatori di risultato", "Il sottotema introduce gli indicatori di risultato, e la misurazione di tempi, qualità, costi e capacità. Riprendiamo, in forma sintetica, gli indicatori principali per ciascuna dimensione. Tempi: tempo per attività, comprensivo di verifica e correzione; tempo complessivo del processo, dalla richiesta alla consegna; tempi di attesa. Qualità: errori, rilavorazioni, completezza, reclami, come visto nel 12.4. Costi: costi diretti e indiretti dell'AI, costo per unità di risultato, come il costo per pratica gestita. Capacità: volumi gestiti, arretrati, attività prima non svolte e ora possibili. A questi si aggiungono gli indicatori dei benefici indiretti, che il sottotema chiede di valutare: soddisfazione dei dipendenti, tempi di inserimento dei nuovi colleghi, soddisfazione dei clienti. Tre avvertenze pratiche. Scegliere pochi indicatori, legati all'obiettivo, invece di misurare tutto. Includere almeno un indicatore di qualità accanto a quelli di tempo, per non premiare la velocità a scapito della correttezza. Misurare a livello del processo, non solo dell'attività, per cogliere l'integrazione D. I sistemi avanzati di misurazione delle prestazioni sono solo da accennare.");
    valTag(s, 3);
    table(s, [["Dimensione", "Indicatori tipici"],
      ["Tempi", "Per attività con verifica; del processo; di attesa"],
      ["Qualità", "Errori, rilavorazioni, completezza, reclami"],
      ["Costi", "Diretti e indiretti; costo per unità di risultato"],
      ["Capacità", "Volumi, arretrati, attività nuove"],
      ["Benefici indiretti", "Soddisfazione, tempi di inserimento, clienti"]],
      { y: 1.15, colW: [2.5, 6.5], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 1 });
    const a = ["Pochi indicatori, legati all'obiettivo", "Sempre almeno uno di qualità", "Misurare sul processo, non solo sull'attività"];
    a.forEach((t, i) => chip(s, 0.5 + i * 3.07, 3.85, 2.86, 0.75, t, { fill: C.accent6, fontSize: 12 }));
  }
  {
    const s = content("Con e senza AI", "Il confronto tra attività con e senza AI è il modo più diretto per misurare un beneficio. Ma va fatto con alcune attenzioni, perché è facile ottenere confronti fuorvianti. Confrontare attività comparabili: se con l'AI si gestiscono le pratiche semplici e senza AI quelle complesse, i tempi non sono confrontabili. Considerare tutto il tempo, compresa la verifica e le rilavorazioni, e non solo quello di produzione, come visto nel 12.3. Considerare la qualità, non solo il tempo. Tenere conto degli altri cambiamenti avvenuti nello stesso periodo: se insieme all'AI è stato introdotto un nuovo processo, o sono arrivati nuovi colleghi, o è cambiata la stagione, il miglioramento non è attribuibile solo all'AI. Tenere conto della curva di apprendimento vista nel 12.7: misurare troppo presto sottostima i benefici. Quando possibile, il confronto più solido è tra due gruppi che lavorano nello stesso periodo su attività simili, uno con e uno senza AI, come negli studi citati nel 12.3. Non sempre è praticabile in azienda, ma anche un confronto semplice, fatto con queste attenzioni, è molto più informativo delle percezioni. Il sottotema richiama anche la distinzione tra beneficio individuale e organizzativo: il confronto va fatto anche sui risultati del team e del processo.");
    valTag(s, 3);
    rowsLabel(s, [["Attività comparabili", "Non pratiche semplici con AI e complesse senza"], ["Tutto il tempo", "Produzione, verifica, rilavorazioni"], ["Anche la qualità", "Non solo la velocità"], ["Altri cambiamenti", "Nuovi processi, persone, stagionalità nello stesso periodo"], ["Curva di apprendimento", "Misurare troppo presto sottostima"]], { y: 1.15, h: 0.5, lw: 2.6 });
    banner(s, 4.15, "Il confronto più solido: due gruppi simili, nello stesso periodo, con e senza AI. Anche un confronto semplice batte le percezioni.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Verso il beneficio netto", "Le integrazioni A e C si ritrovano qui come due verifiche di misurazione. Integrazione A: verificare che il tempo risparmiato si traduca in un beneficio effettivamente valorizzato. Non basta misurare le ore risparmiate: bisogna chiedersi che cosa è successo a quelle ore, come visto nel 12.3. Si sono tradotte in più volumi, in nuove attività, in maggiore qualità, in minori costi esterni? Oppure sono state assorbite o disperse? Solo nel primo caso il tempo risparmiato è diventato valore. Integrazione C: includere i costi necessari per ottenere e mantenere il risultato, senza fermarsi al beneficio lordo apparente. Nel conto vanno messi tutti i costi visti nel 12.7, compresi quelli di verifica, correzione, formazione, integrazione, e i costi di mantenimento nel tempo. Mettendo insieme le due verifiche si arriva al concetto di beneficio netto, che il sottotema chiede di introdurre: il valore effettivamente valorizzato, meno tutti i costi necessari per ottenerlo e mantenerlo. Lo schema in slide riassume il percorso, dal risparmio apparente al beneficio netto. Il calcolo analitico del ritorno sull'investimento, con modelli finanziari e business case, appartiene al Tema 15.");
    valTag(s, 3);
    const st = [["Tempo risparmiato apparente", C.background2, C.text1], ["meno verifica e correzioni", C.background2, C.text1], ["Tempo effettivamente risparmiato", C.accent6, C.text1], ["quanto è valorizzato? (A)", C.background2, C.text1], ["Beneficio valorizzato", C.accent6, C.text1], ["meno tutti i costi (C)", C.background2, C.text1], ["Beneficio netto", C.accent1, C.background1]];
    st.forEach((e, i) => {
      const y = 1.12 + i * 0.44;
      const op = i % 2 === 1;
      shapeBox(s, op ? 2.2 : 1.2, y, op ? 5.6 : 7.6, 0.38, e[1], e[0]);
      txt(s, e[0], { x: op ? 2.3 : 1.3, y, w: op ? 5.4 : 7.4, h: 0.38, fontSize: op ? 11 : 13, bold: !op, italic: op, color: e[2], align: "center", valign: "middle" });
    });
    txt(s, "Un ragionamento, non un modello finanziario: il calcolo analitico del ritorno è un passo successivo.", { x: 0.5, y: 4.3, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2, align: "center" });
  }
  {
    const s = content("Limiti delle misurazioni", "Il sottotema chiede anche di riconoscere i limiti delle misurazioni, per non cadere nell'eccesso opposto: credere che tutto ciò che conta si possa misurare, o che ciò che si misura sia tutto ciò che conta. Alcuni limiti tipici. Non tutto è misurabile con precisione: la qualità di una decisione, l'apprendimento, la reputazione si stimano, non si misurano. Le misure possono essere distorte dal modo in cui vengono raccolte: le persone tendono a migliorare ciò che sanno essere misurato, a volte a scapito di ciò che non lo è. È un fenomeno noto come legge di Goodhart: quando una misura diventa un obiettivo, cessa di essere una buona misura. Attribuire un risultato all'AI è difficile quando molti fattori cambiano insieme. I benefici di lungo periodo, come le competenze o l'innovazione, emergono dopo il periodo di misurazione. Misurare ha un costo, che deve essere proporzionato all'importanza della decisione. Nessuno di questi limiti è un motivo per non misurare: sono motivi per misurare con attenzione, combinare indicatori quantitativi con valutazioni qualitative, e dichiarare l'incertezza dei risultati. È lo stesso equilibrio visto nel Tema 9 per l'analisi dei dati: i numeri sono indispensabili, ma non parlano da soli.");
    valTag(s, 3);
    await iconGrid(s, [
      { icon: "FiHelpCircle", head: "Non tutto è misurabile", body: "Decisioni, apprendimento, reputazione: si stimano" },
      { icon: "FiTarget", head: "Legge di Goodhart", body: "Quando una misura diventa obiettivo, smette di misurare bene" },
      { icon: "FiShuffle", head: "Attribuzione", body: "Molti fattori cambiano insieme" },
      { icon: "FiClock", head: "Lungo periodo", body: "Competenze e innovazione emergono dopo" },
    ], 2, { y: 1.15, H: 2.55, headSize: 14, bodySize: 12 });
    banner(s, 3.9, "Non motivi per non misurare, ma per misurare con attenzione: indicatori e valutazioni qualitative, incertezza dichiarata.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Adozione e impatto, di nuovo", "Chiudiamo il sottotema, e il tema, tornando a una distinzione introdotta nel 12.1: adozione dello strumento e impatto aziendale. Il sottotema la ripropone come criterio di misurazione, perché è l'errore più frequente nel modo in cui le organizzazioni valutano le iniziative AI. Gli indicatori di adozione sono facili da raccogliere, e spesso sono gli unici disponibili: numero di licenze, utenti attivi, richieste al giorno, percentuale di dipendenti che hanno usato lo strumento. Sono utili per capire se lo strumento viene usato, e per individuare dove la formazione o l'accompagnamento servono di più. Ma non sono indicatori di valore. Un'alta adozione è compatibile con un impatto nullo, o persino negativo, se lo strumento è usato per attività poco rilevanti, se gli errori aumentano, se il tempo risparmiato si disperde. Il documento lo indica come prima cosa da evitare: confondere la frequenza d'uso dello strumento con l'impatto aziendale. E il dodicesimo risultato atteso del tema lo riassume: l'adozione dell'AI non costituisce, da sola, una misura del valore prodotto. La misura del valore sta negli indicatori di risultato, collegati agli obiettivi, al netto dei costi, a livello di processo e di organizzazione.");
    valTag(s, 3);
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiUsers", head: "Indicatori di adozione", headSize: 16, bodySize: 12,
      body: bullets(["Licenze, utenti attivi, richieste al giorno", "Facili da raccogliere", "Utili per formazione e accompagnamento", "Non misurano il valore"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiTrendingUp", head: "Indicatori di risultato", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Collegati agli obiettivi", "Al netto dei costi", "A livello di processo e di organizzazione", "Misurano il valore"], { space: 4 }) });
    banner(s, 3.8, "Un'alta adozione è compatibile con un impatto nullo, o negativo. L'adozione da sola non misura il valore prodotto.", { h: 0.85, fontSize: 13 });
  }
  keySlide("Verificare che il tempo risparmiato si traduca in un beneficio effettivamente valorizzato, includendo i costi necessari per ottenere e mantenere il risultato.", "Sottotema 12.8  ·  Dal valore potenziale al valore misurabile", "Concetto chiave dell'ultimo sottotema, che riunisce le integrazioni A e C. Valore ipotizzato, percepito e misurato sono diversi, e solo l'ultimo dice che il valore c'è. Misurare richiede obiettivi concreti e la situazione iniziale, definiti prima; pochi indicatori di risultato, con almeno uno di qualità, a livello di processo; confronti con e senza AI fatti con attenzione. Il beneficio netto è il beneficio valorizzato meno tutti i costi. Le misurazioni hanno limiti, da gestire e non da usare come scusa. E l'adozione non misura il valore. Esercizio suggerito: per un'iniziativa AI reale o fittizia, scrivere un obiettivo misurabile, indicare la situazione iniziale da rilevare e scegliere tre indicatori, di cui uno di qualità.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle nove domande guida. Creare valore: contribuire a un obiettivo concreto e rilevante, per l'organizzazione, i dipendenti o i clienti, al netto dei costi. Tipi di benefici: efficienza, produttività, qualità, meno errori, esperienza del cliente, decisioni, flessibilità, innovazione; tangibili e intangibili. Tempo e produttività: il tempo va verificato, valorizzato, e non deve riguardare un passaggio che non è il collo di bottiglia. Qualità: con criteri osservabili, attenzione alla qualità apparente e agli errori sistematici. Competenze e cose nuove: amplificare senza sostituire, e riconoscere il valore delle attività prima impossibili. Ottimizzare o innovare: migliorare ciò che si fa o offrire qualcosa di nuovo, con criteri di valutazione diversi. Costi: diretti, indiretti e nascosti, soprattutto verifica, correzione e integrazione. Ipotizzato, percepito, misurato: solo il terzo dice che il valore c'è. Singola attività e processo: il processo va al ritmo del collo di bottiglia, e i costi possono spostarsi altrove. Suggerimento: far rispondere i partecipanti prima di mostrare la slide.");
    const qa = [["Che cosa significa creare valore?", "Contribuire a un obiettivo rilevante, al netto dei costi"], ["Quali benefici?", "Otto dimensioni, tangibili e intangibili"], ["Meno tempo, più produttività?", "Solo se verificato, valorizzato, sul collo di bottiglia"], ["Qualità senza nuovi problemi?", "Criteri osservabili, attenzione agli errori sistematici"], ["Competenze e cose nuove?", "Amplificare, non sostituire; attività prima impossibili"], ["Ottimizzare o innovare?", "Criteri di valutazione diversi"], ["Quali costi?", "Diretti, indiretti, nascosti: verifica e integrazione"], ["Ipotizzato, percepito, misurato?", "Solo il misurato dice che il valore c'è"], ["Attività o processo?", "Il ritmo è quello del collo di bottiglia"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.74;
      shapeBox(s, x, y, 4.4, 0.66, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.66, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[0], { x: x + 0.55, y: y + 0.04, w: 3.8, h: 0.3, fontSize: 11, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.55, y: y + 0.33, w: 3.8, h: 0.3, fontSize: 10, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i dodici risultati attesi. Il partecipante dovrebbe essere in grado di: distinguere capacità tecnologica, utilizzo e valore aziendale; riconoscere le principali dimensioni del valore dell'AI; comprendere la differenza tra efficienza e produttività; distinguere miglioramenti individuali e organizzativi; riconoscere il ruolo dell'AI nel miglioramento della qualità; comprendere come l'AI possa amplificare competenze e capacità; individuare opportunità di innovazione oltre alla riduzione dei tempi; riconoscere i principali costi diretti e indiretti dell'adozione; comprendere perché migliorare un'attività non significa necessariamente migliorare il processo; distinguere benefici lordi e netti; riconoscere la differenza tra benefici attesi e risultati misurati; comprendere perché l'adozione dell'AI non costituisce, da sola, una misura del valore prodotto.");
    const r = ["Capacità, utilizzo, valore", "Le dimensioni del valore", "Efficienza e produttività", "Individuale e organizzativo", "AI e qualità", "Amplificare competenze e capacità", "Innovazione oltre i tempi", "Costi diretti e indiretti", "Attività migliore, processo uguale", "Benefici lordi e netti", "Attesi e misurati", "Adozione non è valore"];
    r.forEach((t, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.12 + row * 0.66;
      shapeBox(s, x, y, 4.4, 0.58, row % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.1, y, w: 0.45, h: 0.58, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: 3.8, h: 0.58, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Domande sul valore", "Traduciamo il modulo in una scheda pratica: le domande da porsi davanti a un'iniziativa AI, propria o di altri, per ragionare sul suo valore. Definire: quale problema risolve? Per chi crea valore, e su quali dimensioni? Meccanismi: fa risparmiare tempo, migliora la qualità, amplia le capacità, permette di innovare? Il tempo risparmiato, al netto della verifica, come sarà valorizzato? Riguarda il collo di bottiglia? Condizioni: quali sono i costi diretti, indiretti e nascosti, in particolare di verifica, correzione e integrazione? Ci sono le informazioni, la compatibilità con i processi, le competenze? Verificare: qual è l'obiettivo misurabile e la situazione iniziale? Quali indicatori, con almeno uno di qualità? Il beneficio è lordo o netto, individuale o organizzativo, percepito o misurato? Sono domande che non richiedono competenze finanziarie, ma che fanno emergere la maggior parte delle illusioni sul valore. Il Tema 15 le trasformerà in un metodo di valutazione e selezione delle opportunità.");
    const f = [["Definire", ["Quale problema?", "Per chi, su quali dimensioni?"], C.background2], ["Meccanismi", ["Tempo, qualità, capacità, innovazione?", "Tempo valorizzato?", "Collo di bottiglia?"], C.accent6], ["Condizioni", ["Costi nascosti: verifica, integrazione?", "Informazioni, processi, competenze?"], C.background2], ["Verificare", ["Obiettivo e situazione iniziale?", "Indicatori, uno di qualità?", "Lordo o netto? Misurato?"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Domande senza competenze finanziarie, che fanno emergere la maggior parte delle illusioni sul valore.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei errori tipici quando si parla di valore dell'AI. Quattro sono indicati esplicitamente dal documento di perimetro. Primo: confondere la frequenza d'uso dello strumento con l'impatto aziendale. L'adozione è una condizione, non una misura del valore. Secondo: trasformare stime o esperienze isolate in promesse generali di produttività. Un risultato ottenuto in un'altra azienda, in uno studio, o da un collega entusiasta, non si trasferisce automaticamente. Terzo: misurare soltanto il tempo risparmiato senza considerare revisione, rilavorazione e qualità. Il tempo apparente sopravvaluta il beneficio. Quarto: scambiare la qualità apparente per qualità effettiva. Testi più fluidi e ordinati possono nascondere errori, anche sistematici. Quinto: dare per scontato che, se la tecnologia rende possibile un nuovo servizio, i clienti lo vorranno. Prima va verificata la domanda reale. Sesto: presumere che fattibilità tecnologica e adozione producano automaticamente convenienza. Che si possa fare, e che venga usato, non significa che convenga, al netto dei costi. Queste avvertenze sono anche un filtro critico utile per leggere annunci, presentazioni e articoli sui benefici dell'AI. Il messaggio centrale del tema le riassume: l'AI crea valore quando contribuisce a miglioramenti rilevanti e verificabili per l'organizzazione.");
    const a = [["FiBarChart2", "\"Lo usano tutti, quindi funziona\"", "L'adozione non misura il valore", "12.1"], ["FiVolume2", "\"Altrove ha dato il +30%\"", "Un risultato altrui non si trasferisce", "12.3"], ["FiClock", "\"Risparmiamo due ore a testa\"", "E revisione, rilavorazione, qualità?", "12.3"], ["FiStar", "\"È scritto meglio, vale di più\"", "Qualità apparente non è effettiva", "12.4"], ["FiShoppingBag", "\"Si può fare, i clienti lo vorranno\"", "Prima verificare la domanda reale", "12.6"], ["FiTool", "\"Fattibile e usato, quindi conviene\"", "Conta il beneficio netto", "12.7"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 2.95, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.7, y: y + 0.1, w: 0.55, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Che cosa viene dopo", "Con il Tema 12 abbiamo aperto l'area 'Comprendere il valore per l'azienda', costruendo i concetti per ragionare sul valore dell'AI in modo realistico. Il tema successivo, il Tema 13, è dedicato all'AI e alla trasformazione del lavoro e dei processi: come l'AI modifica le attività professionali, i processi operativi, la collaborazione, le competenze e i ruoli. È il naturale proseguimento di molti punti di questo modulo: abbiamo visto che il tempo liberato va valorizzato con scelte organizzative, che i benefici restano locali se i processi non cambiano, che le competenze vanno mantenute, che il lavoro può essere trasferito invece che eliminato. Il Tema 13 affronterà proprio come riprogettare attività, processi e ruoli, riconoscendo che gli effetti sul lavoro dipendono tanto dalle capacità tecnologiche quanto dalle scelte organizzative. Seguiranno il Tema 14, sui dati e la conoscenza aziendale, e il Tema 15, sulla valutazione e selezione delle opportunità e dei casi d'uso, dove le domande di questo modulo diventeranno un metodo. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.4, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.71, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.08, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 8-11", { x: 0.75, y: 3.39, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Comprendere il valore per l'azienda", { x: 0.75, y: 3.76, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 12: creazione di valore (completato)", { x: 0.75, y: 4.07, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 13: AI e trasformazione del lavoro e dei processi", { x: 5.4, y: 1.72, w: 3.9, h: 0.65, fontSize: 15, bold: true, color: C.background1 });
    txt(s, "Attività, processi, collaborazione, competenze, ruoli", { x: 5.4, y: 2.4, w: 3.9, h: 0.5, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 3.0, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 14: dati e conoscenza aziendale", "Tema 15: opportunità e casi d'uso"], { space: 5 }), { x: 5.4, y: 3.35, w: 3.9, h: 1.2, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. I due studi sulla produttività sono citati nelle versioni pubblicate, verificate a ottobre 2026; le versioni preliminari del 2023 riportano valori leggermente diversi. La pagina dell'articolo di Solow è indicata a memoria: da verificare. I due studi sono tra i più citati sull'AI generativa al lavoro: conviene verificarne i dettagli e cercare studi più recenti prima di ogni edizione, perché la ricerca in questo campo è molto attiva. Il paradosso di Solow, la teoria dei vincoli e la legge di Goodhart sono concetti consolidati, citati qui come strumenti di ragionamento. Tutti gli esempi numerici del modulo sono inventati a scopo didattico, compreso quello del documento di perimetro.");
    const src = [
      "Brynjolfsson, E., Li, D., Raymond, L. (2025). Generative AI at Work. The Quarterly Journal of Economics, 140(2), 889-942.",
      "Dell'Acqua, F. et al. (2026). Navigating the Jagged Technological Frontier. Organization Science, 37(2), 403-423.",
      "Solow, R. (1987). We'd Better Watch Out. New York Times Book Review, 12 luglio 1987, p. 36.",
      "Goldratt, E. M., Cox, J. (1984). The Goal. North River Press (teoria dei vincoli).",
      "Gli esempi numerici delle slide sono inventati a scopo didattico.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
    txt(s, "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.", { x: 1.3, y: 4.7, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema12_AI_creazione_valore_azienda.pptx" });
  await applyTheme("Tema12_AI_creazione_valore_azienda.pptx", THEME);
  console.log("done");
})();
