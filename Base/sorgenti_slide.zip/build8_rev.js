const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 8: AI per testi, documenti e conoscenza (revisione)";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 8  ·  AI per testi, documenti e conoscenza";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}


// ---------- extra helpers ----------
function table(s, rows, o) {
  const acc = o.accentCol === undefined ? -1 : o.accentCol;
  const t = rows.map((r, i) => r.map((c, j) => {
    const head = i === 0;
    let fill, color;
    if (head) {
      if (j === 0 && o.blankCorner !== false) { fill = C.background1; color = C.text1; }
      else { fill = j === acc ? C.accent1 : C.text2; color = C.background1; }
    } else {
      fill = j === acc ? C.accent6 : (j === 0 ? C.background1 : C.background2);
      color = C.text1;
    }
    return { text: c, options: { bold: head || j === 0, color, fill: { color: fill }, fontSize: o.fontSize || 13, valign: "middle", margin: [3, 8, 3, 8] } };
  }));
  s.addTable(t, { x: o.x || 0.5, y: o.y || 1.2, w: o.w || 9.0, colW: o.colW, rowH: o.rowH || 0.5, border: { type: "solid", pt: 1, color: HEX.lt1 } });
}
function chip(s, x, y, w, h, text, o) {
  o = o || {};
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: Math.min(0.12, h / 2), fill: { color: o.fill || C.background2 }, line: o.line || { type: "none" }, objectName: "blocco " + text });
  txt(s, text, { x: x + 0.05, y, w: w - 0.1, h, fontSize: o.fontSize || 13, bold: o.bold !== false, color: o.color || C.text1, align: "center", valign: "middle" });
}
function chartBarH(s, labels, values, o) {
  s.addChart(pres.charts.BAR, [{ name: o.name || "Probabilità", labels, values }], {
    x: o.x, y: o.y, w: o.w, h: o.h, barDir: "bar", chartColors: [o.color || HEX.a1],
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 12, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "0%",
    catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", catAxisOrientation: "maxMin",
    valAxisHidden: true, valAxisMinVal: 0, valAxisMaxVal: o.max || 1, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
    showTitle: !!o.title, title: o.title || "", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 50,
  });
}


(async () => {
  // helper: grid of icon cards (icon left of head) with body
  async function iconGrid(s, items, cols, o) {
    o = o || {};
    const x0 = o.x || 0.5, y0 = o.y || 1.2, W = o.w || 9.0, gap = o.gap || 0.2;
    const rows = Math.ceil(items.length / cols);
    const cw = (W - gap * (cols - 1)) / cols;
    const ch = o.h || ((o.H || 3.75) - gap * (rows - 1)) / rows;
    for (let i = 0; i < items.length; i++) {
      const c = i % cols, r = Math.floor(i / cols);
      const x = x0 + c * (cw + gap), y = y0 + r * (ch + gap);
      const it = items[i];
      shapeBox(s, x, y, cw, ch, it.fill || C.background2, it.head);
      await iconCircle(s, x + 0.18, y + 0.18, 0.48, it.icon, it.iconBg || C.accent1);
      txt(s, it.head, { x: x + 0.78, y: y + 0.14, w: cw - 0.9, h: 0.56, fontSize: o.headSize || 13, bold: true, color: C.text1, valign: "middle" });
      if (it.body) txt(s, it.body, { x: x + 0.18, y: y + 0.78, w: cw - 0.36, h: ch - 0.88, fontSize: o.bodySize || 12, color: C.text2 });
    }
  }
  function banner(s, y, text, o) {
    o = o || {};
    shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
    txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
  }

  function rowList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.2, h = o.h || 0.5, gap = o.gap || 0.08, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + gap);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "riga " + i);
      txt(s, t, { x: x + 0.2, y, w: w - 0.4, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }
  function twoPanel(s, leftHead, leftBody, rightHead, rightBody, o) {
    o = o || {};
    return Promise.all([
      card(s, 0.5, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.li, head: leftHead, headSize: 15, bodySize: 13, body: leftBody }),
      card(s, 5.15, o.y || 1.2, 4.35, o.h || 2.5, { icon: o.ri, head: rightHead, headSize: 15, bodySize: 13, fill: C.accent6, body: rightBody }),
    ]);
  }


  function promptBox(s, x, y, w, h, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "prompt");
    if (o.label) txt(s, o.label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    const ty = o.label ? y + 0.4 : y + 0.12;
    txt(s, text, { x: x + 0.18, y: ty, w: w - 0.36, h: y + h - ty - 0.1, fontSize: o.fontSize || 11, color: C.text1, fontFace: "Courier New" });
  }
  function qGrid(s, qs, cols, rowsY, h, fs) {
    const w = (9.0 - (cols - 1) * 0.14) / cols;
    qs.forEach((q, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = 0.5 + col * (w + 0.14), y = rowsY + row * (h + 0.15);
      shapeBox(s, x, y, w, h, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y: y + 0.1, w: 0.6, h: 0.42, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, q, { x: x + 0.15, y: y + 0.55, w: w - 0.25, h: h - 0.6, fontSize: fs || 11, color: C.text1 });
    });
  }
  function pathSlide(s, items, levels) {
    items.forEach((it, i) => {
      const y = 1.12 + i * 0.47;
      shapeBox(s, 0.5, y, 5.6, 0.4, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.65, y, w: 0.55, h: 0.4, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.2, y, w: 3.9, h: 0.4, fontSize: 13, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, rectRadius: 0.13, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 5.2, y: y + 0.07, w: 0.8, h: 0.26, fontSize: 10, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
    levels.forEach((l, i) => {
      const y = 1.12 + i * 1.27;
      shapeBox(s, 6.35, y, 3.15, 1.12, l[2], "livello " + l[0]);
      txt(s, l[0], { x: 6.5, y: y + 0.08, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: l[3] });
      txt(s, l[1], { x: 6.5, y: y + 0.4, w: 2.9, h: 0.68, fontSize: 10, color: l[3] });
    });
  }

  function modeTag(s, active) {
    const st = ["Produrre", "Trasformare", "Analizzare", "Recuperare"];
    st.forEach((t, i) => {
      const x = 6.46 + i * 0.77;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 0.42, w: 0.74, h: 0.26, rectRadius: 0.13, fill: { color: i === active ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 0.75 }, objectName: "modalità " + t });
      txt(s, t, { x, y: 0.42, w: 0.74, h: 0.26, fontSize: 8, bold: true, color: i === active ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }
  function docBox(s, x, y, w, h, label, text, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.background2, "documento " + label);
    s.addShape(pres.shapes.RECTANGLE, { x, y: y + 0.12, w: 0.06, h: h - 0.24, fill: { color: o.bar || C.accent1 }, line: { type: "none" }, objectName: "barra" });
    txt(s, label, { x: x + 0.22, y: y + 0.1, w: w - 0.4, h: 0.28, fontSize: 11, bold: true, color: o.labelColor || C.accent1 });
    txt(s, text, { x: x + 0.22, y: y + 0.42, w: w - 0.4, h: h - 0.52, fontSize: o.fontSize || 12, color: C.text1 });
  }
  function numList(s, items, o) {
    o = o || {};
    const y0 = o.y || 1.15, h = o.h || 0.5, x = o.x || 0.5, w = o.w || 9.0;
    items.forEach((t, i) => {
      const y = y0 + i * (h + 0.08);
      shapeBox(s, x, y, w, h, i % 2 ? C.background1 : C.background2, "voce " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.12, y, w: 0.4, h, fontSize: 15, bold: true, color: C.accent1, valign: "middle" });
      txt(s, t, { x: x + 0.55, y, w: w - 0.7, h, fontSize: o.fontSize || 13, color: C.text1, valign: "middle" });
    });
  }


  // =====================================================================
  // REVISIONE 16 ottobre 2026: helper aggiuntivi
  function colLabel(s, x, y, w, t, color) {
    txt(s, t, { x, y, w, h: 0.28, fontSize: 11, bold: true, color: color || C.accent1 });
  }
  function resultBox(s, x, y, w, h, label, runs, o) {
    o = o || {};
    shapeBox(s, x, y, w, h, o.fill || C.accent6, "risultato " + label);
    txt(s, label, { x: x + 0.18, y: y + 0.1, w: w - 0.36, h: 0.28, fontSize: 11, bold: true, color: C.accent1 });
    txt(s, runs, { x: x + 0.18, y: y + 0.42, w: w - 0.36, h: h - 0.52, fontSize: o.fontSize || 11, color: C.text1 });
  }

  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 8", { placeholder: "kicker" });
    s.addText("AI per testi, documenti e conoscenza", { placeholder: "title" });
    s.addText("Area: Esplorare le possibilità dell'AI\nContenuti aggiornati a ottobre 2026", { placeholder: "sub" });
    s.addNotes("Benvenuti all'ottavo tema, che apre una nuova area del percorso: 'Esplorare le possibilità dell'AI'. Nelle aree precedenti abbiamo costruito le basi: che cos'è l'AI e come funziona, quali sono i suoi limiti, come dialogare con essa, come formulare richieste e come verificare i risultati. Ora guardiamo a che cosa si può fare concretamente, partendo dall'ambito in cui l'AI generativa è più matura e più usata: i testi, i documenti e la conoscenza. È un tema che riguarda praticamente ogni ruolo aziendale, perché quasi ogni lavoro produce, legge, trasforma e cerca informazioni scritte. Il punto di vista è quello dell'utilizzatore: che cosa permette di fare l'AI, quali benefici porta, come ottenere risultati migliori e quali limiti tenere presenti. Il tema va oltre la semplice scrittura: il suo nucleo distintivo è la capacità di sintetizzare, estrarre, confrontare e consultare documenti. Suggerimento per l'apertura: chiedere ai partecipanti quante ore a settimana dedicano a leggere, scrivere, riassumere o cercare informazioni nei documenti. La risposta, di solito sorprendente, mostra perché il tema è rilevante. Nota per il relatore: i contenuti sono stati verificati a ottobre 2026; le capacità degli strumenti su documenti lunghi, tabelle e scansioni migliorano di continuo, quindi esempi e limiti vanno ricontrollati sugli strumenti autorizzati prima di ogni edizione.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo è comprendere le principali possibilità dell'AI nella produzione, trasformazione, analisi, estrazione e organizzazione di contenuti testuali e documentali, e saperle usare bene. Da un lato, l'AI può supportare moltissime attività basate sulle informazioni: dalla redazione di un'email alla sintesi di un rapporto di sessanta pagine, dal confronto di tre offerte alla consultazione di un archivio di procedure. Dall'altro, il valore del risultato dipende da quattro fattori su cui chi usa l'AI può agire: la qualità del materiale e delle fonti fornite, la chiarezza delle istruzioni sullo scopo, la fedeltà e la tracciabilità del risultato, cioè la possibilità di risalire ai passaggi originali, e un controllo adeguato all'uso che se ne farà. Un punto che svilupperemo: generare, trasformare, analizzare ed estrarre informazioni sono attività diverse, con benefici diversi e con esigenze di controllo diverse. Il messaggio centrale del tema: l'AI può trasformare testi e documenti in informazioni organizzate, confrontabili e consultabili, con un grande risparmio di tempo, a condizione di preservare correttezza, significato e tracciabilità.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo sviluppare", headSize: 16, bodySize: 14,
      body: bullets(["Conoscere che cosa l'AI può fare su testi, documenti e conoscenza", "Distinguere produrre, trasformare, analizzare, recuperare", "Ottenere risultati migliori e controllarli in modo proporzionato"], { space: 6 }) });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Da che cosa dipende il valore", headSize: 16, fill: C.accent6, bodySize: 14,
      body: bullets(["Materiale e fonti di qualità", "Istruzioni chiare sullo scopo", "Fedeltà e tracciabilità del risultato", "Controlli adeguati all'uso"], { space: 6 }) });
  }
  {
    const s = content("Il filo conduttore: quattro modalità", "Il filo conduttore del tema sono quattro modalità applicative, che corrispondono a quattro tipi diversi di lavoro informativo. Produrre: creare contenuti nuovi a partire da istruzioni e materiale, come un'email, una relazione, una descrizione. Corrisponde al sottotema 8.1. Trasformare: lavorare su un testo esistente, correggendolo, semplificandolo, traducendolo, cambiandone il formato. Corrisponde all'8.2. Analizzare e strutturare: ricavare da uno o più documenti sintesi, dati strutturati, confronti. Corrispondono l'8.3, l'8.4 e l'8.5, che sono il nucleo distintivo del tema. Recuperare conoscenza: cercare, approfondire e consultare informazioni, sia all'esterno sia in raccolte documentali. Corrispondono l'8.6 e l'8.7. L'8.8, sulle condizioni di efficacia, attraversa tutte le modalità. Non è una sequenza obbligatoria: le modalità spesso si combinano. Per preparare un dossier si può cercare, sintetizzare, estrarre e infine produrre un testo. Nelle slide, un indicatore in alto a destra ricorda la modalità di cui stiamo parlando. Per il relatore, il perimetro del modulo: vanno compresi e sperimentati generazione, trasformazione, sintesi, estrazione, confronto e tracciabilità; vanno conosciuti ricerca informativa, gestione della conoscenza, interrogazione documentale e limiti dei formati; vanno solo accennati architetture RAG, pipeline documentali, indicizzazione, database vettoriali e ricerca semantica. Confini con gli altri temi: i meccanismi tecnici sono nel Tema 2, la teoria delle allucinazioni nel Tema 3, le tecniche di prompting nel Tema 6, i metodi di verifica nel Tema 7, l'analisi quantitativa nel Tema 9, la multimodalità nel Tema 10, agenti e flussi automatici nel Tema 11, la progettazione dei sistemi di conoscenza aziendale nel Tema 14. Un'avvertenza pratica valida per tutto il modulo: i documenti di lavoro vanno caricati solo negli strumenti autorizzati dall'azienda, secondo le regole sulla riservatezza dei dati.");
    const st = [["FiEdit3", "Produrre", "Creare contenuti nuovi da istruzioni", "8.1"], ["FiRefreshCw", "Trasformare", "Lavorare su un testo esistente", "8.2"], ["FiLayers", "Analizzare e strutturare", "Sintesi, estrazione, confronto", "8.3  8.4  8.5"], ["FiDatabase", "Recuperare conoscenza", "Ricerca e raccolte documentali", "8.6  8.7"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, dark = i === 2;
      shapeBox(s, x, 1.2, 2.1, 2.75, dark ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.7, 1.35, 0.7, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.1, y: 2.15, w: 1.9, h: 0.6, fontSize: 15, bold: true, color: dark ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 2.8, w: 1.8, h: 0.6, fontSize: 12, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, st[i][3], { x: x + 0.1, y: 3.5, w: 1.9, h: 0.35, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 3) arrow(s, x + 2.11, 2.4, 0.17);
    }
    shapeBox(s, 0.5, 4.1, 9.0, 0.85, C.accent6, "condizioni trasversali");
    txt(s, [{ text: "8.8 Condizioni di efficacia: ", options: { bold: true, color: C.accent1 } }, { text: "valgono per tutte le modalità. Le modalità si combinano: per un dossier si cerca, si sintetizza, si estrae e si scrive.", options: { color: C.text1 } }], { x: 0.7, y: 4.1, w: 8.6, h: 0.85, fontSize: 13, valign: "middle" });
  }
  {
    const s = content("Attività diverse, valore e controlli", "Il punto concettuale più importante del tema è che generare, trasformare, analizzare, estrarre e recuperare sono attività diverse: offrono benefici diversi, si migliorano con accorgimenti diversi e richiedono controlli diversi. La tabella le mette a confronto. Generare permette di avere bozze e testi in pochi minuti; il risultato migliora se si forniscono il materiale di partenza, il destinatario e qualche esempio; il controllo riguarda l'accuratezza dei fatti e l'adeguatezza al destinatario. Trasformare rende i testi più chiari, tradotti o riformattati; conviene dire che cosa non deve cambiare; si controlla confrontando con l'originale. Sintetizzare e analizzare permette di orientarsi rapidamente in documenti lunghi; aiuta dichiarare lo scopo e chiedere riferimenti; si controlla che condizioni ed eccezioni siano state conservate. Estrarre trasforma testi liberi in dati organizzati; servono campi e regole definiti in anticipo; il controllo riguarda l'accuratezza campo per campo. Recuperare conoscenza dà risposte rapide da fonti esterne e archivi interni; aiuta indicare fonti e perimetro; si controllano la fonte, la sua attualità e la versione del documento. Non ripetiamo qui i metodi generali di verifica del Tema 7: li applichiamo, sottotema per sottotema, ai contenuti documentali.");
    table(s, [["Attività", "Che cosa offre", "Come ottenere di più", "Che cosa controllare"],
      ["Generare", "Bozze e testi in pochi minuti", "Materiale, destinatario, esempi", "Accuratezza, adeguatezza"],
      ["Trasformare", "Testi più chiari, tradotti, riformattati", "Dire che cosa non deve cambiare", "Confronto con l'originale"],
      ["Sintetizzare, analizzare", "Orientarsi in documenti lunghi", "Scopo dichiarato, riferimenti", "Condizioni ed eccezioni"],
      ["Estrarre", "Dati organizzati da testi liberi", "Campi e regole definiti prima", "Accuratezza campo per campo"],
      ["Recuperare conoscenza", "Risposte rapide da fonti e archivi", "Fonti e perimetro indicati", "Fonte, attualità, versione"]],
      { y: 1.15, colW: [1.9, 2.5, 2.4, 2.2], rowH: 0.5, fontSize: 12, blankCorner: false });
    banner(s, 4.35, "Il controllo giusto dipende dal tipo di lavoro che l'AI ha svolto e dall'uso che si farà del risultato.", { h: 0.6, fontSize: 13 });
  }

  // =====================================================================
  section("8.1 Generazione");
  divider("8.1", "Generazione di contenuti testuali", "L'AI accelera la produzione di testi e moltiplica le alternative; qualità e adeguatezza si presidiano con il giusto livello di revisione", "Partiamo dalla modalità più nota: produrre testi nuovi. È quella che quasi tutti hanno già provato, e quella in cui il guadagno di tempo è più immediato. In questo sottotema, da comprendere e sperimentare, vediamo che cosa si può produrre e con quali benefici, da che cosa dipende la qualità di un testo generato, come adattare lo stesso contenuto a destinatari diversi e quale livello di autonomia dare all'AI a seconda del tipo di testo. Come si formulano le richieste l'abbiamo visto nel Tema 6: qui ci concentriamo sulle possibilità e sulle condizioni per ottenere buoni risultati.");
  {
    const s = content("Che cosa si può produrre", "La generazione di testi copre una gamma molto ampia di contenuti professionali. Comunicazioni: email, risposte a richieste, messaggi, avvisi, comunicazioni interne. Documenti di lavoro: relazioni, report, verbali a partire da appunti, proposte. Contenuti informativi: descrizioni di prodotti o servizi, schede, FAQ, testi per il sito o per la intranet, istruzioni. Bozze e strutture: scalette, indici, prime versioni da completare, modelli riutilizzabili. I benefici sono concreti. La velocità: una prima versione in pochi minuti invece che in un'ora. La personalizzazione: lo stesso contenuto declinato per destinatari diversi. Le alternative: più versioni da confrontare, per scegliere la migliore o combinarle. La fine della pagina bianca: si parte da qualcosa di concreto da migliorare. Gli standard coerenti: testi in serie con la stessa struttura e lo stesso stile, per esempio schede prodotto o risposte frequenti. Il valore principale non è scrivere al posto della persona, ma ridurre il tempo delle parti più ripetitive e lasciare più tempo per il contenuto, la verifica e la cura del testo.");
    modeTag(s, 0);
    await iconGrid(s, [
      { icon: "FiMail", head: "Comunicazioni", body: "Email, risposte, avvisi, comunicazioni interne" },
      { icon: "FiFileText", head: "Documenti di lavoro", body: "Relazioni, report, verbali da appunti, proposte" },
      { icon: "FiInfo", head: "Contenuti informativi", body: "Descrizioni, schede, FAQ, istruzioni, testi per la intranet" },
      { icon: "FiList", head: "Bozze e strutture", body: "Scalette, indici, prime versioni, modelli riutilizzabili" },
    ], 2, { y: 1.15, H: 2.5, headSize: 15, bodySize: 12 });
    txt(s, "Il valore", { x: 0.5, y: 3.8, w: 1.1, h: 0.5, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
    const v = ["Velocità", "Personalizzazione", "Alternative", "Pagina mai bianca", "Standard coerenti"];
    v.forEach((t, i) => chip(s, 1.6 + i * 1.59, 3.8, 1.5, 0.5, t, { fill: C.accent6, fontSize: 11 }));
    banner(s, 4.45, "Meno tempo sulle parti ripetitive, più tempo per contenuto, verifica e cura del testo.", { h: 0.55, fontSize: 13 });
  }
  {
    const s = content("Dalle istruzioni al testo", "Un testo generato è il risultato di tre ingredienti, e la sua qualità dipende da tutti e tre. Il primo sono le istruzioni: scopo, destinatario, tono, lunghezza, struttura. Le tecniche per formularle sono nel Tema 6. Il secondo è il materiale di partenza: fatti, dati, appunti, documenti, decisioni già prese. È l'ingrediente più trascurato e il più importante per i testi professionali: quando il sistema non ha i fatti specifici, tende a riempire i vuoti con contenuti generici o con dettagli verosimili ma non verificati, come date, numeri o impegni. Il terzo sono gli esempi e i riferimenti di stile: un testo simile già approvato, le linee guida di comunicazione. Le istruzioni dicono come scrivere, il materiale dice che cosa scrivere, gli esempi dicono in che stile. Su questa base, l'AI dà il meglio in due usi che cambiano il modo di lavorare. Le bozze: una prima versione concreta in pochi minuti, da leggere, correggere e completare. Le versioni alternative: chiedere fin dall'inizio due o tre impostazioni diverse, per esempio una sintetica e una dettagliata, aiuta a capire che cosa si vuole davvero e a non restare ancorati alla prima proposta, come visto nel Tema 5. Il contributo personale resta ciò che rende un testo riconoscibile, evitando che i testi prodotti con gli stessi strumenti finiscano per assomigliarsi tutti. L'istruzione in basso è un esempio: chiede alternative e, insieme, di usare solo i fatti forniti.");
    modeTag(s, 0);
    const ing = [["FiSliders", "Istruzioni", "Come scrivere", "Scopo, destinatario, tono, lunghezza, struttura"], ["FiFolder", "Materiale di partenza", "Che cosa scrivere", "Fatti, dati, appunti, decisioni già prese"], ["FiBookmark", "Esempi e stile", "In che stile", "Testi approvati, linee guida, modo di rivolgersi"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 5.3, 0.85, i === 1 ? C.accent6 : C.background2, ing[i][1]);
      await iconCircle(s, 0.68, y + 0.16, 0.54, ing[i][0]);
      txt(s, ing[i][1], { x: 1.4, y: y + 0.07, w: 2.3, h: 0.36, fontSize: 14, bold: true, color: C.text1 });
      txt(s, ing[i][2], { x: 3.7, y: y + 0.07, w: 2.0, h: 0.36, fontSize: 12, bold: true, color: C.accent1, align: "right" });
      txt(s, ing[i][3], { x: 1.4, y: y + 0.44, w: 4.3, h: 0.36, fontSize: 12, color: C.text2 });
    }
    arrow(s, 5.95, 2.25, 0.4);
    shapeBox(s, 6.5, 1.15, 3.0, 2.75, C.text1, "bozze e alternative");
    await iconCircle(s, 6.7, 1.3, 0.55, "FiCopy", C.accent1);
    txt(s, "Bozze e alternative", { x: 7.35, y: 1.3, w: 2.05, h: 0.55, fontSize: 15, bold: true, color: C.background1, valign: "middle" });
    txt(s, bullets(["Una prima bozza in pochi minuti", "Più versioni da confrontare: sintetica o dettagliata, formale o diretta", "Si combinano gli elementi migliori"], { space: 5 }), { x: 6.7, y: 2.0, w: 2.65, h: 1.8, fontSize: 12, color: C.background1 });
    promptBox(s, 0.5, 4.08, 9.0, 0.88, "«Proponi tre versioni dell'email: una sintetica, una dettagliata, una più diretta. Usa solo i fatti negli appunti allegati e segnala le informazioni mancanti.»", { label: "Esempio di istruzione", fontSize: 11 });
  }
  {
    const s = content("Adattare il testo ai destinatari", "Uno degli usi più utili della generazione è adattare uno stesso contenuto a destinatari diversi. Lo stesso fatto, per esempio una modifica dell'orario del servizio clienti, va comunicato in modo diverso alla direzione, ai colleghi del servizio e ai clienti. Per la direzione conta il perché e l'impatto. Per i colleghi conta che cosa cambia operativamente: da quando, i nuovi turni, a chi rivolgersi. Per i clienti conta che cosa cambia per loro, con un tono cortese e senza dettagli interni. L'AI produce queste versioni in pochi secondi, partendo da un unico contenuto di base, ed è molto flessibile su tre dimensioni vicine ma distinte. Il tono è l'atteggiamento verso chi legge: cordiale, formale, rassicurante, deciso. Lo stile riguarda le scelte di scrittura: frasi brevi o articolate, lessico tecnico o comune, elenchi o testo continuo. Il registro è il livello di formalità adatto al contesto. Due accorgimenti pratici. Primo, indicare esplicitamente tono e registro, o fornire un testo già approvato come esempio: il tono predefinito dei sistemi tende a essere generico, entusiasta o cerimonioso, e in un contesto professionale può suonare poco credibile; la coerenza con la comunicazione aziendale si ottiene fornendo le linee guida di stile. Secondo, partire da un contenuto di base corretto e completo, perché ogni versione ne eredita gli eventuali errori, e rileggere ogni versione pensando al suo destinatario: per esempio, che nella versione per i clienti non sia finito un dettaglio interno. Esempio fittizio in slide.");
    modeTag(s, 0);
    docBox(s, 0.5, 1.15, 9.0, 0.75, "Contenuto di base (esempio fittizio)", "Dal 1° marzo il servizio clienti telefonico sarà attivo dalle 8 alle 18, invece che dalle 9 alle 17.", { fontSize: 12 });
    table(s, [["Destinatario", "Che cosa conta", "Tono e registro"],
      ["Direzione", "Motivazione, costi, effetti attesi", "Sintetico, orientato alle decisioni"],
      ["Colleghi del servizio", "Da quando, nuovi turni, a chi rivolgersi", "Operativo, diretto"],
      ["Clienti", "Che cosa cambia per loro, come contattarci", "Cortese, senza dettagli interni"]],
      { y: 2.02, colW: [2.2, 3.7, 3.1], rowH: 0.4, fontSize: 12, blankCorner: false });
    chip(s, 0.5, 3.78, 2.9, 0.5, "Tono: l'atteggiamento", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.78, 2.9, 0.5, "Stile: frasi, lessico, struttura", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.78, 2.9, 0.5, "Registro: la formalità", { fill: C.background2, fontSize: 12 });
    banner(s, 4.42, "Indicare tono e registro, o dare un testo approvato come esempio: il tono predefinito tende a essere generico.", { h: 0.58, fontSize: 13 });
  }
  {
    const s = content("Quanta autonomia dare all'AI", "L'AI può supportare la produzione di testi con livelli diversi di autonomia, e ciascun livello ha benefici e condizioni d'uso. Nella redazione supervisionata, il sistema produce una proposta e una persona la rivede, la completa, la approva e ne risponde: è il caso di relazioni, offerte e comunicazioni ai clienti. Il beneficio è una bozza in pochi minuti e più tempo per il contenuto. Nella produzione in serie con controlli, il sistema genera molti testi simili, come schede prodotto, descrizioni o risposte standard, a partire da modelli approvati; i controlli sono a campione, con correzione dei casi anomali. Il beneficio è poter gestire volumi elevati con uno stile uniforme. Nell'automazione di attività a basso rischio, il testo è usato senza revisione caso per caso: conferme di ricezione, classificazione delle richieste, riepiloghi per uso interno. Il beneficio è la rapidità e la liberazione delle persone dalle attività ripetitive; le condizioni sono contenuti a basso impatto, regole definite e un monitoraggio periodico. Quale livello scegliere non dipende da una regola universale, ma da tre elementi, coerenti con quanto visto nel Tema 7: le conseguenze di un errore e la visibilità del testo, il processo in cui il testo si inserisce, e le verifiche disponibili, per esempio controlli automatici o revisioni già previste. Lo stesso tipo di testo può richiedere livelli diversi in contesti diversi. In ogni caso, chi usa e diffonde il testo ne risponde, secondo i ruoli e le regole dell'organizzazione.");
    modeTag(s, 0);
    const lv = [
      ["Redazione supervisionata", "Relazioni, offerte, comunicazioni ai clienti", "Bozza rapida, più tempo per il contenuto", "Una persona rivede, completa e approva", C.background2, C.text1, C.accent1],
      ["In serie con controlli", "Schede prodotto, descrizioni, risposte standard", "Volumi elevati, stile uniforme", "Modelli approvati, controlli a campione", C.accent6, C.text1, C.accent1],
      ["Automazione a basso rischio", "Conferme di ricezione, smistamento, riepiloghi interni", "Rapidità, meno lavoro ripetitivo", "Basso impatto, regole definite, monitoraggio", C.accent1, C.background1, C.accent6],
    ];
    lv.forEach((l, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 3.0, l[4], l[0]);
      txt(s, l[0], { x: x + 0.15, y: 1.22, w: 2.56, h: 0.55, fontSize: 14, bold: true, color: l[5], valign: "middle" });
      const rows = [["Esempi", l[1]], ["Benefici", l[2]], ["Condizioni", l[3]]];
      rows.forEach((r, j) => {
        const y = 1.85 + j * 0.76;
        txt(s, r[0], { x: x + 0.15, y, w: 2.56, h: 0.24, fontSize: 11, bold: true, color: l[6] });
        txt(s, r[1], { x: x + 0.15, y: y + 0.25, w: 2.56, h: 0.48, fontSize: 11, color: l[5] });
      });
      if (i < 2) arrow(s, x + 2.88, 2.6, 0.17);
    });
    txt(s, "Più autonomia", { x: 6.64, y: 0.95, w: 2.86, h: 0.2, fontSize: 9, italic: true, color: C.accent2, align: "right" });
    banner(s, 4.3, "Il livello giusto dipende da conseguenze di un errore, processo e verifiche disponibili: non da una regola universale.", { h: 0.68, fontSize: 13 });
  }
  keySlide("L'AI accelera la produzione di contenuti; qualità, accuratezza e adeguatezza dipendono dal materiale fornito e da una revisione proporzionata al rischio.", "Sottotema 8.1  ·  Generazione di contenuti testuali", "Concetto chiave del primo sottotema. Generare testi è la modalità più immediata: email, relazioni, descrizioni, bozze, versioni per destinatari diversi, con un risparmio di tempo concreto. La qualità dipende da tre ingredienti: istruzioni, materiale di partenza ed esempi di stile. Chiedere alternative fin dall'inizio aiuta a scegliere l'impostazione migliore. E il livello di autonomia va scelto in base alle conseguenze di un errore, al processo e alle verifiche disponibili: dalla redazione supervisionata, alla produzione in serie con controlli a campione, fino all'automazione di attività a basso rischio. La revisione è umana e organizzativa: non basta la buona volontà del singolo, servono anche regole su quali testi richiedono quale revisione. Esercizio suggerito: partire da un contenuto di base fittizio e chiedere ai partecipanti di generare tre versioni per destinatari diversi, poi confrontarle per individuare informazioni perse o aggiunte.");

  // =====================================================================
  section("8.2 Trasformazione");
  divider("8.2", "Revisione, riscrittura e trasformazione", "Correggere, semplificare, tradurre e riorganizzare testi esistenti, preservandone significati e informazioni", "Seconda modalità: trasformare. Qui il punto di partenza non sono istruzioni, ma un testo che esiste già, nostro o di altri. L'AI può correggerlo, renderlo più chiaro, semplificarlo, renderlo più accessibile, riformularlo, tradurlo, cambiarne il formato o la struttura. È una modalità molto potente e spesso sottovalutata, con un vantaggio importante: c'è un originale con cui confrontare il risultato, quindi il controllo è più semplice e mirato. L'attenzione specifica del sottotema è preservare il significato: in questo sottotema, da comprendere e sperimentare, vediamo le principali trasformazioni, un esempio completo da appunti a verbale e come chiedere modifiche che non alterino i contenuti.");
  {
    const s = content("Generare o trasformare?", "Quando conviene generare un testo nuovo e quando è più opportuno trasformarne uno esistente? Generare conviene quando non esiste un punto di partenza adatto e il contenuto è relativamente generico, oppure quando si vogliono esplorare impostazioni diverse. Trasformare conviene quando esiste già un testo che contiene i contenuti corretti: una procedura approvata da semplificare, una relazione tecnica da rendere comprensibile alla direzione, appunti di una riunione da trasformare in verbale, un testo da tradurre. In questi casi la trasformazione ha due vantaggi. Il primo è l'affidabilità: il sistema lavora su contenuti forniti invece di produrli, e quindi il rischio di invenzioni si riduce, anche se non si azzera. Il secondo è la verificabilità: c'è un originale con cui confrontare il risultato. Per questo, per i testi professionali che riguardano fatti specifici, una buona regola è partire dal materiale esistente quando c'è, e usare l'AI per trasformarlo.");
    modeTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.6, { icon: "FiEdit3", head: "Generare conviene se", headSize: 16, bodySize: 13,
      body: bullets(["Non c'è un punto di partenza adatto", "Il contenuto è relativamente generico", "Si vogliono esplorare impostazioni diverse"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.6, { icon: "FiRefreshCw", head: "Trasformare conviene se", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Esiste un testo con i contenuti corretti", "Procedure, relazioni, appunti, testi da tradurre", "Meno invenzioni, controllo più semplice"], { space: 5 }) });
    banner(s, 4.0, "Per i testi su fatti specifici: partire dal materiale esistente, quando c'è, e trasformarlo.", { h: 0.8, fontSize: 14 });
  }
  {
    const s = content("Le principali trasformazioni", "Una panoramica delle trasformazioni più utili, che fanno risparmiare molto tempo e migliorano la qualità dei testi. Correzione e chiarezza: refusi, concordanze, punteggiatura, frasi più brevi, ordine logico, meno ambiguità. Semplificazione: rendere comprensibili procedure, regolamenti e documentazione tecnica a chi deve applicarli. Accessibilità: linguaggio chiaro, struttura leggibile, versioni di lettura facile, utili anche per chi non è madrelingua. Riformulazione: cambiare tono, registro o lessico per un destinatario diverso. Traduzione e localizzazione: non solo cambiare lingua, ma adattare formati, riferimenti e convenzioni. Cambio di formato e struttura: da appunti a verbale, da procedura a FAQ, da testo continuo a tabella, con le informazioni importanti all'inizio. Le prime trasformazioni intervengono soprattutto sulla forma; le ultime riorganizzano anche il contenuto. Le trasformazioni più profonde sono anche quelle che portano più valore, perché rendono un testo utilizzabile da chi prima non riusciva a usarlo; per ottenerle bene conviene dire all'AI che cosa deve restare invariato, come vedremo nelle prossime slide.");
    modeTag(s, 1);
    await iconGrid(s, [
      { icon: "FiCheckSquare", head: "Correzione e chiarezza", body: "Refusi, punteggiatura, frasi brevi, meno ambiguità" },
      { icon: "FiMinimize2", head: "Semplificazione", body: "Procedure e regole comprensibili a chi le applica" },
      { icon: "FiEye", head: "Accessibilità", body: "Linguaggio chiaro, versioni di lettura facile" },
      { icon: "FiRepeat", head: "Riformulazione", body: "Tono, registro, lessico per un altro destinatario" },
      { icon: "FiGlobe", head: "Traduzione e localizzazione", body: "Lingua, contesto culturale, formati locali" },
      { icon: "FiShuffle", head: "Formato e struttura", body: "Appunti in verbale, procedura in FAQ, testo in tabella" },
    ], 3, { y: 1.15, H: 2.85, headSize: 13, bodySize: 12 });
    banner(s, 4.2, "Testi più chiari, accessibili e riutilizzabili, in meno tempo. Per le trasformazioni profonde: dire che cosa deve restare invariato.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Semplificare senza tradire", "La semplificazione è una delle trasformazioni più utili: molti testi aziendali, come procedure, regolamenti e comunicazioni normative, sono difficili da leggere per chi deve applicarli, e l'AI li rende chiari in pochi secondi. La slide mostra lo stesso testo fittizio semplificato con due richieste diverse. Con una richiesta generica, 'semplifica il testo', il risultato è chiaro e scorrevole, ma ha perso due elementi: la soglia di importo oltre la quale serve l'autorizzazione e l'eccezione per gli acquisti urgenti. Chi lo legge applicherà la regola in modo sbagliato. Con una richiesta precisa, che indica che cosa conservare, il risultato è altrettanto chiaro e mantiene soglia, autorizzazioni ed eccezione. Il punto non è diffidare della semplificazione, ma chiederla bene: indicare gli elementi che devono restare, come importi, scadenze, condizioni ed eccezioni, e poi controllare quei punti sull'originale. Nei testi con valore normativo o contrattuale, la versione semplificata dovrebbe rimandare all'originale come riferimento valido.");
    modeTag(s, 1);
    docBox(s, 0.5, 1.15, 2.86, 2.95, "Originale (esempio fittizio)", "Gli acquisti di importo superiore a 5.000 euro richiedono l'autorizzazione preventiva del responsabile di funzione e dell'ufficio acquisti. Per gli acquisti urgenti, documentati come tali, l'autorizzazione dell'ufficio acquisti può essere richiesta entro tre giorni lavorativi successivi.", { fontSize: 11 });
    shapeBox(s, 3.57, 1.15, 2.86, 2.95, C.background2, "richiesta generica");
    colLabel(s, 3.75, 1.25, 2.5, "Richiesta generica");
    txt(s, "«Semplifica il testo»", { x: 3.75, y: 1.55, w: 2.5, h: 0.3, fontSize: 10, color: C.text1, fontFace: "Courier New" });
    txt(s, "Prima di fare un acquisto serve l'autorizzazione del proprio responsabile e dell'ufficio acquisti.", { x: 3.75, y: 1.95, w: 2.5, h: 1.0, fontSize: 12, color: C.text1 });
    chip(s, 3.75, 3.05, 2.5, 0.36, "Manca la soglia", { fill: C.accent5, color: C.background1, fontSize: 10 });
    chip(s, 3.75, 3.5, 2.5, 0.36, "Manca l'eccezione", { fill: C.accent5, color: C.background1, fontSize: 10 });
    shapeBox(s, 6.64, 1.15, 2.86, 2.95, C.accent6, "richiesta precisa");
    colLabel(s, 6.82, 1.25, 2.5, "Richiesta precisa");
    txt(s, "«Semplifica; conserva importi, condizioni ed eccezioni»", { x: 6.82, y: 1.55, w: 2.5, h: 0.45, fontSize: 10, color: C.text1, fontFace: "Courier New" });
    txt(s, "Per acquisti oltre 5.000 euro servono, prima, due autorizzazioni: il tuo responsabile e l'ufficio acquisti. Se l'acquisto è urgente, l'ufficio acquisti può autorizzarlo entro tre giorni lavorativi dopo.", { x: 6.82, y: 2.05, w: 2.5, h: 1.95, fontSize: 11, color: C.text1 });
    banner(s, 4.28, "La semplificazione rende applicabili procedure e regole. Chiederla bene: dire che cosa conservare e controllare quei punti sull'originale.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Tradurre e localizzare", "La traduzione è uno degli ambiti in cui i sistemi linguistici danno spesso risultati di buona qualità, soprattutto tra lingue molto diffuse, e permette di rendere disponibili testi e comunicazioni in più lingue in tempi brevissimi. Tradurre un testo professionale, però, non è solo cambiare lingua: la localizzazione adatta il testo al contesto del destinatario, con formati di date, numeri e valute, unità di misura, riferimenti normativi o istituzionali, convenzioni di cortesia. Alcuni accorgimenti migliorano molto il risultato. Fornire un glossario dei termini tecnici e aziendali, perché un termine di settore può avere più traduzioni possibili. Precisare le sfumature che contano, come i gradi di obbligo: 'deve' e 'dovrebbe' in un contratto fanno una grande differenza. Prestare più attenzione con le lingue meno diffuse, dove la qualità può essere inferiore, e con i testi con valore legale, per cui una traduzione automatica non sostituisce la traduzione professionale o certificata quando è richiesta. Un controllo utile quando non si conosce bene la lingua di arrivo è far ritradurre il testo nella lingua originale con uno strumento diverso: aiuta a far emergere scostamenti di significato, ma non certifica l'accuratezza della traduzione, perché due errori possono compensarsi e alcune sfumature si perdono in entrambi i passaggi.");
    modeTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.2, { icon: "FiGlobe", head: "Tradurre e localizzare", headSize: 15, bodySize: 13,
      body: bullets(["Testi in più lingue in tempi brevi", "Date, numeri, valute, unità di misura", "Riferimenti e convenzioni del Paese"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.2, { icon: "FiSliders", head: "Per risultati migliori", headSize: 15, bodySize: 13, fill: C.accent6,
      body: bullets(["Fornire un glossario dei termini aziendali", "Precisare i gradi di obbligo: 'deve' non è 'dovrebbe'", "Più cura per lingue meno diffuse e testi legali"], { space: 4 }) });
    shapeBox(s, 0.5, 3.6, 9.0, 1.3, C.background2, "ritraduzione");
    await iconCircle(s, 0.7, 3.85, 0.6, "FiRepeat", C.accent1);
    txt(s, "Un controllo utile, non una certificazione", { x: 1.5, y: 3.7, w: 7.8, h: 0.4, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Ritradurre nella lingua originale con uno strumento diverso aiuta a far emergere scostamenti di significato, ma non garantisce che la traduzione sia corretta.", { x: 1.5, y: 4.1, w: 7.8, h: 0.7, fontSize: 13, color: C.text2 });
  }
  {
    const s = content("Da appunti a verbale strutturato", "Ecco un esempio completo di trasformazione tra formati, uno degli usi più apprezzati in azienda. A sinistra, appunti fittizi presi durante una riunione: frammentari, con abbreviazioni, ipotesi e decisioni mescolate. Al centro, la richiesta all'AI: trasformarli in un verbale con decisioni, attività con responsabile e scadenza, punti aperti; non trasformare le ipotesi in decisioni; segnalare ciò che manca. A destra, il risultato: un verbale ordinato, pronto da rivedere e inviare, in un minuto invece di mezz'ora. Si notino due cose. La prima: grazie all'istruzione, il rinvio della stampa resta un punto aperto, con l'obiezione di Neri, invece di diventare una decisione. La seconda: il sistema segnala che per il listino non c'è un responsabile e che per le foto manca la scadenza, invece di inventarli. Sono proprio i due rischi tipici di questa trasformazione: un'ipotesi discussa che diventa una decisione presa, e un'attività attribuita alla persona sbagliata o con una scadenza dedotta. Il controllo finale è rapido: chi ha partecipato alla riunione verifica decisioni e responsabili. Lo stesso schema vale per altre trasformazioni di formato: una relazione in una sintesi per la direzione, una procedura in una lista di controllo o in FAQ, un testo continuo in una tabella. Tutti i nomi e i dati sono fittizi.");
    modeTag(s, 1);
    docBox(s, 0.5, 1.15, 2.75, 3.0, "Appunti (esempio fittizio)", "riunione catalogo 14/5\npresenti Bassi, Neri, Conti\nbudget ok fino a 8k\nstampa: rinviare a sett.?? Neri contrario\nConti sente 2 tipografie entro ven\nfoto le fa Bassi\nricontrollare listino", { fontSize: 11 });
    arrow(s, 3.3, 2.45, 0.22);
    promptBox(s, 3.57, 1.15, 2.55, 3.0, "Trasforma gli appunti in un verbale con: decisioni, attività con responsabile e scadenza, punti aperti. Non trasformare le ipotesi in decisioni. Segnala ciò che manca.", { label: "Richiesta all'AI", fontSize: 10.5 });
    arrow(s, 6.17, 2.45, 0.22);
    resultBox(s, 6.44, 1.15, 3.06, 3.0, "Verbale", [
      { text: "Decisioni: ", options: { bold: true } }, { text: "budget massimo 8.000 euro.", options: { breakLine: true } },
      { text: "Attività: ", options: { bold: true } }, { text: "Conti, preventivi da due tipografie entro venerdì. Bassi, servizio fotografico (scadenza da definire).", options: { breakLine: true } },
      { text: "Punti aperti: ", options: { bold: true } }, { text: "rinvio della stampa a settembre (Neri contrario); listino da ricontrollare (responsabile non indicato)." },
    ], { fontSize: 10.5 });
    banner(s, 4.32, "Da controllare: che le ipotesi restino ipotesi e che ogni attività abbia il responsabile giusto.", { h: 0.66, fontSize: 13 });
  }
  {
    const s = content("Preservare il significato", "Come si ottiene una trasformazione che preserva il significato? Il primo passo è conoscere le modifiche che sembrano formali ma sono sostanziali. Una modifica formale cambia il modo in cui una cosa è detta: un refuso corretto, una frase spezzata, un sinonimo davvero equivalente. Una modifica sostanziale cambia che cosa è detto. La tabella mostra quattro casi tipici: 'entro il 15' che diventa 'verso metà mese' trasforma una scadenza in un'indicazione vaga; 'si raccomanda' che diventa 'è obbligatorio' cambia il grado di obbligo; eliminare 'salvo diversa indicazione' cancella un'eccezione; 'propone' che diventa 'garantisce' attribuisce un impegno. Lo stesso vale quando si confrontano due versioni di un documento, come vedremo nell'8.5. Quattro tecniche, dalla più semplice alla più strutturata. Uno: dire in anticipo che cosa non deve cambiare, come importi, date, condizioni, eccezioni, obblighi. Due: chiedere l'elenco delle modifiche apportate, distinguendo quelle formali da quelle che potrebbero toccare il contenuto; non è una garanzia, ma dirige l'attenzione. Tre: usare la funzione di confronto tra versioni dei programmi di scrittura, per vedere esattamente che cosa è cambiato. Quattro: per testi normativi, contrattuali o tecnici, far validare la versione trasformata da chi conosce la materia, mantenendo l'originale come riferimento. L'istruzione in basso è un esempio di richiesta che limita le modifiche e chiede di segnalare, senza applicarle, quelle di contenuto. Più il testo ha conseguenze, più il confronto con l'originale deve essere sistematico.");
    modeTag(s, 1);
    table(s, [["Originale", "Trasformato", "Che cosa cambia davvero"],
      ["Entro il 15 del mese", "Verso metà mese", "Una scadenza diventa vaga"],
      ["Si raccomanda di...", "È obbligatorio...", "Il grado di obbligo"],
      ["Salvo diversa indicazione, ...", "(eliminato)", "Un'eccezione cancellata"],
      ["Il fornitore propone", "Il fornitore garantisce", "Un impegno attribuito"]],
      { y: 1.15, colW: [3.0, 2.7, 3.3], rowH: 0.38, fontSize: 12, blankCorner: false, accentCol: 2 });
    const tc = ["1  Dire che cosa non deve cambiare", "2  Chiedere l'elenco delle modifiche", "3  Confrontare le versioni", "4  Validazione esperta se serve"];
    tc.forEach((t, i) => chip(s, 0.5 + i * 2.2833, 3.2, 2.15, 0.62, t, { fill: i % 2 ? C.background2 : C.accent6, fontSize: 11 }));
    promptBox(s, 0.5, 4.0, 9.0, 0.96, "«Correggi solo grammatica e punteggiatura. Non cambiare importi, date e obblighi. Elenca, senza applicarle, le modifiche di contenuto che suggerisci.»", { label: "Esempio di istruzione", fontSize: 11 });
  }
  keySlide("Trasformare un testo richiede di controllare che la nuova formulazione non alteri significati, intenzioni o informazioni rilevanti.", "Sottotema 8.2  ·  Revisione, riscrittura e trasformazione", "Concetto chiave del secondo sottotema. Trasformare un testo esistente è spesso preferibile a generarlo da zero, perché riduce le invenzioni e offre un originale con cui confrontare il risultato. Le trasformazioni possibili sono molte e di grande valore: correzione, chiarezza, semplificazione, accessibilità, riformulazione, traduzione, cambio di formato e di struttura. L'attenzione comune è preservare il significato, perché molte modifiche che sembrano formali sono sostanziali; si ottiene dicendo che cosa non deve cambiare e controllando quei punti. Il concetto chiave cita anche le intenzioni: un testo riformulato può dire le stesse cose con un'intenzione diversa, per esempio più perentoria o più accomodante. Esercizio suggerito: dare ai partecipanti un paragrafo fittizio di procedura, farlo semplificare con l'AI con una richiesta generica e con una precisa, e confrontare i due risultati con l'originale.");

  // =====================================================================
  section("8.3 Sintesi e analisi");
  divider("8.3", "Sintesi e analisi documentale", "L'AI permette di orientarsi rapidamente in documenti lunghi; una sintesi utile conserva gli elementi essenziali e permette di risalire all'originale", "Entriamo nel nucleo distintivo del tema. Con i sottotemi 8.3, 8.4 e 8.5 l'AI non produce testi nuovi né riscrive testi esistenti: lavora sui documenti per ricavarne qualcosa. In questo sottotema, da comprendere e sperimentare, vediamo che cosa si può fare su un documento, come scegliere il tipo di sintesi in base allo scopo, un esempio di sintesi esecutiva con riferimenti, e come ottenere sintesi fedeli: quali elementi conservare, come verificarli, come lavorare su documenti lunghi e complessi.");
  {
    const s = content("Le possibilità su un documento", "Per chi lavora con grandi quantità di materiale, le possibilità dell'AI nell'analisi dei documenti sono tra le più preziose. Orientarsi rapidamente: capire di che cosa parla un documento, com'è organizzato, quali parti leggere per intero. Trovare informazioni: dove il documento parla di un certo argomento, che cosa dice su penali, scadenze, responsabilità. Costruire sintesi mirate: esecutive per chi decide, operative per chi applica, oppure in risposta a una domanda specifica. Individuare concetti e decisioni: temi, tesi, richieste, punti aperti di un progetto. Analizzare documentazione tecnica e organizzativa: che cosa prevede una procedura, che cosa richiede un capitolato. Preparare approfondimenti: le domande da porre a un fornitore, le sezioni da far leggere a un esperto. I sistemi attuali lavorano con i formati più comuni, come PDF, Word e testo, e molti accettano più documenti insieme. Il valore principale è il tempo e la qualità dell'attenzione: un primo orientamento su cento pagine in pochi minuti, e poi una lettura mirata proprio delle parti che contano.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiCompass", head: "Orientarsi rapidamente", body: "Di che cosa parla, com'è organizzato, che cosa leggere" },
      { icon: "FiSearch", head: "Trovare informazioni", body: "Che cosa dice su penali, scadenze, responsabilità" },
      { icon: "FiAlignLeft", head: "Sintesi mirate", body: "Esecutive, operative, su una domanda specifica" },
      { icon: "FiTarget", head: "Concetti e decisioni", body: "Temi, tesi, richieste, punti aperti" },
      { icon: "FiTool", head: "Documentazione tecnica", body: "Procedure, capitolati, specifiche" },
      { icon: "FiZoomIn", head: "Preparare approfondimenti", body: "Domande da porre, sezioni da leggere per intero" },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Un primo orientamento su cento pagine in pochi minuti, e poi una lettura mirata delle parti che contano.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Sintesi diverse per scopi diversi", "Non esiste la sintesi giusta in assoluto: esiste la sintesi adatta a uno scopo. Lo stesso documento, per esempio un contratto di fornitura, può essere sintetizzato in modi molto diversi. Una sintesi informativa riassume di che cosa parla e quali sono i contenuti principali: serve per orientarsi. Una sintesi esecutiva evidenzia ciò che serve a chi deve decidere: condizioni economiche, durata, rischi, punti da negoziare. Una sintesi operativa estrae ciò che serve a chi deve applicare il documento: scadenze, adempimenti, responsabilità, contatti. Una sintesi mirata risponde a una domanda specifica: che cosa prevede il contratto in caso di ritardo nelle consegne? Dichiarare lo scopo, come visto nel Tema 6, è il modo più semplice per migliorare il risultato, perché guida il sistema nella scelta di che cosa tenere: senza indicazioni si ottiene una sintesi generica, che dà lo stesso spazio a elementi importanti e secondari. L'istruzione in basso è un esempio: indica destinatario, lunghezza, elementi da includere e chiede i riferimenti. Lo scopo determina anche il controllo: una sintesi per orientarsi richiede meno verifica di una sintesi su cui si basa una decisione.");
    modeTag(s, 2);
    table(s, [["Tipo di sintesi", "A chi serve", "Che cosa evidenzia"],
      ["Informativa", "A chi deve orientarsi", "Di che cosa parla, contenuti principali"],
      ["Esecutiva", "A chi deve decidere", "Condizioni, rischi, punti da negoziare"],
      ["Operativa", "A chi deve applicare", "Scadenze, adempimenti, responsabilità"],
      ["Mirata", "A chi ha una domanda", "Solo ciò che risponde alla domanda"]],
      { y: 1.15, colW: [2.2, 2.8, 4.0], rowH: 0.48, fontSize: 13, blankCorner: false });
    promptBox(s, 0.5, 3.75, 9.0, 1.15, "«Sintesi esecutiva per la direzione, massimo una pagina: condizioni economiche, durata, rischi, punti da negoziare. Per ogni punto indica l'articolo da cui deriva.»", { label: "Esempio di istruzione", fontSize: 12 });
  }
  {
    const s = content("Una sintesi esecutiva in pratica", "Un esempio completo, con dati fittizi. Il documento di partenza è un rapporto di audit sui fornitori di sessantaquattro pagine, con nove sezioni e tre allegati. La richiesta all'AI chiede una sintesi esecutiva in cinque punti per la direzione, con sezione e pagina per ogni punto, e di segnalare ciò che non trova. Il risultato si legge in un minuto e permette di decidere se e che cosa approfondire. Il valore dei riferimenti è doppio. Primo, rendono la verifica rapida: un'affermazione da prendere sulla fiducia diventa un'affermazione controllabile in pochi secondi, aprendo il documento nel punto indicato. Secondo, rendono visibile ciò che manca: il quinto punto, il costo del piano di miglioramento, è segnalato come non trovato invece di essere stimato. Per i punti su cui si basa una decisione, il controllo del riferimento ha tre passaggi, coerenti con quelli visti nel Tema 7 per le fonti: il passaggio esiste nel punto indicato; dice davvero ciò che la sintesi afferma, con le stesse condizioni; se presentato come citazione, corrisponde parola per parola. Serve perché i sistemi possono indicare un articolo sbagliato, una pagina approssimativa o una parafrasi presentata come citazione. L'affidabilità dei numeri di pagina, in particolare, dipende dal formato e dallo strumento: gli strumenti che mostrano direttamente il passaggio citato, con un collegamento al documento, rendono questo controllo molto più rapido.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 2.6, 1.25, "Documento (esempio fittizio)", "Rapporto di audit fornitori: 64 pagine, 9 sezioni, 3 allegati", { fontSize: 11 });
    promptBox(s, 0.5, 2.55, 2.6, 1.75, "Sintesi esecutiva in 5 punti per la direzione. Per ogni punto indica sezione e pagina. Segnala ciò che non trovi.", { label: "Richiesta all'AI", fontSize: 10.5 });
    arrow(s, 3.17, 2.5, 0.2);
    shapeBox(s, 3.45, 1.15, 6.05, 3.15, C.accent6, "sintesi con riferimenti");
    colLabel(s, 3.65, 1.25, 5.6, "Sintesi esecutiva con riferimenti");
    const pts = [["Due fornitori su dodici non hanno rinnovato la certificazione", "§3.2, p. 14"], ["Ritardi medi di consegna in aumento nel secondo semestre", "§4.1, p. 22"], ["Penali previste dai contratti, mai applicate nel periodo", "§5.3, p. 31"], ["Piano di miglioramento proposto entro marzo", "§8, p. 58"], ["Costo stimato del piano", "non trovato"]];
    pts.forEach((p, i) => {
      const y = 1.6 + i * 0.52;
      const none = i === 4;
      txt(s, p[0], { x: 3.65, y, w: 4.25, h: 0.46, fontSize: 11, color: C.text1, valign: "middle" });
      chip(s, 8.0, y + 0.07, 1.35, 0.32, p[1], { fill: none ? C.accent5 : C.accent1, color: C.background1, fontSize: 10 });
    });
    txt(s, "Controllare un riferimento:", { x: 0.5, y: 4.45, w: 2.4, h: 0.5, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    chip(s, 2.9, 4.45, 2.1, 0.5, "Esiste nel punto indicato", { fill: C.background2, fontSize: 11 });
    chip(s, 5.1, 4.45, 2.3, 0.5, "Dice ciò che afferma la sintesi", { fill: C.background2, fontSize: 11 });
    chip(s, 7.5, 4.45, 2.0, 0.5, "Citazione esatta", { fill: C.background2, fontSize: 11 });
  }
  {
    const s = content("Il rischio di perdita di significato", "Questo è forse il punto di attenzione più importante del tema: una sintesi può apparire fedele pur avendo eliminato eccezioni, vincoli, sfumature o elementi decisivi. Il motivo è intrinseco: sintetizzare significa togliere, e il sistema sceglie che cosa togliere secondo criteri che non coincidono necessariamente con ciò che per noi è importante. Gli elementi più a rischio sono quelli che occupano poco spazio ma hanno grande peso: una condizione introdotta da 'solo se', un'eccezione introdotta da 'salvo', un limite numerico, una scadenza, un'espressione di incertezza come 'in via preliminare' o 'da confermare'. L'esempio fittizio mostra un estratto di verbale e una sintesi che sembra corretta: ogni frase è vera, ma la decisione appare definitiva, mentre era condizionata all'approvazione del budget, e l'incertezza sui tempi è sparita. Chi legge la sintesi crede che il progetto sia approvato. Queste perdite non si vedono leggendo la sintesi, che è scorrevole e ben organizzata: si evitano chiedendo esplicitamente di conservare condizioni e gradi di certezza, e si trovano confrontando i punti decisivi con l'originale. La prossima slide mostra dove guardare.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 4.35, 2.6, "Verbale originale (esempio fittizio)", "Il comitato approva in via preliminare l'avvio del progetto, subordinatamente all'approvazione del budget nella riunione di aprile. I tempi di consegna indicati dal fornitore sono da confermare.", { fontSize: 12 });
    docBox(s, 5.15, 1.15, 4.35, 2.6, "Sintesi", "Il comitato ha approvato l'avvio del progetto. Sono stati discussi budget e tempi di consegna.", { fontSize: 13, fill: C.accent6 });
    chip(s, 5.35, 2.5, 1.95, 0.42, "Condizione persa", { fill: C.accent5, color: C.background1, fontSize: 11 });
    chip(s, 7.4, 2.5, 1.9, 0.42, "Incertezza persa", { fill: C.accent5, color: C.background1, fontSize: 11 });
    banner(s, 3.95, "Ogni frase è vera, ma la decisione sembra definitiva. Si evita chiedendo di conservare condizioni e gradi di certezza.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Che cosa conservare in una sintesi", "Per ottenere e controllare sintesi fedeli conviene sapere dove guardare. Gli elementi da conservare sono quelli che occupano poco spazio ma cambiano le conseguenze. Condizioni: 'solo se', 'a condizione che'. Eccezioni: 'salvo', 'tranne'. Limiti e soglie: importi massimi, percentuali. Scadenze: date, termini, preavvisi. Responsabilità: chi deve fare che cosa. Gradi di certezza e di obbligo: 'da confermare', 'è obbligatorio'. Negazioni: 'non si applica', 'esclusivamente'. Voci minoritarie: in un verbale un'obiezione registrata, in un rapporto un rischio segnalato in nota. Il metodo si articola in tre momenti. Prima: dichiarare lo scopo e indicare gli elementi da includere. Durante: chiedere i riferimenti ai passaggi originali e, insieme alla sintesi, un elenco separato di tutte le condizioni, eccezioni, scadenze e limiti presenti nel documento. Dopo: controllare sul documento i punti critici, con un'intensità proporzionata all'uso, come vedremo nell'8.8. È più facile controllare un elenco mirato che cercare le perdite in una sintesi scorrevole. Un principio di fondo: chi legge una sintesi tende a considerarla equivalente al documento; quando una sintesi è destinata ad altri, conviene indicare che si tratta di una sintesi e dove trovare l'originale.");
    modeTag(s, 2);
    const it = [["Condizioni", "solo se, a condizione che"], ["Eccezioni", "salvo, tranne"], ["Limiti e soglie", "importi, percentuali"], ["Scadenze", "date, termini, preavvisi"], ["Responsabilità", "chi fa che cosa"], ["Certezza e obbligo", "da confermare, è obbligatorio"], ["Negazioni", "non si applica, esclusivamente"], ["Voci minoritarie", "obiezioni, rischi in nota"]];
    it.forEach((e, i) => {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.15 + row * 0.9;
      shapeBox(s, x, y, 2.15, 0.8, row === 0 ? C.background2 : C.accent6, e[0]);
      txt(s, e[0], { x: x + 0.15, y: y + 0.07, w: 1.9, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.15, y: y + 0.42, w: 1.9, h: 0.32, fontSize: 11, italic: true, color: C.text2 });
    });
    const ph = [["Prima", "Scopo ed elementi da includere"], ["Durante", "Riferimenti ed elenco di condizioni ed eccezioni"], ["Dopo", "Punti critici verificati sul documento"]];
    ph.forEach((p, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 3.05, 2.86, 1.05, C.background2, p[0]);
      txt(s, p[0], { x: x + 0.18, y: 3.1, w: 2.5, h: 0.36, fontSize: 15, bold: true, color: C.accent1 });
      txt(s, p[1], { x: x + 0.18, y: 3.47, w: 2.55, h: 0.58, fontSize: 12, color: C.text1 });
      if (i < 2) arrow(s, x + 2.88, 3.42, 0.17);
    });
    banner(s, 4.3, "È più facile controllare un elenco mirato che cercare le perdite in una sintesi scorrevole.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Lavorare su documenti complessi", "Alcune caratteristiche dei documenti rendono la sintesi più impegnativa, e per ciascuna esiste un accorgimento pratico. Documenti molto lunghi: chiedere una sintesi per sezioni, che rende visibile se una parte manca, e porre domande mirate anche sulle parti centrali. Rimandi interni e allegati: un contratto in cui l'articolo 9 rimanda all'allegato C, che modifica l'articolo 4, richiede di collegare parti lontane; conviene chiedere esplicitamente di tenerne conto e di indicare i rimandi usati. Tabelle e impaginazioni complesse: chiedere i valori riga per riga e controllarne alcuni. Linguaggio specialistico: fornire un glossario e far rivedere il risultato a chi conosce la materia. Più documenti insieme: chiedere di indicare sempre da quale documento proviene ogni informazione. Le capacità degli strumenti su questi aspetti variano molto, secondo il modello, lo strumento, il formato e la lunghezza, e migliorano di continuo; queste tecniche aiutano con la maggior parte degli strumenti. Le condizioni di efficacia sono riprese in modo più completo nell'8.8.");
    modeTag(s, 2);
    table(s, [["Situazione", "Come ottenere risultati migliori"],
      ["Documenti molto lunghi", "Sintesi per sezioni, domande mirate anche sulle parti centrali"],
      ["Rimandi e allegati", "Chiedere di collegare articoli e allegati citati, indicandoli"],
      ["Tabelle e impaginazioni", "Chiedere i valori riga per riga, controllarne alcuni"],
      ["Linguaggio specialistico", "Fornire un glossario, far rivedere a chi conosce la materia"],
      ["Più documenti insieme", "Chiedere di indicare sempre il documento di provenienza"]],
      { y: 1.15, colW: [2.9, 6.1], rowH: 0.47, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 4.15, "Le capacità variano per modello, strumento, formato e lunghezza: queste tecniche aiutano con la maggior parte degli strumenti.", { h: 0.8, fontSize: 13 });
  }
  keySlide("Una sintesi utile deve rappresentare fedelmente gli elementi essenziali e consentire controlli sui contenuti originali quando richiesto dall'utilizzo previsto.", "Sottotema 8.3  ·  Sintesi e analisi documentale", "Concetto chiave del sottotema 8.3. L'AI offre grandi possibilità nell'analisi dei documenti: orientarsi rapidamente, trovare informazioni, costruire sintesi esecutive, operative e mirate, preparare approfondimenti. Una sintesi rende al meglio quando è pensata per uno scopo, quando indica i riferimenti ai passaggi originali e quando conserva gli elementi che contano di più: condizioni, eccezioni, limiti, scadenze, gradi di certezza. Il controllo va proporzionato all'uso: più la sintesi sostituisce la lettura dell'originale, più va verificata. Esercizio suggerito: dare ai partecipanti un documento fittizio di due o tre pagine con alcune condizioni ed eccezioni, farlo sintetizzare con l'AI prima senza e poi con l'elenco degli elementi da conservare, e confrontare i due risultati con l'originale.");

  // =====================================================================
  section("8.4 Estrazione");
  divider("8.4", "Estrazione e strutturazione delle informazioni", "L'AI trasforma testi non strutturati in dati organizzati e utilizzabili; prima dell'impiego operativo, i dati vanno controllati", "Passiamo dalla sintesi all'estrazione. Qui l'obiettivo non è ridurre un documento, ma ricavarne informazioni puntuali e organizzarle in una struttura: una tabella, un elenco di campi, una classificazione. È una delle possibilità più concrete e meno conosciute dell'AI generativa, perché permette di trasformare testi non strutturati, come email, contratti, moduli, verbali, in dati utilizzabili da attività successive. In questo sottotema, da comprendere e sperimentare, vediamo che cosa si può estrarre, un esempio da email a record, come classificare e trovare ricorrenze, e come passare dal dato estratto al dato validato.");
  {
    const s = content("Sintetizzare o estrarre?", "Qual è la differenza tra sintetizzare un documento ed estrarne dati strutturati? La sintesi produce un testo più breve, che interpreta e seleziona i contenuti: il risultato si legge. L'estrazione produce dati puntuali, organizzati in campi definiti in anticipo, come fornitore, data di scadenza, importo, numero d'ordine: il risultato si usa, in una tabella, in un confronto, in un sistema gestionale, in un'analisi. Le cose che si possono estrarre sono molte. Nomi e codici: persone, aziende, ruoli, numeri di documento. Date e scadenze: decorrenze, termini, rinnovi. Importi e quantità: prezzi, totali, sconti, penali. Riferimenti: ordini, contratti, pratiche, norme. Classificazioni: il tipo di richiesta, l'argomento di un reclamo, l'urgenza. Ricorrenze: i motivi più frequenti di reclamo in cento email, le clausole presenti o assenti in un gruppo di contratti. Le prime quattro categorie riguardano informazioni scritte esplicitamente nel testo e l'estrazione è di norma affidabile; le ultime due richiedono un'interpretazione, e la qualità dipende dalla chiarezza delle categorie fornite. Il valore è grande: informazioni che prima andavano lette documento per documento, per esempio per sapere quanti contratti scadono nel prossimo trimestre, diventano dati da ordinare, filtrare, contare e collegare. Proprio perché vengono usati in attività successive, i dati estratti si controllano campo per campo, come vedremo.");
    modeTag(s, 2);
    await card(s, 0.5, 1.15, 4.35, 1.6, { icon: "FiAlignLeft", inline: true, head: "Sintesi: un testo da leggere", headSize: 14, bodySize: 12,
      body: "Interpreta e seleziona. Si controlla la fedeltà complessiva." });
    await card(s, 5.15, 1.15, 4.35, 1.6, { icon: "FiGrid", inline: true, head: "Estrazione: dati da usare", headSize: 14, bodySize: 12, fill: C.accent6,
      body: "Campi definiti, pronti per tabelle e gestionali. Si controlla campo per campo." });
    txt(s, "Che cosa si può estrarre", { x: 0.5, y: 2.92, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    const ex = ["Nomi e codici", "Date e scadenze", "Importi e quantità", "Riferimenti", "Classificazioni", "Ricorrenze"];
    ex.forEach((t, i) => chip(s, 0.5 + i * 1.52, 3.3, 1.43, 0.5, t, { fill: i < 4 ? C.background2 : C.accent6, fontSize: 11 }));
    banner(s, 4.0, "Informazioni che andavano lette documento per documento diventano dati da ordinare, filtrare, contare e collegare.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Da email a dato utilizzabile", "Gran parte delle informazioni aziendali vive in testi: email, contratti, moduli compilati in formato libero, verbali, segnalazioni, offerte. Sono informazioni preziose, ma difficili da usare in modo sistematico. L'esempio fittizio mostra un'email di un cliente trasformata in un record strutturato: cliente, numero d'ordine, tipo di richiesta, prodotto, scadenza, urgenza. Su cento email, lo stesso procedimento produce una tabella che si può ordinare, filtrare, contare e collegare ad altri dati, per esempio per vedere quali prodotti generano più richieste di sostituzione. È il passaggio che rende utilizzabile da attività successive un'informazione che prima era solo leggibile. L'istruzione in basso mostra due accorgimenti: elencare i campi in anticipo e dire che cosa fare quando un'informazione manca, invece di lasciare che il sistema la stimi. Si noti che l'urgenza non è scritta nell'email: è una classificazione, dedotta dal riferimento all'evento, e come tale va riconosciuta. La qualità dell'estrazione va controllata prima dell'impiego operativo. L'analisi quantitativa dei dati così ottenuti appartiene al Tema 9; i flussi automatici che fanno questo in modo continuo, al Tema 11.");
    modeTag(s, 2);
    docBox(s, 0.5, 1.15, 4.1, 2.75, "Email del cliente (esempio fittizio)", "Buongiorno, vi scrivo per l'ordine 4471 del 12 marzo. Le sedie modello Alfa sono arrivate, ma due su dieci hanno la seduta danneggiata. Avremmo bisogno della sostituzione entro fine mese, perché abbiamo un evento. Grazie, M. Rossi, Studio Bianchi", { fontSize: 12 });
    arrow(s, 4.7, 2.35, 0.4);
    table(s, [["Campo", "Valore"], ["Cliente", "Studio Bianchi"], ["Ordine", "4471"], ["Tipo richiesta", "Sostituzione"], ["Prodotto", "Sedia Alfa, 2 pezzi"], ["Scadenza", "Fine mese"], ["Urgenza", "Alta"]],
      { x: 5.2, y: 1.15, w: 4.3, colW: [1.6, 2.7], rowH: 0.39, fontSize: 12, blankCorner: false, accentCol: 1 });
    promptBox(s, 0.5, 4.05, 9.0, 0.9, "«Estrai cliente, ordine, tipo di richiesta, prodotto, scadenza e urgenza. Se un campo non c'è, scrivi 'non presente'. Indica quali valori hai dedotto.»", { label: "Esempio di istruzione", fontSize: 11 });
  }
  {
    const s = content("Classificare e trovare ricorrenze", "Due forme di strutturazione che vanno oltre l'estrazione di singoli valori, e che hanno un grande valore informativo. La classificazione assegna ogni contenuto a una categoria: il tipo di richiesta, il reparto competente, il tema di un reclamo, il livello di priorità. Applicata a centinaia di email o segnalazioni, permette di smistarle e di misurare dove si concentrano i problemi. Le ricorrenze emergono confrontando molti contenuti: quali problemi si ripetono nelle segnalazioni, quali clausole compaiono in tutti i contratti tranne uno, quali argomenti tornano nelle riunioni. Permettono di vedere schemi che in una lettura documento per documento sfuggono. Tre accorgimenti rendono questi risultati affidabili. Categorie ben definite: fornire per ogni categoria una definizione e qualche esempio, e prevedere una categoria 'altro' o 'non classificabile', per evitare forzature; se le categorie non sono chiare, anche due persone le applicherebbero in modo diverso. Coerenza: verificare che lo stesso tipo di contenuto finisca sempre nella stessa categoria, anche in elaborazioni fatte in momenti diversi. Conteggi verificati: se il sistema dice che il 40 per cento dei reclami riguarda le consegne, conviene controllare su un campione, perché i numeri calcolati su grandi insiemi sono tra gli errori più difficili da notare.");
    modeTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 1.75, { icon: "FiTag", inline: true, head: "Classificare", headSize: 15, bodySize: 13, body: "Smistare email e segnalazioni per tipo, reparto, tema, priorità." });
    await card(s, 5.15, 1.2, 4.35, 1.75, { icon: "FiRepeat", inline: true, head: "Trovare ricorrenze", headSize: 15, bodySize: 13, fill: C.accent6, body: "Vedere gli schemi che si ripetono e sfuggono alla lettura singola." });
    const at = [["Categorie ben definite", "Definizione ed esempi per ognuna, più 'altro' o 'non classificabile'"], ["Coerenza", "Lo stesso contenuto sempre nella stessa categoria"], ["Conteggi verificati", "Controllare le percentuali su un campione"]];
    at.forEach((e, i) => {
      const y = 3.15 + i * 0.6;
      shapeBox(s, 0.5, y, 9.0, 0.52, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.6, h: 0.52, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.3, y, w: 6.0, h: 0.52, fontSize: 13, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Dal dato estratto al dato validato", "Il messaggio chiave del sottotema: un dato estratto non è automaticamente un dato validato. Tra il momento in cui l'AI produce una tabella e il momento in cui quei dati entrano in un processo, in un gestionale o in una decisione, c'è un passaggio di controllo, che è proprio quello che si rischia di saltare, perché la tabella sembra ordinata e completa. Il controllo comincia prima dell'estrazione, con tre regole decise in anticipo. Se l'informazione non è presente, il campo resta vuoto o riporta 'non presente', mai un valore stimato. Se è ambigua, per esempio due date diverse o un importo con e senza IVA, il campo riporta 'ambiguo' con una nota. Se il valore è stato calcolato e non letto, per esempio una scadenza ricavata da data di inizio e durata, è segnalato come dedotto. Queste regole servono perché un valore inventato in una tabella ha lo stesso aspetto di un valore estratto. Dopo l'estrazione, quattro controlli pratici. A campione: confrontare con gli originali una parte dei record, scelti a caso e tra quelli anomali, allargando il controllo se emergono errori. Conteggi: il numero di record corrisponde ai documenti, le somme tornano con un totale noto. Plausibilità: date, ordini di grandezza, categorie. Campi segnalati: tutti i 'non presente', 'ambiguo' e 'dedotto' vanno guardati. Errori tipici sono cifre invertite, IVA inclusa o esclusa, una data come 03/04 letta come 3 aprile o 4 marzo, righe o documenti saltati. Per le estrazioni ripetute nel tempo, una verifica iniziale approfondita può giustificare controlli successivi più leggeri. Infine, conservare per ogni dato il documento e il passaggio di origine permette di controllare anche a distanza di tempo.");
    modeTag(s, 2);
    const st = ["Documento", "Dato estratto", "Dato controllato", "Dato validato", "Impiego"];
    st.forEach((t, i) => {
      const x = 0.5 + i * 1.84;
      chip(s, x, 1.15, 1.6, 0.58, t, { fill: i === 2 ? C.accent5 : (i === 4 ? C.accent1 : C.background2), color: i === 2 || i === 4 ? C.background1 : C.text1, fontSize: 13 });
      if (i < 4) arrow(s, x + 1.62, 1.28, 0.2);
    });
    txt(s, "Regole decise prima", { x: 0.5, y: 1.9, w: 4, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const rl = [["Non presente", "mai un valore stimato"], ["Ambiguo", "con una nota che spiega"], ["Dedotto", "segnalato come tale"]];
    rl.forEach((r, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.25, 2.86, 0.6, C.accent6, r[0]);
      txt(s, [{ text: r[0] + ": ", options: { bold: true, color: C.accent1 } }, { text: r[1], options: { color: C.text1 } }], { x: x + 0.15, y: 2.25, w: 2.6, h: 0.6, fontSize: 12, valign: "middle" });
    });
    txt(s, "Controlli dopo l'estrazione", { x: 0.5, y: 3.0, w: 4, h: 0.3, fontSize: 13, bold: true, color: C.text1 });
    const tc = [["A campione", "Casuali e anomali"], ["Conteggi", "Record, somme, totali"], ["Plausibilità", "Date, scale, categorie"], ["Campi segnalati", "Assenti, ambigui, dedotti"]];
    tc.forEach((t, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 3.35, 2.15, 0.82, C.background2, t[0]);
      txt(s, t[0], { x: x + 0.12, y: 3.4, w: 1.95, h: 0.36, fontSize: 13, bold: true, color: C.accent1, align: "center" });
      txt(s, t[1], { x: x + 0.12, y: 3.76, w: 1.95, h: 0.34, fontSize: 11, color: C.text2, align: "center" });
    });
    banner(s, 4.35, "Per ogni dato, conservare documento e passaggio di origine: la verifica resta possibile anche a distanza di tempo.", { h: 0.62, fontSize: 13 });
  }
  keySlide("L'AI può rendere più utilizzabile il contenuto informativo dei documenti, ma un dato estratto non è automaticamente un dato validato.", "Sottotema 8.4  ·  Estrazione e strutturazione delle informazioni", "Concetto chiave del sottotema 8.4. L'estrazione trasforma testi non strutturati in dati utilizzabili: nomi, date, importi, riferimenti, classificazioni, ricorrenze. È una delle possibilità più concrete dell'AI, perché rende sistematicamente usabili informazioni che prima erano solo leggibili. Funziona al meglio con campi definiti in anticipo, regole per i valori mancanti, ambigui o dedotti, categorie chiare, e un passaggio di validazione prima dell'impiego operativo, con controlli a campione, dei conteggi e della plausibilità. Esercizio suggerito: preparare cinque o sei email fittizie di clienti, chiedere all'AI di estrarne una tabella con campi definiti, e far controllare ai partecipanti ogni valore, contando errori, campi inventati e campi correttamente segnalati come mancanti.");

  // =====================================================================
  section("8.5 Confronto");
  divider("8.5", "Confronto e analisi di più documenti", "L'AI rende rapido il confronto tra versioni, offerte e procedure, mettendo in evidenza le differenze che contano per decidere", "Terzo sottotema del nucleo distintivo: il confronto tra documenti. Mentre l'8.3 lavora su un documento per volta, qui il valore sta nelle relazioni tra documenti diversi: due versioni dello stesso contratto, tre offerte di fornitori, una procedura e il regolamento a cui dovrebbe conformarsi. Confrontare documenti a mano è lungo, faticoso e soggetto a errori di attenzione; l'AI può renderlo molto più rapido e mettere ordine nelle differenze, a supporto di decisioni come la scelta di un fornitore o l'accettazione di un contratto. In questo sottotema, da comprendere e sperimentare, vediamo i tre tipi di confronto, l'identificazione delle modifiche, un esempio di matrice comparativa e la ricerca di contraddizioni e lacune.");
  {
    const s = content("Tre tipi di confronto", "Il sottotema comprende tre famiglie di confronto, ciascuna con un contributo diverso alle decisioni. Il confronto tra versioni di uno stesso documento: che cosa è cambiato tra la bozza di contratto inviata e quella ricevuta dalla controparte, tra la procedura dell'anno scorso e quella aggiornata? Serve a decidere se accettare o rinegoziare, e a individuare anche le modifiche non dichiarate. Il confronto tra documenti alternativi: tre offerte di fornitori, più proposte progettuali, condizioni di diversi contratti. Serve a scegliere, mettendo in evidenza elementi comuni e differenze. Il confronto tra documenti collegati: una procedura e il regolamento che dovrebbe applicare, un capitolato e l'offerta che dovrebbe rispondervi, un verbale e il piano di progetto. Serve a verificare la coerenza, trovando contraddizioni e informazioni mancanti. In tutti e tre i casi, l'AI produce rapidamente un primo quadro ordinato delle differenze. Per il confronto tra versioni esistono anche gli strumenti tradizionali, come la funzione di confronto dei programmi di scrittura, esatti sulle modifiche testuali: l'AI aggiunge la capacità di spiegarle, ordinarle per importanza e confrontare documenti con struttura diversa. Le due cose si combinano bene.");
    modeTag(s, 2);
    await iconGrid(s, [
      { icon: "FiGitCommit", head: "Versioni di un documento", body: "Che cosa è cambiato, anche se non dichiarato. Per decidere se accettare o rinegoziare." },
      { icon: "FiColumns", head: "Documenti alternativi", body: "Offerte, proposte, contratti: punti comuni e differenze. Per scegliere." },
      { icon: "FiGitMerge", head: "Documenti collegati", body: "Procedura e regolamento, capitolato e offerta. Per verificare la coerenza." },
    ], 3, { y: 1.2, h: 2.25, headSize: 14, bodySize: 12 });
    banner(s, 3.7, "Il confronto tradizionale è esatto sulle modifiche testuali; l'AI le spiega, le ordina per importanza e confronta documenti con struttura diversa.", { h: 0.9, fontSize: 13 });
  }
  {
    const s = content("Identificare le modifiche", "Il confronto tra versioni è un caso d'uso molto concreto: quando una controparte restituisce un contratto o un accordo, non sempre segnala tutte le modifiche, e controllare a mano un documento di trenta pagine è lungo e soggetto a distrazioni. Gli strumenti tradizionali mostrano ogni differenza testuale, ma non distinguono un refuso corretto da una clausola modificata, e funzionano male quando il documento è stato riorganizzato. L'AI aiuta in tre modi: elenca le modifiche raggruppandole per importanza, spiega in linguaggio semplice che cosa cambia in pratica, e segnala quelle che potrebbero avere conseguenze. L'esempio fittizio mostra tre modifiche tra due versioni di un accordo: una formale e due sostanziali. Il passaggio da 30 a 60 giorni per il pagamento cambia le condizioni economiche; il passaggio da 'garantisce' a 'si adopera per' sembra una sfumatura di stile, ma attenua un obbligo. Sono le differenze che sembrano formali e non lo sono, già incontrate nell'8.2. Per i confronti importanti conviene chiedere al sistema di classificare ogni differenza come formale o sostanziale e di motivare la classificazione. Due indicazioni pratiche. Per i documenti importanti, combinare l'AI con il confronto tradizionale, che è esaustivo sulle differenze testuali. E ricordare che quanto conta una modifica dipende dal contesto della trattativa, che conosce chi la segue.");
    modeTag(s, 2);
    table(s, [["Versione 1", "Versione 2", "Natura"],
      ["Il fornitre si impegna", "Il fornitore si impegna", "Formale: refuso"],
      ["Pagamento a 30 giorni", "Pagamento a 60 giorni", "Sostanziale: condizioni economiche"],
      ["Il fornitore garantisce la consegna", "Il fornitore si adopera per la consegna", "Sostanziale: obbligo attenuato"]],
      { y: 1.15, colW: [3.0, 3.2, 2.8], rowH: 0.5, fontSize: 12, blankCorner: false, accentCol: 2 });
    txt(s, "Esempio fittizio", { x: 0.5, y: 3.2, w: 3, h: 0.28, fontSize: 10, italic: true, color: C.accent2 });
    await card(s, 0.5, 3.55, 4.35, 1.4, { head: "AI e confronto tradizionale insieme", headSize: 14, bodySize: 12, body: "Il confronto tradizionale trova ogni differenza testuale; l'AI le spiega e le ordina per importanza." });
    await card(s, 5.15, 3.55, 4.35, 1.4, { head: "Il contesto lo porta chi decide", headSize: 14, bodySize: 12, fill: C.accent6, body: "L'AI segnala che cosa cambia; quanto conta lo valuta chi conosce la trattativa." });
  }
  {
    const s = content("Tre offerte in una matrice", "Un esempio completo di confronto tra documenti alternativi, con dati fittizi: tre offerte di fornitori per la stessa fornitura. La richiesta all'AI definisce i criteri che contano per la decisione, chiede valori comparabili, per esempio tutti i prezzi IVA esclusa e tutti i tempi in giorni di calendario, il paragrafo da cui deriva ogni valore, e di dichiarare ciò che manca. Il risultato è una matrice che in pochi secondi mette in evidenza le differenze utili alla scelta: B costa meno ma consegna più lentamente e fa pagare l'assistenza; C consegna prima ma non specifica l'assistenza, e quindi è il primo punto da chiarire con il fornitore. Tre elementi rendono la matrice affidabile. Il riferimento in ogni cella: permette di verificare un valore affiancando il passaggio originale, ed è particolarmente importante perché con più documenti il rischio di attribuire un'informazione al fornitore sbagliato è reale. Contestare a un fornitore una mancanza che non c'è, o scegliere sulla base di una condizione dell'offerta sbagliata, è un errore che si paga. I vuoti dichiarati: se un'offerta non specifica un elemento, la cella deve dirlo, invece di riportare un valore dedotto. La comparabilità: i 20 giorni lavorativi di C sono stati convertiti in circa 28 giorni di calendario, altrimenti il confronto sarebbe sbagliato pur sembrando preciso. Scegliere i criteri è compito di chi decide: se li lasciamo scegliere al sistema, rischiamo un confronto sui criteri più facili da estrarre, non su quelli più importanti. Anche le conclusioni, come 'l'offerta A è la più completa', dovrebbero indicare su quali differenze si basano.");
    modeTag(s, 2);
    promptBox(s, 0.5, 1.12, 9.0, 0.9, "«Confronta le tre offerte su prezzo IVA esclusa, consegna in giorni di calendario, garanzia e assistenza. Per ogni valore indica il paragrafo. Se un dato manca, scrivi 'non specificato'.»", { label: "Richiesta all'AI (esempio fittizio)", fontSize: 11 });
    table(s, [["Criterio", "Fornitore A", "Fornitore B", "Fornitore C"],
      ["Prezzo (IVA esclusa)", "12.400 € (§3)", "11.900 € (§2.1)", "12.100 € (p. 4)"],
      ["Consegna", "30 giorni (§5)", "45 giorni (§4)", "circa 28 giorni: 20 lavorativi (p. 6)"],
      ["Garanzia", "24 mesi (§7)", "36 mesi (§6.2)", "24 mesi (p. 7)"],
      ["Assistenza", "Inclusa 12 mesi (§8)", "A pagamento (§6.4)", "Non specificata"]],
      { y: 2.15, colW: [2.1, 2.2, 2.2, 2.5], rowH: 0.4, fontSize: 12, blankCorner: false });
    chip(s, 0.5, 4.35, 3.6, 0.6, "Un riferimento per ogni cella, da affiancare all'originale", { fill: C.accent6, fontSize: 11 });
    chip(s, 4.25, 4.35, 2.55, 0.6, "Vuoti dichiarati, non dedotti", { fill: C.accent6, fontSize: 11 });
    chip(s, 6.95, 4.35, 2.55, 0.6, "Valori resi comparabili", { fill: C.accent6, fontSize: 11 });
  }
  {
    const s = content("Contraddizioni e lacune", "Il confronto tra documenti collegati serve a trovare due tipi di problemi, e qui l'AI è particolarmente utile, perché richiedono di tenere a mente molti dettagli e incrociarli, attività in cui l'attenzione umana cala rapidamente. Le contraddizioni: due documenti, o due parti dello stesso documento, che dicono cose incompatibili. Una procedura che prevede un'approvazione in due giorni, mentre il regolamento ne prevede cinque. Un'offerta che indica una garanzia di 24 mesi nella premessa e di 12 nelle condizioni generali. Un verbale che attribuisce un'attività a un reparto diverso da quello del piano di progetto. Le informazioni mancanti: elementi richiesti da un documento e assenti nell'altro. Un capitolato che chiede certificazioni, piano di manutenzione e referenze, e un'offerta che risponde solo sulle prime due. Due accorgimenti per risultati migliori. Le lacune si trovano meglio se il sistema sa che cosa cercare: conviene fornire esplicitamente l'elenco dei requisiti da controllare, come visto nel Tema 7 per le omissioni. E ogni contraddizione segnalata va verificata sui due passaggi indicati, perché il sistema può segnalare anche false contraddizioni, dovute a una lettura imprecisa.");
    modeTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.7, { icon: "FiXCircle", head: "Contraddizioni", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Procedura: approvazione in 2 giorni; regolamento: 5", "Offerta: garanzia 24 mesi in premessa, 12 nelle condizioni", "Attività attribuita a reparti diversi"], { space: 5 }) });
    await card(s, 5.15, 1.2, 4.35, 2.7, { icon: "FiMinusCircle", head: "Informazioni mancanti", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Capitolato: certificazioni, manutenzione, referenze; offerta: solo le prime due", "Caso previsto dal regolamento, non disciplinato dalla procedura"], { space: 5 }) });
    const c = [["Per le lacune: l'elenco dei requisiti", "L'AI trova meglio ciò che manca se sa che cosa cercare"], ["Per le contraddizioni: i due passaggi", "Ogni segnalazione si verifica affiancando i testi"]];
    c.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 4.05, 4.35, 0.9, C.text1, e[0]);
      txt(s, e[0], { x: x + 0.2, y: 4.1, w: 3.95, h: 0.38, fontSize: 13, bold: true, color: C.accent6 });
      txt(s, e[1], { x: x + 0.2, y: 4.47, w: 3.95, h: 0.4, fontSize: 12, color: C.background1 });
    });
  }
  keySlide("Un confronto documentale è utile se individua differenze rilevanti, ne distingue la natura e permette di verificarle nelle fonti.", "Sottotema 8.5  ·  Confronto e analisi di più documenti", "Concetto chiave del sottotema 8.5. L'AI rende molto più rapido il confronto tra versioni, tra documenti alternativi e tra documenti collegati: identifica modifiche, costruisce matrici comparative, trova contraddizioni e lacune, a supporto di decisioni concrete come accettare un contratto o scegliere un fornitore. Il valore del confronto dipende da tre condizioni: individuare le differenze rilevanti, non tutte con lo stesso peso; distinguerne la natura, formale o sostanziale, con attenzione a quelle che sembrano formali; permettere di verificarle nelle fonti, con riferimenti ai passaggi di ciascun documento. Esercizio suggerito: preparare due versioni fittizie di un breve accordo, con alcune modifiche formali e due o tre sostanziali, di cui una mascherata da modifica formale, e chiedere ai partecipanti di confrontarle con l'AI e con il confronto tradizionale, valutando che cosa trova ciascun metodo.");

  // =====================================================================
  section("8.6 Ricerca");
  divider("8.6", "Ricerca, approfondimento e organizzazione", "L'AI accelera l'esplorazione di un argomento, la ricerca delle fonti e l'organizzazione delle conoscenze; l'attendibilità si valuta sulle fonti", "Passiamo alla quarta modalità: recuperare conoscenza. In questo sottotema, da comprendere, guardiamo all'AI come supporto alla ricerca informativa e all'approfondimento di argomenti: orientarsi su un tema nuovo, trovare fonti, organizzare ciò che si è raccolto, preparare dossier. È un uso molto diffuso, che cambia il modo di cercare informazioni rispetto ai motori di ricerca tradizionali. La distinzione centrale del sottotema è tra la conoscenza incorporata nel modello e le informazioni recuperate da fonti esterne con strumenti come la ricerca web; e tra ricerca assistita e verifica delle fonti. Il metodo generale di verifica è nel Tema 7: qui ci concentriamo su come l'AI sostiene la ricerca e su come valutarne i risultati.");
  {
    const s = content("L'AI nel lavoro di ricerca", "L'AI può intervenire in tutte le fasi del lavoro di ricerca e approfondimento. Orientarsi: capire rapidamente i concetti di base di un argomento nuovo, il lessico, le questioni principali, le domande giuste da porsi. Trovare fonti: suggerire tipi di fonti, enti di riferimento, documenti normativi, parole chiave; con gli strumenti dotati di ricerca web, trovare e citare pagine specifiche. Approfondire: esplorare un aspetto, chiedere spiegazioni, esempi, collegamenti. Organizzare: raggruppare le informazioni raccolte per tema, individuare sovrapposizioni e lacune, costruire uno schema. Produrre: preparare un dossier, una sintesi tematica, una nota di aggiornamento. Il valore principale è la velocità di orientamento: in pochi minuti si passa da 'non so nulla di questo argomento' a 'so che cosa cercare e dove', con una base organizzata da cui approfondire. Alcune funzioni di ricerca approfondita svolgono molte ricerche in sequenza e producono rapporti estesi con molte fonti: sono molto utili per un primo quadro, e le fonti che citano si valutano come qualsiasi altra fonte, come vedremo tra poco.");
    modeTag(s, 3);
    const ph = [["FiCompass", "Orientarsi", "Concetti, lessico, domande giuste"], ["FiSearch", "Trovare fonti", "Tipi di fonti, enti, parole chiave, pagine"], ["FiZoomIn", "Approfondire", "Spiegazioni, esempi, collegamenti"], ["FiFolder", "Organizzare", "Temi, sovrapposizioni, lacune"], ["FiFileText", "Produrre", "Dossier, sintesi tematiche, note"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.2, 1.66, 2.4, i % 2 ? C.accent6 : C.background2, ph[i][1]);
      await iconCircle(s, x + 0.53, 1.35, 0.6, ph[i][0]);
      txt(s, ph[i][1], { x: x + 0.08, y: 2.05, w: 1.5, h: 0.4, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, ph[i][2], { x: x + 0.1, y: 2.5, w: 1.46, h: 1.0, fontSize: 11, color: C.text2, align: "center" });
      if (i < 4) arrow(s, x + 1.665, 2.2, 0.17);
    }
    banner(s, 3.85, "Il valore: dalla domanda 'che cosa so?' a 'che cosa cercare e dove' in pochi minuti, con una base organizzata da cui approfondire.", { h: 0.95, fontSize: 13 });
  }
  {
    const s = content("Incorporata o recuperata?", "Una distinzione fondamentale, introdotta nel Tema 2 e qui ripresa per le sue conseguenze pratiche. La conoscenza incorporata nel modello è ciò che il modello ha appreso durante l'addestramento: è vasta e molto utile per concetti, spiegazioni e orientamento, ma è aggiornata fino a una data limite, non ha fonti precise da citare e, quando un'informazione manca, il sistema tende a ricostruire risposte plausibili. Le informazioni recuperate sono quelle che il sistema ottiene durante la conversazione tramite strumenti esterni: una ricerca web, i documenti caricati, una base documentale aziendale. Sono adatte a fatti recenti, dati, norme e prezzi, e possono essere citate; ma non sono automaticamente aggiornate né corrette: dipendono dalle fonti trovate, dalla loro data e dalla correttezza con cui lo strumento le legge e le riporta. Una pagina trovata dalla ricerca può essere vecchia, e non tutti gli strumenti indicano chiaramente le fonti. In pratica, la domanda da porsi davanti a una risposta è: da dove viene questa informazione? Se lo strumento indica le fonti consultate, si possono controllare data e contenuto. Se non le indica, la risposta viene probabilmente dalla conoscenza incorporata, e va trattata con più cautela per fatti recenti, dati specifici, norme, prezzi, persone. Molti strumenti combinano le due cose nella stessa risposta, e non sempre distinguono quale parte viene da dove.");
    modeTag(s, 3);
    table(s, [["", "Conoscenza incorporata", "Informazioni recuperate"],
      ["Origine", "Addestramento del modello", "Ricerca web, documenti, basi documentali"],
      ["Utile per", "Concetti, spiegazioni, orientamento", "Fatti recenti, dati, norme, prezzi"],
      ["Aggiornamento", "Fino a una data limite", "Dipende dalle fonti trovate e dalla loro data"],
      ["Fonti", "Non citabili con precisione", "Citabili, quando lo strumento le indica"],
      ["Rischio tipico", "Ricostruzioni plausibili ma errate", "Fonti scadenti o datate, lettura imprecisa"]],
      { y: 1.15, colW: [2.0, 3.4, 3.6], rowH: 0.44, fontSize: 12, accentCol: 2 });
    banner(s, 4.0, "La domanda da porsi: da dove viene questa informazione? Le fonti indicate permettono di controllarne data e contenuto.", { h: 0.85, fontSize: 13 });
  }
  {
    const s = content("Valutare e verificare le fonti", "Due requisiti delle informazioni trovate, che si valutano sulle fonti. L'attualità: un'informazione corretta un anno fa può non esserlo oggi, in particolare per norme e scadenze, prezzi e tariffe, ruoli, prodotti e versioni, dati di mercato. Conviene controllare la data della fonte e, per le informazioni sensibili al tempo, chiedere esplicitamente la versione più recente. L'attendibilità: chi ha prodotto l'informazione, con quali competenze e quali interessi? I criteri sono quelli visti nel Tema 7. Nella ricerca assistita c'è un aspetto specifico: il sistema seleziona e sintetizza le fonti con criteri non sempre trasparenti, e può dare lo stesso peso a una fonte istituzionale e a un blog, o presentare come consolidata una posizione che compare in poche fonti; per questo conviene chiedere di privilegiare fonti primarie e istituzionali. La ricerca assistita non è di per sé una verifica: il sistema ha trovato fonti ritenute pertinenti e ne ha riportato il contenuto. Per le informazioni che contano, la verifica ha tre passaggi: la fonte esiste ed è pertinente; sostiene davvero l'affermazione, con le stesse condizioni; è attuale rispetto all'uso. La ricerca assistita sposta il lavoro, non lo elimina: riduce molto il tempo per trovare il materiale e lascia più tempo per valutarlo. Il rischio da evitare è che la comodità di una risposta già accompagnata da fonti faccia saltare proprio questo passaggio.");
    modeTag(s, 3);
    await card(s, 0.5, 1.15, 4.35, 2.4, { icon: "FiClock", head: "Attualità", headSize: 16, bodySize: 12,
      body: bullets(["Norme, prezzi, ruoli e versioni cambiano", "Controllare la data della fonte", "Chiedere la versione più recente"], { space: 4 }) });
    await card(s, 5.15, 1.15, 4.35, 2.4, { icon: "FiShield", head: "Attendibilità", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Chi l'ha prodotta, con quali interessi", "Chiedere fonti primarie e istituzionali", "Molte fonti citate non sono una verifica"], { space: 4 }) });
    txt(s, "Verificare una fonte che conta:", { x: 0.5, y: 3.72, w: 2.6, h: 0.5, fontSize: 12, bold: true, color: C.text1, valign: "middle" });
    chip(s, 3.1, 3.72, 2.0, 0.5, "Esiste ed è pertinente", { fill: C.background2, fontSize: 11 });
    chip(s, 5.2, 3.72, 2.3, 0.5, "Sostiene l'affermazione", { fill: C.background2, fontSize: 11 });
    chip(s, 7.6, 3.72, 1.9, 0.5, "È attuale per l'uso", { fill: C.background2, fontSize: 11 });
    banner(s, 4.4, "La ricerca assistita riduce il tempo per trovare il materiale e lascia più tempo per valutarlo.", { h: 0.58, fontSize: 13 });
  }
  {
    const s = content("Organizzare dossier e prospettive", "Una volta raccolte le informazioni, l'AI è molto utile per organizzarle. Raggruppare per tema: da trenta appunti e documenti sparsi a una struttura per argomenti. Individuare sovrapposizioni, contraddizioni e lacune, applicando quanto visto nell'8.5. Preparare un dossier su un fornitore, un mercato o una normativa, in vista di una riunione o di una decisione, oppure note di aggiornamento periodiche. Il modo più affidabile è separare le fasi: prima raccogliere le fonti e valutarne attendibilità e attualità; poi fornire al sistema il materiale raccolto e chiedergli di organizzarlo, citando le fonti per ogni punto; infine rivedere coerenza, lacune e punti incerti. Così il dossier si basa su fonti scelte e controllate, e non sulla conoscenza incorporata del modello. Un buon dossier dichiara le sue fonti, la data a cui è aggiornato e i punti che restano incerti. Un uso prezioso, a destra, è il confronto tra prospettive: su argomenti complessi o dibattuti, il sistema aiuta a mappare posizioni diverse, a capire su che cosa concordano e divergono e su quali assunzioni si basano. È un modo efficace per non fermarsi alla prima fonte, una forma del bias di conferma vista nel Tema 7. Due accorgimenti: porre domande neutre, perché chiedere 'quali sono i vantaggi di' produce un quadro diverso da 'quali sono le valutazioni su'; e risalire alle fonti delle posizioni più rilevanti per la decisione, perché il quadro prodotto può dare lo stesso peso a posizioni maggioritarie e minoritarie, o semplificarle.");
    modeTag(s, 3);
    const st = [["1", "Raccogliere", "Fonti scelte e valutate"], ["2", "Organizzare", "Il materiale fornito, con le fonti"], ["3", "Rivedere", "Coerenza, lacune, punti incerti"]];
    st.forEach((e, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 1.15, 2.86, 1.3, i === 1 ? C.accent6 : C.background2, e[1]);
      txt(s, e[0], { x: x + 0.2, y: 1.2, w: 0.5, h: 0.5, fontSize: 24, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.7, y: 1.25, w: 2.0, h: 0.42, fontSize: 16, bold: true, color: C.text1, valign: "middle" });
      txt(s, e[2], { x: x + 0.2, y: 1.8, w: 2.5, h: 0.55, fontSize: 12, color: C.text2 });
      if (i < 2) arrow(s, x + 2.88, 1.65, 0.17);
    });
    shapeBox(s, 0.5, 2.65, 4.35, 2.3, C.text1, "buon dossier");
    txt(s, "Un buon dossier dichiara", { x: 0.7, y: 2.75, w: 4.0, h: 0.38, fontSize: 15, bold: true, color: C.accent6 });
    ["Le sue fonti", "La data di aggiornamento", "I punti incerti"].forEach((t, i) => chip(s, 0.7, 3.2 + i * 0.55, 3.95, 0.45, t, { fill: C.accent1, color: C.background1, fontSize: 13 }));
    await card(s, 5.15, 2.65, 4.35, 2.3, { icon: "FiGitBranch", inline: true, head: "Confrontare prospettive", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Mappare posizioni, concordanze, divergenze", "Non fermarsi alla prima fonte", "Domande neutre: 'valutazioni su', non 'vantaggi di'"], { space: 4 }) });
  }
  keySlide("L'AI può sostenere ricerca e organizzazione della conoscenza, senza rendere automaticamente attendibili le informazioni trovate o generate.", "Sottotema 8.6  ·  Ricerca, approfondimento e organizzazione", "Concetto chiave del sottotema 8.6. L'AI accelera molto l'orientamento su un argomento, la ricerca di fonti, l'approfondimento, l'organizzazione del materiale e la preparazione di dossier. Per usarla al meglio conviene distinguere la conoscenza incorporata nel modello dalle informazioni recuperate con strumenti esterni, valutare attualità e attendibilità delle fonti, porre domande neutre quando si confrontano prospettive, e ricordare che la ricerca assistita trova le fonti ma non le verifica. Esercizio suggerito: scegliere un argomento professionale con aspetti recenti, porre la stessa domanda a uno strumento senza ricerca web e a uno con ricerca web, e confrontare le risposte per attualità, fonti indicate e affermazioni verificabili.");

  // =====================================================================
  section("8.7 Conoscenza");
  divider("8.7", "AI e gestione della conoscenza", "L'AI rende interrogabile il patrimonio documentale e aiuta a organizzarlo; la qualità delle risposte dipende da qualità e aggiornamento dei documenti", "Ultimo sottotema del nucleo distintivo: la gestione della conoscenza. Mentre l'8.6 riguardava la ricerca su fonti esterne, qui guardiamo al patrimonio documentale dell'organizzazione: procedure, manuali, contratti, documentazione tecnica, verbali, FAQ. Le aziende producono enormi quantità di documenti, ma spesso trovare la risposta giusta al momento giusto resta difficile. L'AI apre una possibilità nuova: interrogare una raccolta documentale in linguaggio naturale, come si farebbe con un collega esperto, e ottenere risposte collegate ai documenti. Una distinzione utile per il relatore: i dati sono elementi elementari, come un numero o un codice; le informazioni sono dati con un significato e un contesto; i documenti sono contenitori organizzati di informazioni; la conoscenza è la capacità di usare le informazioni per decidere e agire. In azienda la conoscenza è in parte nei documenti e in parte nelle persone: l'AI lavora su quella scritta. In questo sottotema, da comprendere nelle sue opportunità, vediamo gli assistenti sulla documentazione, come funzionano, un esempio di risposta con riferimenti e le condizioni che rendono un archivio davvero interrogabile. Gli aspetti tecnici, come l'architettura RAG vista nel Tema 2, restano solo accennati; la progettazione di questi sistemi in azienda appartiene al Tema 14.");
  {
    const s = content("Assistenti sulla documentazione", "Gli assistenti basati sulla documentazione permettono di interrogare in linguaggio naturale una raccolta definita di documenti. Le opportunità sono concrete. Un assistente sulle procedure interne risponde a domande come 'come si richiede un rimborso spese per una trasferta all'estero?'. Un assistente sulla documentazione tecnica aiuta il servizio di assistenza a trovare la soluzione a un problema descritto dal cliente. Un assistente sulle condizioni contrattuali aiuta il commerciale a rispondere su garanzie e tempi. Un assistente per l'inserimento dei nuovi colleghi raccoglie regole, contatti e prassi in un unico punto. Il valore è ridurre il tempo per trovare le informazioni, rendere accessibile la conoscenza anche a chi non sa dove cercare, e alleggerire le persone esperte dalle domande ripetitive. Molti strumenti di uso comune permettono già di creare piccoli assistenti su un insieme di documenti; le soluzioni aziendali su larga scala richiedono progettazione, integrazione e gestione dei permessi, temi del Tema 14. Gli assistenti e gli agenti che svolgono azioni sono invece nel Tema 11. Qui ci interessa che cosa possono offrire, e a quali condizioni.");
    modeTag(s, 3);
    await iconGrid(s, [
      { icon: "FiClipboard", head: "Procedure interne", body: "Come si richiede un rimborso per una trasferta all'estero?" },
      { icon: "FiTool", head: "Documentazione tecnica", body: "Soluzioni ai problemi descritti dai clienti" },
      { icon: "FiFileText", head: "Condizioni contrattuali", body: "Garanzie, tempi, condizioni per i commerciali" },
      { icon: "FiUserPlus", head: "Inserimento di nuovi colleghi", body: "Regole, contatti, prassi in un unico punto" },
    ], 2, { y: 1.15, H: 2.6, headSize: 14, bodySize: 12 });
    banner(s, 3.95, "Meno tempo per trovare le informazioni, conoscenza accessibile a chi non sa dove cercare, esperti alleggeriti dalle domande ripetitive.", { h: 0.6, fontSize: 12 });
    txt(s, "Molti strumenti permettono già di creare piccoli assistenti su un insieme definito di documenti.", { x: 0.5, y: 4.65, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Come funziona per chi la usa", "Senza entrare nell'architettura tecnica, è utile capire dal punto di vista dell'utilizzatore che cosa succede quando si interroga una raccolta documentale. Il funzionamento tipico, che nel Tema 2 abbiamo chiamato RAG, avviene in due passaggi. Primo, il recupero: a partire dalla domanda, il sistema cerca nella raccolta i passaggi più pertinenti. Secondo, la generazione: il modello produce una risposta basandosi su quei passaggi, e idealmente li cita. Questa descrizione spiega molti comportamenti che l'utente osserva, e suggerisce come ottenere risposte migliori. Se il recupero non trova il passaggio giusto, perché la domanda usa parole diverse dal documento, la risposta sarà incompleta: aiuta usare il lessico dei documenti. Se il recupero trova documenti superati, la risposta sarà superata: servono versioni gestite, e conviene controllare la data del documento citato. Se non trova nulla di pertinente, un buon sistema lo dice, ma alcuni rispondono con la conoscenza generale del modello: aiuta chiedere di rispondere solo sulla base dei documenti. Se la generazione riporta male un passaggio corretto, la risposta sarà sbagliata con una fonte giusta: per questo, per le risposte che contano, si apre il passaggio citato.");
    modeTag(s, 3);
    chip(s, 0.5, 1.3, 1.7, 0.8, "Domanda", { fill: C.background2, fontSize: 14 });
    arrow(s, 2.3, 1.54, 0.35);
    shapeBox(s, 2.75, 1.15, 2.6, 1.1, C.accent6, "recupero");
    txt(s, "1. Recupero", { x: 2.9, y: 1.22, w: 2.3, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Cerca i passaggi più pertinenti nella raccolta", { x: 2.9, y: 1.58, w: 2.3, h: 0.6, fontSize: 11, color: C.text1 });
    arrow(s, 5.45, 1.54, 0.35);
    shapeBox(s, 5.9, 1.15, 2.6, 1.1, C.accent1, "generazione");
    txt(s, "2. Generazione", { x: 6.05, y: 1.22, w: 2.3, h: 0.35, fontSize: 14, bold: true, color: C.background1 });
    txt(s, "Risponde sulla base dei passaggi, e li cita", { x: 6.05, y: 1.58, w: 2.3, h: 0.6, fontSize: 11, color: C.background1 });
    table(s, [["Se succede che", "L'utente vede", "Che cosa aiuta"],
      ["Il recupero manca il passaggio", "Risposta incompleta", "Usare il lessico dei documenti"],
      ["Trova documenti superati", "Risposta superata", "Versioni gestite, data controllata"],
      ["Non trova nulla di pertinente", "Risposta generica", "Chiedere di usare solo i documenti"],
      ["La generazione riporta male", "Errore con fonte giusta", "Aprire il passaggio citato"]],
      { y: 2.45, colW: [3.0, 2.6, 3.4], rowH: 0.42, fontSize: 12, blankCorner: false, accentCol: 2 });
  }
  {
    const s = content("Dalle procedure alle risposte", "Un esempio completo, con dati fittizi, di risposta collegata ai documenti. A sinistra, la raccolta su cui lavora l'assistente: alcune procedure e regolamenti amministrativi. Al centro, la domanda di un collega, la risposta e il riferimento: documento, versione, data, sezione e passaggio. In pochi secondi il collega ha la risposta, senza cercare il file giusto tra decine di cartelle. Il riferimento permette tre cose. Verificare rapidamente che la risposta corrisponda a ciò che dice il documento. Controllare che il documento sia quello giusto e aggiornato: qui la versione 3.2 di gennaio. Leggere il contesto del passaggio, che spesso contiene condizioni ed eccezioni: in questo caso la possibilità di presentare note intermedie per le trasferte lunghe, che la risposta non riporta. Una risposta senza riferimenti, invece, non permette di distinguere un'informazione tratta dalla documentazione aziendale da un'informazione generica prodotta dal modello. Per chi valuta o sceglie uno strumento di questo tipo, la presenza di riferimenti precisi e cliccabili è un requisito importante. Per chi lo usa, la buona pratica è aprire il riferimento quando la risposta servirà per una decisione o un'azione con conseguenze.");
    modeTag(s, 3);
    shapeBox(s, 0.5, 1.15, 2.3, 2.95, C.background2, "raccolta");
    colLabel(s, 0.68, 1.25, 2.0, "Raccolta (fittizia)");
    ["Procedura rimborsi spese v. 3.2", "Regolamento trasferte", "Policy acquisti v. 1.4", "FAQ amministrazione"].forEach((t, i) => {
      chip(s, 0.68, 1.62 + i * 0.6, 1.95, 0.5, t, { fill: i === 0 ? C.accent6 : C.background1, fontSize: 10 });
    });
    arrow(s, 2.85, 2.45, 0.22);
    shapeBox(s, 3.12, 1.15, 4.1, 2.95, C.background2, "risposta assistente");
    txt(s, "Domanda: entro quando va presentata la nota spese?", { x: 3.3, y: 1.23, w: 3.8, h: 0.42, fontSize: 12, bold: true, color: C.text1 });
    txt(s, "Entro 30 giorni dalla fine della trasferta, allegando i giustificativi in originale.", { x: 3.3, y: 1.68, w: 3.8, h: 0.6, fontSize: 12, color: C.text1 });
    docBox(s, 3.3, 2.35, 3.75, 1.62, "Procedura rimborsi spese, v. 3.2 (gennaio), §4.1", "\"Le note spese devono essere presentate entro 30 giorni dalla conclusione della trasferta. Per le trasferte superiori a 15 giorni è ammessa la presentazione di note intermedie.\"", { fill: C.background1, fontSize: 10.5 });
    await card(s, 7.4, 1.15, 2.1, 2.95, { icon: "FiLink", head: "Con il riferimento", headSize: 13, bodySize: 11, fill: C.accent6,
      body: bullets(["Si verifica la risposta", "Si controllano versione e data", "Si legge il contesto: qui c'è un'eccezione"], { space: 4 }) });
    banner(s, 4.28, "Documento, versione e passaggio distinguono la documentazione aziendale dalla conoscenza generica del modello.", { h: 0.68, fontSize: 13 });
  }
  {
    const s = content("Archivio e conoscenza interrogabile", "Possedere un archivio di documenti e poterlo interrogare in modo affidabile sono due cose diverse, ma la distanza tra le due si può ridurre, anche con l'aiuto dell'AI. Un archivio documentale è una raccolta di file, organizzata per cartelle o in un sistema di gestione: si cerca un documento, lo si apre, lo si legge. La conoscenza interrogabile è una raccolta su cui si pone una domanda e si ottiene una risposta corretta, basata sui documenti pertinenti e collegata ad essi. L'AI rende più accessibili anche archivi imperfetti, perché la ricerca per significato trova documenti che la ricerca per parole chiave non troverebbe, e aiuta a metterli in ordine: classificare i documenti, proporre titoli, sezioni e metadati, segnalare duplicati e versioni in conflitto. La qualità delle risposte resta però legata alla qualità di ciò che c'è nella raccolta. Sul lato dei documenti: contenuti corretti e coerenti, struttura chiara, informazioni esplicite, perché ciò che è solo nella testa delle persone non può essere recuperato. Sul lato della raccolta: un perimetro chiaro, versioni gestite, permessi coerenti, perché ciascuno dovrebbe poter interrogare solo ciò che è autorizzato a vedere. Sul lato dell'uso: domande che usino il lessico dei documenti e controllo dei riferimenti per le risposte con conseguenze. Spesso l'introduzione di un assistente rende visibili problemi di organizzazione che esistevano già, ed è un'occasione per risolverli.");
    modeTag(s, 3);
    shapeBox(s, 0.5, 1.15, 2.6, 1.45, C.background2, "archivio");
    await iconCircle(s, 0.7, 1.3, 0.55, "FiArchive", C.accent2);
    txt(s, "Archivio", { x: 1.35, y: 1.32, w: 1.7, h: 0.5, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
    txt(s, "Si cerca un file, lo si apre, lo si legge", { x: 0.7, y: 1.95, w: 2.3, h: 0.6, fontSize: 11, color: C.text2 });
    arrow(s, 3.2, 1.7, 0.35);
    shapeBox(s, 3.65, 1.15, 2.6, 1.45, C.accent1, "interrogabile");
    await iconCircle(s, 3.85, 1.3, 0.55, "FiMessageCircle", C.background1, HEX.a1);
    txt(s, "Conoscenza interrogabile", { x: 4.5, y: 1.25, w: 1.7, h: 0.65, fontSize: 13, bold: true, color: C.background1, valign: "middle" });
    txt(s, "Una domanda, una risposta collegata ai documenti", { x: 3.85, y: 1.95, w: 2.3, h: 0.6, fontSize: 11, color: C.background1 });
    shapeBox(s, 6.45, 1.15, 3.05, 1.45, C.accent6, "l'AI aiuta a organizzare");
    txt(s, "L'AI aiuta anche a organizzare", { x: 6.62, y: 1.22, w: 2.75, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
    txt(s, "Classificare, proporre titoli e metadati, segnalare duplicati e versioni in conflitto", { x: 6.62, y: 1.56, w: 2.75, h: 0.95, fontSize: 11, color: C.text1 });
    const cd = [["Documenti", "Corretti, coerenti, con struttura chiara e informazioni esplicite"], ["Raccolta", "Perimetro chiaro, versioni gestite, permessi coerenti"], ["Uso", "Lessico dei documenti, controllo dei riferimenti"]];
    cd.forEach((c, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.8, 2.86, 1.35, i === 1 ? C.accent6 : C.background2, c[0]);
      txt(s, c[0], { x: x + 0.18, y: 2.88, w: 2.5, h: 0.34, fontSize: 14, bold: true, color: C.accent1 });
      txt(s, c[1], { x: x + 0.18, y: 3.25, w: 2.55, h: 0.85, fontSize: 12, color: C.text1 });
    });
    banner(s, 4.32, "Anche un archivio imperfetto diventa più accessibile; la qualità delle risposte cresce con qualità e aggiornamento dei documenti.", { h: 0.66, fontSize: 13 });
  }
  {
    const s = content("Aggiornamento e versionamento", "Un aspetto spesso sottovalutato della conoscenza interrogabile è il tempo. Le procedure cambiano, i listini si aggiornano, i contratti vengono rinnovati, le persone cambiano ruolo. Un archivio che contiene più versioni dello stesso documento, senza indicare quale è valida, è un problema già per una persona; per un sistema AI lo è di più, perché il recupero può trovare il passaggio della versione vecchia, magari perché è scritto in modo più simile alla domanda, e la risposta arriva con la stessa sicurezza. Il risultato è un'informazione superata con l'aspetto di un'informazione aggiornata e documentata. Alcune condizioni rendono la raccolta affidabile nel tempo. Chiarezza sulla versione valida: documenti superati rimossi o marcati come tali. Date e numeri di versione visibili nei documenti. Responsabilità definite per l'aggiornamento di ciascun documento. Riesami periodici della raccolta, in cui l'AI stessa può aiutare a individuare versioni in conflitto. Per l'utente, il comportamento pratico è controllare versione e data del documento citato, specialmente per regole, prezzi e scadenze. Le modalità con cui l'azienda gestisce questi processi appartengono al Tema 14.");
    modeTag(s, 3);
    docBox(s, 0.5, 1.15, 2.8, 1.3, "Procedura rimborsi v. 2.0", "Presentazione entro 60 giorni", { fill: C.background2, bar: C.accent2, labelColor: C.accent2 });
    docBox(s, 0.5, 2.6, 2.8, 1.3, "Procedura rimborsi v. 3.2", "Presentazione entro 30 giorni", { fill: C.accent6 });
    chip(s, 3.45, 1.55, 1.5, 0.5, "Superata", { fill: C.accent5, color: C.background1, fontSize: 12 });
    chip(s, 3.45, 3.0, 1.5, 0.5, "Valida", { fill: C.accent1, color: C.background1, fontSize: 12 });
    await card(s, 5.2, 1.15, 4.3, 2.75, { icon: "FiAlertTriangle", inline: true, head: "Se convivono senza indicazioni", headSize: 14, bodySize: 12, iconBg: C.accent5,
      body: "Il recupero può trovare la versione vecchia, e la risposta arriva con la stessa sicurezza: un'informazione superata con l'aspetto di un'informazione aggiornata." });
    const cd = ["Versione valida chiara", "Date e versioni visibili", "Responsabili dell'aggiornamento", "Riesami periodici"];
    cd.forEach((t, i) => chip(s, 0.5 + i * 2.3, 4.1, 2.15, 0.55, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Per l'utente: controllare versione e data del documento citato.", { x: 0.5, y: 4.72, w: 9, h: 0.3, fontSize: 12, italic: true, color: C.text2 });
  }
  keySlide("L'AI può rendere più accessibili le informazioni documentali e aiutare a organizzarle; l'affidabilità delle risposte dipende da qualità, aggiornamento e tracciabilità dei documenti.", "Sottotema 8.7  ·  AI e gestione della conoscenza", "Concetto chiave del sottotema 8.7. L'AI permette di interrogare raccolte documentali in linguaggio naturale, con assistenti sulle procedure, sulla documentazione tecnica, sulle condizioni contrattuali, e aiuta anche a organizzare archivi imperfetti. È una possibilità di grande valore. Il funzionamento in due passaggi, recupero e generazione, spiega perché le risposte migliorano con documenti chiari e aggiornati, versioni gestite e domande che usano il lessico dei documenti. Le risposte collegate ai documenti, con versione e passaggio, rendono l'accesso controllabile. Il documento di perimetro lo formula così: l'AI può agevolare l'accesso alle informazioni documentali, ma non risolve da sola i problemi di organizzazione e qualità della conoscenza. Esercizio suggerito: se in azienda è disponibile uno strumento autorizzato per creare un piccolo assistente su documenti, caricare alcune procedure fittizie, di cui una in due versioni contraddittorie, e osservare come risponde alle domande, verificando i riferimenti.");

  // =====================================================================
  section("8.8 Limiti");
  divider("8.8", "Limiti e condizioni di efficacia", "Le capacità di elaborazione variano per modello, strumento, formato e lunghezza: conoscerle permette di ottenere risultati più completi e di controllarli in modo proporzionato", "Ultimo sottotema, che attraversa tutte le modalità. Nei sottotemi precedenti abbiamo incontrato, al momento giusto, i punti di attenzione specifici: perdite di significato, riferimenti da controllare, campi incerti, versioni superate. Qui li guardiamo dal punto di vista delle condizioni di efficacia: da che cosa dipende il fatto che un'elaborazione documentale funzioni bene, e quali tecniche aiutano. Non ripetiamo la teoria generale delle allucinazioni e dell'affidabilità del Tema 3: ne consideriamo gli effetti sui documenti. E concludiamo con una guida pratica per decidere quanto controllare.");
  {
    const s = content("Dal caricamento all'elaborazione", "Quando carichiamo un file e otteniamo una risposta sicura e ben organizzata, tendiamo a pensare che il sistema abbia letto il documento come lo leggeremmo noi, tutto e con attenzione. Spesso è così, ma non è garantito: tra il caricamento e la comprensione ci sono più passaggi. Il file deve essere convertito in testo, e tabelle, immagini e scansioni possono essere lette in modo parziale. Il documento deve essere elaborato in tutte le sue parti: alcuni strumenti, con documenti molto grandi, ne usano solo i passaggi ritenuti pertinenti alla domanda, oppure lo elaborano a pezzi; e oltre il limite di contesto, visto nel Tema 2, il documento non può essere considerato tutto insieme. Infine, il contenuto deve essere interpretato correttamente. Le capacità su questi aspetti variano molto secondo il modello, lo strumento, il formato e la dimensione del documento, e migliorano di continuo. Uno studio pubblicato nel 2024 da Liu e colleghi, noto come 'lost in the middle', ha osservato che i modelli allora testati usavano meno le informazioni collocate al centro di testi lunghi rispetto a quelle all'inizio e alla fine; molti modelli successivi risultano migliorati, in misura diversa da sistema a sistema e da compito a compito, quindi il fenomeno va considerato una possibilità da controllare, non una regola. Quattro tecniche pratiche aiutano a ottenere una buona copertura. Elaborare per sezioni, con richieste distinte, e poi ricomporre. Usare la ricerca mirata, con domande su punti specifici, anche centrali. Verificare la copertura, per esempio con una sintesi per sezioni, che rende visibile se una parte manca. Recuperare i riferimenti, cioè passaggio e pagina, per i punti che contano.");
    modeTag(s, -1);
    const st = [["FiUpload", "Caricato", "Il file è accettato"], ["FiFileText", "Convertito", "Tabelle, immagini, scansioni lette?"], ["FiLayers", "Elaborato", "Tutte le parti considerate?"], ["FiCheckCircle", "Compreso", "Interpretato correttamente?"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.1, 1.3, i === 0 ? C.accent6 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.15, 1.27, 0.5, st[i][0], i === 0 ? C.accent1 : C.accent2);
      txt(s, st[i][1], { x: x + 0.72, y: 1.27, w: 1.33, h: 0.5, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, st[i][2], { x: x + 0.15, y: 1.85, w: 1.85, h: 0.55, fontSize: 11, color: C.text2 });
      if (i < 3) arrow(s, x + 2.11, 1.65, 0.17);
    }
    txt(s, "Le capacità variano secondo modello, strumento, formato e dimensione del documento", { x: 0.5, y: 2.55, w: 9, h: 0.32, fontSize: 12, italic: true, bold: true, color: C.accent1 });
    txt(s, "Tecniche per una buona copertura", { x: 0.5, y: 2.95, w: 9, h: 0.32, fontSize: 13, bold: true, color: C.text1 });
    const tc = [["Elaborare per sezioni", "Una richiesta per parte, poi ricomporre"], ["Ricerca mirata", "Domande su punti specifici, anche centrali"], ["Verificare la copertura", "Sintesi per sezioni: si vede se una manca"], ["Recuperare i riferimenti", "Passaggio e pagina per i punti che contano"]];
    tc.forEach((t, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 3.32, 2.15, 1.0, C.accent6, t[0]);
      txt(s, t[0], { x: x + 0.12, y: 3.37, w: 1.95, h: 0.34, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, t[1], { x: x + 0.12, y: 3.72, w: 1.95, h: 0.55, fontSize: 11, color: C.text1 });
    });
    txt(s, "Il calo di attenzione al centro dei testi lunghi, osservato nel 2024 (Liu et al.), è oggi variabile da sistema a sistema: va controllato, non dato per scontato.", { x: 0.5, y: 4.45, w: 9, h: 0.5, fontSize: 11, italic: true, color: C.text2 });
  }
  {
    const s = content("Qualità, struttura e formato", "La prima condizione di efficacia riguarda i documenti di partenza. Un principio noto dell'informatica dice: se entra spazzatura, esce spazzatura. Vale anche qui, con una particolarità: con l'AI, da documenti di scarsa qualità esce comunque un risultato ben scritto, quindi la qualità dei documenti va curata a monte. A sinistra, le caratteristiche dei documenti che funzionano meglio: contenuto corretto e coerente, perché errori e contraddizioni vengono riportati o risolti in silenzio scegliendo una delle versioni; struttura chiara, con titoli, sezioni, numerazione e un tema per paragrafo; linguaggio esplicito, perché riferimenti impliciti come 'come concordato' o 'la solita procedura' non sono interpretabili; formato digitale nativo, cioè un file prodotto da un programma di scrittura, più affidabile di una scansione. A destra, gli elementi di formato da tenere d'occhio e che cosa verificare. Le scansioni sono immagini: il testo va riconosciuto, con tecniche di riconoscimento ottico o con le capacità visive dei modelli multimodali, e un errore su una cifra cambia un importo. Scritture a mano e timbri possono essere letti male o ignorati. Le tabelle possono essere lette correttamente oppure appiattite, con valori sotto l'intestazione sbagliata. Immagini e grafici, a seconda dello strumento, possono essere ignorati o interpretati in modo impreciso. Testo su più colonne, note e riquadri possono essere letti nell'ordine sbagliato. Gli strumenti migliorano rapidamente su tutti questi aspetti, e i documenti che funzionano meglio per l'AI sono gli stessi che funzionano meglio per le persone: migliorarli è un investimento che vale doppio. La multimodalità in sé è nel Tema 10.");
    modeTag(s, -1);
    const q = [["Contenuto corretto e coerente", "Errori e contraddizioni vengono riportati"], ["Struttura chiara", "Titoli, sezioni, un tema per paragrafo"], ["Linguaggio esplicito", "Non 'come concordato', ma che cosa"], ["Formato digitale nativo", "Più affidabile di una scansione"]];
    q.forEach((e, i) => {
      const y = 1.15 + i * 0.75;
      shapeBox(s, 0.5, y, 4.1, 0.67, i % 2 ? C.background1 : C.background2, e[0]);
      txt(s, e[0], { x: 0.68, y: y + 0.05, w: 3.8, h: 0.3, fontSize: 12, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 0.68, y: y + 0.35, w: 3.8, h: 0.28, fontSize: 11, color: C.text2 });
    });
    table(s, [["Elemento", "Che cosa verificare"],
      ["Scansioni", "Importi, date, nomi nei punti critici"],
      ["Scritture a mano, timbri", "Se contengono informazioni rilevanti"],
      ["Tabelle", "Alcuni valori, riga per riga"],
      ["Immagini e grafici", "Se l'informazione è solo lì"],
      ["Colonne, note, riquadri", "L'ordine dei passaggi collegati"]],
      { x: 4.8, y: 1.15, w: 4.7, colW: [2.0, 2.7], rowH: 0.48, fontSize: 11, blankCorner: false });
    banner(s, 4.32, "I documenti che funzionano meglio per l'AI sono gli stessi che funzionano meglio per le persone: migliorarli vale doppio.", { h: 0.66, fontSize: 13 });
  }
  {
    const s = content("Linguaggio tecnico e significato", "Due ultimi aspetti, che attraversano tutte le modalità. Il primo è il linguaggio specialistico: documenti giuridici, tecnici, medici o finanziari usano termini con significati precisi, spesso diversi da quelli comuni, come 'risoluzione' in un contratto, 'tolleranza' in una specifica tecnica, 'competenza' in contabilità. I sistemi conoscono molti linguaggi specialistici, ma possono interpretare un termine nel senso comune o non conoscere il gergo e le sigle di un'azienda. Aiuta fornire un glossario; sui documenti specialistici con conseguenze serve la revisione di chi conosce la materia, come visto nel Tema 7. Il secondo riguarda il significato. Ridurre o trasformare un documento può introdurre tre tipi di scostamento. Le omissioni: elementi presenti nel documento e assenti nel risultato, come una condizione o un'eccezione. Le alterazioni: elementi presenti in entrambi, ma con un significato diverso, come un obbligo attenuato o un'incertezza diventata certezza. Le aggiunte: elementi presenti nel risultato e assenti nel documento, dedotti o inventati. Ciascuno si individua con una tecnica già vista nel modulo: l'elenco degli elementi da conservare per le omissioni, il confronto con l'originale sui punti critici per le alterazioni, un riferimento per ogni affermazione per le aggiunte. Per questo la tracciabilità, che abbiamo incontrato in quasi tutti i sottotemi, non è un dettaglio tecnico: è la condizione che rende possibile il controllo. Un'ultima nota sui riferimenti: i numeri di pagina sono i più fragili, perché la numerazione del documento può non coincidere con quella del file.");
    modeTag(s, -1);
    await card(s, 0.5, 1.15, 9.0, 1.3, { icon: "FiCpu", inline: true, head: "Linguaggio specialistico", headSize: 14, bodySize: 12,
      body: "'Risoluzione', 'tolleranza', 'competenza' hanno un significato tecnico preciso. Aiuta un glossario; sui testi specialistici serve chi conosce la materia." });
    const r = [["FiMinusCircle", "Omissioni", "Nel documento, non nel risultato", "elenco degli elementi da conservare"], ["FiShuffle", "Alterazioni", "In entrambi, con significato diverso", "confronto sui punti critici"], ["FiPlusCircle", "Aggiunte", "Nel risultato, non nel documento", "un riferimento per ogni affermazione"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 2.62, 2.86, 1.55, C.background2, r[i][1]);
      await iconCircle(s, x + 0.18, 2.72, 0.45, r[i][0], C.accent5);
      txt(s, r[i][1], { x: x + 0.75, y: 2.72, w: 2.0, h: 0.45, fontSize: 15, bold: true, color: C.text1, valign: "middle" });
      txt(s, r[i][2], { x: x + 0.18, y: 3.24, w: 2.55, h: 0.32, fontSize: 11, color: C.text2 });
      txt(s, [{ text: "Si trovano con: ", options: { bold: true, color: C.accent1 } }, { text: r[i][3], options: { color: C.text1 } }], { x: x + 0.18, y: 3.58, w: 2.55, h: 0.52, fontSize: 11 });
    }
    banner(s, 4.32, "La tracciabilità non è un dettaglio tecnico: è la condizione che rende possibile il controllo.", { h: 0.62, fontSize: 13 });
  }
  {
    const s = content("Quanto controllare: una guida", "Non ogni elaborazione richiede lo stesso controllo, e controllare tutto allo stesso modo toglierebbe all'AI gran parte del suo valore. La tabella propone una guida pratica in tre livelli. Il controllo leggero vale per orientarsi, per un uso personale o quando un eventuale errore è facile da correggere: basta una lettura critica del risultato, chiedendosi se è plausibile e se manca qualcosa di ovvio. Esempio: capire se vale la pena leggere un rapporto. Il controllo a campione vale per il lavoro interno, i risultati in serie e le bozze: si verificano i punti critici e una parte dei record, usando i riferimenti. Esempio: una tabella di lavoro estratta da duecento email. Il controllo approfondito vale per decisioni con conseguenze, testi destinati all'esterno o con valore legale, e ogni volta che il risultato sostituisce la lettura dell'originale: confronto sistematico con l'originale sugli elementi critici e, se serve, revisione di un esperto. Esempio: la risposta formale a un fornitore. Il livello non è fisso: dipende dal rischio, dal processo e dalle verifiche disponibili. Lo alzano documenti di qualità incerta, come scansioni o documenti lunghi e complessi, contenuti specialistici o con valore legale, l'assenza di riferimenti. Lo abbassano controlli già previsti dal processo, come una seconda approvazione o verifiche automatiche, e risultati facilmente reversibili. Il principio, sviluppato nel Tema 7, è che più il risultato sostituisce la lettura dell'originale, più deve essere controllato.");
    modeTag(s, -1);
    table(s, [["Livello", "Quando", "Che cosa fare", "Esempio"],
      ["Leggero", "Per orientarsi, uso personale, errore facile da correggere", "Lettura critica: è plausibile, manca qualcosa?", "Capire se leggere un rapporto"],
      ["A campione", "Lavoro interno, risultati in serie, bozze", "Punti critici e parte dei record, con i riferimenti", "Tabella da 200 email"],
      ["Approfondito", "Decisioni, testi all'esterno o con valore legale", "Confronto sistematico, esperto se serve", "Risposta formale a un fornitore"]],
      { y: 1.15, colW: [1.45, 2.85, 2.75, 1.95], rowH: 0.62, fontSize: 11, blankCorner: false, accentCol: 2 });
    txt(s, "Lo alzano", { x: 0.5, y: 3.85, w: 1.5, h: 0.48, fontSize: 13, bold: true, color: C.accent5, valign: "middle" });
    chip(s, 2.0, 3.85, 2.45, 0.48, "Scansioni, documenti lunghi", { fill: C.background2, fontSize: 11 });
    chip(s, 4.55, 3.85, 2.45, 0.48, "Testi specialistici o legali", { fill: C.background2, fontSize: 11 });
    chip(s, 7.1, 3.85, 2.4, 0.48, "Nessun riferimento", { fill: C.background2, fontSize: 11 });
    txt(s, "Lo abbassano", { x: 0.5, y: 4.45, w: 1.5, h: 0.48, fontSize: 13, bold: true, color: C.accent1, valign: "middle" });
    chip(s, 2.0, 4.45, 3.7, 0.48, "Controlli già previsti dal processo", { fill: C.accent6, fontSize: 11 });
    chip(s, 5.8, 4.45, 3.7, 0.48, "Risultato facilmente reversibile", { fill: C.accent6, fontSize: 11 });
  }
  keySlide("Poter caricare un documento non garantisce che il sistema ne abbia elaborato tutte le parti, interpretato correttamente il contenuto e preservato il significato.", "Sottotema 8.8  ·  Limiti e condizioni di efficacia", "Concetto chiave dell'ultimo sottotema. L'efficacia dell'elaborazione documentale dipende dal modello e dallo strumento, dalla qualità e dalla struttura dei documenti, dal formato, dalla lunghezza e dal linguaggio specialistico. Per ciascun aspetto esistono tecniche pratiche: elaborare per sezioni, usare la ricerca mirata, verificare la copertura, recuperare i riferimenti, fornire glossari. Omissioni, alterazioni e aggiunte si individuano con la tracciabilità, e il livello di controllo si sceglie in base a rischio, processo e verifiche disponibili. Esercizio suggerito: caricare in uno strumento autorizzato un documento fittizio con una tabella, una nota a piè di pagina e una sezione centrale contenente un'informazione chiave, e verificare con domande mirate che cosa il sistema ha effettivamente elaborato.");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i principali apprendimenti, uno per sottotema. Generazione: testi in meno tempo, se si forniscono materiale, destinatario ed esempi, con un livello di revisione proporzionato al rischio. Trasformazione: correggere, semplificare, tradurre e riorganizzare testi esistenti, dicendo che cosa non deve cambiare. Sintesi: sintesi mirate allo scopo, con i riferimenti ai passaggi originali e gli elementi decisivi conservati. Estrazione: da testi liberi a dati utilizzabili, con regole per i campi incerti e una validazione prima dell'uso. Confronto: matrici e confronti che mettono in evidenza le differenze rilevanti per decidere, verificabili nelle fonti. Ricerca: orientamento rapido, distinguendo la conoscenza del modello dalle fonti recuperate, che si valutano. Gestione della conoscenza: archivi interrogabili con risposte collegate ai documenti, la cui qualità dipende da qualità e aggiornamento della raccolta. Condizioni di efficacia: le capacità variano per strumento, formato e lunghezza; tecniche di copertura e controlli proporzionati a rischio, processo e uso. Suggerimento: chiedere ai partecipanti quale di questi usi sperimenteranno per primo nel proprio lavoro, e con quale documento.");
    const r = [["8.1", "Testi in meno tempo, con materiale, destinatario ed esempi giusti"], ["8.2", "Trasformare testi esistenti, dicendo che cosa non deve cambiare"], ["8.3", "Sintesi mirate allo scopo, con riferimenti alle fonti"], ["8.4", "Da testi liberi a dati utilizzabili, validati prima dell'uso"], ["8.5", "Confronti che evidenziano le differenze rilevanti per decidere"], ["8.6", "Ricerca rapida, distinguendo conoscenza del modello e fonti"], ["8.7", "Archivi interrogabili, con risposte collegate ai documenti"], ["8.8", "Tecniche di copertura e controlli proporzionati all'uso"]];
    r.forEach((t, i) => {
      const col = Math.floor(i / 4), row = i % 4;
      const x = 0.5 + col * 4.6, y = 1.15 + row * 0.93;
      shapeBox(s, x, y, 4.4, 0.82, row % 2 ? C.background1 : C.background2, "apprendimento " + t[0]);
      chip(s, x + 0.12, y + 0.2, 0.72, 0.42, t[0], { fill: C.accent1, color: C.background1, fontSize: 12 });
      txt(s, t[1], { x: x + 1.0, y, w: 3.3, h: 0.82, fontSize: 12, color: C.text1, valign: "middle" });
    });
  }
  {
    const s = content("Quattro modalità: una scheda pratica", "Traduciamo il modulo in una scheda pratica, organizzata per modalità. Produrre: fornire il materiale di partenza, indicare destinatario e tono, scegliere il livello di autonomia in base a rischio e processo. Trasformare: partire da materiale corretto, dichiarare le modifiche ammesse, confrontare con l'originale gli elementi che non devono cambiare. Analizzare e strutturare: dichiarare lo scopo della sintesi, chiedere riferimenti ai passaggi, definire campi e regole per i valori mancanti, classificare le differenze nei confronti, validare prima dell'uso. Recuperare conoscenza: chiedersi da dove viene l'informazione, valutare attualità e attendibilità, aprire i riferimenti, controllare versione e data dei documenti. E per tutte le modalità: caricare i documenti solo negli strumenti autorizzati dall'azienda; usare le tecniche di copertura per documenti lunghi e complessi; proporzionare i controlli all'uso. Il messaggio centrale del tema: l'AI può trasformare il lavoro su testi, documenti e conoscenza, a condizione di non confondere un'elaborazione convincente con un'elaborazione completa e verificata.");
    const f = [["Produrre", ["Materiale di partenza", "Destinatario e tono", "Autonomia secondo il rischio"], C.background2], ["Trasformare", ["Partire da materiale corretto", "Modifiche ammesse dichiarate", "Confronto con l'originale"], C.accent6], ["Analizzare", ["Scopo e riferimenti", "Campi e regole per i mancanti", "Differenze classificate, validazione"], C.background2], ["Recuperare", ["Da dove viene?", "Attualità e attendibilità", "Riferimenti, versione e data"], C.accent6]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.15, 2.15, 2.95, f[i][2], f[i][0]);
      txt(s, f[i][0], { x: x + 0.15, y: 1.25, w: 1.9, h: 0.42, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, bullets(f[i][1], { space: 6 }), { x: x + 0.15, y: 1.75, w: 1.92, h: 2.25, fontSize: 12, color: C.text1 });
    }
    banner(s, 4.3, "Sempre: strumenti autorizzati, tecniche di copertura per i documenti complessi, controlli proporzionati all'uso.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa viene dopo", "Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto. Con il Tema 8 si apre l'area 'Esplorare le possibilità dell'AI', che guarda a che cosa si può fare concretamente con l'AI nei diversi ambiti di lavoro. Abbiamo iniziato dai testi, dai documenti e dalla conoscenza, perché è l'ambito più maturo e più trasversale. Il tema successivo, il Tema 9, è dedicato all'AI per dati e analisi: preparazione, elaborazione, analisi, interpretazione e rappresentazione dei dati. È il naturale proseguimento dell'8.4: abbiamo visto come trasformare testi in dati strutturati, ora vedremo come analizzarli. Nel percorso tornano poi l'AI multimodale, nel Tema 10; assistenti, agenti e automazioni, nel Tema 11, dove torneranno gli assistenti documentali e i flussi di estrazione automatica; AI, dati e conoscenza aziendale, nel Tema 14, dove si affronta la progettazione dei sistemi di conoscenza in azienda. In tutti questi temi resteranno validi i principi di questo modulo: fedeltà del significato, completezza, tracciabilità verso le fonti. Lasciare spazio alle domande finali.");
    shapeBox(s, 0.5, 1.2, 4.35, 3.75, C.background2, "aree");
    txt(s, "PERCORSO", { x: 0.75, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Comprendere l'AI", { x: 0.75, y: 1.72, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 1-4", { x: 0.75, y: 2.03, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Interagire con l'AI", { x: 0.75, y: 2.45, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.text1 });
    txt(s, "Temi 5-7", { x: 0.75, y: 2.76, w: 3.9, h: 0.3, fontSize: 12, color: C.text2 });
    txt(s, "Esplorare le possibilità dell'AI", { x: 0.75, y: 3.18, w: 3.9, h: 0.32, fontSize: 14, bold: true, color: C.accent1 });
    txt(s, "Tema 8: testi, documenti e conoscenza (completato)", { x: 0.75, y: 3.49, w: 3.9, h: 0.5, fontSize: 12, color: C.text2 });
    shapeBox(s, 5.15, 1.2, 4.35, 3.75, C.text1, "prossimi");
    txt(s, "PROSSIMO TEMA", { x: 5.4, y: 1.38, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Tema 9: AI per dati e analisi", { x: 5.4, y: 1.72, w: 3.9, h: 0.4, fontSize: 16, bold: true, color: C.background1 });
    txt(s, "Dal testo strutturato all'analisi dei dati", { x: 5.4, y: 2.1, w: 3.9, h: 0.3, fontSize: 12, italic: true, color: C.accent3 });
    txt(s, "NEL PERCORSO", { x: 5.4, y: 2.6, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, bullets(["Tema 10: AI multimodale", "Tema 11: assistenti, agenti e automazioni", "Tema 14: dati e conoscenza aziendale"], { space: 5 }), { x: 5.4, y: 2.95, w: 3.9, h: 1.6, fontSize: 13, color: C.background1 });
  }
  {
    const s = content("Fonti e riferimenti", "Le fonti citate nel modulo. Lo studio di Liu e colleghi, già presentato nel Tema 2, è citato nella slide 'Dal caricamento all'elaborazione' con la precisazione che il fenomeno osservato varia tra i sistemi attuali; il lavoro di Lewis e colleghi introduce l'architettura RAG, qui solo accennata e approfondita nel Tema 14. Il modulo si basa soprattutto sull'esperienza pratica dell'uso dell'AI su testi e documenti, che evolve rapidamente: le capacità degli strumenti nella gestione di documenti lunghi, tabelle e scansioni migliorano di continuo. Prima di ogni edizione è consigliabile verificare le funzionalità degli strumenti autorizzati in azienda, e aggiornare gli esempi di conseguenza. Tutti gli esempi usati nelle slide, compresi appunti, verbali, rapporti, email, offerte e procedure, sono fittizi.");
    const src = [
      "Liu, N. F. et al. (2024). Lost in the Middle: How Language Models Use Long Contexts. Transactions of the Association for Computational Linguistics, 12, 157-173.",
      "Lewis, P. et al. (2020). Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks. NeurIPS 2020.",
      "Gli esempi di appunti, verbali, rapporti, email, offerte e procedure presenti nelle slide sono fittizi.",
      "Fonti verificate a ottobre 2026: ricontrollarle prima di ogni edizione.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 10 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.3, fontSize: 13, color: C.text1 });
  }

  await pres.writeFile({ fileName: "Tema8_AI_testi_documenti_conoscenza_REV.pptx" });
  await applyTheme("Tema8_AI_testi_documenti_conoscenza_REV.pptx", THEME);
  console.log("done");
})();
