
  // =====================================================================
  section("9.3 Elaborazione");
  divider("9.3", "Elaborazione e analisi quantitativa", "Metodo, dati e passaggi di elaborazione sono determinanti per l'affidabilità di un risultato numerico", "Con i dati compresi e preparati, passiamo all'elaborazione: calcoli, aggregazioni, indicatori, confronti, statistiche descrittive. In questo sottotema, da comprendere e sperimentare, vediamo che cosa l'AI può calcolare e come, ma soprattutto affrontiamo l'integrazione più importante del tema: la differenza tra un calcolo effettivamente eseguito e un numero generato linguisticamente. È una distinzione che ogni utilizzatore dovrebbe conoscere, perché i due risultati hanno lo stesso aspetto ma un'affidabilità molto diversa. Nel Tema 7 abbiamo visto come verificare dati e calcoli in generale; qui guardiamo a come l'AI li produce.");
  {
    const s = content("Le operazioni tipiche", "Le operazioni quantitative più comuni nell'analisi aziendale sono poche, e l'AI può eseguirle tutte. I calcoli sulle righe: per ogni ordine, il margine come differenza tra prezzo e costo, l'importo con IVA, i giorni tra ordine e consegna. Le aggregazioni: somme, conteggi, medie, minimi e massimi su un insieme di righe, come il fatturato totale o il numero di ordini. I raggruppamenti: le stesse aggregazioni per categoria, come il fatturato per regione, per prodotto, per mese. È l'operazione che nei fogli di calcolo si fa con le tabelle pivot. Gli indicatori: percentuali, rapporti, variazioni, come la quota di una regione sul totale, il tasso di reso, la crescita rispetto all'anno precedente. I confronti: tra periodi, tra gruppi, tra categorie, rispetto a un obiettivo. Queste operazioni sono semplici dal punto di vista matematico, ma ciascuna richiede scelte: quali righe includere, come trattare i mancanti, rispetto a quale base calcolare una percentuale, quali periodi confrontare. Ed è nelle scelte, più che nell'aritmetica, che nascono gli errori più frequenti.");
    phaseTag(s, 1);
    await iconGrid(s, [
      { icon: "FiHash", head: "Calcoli sulle righe", body: "Margine, importo con IVA, giorni di consegna" },
      { icon: "FiPlusSquare", head: "Aggregazioni", body: "Somme, conteggi, medie, minimi, massimi" },
      { icon: "FiLayers", head: "Raggruppamenti", body: "Per regione, prodotto, mese: le tabelle pivot" },
      { icon: "FiPercent", head: "Indicatori", body: "Quote, tassi, rapporti, variazioni" },
      { icon: "FiColumns", head: "Confronti", body: "Tra periodi, gruppi, categorie, obiettivi" },
      { icon: "FiHelpCircle", head: "Scelte", body: "Quali righe, quali mancanti, quale base, quali periodi" , fill: C.accent6},
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Matematicamente semplici. Gli errori nascono più nelle scelte che nell'aritmetica.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Percentuali, rapporti, variazioni", "Gli indicatori relativi sono i più usati e anche i più fraintesi. Nel Tema 7 abbiamo visto la differenza tra punti percentuali e variazioni relative. Qui aggiungiamo tre attenzioni specifiche per l'analisi assistita. La base della percentuale: 'il 30 per cento dei reclami riguarda le consegne' e 'il 30 per cento delle consegne genera reclami' sono affermazioni molto diverse, ma una richiesta vaga può produrre l'una o l'altra. Bisogna sempre chiedersi: percentuale di che cosa? Le variazioni su basi piccole: passare da 2 a 6 reclami è un aumento del 200 per cento, che sembra allarmante ma riguarda quattro casi. Conviene sempre affiancare la variazione percentuale ai valori assoluti. Il periodo di confronto: una crescita rispetto al mese precedente può essere stagionale; rispetto allo stesso mese dell'anno precedente è più significativa. E il periodo scelto può cambiare la conclusione: rispetto all'anno scorso siamo in crescita, rispetto a due anni fa in calo. Quando l'AI produce un indicatore, conviene controllare la formula usata, la base e il periodo di confronto, e chiedere sempre anche i valori assoluti.");
    phaseTag(s, 1);
    const at = [["Percentuale di che cosa?", "'30% dei reclami riguarda le consegne' non è '30% delle consegne genera reclami'"], ["Basi piccole", "Da 2 a 6 reclami: +200%, ma sono quattro casi. Affiancare i valori assoluti"], ["Periodo di confronto", "Sul mese precedente: stagionalità. Sull'anno precedente: più significativo"]];
    at.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 0.5, y, 9.0, 0.85, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 0.7, y, w: 2.9, h: 0.85, fontSize: 14, bold: true, color: C.accent1, valign: "middle" });
      txt(s, e[1], { x: 3.6, y, w: 5.7, h: 0.85, fontSize: 12, color: C.text1, valign: "middle" });
    });
    banner(s, 4.1, "Controllare formula, base e periodo, e chiedere sempre anche i valori assoluti.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Statistiche descrittive di base", "L'analisi descrittiva riassume i dati con poche misure. Le principali, che conviene conoscere anche senza essere statistici, sono di due tipi. Misure di posizione: la media, cioè la somma divisa per il numero dei valori; la mediana, cioè il valore centrale, che divide i dati a metà. Misure di dispersione: il minimo e il massimo, la deviazione standard, che indica quanto i valori si allontanano in media dalla media. Il grafico in slide mostra un esempio fittizio: il valore degli ordini di dieci clienti. Nove clienti hanno ordini tra 1.000 e 2.000 euro, uno ha un ordine da 20.000. La media è 3.310 euro, ma nessun cliente reale si avvicina a questo valore: è trascinata dal cliente grande. La mediana, 1.450 euro, descrive meglio il cliente tipico. Quando i dati sono asimmetrici, come spesso accade per importi, redditi, tempi, la media da sola è fuorviante. Se si chiede all'AI 'qual è il valore tipico degli ordini?', può rispondere con la media, perché è la misura più comune. Conviene chiedere sempre media e mediana insieme, e un'indicazione della dispersione: se media e mediana sono molto diverse, ci sono valori estremi che vanno guardati.");
    phaseTag(s, 1);
    s.addChart(pres.charts.BAR, [{ name: "Valore ordini (€)", labels: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "L"], values: [1100, 1200, 1300, 1400, 1400, 1500, 1600, 1700, 1900, 20000] }], {
      x: 0.5, y: 1.1, w: 5.4, h: 3.0, barDir: "col", chartColors: [HEX.a1], valAxisLabelColor: HEX.dk2, valAxisLabelFontSize: 9, catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 10,
      valGridLine: { color: HEX.a3, size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 21000, barGapWidthPct: 40,
      showTitle: true, title: "Valore degli ordini di dieci clienti (esempio fittizio)", titleFontSize: 11, titleColor: HEX.dk2, titleFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt", catAxisLabelFontFace: "+mn-lt",
    });
    shapeBox(s, 6.15, 1.15, 3.35, 1.3, C.background2, "media");
    txt(s, "Media", { x: 6.35, y: 1.22, w: 3.0, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    txt(s, "3.310 €", { x: 6.35, y: 1.55, w: 3.0, h: 0.45, fontSize: 24, bold: true, color: C.text1 });
    txt(s, "Nessun cliente reale vicino", { x: 6.35, y: 2.02, w: 3.0, h: 0.35, fontSize: 11, color: C.text2 });
    shapeBox(s, 6.15, 2.6, 3.35, 1.3, C.accent6, "mediana");
    txt(s, "Mediana", { x: 6.35, y: 2.67, w: 3.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1 });
    txt(s, "1.450 €", { x: 6.35, y: 3.0, w: 3.0, h: 0.45, fontSize: 24, bold: true, color: C.text1 });
    txt(s, "Descrive il cliente tipico", { x: 6.35, y: 3.47, w: 3.0, h: 0.35, fontSize: 11, color: C.text2 });
    banner(s, 4.3, "Chiedere sempre media e mediana insieme: se sono molto diverse, ci sono valori estremi da guardare.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Le statistiche non bastano", "Un esempio classico della statistica mostra perché le misure di sintesi, da sole, non bastano. Nel 1973 lo statistico Francis Anscombe costruì quattro piccoli insiemi di dati, oggi noti come quartetto di Anscombe. I quattro insiemi hanno praticamente le stesse statistiche: la stessa media di x, 9, la stessa media di y, 7,5, la stessa varianza, la stessa correlazione, circa 0,82, e la stessa retta di regressione. Ma, come mostrano i grafici, sono completamente diversi. Il primo è una relazione lineare con un po' di variabilità. Il secondo è una curva, non una retta. Il terzo è una relazione lineare perfetta con un solo valore anomalo che la altera. Il quarto non ha alcuna relazione: tutti i valori di x sono uguali tranne uno, che da solo crea la correlazione. La lezione per l'analisi assistita è diretta: se si chiede all'AI una sintesi statistica, si ottengono numeri corretti che possono nascondere situazioni molto diverse. Guardare i dati, con un grafico, è un controllo semplice e potente, che conviene chiedere sempre prima di trarre conclusioni da medie e correlazioni.");
    phaseTag(s, 1);
    const x = [10, 8, 13, 9, 11, 14, 6, 4, 12, 7, 5], x4 = [8, 8, 8, 8, 8, 8, 8, 19, 8, 8, 8];
    const ys = [[8.04, 6.95, 7.58, 8.81, 8.33, 9.96, 7.24, 4.26, 10.84, 4.82, 5.68], [9.14, 8.14, 8.74, 8.77, 9.26, 8.10, 6.13, 3.10, 9.13, 7.26, 4.74], [7.46, 6.77, 12.74, 7.11, 7.81, 8.84, 6.08, 5.39, 8.15, 6.42, 5.73], [6.58, 5.76, 7.71, 8.84, 8.47, 7.04, 5.25, 12.50, 5.56, 7.91, 6.89]];
    for (let i = 0; i < 4; i++) {
      scatter(s, i === 3 ? x4 : x, ys[i], { x: 0.5 + i * 2.27, y: 1.1, w: 2.2, h: 2.2, xmin: 2, xmax: 20, ymin: 2, ymax: 14, title: "Insieme " + (i + 1), size: 5 });
    }
    shapeBox(s, 0.5, 3.45, 9.0, 0.6, C.background2, "statistiche");
    txt(s, "Per tutti e quattro:  media x = 9   ·   media y = 7,5   ·   correlazione = 0,82   ·   stessa retta di regressione", { x: 0.7, y: 3.45, w: 8.6, h: 0.6, fontSize: 13, bold: true, color: C.text1, valign: "middle", align: "center" });
    banner(s, 4.2, "Numeri corretti possono nascondere situazioni molto diverse. Guardare i dati con un grafico, prima di concludere.", { h: 0.75, fontSize: 13 });
  }
  {
    const s = content("Formule e codice generati dall'AI", "L'AI può produrre risultati quantitativi in due modi molto diversi, e il primo è generare strumenti di calcolo: formule per i fogli di calcolo, codice in linguaggi come Python o SQL, che poi vengono eseguiti. È uno degli usi più utili per chi lavora con i dati: si descrive ciò che si vuole ottenere, per esempio 'una formula che calcoli i giorni lavorativi tra la data dell'ordine e la data di consegna', e si ottiene la formula pronta. Per chi non conosce i linguaggi, è una porta d'accesso a elaborazioni prima impossibili. Per chi li conosce, è un acceleratore. Il vantaggio fondamentale di questo approccio è che il calcolo viene eseguito da uno strumento deterministico, il foglio di calcolo o l'interprete del codice, e che la formula o il codice restano visibili e controllabili. Ma anche qui servono attenzioni. La formula può essere sintatticamente corretta e logicamente sbagliata: per esempio includere anche le righe di totale, o usare un intervallo che non copre tutti i dati. Conviene verificarla su pochi casi di cui si conosce il risultato, e chiedere al sistema di spiegarla passo per passo. La programmazione analitica complessa è solo da accennare: per chi vuole approfondire esistono percorsi specifici.");
    phaseTag(s, 1);
    docBox(s, 0.5, 1.15, 5.0, 1.0, "Richiesta", "Una formula che calcoli i giorni lavorativi tra la data dell'ordine (colonna B) e la data di consegna (colonna C).", { fontSize: 12 });
    promptBox(s, 0.5, 2.3, 5.0, 0.85, "=GIORNI.LAVORATIVI.TOT(B2;C2)", { label: "Formula generata", fontSize: 13 });
    await card(s, 5.75, 1.15, 3.75, 2.0, { icon: "FiCheckCircle", inline: true, head: "Il vantaggio", headSize: 14, bodySize: 12, fill: C.accent6,
      body: "Il calcolo lo esegue uno strumento deterministico, e la formula resta visibile e controllabile." });
    txt(s, "Ma una formula corretta nella forma può essere sbagliata nella logica", { x: 0.5, y: 3.3, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.accent5 });
    chip(s, 0.5, 3.7, 2.9, 0.55, "Include le righe di totale?", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 3.7, 2.9, 0.55, "L'intervallo copre tutti i dati?", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 3.7, 2.9, 0.55, "Considera le festività?", { fill: C.background2, fontSize: 12 });
    txt(s, "Verificarla su pochi casi di risultato noto, e chiederne la spiegazione passo per passo.", { x: 0.5, y: 4.45, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Calcolo eseguito o numero generato", "Questa è l'integrazione A del tema, e il concetto più importante del sottotema: un numero presente in una risposta non dimostra che sia stato eseguito un calcolo corretto. Come abbiamo visto nel Tema 2, un modello linguistico genera testo prevedendo una parola dopo l'altra. Quando produce un numero senza usare uno strumento di calcolo, quel numero è generato come qualsiasi altra parola: è plausibile, coerente con il contesto, spesso corretto per operazioni semplici, ma non è il risultato di un calcolo. Con molti dati, operazioni complesse o numeri grandi, gli errori diventano frequenti. E il numero generato ha esattamente lo stesso aspetto di un numero calcolato: stesse cifre, stessa sicurezza, stessa formattazione. Molti strumenti attuali, quando ricevono un file di dati, scrivono ed eseguono codice per elaborarlo: in quel caso il calcolo è effettivo, ed è in genere molto più affidabile. Ma non sempre è chiaro quale dei due modi sia stato usato, e anche nella stessa risposta alcuni numeri possono essere calcolati e altri generati, per esempio un commento finale che cita una percentuale non presente nell'output del codice. La regola pratica: per i numeri che contano, accertarsi che derivino da un calcolo eseguito e controllabile.");
    phaseTag(s, 1);
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiMessageSquare", head: "Numero generato", headSize: 16, bodySize: 12, iconBg: C.accent5,
      body: bullets(["Prodotto come qualsiasi altra parola", "Plausibile, spesso giusto su operazioni semplici", "Errori frequenti con molti dati o numeri grandi", "Nessun passaggio da controllare"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiCpu", head: "Calcolo eseguito", headSize: 16, bodySize: 12, fill: C.accent6,
      body: bullets(["Codice o formula eseguiti da uno strumento", "Deterministico e ripetibile", "In genere molto più affidabile", "Codice e passaggi controllabili"], { space: 4 }) });
    banner(s, 3.95, "Stesse cifre, stessa sicurezza, stessa formattazione. Nella stessa risposta possono convivere numeri calcolati e numeri generati.", { h: 0.7, fontSize: 13 });
    txt(s, "Integrazione A: analisi con codice e generazione di risposte numeriche", { x: 0.5, y: 4.72, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Riconoscere un calcolo eseguito", "Come si capisce, in pratica, se un numero viene da un calcolo eseguito? Alcuni segnali e alcune pratiche. Segnali positivi: lo strumento mostra il codice eseguito o indica di aver usato uno strumento di analisi; mostra i risultati intermedi, come tabelle e conteggi; produce file, grafici o tabelle derivati dai dati; i numeri del commento coincidono con quelli dell'output del calcolo. Segnali di attenzione: la risposta contiene numeri senza alcuna traccia di elaborazione; si chiede un calcolo su dati incollati nel testo della conversazione e la risposta arriva immediata, senza codice; il commento cita valori che non compaiono nei risultati; numeri troppo tondi o troppo precisi rispetto ai dati. Pratiche utili: chiedere esplicitamente di eseguire il calcolo con codice e di mostrarlo; chiedere i valori intermedi; per i risultati importanti, ripetere il calcolo in un foglio di calcolo, o almeno controllare un ordine di grandezza; verificare che il numero di righe elaborate corrisponda a quello del file. Il controllo dell'ordine di grandezza, visto nel Tema 7, resta il primo filtro: un fatturato medio per cliente superiore al fatturato totale è un segnale inequivocabile.");
    phaseTag(s, 1);
    await card(s, 0.5, 1.15, 2.86, 2.9, { icon: "FiCheckCircle", head: "Segnali positivi", headSize: 14, bodySize: 11, fill: C.accent6,
      body: bullets(["Codice mostrato o strumento indicato", "Risultati intermedi visibili", "File, tabelle, grafici derivati", "Commento coerente con l'output"], { space: 4 }) });
    await card(s, 3.57, 1.15, 2.86, 2.9, { icon: "FiAlertTriangle", head: "Segnali di attenzione", headSize: 14, bodySize: 11, iconBg: C.accent5,
      body: bullets(["Numeri senza traccia di elaborazione", "Dati incollati, risposta immediata", "Valori citati ma assenti nei risultati", "Numeri troppo tondi o troppo precisi"], { space: 4 }) });
    await card(s, 6.64, 1.15, 2.86, 2.9, { icon: "FiTool", head: "Pratiche utili", headSize: 14, bodySize: 11,
      body: bullets(["Chiedere il calcolo con codice", "Chiedere i valori intermedi", "Ripetere i calcoli importanti", "Controllare le righe elaborate"], { space: 4 }) });
    banner(s, 4.25, "Primo filtro: l'ordine di grandezza. Una media per cliente superiore al totale è un segnale inequivocabile.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Tracciabilità delle operazioni", "L'ultimo elemento del sottotema è la tracciabilità delle operazioni eseguite: poter ricostruire come si è arrivati a un risultato. Un risultato numerico tracciabile indica da quali dati parte, con quali filtri, quali operazioni sono state eseguite in quale ordine, con quali definizioni e quali scelte, per esempio sul trattamento dei mancanti. L'esempio in slide mostra un registro delle operazioni: è ciò che conviene chiedere al sistema, o tenere da sé, per le analisi importanti. La tracciabilità serve a quattro cose. A verificare: chi controlla può ripercorrere i passaggi. A ripetere: la stessa analisi sul mese successivo produce risultati confrontabili. A spiegare: chi riceve il risultato può capire che cosa significa e quali sono i suoi limiti. A correggere: se emerge un errore nei dati, si sa quali risultati ne sono influenzati. Si ricollega alla distinzione tra dati, metriche e indicatori: un indicatore tracciabile dichiara la sua definizione. E prepara il sottotema 9.8, dove vedremo che l'affidabilità non deriva dall'apparenza professionale del risultato, ma da dati, elaborazioni e ipotesi controllabili.");
    phaseTag(s, 1);
    promptBox(s, 0.5, 1.15, 5.6, 2.9, "1. File: vendite_2025.csv (12.480 righe)\n2. Esclusi ordini annullati: 312 righe\n3. Rimossi duplicati: 41 righe\n4. Importi: netti di IVA e resi\n5. Raggruppamento per regione e mese\n6. Valore medio = fatturato / n. ordini\n7. Mancanti di regione (18): esclusi", { label: "Registro delle operazioni (esempio fittizio)", fontSize: 11 });
    const u = [["Verificare", "Ripercorrere i passaggi"], ["Ripetere", "Risultati confrontabili nel tempo"], ["Spiegare", "Significato e limiti"], ["Correggere", "Sapere che cosa è influenzato"]];
    u.forEach((e, i) => {
      const y = 1.15 + i * 0.74;
      shapeBox(s, 6.35, y, 3.15, 0.64, i % 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.5, y: y + 0.04, w: 2.9, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.5, y: y + 0.33, w: 2.9, h: 0.28, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.25, "Un risultato tracciabile dichiara dati, filtri, operazioni, definizioni e scelte.", { h: 0.7, fontSize: 14 });
  }
  keySlide("Metodo, dati e passaggi di elaborazione sono determinanti per l'affidabilità di un risultato numerico.", "Sottotema 9.3  ·  Elaborazione e analisi quantitativa", "Concetto chiave del sottotema 9.3. L'AI può eseguire tutte le operazioni quantitative comuni, generare formule e codice, calcolare indicatori e statistiche descrittive. Ma un numero in una risposta non dimostra che sia stato eseguito un calcolo: bisogna distinguere i numeri generati linguisticamente da quelli calcolati con strumenti verificabili. Le scelte su base, periodo, definizioni e trattamento dei dati contano quanto l'aritmetica, le statistiche di sintesi vanno sempre accompagnate da uno sguardo ai dati, e la tracciabilità delle operazioni rende il risultato verificabile, ripetibile e spiegabile. Esercizio suggerito: dare a uno strumento AI una tabella fittizia di una trentina di righe incollata nel testo e chiedere un totale e una media, poi chiedere lo stesso caricando il file e chiedendo di usare il codice, e confrontare i risultati con quelli di un foglio di calcolo.");

  // =====================================================================
  section("9.4 Pattern e tendenze");
  divider("9.4", "Pattern, tendenze e anomalie", "Individuare una relazione nei dati non prova automaticamente l'esistenza di un nesso causale", "Passiamo dalle operazioni ai fenomeni. Nel 9.3 abbiamo calcolato; qui cerchiamo nei dati qualcosa di significativo: andamenti nel tempo, schemi che si ripetono, anomalie, relazioni tra variabili. È uno degli usi più promettenti dell'AI, che può esplorare rapidamente molte combinazioni e segnalare ciò che merita attenzione. Ed è anche quello in cui il rischio di vedere ciò che non c'è è più alto. In questo sottotema, da comprendere e sperimentare, vediamo tendenze, stagionalità, anomalie e correlazioni, e l'integrazione B: dati corretti possono portare a conclusioni sbagliate.");
  {
    const s = content("Andamenti nel tempo", "L'analisi degli andamenti temporali è una delle più comuni: come sono cambiate le vendite, i costi, i reclami, le assenze nel corso del tempo. Un andamento osservato è di solito la combinazione di tre componenti. La tendenza di fondo, o trend: la direzione di lungo periodo, di crescita, calo o stabilità. La stagionalità: oscillazioni che si ripetono con regolarità, come il picco di dicembre o il calo di agosto. Le variazioni irregolari: oscillazioni casuali, o dovute a eventi particolari. Il grafico in slide mostra un esempio fittizio di vendite mensili su tre anni: c'è una tendenza di crescita moderata, una forte stagionalità con picchi a fine anno, e piccole variazioni irregolari. L'AI può aiutare a separare queste componenti e a descriverle. L'errore più frequente è confondere stagionalità e tendenza: interpretare il calo di gennaio rispetto a dicembre come un segnale negativo, quando si ripete ogni anno. Per questo i confronti temporali più affidabili sono quelli con lo stesso periodo dell'anno precedente. Un altro errore frequente è dichiarare una tendenza a partire da pochi punti: tre mesi di crescita non sono necessariamente un trend.");
    phaseTag(s, 1);
    const lab = [], v = [];
    const base = [80, 78, 85, 88, 90, 87, 82, 70, 92, 98, 115, 135];
    for (let y = 0; y < 3; y++) for (let m = 0; m < 12; m++) { lab.push(m === 0 ? String(2023 + y) : ""); v.push(Math.round(base[m] * (1 + 0.08 * y) + ((m * 7 + y * 3) % 5) - 2)); }
    lineChart(s, lab, [{ name: "Vendite mensili", values: v }], { x: 0.5, y: 1.1, w: 6.0, h: 3.0, min: 60, max: 160, title: "Vendite mensili, tre anni (esempio fittizio)" });
    const c = [["Tendenza", "Direzione di lungo periodo"], ["Stagionalità", "Oscillazioni regolari, come il picco di fine anno"], ["Irregolari", "Casuali o dovute a eventi"]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.95;
      shapeBox(s, 6.75, y, 2.75, 0.85, i === 1 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 6.9, y: y + 0.06, w: 2.5, h: 0.32, fontSize: 13, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 6.9, y: y + 0.4, w: 2.5, h: 0.4, fontSize: 11, color: C.text2 });
    });
    banner(s, 4.3, "Errori tipici: leggere la stagionalità come tendenza, e dichiarare un trend da pochi punti.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Anomalie e scostamenti", "Un'anomalia è un valore o un comportamento che si discosta in modo significativo da ciò che ci si attende. Le anomalie sono preziose: possono segnalare un errore nei dati, un problema operativo, una frode, un'opportunità. L'AI è molto efficace nel trovarle, anche in grandi quantità di dati e su molte variabili insieme, e può confrontare ogni valore con l'andamento abituale. Il grafico fittizio in slide mostra i reclami settimanali di un servizio: un picco evidente nella settimana 9. Che cosa significa? Le spiegazioni possibili sono molte: un problema con un lotto di prodotto, un cambio di fornitore logistico, un nuovo modulo di reclamo online più facile da usare, un errore di registrazione che ha duplicato le segnalazioni. L'AI può segnalare il picco e proporre ipotesi, ma non può sapere quale sia quella giusta senza informazioni sul contesto. Due attenzioni. Anomalo non significa sbagliato: eliminare i valori anomali in automatico può cancellare proprio l'informazione più importante. E non ogni scostamento è un'anomalia: con molti dati, alcune variazioni ampie sono normali. Conviene chiedere al sistema con quale criterio ha definito anomalo un valore.");
    phaseTag(s, 1);
    const w = [], r = [12, 14, 11, 13, 15, 12, 14, 13, 41, 16, 13, 12, 14, 13];
    for (let i = 0; i < r.length; i++) w.push("S" + (i + 1));
    lineChart(s, w, [{ name: "Reclami", values: r }], { x: 0.5, y: 1.1, w: 5.5, h: 2.6, min: 0, max: 45, symbol: "circle", title: "Reclami settimanali (esempio fittizio)" });
    shapeBox(s, 6.25, 1.15, 3.25, 2.55, C.background2, "ipotesi");
    txt(s, "Settimana 9: perché?", { x: 6.4, y: 1.22, w: 3.0, h: 0.35, fontSize: 14, bold: true, color: C.accent5 });
    txt(s, bullets(["Un lotto difettoso", "Un nuovo fornitore logistico", "Un modulo online più semplice", "Segnalazioni duplicate per errore"], { space: 4 }), { x: 6.4, y: 1.65, w: 3.0, h: 1.9, fontSize: 12, color: C.text1 });
    chip(s, 0.5, 3.9, 4.4, 0.55, "Anomalo non significa sbagliato", { fill: C.accent6, fontSize: 12 });
    chip(s, 5.1, 3.9, 4.4, 0.55, "Non ogni scostamento è un'anomalia", { fill: C.accent6, fontSize: 12 });
    txt(s, "L'AI segnala e propone ipotesi; quale sia giusta lo dice il contesto. Chiedere con quale criterio un valore è definito anomalo.", { x: 0.5, y: 4.55, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Relazioni e correlazioni", "Il confronto tra variabili cerca relazioni: quando una cresce, l'altra cresce o cala? La misura più comune è la correlazione, un numero tra meno uno e più uno che indica quanto due variabili variano insieme in modo lineare. Vicino a più uno, crescono insieme; vicino a meno uno, una cresce quando l'altra cala; vicino a zero, nessuna relazione lineare. Il grafico fittizio in slide mostra la relazione tra il numero di visite commerciali e il fatturato di venti clienti: c'è una correlazione positiva evidente. L'AI può calcolare correlazioni tra molte variabili in pochi secondi, e segnalare quelle più forti. Tre cose da sapere per leggerle correttamente. La correlazione misura solo relazioni lineari: due variabili possono essere fortemente legate in modo non lineare con correlazione bassa, come nel secondo insieme di Anscombe. La correlazione è sensibile ai valori anomali: un solo punto può crearla o cancellarla, come nel quarto insieme. E soprattutto, la correlazione non indica la direzione né la causa: le visite producono fatturato, o i clienti con più fatturato ricevono più visite? Ne parliamo nella prossima slide.");
    phaseTag(s, 1);
    const vx = [2, 3, 3, 4, 5, 5, 6, 6, 7, 8, 8, 9, 10, 10, 11, 12, 13, 14, 15, 16];
    const vy = [18, 22, 30, 26, 35, 41, 38, 47, 44, 52, 58, 55, 63, 70, 66, 74, 80, 78, 90, 94];
    scatter(s, vx, vy, { x: 0.5, y: 1.1, w: 5.0, h: 3.0, xmin: 0, xmax: 18, ymin: 0, ymax: 100, title: "Visite commerciali e fatturato (k€), 20 clienti fittizi", size: 7 });
    const c = [["Solo relazioni lineari", "Legami curvi possono avere correlazione bassa"], ["Sensibile agli anomali", "Un punto può crearla o cancellarla"], ["Né direzione né causa", "Visite che producono fatturato, o il contrario?"]];
    c.forEach((e, i) => {
      const y = 1.15 + i * 0.98;
      shapeBox(s, 5.75, y, 3.75, 0.88, i === 2 ? C.accent6 : C.background2, e[0]);
      txt(s, e[0], { x: 5.9, y: y + 0.06, w: 3.5, h: 0.32, fontSize: 13, bold: true, color: i === 2 ? C.accent5 : C.accent1 });
      txt(s, e[1], { x: 5.9, y: y + 0.4, w: 3.5, h: 0.42, fontSize: 11, color: C.text2 });
    });
    txt(s, "La correlazione va da -1 a +1 e misura quanto due variabili variano insieme in modo lineare.", { x: 0.5, y: 4.4, w: 9, h: 0.45, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Correlazione e causalità nei dati", "Nel Tema 7 abbiamo visto la distinzione tra correlazione e causalità come difetto di ragionamento. Qui la applichiamo ai dati, dove il rischio è particolarmente concreto, perché l'AI trova correlazioni rapidamente e tende a commentarle con un linguaggio causale: 'le visite aumentano il fatturato', 'la formazione riduce le assenze'. Le spiegazioni alternative sono le stesse viste nel Tema 7, declinate sui dati aziendali. Causalità inversa: i clienti più grandi ricevono più visite perché sono più importanti, non il contrario. Terzo fattore: le filiali con più formazione e meno assenze sono anche quelle con un responsabile più attento, che spiega entrambe le cose. Selezione: i dipendenti che hanno scelto di partecipare alla formazione erano già i più motivati. Coincidenza: con pochi dati, una correlazione può essere casuale. Come si può avvicinarsi a una prova causale? Con confronti controllati, per esempio introducendo un cambiamento in alcune sedi e non in altre, scelte a caso, e confrontando i risultati. Sono metodi che richiedono competenze specifiche, da accennare. Per l'utilizzatore, la regola è semplice: una correlazione trovata dall'AI è un'ipotesi da esplorare, non una conclusione.");
    phaseTag(s, 1);
    await iconGrid(s, [
      { icon: "FiRepeat", head: "Causalità inversa", body: "I clienti grandi ricevono più visite, non il contrario" },
      { icon: "FiShare2", head: "Terzo fattore", body: "Un responsabile attento spiega formazione e meno assenze" },
      { icon: "FiFilter", head: "Selezione", body: "Alla formazione sono andati i più motivati" },
      { icon: "FiShuffle", head: "Coincidenza", body: "Con pochi dati, una correlazione può essere casuale" },
    ], 2, { y: 1.15, H: 2.55, headSize: 14, bodySize: 12 });
    banner(s, 3.9, "Una correlazione trovata dall'AI è un'ipotesi da esplorare, non una conclusione. Attenzione al linguaggio causale dei commenti.", { h: 0.75, fontSize: 13 });
    txt(s, "Avvicinarsi a una prova causale richiede confronti controllati: metodi specialistici, da accennare.", { x: 0.5, y: 4.67, w: 9, h: 0.33, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Relazioni prive di significato", "Il sottotema segnala un rischio specifico: individuare relazioni prive di significato. Il meccanismo è statistico e merita di essere compreso. Se si confrontano due variabili casuali, la probabilità che mostrino una correlazione apparentemente rilevante è bassa. Ma se si confrontano tra loro cinquanta variabili, si eseguono più di mille confronti, e alcune correlazioni forti emergeranno per puro caso. È quello che succede quando si chiede all'AI di 'trovare relazioni interessanti nei dati': il sistema esplora molte combinazioni e riporta quelle più forti, che sono proprio quelle con più probabilità di essere casuali. Esistono raccolte famose di correlazioni assurde, come quella tra il consumo di formaggio pro capite e le morti per aggrovigliamento nelle lenzuola negli Stati Uniti, raccolte da Tyler Vigen, che mostrano quanto sia facile trovare relazioni forti tra fenomeni scollegati. Il problema si aggrava con pochi dati e con molte variabili. Le contromisure: partire da domande e ipotesi, invece di cercare relazioni a caso; diffidare delle relazioni senza una spiegazione plausibile; verificare se la relazione regge su un altro periodo o un altro gruppo di dati.");
    phaseTag(s, 1);
    const n = [["2", "variabili", "1 confronto"], ["10", "variabili", "45 confronti"], ["50", "variabili", "1.225 confronti"]];
    n.forEach((e, i) => {
      const x = 0.5 + i * 2.0;
      shapeBox(s, x, 1.15, 1.85, 1.6, i === 2 ? C.accent1 : C.background2, e[0]);
      txt(s, e[0], { x, y: 1.2, w: 1.85, h: 0.6, fontSize: 30, bold: true, color: i === 2 ? C.background1 : C.accent1, align: "center" });
      txt(s, e[1], { x, y: 1.8, w: 1.85, h: 0.3, fontSize: 12, color: i === 2 ? C.background1 : C.text2, align: "center" });
      txt(s, e[2], { x, y: 2.15, w: 1.85, h: 0.4, fontSize: 13, bold: true, color: i === 2 ? C.background1 : C.text1, align: "center" });
    });
    shapeBox(s, 6.6, 1.15, 2.9, 1.6, C.text1, "caso");
    txt(s, "Più confronti, più correlazioni forti per puro caso", { x: 6.75, y: 1.15, w: 2.6, h: 1.6, fontSize: 14, bold: true, color: C.accent6, valign: "middle" });
    txt(s, "Contromisure", { x: 0.5, y: 2.95, w: 9, h: 0.35, fontSize: 13, bold: true, color: C.text1 });
    chip(s, 0.5, 3.35, 2.9, 0.65, "Partire da domande e ipotesi", { fill: C.accent6, fontSize: 12 });
    chip(s, 3.55, 3.35, 2.9, 0.65, "Diffidare delle relazioni senza spiegazione", { fill: C.accent6, fontSize: 12 });
    chip(s, 6.6, 3.35, 2.9, 0.65, "Verificare su altri periodi o gruppi", { fill: C.accent6, fontSize: 12 });
    txt(s, "'Trova relazioni interessanti' porta a galla proprio quelle più probabilmente casuali. Esempi celebri di correlazioni assurde: Tyler Vigen, Spurious Correlations.", { x: 0.5, y: 4.2, w: 9, h: 0.7, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Dati corretti, conclusioni sbagliate", "Questa è l'integrazione B del tema: dati accurati possono comunque portare a interpretazioni improprie e conclusioni infondate. È un punto importante perché va contro un'intuizione diffusa: se i dati sono giusti, anche le conclusioni lo saranno. Non è così. L'esempio fittizio in slide lo mostra. Un'analisi corretta dei dati mostra che i clienti che usano l'app aziendale spendono in media il 40 per cento in più. Ogni numero è giusto. La conclusione proposta, 'spingere tutti i clienti a usare l'app aumenterà la spesa del 40 per cento', è infondata per almeno tre ragioni: i clienti che usano l'app sono probabilmente già i più fedeli e attivi, quindi spenderebbero di più comunque; non sappiamo se chi viene spinto a usarla si comporterà come chi l'ha scelta spontaneamente; e il 40 per cento è una differenza tra gruppi, non l'effetto di un cambiamento. Le conclusioni sbagliate da dati corretti nascono di solito da tre passaggi: dalla correlazione alla causa, dal gruppo osservato a tutti, dalla differenza osservata all'effetto di un intervento. Sono passaggi che i commenti generati dall'AI compiono con facilità, con un linguaggio sicuro.");
    phaseTag(s, 1);
    docBox(s, 0.5, 1.15, 4.35, 1.1, "Dato corretto (esempio fittizio)", "I clienti che usano l'app spendono in media il 40% in più.", { fontSize: 13, fill: C.accent6 });
    docBox(s, 0.5, 2.4, 4.35, 1.1, "Conclusione infondata", "Spingere tutti a usare l'app aumenterà la spesa del 40%.", { fontSize: 13, bar: C.accent5, labelColor: C.accent5 });
    await card(s, 5.15, 1.15, 4.35, 2.35, { icon: "FiHelpCircle", head: "Perché non regge", headSize: 15, bodySize: 12,
      body: bullets(["Chi usa l'app è già più fedele", "Chi viene spinto può comportarsi diversamente", "Una differenza tra gruppi non è l'effetto di un intervento"], { space: 4 }) });
    txt(s, "Tre passaggi a rischio", { x: 0.5, y: 3.65, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.accent5 });
    chip(s, 0.5, 4.0, 2.9, 0.55, "Dalla correlazione alla causa", { fill: C.background2, fontSize: 12 });
    chip(s, 3.55, 4.0, 2.9, 0.55, "Dal gruppo osservato a tutti", { fill: C.background2, fontSize: 12 });
    chip(s, 6.6, 4.0, 2.9, 0.55, "Dalla differenza all'effetto", { fill: C.background2, fontSize: 12 });
    txt(s, "Integrazione B: dati corretti, conclusioni sbagliate", { x: 0.5, y: 4.7, w: 9, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }
  {
    const s = content("Verificare le ipotesi", "Come si passa da un fenomeno osservato a un'interpretazione solida? Il sottotema parla di interpretazione critica dei fenomeni e di necessità di verificare le ipotesi. In pratica, un metodo in cinque passaggi. Primo, descrivere il fenomeno senza interpretarlo: che cosa si osserva, con quali numeri, in quale periodo e su quali dati. Secondo, formulare più ipotesi, non una sola: l'AI è molto utile qui, perché genera rapidamente spiegazioni alternative, come visto nel Tema 7. Terzo, per ciascuna ipotesi, chiedersi che cosa dovremmo osservare nei dati se fosse vera: se il picco di reclami dipende da un lotto difettoso, i reclami dovrebbero riguardare quel prodotto; se dipende dal nuovo modulo online, dovrebbero arrivare tutti da quel canale. Quarto, controllare quelle conseguenze nei dati, o con altre informazioni: è un'analisi mirata, molto più affidabile della ricerca generica di relazioni. Quinto, dichiarare il livello di certezza della conclusione: confermata, probabile, possibile. Questo metodo trasforma l'AI da generatore di conclusioni a strumento per esplorare e verificare ipotesi, che è il suo uso più sicuro e più utile nell'analisi.");
    phaseTag(s, 1);
    numList(s, ["Descrivere il fenomeno senza interpretarlo", "Formulare più ipotesi, non una sola: l'AI aiuta a generarle", "Per ciascuna: che cosa dovremmo osservare se fosse vera?", "Controllare quelle conseguenze nei dati o con altre informazioni", "Dichiarare il livello di certezza: confermata, probabile, possibile"], { y: 1.15, h: 0.52, fontSize: 13 });
    banner(s, 4.25, "Da generatore di conclusioni a strumento per esplorare e verificare ipotesi: l'uso più sicuro e più utile.", { h: 0.65, fontSize: 13 });
  }
  keySlide("Individuare una relazione nei dati non prova automaticamente l'esistenza di un nesso causale.", "Sottotema 9.4  ·  Identificazione di pattern, tendenze e anomalie", "Concetto chiave del sottotema 9.4. L'AI è molto efficace nel trovare tendenze, stagionalità, anomalie e correlazioni, anche in grandi quantità di dati. Ma la stagionalità va distinta dalla tendenza, un'anomalia va capita prima di essere eliminata, la correlazione non indica né direzione né causa, e chi cerca relazioni tra molte variabili ne troverà alcune per puro caso. Dati corretti possono portare a conclusioni sbagliate. Il metodo più solido è usare l'AI per formulare e verificare ipotesi. Esercizio suggerito: presentare ai partecipanti una correlazione fittizia trovata dall'AI, con il commento causale generato, e chiedere di proporre almeno tre spiegazioni alternative e, per ciascuna, quale dato permetterebbe di verificarla.");

  // =====================================================================
  section("9.5 Visualizzazione");
  divider("9.5", "Visualizzazione e comunicazione dei risultati", "Una rappresentazione persuasiva non garantisce la validità dei dati né delle conclusioni", "Dai fenomeni alla loro comunicazione. Un'analisi serve se qualcuno la capisce e la usa, e per questo i risultati vanno rappresentati e comunicati: grafici, tabelle, dashboard, report, commenti. L'AI è diventata molto efficace in tutte queste attività, e produce in pochi secondi grafici e report dall'aspetto professionale. In questo sottotema, da comprendere e sperimentare, vediamo che cosa può fare, come scegliere la rappresentazione giusta, i rischi dei grafici fuorvianti e dei commenti automatici, e la distinzione tra comunicazione efficace e interpretazione corretta. I principi generali di lettura critica dei grafici li abbiamo visti nel Tema 7; qui guardiamo alla produzione.");
  {
    const s = content("Che cosa può produrre l'AI", "Le possibilità dell'AI nella rappresentazione dei risultati sono ampie. Grafici: a partire dai dati, il sistema propone e crea grafici a barre, linee, torte, dispersione, spesso con poche parole di richiesta. Tabelle riepilogative: i risultati principali organizzati in modo leggibile, con totali, percentuali, evidenziazioni. Dashboard: insiemi di grafici e indicatori su una sola schermata, da consultare periodicamente. Report analitici: documenti che combinano testo, tabelle e grafici per presentare un'analisi. Commenti ai risultati: testi che descrivono e interpretano grafici e tabelle, come 'le vendite sono cresciute del 12 per cento, trainate dalla regione Nord'. Il valore è soprattutto la velocità: un report che richiedeva ore si prepara in minuti, e si possono provare rapidamente rappresentazioni diverse. Ma proprio la facilità di produzione rende più importante il controllo: un grafico ben fatto e un commento ben scritto trasmettono un senso di affidabilità che non dipende dalla correttezza dei dati o dell'interpretazione sottostanti.");
    phaseTag(s, 2);
    await iconGrid(s, [
      { icon: "FiBarChart2", head: "Grafici", body: "Barre, linee, torte, dispersione" },
      { icon: "FiGrid", head: "Tabelle riepilogative", body: "Totali, percentuali, evidenziazioni" },
      { icon: "FiMonitor", head: "Dashboard", body: "Grafici e indicatori in una schermata" },
      { icon: "FiFileText", head: "Report analitici", body: "Testo, tabelle e grafici insieme" },
      { icon: "FiMessageSquare", head: "Commenti ai risultati", body: "Descrizione e interpretazione in parole" },
      { icon: "FiClock", head: "Velocità", body: "Da ore a minuti; più rappresentazioni da provare", fill: C.accent6 },
    ], 3, { y: 1.15, H: 3.0, headSize: 13, bodySize: 12 });
    banner(s, 4.35, "Un grafico ben fatto e un commento ben scritto trasmettono affidabilità, che non dipende dai dati sottostanti.", { h: 0.6, fontSize: 13 });
  }
  {
    const s = content("Scegliere la rappresentazione", "La scelta del grafico dipende da che cosa si vuole mostrare. Per confrontare valori tra categorie, come il fatturato per regione, il grafico a barre è di solito la scelta migliore, perché le lunghezze si confrontano facilmente. Per mostrare un andamento nel tempo, il grafico a linee. Per mostrare la composizione di un totale, come la quota di ciascun canale sulle vendite, si usano barre in pila o, con poche categorie, il grafico a torta, che però diventa illeggibile oltre quattro o cinque fette e rende difficile confrontare quote simili. Per mostrare la relazione tra due variabili, il grafico a dispersione. Per mostrare la distribuzione dei valori, come la frequenza degli importi degli ordini, l'istogramma. Per valori precisi da consultare, una tabella è spesso meglio di qualsiasi grafico. L'AI propone di solito una rappresentazione ragionevole, ma non sempre la migliore: tende a scegliere grafici comuni, ad aggiungere elementi decorativi, a usare troppi colori. Conviene indicare che cosa si vuole far vedere, e chiedere al sistema di motivare la scelta. Un buon grafico ha un messaggio principale, visibile in pochi secondi.");
    phaseTag(s, 2);
    table(s, [["Che cosa mostrare", "Rappresentazione", "Attenzione"],
      ["Confronto tra categorie", "Barre", "Ordinare le barre per valore"],
      ["Andamento nel tempo", "Linee", "Periodo completo, non selezionato"],
      ["Composizione di un totale", "Barre in pila o torta", "Torta solo con poche fette"],
      ["Relazione tra due variabili", "Dispersione", "Relazione non significa causa"],
      ["Distribuzione dei valori", "Istogramma", "Scelta degli intervalli"],
      ["Valori precisi", "Tabella", "Spesso meglio di un grafico"]],
      { y: 1.15, colW: [3.0, 2.6, 3.4], rowH: 0.4, fontSize: 12, blankCorner: false, accentCol: 1 });
    banner(s, 4.1, "Indicare che cosa si vuole far vedere, e chiedere di motivare la scelta. Un buon grafico ha un messaggio visibile in pochi secondi.", { h: 0.8, fontSize: 13 });
  }
  {
    const s = content("Tabelle, dashboard e report", "Tre forme di comunicazione con esigenze diverse. Le tabelle riepilogative presentano i risultati principali in forma compatta. L'AI le produce bene; il controllo riguarda la coerenza dei totali con i dati, l'arrotondamento, che può far sì che le percentuali non sommino a cento, e le categorie raggruppate in 'altro', che possono nascondere elementi importanti. Le dashboard sono pensate per un uso ripetuto: si consultano ogni settimana o ogni mese. Qui conta soprattutto la stabilità delle definizioni: se un indicatore cambia formula da un mese all'altro, l'andamento perde significato. Le dashboard aziendali ufficiali sono di solito costruite con strumenti di BI e definizioni concordate; quelle prodotte al volo con l'AI sono utili per esplorare, ma non vanno confuse con le prime. I report analitici combinano testo, numeri e grafici in un racconto. Il rischio specifico è l'incoerenza tra le parti: il testo cita un valore diverso da quello della tabella, un grafico si riferisce a un periodo diverso, una conclusione non è sostenuta dai numeri presentati. Quando l'AI produce un report completo, conviene controllare che ogni numero citato nel testo corrisponda a quelli di tabelle e grafici.");
    phaseTag(s, 2);
    const f = [["FiGrid", "Tabelle riepilogative", ["Totali coerenti con i dati", "Arrotondamenti: somme diverse da 100", "Cosa nasconde 'altro'?"]], ["FiMonitor", "Dashboard", ["Uso ripetuto nel tempo", "Definizioni stabili", "Esplorative o ufficiali?"]], ["FiFileText", "Report analitici", ["Testo, numeri e grafici", "Coerenza tra le parti", "Ogni numero citato va ritrovato"]]];
    for (let i = 0; i < 3; i++) {
      await card(s, 0.5 + i * 3.07, 1.15, 2.86, 2.9, { icon: f[i][0], head: f[i][1], headSize: 15, bodySize: 12, fill: i === 1 ? C.accent6 : C.background2, body: bullets(f[i][2], { space: 5 }) });
    }
    banner(s, 4.25, "Le dashboard prodotte al volo servono a esplorare: non vanno confuse con quelle ufficiali, con definizioni concordate.", { h: 0.7, fontSize: 13 });
  }
  {
    const s = content("Commenti generati e storytelling", "Due attività in cui l'AI è particolarmente brava, e che richiedono particolare attenzione. I commenti ai risultati: l'AI descrive in parole ciò che grafici e tabelle mostrano. È utile, perché rende i risultati accessibili a chi non legge facilmente i numeri. Ma il commento può discostarsi dai dati in modi sottili: citare un valore non presente, arrotondare in modo da cambiare il senso, 'quasi raddoppiato' per un aumento del 70 per cento, enfatizzare un elemento secondario, e soprattutto aggiungere interpretazioni causali che i dati non sostengono, come 'grazie alla nuova campagna'. Il data storytelling è l'arte di costruire un racconto attorno ai dati: un messaggio principale, una sequenza logica, un contesto, un'implicazione. È una competenza preziosa, perché i dati senza racconto spesso non vengono capiti né usati. Ma un racconto efficace seleziona: sceglie che cosa mostrare e che cosa lasciare fuori. Quando il racconto viene costruito dall'AI, le scelte di selezione sono del sistema, e il racconto può essere convincente anche quando i dati sono più ambigui di quanto appaia. Il controllo: ogni affermazione del commento o del racconto deve poter essere ricondotta a un numero presentato.");
    phaseTag(s, 2);
    await card(s, 0.5, 1.2, 4.35, 2.5, { icon: "FiMessageSquare", head: "Commenti generati", headSize: 15, bodySize: 12,
      body: bullets(["Valori non presenti nei dati", "'Quasi raddoppiato' per +70%", "Enfasi su elementi secondari", "'Grazie alla campagna': causa non provata"], { space: 4 }) });
    await card(s, 5.15, 1.2, 4.35, 2.5, { icon: "FiBookOpen", head: "Data storytelling", headSize: 15, bodySize: 12, fill: C.accent6,
      body: bullets(["Messaggio, sequenza, contesto, implicazione", "Rende i dati comprensibili e usati", "Ma seleziona che cosa mostrare", "Se lo costruisce l'AI, la selezione è sua"], { space: 4 }) });
    banner(s, 3.9, "Ogni affermazione del commento o del racconto deve poter essere ricondotta a un numero presentato.", { h: 0.75, fontSize: 14 });
  }
  {
    const s = content("Grafici fuorvianti", "Nel Tema 7 abbiamo visto come un asse che non parte da zero possa ingigantire una differenza. Qui vediamo un altro meccanismo frequente: la scelta del periodo. I due grafici in slide mostrano gli stessi dati fittizi, le vendite mensili di un prodotto. A sinistra, gli ultimi sei mesi: una crescita costante e rassicurante. A destra, gli ultimi trenta mesi: la crescita recente è un recupero parziale dopo un forte calo, e le vendite sono ancora sotto i livelli di due anni fa. Nessuno dei due grafici è falso, ma comunicano messaggi opposti. Altri meccanismi fuorvianti da conoscere: assi diversi per due serie sullo stesso grafico, che fanno sembrare correlati andamenti indipendenti; grafici tridimensionali, che deformano le proporzioni; torte con percentuali che non sommano a cento; categorie ordinate per enfatizzare un risultato; scale logaritmiche non segnalate. L'AI non produce grafici fuorvianti di proposito, ma segue la richiesta: se si chiede di mostrare la crescita, sceglierà il periodo in cui c'è crescita. Il controllo consiste nel chiedersi: quale periodo, quale scala, quali categorie, e che cosa vedrei con scelte diverse?");
    phaseTag(s, 2);
    const full = [100, 102, 99, 101, 98, 96, 97, 94, 90, 88, 85, 82, 80, 78, 75, 73, 70, 68, 66, 65, 64, 63, 62, 64, 66, 68, 70, 72, 74, 77];
    const labF = full.map((v, i) => (i % 6 === 0 ? "M" + (i + 1) : ""));
    lineChart(s, ["M25", "M26", "M27", "M28", "M29", "M30"], [{ name: "Vendite", values: full.slice(24) }], { x: 0.5, y: 1.1, w: 4.3, h: 2.6, min: 60, max: 80, symbol: "circle", title: "Ultimi 6 mesi: crescita costante" });
    lineChart(s, labF, [{ name: "Vendite", values: full, color: HEX.a5 }], { x: 5.2, y: 1.1, w: 4.3, h: 2.6, min: 0, max: 110, title: "Ultimi 30 mesi: un recupero parziale" });
    txt(s, "Stessi dati fittizi", { x: 0.5, y: 3.72, w: 9, h: 0.28, fontSize: 10, italic: true, color: C.accent2, align: "center" });
    const m = ["Due assi diversi", "Effetti 3D", "Torte oltre 100%", "Ordine delle categorie", "Scale logaritmiche"];
    m.forEach((t, i) => chip(s, 0.5 + i * 1.82, 4.05, 1.7, 0.45, t, { fill: C.background2, fontSize: 11 }));
    txt(s, "Chiedersi: quale periodo, quale scala, quali categorie, e che cosa vedrei con scelte diverse?", { x: 0.5, y: 4.6, w: 9, h: 0.4, fontSize: 12, bold: true, italic: true, color: C.accent5 });
  }
  {
    const s = content("Dati e grafico coerenti", "Un controllo di base, spesso trascurato: il grafico rappresenta davvero i dati? Quando l'AI produce un grafico, possono verificarsi errori tra i dati e la loro rappresentazione. Il grafico può usare una colonna diversa da quella intesa, per esempio il fatturato lordo invece del netto. Può includere o escludere righe in modo non dichiarato, per esempio le righe di totale, o i mesi incompleti. Può aggregare in modo diverso da quello atteso, per esempio la somma invece della media. Le etichette possono non corrispondere ai dati: un asse etichettato 'migliaia di euro' su dati in euro, una legenda con i colori invertiti. Il periodo dell'ultimo dato può essere parziale: un mese in corso, con pochi giorni di dati, mostra un calo apparente. Quest'ultimo caso è frequentissimo nei grafici prodotti automaticamente da esportazioni recenti. Alcuni controlli rapidi: verificare due o tre valori del grafico sulla tabella dei dati; controllare il titolo, le etichette, le unità di misura, la fonte e il periodo; chiedersi se l'ultimo punto è completo. Un buon grafico dichiara la fonte dei dati, il periodo e le eventuali esclusioni.");
    phaseTag(s, 2);
    const e = [["Colonna sbagliata", "Lordo invece di netto"], ["Righe incluse o escluse", "Totali, mesi incompleti"], ["Aggregazione diversa", "Somma invece di media"], ["Etichette e unità", "Migliaia su dati in euro"], ["Ultimo periodo parziale", "Un calo che non c'è"]];
    e.forEach((x, i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const xx = 0.5 + col * 3.07, y = 1.15 + row * 1.0;
      shapeBox(s, xx, y, 2.86, 0.88, i === 4 ? C.accent6 : C.background2, x[0]);
      txt(s, x[0], { x: xx + 0.15, y: y + 0.06, w: 2.56, h: 0.35, fontSize: 13, bold: true, color: i === 4 ? C.accent5 : C.accent1 });
      txt(s, x[1], { x: xx + 0.15, y: y + 0.44, w: 2.56, h: 0.36, fontSize: 12, color: C.text2 });
    });
    shapeBox(s, 6.64, 2.15, 2.86, 0.88, C.text1, "buon grafico");
    txt(s, "Un buon grafico dichiara fonte, periodo ed esclusioni", { x: 6.79, y: 2.15, w: 2.56, h: 0.88, fontSize: 12, bold: true, color: C.accent6, valign: "middle" });
    banner(s, 3.3, "Controlli rapidi: due o tre valori sulla tabella; titolo, etichette, unità, fonte, periodo; l'ultimo punto è completo?", { h: 0.85, fontSize: 13 });
    txt(s, "Il mese in corso con pochi giorni di dati è uno degli errori più frequenti nei grafici automatici.", { x: 0.5, y: 4.35, w: 9, h: 0.4, fontSize: 12, italic: true, color: C.text2 });
  }
  {
    const s = content("Comunicare bene, interpretare bene", "L'ultimo punto del sottotema è una distinzione: comunicazione efficace e interpretazione corretta sono due qualità diverse. Una comunicazione efficace è chiara, visivamente gradevole, convincente, facile da ricordare. Un'interpretazione corretta è fondata sui dati, rispetta i limiti dell'analisi, dichiara le incertezze, non va oltre ciò che i numeri sostengono. L'ideale è avere entrambe. Ma le due qualità possono separarsi: un report può essere molto efficace e basato su un'interpretazione sbagliata, oppure corretto e così poco chiaro da non essere usato. Con l'AI, il rischio prevalente è il primo: la qualità della comunicazione è quasi sempre alta, e questo può far percepire come solida anche un'interpretazione debole. È lo stesso fenomeno visto nel Tema 7 per i testi, la fluidità che produce fiducia, applicato ai numeri e ai grafici, dove è ancora più forte, perché un grafico sembra mostrare i fatti. Il concetto chiave del sottotema lo dice chiaramente: una rappresentazione persuasiva non garantisce la validità dei dati né delle conclusioni. Prima di chiedersi se un report è convincente, conviene chiedersi se è corretto.");
    phaseTag(s, 2);
    const q = [["Comunicazione efficace", "Chiara, gradevole, convincente", C.background2], ["Interpretazione corretta", "Fondata, dichiara limiti e incertezze", C.accent6]];
    q.forEach((e, i) => {
      const x = 0.5 + i * 4.65;
      shapeBox(s, x, 1.15, 4.35, 1.2, e[2], e[0]);
      txt(s, e[0], { x: x + 0.2, y: 1.22, w: 3.95, h: 0.4, fontSize: 16, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.2, y: 1.65, w: 3.95, h: 0.6, fontSize: 13, color: C.text1 });
    });
    shapeBox(s, 0.5, 2.55, 9.0, 1.05, C.background2, "rischio prevalente");
    txt(s, [{ text: "Con l'AI il rischio prevalente: ", options: { bold: true, color: C.accent5 } }, { text: "comunicazione quasi sempre ottima, che fa sembrare solida anche un'interpretazione debole. Un grafico sembra mostrare i fatti.", options: { color: C.text1 } }], { x: 0.7, y: 2.55, w: 8.6, h: 1.05, fontSize: 13, valign: "middle" });
    banner(s, 3.85, "Prima di chiedersi se un report è convincente, chiedersi se è corretto.", { h: 0.75, fontSize: 16 });
  }
  keySlide("Una rappresentazione persuasiva non garantisce la validità dei dati né delle conclusioni.", "Sottotema 9.5  ·  Visualizzazione dei dati e comunicazione dei risultati", "Concetto chiave del sottotema 9.5. L'AI produce rapidamente grafici, tabelle, dashboard, report e commenti di qualità professionale. La scelta della rappresentazione va guidata dal messaggio da mostrare; i commenti generati possono discostarsi dai dati o aggiungere cause non provate; la scelta del periodo, della scala e delle categorie può cambiare il messaggio; la coerenza tra dati e grafico va controllata. E soprattutto, comunicazione efficace e interpretazione corretta sono qualità diverse: con l'AI la prima è quasi garantita, la seconda no. Esercizio suggerito: dare ai partecipanti un piccolo dataset fittizio e chiedere di produrre con l'AI due grafici degli stessi dati che comunichino messaggi opposti, poi discutere quale sia la rappresentazione più onesta.");
