const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const Fi = require("react-icons/fi");
const { applyTheme } = require("/root/.claude/skills/synced/089a5cb4-f32b-4603-aa0a-09878bdf984d_e1119d2b-6bf8-43fc-8ae3-be0bf12e39dd/pptx/scripts/apply_theme.js");

const HEX = {
  dk1: "22262B", lt1: "FFFFFF", dk2: "4A515C", lt2: "F2F3F5",
  a1: "2E7D7A", a2: "8A939E", a3: "D5D9DE", a4: "5B6573", a5: "A86F1C", a6: "E6F0EF",
};
const THEME = {
  name: "AI Literacy Neutro",
  headFontFace: "Calibri",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.dk1, lt1: HEX.lt1, dk2: HEX.dk2, lt2: HEX.lt2,
    accent1: HEX.a1, accent2: HEX.a2, accent3: HEX.a3, accent4: HEX.a4, accent5: HEX.a5, accent6: HEX.a6,
    hlink: HEX.a1, folHlink: HEX.a4,
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.title = "Tema 1: Evoluzione e rilevanza dell'Intelligenza Artificiale";
pres.subject = "Percorso AI Literacy";
pres.author = "Percorso AI Literacy";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

// ---------- icons ----------
const iconCache = {};
async function icon(name, color) {
  const key = name + color;
  if (iconCache[key]) return iconCache[key];
  const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(Fi[name], { color: "#" + color, size: 256 }));
  const buf = await sharp(Buffer.from(svg)).resize(256, 256).png().toBuffer();
  iconCache[key] = "image/png;base64," + buf.toString("base64");
  return iconCache[key];
}

// ---------- layouts ----------
const FOOT = "AI Literacy  ·  Tema 1  ·  Evoluzione e rilevanza dell'AI";
pres.defineSlideMaster({
  title: "TITOLO",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.7, y: 1.2, w: 8.6, h: 0.4, fontSize: 13, color: C.accent1, bold: true, charSpacing: 2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 1.7, w: 8.6, h: 1.6, fontSize: 36, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.45, w: 8.6, h: 0.9, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "SEZIONE",
  background: { color: C.text1 },
  objects: [
    { placeholder: { options: { name: "num", type: "body", x: 0.7, y: 1.0, w: 4, h: 1.1, fontSize: 60, bold: true, color: C.accent1, margin: 0, valign: "bottom" }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.7, y: 2.25, w: 8.6, h: 1.0, fontSize: 32, bold: true, color: C.background1, align: "left", margin: 0, valign: "top" }, text: "" } },
    { placeholder: { options: { name: "sub", type: "body", x: 0.7, y: 3.35, w: 8.0, h: 1.2, fontSize: 16, color: C.accent3, margin: 0, valign: "top" }, text: "" } },
    { text: { text: FOOT, options: { x: 0.7, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CONTENUTO",
  background: { color: C.background1 },
  margin: [0.5, 0.5, 0.6, 0.5],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.5, y: 5.2, w: 7, h: 0.25, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.25, fontSize: 9, color: C.accent2, align: "right" },
});
pres.defineSlideMaster({
  title: "CHIAVE",
  background: { color: C.text1 },
  objects: [
    { text: { text: "CONCETTO CHIAVE", options: { x: 0.9, y: 1.25, w: 6, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 3, margin: 0 } } },
    { placeholder: { options: { name: "body", type: "body", x: 0.9, y: 1.75, w: 8.2, h: 2.2, fontSize: 26, color: C.background1, valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "ref", type: "body", x: 0.9, y: 4.15, w: 8.2, h: 0.4, fontSize: 13, color: C.accent3, margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: 0.9, y: 5.1, w: 7, h: 0.3, fontSize: 9, color: C.accent2, margin: 0 } } },
  ],
  slideNumber: { x: 9.0, y: 5.1, w: 0.5, h: 0.3, fontSize: 9, color: C.accent2, align: "right" },
});

// ---------- helpers ----------
let currentSection = "Introduzione";
function section(t) { currentSection = t; pres.addSection({ title: t }); }
function content(title, notes) {
  const s = pres.addSlide({ masterName: "CONTENUTO", sectionTitle: currentSection });
  s.addText(title, { placeholder: "title" });
  s.addNotes(notes);
  return s;
}
function shapeBox(s, x, y, w, h, fill, name, line) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: line || { type: "none" }, objectName: name });
}
async function iconCircle(s, x, y, d, name, bg, fg) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: bg || C.accent1 }, line: { type: "none" }, objectName: "cerchio " + name });
  const p = d * 0.25;
  s.addImage({ data: await icon(name, fg || HEX.lt1), x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, altText: name });
}
// card with icon, heading and body
async function card(s, x, y, w, h, o) {
  shapeBox(s, x, y, w, h, o.fill || C.background2, "scheda " + o.head);
  let ty = y + 0.2;
  let hx = x + 0.2, hh = 0.38, by = null;
  if (o.icon && o.inline) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); hx = x + 0.85; hh = 0.5; by = y + 0.85; }
  else if (o.icon) { await iconCircle(s, x + 0.2, y + 0.2, 0.5, o.icon, o.iconBg, o.iconFg); ty = y + 0.82; }
  s.addText(o.head, { x: hx, y: ty, w: x + w - 0.2 - hx, h: hh, valign: o.inline ? "middle" : "top", fontSize: o.headSize || 15, bold: true, color: o.headColor || C.text1, margin: 0, isTextBox: true });
  if (by === null) by = ty + 0.42;
  if (o.body) s.addText(o.body, { x: x + 0.2, y: by, w: w - 0.4, h: y + h - by - 0.12, fontSize: o.bodySize || 13, color: o.bodyColor || C.text2, margin: 0, valign: "top", isTextBox: true });
}
function bullets(items, opts) {
  return items.map((t, i) => {
    if (typeof t === "string") return { text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: opts && opts.space !== undefined ? opts.space : 6 } };
    return { text: t.text, options: Object.assign({ bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: 6 }, t.options) };
  });
}
function txt(s, text, o) { s.addText(text, Object.assign({ margin: 0, isTextBox: true, color: C.text2, fontSize: 14, valign: "top" }, o)); }
function arrow(s, x, y, w, color) {
  s.addShape(pres.shapes.RIGHT_ARROW, { x, y, w, h: 0.32, fill: { color: color || C.accent2 }, line: { type: "none" }, objectName: "freccia" });
}
function banner(s, y, text, o) {
  o = o || {};
  shapeBox(s, 0.5, y, 9.0, o.h || 0.7, o.fill || C.text1, "messaggio");
  txt(s, text, { x: 0.7, y, w: 8.6, h: o.h || 0.7, fontSize: o.fontSize || 14, color: o.color || C.background1, valign: "middle", italic: !!o.italic });
}
function keySlide(text, ref, notes) {
  const s = pres.addSlide({ masterName: "CHIAVE", sectionTitle: currentSection });
  s.addText(text, { placeholder: "body" });
  s.addText(ref, { placeholder: "ref" });
  s.addNotes(notes);
  return s;
}
function divider(num, title, sub, notes) {
  const s = pres.addSlide({ masterName: "SEZIONE", sectionTitle: currentSection });
  s.addText(num, { placeholder: "num" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addNotes(notes);
  return s;
}

(async () => {
  // =====================================================================
  section("Introduzione");
  {
    const s = pres.addSlide({ masterName: "TITOLO", sectionTitle: currentSection });
    s.addText("PERCORSO AI LITERACY  ·  TEMA 1", { placeholder: "kicker" });
    s.addText("Evoluzione e rilevanza dell'Intelligenza Artificiale", { placeholder: "title" });
    s.addText("Area: Comprendere l'AI", { placeholder: "sub" });
    txt(s, "Contenuti aggiornati a ottobre 2026", { x: 0.7, y: 4.75, w: 6, h: 0.3, fontSize: 11, color: C.accent2 });
    s.addNotes("Benvenuti al primo tema del percorso di AI Literacy. In questo modulo non entreremo ancora nel funzionamento tecnico dei sistemi di Intelligenza Artificiale: quello sarà l'oggetto del Tema 2. Qui costruiamo il quadro di riferimento: da dove arriva l'AI, perché proprio negli ultimi anni è diventata così centrale, che cosa è cambiato con l'AI generativa e perché questa evoluzione riguarda da vicino anche la nostra azienda. Il filo conduttore del modulo è un equilibrio: da un lato riconoscere che si tratta di un'evoluzione tecnologica significativa, dall'altro sviluppare uno sguardo critico, che distingua il potenziale della tecnologia dal valore che effettivamente si riesce a realizzare. Suggerimento per l'apertura: chiedere ai partecipanti di indicare con una parola che cosa associano oggi al termine 'Intelligenza Artificiale'. Le risposte (entusiasmo, timore, curiosità, scetticismo) sono un ottimo punto di partenza e potranno essere riprese nella sezione su hype e realtà. Nota per il relatore: i contenuti e i dati di questo modulo sono aggiornati a ottobre 2026. Alcuni elementi, come i numeri sulla crescita del calcolo, le stime sull'adozione e le posizioni del ciclo delle aspettative, invecchiano rapidamente: prima di ogni edizione conviene ricontrollarli.");
  }
  {
    const s = content("Obiettivo del modulo", "L'obiettivo formativo del tema è triplice: capire come si è evoluta l'AI, capire perché ha assunto un ruolo centrale proprio ora e capire quali cambiamenti può introdurre nelle attività delle persone e delle organizzazioni. Accanto all'obiettivo di conoscenza c'è un obiettivo di consapevolezza, che è forse il più importante. L'AI è un'evoluzione tecnologica significativa, ma il suo impatto non è automatico: non si produce da solo per il solo fatto che la tecnologia esiste. Non è uniforme: alcune attività, persone e organizzazioni ne beneficiano molto, altre poco o per niente. E non è necessariamente positivo: dipende da come la tecnologia viene scelta, inserita nei processi e governata. In altre parole, il risultato dipende da tre elementi: le capacità della tecnologia, il contesto in cui viene usata e le scelte delle persone. Questo messaggio tornerà più volte nel corso del modulo.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiTarget", head: "Che cosa vogliamo comprendere", headSize: 16,
      body: [{ text: "", options: {} }].concat(bullets([
        "Come si è evoluta l'Intelligenza Artificiale",
        "Perché è diventata centrale negli ultimi anni",
        "Quali cambiamenti può introdurre nelle attività umane e nelle organizzazioni",
      ])).slice(1), bodySize: 14 });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiCompass", head: "Quale consapevolezza sviluppare", headSize: 16, fill: C.accent6,
      body: "L'impatto dell'AI non è automatico, uniforme o necessariamente positivo.\n\nDipende dalle capacità della tecnologia, dal contesto e dalle scelte delle persone e delle organizzazioni.", bodySize: 14 });
  }
  {
    const s = content("Sei domande guida per questo modulo", "Queste sei domande accompagnano tutto il modulo e ne rappresentano la struttura logica. Le prime due riguardano la storia e il contesto: perché se ne parla tanto, e se si tratta davvero di qualcosa di nuovo. La terza riguarda la svolta dell'AI generativa. La quarta chiarisce in che cosa l'AI si differenzia dalle tecnologie digitali che già conosciamo. Le ultime due portano il discorso in azienda: perché ci riguarda e quali aspettative sono ragionevoli. Suggerimento: leggere le domande ad alta voce e chiedere ai partecipanti quale ritengono la più importante per il proprio lavoro. Alla fine del modulo torneremo su queste stesse domande con una risposta sintetica per ciascuna.");
    const qs = [
      "Perché oggi si parla così tanto di Intelligenza Artificiale?",
      "L'AI è una tecnologia nuova?",
      "Che cosa è cambiato con l'arrivo dell'AI generativa?",
      "In che cosa l'AI differisce dalle precedenti tecnologie digitali?",
      "Perché questa evoluzione riguarda anche la mia azienda?",
      "Quali aspettative sono ragionevoli e quali rimangono incerte?",
    ];
    for (let i = 0; i < 6; i++) {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.2 + row * 1.95;
      shapeBox(s, x, y, 2.86, 1.75, C.background2, "domanda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.2, y: y + 0.15, w: 0.6, h: 0.5, fontSize: 24, bold: true, color: C.accent1 });
      txt(s, qs[i], { x: x + 0.2, y: y + 0.65, w: 2.46, h: 1.0, fontSize: 14, color: C.text1 });
    }
  }
  {
    const s = content("Il filo conduttore", "Prima di entrare nei sottotemi, fissiamo il filo conduttore che li lega. Il documento di perimetro indica una consapevolezza di fondo: l'impatto dell'AI non è automatico, uniforme o necessariamente positivo, perché dipende da tre elementi. La tecnologia, cioè che cosa i sistemi sanno fare oggi e come ci sono arrivati: è il tema dei sottotemi 1.1, 1.2 e 1.3. Il contesto, cioè i processi, i dati e le attività in cui la tecnologia viene inserita, e la differenza tra digitalizzazione, automazione e AI: sottotemi 1.4 e 1.5. Le scelte, cioè le decisioni delle persone e delle organizzazioni su dove usarla, come valutarla e quanto fidarsi delle promesse: sottotemi 1.5 e 1.6. Da questo filo discendono tre domande che useremo per tutto il modulo e che ritroveremo nel concetto chiave finale: è tecnicamente possibile? È affidabile, cioè funziona in modo costante sui nostri casi reali? È conveniente, cioè i benefici superano i costi complessivi? Suggerimento: lasciare la slide visibile qualche secondo e chiedere ai partecipanti quale dei tre elementi, secondo loro, oggi conta di più nella loro azienda.");
    const d = [["FiCpu", "Tecnologia", "Che cosa sa fare l'AI e come ci è arrivata", "1.1  1.2  1.3"], ["FiLayers", "Contesto", "Processi, dati e attività in cui viene inserita", "1.4  1.5"], ["FiUsers", "Scelte", "Decisioni di persone e organizzazioni", "1.5  1.6"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 3.07, dark = i === 2;
      shapeBox(s, x, 1.2, 2.86, 2.15, dark ? C.accent1 : C.background2, d[i][1]);
      await iconCircle(s, x + 1.08, 1.32, 0.7, d[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, d[i][1], { x: x + 0.15, y: 2.1, w: 2.56, h: 0.4, fontSize: 16, bold: true, color: dark ? C.background1 : C.text1, align: "center" });
      txt(s, d[i][2], { x: x + 0.15, y: 2.5, w: 2.56, h: 0.5, fontSize: 12, color: dark ? C.background1 : C.text2, align: "center" });
      txt(s, d[i][3], { x: x + 0.15, y: 2.98, w: 2.56, h: 0.3, fontSize: 12, bold: true, color: dark ? C.accent6 : C.accent1, align: "center" });
      if (i < 2) arrow(s, x + 2.88, 2.1, 0.17);
    }
    txt(s, "Tre domande per tutto il modulo", { x: 0.5, y: 3.5, w: 9, h: 0.33, fontSize: 13, bold: true, color: C.text1 });
    [["È possibile?", "Tecnicamente, almeno in una demo"], ["È affidabile?", "Funziona in modo costante sui nostri casi"], ["È conveniente?", "I benefici superano i costi complessivi"]].forEach((q, i) => {
      const x = 0.5 + i * 3.07;
      shapeBox(s, x, 3.9, 2.86, 1.0, C.accent6, "domanda filo " + (i + 1));
      txt(s, q[0], { x: x + 0.15, y: 3.97, w: 2.56, h: 0.4, fontSize: 14, bold: true, color: C.accent1, align: "center" });
      txt(s, q[1], { x: x + 0.15, y: 4.37, w: 2.56, h: 0.45, fontSize: 12, color: C.text1, align: "center" });
    });
  }
  {
    const s = content("Il percorso del modulo", "Il modulo è organizzato in sei sottotemi. I primi due (storia ed evoluzione, fattori dell'accelerazione) servono a contestualizzare: li tratteremo con una profondità media, senza entrare in cronologie storiche dettagliate. Gli ultimi quattro sono quelli a priorità alta: la svolta dell'AI generativa, la distinzione tra digitalizzazione, automazione e AI, la rilevanza per le aziende e infine il confronto tra hype e realtà. Precisare fin da subito i confini: in questo modulo non spiegheremo come funzionano tecnicamente i modelli linguistici (Tema 2), non analizzeremo in dettaglio errori, allucinazioni e bias (Tema 3), non confronteremo prodotti e piattaforme specifiche (Tema 4) e non entreremo nei casi d'uso delle singole funzioni aziendali (le applicazioni per tipo di attività sono nei Temi 8-11) né nella valutazione del valore e delle opportunità (Temi 12 e 15). Quando questi argomenti emergono, possiamo anticiparli con un esempio e rimandarli al tema dedicato.");
    const items = [
      ["1.1", "Storia ed evoluzione dell'AI", "Media"],
      ["1.2", "I fattori dell'accelerazione tecnologica", "Media"],
      ["1.3", "La svolta dell'AI generativa", "Alta"],
      ["1.4", "Dalla digitalizzazione all'Intelligenza Artificiale", "Alta"],
      ["1.5", "Rilevanza dell'AI per le aziende", "Alta"],
      ["1.6", "Tra hype e realtà", "Alta"],
    ];
    txt(s, "Priorità", { x: 8.2, y: 1.12, w: 1.3, h: 0.3, fontSize: 11, color: C.accent2, align: "center" });
    items.forEach((it, i) => {
      const y = 1.45 + i * 0.6;
      shapeBox(s, 0.5, y, 9.0, 0.5, i % 2 ? C.background1 : C.background2, "riga " + it[0]);
      txt(s, it[0], { x: 0.7, y, w: 0.7, h: 0.5, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
      txt(s, it[1], { x: 1.5, y, w: 6.5, h: 0.5, fontSize: 15, color: C.text1, valign: "middle" });
      const hi = it[2] === "Alta";
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 8.35, y: y + 0.1, w: 1.0, h: 0.3, rectRadius: 0.15, fill: { color: hi ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 1 }, objectName: "priorità " + it[0] });
      txt(s, it[2], { x: 8.35, y: y + 0.1, w: 1.0, h: 0.3, fontSize: 11, bold: true, color: hi ? C.background1 : C.accent1, align: "center", valign: "middle" });
    });
  }

  // =====================================================================
  section("1.1 Storia ed evoluzione");
  divider("1.1", "Storia ed evoluzione dell'AI", "L'AI è il risultato di decenni di ricerca, non un'invenzione recente", "Apriamo il primo sottotema. L'obiettivo non è fare una lezione di storia, ma smontare un'idea molto diffusa: che l'Intelligenza Artificiale sia nata con ChatGPT alla fine del 2022. In realtà l'AI ha una storia di oltre settant'anni, fatta di approcci diversi, di periodi di grande entusiasmo e di fasi di disillusione. Conoscere questa traiettoria aiuta a leggere il presente con più equilibrio: molte delle promesse e dei timori di oggi sono già stati formulati in passato. Domanda da porre al gruppo: secondo voi, quando è nata l'Intelligenza Artificiale? Raccogliere le risposte prima di mostrare la slide successiva.");
  {
    const s = content("Le origini: si possono costruire macchine che pensano?", "Le radici dell'AI risalgono agli anni Cinquanta. Nel 1950 il matematico britannico Alan Turing pubblica l'articolo 'Computing Machinery and Intelligence', in cui si chiede se le macchine possano pensare e propone quello che diventerà noto come test di Turing: invece di definire che cosa sia il pensiero, propone di verificare se una macchina riesce a sostenere una conversazione in modo indistinguibile da una persona. Il 31 agosto 1955 John McCarthy, Marvin Minsky, Nathaniel Rochester e Claude Shannon firmano la proposta di un seminario estivo da tenere al Dartmouth College, negli Stati Uniti: in quella proposta compare per la prima volta l'espressione 'Artificial Intelligence'. Il seminario si svolge nell'estate del 1956, ed è tradizionalmente considerato l'atto di nascita della disciplina. L'ipotesi di partenza era molto ambiziosa: che ogni aspetto dell'apprendimento e dell'intelligenza potesse, in linea di principio, essere descritto in modo così preciso da poter essere simulato da una macchina. Questa ambizione iniziale spiega anche le aspettative molto alte, e in parte deluse, dei decenni successivi. Curiosità utile: il test di Turing ruota attorno al linguaggio, lo stesso terreno su cui oggi l'AI generativa ha raggiunto la massima visibilità.");
    await card(s, 0.5, 1.2, 4.35, 3.75, { icon: "FiBookOpen", head: "1950: Alan Turing", headSize: 17,
      body: "Nell'articolo \"Computing Machinery and Intelligence\" si chiede se le macchine possano pensare.\n\nPropone un criterio pratico: una macchina che conversa in modo indistinguibile da una persona (il \"gioco dell'imitazione\").", bodySize: 14 });
    await card(s, 5.15, 1.2, 4.35, 3.75, { icon: "FiUsers", head: "1955-1956: Dartmouth College", headSize: 17,
      body: "Nel 1955 McCarthy, Minsky, Rochester e Shannon propongono un seminario sull'\"Artificial Intelligence\", che si tiene nell'estate 1956: nasce la disciplina.\n\nL'ipotesi: ogni aspetto dell'intelligenza può essere descritto e simulato da una macchina.", bodySize: 14 });
  }
  {
    const s = content("Oltre settant'anni di evoluzione", "Questa linea del tempo serve a dare un colpo d'occhio sull'intera traiettoria, senza entrare nei dettagli. 1950: Turing pone la domanda sulle macchine pensanti. 1956: con il seminario di Dartmouth nasce la disciplina, il cui nome era stato proposto l'anno prima. 1958: Frank Rosenblatt presenta il perceptron, uno dei primi modelli di neurone artificiale, antenato lontano delle reti neurali di oggi. Anni Settanta e Ottanta: si diffondono i sistemi esperti, che codificano la conoscenza di specialisti in regole. 1997: il computer Deep Blue di IBM batte il campione del mondo di scacchi Garry Kasparov, un traguardo simbolico raggiunto però con un sistema altamente specializzato. 2012: una rete neurale profonda (AlexNet) vince nettamente una competizione di riconoscimento delle immagini basata sul dataset ImageNet, segnando la svolta del deep learning. 2017: ricercatori di Google pubblicano l'architettura Transformer, alla base dei moderni modelli linguistici. 2022: il lancio pubblico di ChatGPT porta l'AI generativa al grande pubblico. Messaggio: ciò che vediamo oggi è l'ultimo tratto di una lunga strada.");
    const ms = [
      ["1950", "Turing: le macchine possono pensare?"],
      ["1956", "Dartmouth: nasce la disciplina"],
      ["1958", "Perceptron: primo neurone artificiale"],
      ["Anni '70-'80", "Diffusione dei sistemi esperti"],
      ["1997", "Deep Blue batte Kasparov a scacchi"],
      ["2012", "Svolta del deep learning nelle immagini"],
      ["2017", "Architettura Transformer"],
      ["2022", "ChatGPT porta l'AI generativa al pubblico"],
    ];
    const x0 = 1.27, step = 1.065, ly = 3.05;
    s.addShape(pres.shapes.LINE, { x: 0.5, y: ly, w: 9.0, h: 0, line: { color: C.accent3, width: 2 }, objectName: "linea del tempo" });
    ms.forEach((m, i) => {
      const cx = x0 + i * step;
      const up = i % 2 === 0;
      s.addShape(pres.shapes.OVAL, { x: cx - 0.11, y: ly - 0.11, w: 0.22, h: 0.22, fill: { color: i === 7 ? C.accent1 : C.background1 }, line: { color: C.accent1, width: 2 }, objectName: "tappa " + m[0] });
      s.addShape(pres.shapes.LINE, { x: cx, y: up ? ly - 0.55 : ly + 0.11, w: 0, h: 0.44, line: { color: C.accent3, width: 1 }, objectName: "connettore " + m[0] });
      const bx = cx - 0.72;
      txt(s, m[0], { x: bx, y: up ? 1.25 : 3.65, w: 1.44, h: 0.32, fontSize: 14, bold: true, color: C.accent1, align: "center" });
      txt(s, m[1], { x: bx, y: up ? 1.57 : 3.97, w: 1.44, h: 0.9, fontSize: 12, color: C.text2, align: "center" });
    });
  }
  {
    const s = content("L'AI simbolica: la conoscenza scritta in regole", "Per i primi decenni l'approccio dominante è stato quello dell'AI simbolica, detta anche AI basata su regole. L'idea è semplice: se un esperto sa risolvere un problema, possiamo intervistarlo, tradurre la sua conoscenza in regole esplicite del tipo 'se si verifica questa condizione, allora fai quest'altra cosa' e affidarle a un computer. Negli anni Settanta e Ottanta questo approccio ha prodotto i sistemi esperti, impiegati per esempio nella diagnosi medica (il sistema MYCIN, sviluppato a Stanford, suggeriva terapie antibiotiche) o nella configurazione di sistemi informatici. Punti di forza: il comportamento è trasparente e controllabile, perché si può sempre risalire alla regola che ha prodotto una decisione. Limiti: scrivere e mantenere migliaia di regole è costoso; i sistemi sono fragili quando incontrano situazioni non previste; e molta conoscenza umana è difficile da esplicitare. Pensate a quanto sarebbe difficile scrivere le regole per riconoscere un volto o per capire il tono di una email. Ancora oggi i sistemi a regole sono molto usati, per esempio nei motori di regole dei software gestionali: non sono un approccio superato, ma uno strumento adatto a certi problemi.");
    // diagram: esperto -> regole -> sistema
    const steps = [["FiUser", "Esperto umano", "Conosce il dominio"], ["FiList", "Regole esplicite", "SE condizione ALLORA azione"], ["FiCpu", "Sistema esperto", "Applica le regole ai casi"]];
    for (let i = 0; i < 3; i++) {
      const x = 0.5 + i * 1.62;
      await iconCircle(s, x + 0.35, 1.25, 0.6, steps[i][0]);
      txt(s, steps[i][1], { x: x - 0.05, y: 1.95, w: 1.4, h: 0.3, fontSize: 13, bold: true, color: C.text1, align: "center" });
      txt(s, steps[i][2], { x: x - 0.05, y: 2.27, w: 1.4, h: 0.55, fontSize: 11, color: C.text2, align: "center" });
      if (i < 2) arrow(s, x + 1.2, 1.4, 0.35);
    }
    shapeBox(s, 0.5, 3.05, 4.5, 1.9, C.background2, "esempio regola");
    txt(s, "Esempio di regola", { x: 0.7, y: 3.2, w: 4.1, h: 0.3, fontSize: 13, bold: true, color: C.accent1 });
    txt(s, "SE la fattura supera 10.000 euro\nE il fornitore è nuovo\nALLORA richiedi approvazione del responsabile", { x: 0.7, y: 3.55, w: 4.1, h: 1.2, fontSize: 14, color: C.text1, fontFace: "Courier New" });
    await card(s, 5.3, 1.2, 4.2, 1.75, { head: "Punti di forza", body: bullets(["Comportamento trasparente e verificabile", "Prevedibile: stesse condizioni, stessa risposta"], { space: 2 }), bodySize: 13 });
    await card(s, 5.3, 3.1, 4.2, 1.85, { head: "Limiti", body: bullets(["Costoso scrivere e mantenere le regole", "Fragile davanti a casi non previsti", "Difficile esplicitare conoscenze intuitive"], { space: 2 }), bodySize: 13 });
  }
  {
    const s = content("Cicli di entusiasmo e disillusione", "La storia dell'AI non è stata una crescita lineare. Si sono alternate fasi di grande entusiasmo, con promesse ambiziose e forti investimenti, e fasi di disillusione, chiamate 'inverni dell'AI', in cui i finanziamenti e l'interesse sono crollati perché i risultati non erano all'altezza delle aspettative. Il primo inverno si colloca indicativamente a metà degli anni Settanta, dopo che le previsioni dei pionieri (macchine intelligenti come l'uomo entro pochi decenni) si erano rivelate irrealistiche. Il secondo arriva tra la fine degli anni Ottanta e l'inizio dei Novanta, quando i sistemi esperti si dimostrano costosi e difficili da mantenere. Dagli anni Novanta il Machine Learning riprende quota, e dal 2012 il deep learning avvia la fase di crescita attuale, accelerata ulteriormente nel 2022 dall'AI generativa. Precisare che il grafico è qualitativo: rappresenta l'andamento indicativo dell'interesse e degli investimenti, non una misura precisa. L'asse del tempo è a intervalli regolari, un punto ogni cinque anni dal 1955 a oggi. La lezione per noi: aspettative eccessive e delusioni fanno parte della storia di questa tecnologia. Ne riparleremo nel sottotema 1.6, dedicato a hype e realtà. L'hype cycle è ripreso anche nel Tema 16, a proposito dell'adozione.");
    s.addChart(pres.charts.LINE, [{ name: "Interesse e investimenti (indicativo)", labels: ["", "1960", "", "1970", "", "1980", "", "1990", "", "2000", "", "2010", "", "2020", ""], values: [2.5, 5, 6, 4.2, 2, 4.5, 7.5, 2.5, 3.0, 3.6, 4.2, 5.2, 6.8, 8, 10] }], {
      x: 0.5, y: 1.15, w: 9.0, h: 3.0, lineSize: 3, lineDataSymbol: "none", lineSmooth: true, chartColors: [HEX.a1],
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valGridLine: { style: "none" }, catGridLine: { style: "none" },
      showLegend: false, showValue: false, valAxisMinVal: 0, valAxisMaxVal: 11, catAxisLineShow: true, catAxisLineColor: HEX.a3,
    });
    txt(s, "Primo inverno", { x: 2.53, y: 3.5, w: 1.5, h: 0.3, fontSize: 12, bold: true, color: C.accent5, align: "center" });
    txt(s, "Secondo inverno", { x: 4.19, y: 3.5, w: 1.6, h: 0.3, fontSize: 12, bold: true, color: C.accent5, align: "center" });
    const labels = [["Pionieri e grandi promesse", 0.5], ["Sistemi esperti", 3.5], ["Machine Learning", 5.4], ["Deep learning e AI generativa", 7.3]];
    labels.forEach(l => txt(s, l[0], { x: l[1], y: 4.3, w: 2.2, h: 0.3, fontSize: 12, color: C.text2, align: "left" }));
    txt(s, "Andamento qualitativo, a scopo illustrativo", { x: 0.5, y: 4.75, w: 5, h: 0.3, fontSize: 10, italic: true, color: C.accent2 });
  }
  {
    const s = content("Dalle regole all'apprendimento dai dati", "Questa è probabilmente la distinzione concettuale più importante del sottotema. Nella programmazione tradizionale, e nell'AI simbolica, sono le persone a scrivere le regole: il programmatore fornisce al computer regole e dati, e il computer produce le risposte. Con il Machine Learning il paradigma si inverte: forniamo al sistema moltissimi esempi, cioè dati accompagnati dalle risposte corrette, e il sistema ricava da solo le regolarità che collegano gli uni alle altre. Il risultato dell'addestramento è un modello, che possiamo poi usare su casi nuovi. Esempio concreto: per filtrare lo spam con le regole dovremmo elencare tutte le parole sospette e aggiornarle continuamente. Con il Machine Learning mostriamo al sistema migliaia di email già etichettate come spam o non spam, e il sistema impara a riconoscerle. Questo approccio funziona molto bene proprio dove le regole sono difficili da scrivere: riconoscere immagini, comprendere il linguaggio, prevedere comportamenti. Non approfondiamo qui il meccanismo dell'apprendimento: lo vedremo nel Tema 2.");
    const rowY = [1.45, 3.35];
    const heads = ["Programmazione tradizionale e AI a regole", "Machine Learning"];
    const ins = [["Regole scritte da persone", "Dati"], ["Dati", "Risposte corrette (esempi)"]];
    const outs = [["Programma", "Risposte"], ["Addestramento", "Modello: regole apprese"]];
    for (let r = 0; r < 2; r++) {
      const y = rowY[r];
      txt(s, heads[r], { x: 0.5, y: y - 0.3, w: 6, h: 0.3, fontSize: 14, bold: true, color: r ? C.accent1 : C.text1 });
      shapeBox(s, 0.5, y + 0.1, 2.3, 0.55, C.background2, "input a");
      txt(s, ins[r][0], { x: 0.55, y: y + 0.1, w: 2.2, h: 0.55, fontSize: 13, color: C.text1, align: "center", valign: "middle" });
      txt(s, "+", { x: 0.5, y: y + 0.66, w: 2.3, h: 0.3, fontSize: 14, bold: true, color: C.accent2, align: "center" });
      shapeBox(s, 0.5, y + 0.95, 2.3, 0.55, C.background2, "input b");
      txt(s, ins[r][1], { x: 0.55, y: y + 0.95, w: 2.2, h: 0.55, fontSize: 13, color: C.text1, align: "center", valign: "middle" });
      arrow(s, 3.0, y + 0.64, 0.6);
      shapeBox(s, 3.8, y + 0.45, 2.2, 0.7, r ? C.accent1 : C.text2, "processo");
      txt(s, outs[r][0], { x: 3.85, y: y + 0.45, w: 2.1, h: 0.7, fontSize: 14, bold: true, color: C.background1, align: "center", valign: "middle" });
      arrow(s, 6.2, y + 0.64, 0.6);
      shapeBox(s, 7.0, y + 0.45, 2.5, 0.7, r ? C.accent6 : C.background2, "output");
      txt(s, outs[r][1], { x: 7.05, y: y + 0.45, w: 2.4, h: 0.7, fontSize: 14, bold: true, color: C.text1, align: "center", valign: "middle" });
    }
  }
  {
    const s = content("Machine Learning e Deep Learning", "Machine Learning e Deep Learning sono spesso usati come sinonimi, ma il secondo è un sottoinsieme del primo, che a sua volta è un sottoinsieme dell'AI. L'Intelligenza Artificiale è il campo più ampio: comprende qualsiasi tecnica che permetta a una macchina di svolgere compiti che associamo all'intelligenza, inclusi i sistemi a regole. Il Machine Learning comprende le tecniche in cui il sistema apprende dai dati invece di seguire regole scritte a mano; si diffonde soprattutto dagli anni Novanta in applicazioni come il filtro antispam, i sistemi di raccomandazione o la valutazione del rischio di credito. Il Deep Learning usa reti neurali artificiali con molti strati (da qui 'profondo'), capaci di apprendere direttamente da dati grezzi come immagini, suoni e testi. Le reti neurali esistevano da decenni, ma è attorno al 2012 che, grazie a più dati e più potenza di calcolo, iniziano a superare nettamente gli altri approcci, prima nel riconoscimento delle immagini e poi nel riconoscimento vocale e nella traduzione automatica. L'AI generativa di oggi è costruita su questa base. Il Tema 2 approfondirà queste categorie e la loro classificazione.");
    // nested shapes
    s.addShape(pres.shapes.OVAL, { x: 0.5, y: 1.15, w: 4.9, h: 3.85, fill: { color: C.background2 }, line: { color: C.accent3, width: 1 }, objectName: "insieme AI" });
    s.addShape(pres.shapes.OVAL, { x: 1.2, y: 1.85, w: 3.7, h: 2.95, fill: { color: C.accent6 }, line: { color: C.accent1, width: 1 }, objectName: "insieme ML" });
    s.addShape(pres.shapes.OVAL, { x: 1.95, y: 2.65, w: 2.5, h: 1.95, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "insieme DL" });
    txt(s, "Intelligenza Artificiale", { x: 1.2, y: 1.38, w: 3.5, h: 0.35, fontSize: 14, bold: true, color: C.text1, align: "center" });
    txt(s, "Machine Learning", { x: 1.6, y: 2.12, w: 2.9, h: 0.35, fontSize: 14, bold: true, color: C.accent1, align: "center" });
    txt(s, "Deep Learning", { x: 2.0, y: 3.4, w: 2.4, h: 0.4, fontSize: 15, bold: true, color: C.background1, align: "center" });
    const rows = [
      ["Intelligenza Artificiale", "Campo ampio: tecniche che svolgono compiti associati all'intelligenza, comprese le regole"],
      ["Machine Learning", "Il sistema apprende dai dati. Diffuso dagli anni '90: antispam, raccomandazioni, rischio di credito"],
      ["Deep Learning", "Reti neurali a molti strati. Dal 2012 svolta in immagini, voce, traduzione"],
    ];
    rows.forEach((r, i) => {
      const y = 1.25 + i * 1.25;
      txt(s, r[0], { x: 5.8, y, w: 3.7, h: 0.32, fontSize: 15, bold: true, color: i ? C.accent1 : C.text1 });
      txt(s, r[1], { x: 5.8, y: y + 0.35, w: 3.7, h: 0.8, fontSize: 13, color: C.text2 });
    });
  }
  {
    const s = content("Dall'AI specializzata all'AI generativa", "Fino a pochi anni fa la quasi totalità dei sistemi AI era specializzata: un modello addestrato per un compito preciso, come riconoscere difetti su una linea di produzione, prevedere la domanda di un prodotto o filtrare lo spam. Ciascuno richiedeva dati specifici, competenze tecniche e un progetto dedicato. Con l'AI generativa compare un nuovo tipo di sistema: modelli addestrati su enormi quantità di dati, capaci di svolgere molti compiti diversi (scrivere, riassumere, tradurre, analizzare, generare codice) e di essere guidati semplicemente con istruzioni in linguaggio naturale. Sono spesso chiamati modelli di base o modelli fondazionali, perché fanno da base per molte applicazioni. Attenzione però a due equivoci. Primo: l'AI specializzata non scompare, anzi resta la soluzione migliore per molti problemi aziendali. Secondo: la versatilità dei modelli generativi non equivale a un'intelligenza generale paragonabile a quella umana. L'AGI, l'intelligenza artificiale generale, è oggi un tema di dibattito e di ricerca, non una realtà acquisita; ne parleremo nel sottotema 1.6 e il concetto sarà definito meglio nel Tema 2.");
    await card(s, 0.5, 1.2, 4.0, 3.75, { icon: "FiCrosshair", head: "AI specializzata", headSize: 17, bodySize: 14,
      body: bullets(["Un modello per un compito preciso", "Dati e progetto dedicati", "Esempi: controllo qualità visivo, previsione della domanda, filtro antispam", "Ancora oggi molto diffusa ed efficace"], { space: 4 }) });
    arrow(s, 4.65, 2.9, 0.7, C.accent1);
    await card(s, 5.5, 1.2, 4.0, 3.75, { icon: "FiLayers", head: "AI generativa", headSize: 17, bodySize: 14, fill: C.accent6,
      body: bullets(["Un modello per molti compiti diversi", "Guidata con istruzioni in linguaggio naturale", "Esempi: scrivere, riassumere, tradurre, analizzare, generare codice", "Versatile, ma non \"intelligenza generale\""], { space: 4 }) });
  }
  keySlide("L'AI è il risultato di decenni di ricerca ed evoluzione tecnologica, non un'invenzione recente.", "Sottotema 1.1  ·  Storia ed evoluzione dell'AI", "Chiudiamo il primo sottotema con il concetto chiave. Quello che oggi chiamiamo AI generativa è l'ultima fase di un percorso lungo oltre settant'anni, fatto di approcci diversi (regole, apprendimento dai dati, reti neurali profonde) e di cicli di entusiasmo e disillusione. Tre messaggi da fissare: primo, l'AI non è nuova, è nuova la sua diffusione; secondo, non esiste un solo tipo di AI, e approcci diversi convivono ancora oggi; terzo, la storia insegna che le aspettative vanno calibrate. Domanda di verifica: qualcuno sa indicare un sistema AI che usava già prima del 2022 senza saperlo? Esempi tipici: filtro antispam, suggerimenti di acquisto, navigatore, riconoscimento facciale dello smartphone, traduzione automatica.");

  // =====================================================================
  section("1.2 Fattori dell'accelerazione");
  divider("1.2", "I fattori dell'accelerazione tecnologica", "Perché proprio ora? La convergenza di più fattori, non una singola invenzione", "Se l'AI esiste da decenni, perché la sua accelerazione è avvenuta proprio negli ultimi anni? La risposta non è una singola scoperta geniale, ma la convergenza di cinque fattori che sono maturati più o meno nello stesso periodo e si sono rafforzati a vicenda. È un po' come per lo smartphone: nessuno dei suoi componenti era una novità assoluta, ma la loro combinazione al momento giusto ha cambiato le abitudini di miliardi di persone.");
  {
    const s = content("Cinque fattori che si rafforzano a vicenda", "Ecco i cinque fattori. La potenza di calcolo, grazie soprattutto ai processori grafici (GPU) e al cloud. I dati, resi disponibili in quantità enormi dalla digitalizzazione e da internet. Gli algoritmi e le architetture, migliorati in modo decisivo, con l'architettura Transformer del 2017 come tappa cruciale. I modelli di grandi dimensioni, resi possibili dalla combinazione dei tre fattori precedenti. Infine gli investimenti e le infrastrutture, cioè i capitali, i data center e gli ecosistemi industriali che hanno permesso di passare dalla ricerca ai prodotti. Il punto chiave è il rafforzamento reciproco: più dati richiedono più calcolo; più calcolo permette modelli più grandi; risultati migliori attirano più investimenti, che finanziano più calcolo. Nelle prossime slide vediamo brevemente ciascun fattore.");
    const f = [["FiCpu", "Potenza di calcolo", "GPU, chip specializzati, cloud"], ["FiDatabase", "Dati", "Digitalizzazione e internet"], ["FiGitBranch", "Algoritmi e architetture", "Deep learning, Transformer"], ["FiMaximize2", "Modelli di grandi dimensioni", "Più parametri, dati e calcolo"], ["FiServer", "Investimenti e infrastrutture", "Capitali, data center, ecosistemi"]];
    for (let i = 0; i < 5; i++) {
      const x = 0.5 + i * 1.84;
      shapeBox(s, x, 1.25, 1.66, 2.55, C.background2, "fattore " + f[i][1]);
      await iconCircle(s, x + 0.53, 1.45, 0.6, f[i][0]);
      txt(s, f[i][1], { x: x + 0.1, y: 2.2, w: 1.46, h: 0.65, fontSize: 14, bold: true, color: C.text1, align: "center", valign: "middle" });
      txt(s, f[i][2], { x: x + 0.1, y: 2.9, w: 1.46, h: 0.8, fontSize: 12, color: C.text2, align: "center" });
    }
    shapeBox(s, 0.5, 4.05, 9.0, 0.9, C.accent6, "sintesi convergenza");
    await iconCircle(s, 0.7, 4.22, 0.56, "FiRefreshCw");
    txt(s, "Un circolo che si autoalimenta: più dati richiedono più calcolo, il calcolo permette modelli più grandi, i risultati attirano investimenti che finanziano nuovo calcolo.", { x: 1.45, y: 4.1, w: 7.9, h: 0.8, fontSize: 14, color: C.text1, valign: "middle" });
  }
  {
    const s = content("Potenza di calcolo", "Il primo fattore è la potenza di calcolo. Addestrare una rete neurale significa eseguire un numero enorme di operazioni matematiche relativamente semplici, molte delle quali possono essere svolte in parallelo. Le GPU, i processori grafici nati per i videogiochi, si sono rivelate perfette per questo tipo di lavoro, e dal 2012 sono diventate lo strumento standard per il deep learning. Oggi esistono anche chip progettati appositamente per l'AI. Il cloud computing, poi, ha reso questa potenza accessibile a noleggio, senza dover acquistare e gestire infrastrutture proprie. Il dato in evidenza viene da Epoch AI, un istituto di ricerca che monitora l'evoluzione dei modelli: secondo le loro stime, la potenza di calcolo usata per addestrare i modelli di frontiera è cresciuta di circa 4-5 volte all'anno tra il 2010 e il 2024. Per dare un'idea: una crescita di 4 volte all'anno significa moltiplicare per circa mille in cinque anni. Fonte: Epoch AI, 'Training compute of frontier AI models grows by 4-5x per year', 2024. Trattandosi di una stima su un periodo storico, è bene non presentarla come previsione per il futuro.");
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.text1, "callout calcolo");
    txt(s, "4-5x", { x: 0.75, y: 1.5, w: 3.1, h: 1.1, fontSize: 60, bold: true, color: C.accent1 });
    txt(s, "crescita annua stimata della potenza di calcolo usata per addestrare i modelli AI di frontiera (2010-2024)", { x: 0.75, y: 2.7, w: 3.1, h: 1.3, fontSize: 14, color: C.background1 });
    txt(s, "Fonte: Epoch AI, 2024", { x: 0.75, y: 4.4, w: 3.1, h: 0.3, fontSize: 10, color: C.accent3 });
    const pts = [["FiMonitor", "GPU", "Nate per la grafica dei videogiochi, eseguono in parallelo molte operazioni: ideali per le reti neurali"], ["FiCpu", "Chip specializzati", "Processori progettati appositamente per i carichi di lavoro dell'AI"], ["FiCloud", "Cloud", "Potenza di calcolo noleggiabile, senza infrastrutture proprie"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.25 + i * 1.25;
      await iconCircle(s, 4.5, y, 0.55, pts[i][0]);
      txt(s, pts[i][1], { x: 5.25, y: y - 0.02, w: 4.25, h: 0.32, fontSize: 15, bold: true, color: C.text1 });
      txt(s, pts[i][2], { x: 5.25, y: y + 0.32, w: 4.25, h: 0.75, fontSize: 13, color: C.text2 });
    }
  }
  {
    const s = content("Disponibilità di grandi quantità di dati", "Il secondo fattore sono i dati. Le tecniche di Machine Learning, e il deep learning in particolare, hanno bisogno di moltissimi esempi per apprendere. Negli ultimi vent'anni la digitalizzazione di quasi ogni attività ha prodotto una quantità di dati senza precedenti: pagine web, libri digitalizzati, foto e video condivisi, transazioni, dati di sensori e macchinari, documenti aziendali. Un esempio emblematico è ImageNet, un archivio di oltre 14 milioni di immagini etichettate a mano, avviato da ricercatori di Princeton e Stanford alla fine degli anni Duemila: proprio la competizione basata su ImageNet, che usava un sottoinsieme di circa 1,2 milioni di immagini suddivise in mille categorie, ha mostrato nel 2012 la superiorità del deep learning. I modelli linguistici attuali sono addestrati su quantità di testo enormemente superiori. Un messaggio da collegare all'azienda: i dati sono un ingrediente essenziale, ma non basta averne tanti. Contano qualità, pertinenza, rappresentatività e la possibilità legittima di usarli. Il tema dei dati aziendali è approfondito nel Tema 14.");
    const src = [["FiGlobe", "Web e contenuti online"], ["FiBook", "Libri e documenti digitalizzati"], ["FiImage", "Foto, video e audio"], ["FiShoppingCart", "Transazioni e attività online"], ["FiActivity", "Sensori e macchinari"], ["FiFolder", "Archivi aziendali"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 2.75, y = 1.2 + row * 1.0;
      shapeBox(s, x, y, 2.6, 0.85, C.background2, src[i][1]);
      await iconCircle(s, x + 0.15, y + 0.17, 0.5, src[i][0]);
      txt(s, src[i][1], { x: x + 0.78, y, w: 1.75, h: 0.85, fontSize: 13, color: C.text1, valign: "middle" });
    }
    shapeBox(s, 6.2, 1.2, 3.3, 2.8, C.text1, "callout imagenet");
    txt(s, "14 milioni", { x: 6.4, y: 1.35, w: 2.9, h: 0.75, fontSize: 36, bold: true, color: C.accent1 });
    txt(s, "di immagini etichettate in ImageNet. Un suo sottoinsieme, circa 1,2 milioni, è alla base della competizione che nel 2012 ha mostrato la forza del deep learning", { x: 6.4, y: 2.15, w: 2.9, h: 1.75, fontSize: 13, color: C.background1 });
    txt(s, "Non basta la quantità: contano qualità, pertinenza, rappresentatività e diritto di utilizzo dei dati.", { x: 0.5, y: 4.3, w: 9.0, h: 0.6, fontSize: 14, italic: true, color: C.text1 });
  }
  {
    const s = content("Evoluzione degli algoritmi e delle architetture", "Il terzo fattore riguarda gli algoritmi, cioè i metodi con cui i modelli apprendono, e le architetture, cioè il modo in cui sono strutturati. Alcune tappe significative. Nel 1986 un articolo di Rumelhart, Hinton e Williams rende popolare la retropropagazione dell'errore (backpropagation), il metodo che ancora oggi permette di addestrare le reti neurali. Negli anni successivi si affermano le reti convoluzionali, particolarmente adatte alle immagini. Nel 2017 un gruppo di ricercatori di Google pubblica l'articolo 'Attention Is All You Need', che introduce l'architettura Transformer: un modo di elaborare il testo che considera le relazioni tra tutte le parole di una frase e che si presta molto bene al calcolo parallelo su larga scala. È la base di quasi tutti i grandi modelli linguistici attuali. Infine, attorno al 2022, si diffondono tecniche di addestramento che usano il feedback umano per rendere i modelli più capaci di seguire istruzioni e di conversare in modo utile. Non serve ricordare i nomi tecnici: il messaggio è che i progressi nei metodi sono stati importanti quanto quelli nell'hardware. Il funzionamento del Transformer sarà ripreso, a livello concettuale, nel Tema 2.");
    const t = [["1986", "Retropropagazione", "Un metodo efficace per addestrare reti neurali a più strati"], ["Anni '90-2010", "Reti convoluzionali", "Architetture adatte a riconoscere schemi nelle immagini"], ["2017", "Transformer", "Elabora le relazioni tra tutte le parole di un testo, su larga scala"], ["2022", "Feedback umano", "Addestramento per seguire istruzioni e conversare in modo utile"]];
    t.forEach((e, i) => {
      const x = 0.5 + i * 2.3;
      shapeBox(s, x, 1.3, 2.1, 3.0, i === 2 ? C.accent6 : C.background2, "tappa " + e[1]);
      txt(s, e[0], { x: x + 0.18, y: 1.45, w: 1.8, h: 0.4, fontSize: 15, bold: true, color: C.accent1 });
      txt(s, e[1], { x: x + 0.18, y: 1.9, w: 1.8, h: 0.6, fontSize: 16, bold: true, color: C.text1 });
      txt(s, e[2], { x: x + 0.18, y: 2.55, w: 1.8, h: 1.6, fontSize: 13, color: C.text2 });
      if (i < 3) arrow(s, x + 2.11, 2.65, 0.18);
    });
    txt(s, "I progressi nei metodi hanno contato quanto quelli nell'hardware.", { x: 0.5, y: 4.5, w: 9, h: 0.4, fontSize: 14, italic: true, color: C.text1 });
  }
  {
    const s = content("Lo sviluppo di modelli di grandi dimensioni", "Il quarto fattore è la scala. Combinando più calcolo, più dati e architetture efficienti, è diventato possibile addestrare modelli sempre più grandi. La dimensione di un modello si misura spesso in parametri, cioè i valori numerici che il modello regola durante l'addestramento (il concetto verrà spiegato nel Tema 2). Un esempio della crescita: GPT-2, presentato da OpenAI nel 2019, aveva circa 1,5 miliardi di parametri; GPT-3, l'anno successivo, ne aveva 175 miliardi, oltre cento volte di più. Le ricerche sulle cosiddette 'leggi di scala', pubblicate a partire dal 2020, hanno mostrato che aumentando insieme dimensioni del modello, dati e calcolo le prestazioni tendono a migliorare in modo relativamente prevedibile. Questo ha incoraggiato investimenti crescenti. Due precisazioni importanti: primo, più grande non significa automaticamente migliore per ogni uso, e oggi esistono anche modelli più piccoli ed efficienti, adatti a compiti specifici; secondo, molti produttori non rendono più pubbliche le dimensioni dei loro modelli più recenti, quindi i numeri vanno usati solo come illustrazione della tendenza.");
    s.addChart(pres.charts.BAR, [{ name: "Parametri (miliardi)", labels: ["GPT-2 (2019)", "GPT-3 (2020)"], values: [1.5, 175] }], {
      x: 0.5, y: 1.15, w: 4.4, h: 3.4, barDir: "col", chartColors: [HEX.a2, HEX.a1], invertedColors: [HEX.a1], showValue: true, dataLabelPosition: "outEnd", dataLabelColor: HEX.dk1, dataLabelFontSize: 14, dataLabelFontFace: "+mn-lt", dataLabelFormatCode: "General",
      catAxisLabelColor: HEX.dk2, catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false,
      showTitle: true, title: "Parametri, in miliardi", titleFontSize: 13, titleColor: HEX.dk2, titleFontFace: "+mn-lt", barGapWidthPct: 60,
    });
    txt(s, "Fonte: Radford et al. 2019; Brown et al. 2020", { x: 0.5, y: 4.65, w: 4.4, h: 0.3, fontSize: 10, color: C.accent2 });
    await card(s, 5.2, 1.2, 4.3, 1.75, { inline: true, icon: "FiTrendingUp", head: "Leggi di scala", bodySize: 13, body: "Aumentando insieme modello, dati e calcolo le prestazioni migliorano in modo relativamente prevedibile" });
    await card(s, 5.2, 3.15, 4.3, 1.8, { inline: true, icon: "FiAlertCircle", head: "Più grande non è sempre meglio", bodySize: 13, body: "Esistono anche modelli piccoli ed efficienti per compiti specifici. Molte dimensioni oggi non sono pubbliche" });
  }
  {
    const s = content("Investimenti e infrastrutture tecnologiche", "Il quinto fattore è economico e industriale. Addestrare e far funzionare i grandi modelli richiede capitali ingenti: data center, chip, energia, competenze specialistiche. Negli ultimi anni le grandi aziende tecnologiche e numerose startup hanno investito somme molto elevate, e attorno all'AI è nato un intero ecosistema: produttori di chip, fornitori di cloud, sviluppatori di modelli, aziende che costruiscono applicazioni sopra i modelli, consulenti e integratori. Un aspetto importante per le aziende utenti: grazie a questo ecosistema, le capacità AI arrivano sotto forma di servizi pronti, accessibili via abbonamento o tramite API, cioè interfacce che permettono ai software di comunicare tra loro, senza dover costruire nulla da zero. Evitare in aula di citare cifre puntuali sugli investimenti, che cambiano molto rapidamente: se servono numeri aggiornati, verificarli poco prima della sessione. Va anche ricordato che l'infrastruttura dell'AI ha costi e impatti rilevanti, per esempio in termini di consumo energetico: è un tema emergente da tenere presente.");
    const layers = [["FiPackage", "Applicazioni e servizi", "Assistenti, funzioni AI integrate nei software, soluzioni verticali"], ["FiLayers", "Modelli", "Modelli sviluppati da aziende e centri di ricerca, accessibili via API o abbonamento"], ["FiCloud", "Cloud e data center", "Infrastrutture che ospitano addestramento e utilizzo dei modelli"], ["FiCpu", "Chip ed energia", "Hardware specializzato e risorse energetiche"]];
    for (let i = 0; i < 4; i++) {
      const y = 1.2 + i * 0.95;
      const inset = i * 0.25;
      shapeBox(s, 0.5 + inset, y, 5.4 - 2 * inset, 0.8, i === 0 ? C.accent1 : C.background2, "livello " + layers[i][1]);
      txt(s, layers[i][1], { x: 0.5 + inset, y, w: 5.4 - 2 * inset, h: 0.8, fontSize: 15, bold: true, color: i === 0 ? C.background1 : C.text1, align: "center", valign: "middle" });
    }
    txt(s, "La filiera dell'AI", { x: 0.5, y: 4.95, w: 5.4, h: 0.25, fontSize: 10, color: C.accent2, align: "center" });
    await card(s, 6.2, 1.2, 3.3, 1.85, { inline: true, icon: "FiBriefcase", head: "Per le aziende utenti", bodySize: 13, body: "Le capacità AI arrivano come servizi pronti: abbonamenti, funzioni integrate, API" });
    await card(s, 6.2, 3.2, 3.3, 1.75, { inline: true, icon: "FiZap", head: "Costi e impatti", bodySize: 13, body: "Infrastrutture costose ed energivore: un tema emergente da considerare" });
  }
  keySlide("L'accelerazione deriva dalla convergenza di diversi fattori, non da una singola invenzione.", "Sottotema 1.2  ·  I fattori dell'accelerazione tecnologica", "Riassumiamo. Calcolo, dati, algoritmi, scala dei modelli e investimenti sono maturati insieme e si sono alimentati a vicenda. Nessuno di questi fattori, da solo, avrebbe prodotto l'accelerazione che osserviamo. Questa lettura ha una conseguenza pratica: poiché l'evoluzione dipende da più fattori, anche il suo ritmo futuro dipende da come questi evolveranno (disponibilità di dati di qualità, costi dell'energia e del calcolo, nuove scoperte nei metodi, sostenibilità degli investimenti). Per questo, come vedremo nel sottotema 1.6, è prudente distinguere ciò che è osservabile oggi dalle previsioni sul futuro.");

  // =====================================================================
  section("1.3 La svolta generativa");
  divider("1.3", "La svolta dell'AI generativa", "Dall'AI che classifica e prevede all'AI che genera contenuti, usando il linguaggio naturale", "Entriamo in uno dei sottotemi a priorità alta. L'AI generativa non ha soltanto aggiunto nuove capacità tecniche: ha cambiato chi può usare l'AI e come. Fino a pochi anni fa l'AI era qualcosa che lavorava dietro le quinte, progettato da specialisti. Oggi chiunque può interagire direttamente con un sistema AI scrivendo una frase. È questa combinazione di nuove capacità e accessibilità che spiega la centralità attuale del tema.");
  {
    const s = content("Dal classificare e prevedere al generare", "Gran parte dell'AI tradizionale svolge compiti di analisi: classifica (questa email è spam o no? questo pezzo è difettoso o no?) oppure prevede (quanto venderemo il mese prossimo? qual è la probabilità che questo cliente abbandoni il servizio?). L'output è un'etichetta, un numero, una probabilità. L'AI generativa produce invece contenuti nuovi: un testo, un'immagine, un frammento di codice, una sintesi, una traduzione. Contenuti che non esistevano prima nella forma in cui vengono prodotti, anche se derivano da ciò che il modello ha appreso. È importante sottolineare che le due famiglie non sono in competizione: in azienda convivono e spesso si combinano. Un sistema predittivo può individuare i clienti a rischio di abbandono, e un sistema generativo può aiutare a preparare un messaggio personalizzato per ciascuno di loro, che una persona poi verifica. La classificazione più precisa tra AI predittiva, discriminativa e generativa sarà affrontata nel Tema 2.");
    await card(s, 0.5, 1.2, 4.3, 3.75, { icon: "FiBarChart2", head: "AI che classifica e prevede", headSize: 16, bodySize: 13,
      body: [{ text: "Output: un'etichetta, un numero, una probabilità", options: { bold: true, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["Questa email è spam?", "Questo pezzo è difettoso?", "Quanto venderemo il mese prossimo?", "Questo cliente rischia di abbandonarci?"], { space: 3 })) });
    arrow(s, 4.95, 2.9, 0.55, C.accent1);
    await card(s, 5.65, 1.2, 3.85, 3.75, { icon: "FiEdit3", head: "AI che genera", headSize: 16, bodySize: 13, fill: C.accent6,
      body: [{ text: "Output: un contenuto nuovo", options: { bold: true, breakLine: true, paraSpaceAfter: 8 } }].concat(bullets(["Scrivi una bozza di risposta", "Riassumi questo documento", "Traduci questa offerta", "Proponi tre titoli per l'articolo"], { space: 3 })) });
  }
  {
    const s = content("Il linguaggio naturale diventa l'interfaccia", "Questo è il cuore della svolta. La storia dell'informatica può essere letta anche come una storia delle interfacce, cioè di come le persone comunicano con i computer. All'inizio servivano comandi testuali precisi, da imparare a memoria. Poi le interfacce grafiche, con finestre, icone e mouse, hanno reso il computer accessibile a milioni di persone. Gli schermi touch e le app hanno fatto lo stesso con gli smartphone. Con l'AI generativa l'interfaccia diventa il linguaggio naturale: possiamo chiedere ciò che ci serve con parole nostre, in italiano, senza conoscere comandi o linguaggi di programmazione, e possiamo correggere e affinare la richiesta come in una conversazione. Questo abbassa drasticamente la barriera d'ingresso. Attenzione però: scrivere in linguaggio naturale è facile, scrivere richieste efficaci è una competenza che si impara. Il dialogo con l'AI e le tecniche per formulare buone richieste sono approfonditi nei Temi 5 e 6.");
    const st = [["FiTerminal", "Riga di comando", "Comandi precisi da memorizzare"], ["FiMonitor", "Interfaccia grafica", "Finestre, icone, mouse"], ["FiSmartphone", "Touch e app", "Gesti intuitivi, sempre con sé"], ["FiMessageCircle", "Linguaggio naturale", "Chiediamo con parole nostre"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.33;
      const last = i === 3;
      shapeBox(s, x, 1.3, 2.05, 2.6, last ? C.accent1 : C.background2, st[i][1]);
      await iconCircle(s, x + 0.72, 1.5, 0.62, st[i][0], last ? C.background1 : C.accent1, last ? HEX.a1 : HEX.lt1);
      txt(s, st[i][1], { x: x + 0.12, y: 2.3, w: 1.81, h: 0.6, fontSize: 15, bold: true, color: last ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, st[i][2], { x: x + 0.12, y: 2.95, w: 1.81, h: 0.8, fontSize: 13, color: last ? C.background1 : C.text2, align: "center" });
      if (i < 3) arrow(s, x + 2.07, 2.45, 0.24);
    }
    txt(s, "Scrivere una richiesta è facile; scriverne una efficace è una competenza che si impara.", { x: 0.5, y: 4.25, w: 9, h: 0.5, fontSize: 14, italic: true, color: C.text1 });
  }
  {
    const s = content("La diffusione di chatbot e assistenti AI", "Il 30 novembre 2022 OpenAI rende disponibile al pubblico ChatGPT. Nel giro di poche settimane il servizio raggiunge milioni di utenti; secondo stime riportate all'epoca dalla stampa (analisi di UBS citata da Reuters, febbraio 2023), circa 100 milioni di utenti mensili in due mesi, un ritmo di adozione mai visto prima per un'applicazione consumer. Nei mesi e negli anni successivi altri sviluppatori hanno lanciato i propri assistenti, e le funzioni di AI generativa sono state integrate nei software di uso quotidiano: suite di produttività, motori di ricerca, sistemi operativi, strumenti di sviluppo, CRM. Oggi l'AI generativa arriva quindi in tre forme principali: assistenti conversazionali a cui ci si rivolge direttamente; funzioni AI integrate negli strumenti che già usiamo; e servizi accessibili via API, che le aziende incorporano nei propri sistemi. Non ci soffermiamo sui singoli prodotti: il confronto tra modelli e piattaforme è oggetto del Tema 4. Se necessario, aggiornare i riferimenti alla situazione del mercato al momento della sessione.");
    shapeBox(s, 0.5, 1.2, 3.4, 3.75, C.text1, "callout novembre 2022");
    txt(s, "Novembre 2022", { x: 0.75, y: 1.45, w: 3.0, h: 0.6, fontSize: 28, bold: true, color: C.accent1 });
    txt(s, "Il lancio pubblico di ChatGPT porta l'AI generativa a un pubblico di massa.\n\nSecondo stime dell'epoca, circa 100 milioni di utenti in due mesi.", { x: 0.75, y: 2.15, w: 2.95, h: 2.3, fontSize: 14, color: C.background1 });
    txt(s, "Fonte: stima UBS riportata da Reuters, 2023", { x: 0.75, y: 4.5, w: 3.0, h: 0.3, fontSize: 10, color: C.accent3 });
    txt(s, "Tre forme in cui l'AI generativa arriva a noi", { x: 4.2, y: 1.2, w: 5.3, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const f = [["FiMessageSquare", "Assistenti conversazionali", "Ci si rivolge direttamente al sistema con domande e richieste"], ["FiGrid", "Funzioni integrate", "L'AI compare dentro software già in uso: email, documenti, CRM"], ["FiLink", "Servizi via API", "Le aziende incorporano i modelli nei propri sistemi e prodotti"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.7 + i * 1.1;
      await iconCircle(s, 4.2, y, 0.55, f[i][0]);
      txt(s, f[i][1], { x: 4.95, y: y - 0.03, w: 4.55, h: 0.32, fontSize: 15, bold: true, color: C.text1 });
      txt(s, f[i][2], { x: 4.95, y: y + 0.3, w: 4.55, h: 0.6, fontSize: 13, color: C.text2 });
    }
  }
  {
    const s = content("Che cosa può generare l'AI", "L'AI generativa non si limita al testo. Oggi esistono sistemi in grado di generare testi (email, report, sintesi, traduzioni), immagini a partire da una descrizione, codice informatico, audio e voce sintetica, video, e di lavorare su dati strutturati come tabelle e fogli di calcolo. Molti sistemi sono multimodali, cioè capaci di ricevere e produrre più tipi di contenuto: per esempio descrivere una fotografia, leggere un grafico o trasformare una registrazione in un verbale. È utile far notare che la maturità non è la stessa per tutti i tipi di contenuto, e che qualità e affidabilità variano a seconda del compito: lo vedremo nel sottotema 1.6 e lo approfondiremo nel Tema 3. Domanda per il gruppo: quali di questi tipi di contenuto producete più spesso nel vostro lavoro quotidiano?");
    const g = [["FiFileText", "Testi", "Email, report, sintesi, traduzioni"], ["FiImage", "Immagini", "Illustrazioni e grafiche da una descrizione"], ["FiCode", "Codice", "Programmi, formule, script, query"], ["FiMic", "Audio e voce", "Voce sintetica, trascrizioni"], ["FiFilm", "Video", "Clip e animazioni da testo o immagini"], ["FiTable", "Dati e tabelle", "Analisi, estrazione, strutturazione"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.2 + row * 1.75;
      shapeBox(s, x, y, 2.86, 1.55, C.background2, g[i][1]);
      await iconCircle(s, x + 0.2, y + 0.25, 0.6, g[i][0]);
      txt(s, g[i][1], { x: x + 0.95, y: y + 0.25, w: 1.8, h: 0.4, fontSize: 16, bold: true, color: C.text1 });
      txt(s, g[i][2], { x: x + 0.95, y: y + 0.67, w: 1.8, h: 0.75, fontSize: 13, color: C.text2 });
    }
    txt(s, "Molti sistemi sono multimodali: ricevono e producono più tipi di contenuto.", { x: 0.5, y: 4.75, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Un'AI accessibile a tutti", "Questo è forse il cambiamento più rilevante dal punto di vista organizzativo. Prima dell'AI generativa, per usare l'AI in azienda servivano tipicamente un progetto dedicato, un team di data scientist, dati preparati ad hoc e mesi di sviluppo; gli utenti finali beneficiavano dei risultati, ma non interagivano direttamente con la tecnologia. Oggi qualunque collaboratore, senza competenze informatiche specialistiche, può usare direttamente capacità AI nel proprio lavoro: per scrivere, sintetizzare, analizzare, preparare una presentazione. Questa democratizzazione ha due facce. È un'opportunità, perché moltiplica le persone e le attività che possono beneficiare dell'AI e fa nascere idee di utilizzo dal basso. Ma porta anche nuove responsabilità: se tutti possono usare l'AI, tutti devono saperla usare in modo consapevole, sapere quali dati condividere e come verificare i risultati. Ed è esattamente la ragione per cui esiste questo percorso di AI Literacy.");
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiUsers", head: "Prima", headSize: 16, bodySize: 13,
      body: bullets(["L'AI era progettata da specialisti", "Servivano progetti, dati e mesi di sviluppo", "Gli utenti ne vedevano solo i risultati"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiUser", head: "Oggi", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Chiunque può usarla direttamente", "Basta scrivere una richiesta", "Le idee di utilizzo nascono anche dal basso"], { space: 3 }) });
    shapeBox(s, 0.5, 3.95, 9.0, 1.0, C.text1, "messaggio responsabilità");
    await iconCircle(s, 0.7, 4.17, 0.56, "FiShield", C.accent1);
    txt(s, "Se tutti possono usare l'AI, tutti devono saperla usare in modo consapevole: è lo scopo della AI Literacy.", { x: 1.45, y: 3.95, w: 7.9, h: 1.0, fontSize: 15, color: C.background1, valign: "middle" });
  }
  keySlide("L'AI generativa ha ampliato le persone e le attività che possono utilizzare direttamente capacità AI.", "Sottotema 1.3  ·  La svolta dell'AI generativa", "Fissiamo il concetto chiave. La svolta dell'AI generativa ha due componenti: nuove capacità, cioè la generazione di contenuti, e una nuova accessibilità, grazie al linguaggio naturale come interfaccia. È la seconda componente a spiegare soprattutto perché l'AI è diventata un tema per tutti e non solo per gli specialisti. Domanda di verifica: nel vostro lavoro, quali attività svolgete oggi che, almeno in parte, potrebbero essere supportate da un assistente AI? Prendere nota delle risposte senza approfondire: le applicazioni per tipo di attività sono trattate nei Temi 8-11 e l'individuazione delle opportunità nel Tema 15.");

  // =====================================================================
  section("1.4 Digitalizzazione e AI");
  divider("1.4", "Dalla digitalizzazione all'Intelligenza Artificiale", "Concetti collegati ma distinti, che possono coesistere nello stesso processo", "Un altro sottotema ad alta priorità. Nel linguaggio comune, e talvolta anche nel marketing dei fornitori, digitalizzazione, automazione e AI vengono spesso confusi. Chiarire le differenze ci aiuta a capire che cosa è davvero nuovo nell'AI, a valutare meglio le proposte che riceviamo e a riconoscere che spesso la soluzione migliore a un problema non è l'AI, ma una buona digitalizzazione o una semplice automazione.");
  {
    const s = content("Quattro passaggi di un'evoluzione", "Possiamo descrivere l'evoluzione come quattro passaggi successivi, ciascuno dei quali si appoggia al precedente. Primo, la digitalizzazione: trasformare le informazioni in formato digitale, per esempio passare dalla carta ai documenti elettronici, dagli archivi fisici ai database. Secondo, l'automazione basata su regole: far eseguire al software attività ripetitive secondo regole definite da persone, come inviare automaticamente un sollecito quando una fattura scade. Terzo, i sistemi che apprendono dai dati: il Machine Learning, che ricava le regole dagli esempi e permette di classificare o prevedere. Quarto, l'AI generativa: sistemi che generano, analizzano e trasformano informazioni, anche non strutturate come testi e immagini. Un punto fondamentale: ogni passaggio presuppone i precedenti. Senza dati digitali non c'è automazione, e senza dati di qualità non c'è AI utile. Molte aziende che desiderano 'fare AI' scoprono di dover prima consolidare digitalizzazione e qualità dei dati.");
    const st = [["FiFile", "Digitalizzazione", "Le informazioni diventano digitali"], ["FiSettings", "Automazione a regole", "Il software esegue regole definite da persone"], ["FiTrendingUp", "Apprendimento dai dati", "Il sistema ricava regolarità per classificare e prevedere"], ["FiZap", "AI generativa", "Genera, analizza e trasforma informazioni"]];
    for (let i = 0; i < 4; i++) {
      const x = 0.5 + i * 2.3, h = 2.05 + i * 0.5, y = 4.95 - h;
      shapeBox(s, x, y, 2.15, h, i === 3 ? C.accent1 : (i === 2 ? C.accent6 : C.background2), "gradino " + st[i][1]);
      const dark = i === 3;
      await iconCircle(s, x + 0.2, y + 0.2, 0.5, st[i][0], dark ? C.background1 : C.accent1, dark ? HEX.a1 : HEX.lt1);
      txt(s, (i + 1) + ". " + st[i][1], { x: x + 0.2, y: y + 0.8, w: 1.8, h: 0.6, fontSize: 14, bold: true, color: dark ? C.background1 : C.text1 });
      txt(s, st[i][2], { x: x + 0.2, y: y + 1.4, w: 1.8, h: h - 1.5, fontSize: 12, color: dark ? C.background1 : C.text2 });
    }
    txt(s, "Ogni passaggio si appoggia ai precedenti", { x: 0.5, y: 1.2, w: 4.5, h: 0.35, fontSize: 14, italic: true, color: C.text2 });
  }
  {
    const s = content("Un esempio: la gestione delle richieste dei clienti", "Vediamo come i quattro passaggi possono coesistere nello stesso processo aziendale, usando un esempio semplice: la gestione delle email che i clienti inviano all'assistenza. Digitalizzazione: le email arrivano in una casella condivisa e vengono registrate nel CRM, con lo storico di ogni cliente consultabile. Automazione a regole: una regola invia subito una conferma di ricezione e inoltra all'amministrazione tutte le richieste provenienti da un determinato indirizzo o con determinate parole nell'oggetto. Apprendimento dai dati: un modello addestrato sulle richieste passate classifica ogni nuova email per categoria e urgenza, anche quando non contiene le parole previste dalle regole. AI generativa: un assistente riassume la richiesta, recupera le informazioni pertinenti e propone una bozza di risposta, che l'operatore controlla, modifica e invia. Il messaggio è che non si tratta di alternative: ciascuna tecnologia fa ciò che sa fare meglio. E la persona resta nel processo, con un ruolo diverso. Suggerimento: chiedere ai partecipanti di individuare i quattro livelli in un processo che conoscono bene.");
    const st = [["Digitalizzazione", "Le email arrivano in una casella condivisa e sono registrate nel CRM"], ["Automazione a regole", "Conferma di ricezione automatica e inoltro in base a regole fisse"], ["Apprendimento dai dati", "Un modello classifica ogni richiesta per categoria e urgenza"], ["AI generativa", "Sintesi della richiesta e bozza di risposta"]];
    await iconCircle(s, 0.5, 2.25, 0.8, "FiMail");
    txt(s, "Email del cliente", { x: 0.2, y: 3.1, w: 1.4, h: 0.5, fontSize: 12, bold: true, color: C.text1, align: "center" });
    for (let i = 0; i < 4; i++) {
      const x = 1.65 + i * 1.98;
      shapeBox(s, x, 1.3, 1.83, 2.9, i === 3 ? C.accent6 : C.background2, "fase " + st[i][0]);
      txt(s, String(i + 1), { x: x + 0.15, y: 1.42, w: 0.5, h: 0.45, fontSize: 22, bold: true, color: C.accent1 });
      txt(s, st[i][0], { x: x + 0.15, y: 1.9, w: 1.55, h: 0.65, fontSize: 13, bold: true, color: C.text1 });
      txt(s, st[i][1], { x: x + 0.15, y: 2.58, w: 1.55, h: 1.5, fontSize: 12, color: C.text2 });
    }
    shapeBox(s, 1.65, 4.35, 7.85, 0.6, C.text1, "operatore");
    await iconCircle(s, 1.8, 4.42, 0.46, "FiUserCheck", C.accent1);
    txt(s, "L'operatore verifica, modifica e invia la risposta", { x: 2.45, y: 4.35, w: 6.9, h: 0.6, fontSize: 14, color: C.background1, valign: "middle" });
  }
  {
    const s = content("Software deterministico e sistemi probabilistici", "Questa è una distinzione concettuale che useremo molto nel resto del percorso. Il software tradizionale è deterministico: a parità di input, produce sempre lo stesso output, perché segue istruzioni precise scritte da programmatori. Se una calcolatrice sbaglia, c'è un errore nel programma, che può essere trovato e corretto. I sistemi AI basati sull'apprendimento, e in particolare quelli generativi, sono invece probabilistici: producono l'output più plausibile in base a ciò che hanno appreso e al contesto. Questo significa che possono produrre risposte diverse alla stessa domanda e che possono sbagliare anche quando funzionano 'correttamente', perché un risultato plausibile non è necessariamente un risultato vero. La conseguenza pratica è importante: con il software deterministico ci si può fidare del risultato una volta collaudato il programma; con i sistemi probabilistici occorre una verifica proporzionata all'importanza del risultato. Restiamo a livello generale: il meccanismo della variabilità sarà spiegato nel Tema 2 e le cause degli errori nel Tema 3.");
    const rows = [["", "Software deterministico", "Sistema probabilistico"], ["Logica", "Istruzioni scritte da persone", "Regolarità apprese dai dati"], ["Stesso input", "Sempre lo stesso output", "Output anche diversi"], ["Errori", "Difetti del programma, correggibili", "Risultati plausibili ma non sempre corretti"], ["Verifica", "Collaudo del programma", "Verifica proporzionata all'importanza"], ["Esempi", "Calcolo IVA, gestionale, foglio di calcolo", "Classificazione email, assistente che scrive"]];
    const tbl = rows.map((r, i) => r.map((c, j) => ({ text: c, options: { bold: i === 0 || j === 0, color: i === 0 ? (j === 2 ? C.background1 : (j === 1 ? C.background1 : C.text1)) : C.text1, fill: { color: i === 0 ? (j === 2 ? C.accent1 : (j === 1 ? C.text2 : C.background1)) : (j === 2 ? C.accent6 : (j === 1 ? C.background2 : C.background1)) }, fontSize: 13, valign: "middle", margin: [4, 8, 4, 8] } })));
    s.addTable(tbl, { x: 0.5, y: 1.2, w: 9.0, colW: [1.6, 3.7, 3.7], rowH: 0.56, border: { type: "solid", pt: 1, color: HEX.lt1 } });
  }
  keySlide("Digitalizzazione, automazione e AI sono concetti collegati ma distinti; possono coesistere nello stesso processo aziendale.", "Sottotema 1.4  ·  Dalla digitalizzazione all'Intelligenza Artificiale", "Concetto chiave del sottotema. Tre implicazioni pratiche. Primo: non ogni problema richiede l'AI; spesso una buona digitalizzazione o una semplice regola automatica sono la soluzione più economica e affidabile. Secondo: l'AI ha bisogno delle basi, cioè informazioni digitali e dati di qualità. Terzo: la natura probabilistica dei sistemi AI cambia il modo in cui dobbiamo trattarne i risultati, introducendo la necessità di verifica. Domanda di verifica: quando una proposta viene presentata come 'soluzione AI', quali domande potremmo fare per capire se si tratta davvero di AI o di automazione tradizionale?");

  // =====================================================================
  section("1.5 Rilevanza per le aziende");
  divider("1.5", "Rilevanza dell'AI per le aziende", "Una tecnologia abilitante e trasversale: il valore nasce da applicazioni appropriate a problemi reali", "Arriviamo alla domanda più vicina all'esperienza dei partecipanti: perché tutto questo riguarda la nostra azienda? In questo sottotema vediamo perché l'AI è considerata una tecnologia trasversale, quali effetti potenziali può avere su produttività, qualità e innovazione, come cambia il lavoro e quali implicazioni competitive comporta. Chiuderemo con una distinzione decisiva: quella tra potenziale tecnologico e valore effettivamente realizzato. Ricordare che non entreremo nei casi d'uso specifici di ciascuna funzione né nei metodi di valutazione del valore: le applicazioni per tipo di attività sono nei Temi 8-11, il valore e la valutazione delle opportunità nei Temi 12 e 15.");
  {
    const s = content("Un'applicazione trasversale alle funzioni aziendali", "A differenza di molte tecnologie che riguardano una sola funzione (pensiamo a un software di contabilità o a un sistema di gestione del magazzino), l'AI, e in particolare l'AI generativa, tocca potenzialmente tutte le funzioni, perché quasi tutte lavorano con informazioni, testi, dati e comunicazione. In questa slide ci sono solo esempi indicativi, citati per dare un'idea dell'ampiezza: marketing e comunicazione per la produzione di contenuti; vendite per la preparazione degli incontri e delle offerte; assistenza clienti per lo smistamento e le risposte; risorse umane per gli annunci e la formazione; amministrazione e finanza per l'elaborazione dei documenti; operations e produzione per la manutenzione predittiva e il controllo qualità; IT per lo sviluppo e il supporto; legale e compliance per l'analisi preliminare dei documenti. Non approfondire i singoli casi: le applicazioni per tipo di attività sono nei Temi 8-11, l'individuazione delle opportunità nel Tema 15. Il messaggio è l'ampiezza: proprio perché è trasversale, l'AI richiede consapevolezza diffusa e non solo competenze in un singolo reparto.");
    const f = [["FiSpeaker", "Marketing", "Contenuti e analisi"], ["FiTrendingUp", "Vendite", "Incontri e offerte"], ["FiHeadphones", "Assistenza clienti", "Smistamento e risposte"], ["FiUsers", "Risorse umane", "Annunci, formazione"], ["FiDollarSign", "Amministrazione", "Elaborazione documenti"], ["FiTool", "Produzione", "Manutenzione, qualità"], ["FiCode", "IT", "Sviluppo e supporto"], ["FiShield", "Legale e compliance", "Analisi dei documenti"]];
    for (let i = 0; i < 8; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 0.5 + col * 2.3, y = 1.2 + row * 1.75;
      shapeBox(s, x, y, 2.15, 1.6, C.background2, f[i][1]);
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, f[i][0]);
      txt(s, f[i][1], { x: x + 0.18, y: y + 0.78, w: 1.85, h: 0.35, fontSize: 13, bold: true, color: C.text1, valign: "top" });
      txt(s, f[i][2], { x: x + 0.18, y: y + 1.18, w: 1.85, h: 0.35, fontSize: 12, color: C.text2 });
    }
    txt(s, "Esempi indicativi, a scopo illustrativo.", { x: 0.5, y: 4.75, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.accent2 });
  }
  {
    const s = content("L'AI come tecnologia abilitante", "L'AI è spesso descritta come una tecnologia abilitante, o di uso generale, come lo sono state in passato l'elettricità o internet. Una tecnologia abilitante non è un prodotto in sé, ma una capacità che può essere incorporata in molti contesti diversi, rendendo possibili cose nuove o facendo meglio quelle esistenti. Per l'AI questo vale su quattro piani. Nelle funzioni: supporta il lavoro delle persone nelle diverse aree aziendali, come abbiamo visto. Nei prodotti: può essere incorporata in ciò che l'azienda vende, per esempio un macchinario che segnala in anticipo i propri guasti o un software con funzioni intelligenti. Nei servizi: può cambiare il modo in cui l'azienda serve i clienti, per esempio con un'assistenza disponibile in qualsiasi orario per le richieste più semplici. Nei processi: può ridisegnare il modo in cui il lavoro viene organizzato, non solo velocizzare singoli compiti. Il paragone con l'elettricità è utile anche per un altro motivo: i benefici economici delle grandi tecnologie abilitanti si sono manifestati pienamente solo quando le organizzazioni hanno ripensato i propri processi, e questo ha richiesto tempo.");
    const q = [["FiBriefcase", "Funzioni", "Supporta il lavoro delle persone nelle diverse aree aziendali"], ["FiBox", "Prodotti", "Viene incorporata in ciò che l'azienda vende"], ["FiSmile", "Servizi", "Cambia il modo in cui l'azienda serve i clienti"], ["FiShuffle", "Processi", "Ridisegna l'organizzazione del lavoro, non solo i singoli compiti"]];
    s.addShape(pres.shapes.OVAL, { x: 3.95, y: 2.2, w: 2.1, h: 1.6, fill: { color: C.accent1 }, line: { type: "none" }, objectName: "centro AI" });
    txt(s, "AI\nabilitante", { x: 3.95, y: 2.2, w: 2.1, h: 1.6, fontSize: 16, bold: true, color: C.background1, align: "center", valign: "middle" });
    const pos = [[0.5, 1.2], [6.2, 1.2], [0.5, 3.35], [6.2, 3.35]];
    for (let i = 0; i < 4; i++) {
      const [x, y] = pos[i];
      shapeBox(s, x, y, 3.3, 1.6, C.background2, q[i][1]);
      await iconCircle(s, x + 0.2, y + 0.2, 0.5, q[i][0]);
      txt(s, q[i][1], { x: x + 0.85, y: y + 0.25, w: 2.3, h: 0.4, fontSize: 16, bold: true, color: C.text1 });
      txt(s, q[i][2], { x: x + 0.2, y: y + 0.8, w: 2.95, h: 0.7, fontSize: 13, color: C.text2 });
    }
  }
  {
    const s = content("Capacità AI accessibili tramite strumenti commerciali", "Un elemento che rende l'AI particolarmente rilevante per le aziende di ogni dimensione è il modo in cui oggi è disponibile. Fino a pochi anni fa, adottare l'AI richiedeva di sviluppare modelli propri, con team specializzati e investimenti significativi: una strada percorribile soprattutto dalle grandi organizzazioni. Oggi le capacità AI sono accessibili tramite strumenti commerciali: assistenti disponibili in abbonamento, funzioni AI integrate nei software già in uso, servizi accessibili via API da collegare ai propri sistemi. Questo abbassa le barriere d'ingresso anche per le piccole e medie imprese. Ma accessibile non significa privo di scelte: bisogna decidere quali strumenti adottare, con quali regole d'uso, come proteggere i dati, come formare le persone e come integrare gli strumenti nei processi. Facilità di accesso significa anche rischio di adozione disordinata, per esempio con collaboratori che usano strumenti non autorizzati inserendo dati aziendali: è il fenomeno dello Shadow AI, ripreso nei Temi 16, 17 e 18. Il confronto tra prodotti e piattaforme è oggetto del Tema 4.");
    await card(s, 0.5, 1.2, 4.35, 2.4, { icon: "FiTool", head: "Ieri: costruire", headSize: 16, bodySize: 13,
      body: bullets(["Sviluppare modelli propri", "Team specializzati e investimenti elevati", "Accessibile soprattutto alle grandi aziende"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.4, { icon: "FiShoppingBag", head: "Oggi: adottare", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Assistenti in abbonamento", "Funzioni integrate nei software in uso", "Servizi via API collegabili ai sistemi"], { space: 3 }) });
    txt(s, "Accessibile non significa privo di scelte", { x: 0.5, y: 3.8, w: 9, h: 0.35, fontSize: 15, bold: true, color: C.text1 });
    const ch = ["Quali strumenti", "Quali regole d'uso", "Quali dati condividere", "Quale formazione", "Quale integrazione"];
    ch.forEach((c, i) => {
      const x = 0.5 + i * 1.84;
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 4.25, w: 1.7, h: 0.6, rectRadius: 0.3, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.25 }, objectName: "scelta " + c });
      txt(s, c, { x, y: 4.25, w: 1.7, h: 0.6, fontSize: 12, bold: true, color: C.accent1, align: "center", valign: "middle" });
    });
  }
  {
    const s = content("Effetti potenziali: produttività, qualità, innovazione", "L'AI può produrre effetti su tre dimensioni principali. Produttività: svolgere certe attività in meno tempo, per esempio una prima bozza di documento o la sintesi di materiali lunghi. Qualità: migliorare l'output, per esempio con testi più chiari, controlli più sistematici, analisi più complete. Innovazione: rendere possibili cose prima non praticabili, come nuovi servizi o l'esplorazione rapida di molte alternative. Sottolineare la parola 'potenziali'. Un esempio di evidenza empirica: lo studio di Erik Brynjolfsson, Danielle Li e Lindsey Raymond, pubblicato nel 2025 sul Quarterly Journal of Economics, condotto su 5.172 operatori di assistenza clienti di un'azienda di software, ha rilevato che l'introduzione di un assistente basato su AI generativa ha aumentato in media del 15% il numero di problemi risolti per ora. L'aumento è stato del 36% per gli operatori meno qualificati, mentre per i più qualificati non si è osservato un aumento di produttività. Una precisazione utile se qualcuno conosce lo studio: la prima versione del 2023, ancora molto citata, riportava valori leggermente diversi, 14% e 34%. È un risultato interessante perché mostra due cose: i benefici possono essere reali e misurabili, ma non sono uguali per tutti. È un singolo studio in un contesto specifico: non va generalizzato automaticamente ad altri contesti. Fonte: Brynjolfsson, Li, Raymond, 'Generative AI at Work', The Quarterly Journal of Economics, 140(2), 2025. Lo studio è ripreso nel Tema 12, dedicato alla creazione di valore.");
    const d = [["FiClock", "Produttività", "Svolgere alcune attività in meno tempo"], ["FiAward", "Qualità", "Output più chiari, completi e controllati"], ["FiStar", "Innovazione", "Rendere possibili cose prima non praticabili"]];
    for (let i = 0; i < 3; i++) {
      const y = 1.2 + i * 1.27;
      shapeBox(s, 0.5, y, 4.6, 1.12, C.background2, d[i][1]);
      await iconCircle(s, 0.7, y + 0.28, 0.56, d[i][0]);
      txt(s, d[i][1], { x: 1.45, y: y + 0.15, w: 3.5, h: 0.38, fontSize: 16, bold: true, color: C.text1 });
      txt(s, d[i][2], { x: 1.45, y: y + 0.55, w: 3.5, h: 0.5, fontSize: 13, color: C.text2 });
    }
    shapeBox(s, 5.4, 1.2, 4.1, 3.75, C.text1, "evidenza studio");
    txt(s, "UN ESEMPIO DI EVIDENZA", { x: 5.65, y: 1.35, w: 3.6, h: 0.3, fontSize: 11, bold: true, color: C.accent3, charSpacing: 2 });
    txt(s, "+15%", { x: 5.65, y: 1.7, w: 1.9, h: 0.8, fontSize: 40, bold: true, color: C.accent1 });
    txt(s, "+36%", { x: 7.55, y: 1.7, w: 1.9, h: 0.8, fontSize: 40, bold: true, color: C.background1 });
    txt(s, "problemi risolti per ora, in media", { x: 5.65, y: 2.5, w: 1.8, h: 0.6, fontSize: 12, color: C.background1 });
    txt(s, "per gli operatori meno qualificati", { x: 7.55, y: 2.5, w: 1.8, h: 0.6, fontSize: 12, color: C.background1 });
    txt(s, "5.172 operatori di assistenza clienti con un assistente di AI generativa. Per i più qualificati nessun aumento di produttività.", { x: 5.65, y: 3.2, w: 3.65, h: 1.0, fontSize: 13, color: C.accent3 });
    txt(s, "Fonte: Brynjolfsson, Li, Raymond, QJE, 2025", { x: 5.65, y: 4.5, w: 3.65, h: 0.3, fontSize: 10, color: C.accent2 });
  }
  {
    const s = content("Come evolvono il lavoro e le competenze", "L'impatto dell'AI sul lavoro è uno dei temi che generano più preoccupazioni, ed è giusto affrontarlo con equilibrio. Un primo concetto utile: l'AI agisce soprattutto sulle singole attività, più che sui ruoli nel loro complesso. Un ruolo è fatto di molte attività diverse: alcune possono essere automatizzate, altre supportate dall'AI, altre restano essenzialmente umane, come le relazioni, il giudizio in situazioni complesse e la responsabilità delle decisioni. Un secondo concetto: in molti casi l'AI aumenta le capacità delle persone invece di sostituirle; la persona resta responsabile del risultato, ma cambia il modo in cui lavora. Questo sposta il valore verso competenze come saper formulare bene un problema, valutare criticamente un output, integrare l'AI nel proprio flusso di lavoro e mantenere le competenze di dominio necessarie per accorgersi degli errori. È onesto riconoscere che gli effetti complessivi sull'occupazione sono ancora oggetto di studio e dibattito, e che alcune attività e professioni potranno essere trasformate in modo significativo. Evitare in aula sia rassicurazioni assolute sia scenari catastrofici.");
    txt(s, "Un ruolo è fatto di molte attività", { x: 0.5, y: 1.15, w: 4.5, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const a = [["Attività automatizzabili", C.accent1, C.background1], ["Attività supportate dall'AI", C.accent6, C.text1], ["Attività essenzialmente umane: relazioni, giudizio, responsabilità", C.background2, C.text1]];
    a.forEach((r, i) => {
      const y = 1.6 + i * 1.08;
      shapeBox(s, 0.5, y, 4.4, 0.92, r[1], r[0]);
      txt(s, r[0], { x: 0.7, y, w: 4.0, h: 0.92, fontSize: 14, bold: true, color: r[2], valign: "middle" });
    });
    txt(s, "Competenze che acquistano valore", { x: 5.3, y: 1.15, w: 4.2, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const c = [["FiHelpCircle", "Formulare bene i problemi"], ["FiEye", "Valutare criticamente gli output"], ["FiLayers", "Integrare l'AI nel proprio lavoro"], ["FiBookOpen", "Mantenere la competenza di dominio"]];
    for (let i = 0; i < 4; i++) {
      const y = 1.62 + i * 0.82;
      await iconCircle(s, 5.3, y, 0.5, c[i][0]);
      txt(s, c[i][1], { x: 6.0, y, w: 3.5, h: 0.5, fontSize: 14, color: C.text1, valign: "middle" });
    }
  }
  {
    const s = content("Possibili implicazioni competitive", "L'AI ha anche implicazioni competitive, che è bene considerare senza enfasi eccessiva. Primo: quando una capacità diventa ampiamente disponibile, il suo uso tende a diventare uno standard. Se tutti i concorrenti usano l'AI per rispondere più rapidamente ai clienti, non usarla può diventare uno svantaggio, mentre usarla non è più di per sé un vantaggio. Secondo: il vantaggio duraturo raramente deriva dallo strumento in sé, che è accessibile a tutti, ma da ciò che è specifico dell'azienda: la conoscenza del proprio mercato, la qualità dei propri dati, i processi, le competenze delle persone e la capacità di imparare in fretta. Terzo: possono cambiare le aspettative dei clienti, per esempio sui tempi di risposta o sulla personalizzazione. Quarto: l'AI può abbassare le barriere d'ingresso in alcuni settori, favorendo nuovi concorrenti. Restiamo a livello di consapevolezza: le valutazioni strategiche e organizzative sono oggetto dei Temi 12, 15 e 16. Domanda per il gruppo: nel nostro settore, quali di queste dinamiche vediamo già?");
    const k = [["FiMinusCircle", "Da vantaggio a standard", "Ciò che è disponibile a tutti diventa presto la norma: non usarlo può diventare uno svantaggio"], ["FiKey", "Il vantaggio è in ciò che è specifico", "Conoscenza del mercato, dati, processi, persone, capacità di apprendere"], ["FiUserPlus", "Cambiano le aspettative", "I clienti si abituano a risposte più rapide e personalizzate"], ["FiLogIn", "Nuovi concorrenti", "In alcuni settori si abbassano le barriere d'ingresso"]];
    for (let i = 0; i < 4; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      await card(s, 0.5 + col * 4.65, 1.2 + row * 1.9, 4.35, 1.75, { inline: true, icon: k[i][0], head: k[i][1], body: k[i][2], bodySize: 13, fill: i === 1 ? C.accent6 : C.background2 });
    }
  }
  {
    const s = content("Dal potenziale tecnologico al valore realizzato", "Questa è la slide più importante del sottotema. Il potenziale tecnologico è ciò che l'AI potrebbe fare; il valore realizzato è il beneficio che l'azienda ottiene davvero. Tra i due c'è un percorso con diversi passaggi, e a ciascuno corrisponde un possibile ostacolo. Prima di tutto bisogna individuare un problema reale da risolvere, non adottare l'AI per moda: molti progetti partono dalla tecnologia e cercano poi un problema. Poi la soluzione va integrata nei processi, con dati adeguati e strumenti compatibili. Quindi deve essere adottata dalle persone, che devono sapere come usarla, fidarsi il giusto e trovarla utile. Infine il valore va misurato, confrontando i risultati con la situazione di partenza e tenendo conto anche dei costi, compreso il tempo necessario per verificare gli output. A ogni passaggio parte del potenziale può andare perso: per questo è frequente che le iniziative AI producano meno valore di quanto ci si aspettasse. Non entriamo nei metodi di valutazione del valore, oggetto dei Temi 12 e 15: qui ci interessa la consapevolezza della distanza tra potenziale e valore.");
    const st = [["Potenziale tecnologico", "Ciò che l'AI potrebbe fare", 9.0], ["Problema reale", "Un bisogno concreto e rilevante", 8.0], ["Integrazione nei processi", "Dati, strumenti, flussi di lavoro", 7.0], ["Adozione delle persone", "Competenze, fiducia, utilità percepita", 6.0], ["Valore misurato", "Benefici reali al netto dei costi", 5.0]];
    st.forEach((e, i) => {
      const w = e[2] * 0.62, x = 0.5 + (5.6 - w) / 2, y = 1.2 + i * 0.76;
      const last = i === 4;
      shapeBox(s, x, y, w, 0.64, last ? C.accent1 : (i === 0 ? C.text2 : C.background2), "imbuto " + e[0]);
      txt(s, e[0], { x, y, w, h: 0.64, fontSize: 14, bold: true, color: last || i === 0 ? C.background1 : C.text1, align: "center", valign: "middle" });
      txt(s, e[1], { x: 6.35, y, w: 3.15, h: 0.64, fontSize: 13, color: C.text2, valign: "middle" });
    });
    txt(s, "A ogni passaggio parte del potenziale può andare perso", { x: 0.5, y: 5.0, w: 6.0, h: 0.2, fontSize: 11, italic: true, color: C.accent2 });
  }
  keySlide("L'AI può abilitare cambiamenti in molte aree dell'impresa, ma il valore nasce da applicazioni appropriate a problemi reali.", "Sottotema 1.5  ·  Rilevanza dell'AI per le aziende", "Concetto chiave. L'AI è rilevante per le aziende perché è trasversale, abilitante e oggi facilmente accessibile. Ma la rilevanza non coincide con il valore: il valore nasce quando l'AI viene applicata in modo appropriato a problemi reali, integrata nei processi, adottata dalle persone e misurata. Domanda di verifica: pensando alla nostra azienda, qual è un problema concreto, non una tecnologia, che varrebbe la pena esplorare? Raccogliere gli spunti: potranno essere ripresi nel Tema 15, dedicato all'individuazione delle opportunità.");

  // =====================================================================
  section("1.6 Hype e realtà");
  divider("1.6", "Tra hype e realtà", "Valutare criticamente le promesse dell'AI, distinguendo possibilità tecniche, affidabilità e convenienza", "Ultimo sottotema, a priorità alta. Dopo aver visto l'evoluzione, i fattori, la svolta generativa e la rilevanza per le aziende, è il momento di sviluppare uno strumento indispensabile: il giudizio critico. Attorno all'AI circolano promesse entusiastiche e timori catastrofici, spesso amplificati dai media e dagli interessi commerciali. L'obiettivo non è essere scettici o entusiasti a priori, ma imparare a distinguere ciò che è dimostrato da ciò che è promesso, e ciò che è possibile da ciò che è affidabile e conveniente.");
  {
    const s = content("Aspettative, promesse e narrazioni mediatiche", "Un modello spesso usato per descrivere l'andamento delle aspettative verso le nuove tecnologie è il cosiddetto 'hype cycle', proposto dalla società di analisi Gartner. Lo presentiamo come schema interpretativo, non come una legge: non tutte le tecnologie seguono questo percorso. Le fasi sono cinque. Un innesco tecnologico, cioè una novità che attira l'attenzione. Un picco di aspettative eccessive, alimentato da dimostrazioni spettacolari e da narrazioni mediatiche. Una fase di disillusione, quando le applicazioni reali si scontrano con limiti, costi e difficoltà. Una risalita più lenta, in cui si capisce dove la tecnologia funziona davvero. Infine un plateau di produttività, con un uso maturo e stabile. Abbiamo visto un andamento simile nella storia dell'AI, con i suoi inverni. Le diverse applicazioni dell'AI generativa possono trovarsi in fasi diverse. Le narrazioni mediatiche tendono a concentrarsi sugli estremi, cioè promesse straordinarie o rischi catastrofici, perché attirano attenzione. Domanda per il gruppo: dove pensate che si trovi oggi l'AI generativa? Non c'è una risposta unica: l'importante è motivarla. L'hype cycle è ripreso nel Tema 16, a proposito dell'adozione. Dopo la discussione si può aggiungere un dato: nelle sue analisi del 2025 Gartner ha collocato l'AI generativa nella fase di disillusione, dopo il picco del biennio precedente. Non significa che la tecnologia non funzioni, ma che le aspettative si stanno riallineando ai risultati concreti. Il dato va ricontrollato prima di ogni edizione, perché le posizioni nel ciclo cambiano ogni anno.");
    s.addChart(pres.charts.LINE, [{ name: "Aspettative", labels: ["", "", "", "", "", "", "", "", "", "", "", "", "", "", ""], values: [0.5, 2.5, 6, 9.5, 8, 5, 2.6, 2.2, 3.0, 4.0, 4.8, 5.4, 5.8, 6.0, 6.1] }], {
      x: 0.5, y: 1.15, w: 9.0, h: 3.0, lineSize: 3, lineDataSymbol: "none", lineSmooth: true, chartColors: [HEX.a1],
      valAxisHidden: true, catAxisHidden: true, valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 10.5,
    });
    const lab = [["Innesco tecnologico", 0.5], ["Picco di aspettative eccessive", 2.2], ["Fase di disillusione", 4.0], ["Risalita della comprensione", 5.8], ["Plateau di produttività", 7.6]];
    lab.forEach((l, i) => {
      shapeBox(s, l[1], 4.25, 1.75, 0.6, i === 1 ? C.accent6 : C.background2, "fase " + l[0]);
      txt(s, l[0], { x: l[1] + 0.05, y: 4.25, w: 1.65, h: 0.6, fontSize: 12, bold: true, color: C.text1, align: "center", valign: "middle" });
    });
    txt(s, "Schema \"hype cycle\" di Gartner, a scopo interpretativo", { x: 0.5, y: 4.92, w: 6, h: 0.25, fontSize: 10, italic: true, color: C.accent2 });
  }
  {
    const s = content("Dimostrazione tecnologica e uso aziendale continuativo", "Una delle fonti più frequenti di aspettative eccessive è la confusione tra ciò che si vede in una dimostrazione e ciò che serve per usare una tecnologia ogni giorno in azienda. Una demo mostra il caso migliore: un esempio scelto con cura, condizioni controllate, nessun vincolo di costo, nessuna integrazione con i sistemi esistenti. L'uso aziendale continuativo richiede invece che il sistema funzioni bene su tutti i casi reali, compresi quelli difficili e imprevisti; che sia affidabile nel tempo; che si integri con dati e processi esistenti; che rispetti sicurezza, privacy e normative; che abbia costi sostenibili; e che le persone lo usino davvero. La distanza tra 'funziona nella demo' e 'funziona in produzione' può essere molto grande. Domanda utile da porre davanti a qualunque dimostrazione: come si comporta il sistema sui nostri casi, con i nostri dati, nei casi difficili, e quanto costa farlo funzionare ogni giorno?");
    const rows = [["", "Dimostrazione", "Uso aziendale continuativo"], ["Casi", "Esempi scelti con cura", "Tutti i casi reali, anche difficili"], ["Condizioni", "Controllate", "Variabili e imprevedibili"], ["Durata", "Un momento", "Affidabilità nel tempo"], ["Integrazione", "Non necessaria", "Con dati, sistemi e processi"], ["Vincoli", "Pochi o nessuno", "Sicurezza, privacy, normative, costi"], ["Persone", "Un esperto la presenta", "Molti la usano ogni giorno"]];
    const tbl = rows.map((r, i) => r.map((c, j) => ({ text: c, options: { bold: i === 0 || j === 0, color: i === 0 && j > 0 ? C.background1 : C.text1, fill: { color: i === 0 ? (j === 2 ? C.accent1 : (j === 1 ? C.text2 : C.background1)) : (j === 2 ? C.accent6 : (j === 1 ? C.background2 : C.background1)) }, fontSize: 13, valign: "middle", margin: [3, 8, 3, 8] } })));
    s.addTable(tbl, { x: 0.5, y: 1.2, w: 9.0, colW: [1.7, 3.4, 3.9], rowH: 0.47, border: { type: "solid", pt: 1, color: HEX.lt1 } });
    txt(s, "La domanda chiave: come si comporta con i nostri casi, i nostri dati, ogni giorno?", { x: 0.5, y: 4.7, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text1 });
  }
  {
    const s = content("Maturità delle capacità e limiti attuali", "Quanto sono mature oggi le capacità dell'AI generativa? La risposta onesta è: dipende dal compito. Ci sono attività in cui i sistemi attuali sono generalmente utili e relativamente consolidati, soprattutto quando una persona competente verifica il risultato: produrre bozze di testi, riassumere documenti, tradurre, riformulare, generare idee, supportare la scrittura di codice, estrarre informazioni da testi. Ci sono poi attività in cui serve maggiore cautela: fornire fatti precisi, dati, citazioni e riferimenti senza verifica; svolgere calcoli complessi senza strumenti appositi; prendere decisioni ad alto impatto senza supervisione umana; svolgere compiti lunghi e articolati in completa autonomia. Il confine si sposta nel tempo, perché le capacità evolvono rapidamente: ciò che oggi è limitato potrebbe migliorare, e per questo va rivalutato periodicamente. Restiamo a livello generale: le cause degli errori, le allucinazioni e i bias, e i metodi per valutare l'affidabilità sono oggetto del Tema 3. Aggiornare questa slide se necessario in base all'evoluzione degli strumenti al momento della sessione.");
    await card(s, 0.5, 1.2, 4.35, 3.4, { icon: "FiCheckCircle", head: "Generalmente utile, con verifica", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Bozze di testi e riformulazioni", "Sintesi di documenti", "Traduzioni", "Generazione di idee e alternative", "Supporto alla scrittura di codice", "Estrazione di informazioni da testi"], { space: 2 }) });
    await card(s, 5.15, 1.2, 4.35, 3.4, { icon: "FiAlertTriangle", head: "Richiede maggiore cautela", headSize: 16, bodySize: 13, iconBg: C.accent5,
      body: bullets(["Fatti, dati e citazioni senza verifica", "Calcoli complessi senza strumenti appositi", "Decisioni ad alto impatto senza supervisione", "Compiti lunghi in completa autonomia"], { space: 2 }) });
    txt(s, "Il confine si sposta nel tempo: va rivalutato periodicamente.", { x: 0.5, y: 4.72, w: 9, h: 0.35, fontSize: 13, italic: true, color: C.text2 });
  }
  {
    const s = content("Opportunità concrete o affermazioni non dimostrate?", "Come possiamo distinguere un'opportunità concreta da un'affermazione non dimostrata? Ecco sei domande semplici da porre davanti a qualunque promessa sull'AI, che arrivi da un fornitore, da un articolo o da un collega entusiasta. Chi lo afferma, e che interesse ha? Un fornitore ha legittimamente interesse a presentare il suo prodotto nel modo migliore. Su quali evidenze si basa? Un'opinione, un caso aneddotico, uno studio indipendente? In quale contesto è stato misurato? Un risultato ottenuto in un settore o su un compito non si trasferisce automaticamente al nostro. Rispetto a che cosa? Un miglioramento del 30% rispetto a quale situazione di partenza? Quanto costa davvero, considerando licenze, integrazione, formazione e tempo per verificare i risultati? Il risultato è ripetibile nel tempo, o è stato osservato una volta? Queste domande ci aiutano a passare da 'l'AI può fare X' a 'l'AI può fare X in modo affidabile e conveniente nel nostro contesto', che è la domanda che conta. Suggerimento: proporre ai partecipanti di applicare le sei domande a un titolo di giornale o a una pubblicità di un prodotto AI.");
    const q = [["FiUser", "Chi lo afferma?", "E che interesse ha?"], ["FiSearch", "Su quali evidenze?", "Opinione, aneddoto o studio indipendente?"], ["FiMapPin", "In quale contesto?", "Vale anche per il nostro?"], ["FiSliders", "Rispetto a che cosa?", "Qual è il punto di partenza?"], ["FiDollarSign", "Quanto costa davvero?", "Licenze, integrazione, formazione, verifica"], ["FiRepeat", "È ripetibile?", "Funziona stabilmente nel tempo?"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 3, row = Math.floor(i / 3);
      const x = 0.5 + col * 3.07, y = 1.2 + row * 1.85;
      shapeBox(s, x, y, 2.86, 1.68, C.background2, q[i][1]);
      await iconCircle(s, x + 0.2, y + 0.2, 0.5, q[i][0]);
      txt(s, q[i][1], { x: x + 0.85, y: y + 0.2, w: 1.9, h: 0.5, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, q[i][2], { x: x + 0.2, y: y + 0.85, w: 2.46, h: 0.7, fontSize: 13, color: C.text2 });
    }
  }
  {
    const s = content("I benefici non sono uguali per tutti", "Un aspetto spesso trascurato nelle narrazioni sull'AI è l'eterogeneità dei benefici: l'AI non migliora tutto e tutti nella stessa misura. Lo studio più citato su questo tema è quello condotto da ricercatori di Harvard Business School e altre università in collaborazione con Boston Consulting Group (Dell'Acqua e colleghi), presentato nel 2023 e pubblicato nel 2026 sulla rivista Organization Science, su 758 consulenti. Per compiti che rientravano nelle capacità dell'AI, i consulenti che la usavano hanno completato in media il 12,2% di compiti in più, il 25,1% più velocemente e con una qualità superiore in media del 32%. Ma per un compito scelto appositamente al di fuori delle capacità dell'AI, chi la usava arrivava alla soluzione corretta meno spesso: in media 19 punti percentuali in meno rispetto a chi lavorava senza, che la trovava nell'84,5% dei casi. Se qualcuno ricorda il dato 'oltre il 40%' sulla qualità: viene dalla prima versione del 2023; la versione pubblicata riporta circa il 32%. Gli autori parlano di 'frontiera tecnologica frastagliata': i confini di ciò che l'AI sa fare bene sono irregolari e non intuitivi, e compiti apparentemente simili possono trovarsi da parti opposte. Anche lo studio sull'assistenza clienti visto prima mostrava benefici molto diversi tra operatori più e meno qualificati. Conclusione: i benefici variano tra attività, persone e organizzazioni, e saper riconoscere quando usare l'AI è una competenza. Fonte: Dell'Acqua et al., 'Navigating the Jagged Technological Frontier', Organization Science, 37(2), 2026. Lo studio è ripreso nei Temi 3 e 12.");
    txt(s, "Studio su 758 consulenti (Harvard Business School e BCG, pubblicato nel 2026)", { x: 0.5, y: 1.15, w: 9, h: 0.3, fontSize: 13, color: C.text2 });
    shapeBox(s, 0.5, 1.55, 5.6, 2.75, C.accent6, "dentro la frontiera");
    txt(s, "Compiti adatti alle capacità dell'AI", { x: 0.7, y: 1.68, w: 5.2, h: 0.35, fontSize: 14, bold: true, color: C.text1 });
    const st = [["+12,2%", "compiti completati"], ["+25,1%", "velocità"], ["+32%", "qualità, in media"]];
    st.forEach((e, i) => {
      txt(s, e[0], { x: 0.7 + i * 1.75, y: 2.2, w: 1.7, h: 0.75, fontSize: 30, bold: true, color: C.accent1 });
      txt(s, e[1], { x: 0.7 + i * 1.75, y: 2.95, w: 1.7, h: 0.5, fontSize: 13, color: C.text1 });
    });
    shapeBox(s, 6.35, 1.55, 3.15, 2.75, C.text1, "fuori dalla frontiera");
    txt(s, "Compito fuori dalle capacità dell'AI", { x: 6.55, y: 1.68, w: 2.8, h: 0.6, fontSize: 14, bold: true, color: C.background1 });
    txt(s, "-19 punti", { x: 6.55, y: 2.3, w: 2.8, h: 0.7, fontSize: 30, bold: true, color: C.accent5 });
    txt(s, "percentuali di probabilità di arrivare alla soluzione corretta", { x: 6.55, y: 3.0, w: 2.8, h: 0.9, fontSize: 13, color: C.background1 });
    txt(s, "Una \"frontiera frastagliata\": compiti simili possono stare da parti opposte del confine. Saper riconoscere quando usare l'AI è una competenza.", { x: 0.5, y: 4.4, w: 9, h: 0.5, fontSize: 13, italic: true, color: C.text1 });
    txt(s, "Fonte: Dell'Acqua et al., Organization Science, 2026", { x: 0.5, y: 4.92, w: 6, h: 0.25, fontSize: 10, color: C.accent2 });
  }
  {
    const s = content("Velocità del cambiamento e incertezza sul futuro", "L'AI evolve rapidamente, e questo genera sia entusiasmo sia ansia. Per orientarsi è utile distinguere due tipi di affermazioni. Le evoluzioni osservabili: capacità che possiamo verificare oggi, strumenti disponibili, risultati misurati in studi e in contesti reali. E le previsioni: affermazioni su ciò che accadrà, quanto rapidamente e con quali effetti. Le previsioni sull'AI hanno una lunga storia di errori, in entrambe le direzioni: i pionieri degli anni Cinquanta e Sessanta prevedevano macchine intelligenti come l'uomo entro pochi decenni, mentre pochi avevano previsto la rapidità dei progressi recenti nel linguaggio. In questo contesto rientrano anche concetti come l'AGI, l'intelligenza artificiale generale, cioè un sistema capace di svolgere la maggior parte dei compiti cognitivi umani, e la cosiddetta 'singolarità', l'ipotesi di un punto in cui il progresso tecnologico diventerebbe inarrestabile e imprevedibile. Sono temi legittimi del dibattito pubblico e scientifico, su cui esperti autorevoli hanno posizioni molto diverse, sia sui tempi sia sulla possibilità stessa. Il nostro atteggiamento: prendere sul serio il cambiamento, senza trattare le previsioni come certezze.");
    await card(s, 0.5, 1.2, 4.35, 2.55, { icon: "FiEye", head: "Evoluzioni osservabili", headSize: 16, bodySize: 13, fill: C.accent6,
      body: bullets(["Capacità verificabili oggi", "Strumenti effettivamente disponibili", "Risultati misurati in contesti reali"], { space: 3 }) });
    await card(s, 5.15, 1.2, 4.35, 2.55, { icon: "FiCloudDrizzle", head: "Previsioni", headSize: 16, bodySize: 13,
      body: bullets(["Che cosa accadrà, e quando", "Con quali effetti su lavoro e società", "Storicamente spesso errate, in entrambe le direzioni"], { space: 3 }) });
    shapeBox(s, 0.5, 3.95, 9.0, 1.0, C.background2, "AGI e singolarità");
    await iconCircle(s, 0.7, 4.17, 0.56, "FiHelpCircle", C.accent2);
    txt(s, [{ text: "AGI e singolarità ", options: { bold: true, color: C.text1 } }, { text: "fanno parte del dibattito sulle aspettative: esperti autorevoli hanno posizioni molto diverse su tempi e possibilità.", options: { color: C.text2 } }], { x: 1.45, y: 3.95, w: 7.9, h: 1.0, fontSize: 14, valign: "middle" });
  }
  {
    const s = content("Competenze adattabili, non dipendenza dagli strumenti", "Se il futuro è incerto e gli strumenti cambiano rapidamente, su che cosa conviene investire? La risposta di questo percorso è chiara: sulle competenze adattabili, più che sulla padronanza di un singolo strumento. Gli strumenti e le loro interfacce cambiano ogni pochi mesi; un prodotto oggi leader potrebbe essere superato domani; le funzionalità si aggiornano continuamente. Ciò che resta valido nel tempo sono invece le competenze di fondo: comprendere i principi di funzionamento dell'AI, che vedremo nel Tema 2; saper valutare criticamente gli output e la loro affidabilità, oggetto dei Temi 3 e 7; saper formulare bene problemi e richieste, oggetto dei Temi 5 e 6; conoscere i rischi e le regole d'uso, oggetto dei Temi 17 e 18; mantenere un atteggiamento di apprendimento continuo. Chi possiede queste competenze può passare da uno strumento all'altro senza ricominciare da zero e può valutare con lucidità le novità che arrivano. È esattamente l'obiettivo dell'AI Literacy: non formare utenti di un prodotto, ma persone capaci di usare l'AI in modo consapevole, qualunque forma assuma.");
    txt(s, "Cambia rapidamente", { x: 0.5, y: 1.2, w: 3.6, h: 0.35, fontSize: 15, bold: true, color: C.text2 });
    ["Singoli strumenti e prodotti", "Interfacce e funzionalità", "Posizioni di mercato"].forEach((t, i) => {
      shapeBox(s, 0.5, 1.65 + i * 0.75, 3.6, 0.62, C.background2, t);
      txt(s, t, { x: 0.7, y: 1.65 + i * 0.75, w: 3.3, h: 0.62, fontSize: 14, color: C.text2, valign: "middle" });
    });
    arrow(s, 4.3, 2.5, 0.6, C.accent1);
    txt(s, "Resta valido nel tempo", { x: 5.1, y: 1.2, w: 4.4, h: 0.35, fontSize: 15, bold: true, color: C.accent1 });
    const k = [["FiCpu", "Comprendere i principi di funzionamento"], ["FiEye", "Valutare criticamente gli output"], ["FiEdit3", "Formulare bene problemi e richieste"], ["FiShield", "Conoscere rischi e regole d'uso"], ["FiRefreshCw", "Apprendere in modo continuo"]];
    for (let i = 0; i < 5; i++) {
      const y = 1.65 + i * 0.62;
      await iconCircle(s, 5.1, y, 0.46, k[i][0]);
      txt(s, k[i][1], { x: 5.75, y, w: 3.75, h: 0.46, fontSize: 14, color: C.text1, valign: "middle" });
    }
    txt(s, "Non utenti di un prodotto, ma persone capaci di usare l'AI in modo consapevole.", { x: 0.5, y: 4.75, w: 9, h: 0.35, fontSize: 14, italic: true, color: C.text1 });
  }
  keySlide("Occorre valutare criticamente le promesse dell'AI, distinguendo possibilità tecniche, affidabilità e convenienza.", "Sottotema 1.6  ·  Tra hype e realtà", "Concetto chiave dell'ultimo sottotema. Tre domande diverse, da non confondere. È tecnicamente possibile? Molte cose lo sono, almeno in una demo. È affidabile? Cioè funziona in modo costante sui casi reali, con un livello di errore accettabile per l'uso previsto. È conveniente? Cioè i benefici superano i costi complessivi, compresi integrazione, formazione e verifica. Una risposta positiva alla prima domanda non garantisce risposte positive alle altre due. A questo si aggiungono due atteggiamenti: riconoscere che i benefici sono eterogenei e distinguere ciò che è osservabile da ciò che è previsto. Domanda di verifica: pensate a una notizia recente sull'AI. In quale delle tre categorie rientra: possibilità, affidabilità o convenienza?");

  // =====================================================================
  section("Conclusioni");
  {
    const s = content("Le domande guida: le nostre risposte", "Torniamo alle sei domande guida dell'inizio e proviamo a rispondere in modo sintetico. Perché se ne parla tanto? Per la convergenza di più fattori tecnologici e per la svolta dell'AI generativa, che l'ha resa accessibile a tutti. È una tecnologia nuova? No: ha oltre settant'anni di storia; è nuova la sua diffusione. Che cosa è cambiato con l'AI generativa? L'AI genera contenuti e si usa con il linguaggio naturale. In che cosa differisce dalle tecnologie precedenti? Apprende dai dati e funziona in modo probabilistico, non deterministico. Perché riguarda la mia azienda? Perché è trasversale e abilitante, e oggi accessibile tramite strumenti commerciali. Quali aspettative sono ragionevoli? Quelle basate su evidenze osservabili nel proprio contesto; il resto va trattato come incerto. Suggerimento: prima di mostrare le risposte, chiedere ai partecipanti di formularle con parole proprie.");
    const qa = [["Perché se ne parla tanto?", "Convergenza di più fattori e svolta generativa"], ["È una tecnologia nuova?", "No: oltre 70 anni di storia; è nuova la diffusione"], ["Che cosa ha cambiato l'AI generativa?", "Genera contenuti e si usa col linguaggio naturale"], ["Che cosa la distingue dal digitale?", "Apprende dai dati e funziona in modo probabilistico"], ["Perché riguarda la mia azienda?", "È trasversale, abilitante e accessibile"], ["Quali aspettative sono ragionevoli?", "Quelle basate su evidenze nel proprio contesto"]];
    qa.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.2 + row * 1.25;
      shapeBox(s, x, y, 4.4, 1.12, C.background2, "risposta " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.18, y: y + 0.12, w: 0.4, h: 0.45, fontSize: 20, bold: true, color: C.accent1 });
      txt(s, e[0], { x: x + 0.6, y: y + 0.12, w: 3.65, h: 0.4, fontSize: 14, bold: true, color: C.text1 });
      txt(s, e[1], { x: x + 0.6, y: y + 0.55, w: 3.65, h: 0.5, fontSize: 13, color: C.text2 });
    });
  }
  {
    const s = content("Che cosa portiamo a casa", "Riassumiamo i cinque risultati attesi del modulo. Primo: l'AI esiste da decenni e l'AI generativa è una fase importante, ma non l'unica, della sua evoluzione. Secondo: il linguaggio naturale ha contribuito in modo decisivo a rendere l'AI accessibile a un pubblico molto ampio. Terzo: l'AI è una tecnologia abilitante, applicabile a diverse attività e settori. Quarto: il potenziale tecnologico non garantisce automaticamente benefici economici o organizzativi; il valore va costruito e misurato. Quinto: le evoluzioni future sono incerte, ed è quindi utile sviluppare capacità critiche e adattabili. Se i partecipanti escono da questo modulo con questi cinque concetti, il primo obiettivo del percorso è raggiunto.");
    const r = [["FiClock", "L'AI esiste da decenni: l'AI generativa è una fase importante della sua evoluzione"], ["FiMessageCircle", "Il linguaggio naturale ha reso l'AI accessibile a un pubblico molto ampio"], ["FiGrid", "L'AI è una tecnologia abilitante, applicabile a diverse attività e settori"], ["FiTarget", "Il potenziale tecnologico non garantisce automaticamente benefici"], ["FiCompass", "Il futuro è incerto: servono capacità critiche e adattabili"]];
    for (let i = 0; i < 5; i++) {
      const y = 1.2 + i * 0.76;
      shapeBox(s, 0.5, y, 9.0, 0.66, i % 2 ? C.background1 : C.background2, "risultato " + (i + 1));
      await iconCircle(s, 0.65, y + 0.1, 0.46, r[i][0]);
      txt(s, r[i][1], { x: 1.3, y, w: 8.0, h: 0.66, fontSize: 15, color: C.text1, valign: "middle" });
    }
  }
  {
    const s = content("Davanti a una novità sull'AI: una scheda pratica", "Traduciamo il modulo in una scheda pratica: sei domande da porsi quando arriva una novità sull'AI, che sia la proposta di un fornitore, un articolo, una nuova funzione in un software che usiamo o l'idea di un collega. Primo: che cosa fa davvero? Genera contenuti, classifica, prevede, oppure segue regole fisse? È la distinzione dei sottotemi 1.3 e 1.4. Secondo: è davvero AI, o si tratta di digitalizzazione o di automazione a regole, magari più semplici ed economiche? Sottotema 1.4. Terzo: quale problema reale risolve per noi, e chi ne beneficia? Sottotema 1.5. Quarto: su quali evidenze si basa, e ottenute in quale contesto? Sottotema 1.6. Quinto: è possibile, affidabile e conveniente nel nostro caso, non solo in una dimostrazione? Ancora 1.6. Sesto: chi verifica i risultati, e quanto costa farlo? La natura probabilistica dei sistemi AI, vista nel sottotema 1.4, rende la verifica parte del costo. Le domande non richiedono competenze tecniche: servono a far emergere ciò che manca prima di prendere una decisione. Suggerimento: proporre ai partecipanti di applicare la scheda a una novità sull'AI che hanno letto o ricevuto di recente.");
    const f = [["Che cosa fa davvero?", "Genera, classifica, prevede o segue regole?", "1.3  1.4"], ["È davvero AI?", "O bastano digitalizzazione e automazione?", "1.4"], ["Quale problema risolve?", "Un bisogno reale, per chi?", "1.5"], ["Su quali evidenze?", "Misurate in quale contesto?", "1.6"], ["Possibile, affidabile, conveniente?", "Nel nostro caso, non solo nella demo", "1.6"], ["Chi verifica i risultati?", "E quanto costa farlo?", "1.4  1.5"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.0;
      shapeBox(s, x, y, 4.4, 0.88, row % 2 ? C.accent6 : C.background2, "scheda " + (i + 1));
      txt(s, String(i + 1), { x: x + 0.15, y, w: 0.4, h: 0.88, fontSize: 20, bold: true, color: C.accent1, valign: "middle" });
      txt(s, f[i][0], { x: x + 0.6, y: y + 0.08, w: 2.9, h: 0.38, fontSize: 14, bold: true, color: C.text1, valign: "middle" });
      txt(s, f[i][1], { x: x + 0.6, y: y + 0.46, w: 2.9, h: 0.36, fontSize: 12, color: C.text2 });
      txt(s, f[i][2], { x: x + 3.45, y, w: 0.85, h: 0.88, fontSize: 11, bold: true, color: C.accent1, align: "right", valign: "middle" });
    }
    banner(s, 4.25, "Domande semplici, senza competenze tecniche, che fanno emergere ciò che manca prima di decidere.", { h: 0.65, fontSize: 13 });
  }
  {
    const s = content("Che cosa evitare", "Chiudiamo con sei semplificazioni da evitare, una per sottotema, che riassumono in negativo i messaggi del modulo. Primo: pensare che l'AI sia nata con ChatGPT. È una tecnologia con oltre settant'anni di storia; ciò che è nuovo è la sua diffusione. Secondo: attribuire l'accelerazione a una singola invenzione o a un singolo prodotto. È stata la convergenza di calcolo, dati, algoritmi, scala e investimenti. Terzo: confondere la facilità d'uso con la facilità di ottenere buoni risultati. Scrivere una richiesta è facile; scriverne una efficace e valutare la risposta sono competenze. Quarto: chiamare AI qualunque automazione, o usare l'AI dove basterebbe una regola. Digitalizzazione, automazione e AI sono cose diverse, e spesso la soluzione più semplice è la migliore. Quinto: partire dalla tecnologia invece che dal problema. Il valore nasce da applicazioni appropriate a problemi reali. Sesto: scambiare una dimostrazione o una previsione per un risultato. Ciò che conta è come il sistema si comporta sui nostri casi, ogni giorno. Suggerimento: chiedere ai partecipanti quale di queste semplificazioni hanno sentito più spesso, in azienda o nei media.");
    const a = [["FiClock", "\"L'AI è nata con ChatGPT\"", "Oltre 70 anni di storia: è nuova la diffusione", "1.1"], ["FiZap", "\"È merito di una sola invenzione\"", "Convergenza di più fattori", "1.2"], ["FiMessageCircle", "\"Facile da usare, quindi facile da usare bene\"", "Richiedere e valutare sono competenze", "1.3"], ["FiSettings", "\"Tutto ciò che è automatico è AI\"", "Spesso basta una regola", "1.4"], ["FiTarget", "\"Prima lo strumento, poi il problema\"", "Il valore parte da un problema reale", "1.5"], ["FiPlayCircle", "\"Se funziona nella demo, funziona da noi\"", "Contano i nostri casi, ogni giorno", "1.6"]];
    for (let i = 0; i < 6; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      const x = 0.5 + col * 4.6, y = 1.15 + row * 1.27;
      shapeBox(s, x, y, 4.4, 1.12, row % 2 ? C.accent6 : C.background2, "evitare " + (i + 1));
      await iconCircle(s, x + 0.18, y + 0.18, 0.5, a[i][0], C.accent5);
      txt(s, a[i][1], { x: x + 0.8, y: y + 0.1, w: 3.0, h: 0.55, fontSize: 13, bold: true, color: C.text1, valign: "middle" });
      txt(s, a[i][2], { x: x + 0.8, y: y + 0.66, w: 3.0, h: 0.38, fontSize: 12, color: C.text2 });
      txt(s, a[i][3], { x: x + 3.75, y: y + 0.1, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: C.accent1, align: "right" });
    }
  }
  {
    const s = content("Prossimo passo: il Tema 2", "Chiudiamo con uno sguardo al prossimo modulo. In questo primo tema abbiamo costruito il contesto: abbiamo visto da dove arriva l'AI, perché è centrale oggi e perché ci riguarda, sviluppando uno sguardo critico. Nel Tema 2 entreremo nel funzionamento: che cos'è davvero l'Intelligenza Artificiale e in che cosa differisce dall'intelligenza umana; quali sono le principali categorie di AI; come un sistema apprende dai dati; che cosa sono i Large Language Models; che cosa succede quando inviamo una richiesta a un assistente AI; da dove provengono le informazioni che usa; e perché le risposte possono variare. Molti concetti che oggi abbiamo solo accennato, come il funzionamento probabilistico, i parametri o il Transformer, troveranno lì una spiegazione chiara e intuitiva. Lasciare spazio alle domande finali. Slide facoltativa: se il modulo è presentato da solo o in una selezione di slide, può essere nascosta o tolta senza perdere nulla del contenuto.");
    shapeBox(s, 0.5, 1.2, 3.6, 3.75, C.background2, "tema 1");
    txt(s, "TEMA 1", { x: 0.75, y: 1.4, w: 3.1, h: 0.35, fontSize: 13, bold: true, color: C.accent2, charSpacing: 2 });
    txt(s, "Evoluzione e rilevanza", { x: 0.75, y: 1.8, w: 3.1, h: 0.5, fontSize: 18, bold: true, color: C.text1 });
    txt(s, bullets(["Da dove arriva l'AI", "Perché è centrale oggi", "Perché ci riguarda", "Come valutarne le promesse"], { space: 4 }), { x: 0.75, y: 2.45, w: 3.1, h: 2.2, fontSize: 14, color: C.text2 });
    arrow(s, 4.25, 2.9, 0.55, C.accent1);
    shapeBox(s, 4.95, 1.2, 4.55, 3.75, C.text1, "tema 2");
    txt(s, "TEMA 2", { x: 5.2, y: 1.4, w: 4.0, h: 0.35, fontSize: 13, bold: true, color: C.accent1, charSpacing: 2 });
    txt(s, "Fondamenti e funzionamento", { x: 5.2, y: 1.8, w: 4.1, h: 0.5, fontSize: 18, bold: true, color: C.background1 });
    txt(s, bullets(["Che cos'è davvero l'AI", "Come apprende dai dati", "Che cosa sono gli LLM", "Che cosa accade quando inviamo un prompt", "Da dove arrivano le informazioni", "Perché le risposte variano"], { space: 3 }), { x: 5.2, y: 2.45, w: 4.1, h: 2.3, fontSize: 14, color: C.accent3 });
  }
  {
    const notes1 = "Questa slide e la successiva raccolgono le fonti citate nel modulo, ordinate per sottotema, utili sia al relatore per approfondire sia ai partecipanti che desiderano leggere gli originali. Qui ci sono le fonti storiche e tecniche dei sottotemi 1.1 e 1.2: dagli articoli fondativi di Turing e di Dartmouth fino agli articoli che hanno introdotto il Transformer, i grandi modelli linguistici e le leggi di scala. Non è necessario leggerle tutte: per chi vuole approfondire, gli articoli di Turing e la proposta di Dartmouth sono sorprendentemente leggibili anche per un pubblico non tecnico.";
    const s = content("Fonti e riferimenti (1 di 2)", notes1);
    const src = [
      "Turing, A. M. (1950). Computing Machinery and Intelligence. Mind, 59(236).",
      "McCarthy, J., Minsky, M., Rochester, N., Shannon, C. (1955). A Proposal for the Dartmouth Summer Research Project on Artificial Intelligence.",
      "Rosenblatt, F. (1958). The Perceptron: A Probabilistic Model for Information Storage and Organization in the Brain. Psychological Review, 65(6).",
      "Shortliffe, E. H. (1976). Computer-Based Medical Consultations: MYCIN. Elsevier.",
      "Rumelhart, D. E., Hinton, G. E., Williams, R. J. (1986). Learning representations by back-propagating errors. Nature, 323.",
      "Deng, J. et al. (2009). ImageNet: A Large-Scale Hierarchical Image Database. CVPR.",
      "Krizhevsky, A., Sutskever, I., Hinton, G. E. (2012). ImageNet Classification with Deep Convolutional Neural Networks. NeurIPS.",
      "Vaswani, A. et al. (2017). Attention Is All You Need. NeurIPS.",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 4 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.85, fontSize: 12, color: C.text1 });
  }
  {
    const notes2 = "Qui ci sono le fonti dei sottotemi dal 1.2 al 1.6: gli articoli sui grandi modelli, la stima di Epoch AI sulla crescita del calcolo, la stima sulla diffusione di ChatGPT e i due studi sulla produttività. Per i due studi sono indicate le versioni pubblicate su rivista, che riportano valori in parte diversi dalle prime versioni del 2023, ancora molto citate. Tutti i dati di questo modulo sono stati verificati a ottobre 2026. I dati quantitativi, in particolare quelli su adozione, investimenti, capacità dei modelli e posizione nel ciclo delle aspettative, cambiano rapidamente: prima di ogni edizione del corso è consigliabile verificarne l'attualità e, se necessario, aggiornarli.";
    const s = content("Fonti e riferimenti (2 di 2)", notes2);
    const src = [
      "Radford, A. et al. (2019). Language Models are Unsupervised Multitask Learners. OpenAI.",
      "Brown, T. et al. (2020). Language Models are Few-Shot Learners. NeurIPS.",
      "Kaplan, J. et al. (2020). Scaling Laws for Neural Language Models. arXiv:2001.08361.",
      "Ouyang, L. et al. (2022). Training language models to follow instructions with human feedback. NeurIPS.",
      "Epoch AI (2024). Training compute of frontier AI models grows by 4-5x per year.",
      "Reuters (febbraio 2023). Stima UBS sulla crescita degli utenti di ChatGPT.",
      "Brynjolfsson, E., Li, D., Raymond, L. (2025). Generative AI at Work. The Quarterly Journal of Economics, 140(2), 889-942.",
      "Dell'Acqua, F. et al. (2026). Navigating the Jagged Technological Frontier. Organization Science, 37(2), 403-423.",
      "Gartner (2025). Hype Cycle for Artificial Intelligence (modello interpretativo).",
    ];
    await iconCircle(s, 0.5, 1.25, 0.55, "FiBookmark");
    txt(s, bullets(src, { space: 4 }), { x: 1.3, y: 1.2, w: 8.2, h: 3.5, fontSize: 12, color: C.text1 });
    txt(s, "Dati verificati a ottobre 2026: ricontrollarli prima di ogni edizione.", { x: 1.3, y: 4.5, w: 8.2, h: 0.3, fontSize: 11, italic: true, color: C.accent2 });
  }

  await pres.writeFile({ fileName: "Tema1_Evoluzione_e_rilevanza_AI.pptx" });
  await applyTheme("Tema1_Evoluzione_e_rilevanza_AI.pptx", THEME);
  console.log("done");
})();
